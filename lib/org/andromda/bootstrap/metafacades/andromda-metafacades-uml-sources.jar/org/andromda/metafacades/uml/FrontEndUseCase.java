// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Represents a use case used in the "front end" of an application.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndUseCase
    extends UseCaseFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndUseCaseMetaType();

    /**
     * The name of the action class that forwards to this use case.
     * @return String
     */
    public String getActionClassName();

    /**
     * All forwards in this use case that are represented as actions.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getActionForwards();

    /**
     * The actions for this use-case. This will include the initial action to start the use-case.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getActions();

    /**
     * Returns the activity graph describing this use-case in more detail.
     * @return FrontEndActivityGraph
     */
    public FrontEndActivityGraph getActivityGraph();

    /**
     * Constains all forwards includes regular FrontEndForwards and all actiion forwards.
     * @return List
     */
    public List getAllForwards();

    /**
     * A map with keys sorted alphabetically, normalized across all different use-cases, views, etc.
     * @return Map
     */
    public Map getAllMessages();

    /**
     * All roles that directly or indirectly related to any "front-end" use cases.
     * @return List<Role>
     */
    public List<Role> getAllRoles();

    /**
     * Returns all struts use-cases in this "front end" application.
     * @return List<FrontEndUseCase>
     */
    public List<FrontEndUseCase> getAllUseCases();

    /**
     * All views for the application (not just the ones belonging to this use case).
     * @return Collection<FrontEndView>
     */
    public Collection<FrontEndView> getAllViews();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return Collection
     */
    public Collection getAllowedRoles();

    /**
     * Returns the controller for this use-case.
     * @return FrontEndController
     */
    public FrontEndController getController();

    /**
     * The name of the action on the controller that executions this use case.
     * @return String
     */
    public String getControllerAction();

    /**
     * TODO: Model Documentation for FrontEndUseCase.displayCondition
     * @return String
     */
    public String getDisplayCondition();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getFilename();

    /**
     * The key under which to store the action form passed along in this in this use-case.
     * @return String
     */
    public String getFormKey();

    /**
     * The name that will cause a forward to use case.
     * @return String
     */
    public String getForwardName();

    /**
     * All forwards contained in this use case.
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getForwards();

    /**
     * The name of the class that stores all the forwards paths.
     * @return String
     */
    public String getForwardsClassName();

    /**
     * The fully qualified name of the action class that forwards to this use case.
     * @return String
     */
    public String getFullyQualifiedActionClassName();

    /**
     * The fully qualified path to the action class that forwards to this use case.
     * @return String
     */
    public String getFullyQualifiedActionClassPath();

    /**
     * TODO: Model Documentation for FrontEndUseCase.icon
     * @return String
     */
    public String getIcon();

    /**
     * The path of the initial target going into this use case.
     * @return String
     */
    public String getInitialTargetPath();

    /**
     * The first view of this use case, this may actually return a view of another use case if the
     * first is found by traveling through the final state.
     * @return FrontEndView
     */
    public FrontEndView getInitialView();

    /**
     * The path to which this use case points.
     * @return String
     */
    public String getPath();

    /**
     * The root path for this use case (this is the path the directory containing the use case's
     * resources).
     * @return String
     */
    public String getPathRoot();

    /**
     * The final states linking to this use case
     * @return List<FrontEndFinalState>
     */
    public List<FrontEndFinalState> getReferencingFinalStates();

    /**
     * All use cases that are labled as registration use cases.
     * @return List<FrontEndUseCase>
     */
    public List<FrontEndUseCase> getRegistrationUseCases();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getRestPath();

    /**
     * Returns all roles that are directly and indirectly associated to this use-case.
     * @return List<Role>
     */
    public List<Role> getRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getSubstitutionName();

    /**
     * The title message key for this use-case.
     * @return String
     */
    public String getTitleKey();

    /**
     * The title message value for this use-case.
     * @return String
     */
    public String getTitleValue();

    /**
     * The variables for all views in this use-case. A parameter qualifies to be a variable when it
     * explicitely and directly receives it via an action.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getViewVariables();

    /**
     * All views that are part of this use case.
     * @return List<FrontEndView>
     */
    public List<FrontEndView> getViews();

    /**
     * Indicates that at least one client/server parameter found in the collection of existing
     * use-cases requires validation.
     * @return boolean
     */
    public boolean isApplicationValidationRequired();

    /**
     * True if this use-case is the entry point to the front end.
     * @return boolean
     */
    public boolean isEntryUseCase();

    /**
     * Indicates whether or not the initial target of this use case is a view or not.
     * @return boolean
     */
    public boolean isInitialTargetView();

    /**
     * Indicates whether or not this is a front-end registration use case.  Only one use case can be
     * labeled as a 'registration' use case.
     * @return boolean
     */
    public boolean isRegistrationUseCase();

    /**
     * Indicates if this use case is "secured".  This is true when there is at least one role
     * associated to it.
     * @return boolean
     */
    public boolean isSecured();

    /**
     * Indicates whether or not at least one parameter in this use-case require validation.
     * @return boolean
     */
    public boolean isValidationRequired();

    /**
     * Indicates whether or not at least one view in the use case has the same name as this use
     * case.
     * @return boolean
     */
    public boolean isViewHasNameOfUseCase();
}