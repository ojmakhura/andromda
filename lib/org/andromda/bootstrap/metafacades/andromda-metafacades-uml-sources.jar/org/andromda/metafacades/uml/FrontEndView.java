// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * Represents a view within a front end application.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndView
    extends FrontEndActionState
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndViewMetaType();

    /**
     * All those forwards that are actions.
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getActionForwards();

    /**
     * All actions that can be triggered on this view.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getActions();

    /**
     * All parameters for each action going out of this view.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getAllActionParameters();

    /**
     * All fields from all forms on the given view.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getAllFormFields();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return Collection
     */
    public Collection getAllowedRoles();

    /**
     * Represents an attribute on a classifier. UML2 maps both Attributes and AssociationEnds to
     * Property.
     * A property is a structural feature of a classifier that characterizes instances of the
     * classifier. A
     * property related by ownedAttribute to a classifier (other than an association) represents an
     * attribute and might also represent an association end. It relates an instance of the class to
     * a
     * value or set of values of the type of the attribute. A property represents a set of instances
     * that
     * are owned by a containing classifier instance. Property represents a declared state of one or
     * more
     * instances in terms of a named relationship to a value or values. When a property is an
     * attribute of
     * a classifier, the value or values are related to the instance of the classifier by being held
     * in
     * slots of the instance. The range of valid values represented by the property can be
     * controlled by
     * setting the property's type.
     * @return Collection<AttributeFacade>
     */
    public Collection<AttributeFacade> getAttributes();

    /**
     * A front-end parameter is a parameter passed between front-end action states.
     * @return Collection<FrontEndParameter>
     */
    public Collection<FrontEndParameter> getBackingValueVariables();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.displayCondition
     * @return String
     */
    public String getDisplayCondition();

    /**
     * A resource message key suited for the page's documentation.
     * @return String
     */
    public String getDocumentationKey();

    /**
     * A resource message value suited for the view's documentation.
     * @return String
     */
    public String getDocumentationValue();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getFilename();

    /**
     * All actions that have forms associated with them.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getFormActions();

    /**
     * The key that stores the form in which information is passed from one action to another.
     * @return String
     */
    public String getFormKey();

    /**
     * Gets the forwards which can be targgeted from this view.
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getForwards();

    /**
     * The name that corresponds to the from-outcome in an navigational rule.
     * @return String
     */
    public String getFromOutcome();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.frontEndClasses
     * @return Set<String>
     */
    public Set<String> getFrontEndClasses();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndView.fullyQualifiedPageObjectClassName
     * @return String
     */
    public String getFullyQualifiedPageObjectClassName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndView.fullyQualifiedPageObjectClassPath
     * @return String
     */
    public String getFullyQualifiedPageObjectClassPath();

    /**
     * The fully qualified name of this view's form populator.
     * @return String
     */
    public String getFullyQualifiedPopulator();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.icon
     * @return String
     */
    public String getIcon();

    /**
     * The default resource message key for this view.
     * @return String
     */
    public String getMessageKey();

    /**
     * A displayable version of this view's name.
     * @return String
     */
    public String getMessageValue();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.pageObjectBeanName
     * @return String
     */
    public String getPageObjectBeanName();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.pageObjectClassName
     * @return String
     */
    public String getPageObjectClassName();

    /**
     * The full path of the view resources (i.e. the JSP page).
     * @return String
     */
    public String getPath();

    /**
     * The name of the form populator for this view.
     * @return String
     */
    public String getPopulator();

    /**
     * The path to the form populator.
     * @return String
     */
    public String getPopulatorPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getRestPath();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.submitAction
     * @return String
     */
    public String getSubmitAction();

    /**
     * All tables belonging to the front end view.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getTables();

    /**
     * A resource message key suited for the view's title.
     * @return String
     */
    public String getTitleKey();

    /**
     * A default resource message value suited for the page's title.
     * @return String
     */
    public String getTitleValue();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.treePresent
     * @return Boolean
     */
    public Boolean getTreePresent();

    /**
     * The use-case of which this view is a member.
     * @return FrontEndUseCase
     */
    public FrontEndUseCase getUseCase();

    /**
     * All those variables that will be present as variables in the target view. These are the
     * trigger parameters on the incoming transitions.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getVariables();

    /**
     * True if this element carries the FrontEndView stereotype.
     * @return boolean
     */
    public boolean isFrontEndView();

    /**
     * Indicates whether or not this view has the same name as the use case in which it is
     * contained.
     * @return boolean
     */
    public boolean isHasNameOfUseCase();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndView.needsFileUpload
     * @return boolean
     */
    public boolean isNeedsFileUpload();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return boolean
     */
    public boolean isNonTableVariablesPresent();

    /**
     * Indicates if a populator is required for this view.
     * @return boolean
     */
    public boolean isPopulatorRequired();

    /**
     * Indicates if this view represents a popup.
     * @return boolean
     */
    public boolean isPopup();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return boolean
     */
    public boolean isTableVariablesPresent();

    /**
     * Indicates whether or not at least one parameter of an outgoing action in this view requires
     * validation.
     * @return boolean
     */
    public boolean isValidationRequired();
}