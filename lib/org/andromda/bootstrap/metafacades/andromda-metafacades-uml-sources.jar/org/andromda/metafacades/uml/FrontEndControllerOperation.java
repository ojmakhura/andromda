// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;
import java.util.List;

/**
 * Represents an operation modeled on a controller.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndControllerOperation
    extends OperationFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndControllerOperationMetaType();

    /**
     * The activity graph in which this controller operation is used.
     * @return FrontEndActivityGraph
     */
    public FrontEndActivityGraph getActivityGraph();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return Collection
     */
    public Collection getAllowedRoles();

    /**
     * All those actions that contain at least one front-end action state that is deferring to this
     * operation.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getDeferringActions();

    /**
     * The operation call that takes the appropriate form as an argument.
     * @return String
     */
    public String getFormCall();

    /**
     * The set of fields in the form made up form this controller operation's parameters.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getFormFields();

    /**
     * The form name the corresponds to this controller operation.
     * @return String
     */
    public String getFormName();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return String
     */
    public String getFormSignature();

    /**
     * The fully qualified form name.
     * @return String
     */
    public String getFullyQualifiedFormName();

    /**
     * The fully qualified path of the form file.
     * @return String
     */
    public String getFullyQualifiedFormPath();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return String
     */
    public String getHandleFormSignature();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return String
     */
    public String getHandleFormSignatureImplementation();

    /**
     * The controller implementation operation signature that takes the appropriate form (if this
     * operation has at least one form field) as an argument.
     * @return String
     */
    public String getImplementationFormSignature();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getRestPath();

    /**
     * For each front-end controller operation argument there must exist a form field for each
     * action deferring to that operation. This form field must carry the same name and must be of
     * the same type. True if this is the case, false otherwise.
     * @return boolean
     */
    public boolean isAllArgumentsHaveFormFields();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndControllerOperation.exposed
     * @return boolean
     */
    public boolean isExposed();

    /**
     * Indicates if the owner of this operation is a controller.
     * @return boolean
     */
    public boolean isOwnerIsController();
}