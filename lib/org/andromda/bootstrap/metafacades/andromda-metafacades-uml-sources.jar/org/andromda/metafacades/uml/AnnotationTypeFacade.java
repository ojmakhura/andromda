// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * TODO: Model Documentation for org.andromda.metafacades.uml.AnnotationTypeFacade
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AnnotationTypeFacade
    extends ClassifierFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isAnnotationTypeFacadeMetaType();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.AnnotationTypeFacade.retention
     * @return String
     */
    public String getRetention();

    /**
     * Tartgets
     * @return String
     */
    public String getTarget();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.AnnotationTypeFacade.documented
     * @return boolean
     */
    public boolean isDocumented();
}