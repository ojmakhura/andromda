// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;

/**
 * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndComponent
    extends ClassifierFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndComponentMetaType();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.beanName
     * @return String
     */
    public String getBeanName();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getChildComponents();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getComplexes();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getFrontEndAttributes();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.generateTable
     * @return Boolean
     */
    public Boolean getGenerateTable();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.mappedModel
     * @return String
     */
    public String getMappedModel();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.messageKey
     * @return String
     */
    public String getMessageKey();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getNonTables();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.path
     * @return String
     */
    public String getPath();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.tableColumnNames
     * @return Collection<String>
     */
    public Collection<String> getTableColumnNames();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getTableColumns();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.tableName
     * @return String
     */
    public String getTableName();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.tablePath
     * @return String
     */
    public String getTablePath();

    /**
     * TODO: Model Documentation for FrontEndAttribute
     * @return Collection<FrontEndAttribute>
     */
    public Collection<FrontEndAttribute> getTables();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndComponent.treePresent
     * @return Boolean
     */
    public Boolean getTreePresent();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return boolean
     */
    public boolean isTableVariablesPresent();
}