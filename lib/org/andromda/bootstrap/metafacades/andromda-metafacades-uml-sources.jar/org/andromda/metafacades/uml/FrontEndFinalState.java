// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.List;

/**
 * A final state represents the end of a use-case, in a "front-end" application this means its the
 * transition into the next front-end use case.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndFinalState
    extends FinalStateFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndFinalStateMetaType();

    /**
     * Parameters that are directly entering this final state, they will be able to survive a trip
     * to the next use-case.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getInterUseCaseParameters();

    /**
     * The path to which this final state points.
     * @return String
     */
    public String getPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndFinalState.targetController
     * @return FrontEndController
     */
    public FrontEndController getTargetController();

    /**
     * The controller bean name to which this final state points.
     * @return String
     */
    public String getTargetControllerBeanName();

    /**
     * The target controller to which this final state points.
     * @return String
     */
    public String getTargetControllerFullyQualifiedName();

    /**
     * The element to which this final state points.
     * @return ModelElementFacade
     */
    public ModelElementFacade getTargetElement();

    /**
     * The use case the final state is "targetting".
     * @return FrontEndUseCase
     */
    public FrontEndUseCase getTargetUseCase();

    /**
     * Indicates if this front end final state is contained within a FrontEndUseCase.
     * @return boolean
     */
    public boolean isContainedInFrontEndUseCase();
}