// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;

/**
 * A representation of the model object 'Activity'. The specification of parameterized behavior as
 * the coordinated sequencing of subordinate units whose individual elements are actions.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface EventFacade
    extends ModelElementFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isEventFacadeMetaType();

    /**
     * Represents an attribute on a classifier. UML2 maps both Attributes and AssociationEnds to
     * Property.
     * A property is a structural feature of a classifier that characterizes instances of the
     * classifier. A
     * property related by ownedAttribute to a classifier (other than an association) represents an
     * attribute and might also represent an association end. It relates an instance of the class to
     * a
     * value or set of values of the type of the attribute. A property represents a set of instances
     * that
     * are owned by a containing classifier instance. Property represents a declared state of one or
     * more
     * instances in terms of a named relationship to a value or values. When a property is an
     * attribute of
     * a classifier, the value or values are related to the instance of the classifier by being held
     * in
     * slots of the instance. The range of valid values represented by the property can be
     * controlled by
     * setting the property's type.
     * @return Collection<AttributeFacade>
     */
    public Collection<AttributeFacade> getAttributes();

    /**
     * The parameters to this event.
     * @return Collection<ParameterFacade>
     */
    public Collection<ParameterFacade> getParameters();

    /**
     * If this event is located on an action state, this will represent that state.
     * @return StateFacade
     */
    public StateFacade getState();

    /**
     * If this event is located on a transition, this represents that transition.
     * @return TransitionFacade
     */
    public TransitionFacade getTransition();
}