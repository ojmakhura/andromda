// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;

/**
 * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndManageableEntityAttribute
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndManageableEntityAttribute
    extends ManageableEntityAttribute
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndManageableEntityAttributeMetaType();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.backingListName
     * @return String
     */
    public String getBackingListName();

    /**
     * The String format to use when referring to this date, only makes sense when the type is a
     * date type.
     * @return String
     */
    public String getDateFormat();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.dateFormatter
     * @return String
     */
    public String getDateFormatter();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.defaultDateFormat
     * @return String
     */
    public String getDefaultDateFormat();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.defaultTimeFormat
     * @return String
     */
    public String getDefaultTimeFormat();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.dummyValue
     * @return String
     */
    public String getDummyValue();

    /**
     * Gets the unique id of this attribute on the form.
     * @param ownerParameter ParameterFacade
     * @return String
     */
    public String getFormPropertyId(ParameterFacade ownerParameter);

    /**
     * Retrieves the name of the form property for this attribute by taking the name of the owner
     * property.
     * @param ownerParameter ParameterFacade
     * @return String
     */
    public String getFormPropertyName(ParameterFacade ownerParameter);

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.format
     * @return String
     */
    public String getFormat();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputTableIdentifierColumns
     * @return String
     */
    public String getInputTableIdentifierColumns();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.labelListName
     * @return String
     */
    public String getLabelListName();

    /**
     * The max length allowed in the input component
     * @return String
     */
    public String getMaxLength();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.messageKey
     * @return String
     */
    public String getMessageKey();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.messageValue
     * @return String
     */
    public String getMessageValue();

    /**
     * The key to lookup the online help documentation. This documentation is gathered from the
     * documentation entered by the user, as well as analyzing the model.
     * @return String
     */
    public String getOnlineHelpKey();

    /**
     * The online help documentation. This documentation is gathered from the documentation entered
     * by the user, as well as analyzing the model. The format is HTML without any style.
     * @return String
     */
    public String getOnlineHelpValue();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.timeFormatter
     * @return String
     */
    public String getTimeFormatter();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.validWhen
     * @return String
     */
    public String getValidWhen();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.getValidatorArgs
     * @param validatorType String
     * @return Collection
     */
    public Collection getValidatorArgs(String validatorType);

    /**
     * All validator types for this attribute.
     * @return Collection
     */
    public Collection getValidatorTypes();

    /**
     * The validator variables.
     * @return Collection
     */
    public Collection getValidatorVars();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.valueListDummyValue
     * @return String
     */
    public String getValueListDummyValue();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.valueListName
     * @return String
     */
    public String getValueListName();

    /**
     * The widget to use when rendering this attribute
     * @return String
     */
    public String getWidgetType();

    /**
     * Whether or not this attribute should be put in the view
     * @return boolean
     */
    public boolean isEditable();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.equalValidator
     * @return boolean
     */
    public boolean isEqualValidator();

    /**
     * Whether or not this attribute should be hidden from the view
     * @return boolean
     */
    public boolean isHidden();

    /**
     * Indicates whether or not this is an table input type.
     * @return boolean
     */
    public boolean isInputButton();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputCheckbox
     * @return boolean
     */
    public boolean isInputCheckbox();

    /**
     * Indicates whether or not this is an table input type.
     * @return boolean
     */
    public boolean isInputColor();

    /**
     * Indicates whether or not this is an table input type.
     * @return boolean
     */
    public boolean isInputDate();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return boolean
     */
    public boolean isInputDatetimeLocal();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return boolean
     */
    public boolean isInputEmail();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputFile
     * @return boolean
     */
    public boolean isInputFile();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputHidden
     * @return boolean
     */
    public boolean isInputHidden();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return boolean
     */
    public boolean isInputImage();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputMonth();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputMultibox
     * @return boolean
     */
    public boolean isInputMultibox();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputNumber();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputRadio
     * @return boolean
     */
    public boolean isInputRadio();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputRange();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return boolean
     */
    public boolean isInputReset();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return boolean
     */
    public boolean isInputSearch();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputSecret
     * @return boolean
     */
    public boolean isInputSecret();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputSelect
     * @return boolean
     */
    public boolean isInputSelect();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputSubmit();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputTable
     * @return boolean
     */
    public boolean isInputTable();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return boolean
     */
    public boolean isInputTel();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputText
     * @return boolean
     */
    public boolean isInputText();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputTextarea
     * @return boolean
     */
    public boolean isInputTextarea();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputTime();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.inputTypePresent
     * @return boolean
     */
    public boolean isInputTypePresent();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputUrl();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return boolean
     */
    public boolean isInputWeek();

    /**
     * True if this attribute is of a type that cannot easily be represented as a textual string and
     * would be an ideal candidate for HTTP's support for file-upload.
     * @return boolean
     */
    public boolean isNeedsFileUpload();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntityAttribute.plaintext
     * @return boolean
     */
    public boolean isPlaintext();

    /**
     * True if this field is a date type and the date format is not be interpreted strictly.
     * @return boolean
     */
    public boolean isStrictDateFormat();

    /**
     * Indicates whether or not this attribute requires some kind of validation (the collection of
     * validator types is not empty).
     * @return boolean
     */
    public boolean isValidationRequired();
}