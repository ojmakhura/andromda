// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;

/**
 * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndManageableEntity
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndManageableEntity
    extends ManageableEntity
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndManageableEntityMetaType();

    /**
     * The name of the action class that executes the manageable actions.
     * @return String
     */
    public String getActionClassName();

    /**
     * The fully qualified path to the action class that execute the manageable actions.
     * @return String
     */
    public String getActionFullPath();

    /**
     * The path to the action class that execute the manageable actions.
     * @return String
     */
    public String getActionPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.getActionRoles
     * @return String
     */
    public String getActionRoles();

    /**
     * The calcuated serial version UID for this manageable actions.
     * @return String
     */
    public String getActionSerialVersionUID();

    /**
     * The fully qualified name of the action class that execute the manageable actions.
     * @return String
     */
    public String getActionType();

    /**
     * The bean name of this manageable controller (this is what is stored in the JSF configuration
     * file).
     * @return String
     */
    public String getControllerBeanName();

    /**
     * Full path of this manageable controller.
     * @return String
     */
    public String getControllerFullPath();

    /**
     * Manageable controller class name.
     * @return String
     */
    public String getControllerName();

    /**
     * Fully qualified name of this manageable controller.
     * @return String
     */
    public String getControllerType();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.converterClassName
     * @return String
     */
    public String getConverterClassName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.converterFullPath
     * @return String
     */
    public String getConverterFullPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.converterType
     * @return String
     */
    public String getConverterType();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.exceptionKey
     * @return String
     */
    public String getExceptionKey();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.exceptionPath
     * @return String
     */
    public String getExceptionPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.formBeanClassName
     * @return String
     */
    public String getFormBeanClassName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.formBeanFullPath
     * @return String
     */
    public String getFormBeanFullPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.formBeanName
     * @return String
     */
    public String getFormBeanName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.formBeanType
     * @return String
     */
    public String getFormBeanType();

    /**
     * The calcuated serial version UID for this action's form.
     * @return String
     */
    public String getFormSerialVersionUID();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.listGetterName
     * @return String
     */
    public String getListGetterName();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndManageableEntity.listName
     * @return String
     */
    public String getListName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.listSetterName
     * @return String
     */
    public String getListSetterName();

    /**
     * Master/details associations: composition with reverse visibility.
     * @return Collection
     */
    public Collection getManageableDetailsAssociationsEnds();

    /**
     * returns all editable attributes
     * @return Collection
     */
    public Collection getManageableEditAttributes();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.manageableSearchAssociationEnds
     * @return Collection
     */
    public Collection getManageableSearchAssociationEnds();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.manageableSearchAttributes
     * @return Collection
     */
    public Collection getManageableSearchAttributes();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.messageKey
     * @return String
     */
    public String getMessageKey();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.messageValue
     * @return String
     */
    public String getMessageValue();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.odsExportFullPath
     * @return String
     */
    public String getOdsExportFullPath();

    /**
     * The full path to this entity's online help action. The returned String does not have a suffix
     * such as '.do'.
     * @return String
     */
    public String getOnlineHelpActionPath();

    /**
     * The key to lookup the online help documentation.
     * @return String
     */
    public String getOnlineHelpKey();

    /**
     * The full path to this entitiy's online help page. The returned String does not have a suffix
     * such as '.jsp'.
     * @return String
     */
    public String getOnlineHelpPagePath();

    /**
     * The online help documentation. The format is HTML without any style.
     * @return String
     */
    public String getOnlineHelpValue();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.populatorFullPath
     * @return String
     */
    public String getPopulatorFullPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.populatorName
     * @return String
     */
    public String getPopulatorName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.populatorType
     * @return String
     */
    public String getPopulatorType();

    /**
     * Represents a role a user may play within a system.  Provides access to things such as
     * services and
     * service operations.
     * @return Collection<Role>
     */
    public Collection<Role> getRoles();

    /**
     * Full path of this manageable search filter.
     * @return String
     */
    public String getSearchFilterFullPath();

    /**
     * Search filter class name.
     * @return String
     */
    public String getSearchFilterName();

    /**
     * The calculated serial version UID for this controller.
     * @return String
     */
    public String getSearchFilterSerialVersionUID();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.searchFormBeanClassName
     * @return String
     */
    public String getSearchFormBeanClassName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.searchFormBeanFullPath
     * @return String
     */
    public String getSearchFormBeanFullPath();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.searchFormBeanName
     * @return String
     */
    public String getSearchFormBeanName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.searchFormBeanType
     * @return String
     */
    public String getSearchFormBeanType();

    /**
     * Tthe available types of export in a single String instance.
     * @return String
     */
    public String getTableExportTypes();

    /**
     * The maximum number of rows to be displayed in the table at the same time. This is also known
     * as the page size. A value of zero or less will display all data in the same table (therefore
     * also on the same page).
     * @return int
     */
    public int getTableMaxRows();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.valueObjectClassName
     * @return String
     */
    public String getValueObjectClassName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.viewFullPath
     * @return String
     */
    public String getViewFullPath();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndManageableEntity.viewName
     * @return String
     */
    public String getViewName();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.viewTitleKey
     * @return String
     */
    public String getViewTitleKey();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.viewTitleValue
     * @return String
     */
    public String getViewTitleValue();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.needsFileUpload
     * @return boolean
     */
    public boolean isNeedsFileUpload();

    /**
     * Returns true if the user needs to modify the standard behavior and a Impl.java file will be
     * created in web/src/main/java.
     * @return boolean
     */
    public boolean isNeedsImplementation();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.needsUserInterface
     * @return boolean
     */
    public boolean isNeedsUserInterface();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndManageableEntity.preload
     * @return boolean
     */
    public boolean isPreload();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.isSearchable
     * @param element Object
     * @return boolean
     */
    public boolean isSearchable(Object element);

    /**
     * True if it is possible to export the table data to XML, CSV, PDF or Excel format.
     * @return boolean
     */
    public boolean isTableExportable();

    /**
     * True if it is possible to sort the columns of the table.
     * @return boolean
     */
    public boolean isTableSortable();

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.FrontEndManageableEntity.validationRequired
     * @return boolean
     */
    public boolean isValidationRequired();
}