// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;
import java.util.List;

/**
 * Represents a "front-end" action. An action is some action that is taken when a front-end even
 * occurs.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndAction
    extends FrontEndForward
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndActionMetaType();

    /**
     * Finds the parameter on this action having the given name, if no parameter is found, null is
     * returned instead.
     * @param name String
     * @return ParameterFacade
     */
    public ParameterFacade findParameter(String name);

    /**
     * The name of the action class that executes this action.
     * @return String
     */
    public String getActionClassName();

    /**
     * All action forwards for this foward. Each action forward either calls a view or another
     * use-case (which is essentially an action).
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getActionForwards();

    /**
     * All action states visited by this action.
     * @return List<FrontEndActionState>
     */
    public List<FrontEndActionState> getActionStates();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return Collection
     */
    public Collection getAllowedRoles();

    /**
     * The controller that will handle the execution of this front-end action. This controller is
     * set as the context of the activity graph (and therefore also of the use-case).
     * @return FrontEndController
     */
    public FrontEndController getController();

    /**
     * The name of the action on the controller that executions this action.
     * @return String
     */
    public String getControllerAction();

    /**
     * All the transitions coming out of decision points. These transitions should all carry guards.
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getDecisionTransitions();

    /**
     * The controller operations to which this action defers, the order is preserved.
     * @return List<FrontEndControllerOperation>
     */
    public List<FrontEndControllerOperation> getDeferredOperations();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndAction.displayCondition
     * @return String
     */
    public String getDisplayCondition();

    /**
     * A resource message key suited for the action''s documentation.
     * @return String
     */
    public String getDocumentationKey();

    /**
     * The resource messsage value suited for the action''s documentation.
     * @return String
     */
    public String getDocumentationValue();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndAction.enctype
     * @return String
     */
    public String getEnctype();

    /**
     * The name of the bean under which the form is stored.
     * @return String
     */
    public String getFormBeanName();

    /**
     * Form fields for this action. Form fields are those parameters that can be altered by the user
     * on a corresponding view at runtime.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getFormFields();

    /**
     * The name of the form implementation.
     * @return String
     */
    public String getFormImplementationName();

    /**
     * The key that stores the form in which information is passed from one action to another.
     * @return String
     */
    public String getFormKey();

    /**
     * The scope of the JSF form (request, session,application,etc).
     * @return String
     */
    public String getFormScope();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndAction.frontEndClasses
     * @return Collection<String>
     */
    public Collection<String> getFrontEndClasses();

    /**
     * The fully qualified name of the action class that execute this action.
     * @return String
     */
    public String getFullyQualifiedActionClassName();

    /**
     * The fully qualified path to the action class that execute this action.
     * @return String
     */
    public String getFullyQualifiedActionClassPath();

    /**
     * The fully qualified name of the form implementation.
     * @return String
     */
    public String getFullyQualifiedFormImplementationName();

    /**
     * The fully qualified path of the form implementation.
     * @return String
     */
    public String getFullyQualifiedFormImplementationPath();

    /**
     * All parameters that are of hidden input type.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getHiddenParameters();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndAction.icon
     * @return String
     */
    public String getIcon();

    /**
     * The StateVertex (FrontEndView or PseudostateFacade) on which this action can be triggered.
     * @return StateVertexFacade
     */
    public StateVertexFacade getInput();

    /**
     * The default resource message key for this action.
     * @return String
     */
    public String getMessageKey();

    /**
     * All parameters sent by this "front-end" action.
     * @return List<FrontEndParameter>
     */
    public List<FrontEndParameter> getParameters();

    /**
     * The path's root.
     * @return String
     */
    public String getPathRoot();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getRestPath();

    /**
     * The name of the column targetted by this action.
     * @return String
     */
    public String getTableLinkColumnName();

    /**
     * The name of the table link specified for this action.
     * @return String
     */
    public String getTableLinkName();

    /**
     * If the action is a table link then this property represents the table to which is being
     * linked.
     * @return FrontEndParameter
     */
    public FrontEndParameter getTableLinkParameter();

    /**
     * All views that can be possibly targetted by triggering this action.
     * @return List<FrontEndView>
     */
    public List<FrontEndView> getTargetViews();

    /**
     * All the transitions that make up this action, this directly maps onto the forwards.
     * @return List<FrontEndForward>
     */
    public List<FrontEndForward> getTransitions();

    /**
     * The name of the method to be executed when this action is triggered.
     * @return String
     */
    public String getTriggerMethodName();

    /**
     * The name of the trigger that triggers that action.
     * @return String
     */
    public String getTriggerName();

    /**
     * The path to the view fragment corresponding to this action
     * @return String
     */
    public String getViewFragmentPath();

    /**
     * Indicates if this action forwards to a dialog (use case runs in different conversation
     * scope). Only applied when the target is a final state pointing to another use case.
     * @return boolean
     */
    public boolean isDialog();

    /**
     * Whether or not the entire form should be reset (all action parameters on the form).
     * @return boolean
     */
    public boolean isFormReset();

    /**
     * Indicates if at least one parameter on the form requires being reset.
     * @return boolean
     */
    public boolean isFormResetRequired();

    /**
     * Indicates whether or not this action is represented by clicking on a hyperlink.
     * @return boolean
     */
    public boolean isHyperlink();

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.FrontEndAction.needsFileUpload
     * @return boolean
     */
    public boolean isNeedsFileUpload();

    /**
     * Indicates if this action forwards to a popup. Only applied when the target is a final state
     * pointing to another use case.
     * @return boolean
     */
    public boolean isPopup();

    /**
     * Indicates whether or not the values passed along with this action can be reset or not.
     * @return boolean
     */
    public boolean isResettable();

    /**
     * Indicates that this action works on all rows of the table from the table link relation.
     * @return boolean
     */
    public boolean isTableAction();

    /**
     * Indicates if a table link name has been specified and it properly targets a table
     * page-variable from the input page.
     * @return boolean
     */
    public boolean isTableLink();

    /**
     * Indicates if this action represents the beginning of the front-end use case or not.
     * @return boolean
     */
    public boolean isUseCaseStart();

    /**
     * Indicates whether or not at least one parameter on this action requires validation.
     * @return boolean
     */
    public boolean isValidationRequired();
}