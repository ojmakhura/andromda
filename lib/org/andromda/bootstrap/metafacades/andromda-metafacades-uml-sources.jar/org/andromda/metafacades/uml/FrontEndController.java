// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

import java.util.Collection;
import java.util.List;

/**
 * A front end controller is assigned as the context of a use-case. The controller provides the
 * "controlling" of the use case's activity.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndController
    extends ClassifierFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isFrontEndControllerMetaType();

    /**
     * All services the controller needs.
     * @return Collection
     */
    public Collection getAllServices();

    /**
     * Represents an operation modeled on a controller.
     * @return Collection<FrontEndControllerOperation>
     */
    public Collection<FrontEndControllerOperation> getAllowedOperations();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return Collection
     */
    public Collection getAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getBeanName();

    /**
     * The calculated serial version UID for this controller.
     * @return String
     */
    public String getControllerSerialVersionUID();

    /**
     * All actions that defer to at least one operation of this controller.
     * @return List<FrontEndAction>
     */
    public List<FrontEndAction> getDeferringActions();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getFilename();

    /**
     * The fully qualified implementation name of this controller.
     * @return String
     */
    public String getFullyQualifiedImplementationName();

    /**
     * The fully qualified path to the controller implemention file.
     * @return String
     */
    public String getFullyQualifiedImplementationPath();

    /**
     * The implementation name of this controller.
     * @return String
     */
    public String getImplementationName();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getRestPath();

    /**
     * Returns all back-end services referenced by this controller.
     * @return List<DependencyFacade>
     */
    public List<DependencyFacade> getServiceReferences();

    /**
     * A representation of the model object 'Directed Relationship'.Represents a relationship
     * between a
     * collection of source model elements and a collection of target model elements, a
     * dependency/reference.
     * @return Collection<DependencyFacade>
     */
    public Collection<DependencyFacade> getServicesPackagesReferences();

    /**
     * A representation of the model object 'Directed Relationship'.Represents a relationship
     * between a
     * collection of source model elements and a collection of target model elements, a
     * dependency/reference.
     * @return Collection<DependencyFacade>
     */
    public Collection<DependencyFacade> getSessionObjectReferences();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return String
     */
    public String getTargetUrl();

    /**
     * Returns the use-case "controlled" by this controller.
     * @return FrontEndUseCase
     */
    public FrontEndUseCase getUseCase();
}