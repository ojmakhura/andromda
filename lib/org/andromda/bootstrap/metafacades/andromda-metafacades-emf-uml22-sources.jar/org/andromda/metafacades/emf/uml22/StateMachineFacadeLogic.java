// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FinalStateFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.PseudostateFacade;
import org.andromda.metafacades.uml.StateFacade;
import org.andromda.metafacades.uml.StateMachineFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.StateMachine;

/**
 * State machines can be used to express the behavior of part of a system. Behavior is modeled as a
 * traversal of a graph of state nodes interconnected by one or more joined transition arcs that are
 * triggered by the dispatching of series of (event) occurrences. During this traversal, the state
 * machine executes a series of activities associated with various elements of the state machine.
 * MetafacadeLogic for StateMachineFacade
 *
 * @see StateMachineFacade
 */
public abstract class StateMachineFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements StateMachineFacade
{
    /**
     * The underlying UML object
     * @see StateMachine
     */
    protected StateMachine metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected StateMachineFacadeLogic(StateMachine metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(StateMachineFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to StateMachineFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateMachineFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see StateMachineFacade
     */
    public boolean isStateMachineFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<StateFacade> __getStates1r;
    private boolean __getStates1rSet = false;

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<StateFacade>)handleGetStates()
     */
    public final Collection<StateFacade> getStates()
    {
        Collection<StateFacade> getStates1r = this.__getStates1r;
        if (!this.__getStates1rSet)
        {
            // stateMachineFacade has no pre constraints
             Collection result = handleGetStates();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getStates1r = (Collection<StateFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getStates Collection<StateFacade> " + result + ": " + shieldedResult);
            }
            // stateMachineFacade has no post constraints
            this.__getStates1r = getStates1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getStates1rSet = true;
            }
        }
        return getStates1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetStates();

    private PseudostateFacade __getInitialState2r;
    private boolean __getInitialState2rSet = false;

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (PseudostateFacade)handleGetInitialState()
     */
    public final PseudostateFacade getInitialState()
    {
        PseudostateFacade getInitialState2r = this.__getInitialState2r;
        if (!this.__getInitialState2rSet)
        {
            // stateMachineFacade has no pre constraints
            Object result = handleGetInitialState();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInitialState2r = (PseudostateFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getInitialState PseudostateFacade " + result + ": " + shieldedResult);
            }
            // stateMachineFacade has no post constraints
            this.__getInitialState2r = getInitialState2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialState2rSet = true;
            }
        }
        return getInitialState2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInitialState();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<PseudostateFacade>)handleGetInitialStates()
     */
    public final Collection<PseudostateFacade> getInitialStates()
    {
        Collection<PseudostateFacade> getInitialStates3r = null;
        // stateMachineFacade has no pre constraints
         Collection result = handleGetInitialStates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getInitialStates3r = (Collection<PseudostateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getInitialStates Collection<PseudostateFacade> " + result + ": " + shieldedResult);
        }
        // stateMachineFacade has no post constraints
        return getInitialStates3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetInitialStates();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<PseudostateFacade>)handleGetPseudostates()
     */
    public final Collection<PseudostateFacade> getPseudostates()
    {
        Collection<PseudostateFacade> getPseudostates4r = null;
        // stateMachineFacade has no pre constraints
         Collection result = handleGetPseudostates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getPseudostates4r = (Collection<PseudostateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getPseudostates Collection<PseudostateFacade> " + result + ": " + shieldedResult);
        }
        // stateMachineFacade has no post constraints
        return getPseudostates4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetPseudostates();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<TransitionFacade>)handleGetTransitions()
     */
    public final Collection<TransitionFacade> getTransitions()
    {
        Collection<TransitionFacade> getTransitions5r = null;
        // stateMachineFacade has no pre constraints
         Collection result = handleGetTransitions();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTransitions5r = (Collection<TransitionFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getTransitions Collection<TransitionFacade> " + result + ": " + shieldedResult);
        }
        // stateMachineFacade has no post constraints
        return getTransitions5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTransitions();

    private TransitionFacade __getInitialTransition6r;
    private boolean __getInitialTransition6rSet = false;

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (TransitionFacade)handleGetInitialTransition()
     */
    public final TransitionFacade getInitialTransition()
    {
        TransitionFacade getInitialTransition6r = this.__getInitialTransition6r;
        if (!this.__getInitialTransition6rSet)
        {
            // stateMachineFacade has no pre constraints
            Object result = handleGetInitialTransition();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInitialTransition6r = (TransitionFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getInitialTransition TransitionFacade " + result + ": " + shieldedResult);
            }
            // stateMachineFacade has no post constraints
            this.__getInitialTransition6r = getInitialTransition6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialTransition6rSet = true;
            }
        }
        return getInitialTransition6r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInitialTransition();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<FinalStateFacade>)handleGetFinalStates()
     */
    public final Collection<FinalStateFacade> getFinalStates()
    {
        Collection<FinalStateFacade> getFinalStates7r = null;
        // stateMachineFacade has no pre constraints
         Collection result = handleGetFinalStates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getFinalStates7r = (Collection<FinalStateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getFinalStates Collection<FinalStateFacade> " + result + ": " + shieldedResult);
        }
        // stateMachineFacade has no post constraints
        return getFinalStates7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetFinalStates();

    /**
     * If this model element is the context of an activity graph, this represents that activity
     * graph.
     * @return (ModelElementFacade)handleGetContextElement()
     */
    public final ModelElementFacade getContextElement()
    {
        ModelElementFacade getContextElement8r = null;
        // stateMachineContext has no pre constraints
        Object result = handleGetContextElement();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getContextElement8r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateMachineFacadeLogic.logger.warn("incorrect metafacade cast for StateMachineFacadeLogic.getContextElement ModelElementFacade " + result + ": " + shieldedResult);
        }
        // stateMachineContext has no post constraints
        return getContextElement8r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetContextElement();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}