// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.RedefinableTemplateSignatureFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.RedefinableTemplateSignature;

/**
 * A signature containing the template parameters for the templated element (Class, operation,
 * property, etc). A template signature bundles the set of formal template parameters for a
 * templated element.
 * MetafacadeLogic for RedefinableTemplateSignatureFacade
 *
 * @see RedefinableTemplateSignatureFacade
 */
public abstract class RedefinableTemplateSignatureFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements RedefinableTemplateSignatureFacade
{
    /**
     * The underlying UML object
     * @see RedefinableTemplateSignature
     */
    protected RedefinableTemplateSignature metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected RedefinableTemplateSignatureFacadeLogic(RedefinableTemplateSignature metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(RedefinableTemplateSignatureFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to RedefinableTemplateSignatureFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.RedefinableTemplateSignatureFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see RedefinableTemplateSignatureFacade
     */
    public boolean isRedefinableTemplateSignatureFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A signature containing the template parameters for the templated element (Class, operation,
     * property, etc). A template signature bundles the set of formal template parameters for a
     * templated
     * element.
     * @return (ClassifierFacade)handleGetClassifier()
     */
    public final ClassifierFacade getClassifier()
    {
        ClassifierFacade getClassifier1r = null;
        // redefinableTemplateSignatureFacade has no pre constraints
        Object result = handleGetClassifier();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getClassifier1r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            RedefinableTemplateSignatureFacadeLogic.logger.warn("incorrect metafacade cast for RedefinableTemplateSignatureFacadeLogic.getClassifier ClassifierFacade " + result + ": " + shieldedResult);
        }
        // redefinableTemplateSignatureFacade has no post constraints
        return getClassifier1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetClassifier();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}