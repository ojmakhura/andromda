// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AssociationEndFacade;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndView;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Parameter;

/**
 * A front-end parameter is a parameter passed between front-end action states.
 * MetafacadeLogic for FrontEndParameter
 *
 * @see FrontEndParameter
 */
public abstract class FrontEndParameterLogic
    extends ParameterFacadeLogicImpl
    implements FrontEndParameter
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndParameterLogic(Object metaObjectIn, String context)
    {
        super((Parameter)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndParameterLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndParameter if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndParameter";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndParameter
     */
    public boolean isFrontEndParameterMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndParameter#isControllerOperationArgument()
    * @return boolean
    */
    protected abstract boolean handleIsControllerOperationArgument();

    /**
     * Indicates whether or not this parameter is an argument of a controller operation.
     * @return (boolean)handleIsControllerOperationArgument()
     */
    public final boolean isControllerOperationArgument()
    {
        boolean controllerOperationArgument1a = false;
        // controllerOperationArgument has no pre constraints
        controllerOperationArgument1a = handleIsControllerOperationArgument();
        // controllerOperationArgument has no post constraints
        return controllerOperationArgument1a;
    }

   /**
    * @see FrontEndParameter#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * Indicates if this parameter is contained in a "front-end" use case.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase2a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase2a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase2a;
    }

   /**
    * @see FrontEndParameter#isActionParameter()
    * @return boolean
    */
    protected abstract boolean handleIsActionParameter();

    /**
     * Indicates whether or not this is an action parameter or not.
     * @return (boolean)handleIsActionParameter()
     */
    public final boolean isActionParameter()
    {
        boolean actionParameter3a = false;
        // actionParameter has no pre constraints
        actionParameter3a = handleIsActionParameter();
        // actionParameter has no post constraints
        return actionParameter3a;
    }

   /**
    * @see FrontEndParameter#isTable()
    * @return boolean
    */
    protected abstract boolean handleIsTable();

    /**
     * Indicates whether or not this parameter represents a table.
     * @return (boolean)handleIsTable()
     */
    public final boolean isTable()
    {
        boolean table4a = false;
        // table has no pre constraints
        table4a = handleIsTable();
        // table has no post constraints
        return table4a;
    }

   /**
    * @see FrontEndParameter#getTableColumnNames()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableColumnNames();

    /**
     * All the columns for this parameter if it represents a table variable. If a column is linked
     * by an event (action) a FrontEndParameter instance is included in the return value, otherwise
     * a plain String representing the column name.
     * @return (Set<String>)handleGetTableColumnNames()
     */
    public final Set<String> getTableColumnNames()
    {
        Set<String> tableColumnNames5a = null;
        // tableColumnNames has no pre constraints
        tableColumnNames5a = handleGetTableColumnNames();
        // tableColumnNames has no post constraints
        return tableColumnNames5a;
    }

   /**
    * @see FrontEndParameter#getTableColumns()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableColumns();

    /**
     * A list of all attributes which make up the table columns of this table (this only contains
     * attributes when the table is represented by an array).
     * @return (Set<String>)handleGetTableColumns()
     */
    public final Set<String> getTableColumns()
    {
        Set<String> tableColumns6a = null;
        // tableColumns has no pre constraints
        tableColumns6a = handleGetTableColumns();
        // tableColumns has no post constraints
        return tableColumns6a;
    }

   /**
    * @see FrontEndParameter#getTableAttributeNames()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableAttributeNames();

    /**
     * A collection of all possible attribute names of a table (this will only work when your table
     * is modeled as an array..not a collection).
     * @return (Set<String>)handleGetTableAttributeNames()
     */
    public final Set<String> getTableAttributeNames()
    {
        Set<String> tableAttributeNames7a = null;
        // tableAttributeNames has no pre constraints
        tableAttributeNames7a = handleGetTableAttributeNames();
        // tableAttributeNames has no post constraints
        return tableAttributeNames7a;
    }

   /**
    * @see FrontEndParameter#getDateFormatter()
    * @return String
    */
    protected abstract String handleGetDateFormatter();

    /**
     * The name of the date formatter for this parameter (if this parameter represents a date).
     * @return (String)handleGetDateFormatter()
     */
    public final String getDateFormatter()
    {
        String dateFormatter8a = null;
        // dateFormatter has no pre constraints
        dateFormatter8a = handleGetDateFormatter();
        // dateFormatter has no post constraints
        return dateFormatter8a;
    }

   /**
    * @see FrontEndParameter#isStrictDateFormat()
    * @return boolean
    */
    protected abstract boolean handleIsStrictDateFormat();

    /**
     * Indicates where or not the date format is to be strictly respected. Otherwise the date
     * formatter used for the representation of this date is to be set to lenient.
     * @return (boolean)handleIsStrictDateFormat()
     */
    public final boolean isStrictDateFormat()
    {
        boolean strictDateFormat9a = false;
        // strictDateFormat has no pre constraints
        strictDateFormat9a = handleIsStrictDateFormat();
        // strictDateFormat has no post constraints
        return strictDateFormat9a;
    }

   /**
    * @see FrontEndParameter#getFormat()
    * @return String
    */
    protected abstract String handleGetFormat();

    /**
     * If this parameter represents a date or time this method will return the format in which it
     * must be represented. In the event this format has not been specified by the any tagged value
     * the default will be used.
     * @return (String)handleGetFormat()
     */
    public final String getFormat()
    {
        String format10a = null;
        // format has no pre constraints
        format10a = handleGetFormat();
        // format has no post constraints
        return format10a;
    }

   /**
    * @see FrontEndParameter#getTimeFormatter()
    * @return String
    */
    protected abstract String handleGetTimeFormatter();

    /**
     * The name of the time formatter (if this parameter represents a time).
     * @return (String)handleGetTimeFormatter()
     */
    public final String getTimeFormatter()
    {
        String timeFormatter11a = null;
        // timeFormatter has no pre constraints
        timeFormatter11a = handleGetTimeFormatter();
        // timeFormatter has no post constraints
        return timeFormatter11a;
    }

   /**
    * @see FrontEndParameter#isInputCheckbox()
    * @return boolean
    */
    protected abstract boolean handleIsInputCheckbox();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputCheckbox()
     */
    public final boolean isInputCheckbox()
    {
        boolean inputCheckbox12a = false;
        // inputCheckbox has no pre constraints
        inputCheckbox12a = handleIsInputCheckbox();
        // inputCheckbox has no post constraints
        return inputCheckbox12a;
    }

   /**
    * @see FrontEndParameter#isInputTextarea()
    * @return boolean
    */
    protected abstract boolean handleIsInputTextarea();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return (boolean)handleIsInputTextarea()
     */
    public final boolean isInputTextarea()
    {
        boolean inputTextarea13a = false;
        // inputTextarea has no pre constraints
        inputTextarea13a = handleIsInputTextarea();
        // inputTextarea has no post constraints
        return inputTextarea13a;
    }

   /**
    * @see FrontEndParameter#isInputSelect()
    * @return boolean
    */
    protected abstract boolean handleIsInputSelect();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputSelect()
     */
    public final boolean isInputSelect()
    {
        boolean inputSelect14a = false;
        // inputSelect has no pre constraints
        inputSelect14a = handleIsInputSelect();
        // inputSelect has no post constraints
        return inputSelect14a;
    }

   /**
    * @see FrontEndParameter#isInputSecret()
    * @return boolean
    */
    protected abstract boolean handleIsInputSecret();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputSecret()
     */
    public final boolean isInputSecret()
    {
        boolean inputSecret15a = false;
        // inputSecret has no pre constraints
        inputSecret15a = handleIsInputSecret();
        // inputSecret has no post constraints
        return inputSecret15a;
    }

   /**
    * @see FrontEndParameter#isInputHidden()
    * @return boolean
    */
    protected abstract boolean handleIsInputHidden();

    /**
     * Indicates whether or not this parameter represents a hidden input widget.
     * @return (boolean)handleIsInputHidden()
     */
    public final boolean isInputHidden()
    {
        boolean inputHidden16a = false;
        // inputHidden has no pre constraints
        inputHidden16a = handleIsInputHidden();
        // inputHidden has no post constraints
        return inputHidden16a;
    }

   /**
    * @see FrontEndParameter#isInputFile()
    * @return boolean
    */
    protected abstract boolean handleIsInputFile();

    /**
     * Indicates whether or not this is a file input type.
     * @return (boolean)handleIsInputFile()
     */
    public final boolean isInputFile()
    {
        boolean inputFile17a = false;
        // inputFile has no pre constraints
        inputFile17a = handleIsInputFile();
        // inputFile has no post constraints
        return inputFile17a;
    }

   /**
    * @see FrontEndParameter#isPlaintext()
    * @return boolean
    */
    protected abstract boolean handleIsPlaintext();

    /**
     * Indicates whether or not this field should be rendered as plain text (not as a widget).
     * @return (boolean)handleIsPlaintext()
     */
    public final boolean isPlaintext()
    {
        boolean plaintext18a = false;
        // plaintext has no pre constraints
        plaintext18a = handleIsPlaintext();
        // plaintext has no post constraints
        return plaintext18a;
    }

   /**
    * @see FrontEndParameter#isInputRadio()
    * @return boolean
    */
    protected abstract boolean handleIsInputRadio();

    /**
     * Indicates whether or not this parameter should be rendered as an input radio widget.
     * @return (boolean)handleIsInputRadio()
     */
    public final boolean isInputRadio()
    {
        boolean inputRadio19a = false;
        // inputRadio has no pre constraints
        inputRadio19a = handleIsInputRadio();
        // inputRadio has no post constraints
        return inputRadio19a;
    }

   /**
    * @see FrontEndParameter#isInputText()
    * @return boolean
    */
    protected abstract boolean handleIsInputText();

    /**
     * Indicates whether or not this parameter should be rendered as a text input widget.
     * @return (boolean)handleIsInputText()
     */
    public final boolean isInputText()
    {
        boolean inputText20a = false;
        // inputText has no pre constraints
        inputText20a = handleIsInputText();
        // inputText has no post constraints
        return inputText20a;
    }

   /**
    * @see FrontEndParameter#getBackingListName()
    * @return String
    */
    protected abstract String handleGetBackingListName();

    /**
     * The backing list name for this parameter. This is useful if you want to be able to select the
     * parameter value from a list (i.e. a drop-down select input type).
     * @return (String)handleGetBackingListName()
     */
    public final String getBackingListName()
    {
        String backingListName21a = null;
        // backingListName has no pre constraints
        backingListName21a = handleGetBackingListName();
        // backingListName has no post constraints
        return backingListName21a;
    }

   /**
    * @see FrontEndParameter#getLabelListName()
    * @return String
    */
    protected abstract String handleGetLabelListName();

    /**
     * The name of the label list for this parameter. The label list name is the name of the list
     * storing the labels for the possible values of this parameter (typically used for the labels
     * of a drop-down select lists).
     * @return (String)handleGetLabelListName()
     */
    public final String getLabelListName()
    {
        String labelListName22a = null;
        // labelListName has no pre constraints
        labelListName22a = handleGetLabelListName();
        // labelListName has no post constraints
        return labelListName22a;
    }

   /**
    * @see FrontEndParameter#getValueListName()
    * @return String
    */
    protected abstract String handleGetValueListName();

    /**
     * Stores the name of the value list for this parameter; this list stores the possible values
     * that this parameter may be (typically used for the values of a drop-down select list).
     * @return (String)handleGetValueListName()
     */
    public final String getValueListName()
    {
        String valueListName23a = null;
        // valueListName has no pre constraints
        valueListName23a = handleGetValueListName();
        // valueListName has no post constraints
        return valueListName23a;
    }

   /**
    * @see FrontEndParameter#isSelectable()
    * @return boolean
    */
    protected abstract boolean handleIsSelectable();

    /**
     * Indicates whether or not this parameter is selectable or not (that is: it can be selected
     * from a list of values).
     * @return (boolean)handleIsSelectable()
     */
    public final boolean isSelectable()
    {
        boolean selectable24a = false;
        // selectable has no pre constraints
        selectable24a = handleIsSelectable();
        // selectable has no post constraints
        return selectable24a;
    }

   /**
    * @see FrontEndParameter#getDummyValue()
    * @return String
    */
    protected abstract String handleGetDummyValue();

    /**
     * The dummy value for this parameter. The dummy value is used for setting the dummy information
     * when dummyData is enabled.
     * @return (String)handleGetDummyValue()
     */
    public final String getDummyValue()
    {
        String dummyValue25a = null;
        // dummyValue has no pre constraints
        dummyValue25a = handleGetDummyValue();
        // dummyValue has no post constraints
        return dummyValue25a;
    }

   /**
    * @see FrontEndParameter#getValueListDummyValue()
    * @return String
    */
    protected abstract String handleGetValueListDummyValue();

    /**
     * The dummy value for a value list.
     * @return (String)handleGetValueListDummyValue()
     */
    public final String getValueListDummyValue()
    {
        String valueListDummyValue26a = null;
        // valueListDummyValue has no pre constraints
        valueListDummyValue26a = handleGetValueListDummyValue();
        // valueListDummyValue has no post constraints
        return valueListDummyValue26a;
    }

   /**
    * @see FrontEndParameter#getTableSortColumnProperty()
    * @return String
    */
    protected abstract String handleGetTableSortColumnProperty();

    /**
     * The name of the property storing the column to sort by if this parameter represents a table.
     * @return (String)handleGetTableSortColumnProperty()
     */
    public final String getTableSortColumnProperty()
    {
        String tableSortColumnProperty27a = null;
        // tableSortColumnProperty has no pre constraints
        tableSortColumnProperty27a = handleGetTableSortColumnProperty();
        // tableSortColumnProperty has no post constraints
        return tableSortColumnProperty27a;
    }

   /**
    * @see FrontEndParameter#getTableSortAscendingProperty()
    * @return String
    */
    protected abstract String handleGetTableSortAscendingProperty();

    /**
     * The name of the property that Indicates whether or not the table should be sorted ascending
     * (if this parameter represents a table).
     * @return (String)handleGetTableSortAscendingProperty()
     */
    public final String getTableSortAscendingProperty()
    {
        String tableSortAscendingProperty28a = null;
        // tableSortAscendingProperty has no pre constraints
        tableSortAscendingProperty28a = handleGetTableSortAscendingProperty();
        // tableSortAscendingProperty has no post constraints
        return tableSortAscendingProperty28a;
    }

   /**
    * @see FrontEndParameter#getFormAttributeSetProperty()
    * @return String
    */
    protected abstract String handleGetFormAttributeSetProperty();

    /**
     * The name of the property used for indicating whether or not a form attribute has been set at
     * least once.
     * @return (String)handleGetFormAttributeSetProperty()
     */
    public final String getFormAttributeSetProperty()
    {
        String formAttributeSetProperty29a = null;
        // formAttributeSetProperty has no pre constraints
        formAttributeSetProperty29a = handleGetFormAttributeSetProperty();
        // formAttributeSetProperty has no post constraints
        return formAttributeSetProperty29a;
    }

   /**
    * @see FrontEndParameter#isReadOnly()
    * @return boolean
    */
    protected abstract boolean handleIsReadOnly();

    /**
     * Indicates if this parameter can only be read and not modified.
     * @return (boolean)handleIsReadOnly()
     */
    public final boolean isReadOnly()
    {
        boolean readOnly30a = false;
        // readOnly has no pre constraints
        readOnly30a = handleIsReadOnly();
        // readOnly has no post constraints
        return readOnly30a;
    }

   /**
    * @see FrontEndParameter#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not this parameter requires some kind of validation (the collection of
     * validator types is not empty).
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired31a = false;
        // validationRequired has no pre constraints
        validationRequired31a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired31a;
    }

   /**
    * @see FrontEndParameter#getValidatorTypes()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorTypes();

    /**
     * All the validator types for this parameter.
     * @return (Collection)handleGetValidatorTypes()
     */
    public final Collection getValidatorTypes()
    {
        Collection validatorTypes32a = null;
        // validatorTypes has no pre constraints
        validatorTypes32a = handleGetValidatorTypes();
        // validatorTypes has no post constraints
        return validatorTypes32a;
    }

   /**
    * @see FrontEndParameter#getValidWhen()
    * @return String
    */
    protected abstract String handleGetValidWhen();

    /**
     * The validator's 'validwhen' value, this is useful when the validation of a parameter depends
     * on the validation of others. See the apache commons-validator documentation for more
     * information.
     * @return (String)handleGetValidWhen()
     */
    public final String getValidWhen()
    {
        String validWhen33a = null;
        // validWhen has no pre constraints
        validWhen33a = handleGetValidWhen();
        // validWhen has no post constraints
        return validWhen33a;
    }

   /**
    * @see FrontEndParameter#isInputMultibox()
    * @return boolean
    */
    protected abstract boolean handleIsInputMultibox();

    /**
     * Indicates whether or not this type represents an input multibox.
     * @return (boolean)handleIsInputMultibox()
     */
    public final boolean isInputMultibox()
    {
        boolean inputMultibox34a = false;
        // inputMultibox has no pre constraints
        inputMultibox34a = handleIsInputMultibox();
        // inputMultibox has no post constraints
        return inputMultibox34a;
    }

   /**
    * @see FrontEndParameter#isComplex()
    * @return boolean
    */
    protected abstract boolean handleIsComplex();

    /**
     * Indicates if this parameter is 'complex', that is: its of a complex type (has at least one
     * attribute or association).
     * @return (boolean)handleIsComplex()
     */
    public final boolean isComplex()
    {
        boolean complex35a = false;
        // complex has no pre constraints
        complex35a = handleIsComplex();
        // complex has no post constraints
        return complex35a;
    }

   /**
    * @see FrontEndParameter#getAttributes()
    * @return Collection
    */
    protected abstract Collection handleGetAttributes();

    /**
     * All attributes belonging to this parameter's type.
     * @return (Collection)handleGetAttributes()
     */
    public final Collection getAttributes()
    {
        Collection attributes36a = null;
        // attributes has no pre constraints
        attributes36a = handleGetAttributes();
        // attributes has no post constraints
        return attributes36a;
    }

   /**
    * @see FrontEndParameter#getNavigableAssociationEnds()
    * @return Collection<AssociationEndFacade>
    */
    protected abstract Collection<AssociationEndFacade> handleGetNavigableAssociationEnds();

    /**
     * All navigation association ends belonging to this parameter's type.
     * @return (Collection<AssociationEndFacade>)handleGetNavigableAssociationEnds()
     */
    public final Collection<AssociationEndFacade> getNavigableAssociationEnds()
    {
        Collection<AssociationEndFacade> navigableAssociationEnds37a = null;
        // navigableAssociationEnds has no pre constraints
        navigableAssociationEnds37a = handleGetNavigableAssociationEnds();
        // navigableAssociationEnds has no post constraints
        return navigableAssociationEnds37a;
    }

   /**
    * @see FrontEndParameter#getBackingValueName()
    * @return String
    */
    protected abstract String handleGetBackingValueName();

    /**
     * The name of the backing value for this parameter (only used with collections and arrays that
     * are input type table).
     * @return (String)handleGetBackingValueName()
     */
    public final String getBackingValueName()
    {
        String backingValueName38a = null;
        // backingValueName has no pre constraints
        backingValueName38a = handleGetBackingValueName();
        // backingValueName has no post constraints
        return backingValueName38a;
    }

   /**
    * @see FrontEndParameter#isInputTable()
    * @return boolean
    */
    protected abstract boolean handleIsInputTable();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputTable()
     */
    public final boolean isInputTable()
    {
        boolean inputTable39a = false;
        // inputTable has no pre constraints
        inputTable39a = handleIsInputTable();
        // inputTable has no post constraints
        return inputTable39a;
    }

   /**
    * @see FrontEndParameter#isBackingValueRequired()
    * @return boolean
    */
    protected abstract boolean handleIsBackingValueRequired();

    /**
     * Indicates if a backing value is required for this parameter.
     * @return (boolean)handleIsBackingValueRequired()
     */
    public final boolean isBackingValueRequired()
    {
        boolean backingValueRequired40a = false;
        // backingValueRequired has no pre constraints
        backingValueRequired40a = handleIsBackingValueRequired();
        // backingValueRequired has no post constraints
        return backingValueRequired40a;
    }

   /**
    * @see FrontEndParameter#getInputTableIdentifierColumns()
    * @return String
    */
    protected abstract String handleGetInputTableIdentifierColumns();

    /**
     * A comma separated list of the input table identifier columns (these are the columns that
     * uniquely define a row in an input table).
     * @return (String)handleGetInputTableIdentifierColumns()
     */
    public final String getInputTableIdentifierColumns()
    {
        String inputTableIdentifierColumns41a = null;
        // inputTableIdentifierColumns has no pre constraints
        inputTableIdentifierColumns41a = handleGetInputTableIdentifierColumns();
        // inputTableIdentifierColumns has no post constraints
        return inputTableIdentifierColumns41a;
    }

   /**
    * @see FrontEndParameter#isPageableTable()
    * @return boolean
    */
    protected abstract boolean handleIsPageableTable();

    /**
     * Whether or not the parameter is a "pageable table", that is a table that supports paging
     * (i.e. DB paging).
     * @return (boolean)handleIsPageableTable()
     */
    public final boolean isPageableTable()
    {
        boolean pageableTable42a = false;
        // pageableTable has no pre constraints
        pageableTable42a = handleIsPageableTable();
        // pageableTable has no post constraints
        return pageableTable42a;
    }

   /**
    * @see FrontEndParameter#getMaxLength()
    * @return String
    */
    protected abstract String handleGetMaxLength();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMaxLength()
     */
    public final String getMaxLength()
    {
        String maxLength43a = null;
        // maxLength has no pre constraints
        maxLength43a = handleGetMaxLength();
        // maxLength has no post constraints
        return maxLength43a;
    }

   /**
    * @see FrontEndParameter#getAnnotations()
    * @return Collection
    */
    protected abstract Collection handleGetAnnotations();

    /**
     * All the annotations for this parameter.
     * @return (Collection)handleGetAnnotations()
     */
    public final Collection getAnnotations()
    {
        Collection annotations44a = null;
        // annotations has no pre constraints
        annotations44a = handleGetAnnotations();
        // annotations has no post constraints
        return annotations44a;
    }

   /**
    * @see FrontEndParameter#getTableHyperlinkActions()
    * @return List<FrontEndAction>
    */
    protected abstract List<FrontEndAction> handleGetTableHyperlinkActions();

    /**
     * Actions that are working with this table and are to be represented as hyperlinks. This only
     * makes sense on a parameter that represents a table page variable.
     * @return (List<FrontEndAction>)handleGetTableHyperlinkActions()
     */
    public final List<FrontEndAction> getTableHyperlinkActions()
    {
        List<FrontEndAction> tableHyperlinkActions45a = null;
        // tableHyperlinkActions has no pre constraints
        tableHyperlinkActions45a = handleGetTableHyperlinkActions();
        // tableHyperlinkActions has no post constraints
        return tableHyperlinkActions45a;
    }

   /**
    * @see FrontEndParameter#getTableFormActions()
    * @return List<FrontEndAction>
    */
    protected abstract List<FrontEndAction> handleGetTableFormActions();

    /**
     * Actions used when submitting forms for this table. Table actions that are hyperlinks are not
     * included. It only makes sense to call this property on parameters that represent a table
     * page-variable.
     * @return (List<FrontEndAction>)handleGetTableFormActions()
     */
    public final List<FrontEndAction> getTableFormActions()
    {
        List<FrontEndAction> tableFormActions46a = null;
        // tableFormActions has no pre constraints
        tableFormActions46a = handleGetTableFormActions();
        // tableFormActions has no post constraints
        return tableFormActions46a;
    }

   /**
    * @see FrontEndParameter#getTableActions()
    * @return List<FrontEndAction>
    */
    protected abstract List<FrontEndAction> handleGetTableActions();

    /**
     * Actions used when submitting forms for this table. It only makes sense to call this property
     * on parameters that represent a table page-variable.
     * @return (List<FrontEndAction>)handleGetTableActions()
     */
    public final List<FrontEndAction> getTableActions()
    {
        List<FrontEndAction> tableActions47a = null;
        // tableActions has no pre constraints
        tableActions47a = handleGetTableActions();
        // tableActions has no post constraints
        return tableActions47a;
    }

   /**
    * @see FrontEndParameter#isEqualValidator()
    * @return boolean
    */
    protected abstract boolean handleIsEqualValidator();

    /**
     * Indicates whether or not this parameter uses the equal validator.
     * @return (boolean)handleIsEqualValidator()
     */
    public final boolean isEqualValidator()
    {
        boolean equalValidator48a = false;
        // equalValidator has no pre constraints
        equalValidator48a = handleIsEqualValidator();
        // equalValidator has no post constraints
        return equalValidator48a;
    }

   /**
    * @see FrontEndParameter#isReset()
    * @return boolean
    */
    protected abstract boolean handleIsReset();

    /**
     * Indicates if this parameter's value should be reset or not after an action has been performed
     * with this parameter.
     * @return (boolean)handleIsReset()
     */
    public final boolean isReset()
    {
        boolean reset49a = false;
        // reset has no pre constraints
        reset49a = handleIsReset();
        // reset has no post constraints
        return reset49a;
    }

   /**
    * @see FrontEndParameter#getValidatorVars()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorVars();

    /**
     * The validator variables.
     * @return (Collection)handleGetValidatorVars()
     */
    public final Collection getValidatorVars()
    {
        Collection validatorVars50a = null;
        // validatorVars has no pre constraints
        validatorVars50a = handleGetValidatorVars();
        // validatorVars has no post constraints
        return validatorVars50a;
    }

   /**
    * @see FrontEndParameter#isInputButton()
    * @return boolean
    */
    protected abstract boolean handleIsInputButton();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputButton()
     */
    public final boolean isInputButton()
    {
        boolean inputButton51a = false;
        // inputButton has no pre constraints
        inputButton51a = handleIsInputButton();
        // inputButton has no post constraints
        return inputButton51a;
    }

   /**
    * @see FrontEndParameter#isInputColor()
    * @return boolean
    */
    protected abstract boolean handleIsInputColor();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputColor()
     */
    public final boolean isInputColor()
    {
        boolean inputColor52a = false;
        // inputColor has no pre constraints
        inputColor52a = handleIsInputColor();
        // inputColor has no post constraints
        return inputColor52a;
    }

   /**
    * @see FrontEndParameter#isInputDate()
    * @return boolean
    */
    protected abstract boolean handleIsInputDate();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputDate()
     */
    public final boolean isInputDate()
    {
        boolean inputDate53a = false;
        // inputDate has no pre constraints
        inputDate53a = handleIsInputDate();
        // inputDate has no post constraints
        return inputDate53a;
    }

   /**
    * @see FrontEndParameter#isInputDatetimeLocal()
    * @return boolean
    */
    protected abstract boolean handleIsInputDatetimeLocal();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return (boolean)handleIsInputDatetimeLocal()
     */
    public final boolean isInputDatetimeLocal()
    {
        boolean inputDatetimeLocal54a = false;
        // inputDatetimeLocal has no pre constraints
        inputDatetimeLocal54a = handleIsInputDatetimeLocal();
        // inputDatetimeLocal has no post constraints
        return inputDatetimeLocal54a;
    }

   /**
    * @see FrontEndParameter#isInputEmail()
    * @return boolean
    */
    protected abstract boolean handleIsInputEmail();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputEmail()
     */
    public final boolean isInputEmail()
    {
        boolean inputEmail55a = false;
        // inputEmail has no pre constraints
        inputEmail55a = handleIsInputEmail();
        // inputEmail has no post constraints
        return inputEmail55a;
    }

   /**
    * @see FrontEndParameter#isInputImage()
    * @return boolean
    */
    protected abstract boolean handleIsInputImage();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputImage()
     */
    public final boolean isInputImage()
    {
        boolean inputImage56a = false;
        // inputImage has no pre constraints
        inputImage56a = handleIsInputImage();
        // inputImage has no post constraints
        return inputImage56a;
    }

   /**
    * @see FrontEndParameter#isInputMonth()
    * @return boolean
    */
    protected abstract boolean handleIsInputMonth();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputMonth()
     */
    public final boolean isInputMonth()
    {
        boolean inputMonth57a = false;
        // inputMonth has no pre constraints
        inputMonth57a = handleIsInputMonth();
        // inputMonth has no post constraints
        return inputMonth57a;
    }

   /**
    * @see FrontEndParameter#isInputNumber()
    * @return boolean
    */
    protected abstract boolean handleIsInputNumber();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputNumber()
     */
    public final boolean isInputNumber()
    {
        boolean inputNumber58a = false;
        // inputNumber has no pre constraints
        inputNumber58a = handleIsInputNumber();
        // inputNumber has no post constraints
        return inputNumber58a;
    }

   /**
    * @see FrontEndParameter#isInputRange()
    * @return boolean
    */
    protected abstract boolean handleIsInputRange();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputRange()
     */
    public final boolean isInputRange()
    {
        boolean inputRange59a = false;
        // inputRange has no pre constraints
        inputRange59a = handleIsInputRange();
        // inputRange has no post constraints
        return inputRange59a;
    }

   /**
    * @see FrontEndParameter#isInputReset()
    * @return boolean
    */
    protected abstract boolean handleIsInputReset();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputReset()
     */
    public final boolean isInputReset()
    {
        boolean inputReset60a = false;
        // inputReset has no pre constraints
        inputReset60a = handleIsInputReset();
        // inputReset has no post constraints
        return inputReset60a;
    }

   /**
    * @see FrontEndParameter#isInputSearch()
    * @return boolean
    */
    protected abstract boolean handleIsInputSearch();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputSearch()
     */
    public final boolean isInputSearch()
    {
        boolean inputSearch61a = false;
        // inputSearch has no pre constraints
        inputSearch61a = handleIsInputSearch();
        // inputSearch has no post constraints
        return inputSearch61a;
    }

   /**
    * @see FrontEndParameter#isInputSubmit()
    * @return boolean
    */
    protected abstract boolean handleIsInputSubmit();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputSubmit()
     */
    public final boolean isInputSubmit()
    {
        boolean inputSubmit62a = false;
        // inputSubmit has no pre constraints
        inputSubmit62a = handleIsInputSubmit();
        // inputSubmit has no post constraints
        return inputSubmit62a;
    }

   /**
    * @see FrontEndParameter#isInputTel()
    * @return boolean
    */
    protected abstract boolean handleIsInputTel();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputTel()
     */
    public final boolean isInputTel()
    {
        boolean inputTel63a = false;
        // inputTel has no pre constraints
        inputTel63a = handleIsInputTel();
        // inputTel has no post constraints
        return inputTel63a;
    }

   /**
    * @see FrontEndParameter#isInputTime()
    * @return boolean
    */
    protected abstract boolean handleIsInputTime();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputTime()
     */
    public final boolean isInputTime()
    {
        boolean inputTime64a = false;
        // inputTime has no pre constraints
        inputTime64a = handleIsInputTime();
        // inputTime has no post constraints
        return inputTime64a;
    }

   /**
    * @see FrontEndParameter#isInputUrl()
    * @return boolean
    */
    protected abstract boolean handleIsInputUrl();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputUrl()
     */
    public final boolean isInputUrl()
    {
        boolean inputUrl65a = false;
        // inputUrl has no pre constraints
        inputUrl65a = handleIsInputUrl();
        // inputUrl has no post constraints
        return inputUrl65a;
    }

   /**
    * @see FrontEndParameter#isInputWeek()
    * @return boolean
    */
    protected abstract boolean handleIsInputWeek();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputWeek()
     */
    public final boolean isInputWeek()
    {
        boolean inputWeek66a = false;
        // inputWeek has no pre constraints
        inputWeek66a = handleIsInputWeek();
        // inputWeek has no post constraints
        return inputWeek66a;
    }

   /**
    * @see FrontEndParameter#getInputType()
    * @return String
    */
    protected abstract String handleGetInputType();

    /**
     * TODO: Model Documentation for FrontEndParameter.inputType
     * @return (String)handleGetInputType()
     */
    public final String getInputType()
    {
        String inputType67a = null;
        // inputType has no pre constraints
        inputType67a = handleGetInputType();
        // inputType has no post constraints
        return inputType67a;
    }

   /**
    * @see FrontEndParameter#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * The default message value for this parameter.
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue68a = null;
        // messageValue has no pre constraints
        messageValue68a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue68a;
    }

   /**
    * @see FrontEndParameter#getDocumentationKey()
    * @return String
    */
    protected abstract String handleGetDocumentationKey();

    /**
     * A resource message key suited for the parameter's documentation.
     * @return (String)handleGetDocumentationKey()
     */
    public final String getDocumentationKey()
    {
        String documentationKey69a = null;
        // documentationKey has no pre constraints
        documentationKey69a = handleGetDocumentationKey();
        // documentationKey has no post constraints
        return documentationKey69a;
    }

   /**
    * @see FrontEndParameter#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * The default message key for this parameter.
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey70a = null;
        // messageKey has no pre constraints
        messageKey70a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey70a;
    }

   /**
    * @see FrontEndParameter#getDocumentationValue()
    * @return String
    */
    protected abstract String handleGetDocumentationValue();

    /**
     * A resource message value suited for the parameter's documentation.
     * @return (String)handleGetDocumentationValue()
     */
    public final String getDocumentationValue()
    {
        String documentationValue71a = null;
        // documentationValue has no pre constraints
        documentationValue71a = handleGetDocumentationValue();
        // documentationValue has no post constraints
        return documentationValue71a;
    }

   /**
    * @see FrontEndParameter#getInputAction()
    * @return String
    */
    protected abstract String handleGetInputAction();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (String)handleGetInputAction()
     */
    public final String getInputAction()
    {
        String inputAction72a = null;
        // inputAction has no pre constraints
        inputAction72a = handleGetInputAction();
        // inputAction has no post constraints
        return inputAction72a;
    }

   /**
    * @see FrontEndParameter#getFrontEndClasses()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetFrontEndClasses();

    /**
     * TODO: Model Documentation for FrontEndParameter.frontEndClasses
     * @return (Set<String>)handleGetFrontEndClasses()
     */
    public final Set<String> getFrontEndClasses()
    {
        Set<String> frontEndClasses73a = null;
        // frontEndClasses has no pre constraints
        frontEndClasses73a = handleGetFrontEndClasses();
        // frontEndClasses has no post constraints
        return frontEndClasses73a;
    }

   /**
    * @see FrontEndParameter#getDisplayCondition()
    * @return String
    */
    protected abstract String handleGetDisplayCondition();

    /**
     * TODO: Model Documentation for FrontEndParameter.displayCondition
     * @return (String)handleGetDisplayCondition()
     */
    public final String getDisplayCondition()
    {
        String displayCondition74a = null;
        // displayCondition has no pre constraints
        displayCondition74a = handleGetDisplayCondition();
        // displayCondition has no post constraints
        return displayCondition74a;
    }

   /**
    * @see FrontEndParameter#getMinLength()
    * @return String
    */
    protected abstract String handleGetMinLength();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMinLength()
     */
    public final String getMinLength()
    {
        String minLength75a = null;
        // minLength has no pre constraints
        minLength75a = handleGetMinLength();
        // minLength has no post constraints
        return minLength75a;
    }

   /**
    * @see FrontEndParameter#getMin()
    * @return String
    */
    protected abstract String handleGetMin();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMin()
     */
    public final String getMin()
    {
        String min76a = null;
        // min has no pre constraints
        min76a = handleGetMin();
        // min has no post constraints
        return min76a;
    }

   /**
    * @see FrontEndParameter#getMax()
    * @return String
    */
    protected abstract String handleGetMax();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMax()
     */
    public final String getMax()
    {
        String max77a = null;
        // max has no pre constraints
        max77a = handleGetMax();
        // max has no post constraints
        return max77a;
    }

   /**
    * @see FrontEndParameter#getComponent()
    * @return Boolean
    */
    protected abstract Boolean handleGetComponent();

    /**
     * TODO: Model Documentation for FrontEndParameter.component
     * @return (Boolean)handleGetComponent()
     */
    public final Boolean getComponent()
    {
        Boolean component78a = null;
        // component has no pre constraints
        component78a = handleGetComponent();
        // component has no post constraints
        return component78a;
    }

   /**
    * @see FrontEndParameter#getMappedComponent()
    * @return String
    */
    protected abstract String handleGetMappedComponent();

    /**
     * TODO: Model Documentation for FrontEndParameter.mappedComponent
     * @return (String)handleGetMappedComponent()
     */
    public final String getMappedComponent()
    {
        String mappedComponent79a = null;
        // mappedComponent has no pre constraints
        mappedComponent79a = handleGetMappedComponent();
        // mappedComponent has no post constraints
        return mappedComponent79a;
    }

   /**
    * @see FrontEndParameter#getTree()
    * @return Boolean
    */
    protected abstract Boolean handleGetTree();

    /**
     * TODO: Model Documentation for FrontEndParameter.tree
     * @return (Boolean)handleGetTree()
     */
    public final Boolean getTree()
    {
        Boolean tree80a = null;
        // tree has no pre constraints
        tree80a = handleGetTree();
        // tree has no post constraints
        return tree80a;
    }

   /**
    * @see FrontEndParameter#getDisplayAttributes()
    * @return Collection<AttributeFacade>
    */
    protected abstract Collection<AttributeFacade> handleGetDisplayAttributes();

    /**
     * A list of all attributes which make up the table columns of this table (this only contains
     * attributes when the table is represented by an array).
     * @return (Collection<AttributeFacade>)handleGetDisplayAttributes()
     */
    public final Collection<AttributeFacade> getDisplayAttributes()
    {
        Collection<AttributeFacade> displayAttributes81a = null;
        // displayAttributes has no pre constraints
        displayAttributes81a = handleGetDisplayAttributes();
        // displayAttributes has no post constraints
        return displayAttributes81a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * FrontEndParameter.getTableColumnMessageKey
     * @param columnName
     * @return String
     */
    protected abstract String handleGetTableColumnMessageKey(String columnName);

    /**
     * TODO: Model Documentation for
     * FrontEndParameter.getTableColumnMessageKey
     * @param columnName String
     * The name of the table column.
     * @return handleGetTableColumnMessageKey(columnName)
     */
    public String getTableColumnMessageKey(String columnName)
    {
        // getTableColumnMessageKey has no pre constraints
        String returnValue = handleGetTableColumnMessageKey(columnName);
        // getTableColumnMessageKey has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * FrontEndParameter.getTableColumnMessageValue
     * @param columnName
     * @return String
     */
    protected abstract String handleGetTableColumnMessageValue(String columnName);

    /**
     * TODO: Model Documentation for
     * FrontEndParameter.getTableColumnMessageValue
     * @param columnName String
     * Returns the resource bundle value for this table's column, only returns a value when this
     * parameter is a table.
     * @return handleGetTableColumnMessageValue(columnName)
     */
    public String getTableColumnMessageValue(String columnName)
    {
        // getTableColumnMessageValue has no pre constraints
        String returnValue = handleGetTableColumnMessageValue(columnName);
        // getTableColumnMessageValue has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the arguments for this parameter's validators.
     * @param validatorType
     * @return Collection
     */
    protected abstract Collection handleGetValidatorArgs(String validatorType);

    /**
     * Gets the arguments for this parameter's validators.
     * @param validatorType String
     * The type of the validator.
     * @return handleGetValidatorArgs(validatorType)
     */
    public Collection getValidatorArgs(String validatorType)
    {
        // getValidatorArgs has no pre constraints
        Collection returnValue = handleGetValidatorArgs(validatorType);
        // getValidatorArgs has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Those actions that are targetting the given column, only makes sense when this parameter
     * represents a table view-variable.
     * @param columnName
     * @return List
     */
    protected abstract List handleGetTableColumnActions(String columnName);

    /**
     * Those actions that are targetting the given column, only makes sense when this parameter
     * represents a table view-variable.
     * @param columnName String
     * The column name of the column that the retrieved actions target.
     * @return handleGetTableColumnActions(columnName)
     */
    public List getTableColumnActions(String columnName)
    {
        // getTableColumnActions has no pre constraints
        List returnValue = handleGetTableColumnActions(columnName);
        // getTableColumnActions has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    private FrontEndView __getView1r;
    private boolean __getView1rSet = false;

    /**
     * All those variables that will be present as variables in the target view. These are the
     * trigger parameters on the incoming transitions.
     * @return (FrontEndView)handleGetView()
     */
    public final FrontEndView getView()
    {
        FrontEndView getView1r = this.__getView1r;
        if (!this.__getView1rSet)
        {
            // variables has no pre constraints
            Object result = handleGetView();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getView1r = (FrontEndView)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndParameterLogic.logger.warn("incorrect metafacade cast for FrontEndParameterLogic.getView FrontEndView " + result + ": " + shieldedResult);
            }
            // variables has no post constraints
            this.__getView1r = getView1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getView1rSet = true;
            }
        }
        return getView1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetView();

    private FrontEndAction __getAction2r;
    private boolean __getAction2rSet = false;

    /**
     * All parameters sent by this "front-end" action.
     * @return (FrontEndAction)handleGetAction()
     */
    public final FrontEndAction getAction()
    {
        FrontEndAction getAction2r = this.__getAction2r;
        if (!this.__getAction2rSet)
        {
            // parameters has no pre constraints
            Object result = handleGetAction();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAction2r = (FrontEndAction)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndParameterLogic.logger.warn("incorrect metafacade cast for FrontEndParameterLogic.getAction FrontEndAction " + result + ": " + shieldedResult);
            }
            // parameters has no post constraints
            this.__getAction2r = getAction2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAction2rSet = true;
            }
        }
        return getAction2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAction();

    private FrontEndControllerOperation __getControllerOperation3r;
    private boolean __getControllerOperation3rSet = false;

    /**
     * The set of fields in the form made up form this controller operation's parameters.
     * @return (FrontEndControllerOperation)handleGetControllerOperation()
     */
    public final FrontEndControllerOperation getControllerOperation()
    {
        FrontEndControllerOperation getControllerOperation3r = this.__getControllerOperation3r;
        if (!this.__getControllerOperation3rSet)
        {
            // formFields has no pre constraints
            Object result = handleGetControllerOperation();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getControllerOperation3r = (FrontEndControllerOperation)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndParameterLogic.logger.warn("incorrect metafacade cast for FrontEndParameterLogic.getControllerOperation FrontEndControllerOperation " + result + ": " + shieldedResult);
            }
            // formFields has no post constraints
            this.__getControllerOperation3r = getControllerOperation3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerOperation3rSet = true;
            }
        }
        return getControllerOperation3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetControllerOperation();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ParameterFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}