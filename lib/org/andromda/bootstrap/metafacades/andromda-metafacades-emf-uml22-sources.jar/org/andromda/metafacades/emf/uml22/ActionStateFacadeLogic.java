// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActionFacade;
import org.andromda.metafacades.uml.ActionStateFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.State;

/**
 * A state models a situation during which some (usually implicit) invariant condition holds. The
 * states of protocol state machines are exposed to the users of their context classifiers. A
 * protocol state represents an exposed stable situation of its context classifier: when an instance
 * of the classifier is not processing any operation, users of this instance can always know its
 * state configuration.
 * MetafacadeLogic for ActionStateFacade
 *
 * @see ActionStateFacade
 */
public abstract class ActionStateFacadeLogic
    extends StateFacadeLogicImpl
    implements ActionStateFacade
{
    /**
     * The underlying UML object
     * @see State
     */
    protected State metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ActionStateFacadeLogic(State metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ActionStateFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ActionStateFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActionStateFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ActionStateFacade
     */
    public boolean isActionStateFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private ActionFacade __getEntry1r;
    private boolean __getEntry1rSet = false;

    /**
     * If this action is located on an action state, this will represent that state.
     * @return (ActionFacade)handleGetEntry()
     */
    public final ActionFacade getEntry()
    {
        ActionFacade getEntry1r = this.__getEntry1r;
        if (!this.__getEntry1rSet)
        {
            // actionState has no pre constraints
            Object result = handleGetEntry();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getEntry1r = (ActionFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ActionStateFacadeLogic.logger.warn("incorrect metafacade cast for ActionStateFacadeLogic.getEntry ActionFacade " + result + ": " + shieldedResult);
            }
            // actionState has no post constraints
            this.__getEntry1r = getEntry1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getEntry1rSet = true;
            }
        }
        return getEntry1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetEntry();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}