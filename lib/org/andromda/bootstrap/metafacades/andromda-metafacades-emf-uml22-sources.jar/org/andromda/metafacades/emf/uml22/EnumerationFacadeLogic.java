// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.EnumerationFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * Represents an enumeration. A data type whose values are enumerated in the model as enumeration
 * literals. May also be a Classifier with Stereotype Enumeration.
 * MetafacadeLogic for EnumerationFacade
 *
 * @see EnumerationFacade
 */
public abstract class EnumerationFacadeLogic
    extends ClassifierFacadeLogicImpl
    implements EnumerationFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EnumerationFacadeLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(EnumerationFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EnumerationFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EnumerationFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EnumerationFacade
     */
    public boolean isEnumerationFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see EnumerationFacade#getFromOperationSignature()
    * @return String
    */
    protected abstract String handleGetFromOperationSignature();

    /**
     * The 'from' operation signature.  This is the signature that takes the actual literal value
     * and allows a new enumeration to be constructed.
     * @return (String)handleGetFromOperationSignature()
     */
    public final String getFromOperationSignature()
    {
        String fromOperationSignature1a = null;
        // fromOperationSignature has no pre constraints
        fromOperationSignature1a = handleGetFromOperationSignature();
        // fromOperationSignature has no post constraints
        return fromOperationSignature1a;
    }

   /**
    * @see EnumerationFacade#getFromOperationName()
    * @return String
    */
    protected abstract String handleGetFromOperationName();

    /**
     * The 'from' operation name.  This is the name of the operation that takes the actual literal
     * value and allows a new enumeration to be constructed.
     * @return (String)handleGetFromOperationName()
     */
    public final String getFromOperationName()
    {
        String fromOperationName2a = null;
        // fromOperationName has no pre constraints
        fromOperationName2a = handleGetFromOperationName();
        // fromOperationName has no post constraints
        return fromOperationName2a;
    }

   /**
    * @see EnumerationFacade#isTypeSafe()
    * @return boolean
    */
    protected abstract boolean handleIsTypeSafe();

    /**
     * Indicates whether the enumeration must be generated using a Java 5 type-safe enum or a
     * traditional enumeration-pattern class.
     * @return (boolean)handleIsTypeSafe()
     */
    public final boolean isTypeSafe()
    {
        boolean typeSafe3a = false;
        // typeSafe has no pre constraints
        typeSafe3a = handleIsTypeSafe();
        // typeSafe has no post constraints
        return typeSafe3a;
    }

   /**
    * @see EnumerationFacade#getDisplay()
    * @return String
    */
    protected abstract String handleGetDisplay();

    /**
     * The 'from' operation name.  This is the name of the operation that takes the actual literal
     * value and allows a new enumeration to be constructed.
     * @return (String)handleGetDisplay()
     */
    public final String getDisplay()
    {
        String display4a = null;
        // display has no pre constraints
        display4a = handleGetDisplay();
        // display has no post constraints
        return display4a;
    }

    // ------------- associations ------------------

    /**
     * Represents an enumeration. A data type whose values are enumerated in the model as
     * enumeration
     * literals. May also be a Classifier with Stereotype Enumeration.
     * @return (ClassifierFacade)handleGetLiteralType()
     */
    public final ClassifierFacade getLiteralType()
    {
        ClassifierFacade getLiteralType1r = null;
        // enumerationFacade has no pre constraints
        Object result = handleGetLiteralType();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getLiteralType1r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EnumerationFacadeLogic.logger.warn("incorrect metafacade cast for EnumerationFacadeLogic.getLiteralType ClassifierFacade " + result + ": " + shieldedResult);
        }
        // enumerationFacade has no post constraints
        return getLiteralType1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetLiteralType();

    /**
     * Represents an enumeration. A data type whose values are enumerated in the model as
     * enumeration
     * literals. May also be a Classifier with Stereotype Enumeration.
     * @return (Collection<AttributeFacade>)handleGetMemberVariables()
     */
    public final Collection<AttributeFacade> getMemberVariables()
    {
        Collection<AttributeFacade> getMemberVariables2r = null;
        // enumeration has no pre constraints
        Collection result = handleGetMemberVariables();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getMemberVariables2r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EnumerationFacadeLogic.logger.warn("incorrect metafacade cast for EnumerationFacadeLogic.getMemberVariables Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // enumeration has no post constraints
        return getMemberVariables2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetMemberVariables();

    /**
     * If the attribute is an enumeration literal this represents the owning enumeration. Can be
     * empty.
     * @return (Collection<AttributeFacade>)handleGetLiterals()
     */
    public final Collection<AttributeFacade> getLiterals()
    {
        Collection<AttributeFacade> getLiterals3r = null;
        // enumeration has no pre constraints
        Collection result = handleGetLiterals();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getLiterals3r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EnumerationFacadeLogic.logger.warn("incorrect metafacade cast for EnumerationFacadeLogic.getLiterals Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // enumeration has no post constraints
        return getLiterals3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetLiterals();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::EnumerationFacade::enumerations must have at least one literal value</p>
     * <p><b>Error:</b> An enumeration must have at least one literal modeled.</p>
     * <p><b>OCL:</b> context EnumerationFacade
inv: literals -> notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::EnumerationFacade::name must be a valid identifier</p>
     * <p><b>Error:</b> Model Element name cannot be a reserved word</p>
     * <p><b>OCL:</b> context EnumerationFacade inv: validIdentifierName=true</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"literals")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::EnumerationFacade::enumerations must have at least one literal value",
                        "An enumeration must have at least one literal modeled."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::EnumerationFacade::enumerations must have at least one literal value' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"validIdentifierName"),true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::EnumerationFacade::name must be a valid identifier",
                        "Model Element name cannot be a reserved word"));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::EnumerationFacade::name must be a valid identifier' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}