// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActorFacade;
import org.andromda.metafacades.uml.ManageableEntity;
import org.andromda.metafacades.uml.ManageableEntityAssociationEnd;
import org.andromda.metafacades.uml.ManageableEntityAttribute;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.apache.log4j.Logger;

/**
 * An Entity that is Manageable: will produce CRUD operations in the EntityManager implementation.
 * MetafacadeLogic for ManageableEntity
 *
 * @see ManageableEntity
 */
public abstract class ManageableEntityLogic
    extends EntityLogicImpl
    implements ManageableEntity
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ManageableEntityLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ManageableEntityLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ManageableEntity if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntity";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ManageableEntity
     */
    public boolean isManageableEntityMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ManageableEntity#getManageablePackageName()
    * @return String
    */
    protected abstract String handleGetManageablePackageName();

    /**
     * The entity package name.
     * @return (String)handleGetManageablePackageName()
     */
    public final String getManageablePackageName()
    {
        String manageablePackageName1a = null;
        // manageablePackageName has no pre constraints
        manageablePackageName1a = handleGetManageablePackageName();
        // manageablePackageName has no post constraints
        return manageablePackageName1a;
    }

   /**
    * @see ManageableEntity#getManageableServiceAccessorCall()
    * @return String
    */
    protected abstract String handleGetManageableServiceAccessorCall();

    /**
     * The entity accessor (getter) call.
     * @return (String)handleGetManageableServiceAccessorCall()
     */
    public final String getManageableServiceAccessorCall()
    {
        String manageableServiceAccessorCall2a = null;
        // manageableServiceAccessorCall has no pre constraints
        manageableServiceAccessorCall2a = handleGetManageableServiceAccessorCall();
        // manageableServiceAccessorCall has no post constraints
        return manageableServiceAccessorCall2a;
    }

   /**
    * @see ManageableEntity#isRead()
    * @return boolean
    */
    protected abstract boolean handleIsRead();

    /**
     * Create a read operation on the entity manager?
     * @return (boolean)handleIsRead()
     */
    public final boolean isRead()
    {
        boolean read3a = false;
        // read has no pre constraints
        read3a = handleIsRead();
        // read has no post constraints
        return read3a;
    }

   /**
    * @see ManageableEntity#isCreate()
    * @return boolean
    */
    protected abstract boolean handleIsCreate();

    /**
     * Create a create operation on the entity manager?
     * @return (boolean)handleIsCreate()
     */
    public final boolean isCreate()
    {
        boolean create4a = false;
        // create has no pre constraints
        create4a = handleIsCreate();
        // create has no post constraints
        return create4a;
    }

   /**
    * @see ManageableEntity#isUpdate()
    * @return boolean
    */
    protected abstract boolean handleIsUpdate();

    /**
     * Create an update operation on the entity manager?
     * @return (boolean)handleIsUpdate()
     */
    public final boolean isUpdate()
    {
        boolean update5a = false;
        // update has no pre constraints
        update5a = handleIsUpdate();
        // update has no post constraints
        return update5a;
    }

   /**
    * @see ManageableEntity#isDelete()
    * @return boolean
    */
    protected abstract boolean handleIsDelete();

    /**
     * Create a delete operation on the entity manager?
     * @return (boolean)handleIsDelete()
     */
    public final boolean isDelete()
    {
        boolean delete6a = false;
        // delete has no pre constraints
        delete6a = handleIsDelete();
        // delete has no post constraints
        return delete6a;
    }

   /**
    * @see ManageableEntity#getManageablePackagePath()
    * @return String
    */
    protected abstract String handleGetManageablePackagePath();

    /**
     * The Package path of the Entity
     * @return (String)handleGetManageablePackagePath()
     */
    public final String getManageablePackagePath()
    {
        String manageablePackagePath7a = null;
        // manageablePackagePath has no pre constraints
        manageablePackagePath7a = handleGetManageablePackagePath();
        // manageablePackagePath has no post constraints
        return manageablePackagePath7a;
    }

   /**
    * @see ManageableEntity#getManageableServiceName()
    * @return String
    */
    protected abstract String handleGetManageableServiceName();

    /**
     * The service name of the entity.
     * @return (String)handleGetManageableServiceName()
     */
    public final String getManageableServiceName()
    {
        String manageableServiceName8a = null;
        // manageableServiceName has no pre constraints
        manageableServiceName8a = handleGetManageableServiceName();
        // manageableServiceName has no post constraints
        return manageableServiceName8a;
    }

   /**
    * @see ManageableEntity#getFullyQualifiedManageableServiceName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedManageableServiceName();

    /**
     * The fully qualified service name of the entity.
     * @return (String)handleGetFullyQualifiedManageableServiceName()
     */
    public final String getFullyQualifiedManageableServiceName()
    {
        String fullyQualifiedManageableServiceName9a = null;
        // fullyQualifiedManageableServiceName has no pre constraints
        fullyQualifiedManageableServiceName9a = handleGetFullyQualifiedManageableServiceName();
        // fullyQualifiedManageableServiceName has no post constraints
        return fullyQualifiedManageableServiceName9a;
    }

   /**
    * @see ManageableEntity#getManageableServiceFullPath()
    * @return String
    */
    protected abstract String handleGetManageableServiceFullPath();

    /**
     * The service full path of the entity.
     * @return (String)handleGetManageableServiceFullPath()
     */
    public final String getManageableServiceFullPath()
    {
        String manageableServiceFullPath10a = null;
        // manageableServiceFullPath has no pre constraints
        manageableServiceFullPath10a = handleGetManageableServiceFullPath();
        // manageableServiceFullPath has no post constraints
        return manageableServiceFullPath10a;
    }

   /**
    * @see ManageableEntity#getManageableMembers()
    * @return List<ModelElementFacade>
    */
    protected abstract List<ModelElementFacade> handleGetManageableMembers();

    /**
     * ManageableAttributes and ManageableAssociationEnds
     * @return (List<ModelElementFacade>)handleGetManageableMembers()
     */
    public final List<ModelElementFacade> getManageableMembers()
    {
        List<ModelElementFacade> manageableMembers11a = null;
        // manageableMembers has no pre constraints
        manageableMembers11a = handleGetManageableMembers();
        // manageableMembers has no post constraints
        return manageableMembers11a;
    }

   /**
    * @see ManageableEntity#isManageable()
    * @return boolean
    */
    protected abstract boolean handleIsManageable();

    /**
     * True: Entity is manageable.
     * @return (boolean)handleIsManageable()
     */
    public final boolean isManageable()
    {
        boolean manageable12a = false;
        // manageable has no pre constraints
        manageable12a = handleIsManageable();
        // manageable has no post constraints
        return manageable12a;
    }

   /**
    * @see ManageableEntity#getMaximumListSize()
    * @return int
    */
    protected abstract int handleGetMaximumListSize();

    /**
     * The maximum number of rows to load from the database.
     * @return (int)handleGetMaximumListSize()
     */
    public final int getMaximumListSize()
    {
        int maximumListSize13a = 0;
        // maximumListSize has no pre constraints
        maximumListSize13a = handleGetMaximumListSize();
        // maximumListSize has no post constraints
        return maximumListSize13a;
    }

   /**
    * @see ManageableEntity#getPageSize()
    * @return int
    */
    protected abstract int handleGetPageSize();

    /**
     * The maximum number of rows to load from the database.
     * @return (int)handleGetPageSize()
     */
    public final int getPageSize()
    {
        int pageSize14a = 0;
        // pageSize has no pre constraints
        pageSize14a = handleGetPageSize();
        // pageSize has no post constraints
        return pageSize14a;
    }

   /**
    * @see ManageableEntity#isResolveable()
    * @return boolean
    */
    protected abstract boolean handleIsResolveable();

    /**
     * The maximum number of rows to load from the database.
     * @return (boolean)handleIsResolveable()
     */
    public final boolean isResolveable()
    {
        boolean resolveable15a = false;
        // resolveable has no pre constraints
        resolveable15a = handleIsResolveable();
        // resolveable has no post constraints
        return resolveable15a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Returns a string with the attributes without wrapper types.
     * @param withTypes
     * @return String
     */
    protected abstract String handleListManageableMembers(boolean withTypes);

    /**
     * Returns a string with the attributes without wrapper types.
     * @param withTypes boolean
     * TODO: Model Documentation for
     * ManageableEntity.listManageableMembers(withTypes)
     * @return handleListManageableMembers(withTypes)
     */
    public String listManageableMembers(boolean withTypes)
    {
        // listManageableMembers has no pre constraints
        String returnValue = handleListManageableMembers(withTypes);
        // listManageableMembers has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns a string with the attributes and wrapper types.
     * @return String
     */
    protected abstract String handleListManageableMembersWithWrapperTypes();

    /**
     * Returns a string with the attributes and wrapper types.
     * @return handleListManageableMembersWithWrapperTypes()
     */
    public String listManageableMembersWithWrapperTypes()
    {
        // listManageableMembersWithWrapperTypes has no pre constraints
        String returnValue = handleListManageableMembersWithWrapperTypes();
        // listManageableMembersWithWrapperTypes has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    private List<ActorFacade> __getUsers1r;
    private boolean __getUsers1rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (List<ActorFacade>)handleGetUsers()
     */
    public final List<ActorFacade> getUsers()
    {
        List<ActorFacade> getUsers1r = this.__getUsers1r;
        if (!this.__getUsers1rSet)
        {
            // manageableEntity has no pre constraints
            List result = handleGetUsers();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getUsers1r = (List<ActorFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getUsers List<ActorFacade> " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getUsers1r = getUsers1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUsers1rSet = true;
            }
        }
        return getUsers1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetUsers();

    private List<ManageableEntityAssociationEnd> __getManageableAssociationEnds2r;
    private boolean __getManageableAssociationEnds2rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (List<ManageableEntityAssociationEnd>)handleGetManageableAssociationEnds()
     */
    public final List<ManageableEntityAssociationEnd> getManageableAssociationEnds()
    {
        List<ManageableEntityAssociationEnd> getManageableAssociationEnds2r = this.__getManageableAssociationEnds2r;
        if (!this.__getManageableAssociationEnds2rSet)
        {
            // manageableEntity has no pre constraints
            List result = handleGetManageableAssociationEnds();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getManageableAssociationEnds2r = (List<ManageableEntityAssociationEnd>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getManageableAssociationEnds List<ManageableEntityAssociationEnd> " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getManageableAssociationEnds2r = getManageableAssociationEnds2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableAssociationEnds2rSet = true;
            }
        }
        return getManageableAssociationEnds2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetManageableAssociationEnds();

    private List<ManageableEntityAttribute> __getManageableAttributes3r;
    private boolean __getManageableAttributes3rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (List<ManageableEntityAttribute>)handleGetManageableAttributes()
     */
    public final List<ManageableEntityAttribute> getManageableAttributes()
    {
        List<ManageableEntityAttribute> getManageableAttributes3r = this.__getManageableAttributes3r;
        if (!this.__getManageableAttributes3rSet)
        {
            // manageableEntity has no pre constraints
            List result = handleGetManageableAttributes();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getManageableAttributes3r = (List<ManageableEntityAttribute>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getManageableAttributes List<ManageableEntityAttribute> " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getManageableAttributes3r = getManageableAttributes3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableAttributes3rSet = true;
            }
        }
        return getManageableAttributes3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetManageableAttributes();

    private ManageableEntityAttribute __getManageableIdentifier4r;
    private boolean __getManageableIdentifier4rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (ManageableEntityAttribute)handleGetManageableIdentifier()
     */
    public final ManageableEntityAttribute getManageableIdentifier()
    {
        ManageableEntityAttribute getManageableIdentifier4r = this.__getManageableIdentifier4r;
        if (!this.__getManageableIdentifier4rSet)
        {
            // manageableEntity has no pre constraints
            Object result = handleGetManageableIdentifier();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getManageableIdentifier4r = (ManageableEntityAttribute)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getManageableIdentifier ManageableEntityAttribute " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getManageableIdentifier4r = getManageableIdentifier4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableIdentifier4rSet = true;
            }
        }
        return getManageableIdentifier4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetManageableIdentifier();

    private ManageableEntityAttribute __getDisplayAttribute5r;
    private boolean __getDisplayAttribute5rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (ManageableEntityAttribute)handleGetDisplayAttribute()
     */
    public final ManageableEntityAttribute getDisplayAttribute()
    {
        ManageableEntityAttribute getDisplayAttribute5r = this.__getDisplayAttribute5r;
        if (!this.__getDisplayAttribute5rSet)
        {
            // manageableEntity has no pre constraints
            Object result = handleGetDisplayAttribute();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getDisplayAttribute5r = (ManageableEntityAttribute)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getDisplayAttribute ManageableEntityAttribute " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getDisplayAttribute5r = getDisplayAttribute5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDisplayAttribute5rSet = true;
            }
        }
        return getDisplayAttribute5r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetDisplayAttribute();

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (List<ManageableEntity>)handleGetReferencingManageables()
     */
    public final List<ManageableEntity> getReferencingManageables()
    {
        List<ManageableEntity> getReferencingManageables6r = null;
        // manageableEntity has no pre constraints
        List result = handleGetReferencingManageables();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getReferencingManageables6r = (List<ManageableEntity>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getReferencingManageables List<ManageableEntity> " + result + ": " + shieldedResult);
        }
        // manageableEntity has no post constraints
        return getReferencingManageables6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetReferencingManageables();

    private List<ManageableEntity> __getAllManageables7r;
    private boolean __getAllManageables7rSet = false;

    /**
     * An Entity that is Manageable: will produce CRUD operations in the EntityManager
     * implementation.
     * @return (List<ManageableEntity>)handleGetAllManageables()
     */
    public final List<ManageableEntity> getAllManageables()
    {
        List<ManageableEntity> getAllManageables7r = this.__getAllManageables7r;
        if (!this.__getAllManageables7rSet)
        {
            // manageableEntity has no pre constraints
            List result = handleGetAllManageables();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllManageables7r = (List<ManageableEntity>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityLogic.logger.warn("incorrect metafacade cast for ManageableEntityLogic.getAllManageables List<ManageableEntity> " + result + ": " + shieldedResult);
            }
            // manageableEntity has no post constraints
            this.__getAllManageables7r = getAllManageables7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllManageables7rSet = true;
            }
        }
        return getAllManageables7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAllManageables();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see EntityLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}