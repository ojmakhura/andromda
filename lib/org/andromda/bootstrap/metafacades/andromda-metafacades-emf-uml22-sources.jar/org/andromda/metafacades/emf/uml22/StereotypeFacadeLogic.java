// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.StereotypeFacade;
import org.eclipse.uml2.uml.Stereotype;

/**
 * Defines how an existing metaclass may be extended, and enables the use of platform or domain
 * specific terminology or notation in place of, or in addition to, the ones used for the extended
 * metaclass.
 * MetafacadeLogic for StereotypeFacade
 *
 * @see StereotypeFacade
 */
public abstract class StereotypeFacadeLogic
    extends GeneralizableElementFacadeLogicImpl
    implements StereotypeFacade
{
    /**
     * The underlying UML object
     * @see Stereotype
     */
    protected Stereotype metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected StereotypeFacadeLogic(Stereotype metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to StereotypeFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StereotypeFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see StereotypeFacade
     */
    public boolean isStereotypeFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see GeneralizableElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}