// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.GuardFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Constraint;

/**
 * A representation of the model object 'Constraint'. A condition or restriction expressed in
 * natural language text or in a machine readable language for the purpose of declaring some of the
 * semantics of an element.
 * MetafacadeLogic for GuardFacade
 *
 * @see GuardFacade
 */
public abstract class GuardFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements GuardFacade
{
    /**
     * The underlying UML object
     * @see Constraint
     */
    protected Constraint metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected GuardFacadeLogic(Constraint metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(GuardFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to GuardFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GuardFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see GuardFacade
     */
    public boolean isGuardFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see GuardFacade#getBody()
    * @return String
    */
    protected abstract String handleGetBody();

    /**
     * TODO: Model Documentation for GuardFacade.body
     * @return (String)handleGetBody()
     */
    public final String getBody()
    {
        String body1a = null;
        // body has no pre constraints
        body1a = handleGetBody();
        // body has no post constraints
        return body1a;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Constraint'. A condition or restriction expressed in
     * natural
     * language text or in a machine readable language for the purpose of declaring some of the
     * semantics
     * of an element.
     * @return (TransitionFacade)handleGetTransition()
     */
    public final TransitionFacade getTransition()
    {
        TransitionFacade getTransition1r = null;
        // guard has no pre constraints
        Object result = handleGetTransition();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTransition1r = (TransitionFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GuardFacadeLogic.logger.warn("incorrect metafacade cast for GuardFacadeLogic.getTransition TransitionFacade " + result + ": " + shieldedResult);
        }
        // guard has no post constraints
        return getTransition1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTransition();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}