// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EntityAssociationEnd;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;

/**
 * Represents an association end of an entity.
 * MetafacadeLogic for EntityAssociationEnd
 *
 * @see EntityAssociationEnd
 */
public abstract class EntityAssociationEndLogic
    extends AssociationEndFacadeLogicImpl
    implements EntityAssociationEnd
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EntityAssociationEndLogic(Object metaObjectIn, String context)
    {
        super((AssociationEnd)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(EntityAssociationEndLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EntityAssociationEnd if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAssociationEnd";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EntityAssociationEnd
     */
    public boolean isEntityAssociationEndMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see EntityAssociationEnd#getColumnName()
    * @return String
    */
    protected abstract String handleGetColumnName();

    /**
     * The name of the column that makes up the foreign key.
     * @return (String)handleGetColumnName()
     */
    public final String getColumnName()
    {
        String columnName1a = null;
        // columnName has no pre constraints
        columnName1a = handleGetColumnName();
        // columnName has no post constraints
        return columnName1a;
    }

   /**
    * @see EntityAssociationEnd#getForeignKeySuffix()
    * @return String
    */
    protected abstract String handleGetForeignKeySuffix();

    /**
     * The current foreign key suffix specified for this entity association end facade.
     * @return (String)handleGetForeignKeySuffix()
     */
    public final String getForeignKeySuffix()
    {
        String foreignKeySuffix2a = null;
        // foreignKeySuffix has no pre constraints
        foreignKeySuffix2a = handleGetForeignKeySuffix();
        // foreignKeySuffix has no post constraints
        return foreignKeySuffix2a;
    }

   /**
    * @see EntityAssociationEnd#isForeignIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsForeignIdentifier();

    /**
     * Indicates whether or not a foreign identifier should be used for the entity that owns this
     * association end.  This would only make sense in the case of a child in a one-to-one
     * parent-child association.  If this flag is true, then the identifier of this entity should
     * also be used as the foreign key to the related parent entity.
     * @return (boolean)handleIsForeignIdentifier()
     */
    public final boolean isForeignIdentifier()
    {
        boolean foreignIdentifier3a = false;
        // foreignIdentifier has no pre constraints
        foreignIdentifier3a = handleIsForeignIdentifier();
        // foreignIdentifier has no post constraints
        return foreignIdentifier3a;
    }

   /**
    * @see EntityAssociationEnd#getForeignKeyConstraintName()
    * @return String
    */
    protected abstract String handleGetForeignKeyConstraintName();

    /**
     * The name of the foreign key constraint to use for databases.
     * @return (String)handleGetForeignKeyConstraintName()
     */
    public final String getForeignKeyConstraintName()
    {
        String foreignKeyConstraintName4a = null;
        // foreignKeyConstraintName has no pre constraints
        foreignKeyConstraintName4a = handleGetForeignKeyConstraintName();
        // foreignKeyConstraintName has no post constraints
        return foreignKeyConstraintName4a;
    }

   /**
    * @see EntityAssociationEnd#getColumnIndex()
    * @return String
    */
    protected abstract String handleGetColumnIndex();

    /**
     * The name of the index to create on a column that persists the foreign key attribute.
     * @return (String)handleGetColumnIndex()
     */
    public final String getColumnIndex()
    {
        String columnIndex5a = null;
        // columnIndex has no pre constraints
        columnIndex5a = handleGetColumnIndex();
        // columnIndex has no post constraints
        return columnIndex5a;
    }

   /**
    * @see EntityAssociationEnd#getSqlType()
    * @return String
    */
    protected abstract String handleGetSqlType();

    /**
     * The SQL type for this the foreign key column of this association end.
     * @return (String)handleGetSqlType()
     */
    public final String getSqlType()
    {
        String sqlType6a = null;
        // sqlType has no pre constraints
        sqlType6a = handleGetSqlType();
        // sqlType has no post constraints
        return sqlType6a;
    }

   /**
    * @see EntityAssociationEnd#isTransient()
    * @return boolean
    */
    protected abstract boolean handleIsTransient();

    /**
     * Indicates this association end should be ignored by the persistence layer.
     * @return (boolean)handleIsTransient()
     */
    public final boolean isTransient()
    {
        boolean transient7a = false;
        // transient has no pre constraints
        transient7a = handleIsTransient();
        // transient has no post constraints
        return transient7a;
    }

   /**
    * @see EntityAssociationEnd#isIdentifiersPresent()
    * @return boolean
    */
    protected abstract boolean handleIsIdentifiersPresent();

    /**
     * True if the associationEnd is marked with identifiers stereotype, false otherwise.
     * @return (boolean)handleIsIdentifiersPresent()
     */
    public final boolean isIdentifiersPresent()
    {
        boolean identifiersPresent8a = false;
        // identifiersPresent has no pre constraints
        identifiersPresent8a = handleIsIdentifiersPresent();
        // identifiersPresent has no post constraints
        return identifiersPresent8a;
    }

   /**
    * @see EntityAssociationEnd#getUniqueGroup()
    * @return String
    */
    protected abstract String handleGetUniqueGroup();

    /**
     * The name of the unique-key that this unique association end belongs
     * @return (String)handleGetUniqueGroup()
     */
    public final String getUniqueGroup()
    {
        String uniqueGroup9a = null;
        // uniqueGroup has no pre constraints
        uniqueGroup9a = handleGetUniqueGroup();
        // uniqueGroup has no post constraints
        return uniqueGroup9a;
    }

   /**
    * @see EntityAssociationEnd#isIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsIdentifier();

    /**
     * True if this association is an identifier for its entity.
     * @return (boolean)handleIsIdentifier()
     */
    public final boolean isIdentifier()
    {
        boolean identifier10a = false;
        // identifier has no pre constraints
        identifier10a = handleIsIdentifier();
        // identifier has no post constraints
        return identifier10a;
    }

    // ------------- associations ------------------

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::EntityAssociationEnd::valid foreign identifiers.</p>
     * <p><b>Error:</b> Only ONE association end on an entity can be flagged as having a foreign identifier at any given
time.  It also MUST be the child end (the other side is flagged as having composite aggregation) of
a one-to-one association.</p>
     * <p><b>OCL:</b> context EntityAssociationEndFacade 
inv : foreignIdentifier implies (one2One and child and type.associationEnds -> one (foreignIdentifier))</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see AssociationEndFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"foreignIdentifier"))).booleanValue()?(Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"one2One"))).booleanValue()&&Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"child"))).booleanValue()&&OCLCollections.one(OCLIntrospector.invoke(contextElement,"type.associationEnds"),new Predicate(){public boolean evaluate(Object object){return Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(object,"foreignIdentifier"))).booleanValue();}})):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::EntityAssociationEnd::valid foreign identifiers.",
                        "Only ONE association end on an entity can be flagged as having a foreign identifier at any given\ntime.  It also MUST be the child end (the other side is flagged as having composite aggregation) of\na one-to-one association."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::EntityAssociationEnd::valid foreign identifiers.' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}