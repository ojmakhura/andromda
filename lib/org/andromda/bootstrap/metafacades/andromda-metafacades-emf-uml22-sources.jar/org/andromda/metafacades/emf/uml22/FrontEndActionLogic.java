// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActionState;
import org.andromda.metafacades.uml.FrontEndController;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndForward;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndView;
import org.andromda.metafacades.uml.ParameterFacade;
import org.andromda.metafacades.uml.StateVertexFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Transformer;
import org.apache.log4j.Logger;

/**
 * Represents a "front-end" action. An action is some action that is taken when a front-end even
 * occurs.
 * MetafacadeLogic for FrontEndAction
 *
 * @see FrontEndAction
 */
public abstract class FrontEndActionLogic
    extends FrontEndForwardLogicImpl
    implements FrontEndAction
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndActionLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndActionLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndAction if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndAction";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndAction
     */
    public boolean isFrontEndActionMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndAction#isUseCaseStart()
    * @return boolean
    */
    protected abstract boolean handleIsUseCaseStart();

    /**
     * Indicates if this action represents the beginning of the front-end use case or not.
     * @return (boolean)handleIsUseCaseStart()
     */
    public final boolean isUseCaseStart()
    {
        boolean useCaseStart1a = false;
        // useCaseStart has no pre constraints
        useCaseStart1a = handleIsUseCaseStart();
        // useCaseStart has no post constraints
        return useCaseStart1a;
    }

   /**
    * @see FrontEndAction#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * The default resource message key for this action.
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey2a = null;
        // messageKey has no pre constraints
        messageKey2a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey2a;
    }

   /**
    * @see FrontEndAction#getTriggerName()
    * @return String
    */
    protected abstract String handleGetTriggerName();

    /**
     * The name of the trigger that triggers that action.
     * @return (String)handleGetTriggerName()
     */
    public final String getTriggerName()
    {
        String triggerName3a = null;
        // triggerName has no pre constraints
        triggerName3a = handleGetTriggerName();
        // triggerName has no post constraints
        return triggerName3a;
    }

   /**
    * @see FrontEndAction#isResettable()
    * @return boolean
    */
    protected abstract boolean handleIsResettable();

    /**
     * Indicates whether or not the values passed along with this action can be reset or not.
     * @return (boolean)handleIsResettable()
     */
    public final boolean isResettable()
    {
        boolean resettable4a = false;
        // resettable has no pre constraints
        resettable4a = handleIsResettable();
        // resettable has no post constraints
        return resettable4a;
    }

   /**
    * @see FrontEndAction#isTableLink()
    * @return boolean
    */
    protected abstract boolean handleIsTableLink();

    /**
     * Indicates if a table link name has been specified and it properly targets a table
     * page-variable from the input page.
     * @return (boolean)handleIsTableLink()
     */
    public final boolean isTableLink()
    {
        boolean tableLink5a = false;
        // tableLink has no pre constraints
        tableLink5a = handleIsTableLink();
        // tableLink has no post constraints
        return tableLink5a;
    }

   /**
    * @see FrontEndAction#getViewFragmentPath()
    * @return String
    */
    protected abstract String handleGetViewFragmentPath();

    /**
     * The path to the view fragment corresponding to this action
     * @return (String)handleGetViewFragmentPath()
     */
    public final String getViewFragmentPath()
    {
        String viewFragmentPath6a = null;
        // viewFragmentPath has no pre constraints
        viewFragmentPath6a = handleGetViewFragmentPath();
        // viewFragmentPath has no post constraints
        return viewFragmentPath6a;
    }

   /**
    * @see FrontEndAction#getHiddenParameters()
    * @return List<FrontEndParameter>
    */
    protected abstract List<FrontEndParameter> handleGetHiddenParameters();

    /**
     * All parameters that are of hidden input type.
     * @return (List<FrontEndParameter>)handleGetHiddenParameters()
     */
    public final List<FrontEndParameter> getHiddenParameters()
    {
        List<FrontEndParameter> hiddenParameters7a = null;
        // hiddenParameters has no pre constraints
        hiddenParameters7a = handleGetHiddenParameters();
        // hiddenParameters has no post constraints
        return hiddenParameters7a;
    }

   /**
    * @see FrontEndAction#isHyperlink()
    * @return boolean
    */
    protected abstract boolean handleIsHyperlink();

    /**
     * Indicates whether or not this action is represented by clicking on a hyperlink.
     * @return (boolean)handleIsHyperlink()
     */
    public final boolean isHyperlink()
    {
        boolean hyperlink8a = false;
        // hyperlink has no pre constraints
        hyperlink8a = handleIsHyperlink();
        // hyperlink has no post constraints
        return hyperlink8a;
    }

   /**
    * @see FrontEndAction#isTableAction()
    * @return boolean
    */
    protected abstract boolean handleIsTableAction();

    /**
     * Indicates that this action works on all rows of the table from the table link relation.
     * @return (boolean)handleIsTableAction()
     */
    public final boolean isTableAction()
    {
        boolean tableAction9a = false;
        // tableAction has no pre constraints
        tableAction9a = handleIsTableAction();
        // tableAction has no post constraints
        return tableAction9a;
    }

   /**
    * @see FrontEndAction#getFullyQualifiedActionClassName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedActionClassName();

    /**
     * The fully qualified name of the action class that execute this action.
     * @return (String)handleGetFullyQualifiedActionClassName()
     */
    public final String getFullyQualifiedActionClassName()
    {
        String fullyQualifiedActionClassName10a = null;
        // fullyQualifiedActionClassName has no pre constraints
        fullyQualifiedActionClassName10a = handleGetFullyQualifiedActionClassName();
        // fullyQualifiedActionClassName has no post constraints
        return fullyQualifiedActionClassName10a;
    }

   /**
    * @see FrontEndAction#getTriggerMethodName()
    * @return String
    */
    protected abstract String handleGetTriggerMethodName();

    /**
     * The name of the method to be executed when this action is triggered.
     * @return (String)handleGetTriggerMethodName()
     */
    public final String getTriggerMethodName()
    {
        String triggerMethodName11a = null;
        // triggerMethodName has no pre constraints
        triggerMethodName11a = handleGetTriggerMethodName();
        // triggerMethodName has no post constraints
        return triggerMethodName11a;
    }

   /**
    * @see FrontEndAction#isNeedsFileUpload()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsFileUpload();

    /**
     * TODO: Model Documentation for FrontEndAction.needsFileUpload
     * @return (boolean)handleIsNeedsFileUpload()
     */
    public final boolean isNeedsFileUpload()
    {
        boolean needsFileUpload12a = false;
        // needsFileUpload has no pre constraints
        needsFileUpload12a = handleIsNeedsFileUpload();
        // needsFileUpload has no post constraints
        return needsFileUpload12a;
    }

   /**
    * @see FrontEndAction#getTableLinkParameter()
    * @return FrontEndParameter
    */
    protected abstract FrontEndParameter handleGetTableLinkParameter();

    /**
     * If the action is a table link then this property represents the table to which is being
     * linked.
     * @return (FrontEndParameter)handleGetTableLinkParameter()
     */
    public final FrontEndParameter getTableLinkParameter()
    {
        FrontEndParameter tableLinkParameter13a = null;
        // tableLinkParameter has no pre constraints
        tableLinkParameter13a = handleGetTableLinkParameter();
        // tableLinkParameter has no post constraints
        return tableLinkParameter13a;
    }

   /**
    * @see FrontEndAction#isFormReset()
    * @return boolean
    */
    protected abstract boolean handleIsFormReset();

    /**
     * Whether or not the entire form should be reset (all action parameters on the form).
     * @return (boolean)handleIsFormReset()
     */
    public final boolean isFormReset()
    {
        boolean formReset14a = false;
        // formReset has no pre constraints
        formReset14a = handleIsFormReset();
        // formReset has no post constraints
        return formReset14a;
    }

   /**
    * @see FrontEndAction#getFormKey()
    * @return String
    */
    protected abstract String handleGetFormKey();

    /**
     * The key that stores the form in which information is passed from one action to another.
     * @return (String)handleGetFormKey()
     */
    public final String getFormKey()
    {
        String formKey15a = null;
        // formKey has no pre constraints
        formKey15a = handleGetFormKey();
        // formKey has no post constraints
        return formKey15a;
    }

   /**
    * @see FrontEndAction#getPathRoot()
    * @return String
    */
    protected abstract String handleGetPathRoot();

    /**
     * The path's root.
     * @return (String)handleGetPathRoot()
     */
    public final String getPathRoot()
    {
        String pathRoot16a = null;
        // pathRoot has no pre constraints
        pathRoot16a = handleGetPathRoot();
        // pathRoot has no post constraints
        return pathRoot16a;
    }

   /**
    * @see FrontEndAction#getTableLinkColumnName()
    * @return String
    */
    protected abstract String handleGetTableLinkColumnName();

    /**
     * The name of the column targetted by this action.
     * @return (String)handleGetTableLinkColumnName()
     */
    public final String getTableLinkColumnName()
    {
        String tableLinkColumnName17a = null;
        // tableLinkColumnName has no pre constraints
        tableLinkColumnName17a = handleGetTableLinkColumnName();
        // tableLinkColumnName has no post constraints
        return tableLinkColumnName17a;
    }

   /**
    * @see FrontEndAction#isPopup()
    * @return boolean
    */
    protected abstract boolean handleIsPopup();

    /**
     * Indicates if this action forwards to a popup. Only applied when the target is a final state
     * pointing to another use case.
     * @return (boolean)handleIsPopup()
     */
    public final boolean isPopup()
    {
        boolean popup18a = false;
        // popup has no pre constraints
        popup18a = handleIsPopup();
        // popup has no post constraints
        return popup18a;
    }

   /**
    * @see FrontEndAction#isFormResetRequired()
    * @return boolean
    */
    protected abstract boolean handleIsFormResetRequired();

    /**
     * Indicates if at least one parameter on the form requires being reset.
     * @return (boolean)handleIsFormResetRequired()
     */
    public final boolean isFormResetRequired()
    {
        boolean formResetRequired19a = false;
        // formResetRequired has no pre constraints
        formResetRequired19a = handleIsFormResetRequired();
        // formResetRequired has no post constraints
        return formResetRequired19a;
    }

   /**
    * @see FrontEndAction#getTableLinkName()
    * @return String
    */
    protected abstract String handleGetTableLinkName();

    /**
     * The name of the table link specified for this action.
     * @return (String)handleGetTableLinkName()
     */
    public final String getTableLinkName()
    {
        String tableLinkName20a = null;
        // tableLinkName has no pre constraints
        tableLinkName20a = handleGetTableLinkName();
        // tableLinkName has no post constraints
        return tableLinkName20a;
    }

   /**
    * @see FrontEndAction#isDialog()
    * @return boolean
    */
    protected abstract boolean handleIsDialog();

    /**
     * Indicates if this action forwards to a dialog (use case runs in different conversation
     * scope). Only applied when the target is a final state pointing to another use case.
     * @return (boolean)handleIsDialog()
     */
    public final boolean isDialog()
    {
        boolean dialog21a = false;
        // dialog has no pre constraints
        dialog21a = handleIsDialog();
        // dialog has no post constraints
        return dialog21a;
    }

   /**
    * @see FrontEndAction#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not at least one parameter on this action requires validation.
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired22a = false;
        // validationRequired has no pre constraints
        validationRequired22a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired22a;
    }

   /**
    * @see FrontEndAction#getFullyQualifiedActionClassPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedActionClassPath();

    /**
     * The fully qualified path to the action class that execute this action.
     * @return (String)handleGetFullyQualifiedActionClassPath()
     */
    public final String getFullyQualifiedActionClassPath()
    {
        String fullyQualifiedActionClassPath23a = null;
        // fullyQualifiedActionClassPath has no pre constraints
        fullyQualifiedActionClassPath23a = handleGetFullyQualifiedActionClassPath();
        // fullyQualifiedActionClassPath has no post constraints
        return fullyQualifiedActionClassPath23a;
    }

   /**
    * @see FrontEndAction#getControllerAction()
    * @return String
    */
    protected abstract String handleGetControllerAction();

    /**
     * The name of the action on the controller that executions this action.
     * @return (String)handleGetControllerAction()
     */
    public final String getControllerAction()
    {
        String controllerAction24a = null;
        // controllerAction has no pre constraints
        controllerAction24a = handleGetControllerAction();
        // controllerAction has no post constraints
        return controllerAction24a;
    }

   /**
    * @see FrontEndAction#getActionClassName()
    * @return String
    */
    protected abstract String handleGetActionClassName();

    /**
     * The name of the action class that executes this action.
     * @return (String)handleGetActionClassName()
     */
    public final String getActionClassName()
    {
        String actionClassName25a = null;
        // actionClassName has no pre constraints
        actionClassName25a = handleGetActionClassName();
        // actionClassName has no post constraints
        return actionClassName25a;
    }

   /**
    * @see FrontEndAction#getDocumentationValue()
    * @return String
    */
    protected abstract String handleGetDocumentationValue();

    /**
     * The resource messsage value suited for the action''s documentation.
     * @return (String)handleGetDocumentationValue()
     */
    public final String getDocumentationValue()
    {
        String documentationValue26a = null;
        // documentationValue has no pre constraints
        documentationValue26a = handleGetDocumentationValue();
        // documentationValue has no post constraints
        return documentationValue26a;
    }

   /**
    * @see FrontEndAction#getDocumentationKey()
    * @return String
    */
    protected abstract String handleGetDocumentationKey();

    /**
     * A resource message key suited for the action''s documentation.
     * @return (String)handleGetDocumentationKey()
     */
    public final String getDocumentationKey()
    {
        String documentationKey27a = null;
        // documentationKey has no pre constraints
        documentationKey27a = handleGetDocumentationKey();
        // documentationKey has no post constraints
        return documentationKey27a;
    }

   /**
    * @see FrontEndAction#getFormImplementationName()
    * @return String
    */
    protected abstract String handleGetFormImplementationName();

    /**
     * The name of the form implementation.
     * @return (String)handleGetFormImplementationName()
     */
    public final String getFormImplementationName()
    {
        String formImplementationName28a = null;
        // formImplementationName has no pre constraints
        formImplementationName28a = handleGetFormImplementationName();
        // formImplementationName has no post constraints
        return formImplementationName28a;
    }

   /**
    * @see FrontEndAction#getFormBeanName()
    * @return String
    */
    protected abstract String handleGetFormBeanName();

    /**
     * The name of the bean under which the form is stored.
     * @return (String)handleGetFormBeanName()
     */
    public final String getFormBeanName()
    {
        String formBeanName29a = null;
        // formBeanName has no pre constraints
        formBeanName29a = handleGetFormBeanName();
        // formBeanName has no post constraints
        return formBeanName29a;
    }

   /**
    * @see FrontEndAction#getFullyQualifiedFormImplementationName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedFormImplementationName();

    /**
     * The fully qualified name of the form implementation.
     * @return (String)handleGetFullyQualifiedFormImplementationName()
     */
    public final String getFullyQualifiedFormImplementationName()
    {
        String fullyQualifiedFormImplementationName30a = null;
        // fullyQualifiedFormImplementationName has no pre constraints
        fullyQualifiedFormImplementationName30a = handleGetFullyQualifiedFormImplementationName();
        // fullyQualifiedFormImplementationName has no post constraints
        return fullyQualifiedFormImplementationName30a;
    }

   /**
    * @see FrontEndAction#getFullyQualifiedFormImplementationPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedFormImplementationPath();

    /**
     * The fully qualified path of the form implementation.
     * @return (String)handleGetFullyQualifiedFormImplementationPath()
     */
    public final String getFullyQualifiedFormImplementationPath()
    {
        String fullyQualifiedFormImplementationPath31a = null;
        // fullyQualifiedFormImplementationPath has no pre constraints
        fullyQualifiedFormImplementationPath31a = handleGetFullyQualifiedFormImplementationPath();
        // fullyQualifiedFormImplementationPath has no post constraints
        return fullyQualifiedFormImplementationPath31a;
    }

   /**
    * @see FrontEndAction#getFormScope()
    * @return String
    */
    protected abstract String handleGetFormScope();

    /**
     * The scope of the JSF form (request, session,application,etc).
     * @return (String)handleGetFormScope()
     */
    public final String getFormScope()
    {
        String formScope32a = null;
        // formScope has no pre constraints
        formScope32a = handleGetFormScope();
        // formScope has no post constraints
        return formScope32a;
    }

   /**
    * @see FrontEndAction#getRestPath()
    * @return String
    */
    protected abstract String handleGetRestPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetRestPath()
     */
    public final String getRestPath()
    {
        String restPath33a = null;
        // restPath has no pre constraints
        restPath33a = handleGetRestPath();
        // restPath has no post constraints
        return restPath33a;
    }

   /**
    * @see FrontEndAction#getAllowedRoles()
    * @return Collection
    */
    protected abstract Collection handleGetAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (Collection)handleGetAllowedRoles()
     */
    public final Collection getAllowedRoles()
    {
        Collection allowedRoles34a = null;
        // allowedRoles has no pre constraints
        allowedRoles34a = handleGetAllowedRoles();
        // allowedRoles has no post constraints
        return allowedRoles34a;
    }

   /**
    * @see FrontEndAction#getFrontEndClasses()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetFrontEndClasses();

    /**
     * TODO: Model Documentation for FrontEndAction.frontEndClasses
     * @return (Set<String>)handleGetFrontEndClasses()
     */
    public final Set<String> getFrontEndClasses()
    {
        Set<String> frontEndClasses35a = null;
        // frontEndClasses has no pre constraints
        frontEndClasses35a = handleGetFrontEndClasses();
        // frontEndClasses has no post constraints
        return frontEndClasses35a;
    }

   /**
    * @see FrontEndAction#getEnctype()
    * @return String
    */
    protected abstract String handleGetEnctype();

    /**
     * TODO: Model Documentation for FrontEndAction.enctype
     * @return (String)handleGetEnctype()
     */
    public final String getEnctype()
    {
        String enctype36a = null;
        // enctype has no pre constraints
        enctype36a = handleGetEnctype();
        // enctype has no post constraints
        return enctype36a;
    }

   /**
    * @see FrontEndAction#getIcon()
    * @return String
    */
    protected abstract String handleGetIcon();

    /**
     * TODO: Model Documentation for FrontEndAction.icon
     * @return (String)handleGetIcon()
     */
    public final String getIcon()
    {
        String icon37a = null;
        // icon has no pre constraints
        icon37a = handleGetIcon();
        // icon has no post constraints
        return icon37a;
    }

   /**
    * @see FrontEndAction#getDisplayCondition()
    * @return String
    */
    protected abstract String handleGetDisplayCondition();

    /**
     * TODO: Model Documentation for FrontEndAction.displayCondition
     * @return (String)handleGetDisplayCondition()
     */
    public final String getDisplayCondition()
    {
        String displayCondition38a = null;
        // displayCondition has no pre constraints
        displayCondition38a = handleGetDisplayCondition();
        // displayCondition has no post constraints
        return displayCondition38a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Finds the parameter on this action having the given name, if no parameter is found, null is
     * returned instead.
     * @param name
     * @return ParameterFacade
     */
    protected abstract ParameterFacade handleFindParameter(String name);

    /**
     * Finds the parameter on this action having the given name, if no parameter is found, null is
     * returned instead.
     * @param name String
     * The name of the parameter to find on the owner action.
     * @return handleFindParameter(name)
     */
    public ParameterFacade findParameter(String name)
    {
        // findParameter has no pre constraints
        ParameterFacade returnValue = handleFindParameter(name);
        // findParameter has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    private List<FrontEndForward> __getDecisionTransitions1r;
    private boolean __getDecisionTransitions1rSet = false;

    /**
     * Represents a "front-end" action. An action is some action that is taken when a front-end even
     * occurs.
     * @return (List<FrontEndForward>)handleGetDecisionTransitions()
     */
    public final List<FrontEndForward> getDecisionTransitions()
    {
        List<FrontEndForward> getDecisionTransitions1r = this.__getDecisionTransitions1r;
        if (!this.__getDecisionTransitions1rSet)
        {
            // frontEndAction has no pre constraints
             List result = handleGetDecisionTransitions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getDecisionTransitions1r = (List<FrontEndForward>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getDecisionTransitions List<FrontEndForward> " + result + ": " + shieldedResult);
            }
            // frontEndAction has no post constraints
            this.__getDecisionTransitions1r = getDecisionTransitions1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDecisionTransitions1rSet = true;
            }
        }
        return getDecisionTransitions1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetDecisionTransitions();

    private List<FrontEndForward> __getActionForwards2r;
    private boolean __getActionForwards2rSet = false;

    /**
     * Represents a "front-end" action. An action is some action that is taken when a front-end even
     * occurs.
     * @return (List<FrontEndForward>)handleGetActionForwards()
     */
    public final List<FrontEndForward> getActionForwards()
    {
        List<FrontEndForward> getActionForwards2r = this.__getActionForwards2r;
        if (!this.__getActionForwards2rSet)
        {
            // frontEndAction has no pre constraints
             List result = handleGetActionForwards();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getActionForwards2r = (List<FrontEndForward>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getActionForwards List<FrontEndForward> " + result + ": " + shieldedResult);
            }
            // frontEndAction has no post constraints
            this.__getActionForwards2r = getActionForwards2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActionForwards2rSet = true;
            }
        }
        return getActionForwards2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetActionForwards();

    /**
     * Represents a "front-end" action. An action is some action that is taken when a front-end even
     * occurs.
     * @return (StateVertexFacade)handleGetInput()
     */
    public final StateVertexFacade getInput()
    {
        StateVertexFacade getInput3r = null;
        // frontEndAction has no pre constraints
        Object result = handleGetInput();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getInput3r = (StateVertexFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getInput StateVertexFacade " + result + ": " + shieldedResult);
        }
        // frontEndAction has no post constraints
        return getInput3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInput();

    private List<FrontEndForward> __getTransitions4r;
    private boolean __getTransitions4rSet = false;

    /**
     * The front-end actions directly containing this front-end forward.
     * @return (List<FrontEndForward>)handleGetTransitions()
     */
    public final List<FrontEndForward> getTransitions()
    {
        List<FrontEndForward> getTransitions4r = this.__getTransitions4r;
        if (!this.__getTransitions4rSet)
        {
            // actions has no pre constraints
             List result = handleGetTransitions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getTransitions4r = (List<FrontEndForward>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getTransitions List<FrontEndForward> " + result + ": " + shieldedResult);
            }
            // actions has no post constraints
            this.__getTransitions4r = getTransitions4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTransitions4rSet = true;
            }
        }
        return getTransitions4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetTransitions();

    private FrontEndController __getController5r;
    private boolean __getController5rSet = false;

    /**
     * All actions that defer to at least one operation of this controller.
     * @return (FrontEndController)handleGetController()
     */
    public final FrontEndController getController()
    {
        FrontEndController getController5r = this.__getController5r;
        if (!this.__getController5rSet)
        {
            // deferringActions has no pre constraints
            Object result = handleGetController();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getController5r = (FrontEndController)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getController FrontEndController " + result + ": " + shieldedResult);
            }
            // deferringActions has no post constraints
            this.__getController5r = getController5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController5rSet = true;
            }
        }
        return getController5r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetController();

    private List<FrontEndParameter> __getParameters6r;
    private boolean __getParameters6rSet = false;

    /**
     * The action to which this parameter belongs (if it belongs to an action), otherwise it returns
     * null.
     * @return (List<FrontEndParameter>)handleGetParameters()
     */
    public final List<FrontEndParameter> getParameters()
    {
        List<FrontEndParameter> getParameters6r = this.__getParameters6r;
        if (!this.__getParameters6rSet)
        {
            // action has no pre constraints
             List result = handleGetParameters();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getParameters6r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getParameters List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // action has no post constraints
            this.__getParameters6r = getParameters6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getParameters6rSet = true;
            }
        }
        return getParameters6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetParameters();

    private List<FrontEndActionState> __getActionStates7r;
    private boolean __getActionStates7rSet = false;

    /**
     * The actions that pass through this action state.
     * @return (List<FrontEndActionState>)handleGetActionStates()
     */
    public final List<FrontEndActionState> getActionStates()
    {
        List<FrontEndActionState> getActionStates7r = this.__getActionStates7r;
        if (!this.__getActionStates7rSet)
        {
            // containerActions has no pre constraints
             List result = handleGetActionStates();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getActionStates7r = (List<FrontEndActionState>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getActionStates List<FrontEndActionState> " + result + ": " + shieldedResult);
            }
            // containerActions has no post constraints
            this.__getActionStates7r = getActionStates7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActionStates7rSet = true;
            }
        }
        return getActionStates7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetActionStates();

    private List<FrontEndParameter> __getFormFields8r;
    private boolean __getFormFields8rSet = false;

    /**
     * Represents a "front-end" action. An action is some action that is taken when a front-end even
     * occurs.
     * @return (List<FrontEndParameter>)handleGetFormFields()
     */
    public final List<FrontEndParameter> getFormFields()
    {
        List<FrontEndParameter> getFormFields8r = this.__getFormFields8r;
        if (!this.__getFormFields8rSet)
        {
            // frontEndAction has no pre constraints
             List result = handleGetFormFields();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getFormFields8r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getFormFields List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndAction has no post constraints
            this.__getFormFields8r = getFormFields8r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFormFields8rSet = true;
            }
        }
        return getFormFields8r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetFormFields();

    private List<FrontEndView> __getTargetViews9r;
    private boolean __getTargetViews9rSet = false;

    /**
     * Represents a "front-end" action. An action is some action that is taken when a front-end even
     * occurs.
     * @return (List<FrontEndView>)handleGetTargetViews()
     */
    public final List<FrontEndView> getTargetViews()
    {
        List<FrontEndView> getTargetViews9r = this.__getTargetViews9r;
        if (!this.__getTargetViews9rSet)
        {
            // frontEndAction has no pre constraints
             List result = handleGetTargetViews();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getTargetViews9r = (List<FrontEndView>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getTargetViews List<FrontEndView> " + result + ": " + shieldedResult);
            }
            // frontEndAction has no post constraints
            this.__getTargetViews9r = getTargetViews9r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTargetViews9rSet = true;
            }
        }
        return getTargetViews9r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetTargetViews();

    private Collection<FrontEndControllerOperation> __getDeferredOperations10r;
    private boolean __getDeferredOperations10rSet = false;

    /**
     * All those actions that contain at least one front-end action state that is deferring to this
     * operation.
     * @return (Collection<FrontEndControllerOperation>)handleGetDeferredOperations()
     */
    public final Collection<FrontEndControllerOperation> getDeferredOperations()
    {
        Collection<FrontEndControllerOperation> getDeferredOperations10r = this.__getDeferredOperations10r;
        if (!this.__getDeferredOperations10rSet)
        {
            // deferringActions has no pre constraints
             Collection result = handleGetDeferredOperations();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getDeferredOperations10r = (Collection<FrontEndControllerOperation>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionLogic.logger.warn("incorrect metafacade cast for FrontEndActionLogic.getDeferredOperations Collection<FrontEndControllerOperation> " + result + ": " + shieldedResult);
            }
            // deferringActions has no post constraints
            this.__getDeferredOperations10r = getDeferredOperations10r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferredOperations10rSet = true;
            }
        }
        return getDeferredOperations10r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetDeferredOperations();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndAction::parameters must be unique</p>
     * <p><b>Error:</b> Each front-end action parameter must have a unique name.</p>
     * <p><b>OCL:</b> context FrontEndAction
inv : parameters -> isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndAction::each action must carry a trigger</p>
     * <p><b>Error:</b> Each action transition coming out of a view must have a trigger (the name is sufficient), it is
recommended to add a trigger of type 'signal'.</p>
     * <p><b>OCL:</b> context FrontEndAction inv: exitingView implies triggerPresent</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see FrontEndForwardLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"parameters"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndAction::parameters must be unique",
                        "Each front-end action parameter must have a unique name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndAction::parameters must be unique' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"exitingView"))).booleanValue())).booleanValue()?Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"triggerPresent"))).booleanValue():true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndAction::each action must carry a trigger",
                        "Each action transition coming out of a view must have a trigger (the name is sufficient), it is\nrecommended to add a trigger of type 'signal'."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndAction::each action must carry a trigger' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}