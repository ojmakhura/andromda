// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ManageableEntityAttribute;

/**
 * TODO: Model Documentation for ManageableEntityAttribute
 * MetafacadeLogic for ManageableEntityAttribute
 *
 * @see ManageableEntityAttribute
 */
public abstract class ManageableEntityAttributeLogic
    extends EntityAttributeLogicImpl
    implements ManageableEntityAttribute
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ManageableEntityAttributeLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ManageableEntityAttribute if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAttribute";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ManageableEntityAttribute
     */
    public boolean isManageableEntityAttributeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ManageableEntityAttribute#isDisplay()
    * @return boolean
    */
    protected abstract boolean handleIsDisplay();

    /**
     * Whether or not this attribute should be displayed.
     * @return (boolean)handleIsDisplay()
     */
    public final boolean isDisplay()
    {
        boolean display1a = false;
        // display has no pre constraints
        display1a = handleIsDisplay();
        // display has no post constraints
        return display1a;
    }

   /**
    * @see ManageableEntityAttribute#isManageableGetterAvailable()
    * @return boolean
    */
    protected abstract boolean handleIsManageableGetterAvailable();

    /**
     * Whether or not this attribute can be read in a call isolated from the rest (for example when
     * downloading binary fields).
     * @return (boolean)handleIsManageableGetterAvailable()
     */
    public final boolean isManageableGetterAvailable()
    {
        boolean manageableGetterAvailable2a = false;
        // manageableGetterAvailable has no pre constraints
        manageableGetterAvailable2a = handleIsManageableGetterAvailable();
        // manageableGetterAvailable has no post constraints
        return manageableGetterAvailable2a;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see EntityAttributeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}