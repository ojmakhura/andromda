// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActivityGraph;
import org.andromda.metafacades.uml.FrontEndController;
import org.andromda.metafacades.uml.FrontEndFinalState;
import org.andromda.metafacades.uml.FrontEndForward;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndUseCase;
import org.andromda.metafacades.uml.FrontEndView;
import org.andromda.metafacades.uml.Role;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Predicate;
import org.apache.commons.collections.Transformer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.UseCase;

/**
 * Represents a use case used in the "front end" of an application.
 * MetafacadeLogic for FrontEndUseCase
 *
 * @see FrontEndUseCase
 */
public abstract class FrontEndUseCaseLogic
    extends UseCaseFacadeLogicImpl
    implements FrontEndUseCase
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndUseCaseLogic(Object metaObjectIn, String context)
    {
        super((UseCase)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndUseCaseLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndUseCase if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndUseCase";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndUseCase
     */
    public boolean isFrontEndUseCaseMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndUseCase#isEntryUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsEntryUseCase();

    /**
     * True if this use-case is the entry point to the front end.
     * @return (boolean)handleIsEntryUseCase()
     */
    public final boolean isEntryUseCase()
    {
        boolean entryUseCase1a = false;
        // entryUseCase has no pre constraints
        entryUseCase1a = handleIsEntryUseCase();
        // entryUseCase has no post constraints
        return entryUseCase1a;
    }

   /**
    * @see FrontEndUseCase#isSecured()
    * @return boolean
    */
    protected abstract boolean handleIsSecured();

    /**
     * Indicates if this use case is "secured".  This is true when there is at least one role
     * associated to it.
     * @return (boolean)handleIsSecured()
     */
    public final boolean isSecured()
    {
        boolean secured2a = false;
        // secured has no pre constraints
        secured2a = handleIsSecured();
        // secured has no post constraints
        return secured2a;
    }

   /**
    * @see FrontEndUseCase#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * The path to which this use case points.
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path3a = null;
        // path has no pre constraints
        path3a = handleGetPath();
        // path has no post constraints
        return path3a;
    }

   /**
    * @see FrontEndUseCase#getPathRoot()
    * @return String
    */
    protected abstract String handleGetPathRoot();

    /**
     * The root path for this use case (this is the path the directory containing the use case's
     * resources).
     * @return (String)handleGetPathRoot()
     */
    public final String getPathRoot()
    {
        String pathRoot4a = null;
        // pathRoot has no pre constraints
        pathRoot4a = handleGetPathRoot();
        // pathRoot has no post constraints
        return pathRoot4a;
    }

   /**
    * @see FrontEndUseCase#getForwardName()
    * @return String
    */
    protected abstract String handleGetForwardName();

    /**
     * The name that will cause a forward to use case.
     * @return (String)handleGetForwardName()
     */
    public final String getForwardName()
    {
        String forwardName5a = null;
        // forwardName has no pre constraints
        forwardName5a = handleGetForwardName();
        // forwardName has no post constraints
        return forwardName5a;
    }

   /**
    * @see FrontEndUseCase#getAllMessages()
    * @return Map
    */
    protected abstract Map handleGetAllMessages();

    /**
     * A map with keys sorted alphabetically, normalized across all different use-cases, views, etc.
     * @return (Map)handleGetAllMessages()
     */
    public final Map getAllMessages()
    {
        Map allMessages6a = null;
        // allMessages has no pre constraints
        allMessages6a = handleGetAllMessages();
        // allMessages has no post constraints
        return allMessages6a;
    }

   /**
    * @see FrontEndUseCase#getTitleKey()
    * @return String
    */
    protected abstract String handleGetTitleKey();

    /**
     * The title message key for this use-case.
     * @return (String)handleGetTitleKey()
     */
    public final String getTitleKey()
    {
        String titleKey7a = null;
        // titleKey has no pre constraints
        titleKey7a = handleGetTitleKey();
        // titleKey has no post constraints
        return titleKey7a;
    }

   /**
    * @see FrontEndUseCase#getTitleValue()
    * @return String
    */
    protected abstract String handleGetTitleValue();

    /**
     * The title message value for this use-case.
     * @return (String)handleGetTitleValue()
     */
    public final String getTitleValue()
    {
        String titleValue8a = null;
        // titleValue has no pre constraints
        titleValue8a = handleGetTitleValue();
        // titleValue has no post constraints
        return titleValue8a;
    }

   /**
    * @see FrontEndUseCase#getActionClassName()
    * @return String
    */
    protected abstract String handleGetActionClassName();

    /**
     * The name of the action class that forwards to this use case.
     * @return (String)handleGetActionClassName()
     */
    public final String getActionClassName()
    {
        String actionClassName9a = null;
        // actionClassName has no pre constraints
        actionClassName9a = handleGetActionClassName();
        // actionClassName has no post constraints
        return actionClassName9a;
    }

   /**
    * @see FrontEndUseCase#getFullyQualifiedActionClassPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedActionClassPath();

    /**
     * The fully qualified path to the action class that forwards to this use case.
     * @return (String)handleGetFullyQualifiedActionClassPath()
     */
    public final String getFullyQualifiedActionClassPath()
    {
        String fullyQualifiedActionClassPath10a = null;
        // fullyQualifiedActionClassPath has no pre constraints
        fullyQualifiedActionClassPath10a = handleGetFullyQualifiedActionClassPath();
        // fullyQualifiedActionClassPath has no post constraints
        return fullyQualifiedActionClassPath10a;
    }

   /**
    * @see FrontEndUseCase#getControllerAction()
    * @return String
    */
    protected abstract String handleGetControllerAction();

    /**
     * The name of the action on the controller that executions this use case.
     * @return (String)handleGetControllerAction()
     */
    public final String getControllerAction()
    {
        String controllerAction11a = null;
        // controllerAction has no pre constraints
        controllerAction11a = handleGetControllerAction();
        // controllerAction has no post constraints
        return controllerAction11a;
    }

   /**
    * @see FrontEndUseCase#getFullyQualifiedActionClassName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedActionClassName();

    /**
     * The fully qualified name of the action class that forwards to this use case.
     * @return (String)handleGetFullyQualifiedActionClassName()
     */
    public final String getFullyQualifiedActionClassName()
    {
        String fullyQualifiedActionClassName12a = null;
        // fullyQualifiedActionClassName has no pre constraints
        fullyQualifiedActionClassName12a = handleGetFullyQualifiedActionClassName();
        // fullyQualifiedActionClassName has no post constraints
        return fullyQualifiedActionClassName12a;
    }

   /**
    * @see FrontEndUseCase#getFormKey()
    * @return String
    */
    protected abstract String handleGetFormKey();

    /**
     * The key under which to store the action form passed along in this in this use-case.
     * @return (String)handleGetFormKey()
     */
    public final String getFormKey()
    {
        String formKey13a = null;
        // formKey has no pre constraints
        formKey13a = handleGetFormKey();
        // formKey has no post constraints
        return formKey13a;
    }

   /**
    * @see FrontEndUseCase#getInitialTargetPath()
    * @return String
    */
    protected abstract String handleGetInitialTargetPath();

    /**
     * The path of the initial target going into this use case.
     * @return (String)handleGetInitialTargetPath()
     */
    public final String getInitialTargetPath()
    {
        String initialTargetPath14a = null;
        // initialTargetPath has no pre constraints
        initialTargetPath14a = handleGetInitialTargetPath();
        // initialTargetPath has no post constraints
        return initialTargetPath14a;
    }

   /**
    * @see FrontEndUseCase#isInitialTargetView()
    * @return boolean
    */
    protected abstract boolean handleIsInitialTargetView();

    /**
     * Indicates whether or not the initial target of this use case is a view or not.
     * @return (boolean)handleIsInitialTargetView()
     */
    public final boolean isInitialTargetView()
    {
        boolean initialTargetView15a = false;
        // initialTargetView has no pre constraints
        initialTargetView15a = handleIsInitialTargetView();
        // initialTargetView has no post constraints
        return initialTargetView15a;
    }

   /**
    * @see FrontEndUseCase#isApplicationValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsApplicationValidationRequired();

    /**
     * Indicates that at least one client/server parameter found in the collection of existing
     * use-cases requires validation.
     * @return (boolean)handleIsApplicationValidationRequired()
     */
    public final boolean isApplicationValidationRequired()
    {
        boolean applicationValidationRequired16a = false;
        // applicationValidationRequired has no pre constraints
        applicationValidationRequired16a = handleIsApplicationValidationRequired();
        // applicationValidationRequired has no post constraints
        return applicationValidationRequired16a;
    }

   /**
    * @see FrontEndUseCase#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not at least one parameter in this use-case require validation.
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired17a = false;
        // validationRequired has no pre constraints
        validationRequired17a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired17a;
    }

   /**
    * @see FrontEndUseCase#isViewHasNameOfUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsViewHasNameOfUseCase();

    /**
     * Indicates whether or not at least one view in the use case has the same name as this use
     * case.
     * @return (boolean)handleIsViewHasNameOfUseCase()
     */
    public final boolean isViewHasNameOfUseCase()
    {
        boolean viewHasNameOfUseCase18a = false;
        // viewHasNameOfUseCase has no pre constraints
        viewHasNameOfUseCase18a = handleIsViewHasNameOfUseCase();
        // viewHasNameOfUseCase has no post constraints
        return viewHasNameOfUseCase18a;
    }

   /**
    * @see FrontEndUseCase#isRegistrationUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsRegistrationUseCase();

    /**
     * Indicates whether or not this is a front-end registration use case.  Only one use case can be
     * labeled as a 'registration' use case.
     * @return (boolean)handleIsRegistrationUseCase()
     */
    public final boolean isRegistrationUseCase()
    {
        boolean registrationUseCase19a = false;
        // registrationUseCase has no pre constraints
        registrationUseCase19a = handleIsRegistrationUseCase();
        // registrationUseCase has no post constraints
        return registrationUseCase19a;
    }

   /**
    * @see FrontEndUseCase#getForwardsClassName()
    * @return String
    */
    protected abstract String handleGetForwardsClassName();

    /**
     * The name of the class that stores all the forwards paths.
     * @return (String)handleGetForwardsClassName()
     */
    public final String getForwardsClassName()
    {
        String forwardsClassName20a = null;
        // forwardsClassName has no pre constraints
        forwardsClassName20a = handleGetForwardsClassName();
        // forwardsClassName has no post constraints
        return forwardsClassName20a;
    }

   /**
    * @see FrontEndUseCase#getAllForwards()
    * @return List
    */
    protected abstract List handleGetAllForwards();

    /**
     * Constains all forwards includes regular FrontEndForwards and all actiion forwards.
     * @return (List)handleGetAllForwards()
     */
    public final List getAllForwards()
    {
        List allForwards21a = null;
        // allForwards has no pre constraints
        allForwards21a = handleGetAllForwards();
        // allForwards has no post constraints
        return allForwards21a;
    }

   /**
    * @see FrontEndUseCase#getForwards()
    * @return List<FrontEndForward>
    */
    protected abstract List<FrontEndForward> handleGetForwards();

    /**
     * All forwards contained in this use case.
     * @return (List<FrontEndForward>)handleGetForwards()
     */
    public final List<FrontEndForward> getForwards()
    {
        List<FrontEndForward> forwards22a = null;
        // forwards has no pre constraints
        forwards22a = handleGetForwards();
        // forwards has no post constraints
        return forwards22a;
    }

   /**
    * @see FrontEndUseCase#getActionForwards()
    * @return List<FrontEndAction>
    */
    protected abstract List<FrontEndAction> handleGetActionForwards();

    /**
     * All forwards in this use case that are represented as actions.
     * @return (List<FrontEndAction>)handleGetActionForwards()
     */
    public final List<FrontEndAction> getActionForwards()
    {
        List<FrontEndAction> actionForwards23a = null;
        // actionForwards has no pre constraints
        actionForwards23a = handleGetActionForwards();
        // actionForwards has no post constraints
        return actionForwards23a;
    }

   /**
    * @see FrontEndUseCase#getAllViews()
    * @return Collection<FrontEndView>
    */
    protected abstract Collection<FrontEndView> handleGetAllViews();

    /**
     * All views for the application (not just the ones belonging to this use case).
     * @return (Collection<FrontEndView>)handleGetAllViews()
     */
    public final Collection<FrontEndView> getAllViews()
    {
        Collection<FrontEndView> allViews24a = null;
        // allViews has no pre constraints
        allViews24a = handleGetAllViews();
        // allViews has no post constraints
        return allViews24a;
    }

   /**
    * @see FrontEndUseCase#getRegistrationUseCases()
    * @return List<FrontEndUseCase>
    */
    protected abstract List<FrontEndUseCase> handleGetRegistrationUseCases();

    /**
     * All use cases that are labled as registration use cases.
     * @return (List<FrontEndUseCase>)handleGetRegistrationUseCases()
     */
    public final List<FrontEndUseCase> getRegistrationUseCases()
    {
        List<FrontEndUseCase> registrationUseCases25a = null;
        // registrationUseCases has no pre constraints
        registrationUseCases25a = handleGetRegistrationUseCases();
        // registrationUseCases has no post constraints
        return registrationUseCases25a;
    }

   /**
    * @see FrontEndUseCase#getRestPath()
    * @return String
    */
    protected abstract String handleGetRestPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetRestPath()
     */
    public final String getRestPath()
    {
        String restPath26a = null;
        // restPath has no pre constraints
        restPath26a = handleGetRestPath();
        // restPath has no post constraints
        return restPath26a;
    }

   /**
    * @see FrontEndUseCase#getFilename()
    * @return String
    */
    protected abstract String handleGetFilename();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetFilename()
     */
    public final String getFilename()
    {
        String filename27a = null;
        // filename has no pre constraints
        filename27a = handleGetFilename();
        // filename has no post constraints
        return filename27a;
    }

   /**
    * @see FrontEndUseCase#getAllowedRoles()
    * @return Collection
    */
    protected abstract Collection handleGetAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (Collection)handleGetAllowedRoles()
     */
    public final Collection getAllowedRoles()
    {
        Collection allowedRoles28a = null;
        // allowedRoles has no pre constraints
        allowedRoles28a = handleGetAllowedRoles();
        // allowedRoles has no post constraints
        return allowedRoles28a;
    }

   /**
    * @see FrontEndUseCase#getSubstitutionName()
    * @return String
    */
    protected abstract String handleGetSubstitutionName();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetSubstitutionName()
     */
    public final String getSubstitutionName()
    {
        String substitutionName29a = null;
        // substitutionName has no pre constraints
        substitutionName29a = handleGetSubstitutionName();
        // substitutionName has no post constraints
        return substitutionName29a;
    }

   /**
    * @see FrontEndUseCase#getIcon()
    * @return String
    */
    protected abstract String handleGetIcon();

    /**
     * TODO: Model Documentation for FrontEndUseCase.icon
     * @return (String)handleGetIcon()
     */
    public final String getIcon()
    {
        String icon30a = null;
        // icon has no pre constraints
        icon30a = handleGetIcon();
        // icon has no post constraints
        return icon30a;
    }

   /**
    * @see FrontEndUseCase#getDisplayCondition()
    * @return String
    */
    protected abstract String handleGetDisplayCondition();

    /**
     * TODO: Model Documentation for FrontEndUseCase.displayCondition
     * @return (String)handleGetDisplayCondition()
     */
    public final String getDisplayCondition()
    {
        String displayCondition31a = null;
        // displayCondition has no pre constraints
        displayCondition31a = handleGetDisplayCondition();
        // displayCondition has no post constraints
        return displayCondition31a;
    }

    // ------------- associations ------------------

    private List<FrontEndFinalState> __getReferencingFinalStates1r;
    private boolean __getReferencingFinalStates1rSet = false;

    /**
     * The use case the final state is "targetting".
     * @return (List<FrontEndFinalState>)handleGetReferencingFinalStates()
     */
    public final List<FrontEndFinalState> getReferencingFinalStates()
    {
        List<FrontEndFinalState> getReferencingFinalStates1r = this.__getReferencingFinalStates1r;
        if (!this.__getReferencingFinalStates1rSet)
        {
            // targetUseCase has no pre constraints
            List result = handleGetReferencingFinalStates();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getReferencingFinalStates1r = (List<FrontEndFinalState>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getReferencingFinalStates List<FrontEndFinalState> " + result + ": " + shieldedResult);
            }
            // targetUseCase has no post constraints
            this.__getReferencingFinalStates1r = getReferencingFinalStates1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getReferencingFinalStates1rSet = true;
            }
        }
        return getReferencingFinalStates1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetReferencingFinalStates();

    private List<Role> __getAllRoles2r;
    private boolean __getAllRoles2rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (List<Role>)handleGetAllRoles()
     */
    public final List<Role> getAllRoles()
    {
        List<Role> getAllRoles2r = this.__getAllRoles2r;
        if (!this.__getAllRoles2rSet)
        {
            // frontEndUseCase has no pre constraints
            List result = handleGetAllRoles();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllRoles2r = (List<Role>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getAllRoles List<Role> " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getAllRoles2r = getAllRoles2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllRoles2rSet = true;
            }
        }
        return getAllRoles2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAllRoles();

    private List<Role> __getRoles3r;
    private boolean __getRoles3rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (List<Role>)handleGetRoles()
     */
    public final List<Role> getRoles()
    {
        List<Role> getRoles3r = this.__getRoles3r;
        if (!this.__getRoles3rSet)
        {
            // frontEndUseCase has no pre constraints
            List result = handleGetRoles();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getRoles3r = (List<Role>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getRoles List<Role> " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getRoles3r = getRoles3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getRoles3rSet = true;
            }
        }
        return getRoles3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetRoles();

    private FrontEndController __getController4r;
    private boolean __getController4rSet = false;

    /**
     * Returns the use-case "controlled" by this controller.
     * @return (FrontEndController)handleGetController()
     */
    public final FrontEndController getController()
    {
        FrontEndController getController4r = this.__getController4r;
        if (!this.__getController4rSet)
        {
            // useCase has no pre constraints
            Object result = handleGetController();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getController4r = (FrontEndController)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getController FrontEndController " + result + ": " + shieldedResult);
            }
            // useCase has no post constraints
            this.__getController4r = getController4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController4rSet = true;
            }
        }
        return getController4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetController();

    private List<FrontEndView> __getViews5r;
    private boolean __getViews5rSet = false;

    /**
     * The use-case of which this view is a member.
     * @return (List<FrontEndView>)handleGetViews()
     */
    public final List<FrontEndView> getViews()
    {
        List<FrontEndView> getViews5r = this.__getViews5r;
        if (!this.__getViews5rSet)
        {
            // useCase has no pre constraints
            List result = handleGetViews();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getViews5r = (List<FrontEndView>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getViews List<FrontEndView> " + result + ": " + shieldedResult);
            }
            // useCase has no post constraints
            this.__getViews5r = getViews5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getViews5rSet = true;
            }
        }
        return getViews5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetViews();

    private List<FrontEndAction> __getActions6r;
    private boolean __getActions6rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (List<FrontEndAction>)handleGetActions()
     */
    public final List<FrontEndAction> getActions()
    {
        List<FrontEndAction> getActions6r = this.__getActions6r;
        if (!this.__getActions6rSet)
        {
            // frontEndUseCase has no pre constraints
            List result = handleGetActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getActions6r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getActions6r = getActions6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions6rSet = true;
            }
        }
        return getActions6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetActions();

    private List<FrontEndUseCase> __getAllUseCases7r;
    private boolean __getAllUseCases7rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (List<FrontEndUseCase>)handleGetAllUseCases()
     */
    public final List<FrontEndUseCase> getAllUseCases()
    {
        List<FrontEndUseCase> getAllUseCases7r = this.__getAllUseCases7r;
        if (!this.__getAllUseCases7rSet)
        {
            // frontEndUseCase has no pre constraints
            List result = handleGetAllUseCases();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllUseCases7r = (List<FrontEndUseCase>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getAllUseCases List<FrontEndUseCase> " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getAllUseCases7r = getAllUseCases7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllUseCases7rSet = true;
            }
        }
        return getAllUseCases7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAllUseCases();

    private FrontEndView __getInitialView8r;
    private boolean __getInitialView8rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (FrontEndView)handleGetInitialView()
     */
    public final FrontEndView getInitialView()
    {
        FrontEndView getInitialView8r = this.__getInitialView8r;
        if (!this.__getInitialView8rSet)
        {
            // frontEndUseCase has no pre constraints
            Object result = handleGetInitialView();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInitialView8r = (FrontEndView)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getInitialView FrontEndView " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getInitialView8r = getInitialView8r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialView8rSet = true;
            }
        }
        return getInitialView8r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInitialView();

    private FrontEndActivityGraph __getActivityGraph9r;
    private boolean __getActivityGraph9rSet = false;

    /**
     * The use case to which this activity graph belongs.
     * @return (FrontEndActivityGraph)handleGetActivityGraph()
     */
    public final FrontEndActivityGraph getActivityGraph()
    {
        FrontEndActivityGraph getActivityGraph9r = this.__getActivityGraph9r;
        if (!this.__getActivityGraph9rSet)
        {
            // frontEndUseCase has no pre constraints
            Object result = handleGetActivityGraph();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getActivityGraph9r = (FrontEndActivityGraph)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getActivityGraph FrontEndActivityGraph " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getActivityGraph9r = getActivityGraph9r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActivityGraph9rSet = true;
            }
        }
        return getActivityGraph9r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetActivityGraph();

    private List<FrontEndParameter> __getViewVariables10r;
    private boolean __getViewVariables10rSet = false;

    /**
     * Represents a use case used in the "front end" of an application.
     * @return (List<FrontEndParameter>)handleGetViewVariables()
     */
    public final List<FrontEndParameter> getViewVariables()
    {
        List<FrontEndParameter> getViewVariables10r = this.__getViewVariables10r;
        if (!this.__getViewVariables10rSet)
        {
            // frontEndUseCase has no pre constraints
            List result = handleGetViewVariables();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getViewVariables10r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndUseCaseLogic.logger.warn("incorrect metafacade cast for FrontEndUseCaseLogic.getViewVariables List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndUseCase has no post constraints
            this.__getViewVariables10r = getViewVariables10r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getViewVariables10rSet = true;
            }
        }
        return getViewVariables10r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetViewVariables();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndUseCase::each usecase needs one and only one graph</p>
     * <p><b>Error:</b> Each use-case needs one and only one activity graph.</p>
     * <p><b>OCL:</b> context FrontEndUseCase inv: activityGraph->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndUseCase::one and only one usecase must be a FrontEndApplication</p>
     * <p><b>Error:</b> One and only one use-case must be marked as the application entry use-case. Currently this is done
by adding the FrontEndApplication stereotype to it.</p>
     * <p><b>OCL:</b> context FrontEndUseCase inv: allUseCases->one(entryUseCase = true)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndUseCase::non-empty unique usecase name</p>
     * <p><b>Error:</b> Each use-case must have a non-empty name that is unique among all use-cases.</p>
     * <p><b>OCL:</b> context FrontEndUseCase inv: name->notEmpty() and model.allUseCases->isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndUseCase::each front-end use-case needs to be in a package</p>
     * <p><b>Error:</b> Each front-end use-case is required to be modeled in a package, doing otherwise will result in
uncompileable code due to filename collisions.</p>
     * <p><b>OCL:</b> context FrontEndUseCase inv: packageName->notEmpty()</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see UseCaseFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"activityGraph")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndUseCase::each usecase needs one and only one graph",
                        "Each use-case needs one and only one activity graph."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndUseCase::each usecase needs one and only one graph' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.one(OCLIntrospector.invoke(contextElement,"allUseCases"),new Predicate(){public boolean evaluate(Object object){return Boolean.valueOf(String.valueOf(OCLExpressions.equal(OCLIntrospector.invoke(object,"entryUseCase"),true))).booleanValue();}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndUseCase::one and only one usecase must be a FrontEndApplication",
                        "One and only one use-case must be marked as the application entry use-case. Currently this is done\nby adding the FrontEndApplication stereotype to it."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndUseCase::one and only one usecase must be a FrontEndApplication' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name"))&&OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"model.allUseCases"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndUseCase::non-empty unique usecase name",
                        "Each use-case must have a non-empty name that is unique among all use-cases."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndUseCase::non-empty unique usecase name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"packageName")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndUseCase::each front-end use-case needs to be in a package",
                        "Each front-end use-case is required to be modeled in a package, doing otherwise will result in\nuncompileable code due to filename collisions."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndUseCase::each front-end use-case needs to be in a package' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}