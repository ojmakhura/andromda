// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AssociationEndFacade;
import org.andromda.metafacades.uml.InstanceFacade;
import org.andromda.metafacades.uml.LinkEndFacade;
import org.andromda.metafacades.uml.LinkFacade;
import org.apache.log4j.Logger;

/**
 * Can be an AttributeLinkImpl or LinkEndImpl. A representation of the model object 'Slot'. A slot
 * specifies that an entity modeled by an instance specification has a value or values for a
 * specific structural feature.
 * MetafacadeLogic for LinkEndFacade
 *
 * @see LinkEndFacade
 */
public abstract class LinkEndFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements LinkEndFacade
{
    /**
     * The underlying UML object
     * @see LinkEnd
     */
    protected LinkEnd metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected LinkEndFacadeLogic(LinkEnd metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(LinkEndFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to LinkEndFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.LinkEndFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see LinkEndFacade
     */
    public boolean isLinkEndFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private LinkFacade __getLink1r;
    private boolean __getLink1rSet = false;

    /**
     * The two links ends owned by this link.
     * @return (LinkFacade)handleGetLink()
     */
    public final LinkFacade getLink()
    {
        LinkFacade getLink1r = this.__getLink1r;
        if (!this.__getLink1rSet)
        {
            // linkEnds has no pre constraints
            Object result = handleGetLink();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getLink1r = (LinkFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                LinkEndFacadeLogic.logger.warn("incorrect metafacade cast for LinkEndFacadeLogic.getLink LinkFacade " + result + ": " + shieldedResult);
            }
            // linkEnds has no post constraints
            this.__getLink1r = getLink1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLink1rSet = true;
            }
        }
        return getLink1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetLink();

    private Collection<InstanceFacade> __getInstances2r;
    private boolean __getInstances2rSet = false;

    /**
     * Can be an AttributeLinkImpl or LinkEndImpl. A representation of the model object 'Slot'. A
     * slot
     * specifies that an entity modeled by an instance specification has a value or values for a
     * specific
     * structural feature.
     * @return (Collection<InstanceFacade>)handleGetInstances()
     */
    public final Collection<InstanceFacade> getInstances()
    {
        Collection<InstanceFacade> getInstances2r = this.__getInstances2r;
        if (!this.__getInstances2rSet)
        {
            // linkEndFacade has no pre constraints
            Collection result = handleGetInstances();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getInstances2r = (Collection<InstanceFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                LinkEndFacadeLogic.logger.warn("incorrect metafacade cast for LinkEndFacadeLogic.getInstances Collection<InstanceFacade> " + result + ": " + shieldedResult);
            }
            // linkEndFacade has no post constraints
            this.__getInstances2r = getInstances2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInstances2rSet = true;
            }
        }
        return getInstances2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetInstances();

    private AssociationEndFacade __getAssociationEnd3r;
    private boolean __getAssociationEnd3rSet = false;

    /**
     * Can be an AttributeLinkImpl or LinkEndImpl. A representation of the model object 'Slot'. A
     * slot
     * specifies that an entity modeled by an instance specification has a value or values for a
     * specific
     * structural feature.
     * @return (AssociationEndFacade)handleGetAssociationEnd()
     */
    public final AssociationEndFacade getAssociationEnd()
    {
        AssociationEndFacade getAssociationEnd3r = this.__getAssociationEnd3r;
        if (!this.__getAssociationEnd3rSet)
        {
            // linkEndFacade has no pre constraints
            Object result = handleGetAssociationEnd();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAssociationEnd3r = (AssociationEndFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                LinkEndFacadeLogic.logger.warn("incorrect metafacade cast for LinkEndFacadeLogic.getAssociationEnd AssociationEndFacade " + result + ": " + shieldedResult);
            }
            // linkEndFacade has no post constraints
            this.__getAssociationEnd3r = getAssociationEnd3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAssociationEnd3rSet = true;
            }
        }
        return getAssociationEnd3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAssociationEnd();

    private InstanceFacade __getInstance4r;
    private boolean __getInstance4rSet = false;

    /**
     * Those slots that map onto association ends.
     * @return (InstanceFacade)handleGetInstance()
     */
    public final InstanceFacade getInstance()
    {
        InstanceFacade getInstance4r = this.__getInstance4r;
        if (!this.__getInstance4rSet)
        {
            // linkEnds has no pre constraints
            Object result = handleGetInstance();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInstance4r = (InstanceFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                LinkEndFacadeLogic.logger.warn("incorrect metafacade cast for LinkEndFacadeLogic.getInstance InstanceFacade " + result + ": " + shieldedResult);
            }
            // linkEnds has no post constraints
            this.__getInstance4r = getInstance4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInstance4rSet = true;
            }
        }
        return getInstance4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInstance();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}