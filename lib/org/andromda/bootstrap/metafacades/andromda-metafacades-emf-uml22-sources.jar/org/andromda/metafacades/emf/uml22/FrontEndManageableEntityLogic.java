// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndManageableEntity;
import org.andromda.metafacades.uml.Role;
import org.apache.log4j.Logger;

/**
 * TODO: Model Documentation for FrontEndManageableEntity
 * MetafacadeLogic for FrontEndManageableEntity
 *
 * @see FrontEndManageableEntity
 */
public abstract class FrontEndManageableEntityLogic
    extends ManageableEntityLogicImpl
    implements FrontEndManageableEntity
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndManageableEntityLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndManageableEntityLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndManageableEntity if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndManageableEntity";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndManageableEntity
     */
    public boolean isFrontEndManageableEntityMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndManageableEntity#getViewName()
    * @return String
    */
    protected abstract String handleGetViewName();

    /**
     * TODO: Model Documentation for FrontEndManageableEntity.viewName
     * @return (String)handleGetViewName()
     */
    public final String getViewName()
    {
        String viewName1a = null;
        // viewName has no pre constraints
        viewName1a = handleGetViewName();
        // viewName has no post constraints
        return viewName1a;
    }

   /**
    * @see FrontEndManageableEntity#getViewTitleKey()
    * @return String
    */
    protected abstract String handleGetViewTitleKey();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.viewTitleKey
     * @return (String)handleGetViewTitleKey()
     */
    public final String getViewTitleKey()
    {
        String viewTitleKey2a = null;
        // viewTitleKey has no pre constraints
        viewTitleKey2a = handleGetViewTitleKey();
        // viewTitleKey has no post constraints
        return viewTitleKey2a;
    }

   /**
    * @see FrontEndManageableEntity#getViewTitleValue()
    * @return String
    */
    protected abstract String handleGetViewTitleValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.viewTitleValue
     * @return (String)handleGetViewTitleValue()
     */
    public final String getViewTitleValue()
    {
        String viewTitleValue3a = null;
        // viewTitleValue has no pre constraints
        viewTitleValue3a = handleGetViewTitleValue();
        // viewTitleValue has no post constraints
        return viewTitleValue3a;
    }

   /**
    * @see FrontEndManageableEntity#getListName()
    * @return String
    */
    protected abstract String handleGetListName();

    /**
     * TODO: Model Documentation for FrontEndManageableEntity.listName
     * @return (String)handleGetListName()
     */
    public final String getListName()
    {
        String listName4a = null;
        // listName has no pre constraints
        listName4a = handleGetListName();
        // listName has no post constraints
        return listName4a;
    }

   /**
    * @see FrontEndManageableEntity#getFormBeanType()
    * @return String
    */
    protected abstract String handleGetFormBeanType();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.formBeanType
     * @return (String)handleGetFormBeanType()
     */
    public final String getFormBeanType()
    {
        String formBeanType5a = null;
        // formBeanType has no pre constraints
        formBeanType5a = handleGetFormBeanType();
        // formBeanType has no post constraints
        return formBeanType5a;
    }

   /**
    * @see FrontEndManageableEntity#getFormBeanName()
    * @return String
    */
    protected abstract String handleGetFormBeanName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.formBeanName
     * @return (String)handleGetFormBeanName()
     */
    public final String getFormBeanName()
    {
        String formBeanName6a = null;
        // formBeanName has no pre constraints
        formBeanName6a = handleGetFormBeanName();
        // formBeanName has no post constraints
        return formBeanName6a;
    }

   /**
    * @see FrontEndManageableEntity#getExceptionKey()
    * @return String
    */
    protected abstract String handleGetExceptionKey();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.exceptionKey
     * @return (String)handleGetExceptionKey()
     */
    public final String getExceptionKey()
    {
        String exceptionKey7a = null;
        // exceptionKey has no pre constraints
        exceptionKey7a = handleGetExceptionKey();
        // exceptionKey has no post constraints
        return exceptionKey7a;
    }

   /**
    * @see FrontEndManageableEntity#getActionType()
    * @return String
    */
    protected abstract String handleGetActionType();

    /**
     * The fully qualified name of the action class that execute the manageable actions.
     * @return (String)handleGetActionType()
     */
    public final String getActionType()
    {
        String actionType8a = null;
        // actionType has no pre constraints
        actionType8a = handleGetActionType();
        // actionType has no post constraints
        return actionType8a;
    }

   /**
    * @see FrontEndManageableEntity#getActionFullPath()
    * @return String
    */
    protected abstract String handleGetActionFullPath();

    /**
     * The fully qualified path to the action class that execute the manageable actions.
     * @return (String)handleGetActionFullPath()
     */
    public final String getActionFullPath()
    {
        String actionFullPath9a = null;
        // actionFullPath has no pre constraints
        actionFullPath9a = handleGetActionFullPath();
        // actionFullPath has no post constraints
        return actionFullPath9a;
    }

   /**
    * @see FrontEndManageableEntity#getActionPath()
    * @return String
    */
    protected abstract String handleGetActionPath();

    /**
     * The path to the action class that execute the manageable actions.
     * @return (String)handleGetActionPath()
     */
    public final String getActionPath()
    {
        String actionPath10a = null;
        // actionPath has no pre constraints
        actionPath10a = handleGetActionPath();
        // actionPath has no post constraints
        return actionPath10a;
    }

   /**
    * @see FrontEndManageableEntity#getActionClassName()
    * @return String
    */
    protected abstract String handleGetActionClassName();

    /**
     * The name of the action class that executes the manageable actions.
     * @return (String)handleGetActionClassName()
     */
    public final String getActionClassName()
    {
        String actionClassName11a = null;
        // actionClassName has no pre constraints
        actionClassName11a = handleGetActionClassName();
        // actionClassName has no post constraints
        return actionClassName11a;
    }

   /**
    * @see FrontEndManageableEntity#getExceptionPath()
    * @return String
    */
    protected abstract String handleGetExceptionPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.exceptionPath
     * @return (String)handleGetExceptionPath()
     */
    public final String getExceptionPath()
    {
        String exceptionPath12a = null;
        // exceptionPath has no pre constraints
        exceptionPath12a = handleGetExceptionPath();
        // exceptionPath has no post constraints
        return exceptionPath12a;
    }

   /**
    * @see FrontEndManageableEntity#isPreload()
    * @return boolean
    */
    protected abstract boolean handleIsPreload();

    /**
     * TODO: Model Documentation for FrontEndManageableEntity.preload
     * @return (boolean)handleIsPreload()
     */
    public final boolean isPreload()
    {
        boolean preload13a = false;
        // preload has no pre constraints
        preload13a = handleIsPreload();
        // preload has no post constraints
        return preload13a;
    }

   /**
    * @see FrontEndManageableEntity#getFormBeanClassName()
    * @return String
    */
    protected abstract String handleGetFormBeanClassName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.formBeanClassName
     * @return (String)handleGetFormBeanClassName()
     */
    public final String getFormBeanClassName()
    {
        String formBeanClassName14a = null;
        // formBeanClassName has no pre constraints
        formBeanClassName14a = handleGetFormBeanClassName();
        // formBeanClassName has no post constraints
        return formBeanClassName14a;
    }

   /**
    * @see FrontEndManageableEntity#getFormBeanFullPath()
    * @return String
    */
    protected abstract String handleGetFormBeanFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.formBeanFullPath
     * @return (String)handleGetFormBeanFullPath()
     */
    public final String getFormBeanFullPath()
    {
        String formBeanFullPath15a = null;
        // formBeanFullPath has no pre constraints
        formBeanFullPath15a = handleGetFormBeanFullPath();
        // formBeanFullPath has no post constraints
        return formBeanFullPath15a;
    }

   /**
    * @see FrontEndManageableEntity#getListGetterName()
    * @return String
    */
    protected abstract String handleGetListGetterName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.listGetterName
     * @return (String)handleGetListGetterName()
     */
    public final String getListGetterName()
    {
        String listGetterName16a = null;
        // listGetterName has no pre constraints
        listGetterName16a = handleGetListGetterName();
        // listGetterName has no post constraints
        return listGetterName16a;
    }

   /**
    * @see FrontEndManageableEntity#getListSetterName()
    * @return String
    */
    protected abstract String handleGetListSetterName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.listSetterName
     * @return (String)handleGetListSetterName()
     */
    public final String getListSetterName()
    {
        String listSetterName17a = null;
        // listSetterName has no pre constraints
        listSetterName17a = handleGetListSetterName();
        // listSetterName has no post constraints
        return listSetterName17a;
    }

   /**
    * @see FrontEndManageableEntity#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.messageKey
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey18a = null;
        // messageKey has no pre constraints
        messageKey18a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey18a;
    }

   /**
    * @see FrontEndManageableEntity#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.messageValue
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue19a = null;
        // messageValue has no pre constraints
        messageValue19a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue19a;
    }

   /**
    * @see FrontEndManageableEntity#getOnlineHelpKey()
    * @return String
    */
    protected abstract String handleGetOnlineHelpKey();

    /**
     * The key to lookup the online help documentation.
     * @return (String)handleGetOnlineHelpKey()
     */
    public final String getOnlineHelpKey()
    {
        String onlineHelpKey20a = null;
        // onlineHelpKey has no pre constraints
        onlineHelpKey20a = handleGetOnlineHelpKey();
        // onlineHelpKey has no post constraints
        return onlineHelpKey20a;
    }

   /**
    * @see FrontEndManageableEntity#getOnlineHelpValue()
    * @return String
    */
    protected abstract String handleGetOnlineHelpValue();

    /**
     * The online help documentation. The format is HTML without any style.
     * @return (String)handleGetOnlineHelpValue()
     */
    public final String getOnlineHelpValue()
    {
        String onlineHelpValue21a = null;
        // onlineHelpValue has no pre constraints
        onlineHelpValue21a = handleGetOnlineHelpValue();
        // onlineHelpValue has no post constraints
        return onlineHelpValue21a;
    }

   /**
    * @see FrontEndManageableEntity#getOnlineHelpActionPath()
    * @return String
    */
    protected abstract String handleGetOnlineHelpActionPath();

    /**
     * The full path to this entity's online help action. The returned String does not have a suffix
     * such as '.do'.
     * @return (String)handleGetOnlineHelpActionPath()
     */
    public final String getOnlineHelpActionPath()
    {
        String onlineHelpActionPath22a = null;
        // onlineHelpActionPath has no pre constraints
        onlineHelpActionPath22a = handleGetOnlineHelpActionPath();
        // onlineHelpActionPath has no post constraints
        return onlineHelpActionPath22a;
    }

   /**
    * @see FrontEndManageableEntity#getOnlineHelpPagePath()
    * @return String
    */
    protected abstract String handleGetOnlineHelpPagePath();

    /**
     * The full path to this entitiy's online help page. The returned String does not have a suffix
     * such as '.jsp'.
     * @return (String)handleGetOnlineHelpPagePath()
     */
    public final String getOnlineHelpPagePath()
    {
        String onlineHelpPagePath23a = null;
        // onlineHelpPagePath has no pre constraints
        onlineHelpPagePath23a = handleGetOnlineHelpPagePath();
        // onlineHelpPagePath has no post constraints
        return onlineHelpPagePath23a;
    }

   /**
    * @see FrontEndManageableEntity#isTableExportable()
    * @return boolean
    */
    protected abstract boolean handleIsTableExportable();

    /**
     * True if it is possible to export the table data to XML, CSV, PDF or Excel format.
     * @return (boolean)handleIsTableExportable()
     */
    public final boolean isTableExportable()
    {
        boolean tableExportable24a = false;
        // tableExportable has no pre constraints
        tableExportable24a = handleIsTableExportable();
        // tableExportable has no post constraints
        return tableExportable24a;
    }

   /**
    * @see FrontEndManageableEntity#getTableExportTypes()
    * @return String
    */
    protected abstract String handleGetTableExportTypes();

    /**
     * Tthe available types of export in a single String instance.
     * @return (String)handleGetTableExportTypes()
     */
    public final String getTableExportTypes()
    {
        String tableExportTypes25a = null;
        // tableExportTypes has no pre constraints
        tableExportTypes25a = handleGetTableExportTypes();
        // tableExportTypes has no post constraints
        return tableExportTypes25a;
    }

   /**
    * @see FrontEndManageableEntity#getTableMaxRows()
    * @return int
    */
    protected abstract int handleGetTableMaxRows();

    /**
     * The maximum number of rows to be displayed in the table at the same time. This is also known
     * as the page size. A value of zero or less will display all data in the same table (therefore
     * also on the same page).
     * @return (int)handleGetTableMaxRows()
     */
    public final int getTableMaxRows()
    {
        int tableMaxRows26a = 0;
        // tableMaxRows has no pre constraints
        tableMaxRows26a = handleGetTableMaxRows();
        // tableMaxRows has no post constraints
        return tableMaxRows26a;
    }

   /**
    * @see FrontEndManageableEntity#isTableSortable()
    * @return boolean
    */
    protected abstract boolean handleIsTableSortable();

    /**
     * True if it is possible to sort the columns of the table.
     * @return (boolean)handleIsTableSortable()
     */
    public final boolean isTableSortable()
    {
        boolean tableSortable27a = false;
        // tableSortable has no pre constraints
        tableSortable27a = handleIsTableSortable();
        // tableSortable has no post constraints
        return tableSortable27a;
    }

   /**
    * @see FrontEndManageableEntity#getControllerType()
    * @return String
    */
    protected abstract String handleGetControllerType();

    /**
     * Fully qualified name of this manageable controller.
     * @return (String)handleGetControllerType()
     */
    public final String getControllerType()
    {
        String controllerType28a = null;
        // controllerType has no pre constraints
        controllerType28a = handleGetControllerType();
        // controllerType has no post constraints
        return controllerType28a;
    }

   /**
    * @see FrontEndManageableEntity#getControllerBeanName()
    * @return String
    */
    protected abstract String handleGetControllerBeanName();

    /**
     * The bean name of this manageable controller (this is what is stored in the JSF configuration
     * file).
     * @return (String)handleGetControllerBeanName()
     */
    public final String getControllerBeanName()
    {
        String controllerBeanName29a = null;
        // controllerBeanName has no pre constraints
        controllerBeanName29a = handleGetControllerBeanName();
        // controllerBeanName has no post constraints
        return controllerBeanName29a;
    }

   /**
    * @see FrontEndManageableEntity#getControllerFullPath()
    * @return String
    */
    protected abstract String handleGetControllerFullPath();

    /**
     * Full path of this manageable controller.
     * @return (String)handleGetControllerFullPath()
     */
    public final String getControllerFullPath()
    {
        String controllerFullPath30a = null;
        // controllerFullPath has no pre constraints
        controllerFullPath30a = handleGetControllerFullPath();
        // controllerFullPath has no post constraints
        return controllerFullPath30a;
    }

   /**
    * @see FrontEndManageableEntity#getControllerName()
    * @return String
    */
    protected abstract String handleGetControllerName();

    /**
     * Manageable controller class name.
     * @return (String)handleGetControllerName()
     */
    public final String getControllerName()
    {
        String controllerName31a = null;
        // controllerName has no pre constraints
        controllerName31a = handleGetControllerName();
        // controllerName has no post constraints
        return controllerName31a;
    }

   /**
    * @see FrontEndManageableEntity#getValueObjectClassName()
    * @return String
    */
    protected abstract String handleGetValueObjectClassName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.valueObjectClassName
     * @return (String)handleGetValueObjectClassName()
     */
    public final String getValueObjectClassName()
    {
        String valueObjectClassName32a = null;
        // valueObjectClassName has no pre constraints
        valueObjectClassName32a = handleGetValueObjectClassName();
        // valueObjectClassName has no post constraints
        return valueObjectClassName32a;
    }

   /**
    * @see FrontEndManageableEntity#getFormSerialVersionUID()
    * @return String
    */
    protected abstract String handleGetFormSerialVersionUID();

    /**
     * The calcuated serial version UID for this action's form.
     * @return (String)handleGetFormSerialVersionUID()
     */
    public final String getFormSerialVersionUID()
    {
        String formSerialVersionUID33a = null;
        // formSerialVersionUID has no pre constraints
        formSerialVersionUID33a = handleGetFormSerialVersionUID();
        // formSerialVersionUID has no post constraints
        return formSerialVersionUID33a;
    }

   /**
    * @see FrontEndManageableEntity#getActionSerialVersionUID()
    * @return String
    */
    protected abstract String handleGetActionSerialVersionUID();

    /**
     * The calcuated serial version UID for this manageable actions.
     * @return (String)handleGetActionSerialVersionUID()
     */
    public final String getActionSerialVersionUID()
    {
        String actionSerialVersionUID34a = null;
        // actionSerialVersionUID has no pre constraints
        actionSerialVersionUID34a = handleGetActionSerialVersionUID();
        // actionSerialVersionUID has no post constraints
        return actionSerialVersionUID34a;
    }

   /**
    * @see FrontEndManageableEntity#getPopulatorName()
    * @return String
    */
    protected abstract String handleGetPopulatorName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.populatorName
     * @return (String)handleGetPopulatorName()
     */
    public final String getPopulatorName()
    {
        String populatorName35a = null;
        // populatorName has no pre constraints
        populatorName35a = handleGetPopulatorName();
        // populatorName has no post constraints
        return populatorName35a;
    }

   /**
    * @see FrontEndManageableEntity#getPopulatorFullPath()
    * @return String
    */
    protected abstract String handleGetPopulatorFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.populatorFullPath
     * @return (String)handleGetPopulatorFullPath()
     */
    public final String getPopulatorFullPath()
    {
        String populatorFullPath36a = null;
        // populatorFullPath has no pre constraints
        populatorFullPath36a = handleGetPopulatorFullPath();
        // populatorFullPath has no post constraints
        return populatorFullPath36a;
    }

   /**
    * @see FrontEndManageableEntity#getPopulatorType()
    * @return String
    */
    protected abstract String handleGetPopulatorType();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.populatorType
     * @return (String)handleGetPopulatorType()
     */
    public final String getPopulatorType()
    {
        String populatorType37a = null;
        // populatorType has no pre constraints
        populatorType37a = handleGetPopulatorType();
        // populatorType has no post constraints
        return populatorType37a;
    }

   /**
    * @see FrontEndManageableEntity#getViewFullPath()
    * @return String
    */
    protected abstract String handleGetViewFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.viewFullPath
     * @return (String)handleGetViewFullPath()
     */
    public final String getViewFullPath()
    {
        String viewFullPath38a = null;
        // viewFullPath has no pre constraints
        viewFullPath38a = handleGetViewFullPath();
        // viewFullPath has no post constraints
        return viewFullPath38a;
    }

   /**
    * @see FrontEndManageableEntity#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.validationRequired
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired39a = false;
        // validationRequired has no pre constraints
        validationRequired39a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired39a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFormBeanName()
    * @return String
    */
    protected abstract String handleGetSearchFormBeanName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.searchFormBeanName
     * @return (String)handleGetSearchFormBeanName()
     */
    public final String getSearchFormBeanName()
    {
        String searchFormBeanName40a = null;
        // searchFormBeanName has no pre constraints
        searchFormBeanName40a = handleGetSearchFormBeanName();
        // searchFormBeanName has no post constraints
        return searchFormBeanName40a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFormBeanType()
    * @return String
    */
    protected abstract String handleGetSearchFormBeanType();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.searchFormBeanType
     * @return (String)handleGetSearchFormBeanType()
     */
    public final String getSearchFormBeanType()
    {
        String searchFormBeanType41a = null;
        // searchFormBeanType has no pre constraints
        searchFormBeanType41a = handleGetSearchFormBeanType();
        // searchFormBeanType has no post constraints
        return searchFormBeanType41a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFormBeanFullPath()
    * @return String
    */
    protected abstract String handleGetSearchFormBeanFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.searchFormBeanFullPath
     * @return (String)handleGetSearchFormBeanFullPath()
     */
    public final String getSearchFormBeanFullPath()
    {
        String searchFormBeanFullPath42a = null;
        // searchFormBeanFullPath has no pre constraints
        searchFormBeanFullPath42a = handleGetSearchFormBeanFullPath();
        // searchFormBeanFullPath has no post constraints
        return searchFormBeanFullPath42a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFormBeanClassName()
    * @return String
    */
    protected abstract String handleGetSearchFormBeanClassName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.searchFormBeanClassName
     * @return (String)handleGetSearchFormBeanClassName()
     */
    public final String getSearchFormBeanClassName()
    {
        String searchFormBeanClassName43a = null;
        // searchFormBeanClassName has no pre constraints
        searchFormBeanClassName43a = handleGetSearchFormBeanClassName();
        // searchFormBeanClassName has no post constraints
        return searchFormBeanClassName43a;
    }

   /**
    * @see FrontEndManageableEntity#getManageableSearchAttributes()
    * @return Collection
    */
    protected abstract Collection handleGetManageableSearchAttributes();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.manageableSearchAttributes
     * @return (Collection)handleGetManageableSearchAttributes()
     */
    public final Collection getManageableSearchAttributes()
    {
        Collection manageableSearchAttributes44a = null;
        // manageableSearchAttributes has no pre constraints
        manageableSearchAttributes44a = handleGetManageableSearchAttributes();
        // manageableSearchAttributes has no post constraints
        return manageableSearchAttributes44a;
    }

   /**
    * @see FrontEndManageableEntity#getManageableSearchAssociationEnds()
    * @return Collection
    */
    protected abstract Collection handleGetManageableSearchAssociationEnds();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.manageableSearchAssociationEnds
     * @return (Collection)handleGetManageableSearchAssociationEnds()
     */
    public final Collection getManageableSearchAssociationEnds()
    {
        Collection manageableSearchAssociationEnds45a = null;
        // manageableSearchAssociationEnds has no pre constraints
        manageableSearchAssociationEnds45a = handleGetManageableSearchAssociationEnds();
        // manageableSearchAssociationEnds has no post constraints
        return manageableSearchAssociationEnds45a;
    }

   /**
    * @see FrontEndManageableEntity#isNeedsFileUpload()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsFileUpload();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.needsFileUpload
     * @return (boolean)handleIsNeedsFileUpload()
     */
    public final boolean isNeedsFileUpload()
    {
        boolean needsFileUpload46a = false;
        // needsFileUpload has no pre constraints
        needsFileUpload46a = handleIsNeedsFileUpload();
        // needsFileUpload has no post constraints
        return needsFileUpload46a;
    }

   /**
    * @see FrontEndManageableEntity#getConverterFullPath()
    * @return String
    */
    protected abstract String handleGetConverterFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.converterFullPath
     * @return (String)handleGetConverterFullPath()
     */
    public final String getConverterFullPath()
    {
        String converterFullPath47a = null;
        // converterFullPath has no pre constraints
        converterFullPath47a = handleGetConverterFullPath();
        // converterFullPath has no post constraints
        return converterFullPath47a;
    }

   /**
    * @see FrontEndManageableEntity#getConverterType()
    * @return String
    */
    protected abstract String handleGetConverterType();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.converterType
     * @return (String)handleGetConverterType()
     */
    public final String getConverterType()
    {
        String converterType48a = null;
        // converterType has no pre constraints
        converterType48a = handleGetConverterType();
        // converterType has no post constraints
        return converterType48a;
    }

   /**
    * @see FrontEndManageableEntity#getConverterClassName()
    * @return String
    */
    protected abstract String handleGetConverterClassName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.converterClassName
     * @return (String)handleGetConverterClassName()
     */
    public final String getConverterClassName()
    {
        String converterClassName49a = null;
        // converterClassName has no pre constraints
        converterClassName49a = handleGetConverterClassName();
        // converterClassName has no post constraints
        return converterClassName49a;
    }

   /**
    * @see FrontEndManageableEntity#getOdsExportFullPath()
    * @return String
    */
    protected abstract String handleGetOdsExportFullPath();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.odsExportFullPath
     * @return (String)handleGetOdsExportFullPath()
     */
    public final String getOdsExportFullPath()
    {
        String odsExportFullPath50a = null;
        // odsExportFullPath has no pre constraints
        odsExportFullPath50a = handleGetOdsExportFullPath();
        // odsExportFullPath has no post constraints
        return odsExportFullPath50a;
    }

   /**
    * @see FrontEndManageableEntity#isNeedsUserInterface()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsUserInterface();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.needsUserInterface
     * @return (boolean)handleIsNeedsUserInterface()
     */
    public final boolean isNeedsUserInterface()
    {
        boolean needsUserInterface51a = false;
        // needsUserInterface has no pre constraints
        needsUserInterface51a = handleIsNeedsUserInterface();
        // needsUserInterface has no post constraints
        return needsUserInterface51a;
    }

   /**
    * @see FrontEndManageableEntity#isNeedsImplementation()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsImplementation();

    /**
     * Returns true if the user needs to modify the standard behavior and a Impl.java file will be
     * created in web/src/main/java.
     * @return (boolean)handleIsNeedsImplementation()
     */
    public final boolean isNeedsImplementation()
    {
        boolean needsImplementation52a = false;
        // needsImplementation has no pre constraints
        needsImplementation52a = handleIsNeedsImplementation();
        // needsImplementation has no post constraints
        return needsImplementation52a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFilterFullPath()
    * @return String
    */
    protected abstract String handleGetSearchFilterFullPath();

    /**
     * Full path of this manageable search filter.
     * @return (String)handleGetSearchFilterFullPath()
     */
    public final String getSearchFilterFullPath()
    {
        String searchFilterFullPath53a = null;
        // searchFilterFullPath has no pre constraints
        searchFilterFullPath53a = handleGetSearchFilterFullPath();
        // searchFilterFullPath has no post constraints
        return searchFilterFullPath53a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFilterName()
    * @return String
    */
    protected abstract String handleGetSearchFilterName();

    /**
     * Search filter class name.
     * @return (String)handleGetSearchFilterName()
     */
    public final String getSearchFilterName()
    {
        String searchFilterName54a = null;
        // searchFilterName has no pre constraints
        searchFilterName54a = handleGetSearchFilterName();
        // searchFilterName has no post constraints
        return searchFilterName54a;
    }

   /**
    * @see FrontEndManageableEntity#getSearchFilterSerialVersionUID()
    * @return String
    */
    protected abstract String handleGetSearchFilterSerialVersionUID();

    /**
     * The calculated serial version UID for this controller.
     * @return (String)handleGetSearchFilterSerialVersionUID()
     */
    public final String getSearchFilterSerialVersionUID()
    {
        String searchFilterSerialVersionUID55a = null;
        // searchFilterSerialVersionUID has no pre constraints
        searchFilterSerialVersionUID55a = handleGetSearchFilterSerialVersionUID();
        // searchFilterSerialVersionUID has no post constraints
        return searchFilterSerialVersionUID55a;
    }

   /**
    * @see FrontEndManageableEntity#getManageableEditAttributes()
    * @return Collection
    */
    protected abstract Collection handleGetManageableEditAttributes();

    /**
     * returns all editable attributes
     * @return (Collection)handleGetManageableEditAttributes()
     */
    public final Collection getManageableEditAttributes()
    {
        Collection manageableEditAttributes56a = null;
        // manageableEditAttributes has no pre constraints
        manageableEditAttributes56a = handleGetManageableEditAttributes();
        // manageableEditAttributes has no post constraints
        return manageableEditAttributes56a;
    }

   /**
    * @see FrontEndManageableEntity#getManageableDetailsAssociationsEnds()
    * @return Collection
    */
    protected abstract Collection handleGetManageableDetailsAssociationsEnds();

    /**
     * Master/details associations: composition with reverse visibility.
     * @return (Collection)handleGetManageableDetailsAssociationsEnds()
     */
    public final Collection getManageableDetailsAssociationsEnds()
    {
        Collection manageableDetailsAssociationsEnds57a = null;
        // manageableDetailsAssociationsEnds has no pre constraints
        manageableDetailsAssociationsEnds57a = handleGetManageableDetailsAssociationsEnds();
        // manageableDetailsAssociationsEnds has no post constraints
        return manageableDetailsAssociationsEnds57a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * FrontEndManageableEntity.isSearchable
     * @param element
     * @return boolean
     */
    protected abstract boolean handleIsSearchable(Object element);

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.isSearchable
     * @param element Object
     * TODO: Model Documentation for
     * FrontEndManageableEntity.isSearchable(element)
     * @return handleIsSearchable(element)
     */
    public boolean isSearchable(Object element)
    {
        // isSearchable has no pre constraints
        boolean returnValue = handleIsSearchable(element);
        // isSearchable has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * FrontEndManageableEntity.getActionRoles
     * @return String
     */
    protected abstract String handleGetActionRoles();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntity.getActionRoles
     * @return handleGetActionRoles()
     */
    public String getActionRoles()
    {
        // getActionRoles has no pre constraints
        String returnValue = handleGetActionRoles();
        // getActionRoles has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * TODO: Model Documentation for FrontEndManageableEntity
     * @return (Collection<Role>)handleGetRoles()
     */
    public final Collection<Role> getRoles()
    {
        Collection<Role> getRoles1r = null;
        // frontEndManageableEntity has no pre constraints
        Collection result = handleGetRoles();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getRoles1r = (Collection<Role>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndManageableEntityLogic.logger.warn("incorrect metafacade cast for FrontEndManageableEntityLogic.getRoles Collection<Role> " + result + ": " + shieldedResult);
        }
        // frontEndManageableEntity has no post constraints
        return getRoles1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetRoles();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ManageableEntityLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}