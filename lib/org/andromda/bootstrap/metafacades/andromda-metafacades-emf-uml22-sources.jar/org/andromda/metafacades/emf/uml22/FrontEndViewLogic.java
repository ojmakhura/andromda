// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndForward;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndUseCase;
import org.andromda.metafacades.uml.FrontEndView;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Transformer;
import org.apache.log4j.Logger;

/**
 * Represents a view within a front end application.
 * MetafacadeLogic for FrontEndView
 *
 * @see FrontEndView
 */
public abstract class FrontEndViewLogic
    extends FrontEndActionStateLogicImpl
    implements FrontEndView
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndViewLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndViewLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndView if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndView";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndView
     */
    public boolean isFrontEndViewMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndView#isFrontEndView()
    * @return boolean
    */
    protected abstract boolean handleIsFrontEndView();

    /**
     * True if this element carries the FrontEndView stereotype.
     * @return (boolean)handleIsFrontEndView()
     */
    public final boolean isFrontEndView()
    {
        boolean frontEndView1a = false;
        // frontEndView has no pre constraints
        frontEndView1a = handleIsFrontEndView();
        // frontEndView has no post constraints
        return frontEndView1a;
    }

   /**
    * @see FrontEndView#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * The full path of the view resources (i.e. the JSP page).
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path2a = null;
        // path has no pre constraints
        path2a = handleGetPath();
        // path has no post constraints
        return path2a;
    }

   /**
    * @see FrontEndView#getTitleKey()
    * @return String
    */
    protected abstract String handleGetTitleKey();

    /**
     * A resource message key suited for the view's title.
     * @return (String)handleGetTitleKey()
     */
    public final String getTitleKey()
    {
        String titleKey3a = null;
        // titleKey has no pre constraints
        titleKey3a = handleGetTitleKey();
        // titleKey has no post constraints
        return titleKey3a;
    }

   /**
    * @see FrontEndView#getTitleValue()
    * @return String
    */
    protected abstract String handleGetTitleValue();

    /**
     * A default resource message value suited for the page's title.
     * @return (String)handleGetTitleValue()
     */
    public final String getTitleValue()
    {
        String titleValue4a = null;
        // titleValue has no pre constraints
        titleValue4a = handleGetTitleValue();
        // titleValue has no post constraints
        return titleValue4a;
    }

   /**
    * @see FrontEndView#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * The default resource message key for this view.
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey5a = null;
        // messageKey has no pre constraints
        messageKey5a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey5a;
    }

   /**
    * @see FrontEndView#getDocumentationKey()
    * @return String
    */
    protected abstract String handleGetDocumentationKey();

    /**
     * A resource message key suited for the page's documentation.
     * @return (String)handleGetDocumentationKey()
     */
    public final String getDocumentationKey()
    {
        String documentationKey6a = null;
        // documentationKey has no pre constraints
        documentationKey6a = handleGetDocumentationKey();
        // documentationKey has no post constraints
        return documentationKey6a;
    }

   /**
    * @see FrontEndView#getDocumentationValue()
    * @return String
    */
    protected abstract String handleGetDocumentationValue();

    /**
     * A resource message value suited for the view's documentation.
     * @return (String)handleGetDocumentationValue()
     */
    public final String getDocumentationValue()
    {
        String documentationValue7a = null;
        // documentationValue has no pre constraints
        documentationValue7a = handleGetDocumentationValue();
        // documentationValue has no post constraints
        return documentationValue7a;
    }

   /**
    * @see FrontEndView#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * A displayable version of this view's name.
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue8a = null;
        // messageValue has no pre constraints
        messageValue8a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue8a;
    }

   /**
    * @see FrontEndView#getFullyQualifiedPopulator()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedPopulator();

    /**
     * The fully qualified name of this view's form populator.
     * @return (String)handleGetFullyQualifiedPopulator()
     */
    public final String getFullyQualifiedPopulator()
    {
        String fullyQualifiedPopulator9a = null;
        // fullyQualifiedPopulator has no pre constraints
        fullyQualifiedPopulator9a = handleGetFullyQualifiedPopulator();
        // fullyQualifiedPopulator has no post constraints
        return fullyQualifiedPopulator9a;
    }

   /**
    * @see FrontEndView#getPopulatorPath()
    * @return String
    */
    protected abstract String handleGetPopulatorPath();

    /**
     * The path to the form populator.
     * @return (String)handleGetPopulatorPath()
     */
    public final String getPopulatorPath()
    {
        String populatorPath10a = null;
        // populatorPath has no pre constraints
        populatorPath10a = handleGetPopulatorPath();
        // populatorPath has no post constraints
        return populatorPath10a;
    }

   /**
    * @see FrontEndView#getPopulator()
    * @return String
    */
    protected abstract String handleGetPopulator();

    /**
     * The name of the form populator for this view.
     * @return (String)handleGetPopulator()
     */
    public final String getPopulator()
    {
        String populator11a = null;
        // populator has no pre constraints
        populator11a = handleGetPopulator();
        // populator has no post constraints
        return populator11a;
    }

   /**
    * @see FrontEndView#isPopulatorRequired()
    * @return boolean
    */
    protected abstract boolean handleIsPopulatorRequired();

    /**
     * Indicates if a populator is required for this view.
     * @return (boolean)handleIsPopulatorRequired()
     */
    public final boolean isPopulatorRequired()
    {
        boolean populatorRequired12a = false;
        // populatorRequired has no pre constraints
        populatorRequired12a = handleIsPopulatorRequired();
        // populatorRequired has no post constraints
        return populatorRequired12a;
    }

   /**
    * @see FrontEndView#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not at least one parameter of an outgoing action in this view requires
     * validation.
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired13a = false;
        // validationRequired has no pre constraints
        validationRequired13a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired13a;
    }

   /**
    * @see FrontEndView#isPopup()
    * @return boolean
    */
    protected abstract boolean handleIsPopup();

    /**
     * Indicates if this view represents a popup.
     * @return (boolean)handleIsPopup()
     */
    public final boolean isPopup()
    {
        boolean popup14a = false;
        // popup has no pre constraints
        popup14a = handleIsPopup();
        // popup has no post constraints
        return popup14a;
    }

   /**
    * @see FrontEndView#isNonTableVariablesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsNonTableVariablesPresent();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return (boolean)handleIsNonTableVariablesPresent()
     */
    public final boolean isNonTableVariablesPresent()
    {
        boolean nonTableVariablesPresent15a = false;
        // nonTableVariablesPresent has no pre constraints
        nonTableVariablesPresent15a = handleIsNonTableVariablesPresent();
        // nonTableVariablesPresent has no post constraints
        return nonTableVariablesPresent15a;
    }

   /**
    * @see FrontEndView#isHasNameOfUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsHasNameOfUseCase();

    /**
     * Indicates whether or not this view has the same name as the use case in which it is
     * contained.
     * @return (boolean)handleIsHasNameOfUseCase()
     */
    public final boolean isHasNameOfUseCase()
    {
        boolean hasNameOfUseCase16a = false;
        // hasNameOfUseCase has no pre constraints
        hasNameOfUseCase16a = handleIsHasNameOfUseCase();
        // hasNameOfUseCase has no post constraints
        return hasNameOfUseCase16a;
    }

   /**
    * @see FrontEndView#getFormKey()
    * @return String
    */
    protected abstract String handleGetFormKey();

    /**
     * The key that stores the form in which information is passed from one action to another.
     * @return (String)handleGetFormKey()
     */
    public final String getFormKey()
    {
        String formKey17a = null;
        // formKey has no pre constraints
        formKey17a = handleGetFormKey();
        // formKey has no post constraints
        return formKey17a;
    }

   /**
    * @see FrontEndView#getFromOutcome()
    * @return String
    */
    protected abstract String handleGetFromOutcome();

    /**
     * The name that corresponds to the from-outcome in an navigational rule.
     * @return (String)handleGetFromOutcome()
     */
    public final String getFromOutcome()
    {
        String fromOutcome18a = null;
        // fromOutcome has no pre constraints
        fromOutcome18a = handleGetFromOutcome();
        // fromOutcome has no post constraints
        return fromOutcome18a;
    }

   /**
    * @see FrontEndView#isNeedsFileUpload()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsFileUpload();

    /**
     * TODO: Model Documentation for FrontEndView.needsFileUpload
     * @return (boolean)handleIsNeedsFileUpload()
     */
    public final boolean isNeedsFileUpload()
    {
        boolean needsFileUpload19a = false;
        // needsFileUpload has no pre constraints
        needsFileUpload19a = handleIsNeedsFileUpload();
        // needsFileUpload has no post constraints
        return needsFileUpload19a;
    }

   /**
    * @see FrontEndView#getFullyQualifiedPageObjectClassPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedPageObjectClassPath();

    /**
     * TODO: Model Documentation for
     * FrontEndView.fullyQualifiedPageObjectClassPath
     * @return (String)handleGetFullyQualifiedPageObjectClassPath()
     */
    public final String getFullyQualifiedPageObjectClassPath()
    {
        String fullyQualifiedPageObjectClassPath20a = null;
        // fullyQualifiedPageObjectClassPath has no pre constraints
        fullyQualifiedPageObjectClassPath20a = handleGetFullyQualifiedPageObjectClassPath();
        // fullyQualifiedPageObjectClassPath has no post constraints
        return fullyQualifiedPageObjectClassPath20a;
    }

   /**
    * @see FrontEndView#getFullyQualifiedPageObjectClassName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedPageObjectClassName();

    /**
     * TODO: Model Documentation for
     * FrontEndView.fullyQualifiedPageObjectClassName
     * @return (String)handleGetFullyQualifiedPageObjectClassName()
     */
    public final String getFullyQualifiedPageObjectClassName()
    {
        String fullyQualifiedPageObjectClassName21a = null;
        // fullyQualifiedPageObjectClassName has no pre constraints
        fullyQualifiedPageObjectClassName21a = handleGetFullyQualifiedPageObjectClassName();
        // fullyQualifiedPageObjectClassName has no post constraints
        return fullyQualifiedPageObjectClassName21a;
    }

   /**
    * @see FrontEndView#getPageObjectClassName()
    * @return String
    */
    protected abstract String handleGetPageObjectClassName();

    /**
     * TODO: Model Documentation for FrontEndView.pageObjectClassName
     * @return (String)handleGetPageObjectClassName()
     */
    public final String getPageObjectClassName()
    {
        String pageObjectClassName22a = null;
        // pageObjectClassName has no pre constraints
        pageObjectClassName22a = handleGetPageObjectClassName();
        // pageObjectClassName has no post constraints
        return pageObjectClassName22a;
    }

   /**
    * @see FrontEndView#getFormActions()
    * @return List<FrontEndAction>
    */
    protected abstract List<FrontEndAction> handleGetFormActions();

    /**
     * All actions that have forms associated with them.
     * @return (List<FrontEndAction>)handleGetFormActions()
     */
    public final List<FrontEndAction> getFormActions()
    {
        List<FrontEndAction> formActions23a = null;
        // formActions has no pre constraints
        formActions23a = handleGetFormActions();
        // formActions has no post constraints
        return formActions23a;
    }

   /**
    * @see FrontEndView#getActionForwards()
    * @return List<FrontEndForward>
    */
    protected abstract List<FrontEndForward> handleGetActionForwards();

    /**
     * All those forwards that are actions.
     * @return (List<FrontEndForward>)handleGetActionForwards()
     */
    public final List<FrontEndForward> getActionForwards()
    {
        List<FrontEndForward> actionForwards24a = null;
        // actionForwards has no pre constraints
        actionForwards24a = handleGetActionForwards();
        // actionForwards has no post constraints
        return actionForwards24a;
    }

   /**
    * @see FrontEndView#getForwards()
    * @return List<FrontEndForward>
    */
    protected abstract List<FrontEndForward> handleGetForwards();

    /**
     * Gets the forwards which can be targgeted from this view.
     * @return (List<FrontEndForward>)handleGetForwards()
     */
    public final List<FrontEndForward> getForwards()
    {
        List<FrontEndForward> forwards25a = null;
        // forwards has no pre constraints
        forwards25a = handleGetForwards();
        // forwards has no post constraints
        return forwards25a;
    }

   /**
    * @see FrontEndView#getPageObjectBeanName()
    * @return String
    */
    protected abstract String handleGetPageObjectBeanName();

    /**
     * TODO: Model Documentation for FrontEndView.pageObjectBeanName
     * @return (String)handleGetPageObjectBeanName()
     */
    public final String getPageObjectBeanName()
    {
        String pageObjectBeanName26a = null;
        // pageObjectBeanName has no pre constraints
        pageObjectBeanName26a = handleGetPageObjectBeanName();
        // pageObjectBeanName has no post constraints
        return pageObjectBeanName26a;
    }

   /**
    * @see FrontEndView#getFilename()
    * @return String
    */
    protected abstract String handleGetFilename();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetFilename()
     */
    public final String getFilename()
    {
        String filename27a = null;
        // filename has no pre constraints
        filename27a = handleGetFilename();
        // filename has no post constraints
        return filename27a;
    }

   /**
    * @see FrontEndView#getAllowedRoles()
    * @return Collection
    */
    protected abstract Collection handleGetAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (Collection)handleGetAllowedRoles()
     */
    public final Collection getAllowedRoles()
    {
        Collection allowedRoles28a = null;
        // allowedRoles has no pre constraints
        allowedRoles28a = handleGetAllowedRoles();
        // allowedRoles has no post constraints
        return allowedRoles28a;
    }

   /**
    * @see FrontEndView#getRestPath()
    * @return String
    */
    protected abstract String handleGetRestPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetRestPath()
     */
    public final String getRestPath()
    {
        String restPath29a = null;
        // restPath has no pre constraints
        restPath29a = handleGetRestPath();
        // restPath has no post constraints
        return restPath29a;
    }

   /**
    * @see FrontEndView#getFrontEndClasses()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetFrontEndClasses();

    /**
     * TODO: Model Documentation for FrontEndView.frontEndClasses
     * @return (Set<String>)handleGetFrontEndClasses()
     */
    public final Set<String> getFrontEndClasses()
    {
        Set<String> frontEndClasses30a = null;
        // frontEndClasses has no pre constraints
        frontEndClasses30a = handleGetFrontEndClasses();
        // frontEndClasses has no post constraints
        return frontEndClasses30a;
    }

   /**
    * @see FrontEndView#getIcon()
    * @return String
    */
    protected abstract String handleGetIcon();

    /**
     * TODO: Model Documentation for FrontEndView.icon
     * @return (String)handleGetIcon()
     */
    public final String getIcon()
    {
        String icon31a = null;
        // icon has no pre constraints
        icon31a = handleGetIcon();
        // icon has no post constraints
        return icon31a;
    }

   /**
    * @see FrontEndView#getDisplayCondition()
    * @return String
    */
    protected abstract String handleGetDisplayCondition();

    /**
     * TODO: Model Documentation for FrontEndView.displayCondition
     * @return (String)handleGetDisplayCondition()
     */
    public final String getDisplayCondition()
    {
        String displayCondition32a = null;
        // displayCondition has no pre constraints
        displayCondition32a = handleGetDisplayCondition();
        // displayCondition has no post constraints
        return displayCondition32a;
    }

   /**
    * @see FrontEndView#getSubmitAction()
    * @return String
    */
    protected abstract String handleGetSubmitAction();

    /**
     * TODO: Model Documentation for FrontEndView.submitAction
     * @return (String)handleGetSubmitAction()
     */
    public final String getSubmitAction()
    {
        String submitAction33a = null;
        // submitAction has no pre constraints
        submitAction33a = handleGetSubmitAction();
        // submitAction has no post constraints
        return submitAction33a;
    }

   /**
    * @see FrontEndView#getTreePresent()
    * @return Boolean
    */
    protected abstract Boolean handleGetTreePresent();

    /**
     * TODO: Model Documentation for FrontEndView.treePresent
     * @return (Boolean)handleGetTreePresent()
     */
    public final Boolean getTreePresent()
    {
        Boolean treePresent34a = null;
        // treePresent has no pre constraints
        treePresent34a = handleGetTreePresent();
        // treePresent has no post constraints
        return treePresent34a;
    }

   /**
    * @see FrontEndView#isTableVariablesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsTableVariablesPresent();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return (boolean)handleIsTableVariablesPresent()
     */
    public final boolean isTableVariablesPresent()
    {
        boolean tableVariablesPresent35a = false;
        // tableVariablesPresent has no pre constraints
        tableVariablesPresent35a = handleIsTableVariablesPresent();
        // tableVariablesPresent has no post constraints
        return tableVariablesPresent35a;
    }

    // ------------- associations ------------------

    private List<FrontEndParameter> __getTables1r;
    private boolean __getTables1rSet = false;

    /**
     * Represents a view within a front end application.
     * @return (List<FrontEndParameter>)handleGetTables()
     */
    public final List<FrontEndParameter> getTables()
    {
        List<FrontEndParameter> getTables1r = this.__getTables1r;
        if (!this.__getTables1rSet)
        {
            // frontEndView has no pre constraints
             List result = handleGetTables();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getTables1r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getTables List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndView has no post constraints
            this.__getTables1r = getTables1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTables1rSet = true;
            }
        }
        return getTables1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetTables();

    private List<FrontEndParameter> __getAllActionParameters2r;
    private boolean __getAllActionParameters2rSet = false;

    /**
     * Represents a view within a front end application.
     * @return (List<FrontEndParameter>)handleGetAllActionParameters()
     */
    public final List<FrontEndParameter> getAllActionParameters()
    {
        List<FrontEndParameter> getAllActionParameters2r = this.__getAllActionParameters2r;
        if (!this.__getAllActionParameters2rSet)
        {
            // frontEndView has no pre constraints
             List result = handleGetAllActionParameters();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllActionParameters2r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getAllActionParameters List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndView has no post constraints
            this.__getAllActionParameters2r = getAllActionParameters2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllActionParameters2rSet = true;
            }
        }
        return getAllActionParameters2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAllActionParameters();

    private List<FrontEndAction> __getActions3r;
    private boolean __getActions3rSet = false;

    /**
     * The StateVertex (FrontEndView or PseudostateFacade) on which this action can be triggered.
     * @return (List<FrontEndAction>)handleGetActions()
     */
    public final List<FrontEndAction> getActions()
    {
        List<FrontEndAction> getActions3r = this.__getActions3r;
        if (!this.__getActions3rSet)
        {
            // input has no pre constraints
             List result = handleGetActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getActions3r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // input has no post constraints
            this.__getActions3r = getActions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions3rSet = true;
            }
        }
        return getActions3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetActions();

    private List<FrontEndParameter> __getAllFormFields4r;
    private boolean __getAllFormFields4rSet = false;

    /**
     * Represents a view within a front end application.
     * @return (List<FrontEndParameter>)handleGetAllFormFields()
     */
    public final List<FrontEndParameter> getAllFormFields()
    {
        List<FrontEndParameter> getAllFormFields4r = this.__getAllFormFields4r;
        if (!this.__getAllFormFields4rSet)
        {
            // frontEndView has no pre constraints
             List result = handleGetAllFormFields();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllFormFields4r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getAllFormFields List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndView has no post constraints
            this.__getAllFormFields4r = getAllFormFields4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllFormFields4rSet = true;
            }
        }
        return getAllFormFields4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAllFormFields();

    private List<FrontEndParameter> __getVariables5r;
    private boolean __getVariables5rSet = false;

    /**
     * Represents the view in which this parameter will be used.
     * @return (List<FrontEndParameter>)handleGetVariables()
     */
    public final List<FrontEndParameter> getVariables()
    {
        List<FrontEndParameter> getVariables5r = this.__getVariables5r;
        if (!this.__getVariables5rSet)
        {
            // view has no pre constraints
             List result = handleGetVariables();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getVariables5r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getVariables List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // view has no post constraints
            this.__getVariables5r = getVariables5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getVariables5rSet = true;
            }
        }
        return getVariables5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetVariables();

    private FrontEndUseCase __getUseCase6r;
    private boolean __getUseCase6rSet = false;

    /**
     * All views that are part of this use case.
     * @return (FrontEndUseCase)handleGetUseCase()
     */
    public final FrontEndUseCase getUseCase()
    {
        FrontEndUseCase getUseCase6r = this.__getUseCase6r;
        if (!this.__getUseCase6rSet)
        {
            // views has no pre constraints
            Object result = handleGetUseCase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getUseCase6r = (FrontEndUseCase)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getUseCase FrontEndUseCase " + result + ": " + shieldedResult);
            }
            // views has no post constraints
            this.__getUseCase6r = getUseCase6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase6rSet = true;
            }
        }
        return getUseCase6r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetUseCase();

    /**
     * Represents a view within a front end application.
     * @return (Collection<FrontEndParameter>)handleGetBackingValueVariables()
     */
    public final Collection<FrontEndParameter> getBackingValueVariables()
    {
        Collection<FrontEndParameter> getBackingValueVariables7r = null;
        // frontEndView has no pre constraints
         Collection result = handleGetBackingValueVariables();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getBackingValueVariables7r = (Collection<FrontEndParameter>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getBackingValueVariables Collection<FrontEndParameter> " + result + ": " + shieldedResult);
        }
        // frontEndView has no post constraints
        return getBackingValueVariables7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetBackingValueVariables();

    /**
     * Represents a view within a front end application.
     * @return (Collection<AttributeFacade>)handleGetAttributes()
     */
    public final Collection<AttributeFacade> getAttributes()
    {
        Collection<AttributeFacade> getAttributes8r = null;
        // frontEndView has no pre constraints
         Collection result = handleGetAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAttributes8r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndViewLogic.logger.warn("incorrect metafacade cast for FrontEndViewLogic.getAttributes Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // frontEndView has no post constraints
        return getAttributes8r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAttributes();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndView::unique view name per usecase</p>
     * <p><b>Error:</b> Each name of a view action state must be unique in the namespace of a front-end use-case.</p>
     * <p><b>OCL:</b> context FrontEndView inv: useCase.views->isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndView::view variables must have unique names</p>
     * <p><b>Error:</b> Each view-variable should have a unique name within the context of a view.</p>
     * <p><b>OCL:</b> context FrontEndView inv : variables->isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndView::front-end views cannot defer operations</p>
     * <p><b>Error:</b> Views cannot defer to operations. All deferrable events modeled on a front-end view will be ignored.</p>
     * <p><b>OCL:</b> context FrontEndView inv: controllerCalls->size() = 0</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndView::each action going out of a front-end view must be unique</p>
     * <p><b>Error:</b> Each view must contain actions which each have a unique name, this view has actions with duplicate
names.</p>
     * <p><b>OCL:</b> context FrontEndView inv: actions->isUnique(name)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see FrontEndActionStateLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"useCase.views"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndView::unique view name per usecase",
                        "Each name of a view action state must be unique in the namespace of a front-end use-case."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndView::unique view name per usecase' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"variables"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndView::view variables must have unique names",
                        "Each view-variable should have a unique name within the context of a view."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndView::view variables must have unique names' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLExpressions.equal(OCLCollections.size(OCLIntrospector.invoke(contextElement,"controllerCalls")),0));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndView::front-end views cannot defer operations",
                        "Views cannot defer to operations. All deferrable events modeled on a front-end view will be ignored."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndView::front-end views cannot defer operations' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"actions"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndView::each action going out of a front-end view must be unique",
                        "Each view must contain actions which each have a unique name, this view has actions with duplicate\nnames."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndView::each action going out of a front-end view must be unique' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}