// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ExtendFacade;
import org.andromda.metafacades.uml.ExtensionPointFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Extend;

/**
 * A relationship from an extending use case to an extended use case that specifies how and when the
 * behavior defined in the extending use case can be inserted into the behavior defined in the
 * extended use case.
 * MetafacadeLogic for ExtendFacade
 *
 * @see ExtendFacade
 */
public abstract class ExtendFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements ExtendFacade
{
    /**
     * The underlying UML object
     * @see Extend
     */
    protected Extend metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ExtendFacadeLogic(Extend metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ExtendFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ExtendFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ExtendFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ExtendFacade
     */
    public boolean isExtendFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private List<ExtensionPointFacade> __getExtensionPoints1r;
    private boolean __getExtensionPoints1rSet = false;

    /**
     * A relationship from an extending use case to an extended use case that specifies how and when
     * the
     * behavior defined in the extending use case can be inserted into the behavior defined in the
     * extended
     * use case.
     * @return (List<ExtensionPointFacade>)handleGetExtensionPoints()
     */
    public final List<ExtensionPointFacade> getExtensionPoints()
    {
        List<ExtensionPointFacade> getExtensionPoints1r = this.__getExtensionPoints1r;
        if (!this.__getExtensionPoints1rSet)
        {
            // extendFacade has no pre constraints
            List result = handleGetExtensionPoints();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getExtensionPoints1r = (List<ExtensionPointFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ExtendFacadeLogic.logger.warn("incorrect metafacade cast for ExtendFacadeLogic.getExtensionPoints List<ExtensionPointFacade> " + result + ": " + shieldedResult);
            }
            // extendFacade has no post constraints
            this.__getExtensionPoints1r = getExtensionPoints1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtensionPoints1rSet = true;
            }
        }
        return getExtensionPoints1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetExtensionPoints();

    private UseCaseFacade __getBase2r;
    private boolean __getBase2rSet = false;

    /**
     * The extend instances related to this use-case.
     * @return (UseCaseFacade)handleGetBase()
     */
    public final UseCaseFacade getBase()
    {
        UseCaseFacade getBase2r = this.__getBase2r;
        if (!this.__getBase2rSet)
        {
            // extends has no pre constraints
            Object result = handleGetBase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getBase2r = (UseCaseFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ExtendFacadeLogic.logger.warn("incorrect metafacade cast for ExtendFacadeLogic.getBase UseCaseFacade " + result + ": " + shieldedResult);
            }
            // extends has no post constraints
            this.__getBase2r = getBase2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getBase2rSet = true;
            }
        }
        return getBase2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetBase();

    private UseCaseFacade __getExtension3r;
    private boolean __getExtension3rSet = false;

    /**
     * A relationship from an extending use case to an extended use case that specifies how and when
     * the
     * behavior defined in the extending use case can be inserted into the behavior defined in the
     * extended
     * use case.
     * @return (UseCaseFacade)handleGetExtension()
     */
    public final UseCaseFacade getExtension()
    {
        UseCaseFacade getExtension3r = this.__getExtension3r;
        if (!this.__getExtension3rSet)
        {
            // extendFacade has no pre constraints
            Object result = handleGetExtension();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getExtension3r = (UseCaseFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ExtendFacadeLogic.logger.warn("incorrect metafacade cast for ExtendFacadeLogic.getExtension UseCaseFacade " + result + ": " + shieldedResult);
            }
            // extendFacade has no post constraints
            this.__getExtension3r = getExtension3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtension3rSet = true;
            }
        }
        return getExtension3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetExtension();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}