// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndManageableEntityAttribute;
import org.andromda.metafacades.uml.ParameterFacade;

/**
 * TODO: Model Documentation for FrontEndManageableEntityAttribute
 * MetafacadeLogic for FrontEndManageableEntityAttribute
 *
 * @see FrontEndManageableEntityAttribute
 */
public abstract class FrontEndManageableEntityAttributeLogic
    extends ManageableEntityAttributeLogicImpl
    implements FrontEndManageableEntityAttribute
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndManageableEntityAttributeLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndManageableEntityAttribute if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndManageableEntityAttribute";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndManageableEntityAttribute
     */
    public boolean isFrontEndManageableEntityAttributeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndManageableEntityAttribute#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.messageKey
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey1a = null;
        // messageKey has no pre constraints
        messageKey1a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey1a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.messageValue
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue2a = null;
        // messageValue has no pre constraints
        messageValue2a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue2a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getDateFormat()
    * @return String
    */
    protected abstract String handleGetDateFormat();

    /**
     * The String format to use when referring to this date, only makes sense when the type is a
     * date type.
     * @return (String)handleGetDateFormat()
     */
    public final String getDateFormat()
    {
        String dateFormat3a = null;
        // dateFormat has no pre constraints
        dateFormat3a = handleGetDateFormat();
        // dateFormat has no post constraints
        return dateFormat3a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isNeedsFileUpload()
    * @return boolean
    */
    protected abstract boolean handleIsNeedsFileUpload();

    /**
     * True if this attribute is of a type that cannot easily be represented as a textual string and
     * would be an ideal candidate for HTTP's support for file-upload.
     * @return (boolean)handleIsNeedsFileUpload()
     */
    public final boolean isNeedsFileUpload()
    {
        boolean needsFileUpload4a = false;
        // needsFileUpload has no pre constraints
        needsFileUpload4a = handleIsNeedsFileUpload();
        // needsFileUpload has no post constraints
        return needsFileUpload4a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isHidden()
    * @return boolean
    */
    protected abstract boolean handleIsHidden();

    /**
     * Whether or not this attribute should be hidden from the view
     * @return (boolean)handleIsHidden()
     */
    public final boolean isHidden()
    {
        boolean hidden5a = false;
        // hidden has no pre constraints
        hidden5a = handleIsHidden();
        // hidden has no post constraints
        return hidden5a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getWidgetType()
    * @return String
    */
    protected abstract String handleGetWidgetType();

    /**
     * The widget to use when rendering this attribute
     * @return (String)handleGetWidgetType()
     */
    public final String getWidgetType()
    {
        String widgetType6a = null;
        // widgetType has no pre constraints
        widgetType6a = handleGetWidgetType();
        // widgetType has no post constraints
        return widgetType6a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isStrictDateFormat()
    * @return boolean
    */
    protected abstract boolean handleIsStrictDateFormat();

    /**
     * True if this field is a date type and the date format is not be interpreted strictly.
     * @return (boolean)handleIsStrictDateFormat()
     */
    public final boolean isStrictDateFormat()
    {
        boolean strictDateFormat7a = false;
        // strictDateFormat has no pre constraints
        strictDateFormat7a = handleIsStrictDateFormat();
        // strictDateFormat has no post constraints
        return strictDateFormat7a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getOnlineHelpKey()
    * @return String
    */
    protected abstract String handleGetOnlineHelpKey();

    /**
     * The key to lookup the online help documentation. This documentation is gathered from the
     * documentation entered by the user, as well as analyzing the model.
     * @return (String)handleGetOnlineHelpKey()
     */
    public final String getOnlineHelpKey()
    {
        String onlineHelpKey8a = null;
        // onlineHelpKey has no pre constraints
        onlineHelpKey8a = handleGetOnlineHelpKey();
        // onlineHelpKey has no post constraints
        return onlineHelpKey8a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getOnlineHelpValue()
    * @return String
    */
    protected abstract String handleGetOnlineHelpValue();

    /**
     * The online help documentation. This documentation is gathered from the documentation entered
     * by the user, as well as analyzing the model. The format is HTML without any style.
     * @return (String)handleGetOnlineHelpValue()
     */
    public final String getOnlineHelpValue()
    {
        String onlineHelpValue9a = null;
        // onlineHelpValue has no pre constraints
        onlineHelpValue9a = handleGetOnlineHelpValue();
        // onlineHelpValue has no post constraints
        return onlineHelpValue9a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getFormat()
    * @return String
    */
    protected abstract String handleGetFormat();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.format
     * @return (String)handleGetFormat()
     */
    public final String getFormat()
    {
        String format10a = null;
        // format has no pre constraints
        format10a = handleGetFormat();
        // format has no post constraints
        return format10a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getDefaultDateFormat()
    * @return String
    */
    protected abstract String handleGetDefaultDateFormat();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.defaultDateFormat
     * @return (String)handleGetDefaultDateFormat()
     */
    public final String getDefaultDateFormat()
    {
        String defaultDateFormat11a = null;
        // defaultDateFormat has no pre constraints
        defaultDateFormat11a = handleGetDefaultDateFormat();
        // defaultDateFormat has no post constraints
        return defaultDateFormat11a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getDefaultTimeFormat()
    * @return String
    */
    protected abstract String handleGetDefaultTimeFormat();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.defaultTimeFormat
     * @return (String)handleGetDefaultTimeFormat()
     */
    public final String getDefaultTimeFormat()
    {
        String defaultTimeFormat12a = null;
        // defaultTimeFormat has no pre constraints
        defaultTimeFormat12a = handleGetDefaultTimeFormat();
        // defaultTimeFormat has no post constraints
        return defaultTimeFormat12a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getDateFormatter()
    * @return String
    */
    protected abstract String handleGetDateFormatter();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.dateFormatter
     * @return (String)handleGetDateFormatter()
     */
    public final String getDateFormatter()
    {
        String dateFormatter13a = null;
        // dateFormatter has no pre constraints
        dateFormatter13a = handleGetDateFormatter();
        // dateFormatter has no post constraints
        return dateFormatter13a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getTimeFormatter()
    * @return String
    */
    protected abstract String handleGetTimeFormatter();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.timeFormatter
     * @return (String)handleGetTimeFormatter()
     */
    public final String getTimeFormatter()
    {
        String timeFormatter14a = null;
        // timeFormatter has no pre constraints
        timeFormatter14a = handleGetTimeFormatter();
        // timeFormatter has no post constraints
        return timeFormatter14a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getBackingListName()
    * @return String
    */
    protected abstract String handleGetBackingListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.backingListName
     * @return (String)handleGetBackingListName()
     */
    public final String getBackingListName()
    {
        String backingListName15a = null;
        // backingListName has no pre constraints
        backingListName15a = handleGetBackingListName();
        // backingListName has no post constraints
        return backingListName15a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getValueListName()
    * @return String
    */
    protected abstract String handleGetValueListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.valueListName
     * @return (String)handleGetValueListName()
     */
    public final String getValueListName()
    {
        String valueListName16a = null;
        // valueListName has no pre constraints
        valueListName16a = handleGetValueListName();
        // valueListName has no post constraints
        return valueListName16a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getLabelListName()
    * @return String
    */
    protected abstract String handleGetLabelListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.labelListName
     * @return (String)handleGetLabelListName()
     */
    public final String getLabelListName()
    {
        String labelListName17a = null;
        // labelListName has no pre constraints
        labelListName17a = handleGetLabelListName();
        // labelListName has no post constraints
        return labelListName17a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getValidatorTypes()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorTypes();

    /**
     * All validator types for this attribute.
     * @return (Collection)handleGetValidatorTypes()
     */
    public final Collection getValidatorTypes()
    {
        Collection validatorTypes18a = null;
        // validatorTypes has no pre constraints
        validatorTypes18a = handleGetValidatorTypes();
        // validatorTypes has no post constraints
        return validatorTypes18a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not this attribute requires some kind of validation (the collection of
     * validator types is not empty).
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired19a = false;
        // validationRequired has no pre constraints
        validationRequired19a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired19a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getValidWhen()
    * @return String
    */
    protected abstract String handleGetValidWhen();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.validWhen
     * @return (String)handleGetValidWhen()
     */
    public final String getValidWhen()
    {
        String validWhen20a = null;
        // validWhen has no pre constraints
        validWhen20a = handleGetValidWhen();
        // validWhen has no post constraints
        return validWhen20a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputCheckbox()
    * @return boolean
    */
    protected abstract boolean handleIsInputCheckbox();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputCheckbox
     * @return (boolean)handleIsInputCheckbox()
     */
    public final boolean isInputCheckbox()
    {
        boolean inputCheckbox21a = false;
        // inputCheckbox has no pre constraints
        inputCheckbox21a = handleIsInputCheckbox();
        // inputCheckbox has no post constraints
        return inputCheckbox21a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputFile()
    * @return boolean
    */
    protected abstract boolean handleIsInputFile();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputFile
     * @return (boolean)handleIsInputFile()
     */
    public final boolean isInputFile()
    {
        boolean inputFile22a = false;
        // inputFile has no pre constraints
        inputFile22a = handleIsInputFile();
        // inputFile has no post constraints
        return inputFile22a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputHidden()
    * @return boolean
    */
    protected abstract boolean handleIsInputHidden();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputHidden
     * @return (boolean)handleIsInputHidden()
     */
    public final boolean isInputHidden()
    {
        boolean inputHidden23a = false;
        // inputHidden has no pre constraints
        inputHidden23a = handleIsInputHidden();
        // inputHidden has no post constraints
        return inputHidden23a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputMultibox()
    * @return boolean
    */
    protected abstract boolean handleIsInputMultibox();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputMultibox
     * @return (boolean)handleIsInputMultibox()
     */
    public final boolean isInputMultibox()
    {
        boolean inputMultibox24a = false;
        // inputMultibox has no pre constraints
        inputMultibox24a = handleIsInputMultibox();
        // inputMultibox has no post constraints
        return inputMultibox24a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputRadio()
    * @return boolean
    */
    protected abstract boolean handleIsInputRadio();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputRadio
     * @return (boolean)handleIsInputRadio()
     */
    public final boolean isInputRadio()
    {
        boolean inputRadio25a = false;
        // inputRadio has no pre constraints
        inputRadio25a = handleIsInputRadio();
        // inputRadio has no post constraints
        return inputRadio25a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputSecret()
    * @return boolean
    */
    protected abstract boolean handleIsInputSecret();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputSecret
     * @return (boolean)handleIsInputSecret()
     */
    public final boolean isInputSecret()
    {
        boolean inputSecret26a = false;
        // inputSecret has no pre constraints
        inputSecret26a = handleIsInputSecret();
        // inputSecret has no post constraints
        return inputSecret26a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputSelect()
    * @return boolean
    */
    protected abstract boolean handleIsInputSelect();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputSelect
     * @return (boolean)handleIsInputSelect()
     */
    public final boolean isInputSelect()
    {
        boolean inputSelect27a = false;
        // inputSelect has no pre constraints
        inputSelect27a = handleIsInputSelect();
        // inputSelect has no post constraints
        return inputSelect27a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputTable()
    * @return boolean
    */
    protected abstract boolean handleIsInputTable();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputTable
     * @return (boolean)handleIsInputTable()
     */
    public final boolean isInputTable()
    {
        boolean inputTable28a = false;
        // inputTable has no pre constraints
        inputTable28a = handleIsInputTable();
        // inputTable has no post constraints
        return inputTable28a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getInputTableIdentifierColumns()
    * @return String
    */
    protected abstract String handleGetInputTableIdentifierColumns();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputTableIdentifierColumns
     * @return (String)handleGetInputTableIdentifierColumns()
     */
    public final String getInputTableIdentifierColumns()
    {
        String inputTableIdentifierColumns29a = null;
        // inputTableIdentifierColumns has no pre constraints
        inputTableIdentifierColumns29a = handleGetInputTableIdentifierColumns();
        // inputTableIdentifierColumns has no post constraints
        return inputTableIdentifierColumns29a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputText()
    * @return boolean
    */
    protected abstract boolean handleIsInputText();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputText
     * @return (boolean)handleIsInputText()
     */
    public final boolean isInputText()
    {
        boolean inputText30a = false;
        // inputText has no pre constraints
        inputText30a = handleIsInputText();
        // inputText has no post constraints
        return inputText30a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputTextarea()
    * @return boolean
    */
    protected abstract boolean handleIsInputTextarea();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputTextarea
     * @return (boolean)handleIsInputTextarea()
     */
    public final boolean isInputTextarea()
    {
        boolean inputTextarea31a = false;
        // inputTextarea has no pre constraints
        inputTextarea31a = handleIsInputTextarea();
        // inputTextarea has no post constraints
        return inputTextarea31a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputTypePresent()
    * @return boolean
    */
    protected abstract boolean handleIsInputTypePresent();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.inputTypePresent
     * @return (boolean)handleIsInputTypePresent()
     */
    public final boolean isInputTypePresent()
    {
        boolean inputTypePresent32a = false;
        // inputTypePresent has no pre constraints
        inputTypePresent32a = handleIsInputTypePresent();
        // inputTypePresent has no post constraints
        return inputTypePresent32a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getDummyValue()
    * @return String
    */
    protected abstract String handleGetDummyValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.dummyValue
     * @return (String)handleGetDummyValue()
     */
    public final String getDummyValue()
    {
        String dummyValue33a = null;
        // dummyValue has no pre constraints
        dummyValue33a = handleGetDummyValue();
        // dummyValue has no post constraints
        return dummyValue33a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isEqualValidator()
    * @return boolean
    */
    protected abstract boolean handleIsEqualValidator();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.equalValidator
     * @return (boolean)handleIsEqualValidator()
     */
    public final boolean isEqualValidator()
    {
        boolean equalValidator34a = false;
        // equalValidator has no pre constraints
        equalValidator34a = handleIsEqualValidator();
        // equalValidator has no post constraints
        return equalValidator34a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isPlaintext()
    * @return boolean
    */
    protected abstract boolean handleIsPlaintext();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.plaintext
     * @return (boolean)handleIsPlaintext()
     */
    public final boolean isPlaintext()
    {
        boolean plaintext35a = false;
        // plaintext has no pre constraints
        plaintext35a = handleIsPlaintext();
        // plaintext has no post constraints
        return plaintext35a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getValueListDummyValue()
    * @return String
    */
    protected abstract String handleGetValueListDummyValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.valueListDummyValue
     * @return (String)handleGetValueListDummyValue()
     */
    public final String getValueListDummyValue()
    {
        String valueListDummyValue36a = null;
        // valueListDummyValue has no pre constraints
        valueListDummyValue36a = handleGetValueListDummyValue();
        // valueListDummyValue has no post constraints
        return valueListDummyValue36a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getValidatorVars()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorVars();

    /**
     * The validator variables.
     * @return (Collection)handleGetValidatorVars()
     */
    public final Collection getValidatorVars()
    {
        Collection validatorVars37a = null;
        // validatorVars has no pre constraints
        validatorVars37a = handleGetValidatorVars();
        // validatorVars has no post constraints
        return validatorVars37a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#getMaxLength()
    * @return String
    */
    protected abstract String handleGetMaxLength();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMaxLength()
     */
    public final String getMaxLength()
    {
        String maxLength38a = null;
        // maxLength has no pre constraints
        maxLength38a = handleGetMaxLength();
        // maxLength has no post constraints
        return maxLength38a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isEditable()
    * @return boolean
    */
    protected abstract boolean handleIsEditable();

    /**
     * Whether or not this attribute should be put in the view
     * @return (boolean)handleIsEditable()
     */
    public final boolean isEditable()
    {
        boolean editable39a = false;
        // editable has no pre constraints
        editable39a = handleIsEditable();
        // editable has no post constraints
        return editable39a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputButton()
    * @return boolean
    */
    protected abstract boolean handleIsInputButton();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputButton()
     */
    public final boolean isInputButton()
    {
        boolean inputButton40a = false;
        // inputButton has no pre constraints
        inputButton40a = handleIsInputButton();
        // inputButton has no post constraints
        return inputButton40a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputColor()
    * @return boolean
    */
    protected abstract boolean handleIsInputColor();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputColor()
     */
    public final boolean isInputColor()
    {
        boolean inputColor41a = false;
        // inputColor has no pre constraints
        inputColor41a = handleIsInputColor();
        // inputColor has no post constraints
        return inputColor41a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputDate()
    * @return boolean
    */
    protected abstract boolean handleIsInputDate();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputDate()
     */
    public final boolean isInputDate()
    {
        boolean inputDate42a = false;
        // inputDate has no pre constraints
        inputDate42a = handleIsInputDate();
        // inputDate has no post constraints
        return inputDate42a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputDatetimeLocal()
    * @return boolean
    */
    protected abstract boolean handleIsInputDatetimeLocal();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return (boolean)handleIsInputDatetimeLocal()
     */
    public final boolean isInputDatetimeLocal()
    {
        boolean inputDatetimeLocal43a = false;
        // inputDatetimeLocal has no pre constraints
        inputDatetimeLocal43a = handleIsInputDatetimeLocal();
        // inputDatetimeLocal has no post constraints
        return inputDatetimeLocal43a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputEmail()
    * @return boolean
    */
    protected abstract boolean handleIsInputEmail();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputEmail()
     */
    public final boolean isInputEmail()
    {
        boolean inputEmail44a = false;
        // inputEmail has no pre constraints
        inputEmail44a = handleIsInputEmail();
        // inputEmail has no post constraints
        return inputEmail44a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputImage()
    * @return boolean
    */
    protected abstract boolean handleIsInputImage();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputImage()
     */
    public final boolean isInputImage()
    {
        boolean inputImage45a = false;
        // inputImage has no pre constraints
        inputImage45a = handleIsInputImage();
        // inputImage has no post constraints
        return inputImage45a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputMonth()
    * @return boolean
    */
    protected abstract boolean handleIsInputMonth();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputMonth()
     */
    public final boolean isInputMonth()
    {
        boolean inputMonth46a = false;
        // inputMonth has no pre constraints
        inputMonth46a = handleIsInputMonth();
        // inputMonth has no post constraints
        return inputMonth46a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputNumber()
    * @return boolean
    */
    protected abstract boolean handleIsInputNumber();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputNumber()
     */
    public final boolean isInputNumber()
    {
        boolean inputNumber47a = false;
        // inputNumber has no pre constraints
        inputNumber47a = handleIsInputNumber();
        // inputNumber has no post constraints
        return inputNumber47a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputRange()
    * @return boolean
    */
    protected abstract boolean handleIsInputRange();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputRange()
     */
    public final boolean isInputRange()
    {
        boolean inputRange48a = false;
        // inputRange has no pre constraints
        inputRange48a = handleIsInputRange();
        // inputRange has no post constraints
        return inputRange48a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputReset()
    * @return boolean
    */
    protected abstract boolean handleIsInputReset();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputReset()
     */
    public final boolean isInputReset()
    {
        boolean inputReset49a = false;
        // inputReset has no pre constraints
        inputReset49a = handleIsInputReset();
        // inputReset has no post constraints
        return inputReset49a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputSearch()
    * @return boolean
    */
    protected abstract boolean handleIsInputSearch();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputSearch()
     */
    public final boolean isInputSearch()
    {
        boolean inputSearch50a = false;
        // inputSearch has no pre constraints
        inputSearch50a = handleIsInputSearch();
        // inputSearch has no post constraints
        return inputSearch50a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputSubmit()
    * @return boolean
    */
    protected abstract boolean handleIsInputSubmit();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputSubmit()
     */
    public final boolean isInputSubmit()
    {
        boolean inputSubmit51a = false;
        // inputSubmit has no pre constraints
        inputSubmit51a = handleIsInputSubmit();
        // inputSubmit has no post constraints
        return inputSubmit51a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputTel()
    * @return boolean
    */
    protected abstract boolean handleIsInputTel();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputTel()
     */
    public final boolean isInputTel()
    {
        boolean inputTel52a = false;
        // inputTel has no pre constraints
        inputTel52a = handleIsInputTel();
        // inputTel has no post constraints
        return inputTel52a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputTime()
    * @return boolean
    */
    protected abstract boolean handleIsInputTime();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputTime()
     */
    public final boolean isInputTime()
    {
        boolean inputTime53a = false;
        // inputTime has no pre constraints
        inputTime53a = handleIsInputTime();
        // inputTime has no post constraints
        return inputTime53a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputUrl()
    * @return boolean
    */
    protected abstract boolean handleIsInputUrl();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputUrl()
     */
    public final boolean isInputUrl()
    {
        boolean inputUrl54a = false;
        // inputUrl has no pre constraints
        inputUrl54a = handleIsInputUrl();
        // inputUrl has no post constraints
        return inputUrl54a;
    }

   /**
    * @see FrontEndManageableEntityAttribute#isInputWeek()
    * @return boolean
    */
    protected abstract boolean handleIsInputWeek();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputWeek()
     */
    public final boolean isInputWeek()
    {
        boolean inputWeek55a = false;
        // inputWeek has no pre constraints
        inputWeek55a = handleIsInputWeek();
        // inputWeek has no post constraints
        return inputWeek55a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.getValidatorArgs
     * @param validatorType
     * @return Collection
     */
    protected abstract Collection handleGetValidatorArgs(String validatorType);

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.getValidatorArgs
     * @param validatorType String
     * TODO: Model Documentation for
     * FrontEndManageableEntityAttribute.getValidatorArgs(validatorType)
     * @return handleGetValidatorArgs(validatorType)
     */
    public Collection getValidatorArgs(String validatorType)
    {
        // getValidatorArgs has no pre constraints
        Collection returnValue = handleGetValidatorArgs(validatorType);
        // getValidatorArgs has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the unique id of this attribute on the form.
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetFormPropertyId(ParameterFacade ownerParameter);

    /**
     * Gets the unique id of this attribute on the form.
     * @param ownerParameter ParameterFacade
     * The parameter that is the owner of this attribute.
     * @return handleGetFormPropertyId(ownerParameter)
     */
    public String getFormPropertyId(ParameterFacade ownerParameter)
    {
        // getFormPropertyId has no pre constraints
        String returnValue = handleGetFormPropertyId(ownerParameter);
        // getFormPropertyId has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Retrieves the name of the form property for this attribute by taking the name of the owner
     * property.
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetFormPropertyName(ParameterFacade ownerParameter);

    /**
     * Retrieves the name of the form property for this attribute by taking the name of the owner
     * property.
     * @param ownerParameter ParameterFacade
     * The parent that is the owner of this parameter.
     * @return handleGetFormPropertyName(ownerParameter)
     */
    public String getFormPropertyName(ParameterFacade ownerParameter)
    {
        // getFormPropertyName has no pre constraints
        String returnValue = handleGetFormPropertyName(ownerParameter);
        // getFormPropertyName has no post constraints
        return returnValue;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ManageableEntityAttributeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}