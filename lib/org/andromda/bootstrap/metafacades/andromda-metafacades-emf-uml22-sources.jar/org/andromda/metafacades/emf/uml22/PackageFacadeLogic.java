// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.PackageFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Package;

/**
 * Used to group elements, and provides a namespace for the grouped elements. A package can have one
 * or more profile applications to indicate which profiles have been applied. Because a profile is a
 * package, it is possible to apply a profile not only to packages, but also to profiles. Package
 * specializes TemplateableElement and PackageableElement specializes ParameterableElement to
 * specify that a package can be used as a template and a PackageableElement as a template
 * parameter.
 * MetafacadeLogic for PackageFacade
 *
 * @see PackageFacade
 */
public abstract class PackageFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements PackageFacade
{
    /**
     * The underlying UML object
     * @see Package
     */
    protected Package metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected PackageFacadeLogic(Package metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(PackageFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to PackageFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PackageFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see PackageFacade
     */
    public boolean isPackageFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see PackageFacade#getTablePrefix()
    * @return String
    */
    protected abstract String handleGetTablePrefix();

    /**
     * The Entity table prefix to be used for this package.
     * @return (String)handleGetTablePrefix()
     */
    public final String getTablePrefix()
    {
        String tablePrefix1a = null;
        // tablePrefix has no pre constraints
        tablePrefix1a = handleGetTablePrefix();
        // tablePrefix has no post constraints
        return tablePrefix1a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Finds the model element with the given 'fullyQualifiedName', or returns null if one can't be
     * found with that name.
     * @param fullyQualifiedName
     * @return ModelElementFacade
     */
    protected abstract ModelElementFacade handleFindModelElement(String fullyQualifiedName);

    /**
     * Finds the model element with the given 'fullyQualifiedName', or returns null if one can't be
     * found with that name.
     * @param fullyQualifiedName String
     * The fully qualified name of the model element to find.
     * @return handleFindModelElement(fullyQualifiedName)
     */
    public ModelElementFacade findModelElement(String fullyQualifiedName)
    {
        // findModelElement has no pre constraints
        ModelElementFacade returnValue = handleFindModelElement(fullyQualifiedName);
        // findModelElement has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * Used to group elements, and provides a namespace for the grouped elements. A package can have
     * one or
     * more profile applications to indicate which profiles have been applied. Because a profile is
     * a
     * package, it is possible to apply a profile not only to packages, but also to profiles.
     * Package
     * specializes TemplateableElement and PackageableElement specializes ParameterableElement to
     * specify
     * that a package can be used as a template and a PackageableElement as a template parameter.
     * @return (Collection<ClassifierFacade>)handleGetClasses()
     */
    public final Collection<ClassifierFacade> getClasses()
    {
        Collection<ClassifierFacade> getClasses1r = null;
        // packageFacade has no pre constraints
         Collection result = handleGetClasses();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getClasses1r = (Collection<ClassifierFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            PackageFacadeLogic.logger.warn("incorrect metafacade cast for PackageFacadeLogic.getClasses Collection<ClassifierFacade> " + result + ": " + shieldedResult);
        }
        // packageFacade has no post constraints
        return getClasses1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetClasses();

    /**
     * Gets the root package for the model element.
     * @return (Collection<ModelElementFacade>)handleGetModelElements()
     */
    public final Collection<ModelElementFacade> getModelElements()
    {
        Collection<ModelElementFacade> getModelElements2r = null;
        // rootPackage has no pre constraints
         Collection result = handleGetModelElements();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getModelElements2r = (Collection<ModelElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            PackageFacadeLogic.logger.warn("incorrect metafacade cast for PackageFacadeLogic.getModelElements Collection<ModelElementFacade> " + result + ": " + shieldedResult);
        }
        // rootPackage has no post constraints
        return getModelElements2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetModelElements();

    /**
     * Used to group elements, and provides a namespace for the grouped elements. A package can have
     * one or
     * more profile applications to indicate which profiles have been applied. Because a profile is
     * a
     * package, it is possible to apply a profile not only to packages, but also to profiles.
     * Package
     * specializes TemplateableElement and PackageableElement specializes ParameterableElement to
     * specify
     * that a package can be used as a template and a PackageableElement as a template parameter.
     * @return (Collection<PackageFacade>)handleGetSubPackages()
     */
    public final Collection<PackageFacade> getSubPackages()
    {
        Collection<PackageFacade> getSubPackages3r = null;
        // packageFacade has no pre constraints
         Collection result = handleGetSubPackages();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getSubPackages3r = (Collection<PackageFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            PackageFacadeLogic.logger.warn("incorrect metafacade cast for PackageFacadeLogic.getSubPackages Collection<PackageFacade> " + result + ": " + shieldedResult);
        }
        // packageFacade has no post constraints
        return getSubPackages3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetSubPackages();

    /**
     * Used to group elements, and provides a namespace for the grouped elements. A package can have
     * one or
     * more profile applications to indicate which profiles have been applied. Because a profile is
     * a
     * package, it is possible to apply a profile not only to packages, but also to profiles.
     * Package
     * specializes TemplateableElement and PackageableElement specializes ParameterableElement to
     * specify
     * that a package can be used as a template and a PackageableElement as a template parameter.
     * @return (Collection<ModelElementFacade>)handleGetOwnedElements()
     */
    public final Collection<ModelElementFacade> getOwnedElements()
    {
        Collection<ModelElementFacade> getOwnedElements4r = null;
        // packageFacade has no pre constraints
         Collection result = handleGetOwnedElements();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getOwnedElements4r = (Collection<ModelElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            PackageFacadeLogic.logger.warn("incorrect metafacade cast for PackageFacadeLogic.getOwnedElements Collection<ModelElementFacade> " + result + ": " + shieldedResult);
        }
        // packageFacade has no post constraints
        return getOwnedElements4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOwnedElements();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}