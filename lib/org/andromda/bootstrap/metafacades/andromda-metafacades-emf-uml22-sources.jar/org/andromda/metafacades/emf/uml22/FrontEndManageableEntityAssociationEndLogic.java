// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndManageableEntityAssociationEnd;

/**
 * TODO: Model Documentation for FrontEndManageableEntityAssociationEnd
 * MetafacadeLogic for FrontEndManageableEntityAssociationEnd
 *
 * @see FrontEndManageableEntityAssociationEnd
 */
public abstract class FrontEndManageableEntityAssociationEndLogic
    extends ManageableEntityAssociationEndLogicImpl
    implements FrontEndManageableEntityAssociationEnd
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndManageableEntityAssociationEndLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndManageableEntityAssociationEnd if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndManageableEntityAssociationEnd";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndManageableEntityAssociationEnd
     */
    public boolean isFrontEndManageableEntityAssociationEndMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndManageableEntityAssociationEnd#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAssociationEnd.messageKey
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey1a = null;
        // messageKey has no pre constraints
        messageKey1a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey1a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAssociationEnd.messageValue
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue2a = null;
        // messageValue has no pre constraints
        messageValue2a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue2a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getOnlineHelpKey()
    * @return String
    */
    protected abstract String handleGetOnlineHelpKey();

    /**
     * The key to lookup the online help documentation. This documentation is gathered from the
     * documentation entered by the user, as well as analyzing the model.
     * @return (String)handleGetOnlineHelpKey()
     */
    public final String getOnlineHelpKey()
    {
        String onlineHelpKey3a = null;
        // onlineHelpKey has no pre constraints
        onlineHelpKey3a = handleGetOnlineHelpKey();
        // onlineHelpKey has no post constraints
        return onlineHelpKey3a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getOnlineHelpValue()
    * @return String
    */
    protected abstract String handleGetOnlineHelpValue();

    /**
     * The online help documentation. This documentation is gathered from the documentation entered
     * by the user, as well as analyzing the model. The format is HTML without any style.
     * @return (String)handleGetOnlineHelpValue()
     */
    public final String getOnlineHelpValue()
    {
        String onlineHelpValue4a = null;
        // onlineHelpValue has no pre constraints
        onlineHelpValue4a = handleGetOnlineHelpValue();
        // onlineHelpValue has no post constraints
        return onlineHelpValue4a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getBackingListName()
    * @return String
    */
    protected abstract String handleGetBackingListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAssociationEnd.backingListName
     * @return (String)handleGetBackingListName()
     */
    public final String getBackingListName()
    {
        String backingListName5a = null;
        // backingListName has no pre constraints
        backingListName5a = handleGetBackingListName();
        // backingListName has no post constraints
        return backingListName5a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getValueListName()
    * @return String
    */
    protected abstract String handleGetValueListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAssociationEnd.valueListName
     * @return (String)handleGetValueListName()
     */
    public final String getValueListName()
    {
        String valueListName6a = null;
        // valueListName has no pre constraints
        valueListName6a = handleGetValueListName();
        // valueListName has no post constraints
        return valueListName6a;
    }

   /**
    * @see FrontEndManageableEntityAssociationEnd#getLabelListName()
    * @return String
    */
    protected abstract String handleGetLabelListName();

    /**
     * TODO: Model Documentation for
     * FrontEndManageableEntityAssociationEnd.labelListName
     * @return (String)handleGetLabelListName()
     */
    public final String getLabelListName()
    {
        String labelListName7a = null;
        // labelListName has no pre constraints
        labelListName7a = handleGetLabelListName();
        // labelListName has no post constraints
        return labelListName7a;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ManageableEntityAssociationEndLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}