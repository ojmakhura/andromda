// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.EventFacade;
import org.andromda.metafacades.uml.ParameterFacade;
import org.andromda.metafacades.uml.StateFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Activity;

/**
 * A representation of the model object 'Activity'. The specification of parameterized behavior as
 * the coordinated sequencing of subordinate units whose individual elements are actions.
 * MetafacadeLogic for EventFacade
 *
 * @see EventFacade
 */
public abstract class EventFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements EventFacade
{
    /**
     * The underlying UML object
     * @see Activity
     */
    protected Activity metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EventFacadeLogic(Activity metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(EventFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EventFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EventFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EventFacade
     */
    public boolean isEventFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * If this parameter is located on an event, this will represent that event.
     * @return (Collection<ParameterFacade>)handleGetParameters()
     */
    public final Collection<ParameterFacade> getParameters()
    {
        Collection<ParameterFacade> getParameters1r = null;
        // event has no pre constraints
         Collection result = handleGetParameters();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getParameters1r = (Collection<ParameterFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EventFacadeLogic.logger.warn("incorrect metafacade cast for EventFacadeLogic.getParameters Collection<ParameterFacade> " + result + ": " + shieldedResult);
        }
        // event has no post constraints
        return getParameters1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetParameters();

    /**
     * If a trigger is present on this transition, this event represents that trigger.
     * @return (TransitionFacade)handleGetTransition()
     */
    public final TransitionFacade getTransition()
    {
        TransitionFacade getTransition2r = null;
        // trigger has no pre constraints
        Object result = handleGetTransition();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTransition2r = (TransitionFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EventFacadeLogic.logger.warn("incorrect metafacade cast for EventFacadeLogic.getTransition TransitionFacade " + result + ": " + shieldedResult);
        }
        // trigger has no post constraints
        return getTransition2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTransition();

    /**
     * Events to which is being deferred in this action state.
     * @return (StateFacade)handleGetState()
     */
    public final StateFacade getState()
    {
        StateFacade getState3r = null;
        // deferrableEvents has no pre constraints
        Object result = handleGetState();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getState3r = (StateFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EventFacadeLogic.logger.warn("incorrect metafacade cast for EventFacadeLogic.getState StateFacade " + result + ": " + shieldedResult);
        }
        // deferrableEvents has no post constraints
        return getState3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetState();

    /**
     * A representation of the model object 'Activity'. The specification of parameterized behavior
     * as the
     * coordinated sequencing of subordinate units whose individual elements are actions.
     * @return (Collection<AttributeFacade>)handleGetAttributes()
     */
    public final Collection<AttributeFacade> getAttributes()
    {
        Collection<AttributeFacade> getAttributes4r = null;
        // eventFacade has no pre constraints
         Collection result = handleGetAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAttributes4r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EventFacadeLogic.logger.warn("incorrect metafacade cast for EventFacadeLogic.getAttributes Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // eventFacade has no post constraints
        return getAttributes4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAttributes();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}