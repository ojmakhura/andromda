// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActionState;
import org.andromda.metafacades.uml.FrontEndExceptionHandler;
import org.andromda.metafacades.uml.FrontEndForward;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.State;

/**
 * Represents an operation on the server called by an action. Optionally may defer operations to the
 * controller.
 * MetafacadeLogic for FrontEndActionState
 *
 * @see FrontEndActionState
 */
public abstract class FrontEndActionStateLogic
    extends ActionStateFacadeLogicImpl
    implements FrontEndActionState
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndActionStateLogic(Object metaObjectIn, String context)
    {
        super((State)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndActionStateLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndActionState if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndActionState";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndActionState
     */
    public boolean isFrontEndActionStateMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndActionState#isServerSide()
    * @return boolean
    */
    protected abstract boolean handleIsServerSide();

    /**
     * Indicates whether or not this front end action state is server side. Pages, for example, are
     * also action states but they return control to the client.
     * @return (boolean)handleIsServerSide()
     */
    public final boolean isServerSide()
    {
        boolean serverSide1a = false;
        // serverSide has no pre constraints
        serverSide1a = handleIsServerSide();
        // serverSide has no post constraints
        return serverSide1a;
    }

   /**
    * @see FrontEndActionState#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * True if this element is contained in a FrontEndUseCase.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase2a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase2a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase2a;
    }

   /**
    * @see FrontEndActionState#getActionMethodName()
    * @return String
    */
    protected abstract String handleGetActionMethodName();

    /**
     * The method name representing this action state.
     * @return (String)handleGetActionMethodName()
     */
    public final String getActionMethodName()
    {
        String actionMethodName3a = null;
        // actionMethodName has no pre constraints
        actionMethodName3a = handleGetActionMethodName();
        // actionMethodName has no post constraints
        return actionMethodName3a;
    }

   /**
    * @see FrontEndActionState#getServiceCalls()
    * @return List<OperationFacade>
    */
    protected abstract List<OperationFacade> handleGetServiceCalls();

    /**
     * All calls deferred to the services by this action state.
     * @return (List<OperationFacade>)handleGetServiceCalls()
     */
    public final List<OperationFacade> getServiceCalls()
    {
        List<OperationFacade> serviceCalls4a = null;
        // serviceCalls has no pre constraints
        serviceCalls4a = handleGetServiceCalls();
        // serviceCalls has no post constraints
        return serviceCalls4a;
    }

    // ------------- associations ------------------

    private List<FrontEndAction> __getContainerActions1r;
    private boolean __getContainerActions1rSet = false;

    /**
     * All action states visited by this action.
     * @return (List<FrontEndAction>)handleGetContainerActions()
     */
    public final List<FrontEndAction> getContainerActions()
    {
        List<FrontEndAction> getContainerActions1r = this.__getContainerActions1r;
        if (!this.__getContainerActions1rSet)
        {
            // actionStates has no pre constraints
             List result = handleGetContainerActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getContainerActions1r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionStateLogic.logger.warn("incorrect metafacade cast for FrontEndActionStateLogic.getContainerActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // actionStates has no post constraints
            this.__getContainerActions1r = getContainerActions1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getContainerActions1rSet = true;
            }
        }
        return getContainerActions1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetContainerActions();

    private List<OperationFacade> __getControllerCalls2r;
    private boolean __getControllerCalls2rSet = false;

    /**
     * Represents an operation on the server called by an action. Optionally may defer operations to
     * the
     * controller.
     * @return (List<OperationFacade>)handleGetControllerCalls()
     */
    public final List<OperationFacade> getControllerCalls()
    {
        List<OperationFacade> getControllerCalls2r = this.__getControllerCalls2r;
        if (!this.__getControllerCalls2rSet)
        {
            // frontEndActionState has no pre constraints
             List result = handleGetControllerCalls();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getControllerCalls2r = (List<OperationFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionStateLogic.logger.warn("incorrect metafacade cast for FrontEndActionStateLogic.getControllerCalls List<OperationFacade> " + result + ": " + shieldedResult);
            }
            // frontEndActionState has no post constraints
            this.__getControllerCalls2r = getControllerCalls2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerCalls2rSet = true;
            }
        }
        return getControllerCalls2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetControllerCalls();

    private List<FrontEndExceptionHandler> __getExceptions3r;
    private boolean __getExceptions3rSet = false;

    /**
     * Represents an operation on the server called by an action. Optionally may defer operations to
     * the
     * controller.
     * @return (List<FrontEndExceptionHandler>)handleGetExceptions()
     */
    public final List<FrontEndExceptionHandler> getExceptions()
    {
        List<FrontEndExceptionHandler> getExceptions3r = this.__getExceptions3r;
        if (!this.__getExceptions3rSet)
        {
            // frontEndActionState has no pre constraints
             List result = handleGetExceptions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getExceptions3r = (List<FrontEndExceptionHandler>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionStateLogic.logger.warn("incorrect metafacade cast for FrontEndActionStateLogic.getExceptions List<FrontEndExceptionHandler> " + result + ": " + shieldedResult);
            }
            // frontEndActionState has no post constraints
            this.__getExceptions3r = getExceptions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExceptions3rSet = true;
            }
        }
        return getExceptions3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetExceptions();

    private FrontEndForward __getForward4r;
    private boolean __getForward4rSet = false;

    /**
     * Represents an operation on the server called by an action. Optionally may defer operations to
     * the
     * controller.
     * @return (FrontEndForward)handleGetForward()
     */
    public final FrontEndForward getForward()
    {
        FrontEndForward getForward4r = this.__getForward4r;
        if (!this.__getForward4rSet)
        {
            // frontEndActionState has no pre constraints
            Object result = handleGetForward();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getForward4r = (FrontEndForward)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActionStateLogic.logger.warn("incorrect metafacade cast for FrontEndActionStateLogic.getForward FrontEndForward " + result + ": " + shieldedResult);
            }
            // frontEndActionState has no post constraints
            this.__getForward4r = getForward4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getForward4rSet = true;
            }
        }
        return getForward4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetForward();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndActionState::each front-end action state must have a name</p>
     * <p><b>Error:</b> A "front-end" action state must have a non-empty name.</p>
     * <p><b>OCL:</b> context FrontEndActionState inv: name->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndActionState::front-end action states can have at most one outgoing transition</p>
     * <p><b>Error:</b> A "front-end" action state needs at most one outgoing transition that is not an
exception-transition.</p>
     * <p><b>OCL:</b> context FrontEndActionState inv: serverSide implies (exceptions->size() + 1 = outgoings->size() or exceptions->size() = outgoings->size())</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ActionStateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndActionState::each front-end action state must have a name",
                        "A \"front-end\" action state must have a non-empty name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndActionState::each front-end action state must have a name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"serverSide"))).booleanValue()?(OCLExpressions.equal(OCLCollections.size(OCLIntrospector.invoke(contextElement,"exceptions"))+1,OCLCollections.size(OCLIntrospector.invoke(contextElement,"outgoings")))||OCLExpressions.equal(OCLCollections.size(OCLIntrospector.invoke(contextElement,"exceptions")),OCLCollections.size(OCLIntrospector.invoke(contextElement,"outgoings")))):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndActionState::front-end action states can have at most one outgoing transition",
                        "A \"front-end\" action state needs at most one outgoing transition that is not an\nexception-transition."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndActionState::front-end action states can have at most one outgoing transition' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}