// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AssociationEndFacade;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Transformer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * A Classifier is a classification of instances - it describes a set of instances that have
 * features in common. Can specify a generalization hierarchy by referencing its general
 * classifiers. It may be a Class, DataType, PrimitiveType, Association, Collaboration, UseCase,
 * etc. Can specify a generalization hierarchy by referencing its general classifiers. Has the
 * capability to own collaboration uses. These collaboration uses link a collaboration with the
 * classifier to give a description of the workings of the classifier. Classifier is defined to be a
 * kind of templateable element so that a classifier can be parameterized. It is also defined to be
 * a kind of parameterable element so that a classifier can be a formal template parameter.
 * MetafacadeLogic for ClassifierFacade
 *
 * @see ClassifierFacade
 */
public abstract class ClassifierFacadeLogic
    extends GeneralizableElementFacadeLogicImpl
    implements ClassifierFacade
{
    /**
     * The underlying UML object
     * @see Classifier
     */
    protected Classifier metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ClassifierFacadeLogic(Classifier metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ClassifierFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ClassifierFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ClassifierFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ClassifierFacade
     */
    public boolean isClassifierFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ClassifierFacade#isPrimitive()
    * @return boolean
    */
    protected abstract boolean handleIsPrimitive();

    /**
     * Indicates whether or not this classifier represents a primitive type.
     * @return (boolean)handleIsPrimitive()
     */
    public final boolean isPrimitive()
    {
        boolean primitive1a = false;
        // primitive has no pre constraints
        primitive1a = handleIsPrimitive();
        // primitive has no post constraints
        return primitive1a;
    }

   /**
    * @see ClassifierFacade#getOperationCallFromAttributes()
    * @return String
    */
    protected abstract String handleGetOperationCallFromAttributes();

    /**
     * The attributes from this classifier in the form of an operation call (this example would be
     * in Java): '(String attributeOne, String attributeTwo).  If there were no attributes on the
     * classifier, the result would be an empty '()'.
     * @return (String)handleGetOperationCallFromAttributes()
     */
    public final String getOperationCallFromAttributes()
    {
        String operationCallFromAttributes2a = null;
        // operationCallFromAttributes has no pre constraints
        operationCallFromAttributes2a = handleGetOperationCallFromAttributes();
        // operationCallFromAttributes has no post constraints
        return operationCallFromAttributes2a;
    }

   /**
    * @see ClassifierFacade#isAbstract()
    * @return boolean
    */
    protected abstract boolean handleIsAbstract();

    /**
     * Indicates if this classifier is 'abstract'.
     * @return (boolean)handleIsAbstract()
     */
    public final boolean isAbstract()
    {
        boolean abstract3a = false;
        // abstract has no pre constraints
        abstract3a = handleIsAbstract();
        // abstract has no post constraints
        return abstract3a;
    }

   /**
    * @see ClassifierFacade#isDataType()
    * @return boolean
    */
    protected abstract boolean handleIsDataType();

    /**
     * True/false depending on whether or not this classifier represents a datatype. A data type is
     * a type whose instances are identified only by their value. A data type may contain attributes
     * to support the modeling of structured data types.
     * @return (boolean)handleIsDataType()
     */
    public final boolean isDataType()
    {
        boolean dataType4a = false;
        // dataType has no pre constraints
        dataType4a = handleIsDataType();
        // dataType has no post constraints
        return dataType4a;
    }

   /**
    * @see ClassifierFacade#isArrayType()
    * @return boolean
    */
    protected abstract boolean handleIsArrayType();

    /**
     * True if this classifier represents an array type. False otherwise.
     * @return (boolean)handleIsArrayType()
     */
    public final boolean isArrayType()
    {
        boolean arrayType5a = false;
        // arrayType has no pre constraints
        arrayType5a = handleIsArrayType();
        // arrayType has no post constraints
        return arrayType5a;
    }

   /**
    * @see ClassifierFacade#isCollectionType()
    * @return boolean
    */
    protected abstract boolean handleIsCollectionType();

    /**
     * True if this classifier represents a collection type. False otherwise.
     * @return (boolean)handleIsCollectionType()
     */
    public final boolean isCollectionType()
    {
        boolean collectionType6a = false;
        // collectionType has no pre constraints
        collectionType6a = handleIsCollectionType();
        // collectionType has no post constraints
        return collectionType6a;
    }

   /**
    * @see ClassifierFacade#getWrapperName()
    * @return String
    */
    protected abstract String handleGetWrapperName();

    /**
     * The wrapper name for this classifier if a mapped type has a defined wrapper class (ie. 'long'
     * maps to 'Long').  If the classifier doesn't have a wrapper defined for it, this method will
     * return a null.  Note that wrapper mappings must be defined for the namespace by defining the
     * 'wrapperMappingsUri', this property must point to the location of the mappings file which
     * maps the primitives to wrapper types.
     * @return (String)handleGetWrapperName()
     */
    public final String getWrapperName()
    {
        String wrapperName7a = null;
        // wrapperName has no pre constraints
        wrapperName7a = handleGetWrapperName();
        // wrapperName has no post constraints
        return wrapperName7a;
    }

   /**
    * @see ClassifierFacade#isDateType()
    * @return boolean
    */
    protected abstract boolean handleIsDateType();

    /**
     * True when this classifier is a date type.
     * @return (boolean)handleIsDateType()
     */
    public final boolean isDateType()
    {
        boolean dateType8a = false;
        // dateType has no pre constraints
        dateType8a = handleIsDateType();
        // dateType has no post constraints
        return dateType8a;
    }

   /**
    * @see ClassifierFacade#isInterface()
    * @return boolean
    */
    protected abstract boolean handleIsInterface();

    /**
     * True/false depending on whether or not this Classifier represents an interface.
     * @return (boolean)handleIsInterface()
     */
    public final boolean isInterface()
    {
        boolean interface9a = false;
        // interface has no pre constraints
        interface9a = handleIsInterface();
        // interface has no post constraints
        return interface9a;
    }

   /**
    * @see ClassifierFacade#getJavaNewString()
    * @return String
    */
    protected abstract String handleGetJavaNewString();

    /**
     * A String representing a new Constructor declaration for this classifier type to be used in a
     * Java environment.
     * @return (String)handleGetJavaNewString()
     */
    public final String getJavaNewString()
    {
        String javaNewString10a = null;
        // javaNewString has no pre constraints
        javaNewString10a = handleGetJavaNewString();
        // javaNewString has no post constraints
        return javaNewString10a;
    }

   /**
    * @see ClassifierFacade#isListType()
    * @return boolean
    */
    protected abstract boolean handleIsListType();

    /**
     * True if this classifier represents a list type. False otherwise.
     * @return (boolean)handleIsListType()
     */
    public final boolean isListType()
    {
        boolean listType11a = false;
        // listType has no pre constraints
        listType11a = handleIsListType();
        // listType has no post constraints
        return listType11a;
    }

   /**
    * @see ClassifierFacade#isSetType()
    * @return boolean
    */
    protected abstract boolean handleIsSetType();

    /**
     * True if this classifier represents a set type. False otherwise.
     * @return (boolean)handleIsSetType()
     */
    public final boolean isSetType()
    {
        boolean setType12a = false;
        // setType has no pre constraints
        setType12a = handleIsSetType();
        // setType has no post constraints
        return setType12a;
    }

   /**
    * @see ClassifierFacade#isFileType()
    * @return boolean
    */
    protected abstract boolean handleIsFileType();

    /**
     * Returns true if this type represents a 'file' type.
     * @return (boolean)handleIsFileType()
     */
    public final boolean isFileType()
    {
        boolean fileType13a = false;
        // fileType has no pre constraints
        fileType13a = handleIsFileType();
        // fileType has no post constraints
        return fileType13a;
    }

   /**
    * @see ClassifierFacade#isMapType()
    * @return boolean
    */
    protected abstract boolean handleIsMapType();

    /**
     * Indicates whether or not this classifier represents a Map type.
     * @return (boolean)handleIsMapType()
     */
    public final boolean isMapType()
    {
        boolean mapType14a = false;
        // mapType has no pre constraints
        mapType14a = handleIsMapType();
        // mapType has no post constraints
        return mapType14a;
    }

   /**
    * @see ClassifierFacade#isStringType()
    * @return boolean
    */
    protected abstract boolean handleIsStringType();

    /**
     * Indicates whether or not this classifier represents a string type.
     * @return (boolean)handleIsStringType()
     */
    public final boolean isStringType()
    {
        boolean stringType15a = false;
        // stringType has no pre constraints
        stringType15a = handleIsStringType();
        // stringType has no post constraints
        return stringType15a;
    }

   /**
    * @see ClassifierFacade#isEnumeration()
    * @return boolean
    */
    protected abstract boolean handleIsEnumeration();

    /**
     * True if this classifier is in fact marked as an enumeration.
     * @return (boolean)handleIsEnumeration()
     */
    public final boolean isEnumeration()
    {
        boolean enumeration16a = false;
        // enumeration has no pre constraints
        enumeration16a = handleIsEnumeration();
        // enumeration has no post constraints
        return enumeration16a;
    }

   /**
    * @see ClassifierFacade#getArrayName()
    * @return String
    */
    protected abstract String handleGetArrayName();

    /**
     * The name of the classifier as an array.
     * @return (String)handleGetArrayName()
     */
    public final String getArrayName()
    {
        String arrayName17a = null;
        // arrayName has no pre constraints
        arrayName17a = handleGetArrayName();
        // arrayName has no post constraints
        return arrayName17a;
    }

   /**
    * @see ClassifierFacade#getFullyQualifiedArrayName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedArrayName();

    /**
     * The fully qualified name of the classifier as an array.
     * @return (String)handleGetFullyQualifiedArrayName()
     */
    public final String getFullyQualifiedArrayName()
    {
        String fullyQualifiedArrayName18a = null;
        // fullyQualifiedArrayName has no pre constraints
        fullyQualifiedArrayName18a = handleGetFullyQualifiedArrayName();
        // fullyQualifiedArrayName has no post constraints
        return fullyQualifiedArrayName18a;
    }

   /**
    * @see ClassifierFacade#getSerialVersionUID()
    * @return long
    */
    protected abstract long handleGetSerialVersionUID();

    /**
     * Returns the serial version UID of the underlying model element.
     * @return (long)handleGetSerialVersionUID()
     */
    public final long getSerialVersionUID()
    {
        long serialVersionUID19a = 0;
        // serialVersionUID has no pre constraints
        serialVersionUID19a = handleGetSerialVersionUID();
        // serialVersionUID has no post constraints
        return serialVersionUID19a;
    }

   /**
    * @see ClassifierFacade#isBlobType()
    * @return boolean
    */
    protected abstract boolean handleIsBlobType();

    /**
     * Returns true if this type represents a Blob type.
     * @return (boolean)handleIsBlobType()
     */
    public final boolean isBlobType()
    {
        boolean blobType20a = false;
        // blobType has no pre constraints
        blobType20a = handleIsBlobType();
        // blobType has no post constraints
        return blobType20a;
    }

   /**
    * @see ClassifierFacade#isBooleanType()
    * @return boolean
    */
    protected abstract boolean handleIsBooleanType();

    /**
     * Indicates if this type represents a boolean type or not.
     * @return (boolean)handleIsBooleanType()
     */
    public final boolean isBooleanType()
    {
        boolean booleanType21a = false;
        // booleanType has no pre constraints
        booleanType21a = handleIsBooleanType();
        // booleanType has no post constraints
        return booleanType21a;
    }

   /**
    * @see ClassifierFacade#isTimeType()
    * @return boolean
    */
    protected abstract boolean handleIsTimeType();

    /**
     * Indicates whether or not this classifier represents a time type.
     * @return (boolean)handleIsTimeType()
     */
    public final boolean isTimeType()
    {
        boolean timeType22a = false;
        // timeType has no pre constraints
        timeType22a = handleIsTimeType();
        // timeType has no post constraints
        return timeType22a;
    }

   /**
    * @see ClassifierFacade#isLeaf()
    * @return boolean
    */
    protected abstract boolean handleIsLeaf();

    /**
     * True if this classifier cannot be extended and represent a leaf in the inheritance tree.
     * @return (boolean)handleIsLeaf()
     */
    public final boolean isLeaf()
    {
        boolean leaf23a = false;
        // leaf has no pre constraints
        leaf23a = handleIsLeaf();
        // leaf has no post constraints
        return leaf23a;
    }

   /**
    * @see ClassifierFacade#getImplementedInterfaceList()
    * @return String
    */
    protected abstract String handleGetImplementedInterfaceList();

    /**
     * A comma separated list of the fully qualified names of all implemented interfaces.
     * @return (String)handleGetImplementedInterfaceList()
     */
    public final String getImplementedInterfaceList()
    {
        String implementedInterfaceList24a = null;
        // implementedInterfaceList has no pre constraints
        implementedInterfaceList24a = handleGetImplementedInterfaceList();
        // implementedInterfaceList has no post constraints
        return implementedInterfaceList24a;
    }

   /**
    * @see ClassifierFacade#getRequiredConstructorParameters()
    * @return Collection<ModelElementFacade>
    */
    protected abstract Collection<ModelElementFacade> handleGetRequiredConstructorParameters();

    /**
     * A collection containing all required and/or read-only 'properties' of the classifier. 
     * Properties are any attributes and navigable connecting association ends.
     * @return (Collection<ModelElementFacade>)handleGetRequiredConstructorParameters()
     */
    public final Collection<ModelElementFacade> getRequiredConstructorParameters()
    {
        Collection<ModelElementFacade> requiredConstructorParameters25a = null;
        // requiredConstructorParameters has no pre constraints
        requiredConstructorParameters25a = handleGetRequiredConstructorParameters();
        // requiredConstructorParameters has no post constraints
        return requiredConstructorParameters25a;
    }

   /**
    * @see ClassifierFacade#getAllRequiredConstructorParameters()
    * @return Collection<ModelElementFacade>
    */
    protected abstract Collection<ModelElementFacade> handleGetAllRequiredConstructorParameters();

    /**
     * A collection containing all required and/or read-only 'properties' of the classifier and its
     * ancestors. Properties are any attributes and navigable connecting association ends.
     * @return (Collection<ModelElementFacade>)handleGetAllRequiredConstructorParameters()
     */
    public final Collection<ModelElementFacade> getAllRequiredConstructorParameters()
    {
        Collection<ModelElementFacade> allRequiredConstructorParameters26a = null;
        // allRequiredConstructorParameters has no pre constraints
        allRequiredConstructorParameters26a = handleGetAllRequiredConstructorParameters();
        // allRequiredConstructorParameters has no post constraints
        return allRequiredConstructorParameters26a;
    }

   /**
    * @see ClassifierFacade#getProperties()
    * @return List<ModelElementFacade>
    */
    protected abstract List<ModelElementFacade> handleGetProperties();

    /**
     * A collection containing all 'properties' of the classifier.  Properties are any attributes
     * and navigable connecting association ends.
     * @return (List<ModelElementFacade>)handleGetProperties()
     */
    public final List<ModelElementFacade> getProperties()
    {
        List<ModelElementFacade> properties27a = null;
        // properties has no pre constraints
        properties27a = handleGetProperties();
        // properties has no post constraints
        return properties27a;
    }

   /**
    * @see ClassifierFacade#getAllProperties()
    * @return Collection<ModelElementFacade>
    */
    protected abstract Collection<ModelElementFacade> handleGetAllProperties();

    /**
     * A collection containing all 'properties' of the classifier and its ancestors.  Properties are
     * any attributes and navigable connecting association ends.
     * @return (Collection<ModelElementFacade>)handleGetAllProperties()
     */
    public final Collection<ModelElementFacade> getAllProperties()
    {
        Collection<ModelElementFacade> allProperties28a = null;
        // allProperties has no pre constraints
        allProperties28a = handleGetAllProperties();
        // allProperties has no post constraints
        return allProperties28a;
    }

   /**
    * @see ClassifierFacade#isAssociationClass()
    * @return boolean
    */
    protected abstract boolean handleIsAssociationClass();

    /**
     * True if the ClassifierFacade is an AssociationClass.
     * @return (boolean)handleIsAssociationClass()
     */
    public final boolean isAssociationClass()
    {
        boolean associationClass29a = false;
        // associationClass has no pre constraints
        associationClass29a = handleIsAssociationClass();
        // associationClass has no post constraints
        return associationClass29a;
    }

   /**
    * @see ClassifierFacade#isClobType()
    * @return boolean
    */
    protected abstract boolean handleIsClobType();

    /**
     * Returns true if this type represents a Clob type.
     * @return (boolean)handleIsClobType()
     */
    public final boolean isClobType()
    {
        boolean clobType30a = false;
        // clobType has no pre constraints
        clobType30a = handleIsClobType();
        // clobType has no post constraints
        return clobType30a;
    }

   /**
    * @see ClassifierFacade#isEmbeddedValue()
    * @return boolean
    */
    protected abstract boolean handleIsEmbeddedValue();

    /**
     * Indicates whether or not this classifier represents an "EmbeddedValue'.
     * @return (boolean)handleIsEmbeddedValue()
     */
    public final boolean isEmbeddedValue()
    {
        boolean embeddedValue31a = false;
        // embeddedValue has no pre constraints
        embeddedValue31a = handleIsEmbeddedValue();
        // embeddedValue has no post constraints
        return embeddedValue31a;
    }

   /**
    * @see ClassifierFacade#isIntegerType()
    * @return boolean
    */
    protected abstract boolean handleIsIntegerType();

    /**
     * Indicates if this type represents an int or Integer or java.lang.Integer type or not.
     * @return (boolean)handleIsIntegerType()
     */
    public final boolean isIntegerType()
    {
        boolean integerType32a = false;
        // integerType has no pre constraints
        integerType32a = handleIsIntegerType();
        // integerType has no post constraints
        return integerType32a;
    }

   /**
    * @see ClassifierFacade#isFloatType()
    * @return boolean
    */
    protected abstract boolean handleIsFloatType();

    /**
     * Indicates if this type represents a Float type or not.
     * @return (boolean)handleIsFloatType()
     */
    public final boolean isFloatType()
    {
        boolean floatType33a = false;
        // floatType has no pre constraints
        floatType33a = handleIsFloatType();
        // floatType has no post constraints
        return floatType33a;
    }

   /**
    * @see ClassifierFacade#isLongType()
    * @return boolean
    */
    protected abstract boolean handleIsLongType();

    /**
     * Indicates if this type represents a Long type or not.
     * @return (boolean)handleIsLongType()
     */
    public final boolean isLongType()
    {
        boolean longType34a = false;
        // longType has no pre constraints
        longType34a = handleIsLongType();
        // longType has no post constraints
        return longType34a;
    }

   /**
    * @see ClassifierFacade#isDoubleType()
    * @return boolean
    */
    protected abstract boolean handleIsDoubleType();

    /**
     * Indicates if this type represents a Double type or not.
     * @return (boolean)handleIsDoubleType()
     */
    public final boolean isDoubleType()
    {
        boolean doubleType35a = false;
        // doubleType has no pre constraints
        doubleType35a = handleIsDoubleType();
        // doubleType has no post constraints
        return doubleType35a;
    }

   /**
    * @see ClassifierFacade#isWrappedPrimitive()
    * @return boolean
    */
    protected abstract boolean handleIsWrappedPrimitive();

    /**
     * Returns true if this type is a wrapped primitive type.
     * @return (boolean)handleIsWrappedPrimitive()
     */
    public final boolean isWrappedPrimitive()
    {
        boolean wrappedPrimitive36a = false;
        // wrappedPrimitive has no pre constraints
        wrappedPrimitive36a = handleIsWrappedPrimitive();
        // wrappedPrimitive has no post constraints
        return wrappedPrimitive36a;
    }

   /**
    * @see ClassifierFacade#getJavaNullString()
    * @return String
    */
    protected abstract String handleGetJavaNullString();

    /**
     * A String representing the null-value for this classifier type to be used in a Java
     * environment.
     * @return (String)handleGetJavaNullString()
     */
    public final String getJavaNullString()
    {
        String javaNullString37a = null;
        // javaNullString has no pre constraints
        javaNullString37a = handleGetJavaNullString();
        // javaNullString has no post constraints
        return javaNullString37a;
    }

   /**
    * @see ClassifierFacade#isCharacterType()
    * @return boolean
    */
    protected abstract boolean handleIsCharacterType();

    /**
     * Indicates if this type represents a char, Character, or java.lang.Character type or not.
     * @return (boolean)handleIsCharacterType()
     */
    public final boolean isCharacterType()
    {
        boolean characterType38a = false;
        // characterType has no pre constraints
        characterType38a = handleIsCharacterType();
        // characterType has no post constraints
        return characterType38a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Gets all attributes for the classifier and if 'follow' is true goes up the inheritance
     * hierarchy and gets the attributes from the super classes as well.
     * @param follow
     * @return List<AttributeFacade>
     */
    protected abstract List<AttributeFacade> handleGetAttributes(boolean follow);

    /**
     * Gets all attributes for the classifier and if 'follow' is true goes up the inheritance
     * hierarchy and gets the attributes from the super classes as well.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retrieveing attributes.
     * @return handleGetAttributes(follow)
     */
    public List<AttributeFacade> getAttributes(boolean follow)
    {
        // getAttributes has no pre constraints
        List<AttributeFacade> returnValue = handleGetAttributes(follow);
        // getAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Return the attribute which name matches the parameter
     * @param name
     * @return AttributeFacade
     */
    protected abstract AttributeFacade handleFindAttribute(String name);

    /**
     * Return the attribute which name matches the parameter
     * @param name String
     * TODO: Model Documentation for
     * ClassifierFacade.findAttribute(name)
     * @return handleFindAttribute(name)
     */
    public AttributeFacade findAttribute(String name)
    {
        // findAttribute has no pre constraints
        AttributeFacade returnValue = handleFindAttribute(name);
        // findAttribute has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all properties (attributes and navigable association ends) for the classifier and if
     * 'follow' is true goes up the inheritance hierarchy and gets the properties from the super
     * classes as well.
     * @param follow
     * @return List
     */
    protected abstract List handleGetProperties(boolean follow);

    /**
     * Gets all properties (attributes and navigable association ends) for the classifier and if
     * 'follow' is true goes up the inheritance hierarchy and gets the properties from the super
     * classes as well.
     * @param follow boolean
     * TODO: Model Documentation for
     * ClassifierFacade.getProperties(follow)
     * @return handleGetProperties(follow)
     */
    public List getProperties(boolean follow)
    {
        // getProperties has no pre constraints
        List returnValue = handleGetProperties(follow);
        // getProperties has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Get the other ends of this classifier's association ends which are navigable and if 'follow'
     * is true goes up the inheritance hierarchy and gets the super association ends as well.
     * @param follow
     * @return List<AssociationEndFacade>
     */
    protected abstract List<AssociationEndFacade> handleGetNavigableConnectingEnds(boolean follow);

    /**
     * Get the other ends of this classifier's association ends which are navigable and if 'follow'
     * is true goes up the inheritance hierarchy and gets the super association ends as well.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retrieving navicables.
     * @return handleGetNavigableConnectingEnds(follow)
     */
    public List<AssociationEndFacade> getNavigableConnectingEnds(boolean follow)
    {
        // getNavigableConnectingEnds has no pre constraints
        List<AssociationEndFacade> returnValue = handleGetNavigableConnectingEnds(follow);
        // getNavigableConnectingEnds has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    private ClassifierFacade __getArray1r;
    private boolean __getArray1rSet = false;

    /**
     * Assuming that the classifier is an array, this will return the non array type of the
     * classifier from
     * the model.  If the classifier is NOT an array, it will just return itself.
     * @return (ClassifierFacade)handleGetArray()
     */
    public final ClassifierFacade getArray()
    {
        ClassifierFacade getArray1r = this.__getArray1r;
        if (!this.__getArray1rSet)
        {
            // nonArray has no pre constraints
            Object result = handleGetArray();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getArray1r = (ClassifierFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getArray ClassifierFacade " + result + ": " + shieldedResult);
            }
            // nonArray has no post constraints
            this.__getArray1r = getArray1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getArray1rSet = true;
            }
        }
        return getArray1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetArray();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (List<OperationFacade>)handleGetInstanceOperations()
     */
    public final List<OperationFacade> getInstanceOperations()
    {
        List<OperationFacade> getInstanceOperations2r = null;
        // classifierFacade has no pre constraints
        List result = handleGetInstanceOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getInstanceOperations2r = (List<OperationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getInstanceOperations List<OperationFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getInstanceOperations2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetInstanceOperations();

    /**
     * Gets the owner of this operation
     * @return (List<OperationFacade>)handleGetOperations()
     */
    public final List<OperationFacade> getOperations()
    {
        List<OperationFacade> getOperations3r = null;
        // owner has no pre constraints
        List result = handleGetOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getOperations3r = (List<OperationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getOperations List<OperationFacade> " + result + ": " + shieldedResult);
        }
        // owner has no post constraints
        return getOperations3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetOperations();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (List<OperationFacade>)handleGetStaticOperations()
     */
    public final List<OperationFacade> getStaticOperations()
    {
        List<OperationFacade> getStaticOperations4r = null;
        // classifierFacade has no pre constraints
        List result = handleGetStaticOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getStaticOperations4r = (List<OperationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getStaticOperations List<OperationFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getStaticOperations4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetStaticOperations();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<ClassifierFacade>)handleGetAbstractions()
     */
    public final Collection<ClassifierFacade> getAbstractions()
    {
        Collection<ClassifierFacade> getAbstractions5r = null;
        // classifierFacade has no pre constraints
        Collection result = handleGetAbstractions();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAbstractions5r = (Collection<ClassifierFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getAbstractions Collection<ClassifierFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getAbstractions5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAbstractions();

    /**
     * Gets the classifier who is the owner of the attributes.
     * @return (List<AttributeFacade>)handleGetAttributes()
     */
    public final List<AttributeFacade> getAttributes()
    {
        List<AttributeFacade> getAttributes6r = null;
        // owner has no pre constraints
        List result = handleGetAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAttributes6r = (List<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getAttributes List<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // owner has no post constraints
        return getAttributes6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAttributes();

    /**
     * Lists the classes associated to this one, there is no repitition of classes. The order of the
     * elements is predictable.
     * @return (Collection<ClassifierFacade>)handleGetAllAssociatedClasses()
     */
    public final Collection<ClassifierFacade> getAllAssociatedClasses()
    {
        Collection<ClassifierFacade> getAllAssociatedClasses7r = null;
        // associatedClasses has no pre constraints
        Collection result = handleGetAllAssociatedClasses();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllAssociatedClasses7r = (Collection<ClassifierFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getAllAssociatedClasses Collection<ClassifierFacade> " + result + ": " + shieldedResult);
        }
        // associatedClasses has no post constraints
        return getAllAssociatedClasses7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllAssociatedClasses();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<AttributeFacade>)handleGetStaticAttributes()
     */
    public final Collection<AttributeFacade> getStaticAttributes()
    {
        Collection<AttributeFacade> getStaticAttributes8r = null;
        // classifierFacade has no pre constraints
        Collection result = handleGetStaticAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getStaticAttributes8r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getStaticAttributes Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getStaticAttributes8r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetStaticAttributes();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<AssociationEndFacade>)handleGetNavigableConnectingEnds()
     */
    public final Collection<AssociationEndFacade> getNavigableConnectingEnds()
    {
        Collection<AssociationEndFacade> getNavigableConnectingEnds9r = null;
        // classifierFacade has no pre constraints
        Collection result = handleGetNavigableConnectingEnds();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getNavigableConnectingEnds9r = (Collection<AssociationEndFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getNavigableConnectingEnds Collection<AssociationEndFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getNavigableConnectingEnds9r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetNavigableConnectingEnds();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (List<AssociationEndFacade>)handleGetAssociationEnds()
     */
    public final List<AssociationEndFacade> getAssociationEnds()
    {
        List<AssociationEndFacade> getAssociationEnds10r = null;
        // classifierFacade has no pre constraints
        List result = handleGetAssociationEnds();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAssociationEnds10r = (List<AssociationEndFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getAssociationEnds List<AssociationEndFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getAssociationEnds10r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAssociationEnds();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<AttributeFacade>)handleGetInstanceAttributes()
     */
    public final Collection<AttributeFacade> getInstanceAttributes()
    {
        Collection<AttributeFacade> getInstanceAttributes11r = null;
        // classifierFacade has no pre constraints
        Collection result = handleGetInstanceAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getInstanceAttributes11r = (Collection<AttributeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getInstanceAttributes Collection<AttributeFacade> " + result + ": " + shieldedResult);
        }
        // classifierFacade has no post constraints
        return getInstanceAttributes11r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetInstanceAttributes();

    private ClassifierFacade __getNonArray12r;
    private boolean __getNonArray12rSet = false;

    /**
     * Gets the array type for this classifier.  If this classifier already represents an array, it
     * just returns itself.
     * @return (ClassifierFacade)handleGetNonArray()
     */
    public final ClassifierFacade getNonArray()
    {
        ClassifierFacade getNonArray12r = this.__getNonArray12r;
        if (!this.__getNonArray12rSet)
        {
            // array has no pre constraints
            Object result = handleGetNonArray();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getNonArray12r = (ClassifierFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getNonArray ClassifierFacade " + result + ": " + shieldedResult);
            }
            // array has no post constraints
            this.__getNonArray12r = getNonArray12r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getNonArray12rSet = true;
            }
        }
        return getNonArray12r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetNonArray();

    /**
     * Lists all classes associated to this one and any ancestor classes (through generalization).
     * There will be no duplicates. The order of the elements is predictable.
     * @return (Collection<ClassifierFacade>)handleGetAssociatedClasses()
     */
    public final Collection<ClassifierFacade> getAssociatedClasses()
    {
        Collection<ClassifierFacade> getAssociatedClasses13r = null;
        // allAssociatedClasses has no pre constraints
        Collection result = handleGetAssociatedClasses();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAssociatedClasses13r = (Collection<ClassifierFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getAssociatedClasses Collection<ClassifierFacade> " + result + ": " + shieldedResult);
        }
        // allAssociatedClasses has no post constraints
        return getAssociatedClasses13r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAssociatedClasses();

    private Collection<ClassifierFacade> __getInterfaceAbstractions14r;
    private boolean __getInterfaceAbstractions14rSet = false;

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<ClassifierFacade>)handleGetInterfaceAbstractions()
     */
    public final Collection<ClassifierFacade> getInterfaceAbstractions()
    {
        Collection<ClassifierFacade> getInterfaceAbstractions14r = this.__getInterfaceAbstractions14r;
        if (!this.__getInterfaceAbstractions14rSet)
        {
            // classifierFacade has no pre constraints
            Collection result = handleGetInterfaceAbstractions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getInterfaceAbstractions14r = (Collection<ClassifierFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getInterfaceAbstractions Collection<ClassifierFacade> " + result + ": " + shieldedResult);
            }
            // classifierFacade has no post constraints
            this.__getInterfaceAbstractions14r = getInterfaceAbstractions14r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInterfaceAbstractions14rSet = true;
            }
        }
        return getInterfaceAbstractions14r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetInterfaceAbstractions();

    private ClassifierFacade __getSuperClass15r;
    private boolean __getSuperClass15rSet = false;

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (ClassifierFacade)handleGetSuperClass()
     */
    public final ClassifierFacade getSuperClass()
    {
        ClassifierFacade getSuperClass15r = this.__getSuperClass15r;
        if (!this.__getSuperClass15rSet)
        {
            // classifierFacade has no pre constraints
            Object result = handleGetSuperClass();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getSuperClass15r = (ClassifierFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getSuperClass ClassifierFacade " + result + ": " + shieldedResult);
            }
            // classifierFacade has no post constraints
            this.__getSuperClass15r = getSuperClass15r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getSuperClass15rSet = true;
            }
        }
        return getSuperClass15r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetSuperClass();

    private Collection<OperationFacade> __getImplementationOperations16r;
    private boolean __getImplementationOperations16rSet = false;

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return (Collection<OperationFacade>)handleGetImplementationOperations()
     */
    public final Collection<OperationFacade> getImplementationOperations()
    {
        Collection<OperationFacade> getImplementationOperations16r = this.__getImplementationOperations16r;
        if (!this.__getImplementationOperations16rSet)
        {
            // classifierFacade has no pre constraints
            Collection result = handleGetImplementationOperations();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getImplementationOperations16r = (Collection<OperationFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ClassifierFacadeLogic.logger.warn("incorrect metafacade cast for ClassifierFacadeLogic.getImplementationOperations Collection<OperationFacade> " + result + ": " + shieldedResult);
            }
            // classifierFacade has no post constraints
            this.__getImplementationOperations16r = getImplementationOperations16r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getImplementationOperations16rSet = true;
            }
        }
        return getImplementationOperations16r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetImplementationOperations();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ClassifierFacade::classifier must have a name</p>
     * <p><b>Error:</b> Each classifier must have a non-empty name.</p>
     * <p><b>OCL:</b> context ClassifierFacade inv: name->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ClassifierFacade::attribute names must be unique</p>
     * <p><b>Error:</b> Each attribute on an element must have a unique name.</p>
     * <p><b>OCL:</b> context ClassifierFacade
inv : attributes -> isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ClassifierFacade::association end names must be unique</p>
     * <p><b>Error:</b> The name of each navigable connecting association end must be unique.</p>
     * <p><b>OCL:</b> context ClassifierFacade
inv : navigableConnectingEnds -> isUnique(name)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ClassifierFacade::source dependencies must be unique</p>
     * <p><b>Error:</b> Each dependency going out a of an element must have a unique name.</p>
     * <p><b>OCL:</b> context ClassifierFacade
inv : sourceDependencies -> isUnique(name)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see GeneralizableElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::classifier must have a name",
                        "Each classifier must have a non-empty name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ClassifierFacade::classifier must have a name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"attributes"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::attribute names must be unique",
                        "Each attribute on an element must have a unique name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ClassifierFacade::attribute names must be unique' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"navigableConnectingEnds"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::association end names must be unique",
                        "The name of each navigable connecting association end must be unique."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ClassifierFacade::association end names must be unique' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"sourceDependencies"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::source dependencies must be unique",
                        "Each dependency going out a of an element must have a unique name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ClassifierFacade::source dependencies must be unique' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}