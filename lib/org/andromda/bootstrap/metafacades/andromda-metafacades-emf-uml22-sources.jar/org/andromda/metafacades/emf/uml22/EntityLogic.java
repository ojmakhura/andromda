// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AssociationEndFacade;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.Entity;
import org.andromda.metafacades.uml.EntityAssociationEnd;
import org.andromda.metafacades.uml.EntityQueryOperation;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * Represents a persistent entity.
 * MetafacadeLogic for Entity
 *
 * @see Entity
 */
public abstract class EntityLogic
    extends ClassifierFacadeLogicImpl
    implements Entity
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EntityLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(EntityLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to Entity if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Entity";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see Entity
     */
    public boolean isEntityMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see Entity#isChild()
    * @return boolean
    */
    protected abstract boolean handleIsChild();

    /**
     * Returns true/false depending on whether or not this entity represetns a child in an
     * association (this occurs when this entity is on the opposite end of an assocation end defined
     * as composite).
     * @return (boolean)handleIsChild()
     */
    public final boolean isChild()
    {
        boolean child1a = false;
        // child has no pre constraints
        child1a = handleIsChild();
        // child has no post constraints
        return child1a;
    }

   /**
    * @see Entity#getTableName()
    * @return String
    */
    protected abstract String handleGetTableName();

    /**
     * The name of the database table to which this entity is persisted.
     * @return (String)handleGetTableName()
     */
    public final String getTableName()
    {
        String tableName2a = null;
        // tableName has no pre constraints
        tableName2a = handleGetTableName();
        // tableName has no post constraints
        return tableName2a;
    }

   /**
    * @see Entity#isIdentifiersPresent()
    * @return boolean
    */
    protected abstract boolean handleIsIdentifiersPresent();

    /**
     * True if the entity has any identifiers defined, false otherwise.
     * @return (boolean)handleIsIdentifiersPresent()
     */
    public final boolean isIdentifiersPresent()
    {
        boolean identifiersPresent3a = false;
        // identifiersPresent has no pre constraints
        identifiersPresent3a = handleIsIdentifiersPresent();
        // identifiersPresent has no post constraints
        return identifiersPresent3a;
    }

   /**
    * @see Entity#getMaxSqlNameLength()
    * @return short
    */
    protected abstract short handleGetMaxSqlNameLength();

    /**
     * The maximum length a SQL name may be.
     * @return (short)handleGetMaxSqlNameLength()
     */
    public final short getMaxSqlNameLength()
    {
        short maxSqlNameLength4a = 0;
        // maxSqlNameLength has no pre constraints
        maxSqlNameLength4a = handleGetMaxSqlNameLength();
        // maxSqlNameLength has no post constraints
        return maxSqlNameLength4a;
    }

   /**
    * @see Entity#isUsingForeignIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsUsingForeignIdentifier();

    /**
     * Indicates whether or not this entity is using a foreign identifier as its identifiers.  That
     * is: the foreignIdentifier flag was set on an incoming association end and the entity is
     * therefore using the related foreign parent entity's identifier.
     * @return (boolean)handleIsUsingForeignIdentifier()
     */
    public final boolean isUsingForeignIdentifier()
    {
        boolean usingForeignIdentifier5a = false;
        // usingForeignIdentifier has no pre constraints
        usingForeignIdentifier5a = handleIsUsingForeignIdentifier();
        // usingForeignIdentifier has no post constraints
        return usingForeignIdentifier5a;
    }

   /**
    * @see Entity#isDynamicIdentifiersPresent()
    * @return boolean
    */
    protected abstract boolean handleIsDynamicIdentifiersPresent();

    /**
     * True if the entity has its identifiers dynamically added, false otherwise.
     * @return (boolean)handleIsDynamicIdentifiersPresent()
     */
    public final boolean isDynamicIdentifiersPresent()
    {
        boolean dynamicIdentifiersPresent6a = false;
        // dynamicIdentifiersPresent has no pre constraints
        dynamicIdentifiersPresent6a = handleIsDynamicIdentifiersPresent();
        // dynamicIdentifiersPresent has no post constraints
        return dynamicIdentifiersPresent6a;
    }

   /**
    * @see Entity#isUsingAssignedIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsUsingAssignedIdentifier();

    /**
     * Indiciates if this entity is using an assigned identifier or not.
     * @return (boolean)handleIsUsingAssignedIdentifier()
     */
    public final boolean isUsingAssignedIdentifier()
    {
        boolean usingAssignedIdentifier7a = false;
        // usingAssignedIdentifier has no pre constraints
        usingAssignedIdentifier7a = handleIsUsingAssignedIdentifier();
        // usingAssignedIdentifier has no post constraints
        return usingAssignedIdentifier7a;
    }

   /**
    * @see Entity#getSchema()
    * @return String
    */
    protected abstract String handleGetSchema();

    /**
     * The name of the schema that contains the database table
     * @return (String)handleGetSchema()
     */
    public final String getSchema()
    {
        String schema8a = null;
        // schema has no pre constraints
        schema8a = handleGetSchema();
        // schema has no post constraints
        return schema8a;
    }

   /**
    * @see Entity#isCompositeIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsCompositeIdentifier();

    /**
     * True if this entity identifier is a composite (consists of multiple key columns, typically
     * abstracted into an external composite identifier class)
     * @return (boolean)handleIsCompositeIdentifier()
     */
    public final boolean isCompositeIdentifier()
    {
        boolean compositeIdentifier9a = false;
        // compositeIdentifier has no pre constraints
        compositeIdentifier9a = handleIsCompositeIdentifier();
        // compositeIdentifier has no post constraints
        return compositeIdentifier9a;
    }

   /**
    * @see Entity#getEmbeddedValues()
    * @return Collection<AttributeFacade>
    */
    protected abstract Collection<AttributeFacade> handleGetEmbeddedValues();

    /**
     * The embedded values belonging to this entity.
     * @return (Collection<AttributeFacade>)handleGetEmbeddedValues()
     */
    public final Collection<AttributeFacade> getEmbeddedValues()
    {
        Collection<AttributeFacade> embeddedValues10a = null;
        // embeddedValues has no pre constraints
        embeddedValues10a = handleGetEmbeddedValues();
        // embeddedValues has no post constraints
        return embeddedValues10a;
    }

   /**
    * @see Entity#getFullyQualifiedIdentifierTypeName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedIdentifierTypeName();

    /**
     * The full name of the type of the identifier. If composite identifier add the PK sufix to the
     * class name. If not, retorns the fully qualified name of the identifier.
     * @return (String)handleGetFullyQualifiedIdentifierTypeName()
     */
    public final String getFullyQualifiedIdentifierTypeName()
    {
        String fullyQualifiedIdentifierTypeName11a = null;
        // fullyQualifiedIdentifierTypeName has no pre constraints
        fullyQualifiedIdentifierTypeName11a = handleGetFullyQualifiedIdentifierTypeName();
        // fullyQualifiedIdentifierTypeName has no post constraints
        return fullyQualifiedIdentifierTypeName11a;
    }

   /**
    * @see Entity#getIdentifierGetterName()
    * @return String
    */
    protected abstract String handleGetIdentifierGetterName();

    /**
     * The getter name of the identifier.
     * @return (String)handleGetIdentifierGetterName()
     */
    public final String getIdentifierGetterName()
    {
        String identifierGetterName12a = null;
        // identifierGetterName has no pre constraints
        identifierGetterName12a = handleGetIdentifierGetterName();
        // identifierGetterName has no post constraints
        return identifierGetterName12a;
    }

   /**
    * @see Entity#getIdentifierName()
    * @return String
    */
    protected abstract String handleGetIdentifierName();

    /**
     * The name of the identifier. If composite identifier add the Pk suffix. If not composite
     * returns the attribute name of the identifier.
     * @return (String)handleGetIdentifierName()
     */
    public final String getIdentifierName()
    {
        String identifierName13a = null;
        // identifierName has no pre constraints
        identifierName13a = handleGetIdentifierName();
        // identifierName has no post constraints
        return identifierName13a;
    }

   /**
    * @see Entity#getIdentifierSetterName()
    * @return String
    */
    protected abstract String handleGetIdentifierSetterName();

    /**
     * The setter name of the identifier.
     * @return (String)handleGetIdentifierSetterName()
     */
    public final String getIdentifierSetterName()
    {
        String identifierSetterName14a = null;
        // identifierSetterName has no pre constraints
        identifierSetterName14a = handleGetIdentifierSetterName();
        // identifierSetterName has no post constraints
        return identifierSetterName14a;
    }

   /**
    * @see Entity#getIdentifierTypeName()
    * @return String
    */
    protected abstract String handleGetIdentifierTypeName();

    /**
     * The name of the type of the identifier. If composite identifier add the PK suffix to the
     * class name. If not, returns the name of the identifier.
     * @return (String)handleGetIdentifierTypeName()
     */
    public final String getIdentifierTypeName()
    {
        String identifierTypeName15a = null;
        // identifierTypeName has no pre constraints
        identifierTypeName15a = handleGetIdentifierTypeName();
        // identifierTypeName has no post constraints
        return identifierTypeName15a;
    }

   /**
    * @see Entity#getUniqueConstraints()
    * @return Map
    */
    protected abstract Map handleGetUniqueConstraints();

    /**
     * The name of the type of the identifier. If composite identifier add the PK suffix to the
     * class name. If not, returns the name of the identifier.
     * @return (Map)handleGetUniqueConstraints()
     */
    public final Map getUniqueConstraints()
    {
        Map uniqueConstraints16a = null;
        // uniqueConstraints has no pre constraints
        uniqueConstraints16a = handleGetUniqueConstraints();
        // uniqueConstraints has no post constraints
        return uniqueConstraints16a;
    }

   /**
    * @see Entity#isEmbeddableSuperclassGeneralizationExists()
    * @return boolean
    */
    protected abstract boolean handleIsEmbeddableSuperclassGeneralizationExists();

    /**
     * Returns true if this entity is a subclass of an mapped/embeddable super class.  You cannot
     * have more than 1 level of inheritance using mapped/embeddable super class.  To achieve
     * multiple levels, use one of the inheritance mapping strategies like single table, table per
     * class or joined table strategies.
     * @return (boolean)handleIsEmbeddableSuperclassGeneralizationExists()
     */
    public final boolean isEmbeddableSuperclassGeneralizationExists()
    {
        boolean embeddableSuperclassGeneralizationExists17a = false;
        // embeddableSuperclassGeneralizationExists has no pre constraints
        embeddableSuperclassGeneralizationExists17a = handleIsEmbeddableSuperclassGeneralizationExists();
        // embeddableSuperclassGeneralizationExists has no post constraints
        return embeddableSuperclassGeneralizationExists17a;
    }

   /**
    * @see Entity#isEmbeddableSuperclass()
    * @return boolean
    */
    protected abstract boolean handleIsEmbeddableSuperclass();

    /**
     * Determines if this entity is an mapped/embeddable super class.
     * @return (boolean)handleIsEmbeddableSuperclass()
     */
    public final boolean isEmbeddableSuperclass()
    {
        boolean embeddableSuperclass18a = false;
        // embeddableSuperclass has no pre constraints
        embeddableSuperclass18a = handleIsEmbeddableSuperclass();
        // embeddableSuperclass has no post constraints
        return embeddableSuperclass18a;
    }

   /**
    * @see Entity#isCompositePrimaryKeyPresent()
    * @return boolean
    */
    protected abstract boolean handleIsCompositePrimaryKeyPresent();

    /**
     * Returns true if a composite primary key exists for this entity bean.  A composite primary key
     * consists of 2 or more entity identifiers.
     * @return (boolean)handleIsCompositePrimaryKeyPresent()
     */
    public final boolean isCompositePrimaryKeyPresent()
    {
        boolean compositePrimaryKeyPresent19a = false;
        // compositePrimaryKeyPresent has no pre constraints
        compositePrimaryKeyPresent19a = handleIsCompositePrimaryKeyPresent();
        // compositePrimaryKeyPresent has no post constraints
        return compositePrimaryKeyPresent19a;
    }

   /**
    * @see Entity#getEntityEmbeddableName()
    * @return String
    */
    protected abstract String handleGetEntityEmbeddableName();

    /**
     * Entity embeddable super class name this entity inherits from.
     * @return (String)handleGetEntityEmbeddableName()
     */
    public final String getEntityEmbeddableName()
    {
        String entityEmbeddableName20a = null;
        // entityEmbeddableName has no pre constraints
        entityEmbeddableName20a = handleGetEntityEmbeddableName();
        // entityEmbeddableName has no post constraints
        return entityEmbeddableName20a;
    }

   /**
    * @see Entity#getEntityCompositePrimaryKeyName()
    * @return String
    */
    protected abstract String handleGetEntityCompositePrimaryKeyName();

    /**
     * Entity composite primary key class name for this entity.
     * @return (String)handleGetEntityCompositePrimaryKeyName()
     */
    public final String getEntityCompositePrimaryKeyName()
    {
        String entityCompositePrimaryKeyName21a = null;
        // entityCompositePrimaryKeyName has no pre constraints
        entityCompositePrimaryKeyName21a = handleGetEntityCompositePrimaryKeyName();
        // entityCompositePrimaryKeyName has no post constraints
        return entityCompositePrimaryKeyName21a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Gets the attributes as a list within an operation call, optionally including the type names
     * and the identifier attributes.
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetOperationCallFromAttributes(boolean withIdentifiers);

    /**
     * Gets the attributes as a list within an operation call, optionally including the type names
     * and the identifier attributes.
     * @param withIdentifiers boolean
     * True if you want to include identifiers within the attribute list, false otherwise.
     * @return handleGetOperationCallFromAttributes(withIdentifiers)
     */
    public String getOperationCallFromAttributes(boolean withIdentifiers)
    {
        // getOperationCallFromAttributes has no pre constraints
        String returnValue = handleGetOperationCallFromAttributes(withIdentifiers);
        // getOperationCallFromAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all identifiers for an entity. If 'follow' is true, and if no identifiers can be found
     * on the entity, a search up the inheritance chain will be performed, and the identifiers from
     * the first super class having them will be used.   If no identifiers exist, a default
     * identifier will be created if the allowDefaultIdentifiers property is set to true.
     * Identifiers can be on attributes or associations (composite primary key).
     * @param follow
     * @return Collection<ModelElementFacade>
     */
    protected abstract Collection<ModelElementFacade> handleGetIdentifiers(boolean follow);

    /**
     * Gets all identifiers for an entity. If 'follow' is true, and if no identifiers can be found
     * on the entity, a search up the inheritance chain will be performed, and the identifiers from
     * the first super class having them will be used.   If no identifiers exist, a default
     * identifier will be created if the allowDefaultIdentifiers property is set to true.
     * Identifiers can be on attributes or associations (composite primary key).
     * @param follow boolean
     * TODO: Model Documentation for Entity.getIdentifiers(follow)
     * @return handleGetIdentifiers(follow)
     */
    public Collection<ModelElementFacade> getIdentifiers(boolean follow)
    {
        // getIdentifiers has no pre constraints
        Collection<ModelElementFacade> returnValue = handleGetIdentifiers(follow);
        // getIdentifiers has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the attributes as a list within an operation call.  If 'withTypeNames' is true, it will
     * include the type names, if 'withIdentifiers' is true it will include the identifiers.  If
     * 'follow' is true it will follow the inheritance hierarchy and get the attributes of the super
     * class as well.
     * @param withIdentifiers
     * @param follow
     * @return String
     */
    protected abstract String handleGetOperationCallFromAttributes(boolean withIdentifiers, boolean follow);

    /**
     * Gets the attributes as a list within an operation call.  If 'withTypeNames' is true, it will
     * include the type names, if 'withIdentifiers' is true it will include the identifiers.  If
     * 'follow' is true it will follow the inheritance hierarchy and get the attributes of the super
     * class as well.
     * @param withIdentifiers boolean
     * If true, identifiers will be included in the list.
     * @param follow boolean
     * If this is true, the inheritance hierarchy will be followed when retrieving all attrbutes.
     * @return handleGetOperationCallFromAttributes(withIdentifiers, follow)
     */
    public String getOperationCallFromAttributes(boolean withIdentifiers, boolean follow)
    {
        // getOperationCallFromAttributes has no pre constraints
        String returnValue = handleGetOperationCallFromAttributes(withIdentifiers, follow);
        // getOperationCallFromAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns all attributes that are specified as 'required' in the model.  If 'follow' is true,
     * then required attributes in super classes will also be returned, if false, just the ones
     * directly on the entity will be returned.  If 'withIdentifiers' is true, the identifiers will
     * be include, if false, no identifiers will be included.
     * @param follow
     * @param withIdentifiers
     * @return Collection<AttributeFacade>
     */
    protected abstract Collection<AttributeFacade> handleGetRequiredAttributes(boolean follow, boolean withIdentifiers);

    /**
     * Returns all attributes that are specified as 'required' in the model.  If 'follow' is true,
     * then required attributes in super classes will also be returned, if false, just the ones
     * directly on the entity will be returned.  If 'withIdentifiers' is true, the identifiers will
     * be include, if false, no identifiers will be included.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retreiving the attributes. If true,
     * the required attributes in super classes will also be returned, if false, just the ones
     * directly on the entity will be returned.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list of required attributes.
     * @return handleGetRequiredAttributes(follow, withIdentifiers)
     */
    public Collection<AttributeFacade> getRequiredAttributes(boolean follow, boolean withIdentifiers)
    {
        // getRequiredAttributes has no pre constraints
        Collection<AttributeFacade> returnValue = handleGetRequiredAttributes(follow, withIdentifiers);
        // getRequiredAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all required properties for this entity.  These consist of any required attributes as
     * well as navigable associations that are marked as 'required'.  If 'follow' is true, then the
     * inheritance hierchy will be followed and all required properties from super classes will be
     * included as well.
     * If 'withIdentifiers' is true, the identifiers will be include, if false, no identifiers will
     * be included.
     * @param follow
     * @param withIdentifiers
     * @return Collection<ModelElementFacade>
     */
    protected abstract Collection<ModelElementFacade> handleGetRequiredProperties(boolean follow, boolean withIdentifiers);

    /**
     * Gets all required properties for this entity.  These consist of any required attributes as
     * well as navigable associations that are marked as 'required'.  If 'follow' is true, then the
     * inheritance hierchy will be followed and all required properties from super classes will be
     * included as well.
     * If 'withIdentifiers' is true, the identifiers will be include, if false, no identifiers will
     * be included.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retreiving the properties. If true,
     * the required propertis in super classes will also be returned, if false, just the ones
     * directly on the entity will be returned.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list of required attributes.
     * @return handleGetRequiredProperties(follow, withIdentifiers)
     */
    public Collection<ModelElementFacade> getRequiredProperties(boolean follow, boolean withIdentifiers)
    {
        // getRequiredProperties has no pre constraints
        Collection<ModelElementFacade> returnValue = handleGetRequiredProperties(follow, withIdentifiers);
        // getRequiredProperties has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all attributes of the entity, and optionally retieves the super entities attributes as
     * well as excludes the entity's identifiers if 'withIdentifiers' is set to false.
     * @param follow
     * @param withIdentifiers
     * @return Collection<AttributeFacade>
     */
    protected abstract Collection<AttributeFacade> handleGetAttributes(boolean follow, boolean withIdentifiers);

    /**
     * Gets all attributes of the entity, and optionally retieves the super entities attributes as
     * well as excludes the entity's identifiers if 'withIdentifiers' is set to false.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retreiving attributes.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the returned attributes.
     * @return handleGetAttributes(follow, withIdentifiers)
     */
    public Collection<AttributeFacade> getAttributes(boolean follow, boolean withIdentifiers)
    {
        // getAttributes has no pre constraints
        Collection<AttributeFacade> returnValue = handleGetAttributes(follow, withIdentifiers);
        // getAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets a comma separated list of attribute types.  If 'follow' is true, will travel up the
     * inheritance hierarchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetAttributeTypeList(boolean follow, boolean withIdentifiers);

    /**
     * Gets a comma separated list of attribute types.  If 'follow' is true, will travel up the
     * inheritance hierarchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers.
     * @param follow boolean
     * Whether or not to 'follow' the inheritance hierarchy.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers.
     * @return handleGetAttributeTypeList(follow, withIdentifiers)
     */
    public String getAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        // getAttributeTypeList has no pre constraints
        String returnValue = handleGetAttributeTypeList(follow, withIdentifiers);
        // getAttributeTypeList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets a comma separated list of attribute names.  If 'follow' is true, will travel up the
     * inheritance hiearchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetAttributeNameList(boolean follow, boolean withIdentifiers);

    /**
     * Gets a comma separated list of attribute names.  If 'follow' is true, will travel up the
     * inheritance hiearchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers.
     * @param follow boolean
     * Whether or not to 'follow' the inheritance hierarchy.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the returned attributes.
     * @return handleGetAttributeNameList(follow, withIdentifiers)
     */
    public String getAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        // getAttributeNameList has no pre constraints
        String returnValue = handleGetAttributeNameList(follow, withIdentifiers);
        // getAttributeNameList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets a comma separated list of attribute types with are required.  If 'follow' is true, will
     * travel up the inheritance hierarchy to include attributes in parent entities as well.  If
     * 'withIdentifiers' is true, will include identifiers.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetRequiredAttributeTypeList(boolean follow, boolean withIdentifiers);

    /**
     * Gets a comma separated list of attribute types with are required.  If 'follow' is true, will
     * travel up the inheritance hierarchy to include attributes in parent entities as well.  If
     * 'withIdentifiers' is true, will include identifiers.
     * @param follow boolean
     * Whether or not to 'follow' the inheritance hierarchy.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list of required attributes.
     * @return handleGetRequiredAttributeTypeList(follow, withIdentifiers)
     */
    public String getRequiredAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        // getRequiredAttributeTypeList has no pre constraints
        String returnValue = handleGetRequiredAttributeTypeList(follow, withIdentifiers);
        // getRequiredAttributeTypeList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets a comma separated list of required attribute names.  If 'follow' is true, will travel up
     * the inheritance hierarchy to include attributes in parent entities as well.  If
     * 'withIdentifiers' is true, will include identifiers.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetRequiredAttributeNameList(boolean follow, boolean withIdentifiers);

    /**
     * Gets a comma separated list of required attribute names.  If 'follow' is true, will travel up
     * the inheritance hierarchy to include attributes in parent entities as well.  If
     * 'withIdentifiers' is true, will include identifiers.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retreiving the attributes. If true,
     * the required attributes in super classes will also be used, if false, just the ones directly
     * on the entity will be added to the list.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list of required attribute names.
     * @return handleGetRequiredAttributeNameList(follow, withIdentifiers)
     */
    public String getRequiredAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        // getRequiredAttributeNameList has no pre constraints
        String returnValue = handleGetRequiredAttributeNameList(follow, withIdentifiers);
        // getRequiredAttributeNameList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all query operations for an entity. If 'follow' is true, and if no query operations can
     * be found on the entity, a search up the inheritance chain will be performed, and the
     * identifiers from the first super class having them will be used.   If no identifiers exist, a
     * default identifier will be created if the allowDefaultIdentifiers property is set to true.
     * @param follow
     * @return Collection<OperationFacade>
     */
    protected abstract Collection<OperationFacade> handleGetQueryOperations(boolean follow);

    /**
     * Gets all query operations for an entity. If 'follow' is true, and if no query operations can
     * be found on the entity, a search up the inheritance chain will be performed, and the
     * identifiers from the first super class having them will be used.   If no identifiers exist, a
     * default identifier will be created if the allowDefaultIdentifiers property is set to true.
     * @param follow boolean
     * TODO: Model Documentation for Entity.getQueryOperations(follow)
     * @return handleGetQueryOperations(follow)
     */
    public Collection<OperationFacade> getQueryOperations(boolean follow)
    {
        // getQueryOperations has no pre constraints
        Collection<OperationFacade> returnValue = handleGetQueryOperations(follow);
        // getQueryOperations has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Creates a comma separated list of the required property names.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetRequiredPropertyNameList(boolean follow, boolean withIdentifiers);

    /**
     * Creates a comma separated list of the required property names.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retrieving the properties.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list.
     * @return handleGetRequiredPropertyNameList(follow, withIdentifiers)
     */
    public String getRequiredPropertyNameList(boolean follow, boolean withIdentifiers)
    {
        // getRequiredPropertyNameList has no pre constraints
        String returnValue = handleGetRequiredPropertyNameList(follow, withIdentifiers);
        // getRequiredPropertyNameList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * A comma separated list of the required property types.
     * @param follow
     * @param withIdentifiers
     * @return String
     */
    protected abstract String handleGetRequiredPropertyTypeList(boolean follow, boolean withIdentifiers);

    /**
     * A comma separated list of the required property types.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the list.
     * @return handleGetRequiredPropertyTypeList(follow, withIdentifiers)
     */
    public String getRequiredPropertyTypeList(boolean follow, boolean withIdentifiers)
    {
        // getRequiredPropertyTypeList has no pre constraints
        String returnValue = handleGetRequiredPropertyTypeList(follow, withIdentifiers);
        // getRequiredPropertyTypeList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all properties of this entity, this includes the attributes and navigable association
     * ends of the entity.  The 'follow' flag indcates whether or not the inheritance hierarchy
     * should be followed when getting all the properties.  The 'withIdentifiers' flag indicates
     * whether or not identifiers should be included in the collection of properties.
     * @param follow
     * @param withIdentifiers
     * @return Collection<ModelElementFacade>
     */
    protected abstract Collection<ModelElementFacade> handleGetProperties(boolean follow, boolean withIdentifiers);

    /**
     * Gets all properties of this entity, this includes the attributes and navigable association
     * ends of the entity.  The 'follow' flag indcates whether or not the inheritance hierarchy
     * should be followed when getting all the properties.  The 'withIdentifiers' flag indicates
     * whether or not identifiers should be included in the collection of properties.
     * @param follow boolean
     * TODO: Model Documentation for Entity.getProperties(follow)
     * @param withIdentifiers boolean
     * TODO: Model Documentation for
     * Entity.getProperties(withIdentifiers)
     * @return handleGetProperties(follow, withIdentifiers)
     */
    public Collection<ModelElementFacade> getProperties(boolean follow, boolean withIdentifiers)
    {
        // getProperties has no pre constraints
        Collection<ModelElementFacade> returnValue = handleGetProperties(follow, withIdentifiers);
        // getProperties has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all the associationEnds of this entity marked with the identifiers stereotype.
     * @return Collection<AssociationEndFacade>
     */
    protected abstract Collection<AssociationEndFacade> handleGetIdentifierAssociationEnds();

    /**
     * Gets all the associationEnds of this entity marked with the identifiers stereotype.
     * @return handleGetIdentifierAssociationEnds()
     */
    public Collection<AssociationEndFacade> getIdentifierAssociationEnds()
    {
        // getIdentifierAssociationEnds has no pre constraints
        Collection<AssociationEndFacade> returnValue = handleGetIdentifierAssociationEnds();
        // getIdentifierAssociationEnds has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all attributes of the entity, and optionally retieves the super entities attributes as
     * well as excludes the entity's identifiers if 'withIdentifiers' is set to false and exclude
     * derived attributes if 'withDerived' is set to false.
     * @param follow
     * @param withIdentifiers
     * @param withDerived
     * @return Collection<AttributeFacade>
     */
    protected abstract Collection<AttributeFacade> handleGetAttributes(boolean follow, boolean withIdentifiers, boolean withDerived);

    /**
     * Gets all attributes of the entity, and optionally retieves the super entities attributes as
     * well as excludes the entity's identifiers if 'withIdentifiers' is set to false and exclude
     * derived attributes if 'withDerived' is set to false.
     * @param follow boolean
     * Whether or not to follow the inheritance hierarchy when retreiving attributes.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the returned attributes.
     * @param withDerived boolean
     * Whether or not to include derived attributes in the returned attributes.
     * @return handleGetAttributes(follow, withIdentifiers, withDerived)
     */
    public Collection<AttributeFacade> getAttributes(boolean follow, boolean withIdentifiers, boolean withDerived)
    {
        // getAttributes has no pre constraints
        Collection<AttributeFacade> returnValue = handleGetAttributes(follow, withIdentifiers, withDerived);
        // getAttributes has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets a comma separated list of attribute names.  If 'follow' is true, will travel up the
     * inheritance hiearchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers  and  if 'withDerived' is set to true, will include derived
     * attributes.
     * @param follow
     * @param withIdentifiers
     * @param withDerived
     * @return String
     */
    protected abstract String handleGetAttributeNameList(boolean follow, boolean withIdentifiers, boolean withDerived);

    /**
     * Gets a comma separated list of attribute names.  If 'follow' is true, will travel up the
     * inheritance hiearchy to include attributes in parent entities as well.  If 'withIdentifiers'
     * is true, will include identifiers  and  if 'withDerived' is set to true, will include derived
     * attributes.
     * @param follow boolean
     * Whether or not to 'follow' the inheritance hierarchy.
     * @param withIdentifiers boolean
     * Whether or not to include identifiers in the returned attributes.
     * @param withDerived boolean
     * Whether or not to include derived attributes in the returned attributes.
     * @return handleGetAttributeNameList(follow, withIdentifiers, withDerived)
     */
    public String getAttributeNameList(boolean follow, boolean withIdentifiers, boolean withDerived)
    {
        // getAttributeNameList has no pre constraints
        String returnValue = handleGetAttributeNameList(follow, withIdentifiers, withDerived);
        // getAttributeNameList has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * Represents a persistent entity.
     * @return (Collection<DependencyFacade>)handleGetEntityReferences()
     */
    public final Collection<DependencyFacade> getEntityReferences()
    {
        Collection<DependencyFacade> getEntityReferences1r = null;
        // entity has no pre constraints
        Collection result = handleGetEntityReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getEntityReferences1r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getEntityReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getEntityReferences1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetEntityReferences();

    /**
     * Represents a persistent entity.
     * @return (Collection<DependencyFacade>)handleGetAllEntityReferences()
     */
    public final Collection<DependencyFacade> getAllEntityReferences()
    {
        Collection<DependencyFacade> getAllEntityReferences2r = null;
        // entity has no pre constraints
        Collection result = handleGetAllEntityReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllEntityReferences2r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getAllEntityReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getAllEntityReferences2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllEntityReferences();

    /**
     * Represents a persistent entity.
     * @return (EntityAssociationEnd)handleGetParentEnd()
     */
    public final EntityAssociationEnd getParentEnd()
    {
        EntityAssociationEnd getParentEnd3r = null;
        // entity has no pre constraints
        Object result = handleGetParentEnd();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getParentEnd3r = (EntityAssociationEnd)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getParentEnd EntityAssociationEnd " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getParentEnd3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetParentEnd();

    /**
     * Represents a persistent entity.
     * @return (Collection<ModelElementFacade>)handleGetIdentifiers()
     */
    public final Collection<ModelElementFacade> getIdentifiers()
    {
        Collection<ModelElementFacade> getIdentifiers4r = null;
        // entity has no pre constraints
        Collection result = handleGetIdentifiers();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getIdentifiers4r = (Collection<ModelElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getIdentifiers Collection<ModelElementFacade> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getIdentifiers4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetIdentifiers();

    /**
     * Represents a persistent entity.
     * @return (Collection<EntityAssociationEnd>)handleGetChildEnds()
     */
    public final Collection<EntityAssociationEnd> getChildEnds()
    {
        Collection<EntityAssociationEnd> getChildEnds5r = null;
        // entity has no pre constraints
        Collection result = handleGetChildEnds();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getChildEnds5r = (Collection<EntityAssociationEnd>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getChildEnds Collection<EntityAssociationEnd> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getChildEnds5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetChildEnds();

    /**
     * Represents a persistent entity.
     * @return (Collection<EntityQueryOperation>)handleGetQueryOperations()
     */
    public final Collection<EntityQueryOperation> getQueryOperations()
    {
        Collection<EntityQueryOperation> getQueryOperations6r = null;
        // entity has no pre constraints
        Collection result = handleGetQueryOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getQueryOperations6r = (Collection<EntityQueryOperation>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getQueryOperations Collection<EntityQueryOperation> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getQueryOperations6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetQueryOperations();

    /**
     * Represents a persistent entity.
     * @return (Collection<OperationFacade>)handleGetBusinessOperations()
     */
    public final Collection<OperationFacade> getBusinessOperations()
    {
        Collection<OperationFacade> getBusinessOperations7r = null;
        // entity has no pre constraints
        Collection result = handleGetBusinessOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getBusinessOperations7r = (Collection<OperationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            EntityLogic.logger.warn("incorrect metafacade cast for EntityLogic.getBusinessOperations Collection<OperationFacade> " + result + ": " + shieldedResult);
        }
        // entity has no post constraints
        return getBusinessOperations7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetBusinessOperations();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::Entity::entity must have at least one primary key</p>
     * <p><b>Error:</b> Each entity must have at least one identifier defined.</p>
     * <p><b>OCL:</b> context Entity inv: identifiersPresent</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::Entity::entities can only specialize other entites</p>
     * <p><b>Error:</b> An entity can only specialize another entity.</p>
     * <p><b>OCL:</b> context Entity inv : specializations -> notEmpty() implies specializations -> forAll(oclIsKindOf(Entity))</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLIntrospector.invoke(contextElement,"identifiersPresent"));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::Entity::entity must have at least one primary key",
                        "Each entity must have at least one identifier defined."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::Entity::entity must have at least one primary key' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"specializations")))).booleanValue()?OCLCollections.forAll(OCLIntrospector.invoke(contextElement,"specializations"),new Predicate(){public boolean evaluate(Object object){return Boolean.valueOf(String.valueOf(object instanceof Entity)).booleanValue();}}):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::Entity::entities can only specialize other entites",
                        "An entity can only specialize another entity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::Entity::entities can only specialize other entites' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}