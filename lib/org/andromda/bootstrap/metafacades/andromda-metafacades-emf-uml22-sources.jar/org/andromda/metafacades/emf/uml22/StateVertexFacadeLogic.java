// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.PartitionFacade;
import org.andromda.metafacades.uml.StateFacade;
import org.andromda.metafacades.uml.StateMachineFacade;
import org.andromda.metafacades.uml.StateVertexFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Vertex;

/**
 * A representation of the model object 'Vertex'. An abstraction of a node in a state machine graph.
 * In general, it can be the source or destination of any number of transitions.
 * MetafacadeLogic for StateVertexFacade
 *
 * @see StateVertexFacade
 */
public abstract class StateVertexFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements StateVertexFacade
{
    /**
     * The underlying UML object
     * @see Vertex
     */
    protected Vertex metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected StateVertexFacadeLogic(Vertex metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(StateVertexFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to StateVertexFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateVertexFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see StateVertexFacade
     */
    public boolean isStateVertexFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Vertex'. An abstraction of a node in a state machine
     * graph. In
     * general, it can be the source or destination of any number of transitions.
     * @return (Collection<TransitionFacade>)handleGetOutgoings()
     */
    public final Collection<TransitionFacade> getOutgoings()
    {
        Collection<TransitionFacade> getOutgoings1r = null;
        // target has no pre constraints
        Collection result = handleGetOutgoings();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getOutgoings1r = (Collection<TransitionFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateVertexFacadeLogic.logger.warn("incorrect metafacade cast for StateVertexFacadeLogic.getOutgoings Collection<TransitionFacade> " + result + ": " + shieldedResult);
        }
        // target has no post constraints
        return getOutgoings1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOutgoings();

    private PartitionFacade __getPartition2r;
    private boolean __getPartition2rSet = false;

    /**
     * All vertices enveloped by this partition.
     * @return (PartitionFacade)handleGetPartition()
     */
    public final PartitionFacade getPartition()
    {
        PartitionFacade getPartition2r = this.__getPartition2r;
        if (!this.__getPartition2rSet)
        {
            // vertices has no pre constraints
            Object result = handleGetPartition();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getPartition2r = (PartitionFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                StateVertexFacadeLogic.logger.warn("incorrect metafacade cast for StateVertexFacadeLogic.getPartition PartitionFacade " + result + ": " + shieldedResult);
            }
            // vertices has no post constraints
            this.__getPartition2r = getPartition2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getPartition2rSet = true;
            }
        }
        return getPartition2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetPartition();

    /**
     * A representation of the model object 'Vertex'. An abstraction of a node in a state machine
     * graph. In
     * general, it can be the source or destination of any number of transitions.
     * @return (StateFacade)handleGetContainer()
     */
    public final StateFacade getContainer()
    {
        StateFacade getContainer3r = null;
        // stateVertexFacade has no pre constraints
        Object result = handleGetContainer();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getContainer3r = (StateFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateVertexFacadeLogic.logger.warn("incorrect metafacade cast for StateVertexFacadeLogic.getContainer StateFacade " + result + ": " + shieldedResult);
        }
        // stateVertexFacade has no post constraints
        return getContainer3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetContainer();

    private StateMachineFacade __getStateMachine4r;
    private boolean __getStateMachine4rSet = false;

    /**
     * A representation of the model object 'Vertex'. An abstraction of a node in a state machine
     * graph. In
     * general, it can be the source or destination of any number of transitions.
     * @return (StateMachineFacade)handleGetStateMachine()
     */
    public final StateMachineFacade getStateMachine()
    {
        StateMachineFacade getStateMachine4r = this.__getStateMachine4r;
        if (!this.__getStateMachine4rSet)
        {
            // stateVertexFacade has no pre constraints
            Object result = handleGetStateMachine();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getStateMachine4r = (StateMachineFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                StateVertexFacadeLogic.logger.warn("incorrect metafacade cast for StateVertexFacadeLogic.getStateMachine StateMachineFacade " + result + ": " + shieldedResult);
            }
            // stateVertexFacade has no post constraints
            this.__getStateMachine4r = getStateMachine4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getStateMachine4rSet = true;
            }
        }
        return getStateMachine4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetStateMachine();

    /**
     * A representation of the model object 'Vertex'. An abstraction of a node in a state machine
     * graph. In
     * general, it can be the source or destination of any number of transitions.
     * @return (Collection<TransitionFacade>)handleGetIncomings()
     */
    public final Collection<TransitionFacade> getIncomings()
    {
        Collection<TransitionFacade> getIncomings5r = null;
        // source has no pre constraints
        Collection result = handleGetIncomings();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getIncomings5r = (Collection<TransitionFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            StateVertexFacadeLogic.logger.warn("incorrect metafacade cast for StateVertexFacadeLogic.getIncomings Collection<TransitionFacade> " + result + ": " + shieldedResult);
        }
        // source has no post constraints
        return getIncomings5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetIncomings();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}