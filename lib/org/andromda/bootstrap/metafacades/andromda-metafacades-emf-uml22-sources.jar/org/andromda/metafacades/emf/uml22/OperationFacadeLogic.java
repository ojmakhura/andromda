// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ConstraintFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.metafacades.uml.ParameterFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Operation;

/**
 * A behavioral feature of a classifier that specifies the name, type, parameters, and constraints
 * for invoking an associated behavior. May invoke both the execution of method behaviors as well as
 * other behavioral responses.
 * MetafacadeLogic for OperationFacade
 *
 * @see OperationFacade
 */
public abstract class OperationFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements OperationFacade
{
    /**
     * The underlying UML object
     * @see Operation
     */
    protected Operation metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected OperationFacadeLogic(Operation metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(OperationFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to OperationFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.OperationFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see OperationFacade
     */
    public boolean isOperationFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see OperationFacade#getSignature()
    * @return String
    */
    protected abstract String handleGetSignature();

    /**
     * Return the operation signature, including public/protested abstract returnType name plus
     * argument type and name
     * @return (String)handleGetSignature()
     */
    public final String getSignature()
    {
        String signature1a = null;
        // signature has no pre constraints
        signature1a = handleGetSignature();
        // signature has no post constraints
        return signature1a;
    }

   /**
    * @see OperationFacade#getCall()
    * @return String
    */
    protected abstract String handleGetCall();

    /**
     * Constructs the operation call with the operation name
     * @return (String)handleGetCall()
     */
    public final String getCall()
    {
        String call2a = null;
        // call has no pre constraints
        call2a = handleGetCall();
        // call has no post constraints
        return call2a;
    }

   /**
    * @see OperationFacade#getTypedArgumentList()
    * @return String
    */
    protected abstract String handleGetTypedArgumentList();

    /**
     * A comma-separated parameter list  (type and name of each parameter) of an operation.
     * @return (String)handleGetTypedArgumentList()
     */
    public final String getTypedArgumentList()
    {
        String typedArgumentList3a = null;
        // typedArgumentList has no pre constraints
        typedArgumentList3a = handleGetTypedArgumentList();
        // typedArgumentList has no post constraints
        return typedArgumentList3a;
    }

   /**
    * @see OperationFacade#isAbstract()
    * @return boolean
    */
    protected abstract boolean handleIsAbstract();

    /**
     * True is the operation is abstract.
     * @return (boolean)handleIsAbstract()
     */
    public final boolean isAbstract()
    {
        boolean abstract4a = false;
        // abstract has no pre constraints
        abstract4a = handleIsAbstract();
        // abstract has no post constraints
        return abstract4a;
    }

   /**
    * @see OperationFacade#getExceptionList()
    * @return String
    */
    protected abstract String handleGetExceptionList();

    /**
     * A comma separated list containing all exceptions that this operation throws.  Exceptions are
     * determined through dependencies that have the target element stereotyped as <<Exception>>.
     * @return (String)handleGetExceptionList()
     */
    public final String getExceptionList()
    {
        String exceptionList5a = null;
        // exceptionList has no pre constraints
        exceptionList5a = handleGetExceptionList();
        // exceptionList has no post constraints
        return exceptionList5a;
    }

   /**
    * @see OperationFacade#getExceptions()
    * @return Collection<ModelElementFacade>
    */
    protected abstract Collection<ModelElementFacade> handleGetExceptions();

    /**
     * A collection of all exceptions thrown by this operation.
     * @return (Collection<ModelElementFacade>)handleGetExceptions()
     */
    public final Collection<ModelElementFacade> getExceptions()
    {
        Collection<ModelElementFacade> exceptions6a = null;
        // exceptions has no pre constraints
        exceptions6a = handleGetExceptions();
        // exceptions has no post constraints
        return exceptions6a;
    }

   /**
    * @see OperationFacade#isReturnTypePresent()
    * @return boolean
    */
    protected abstract boolean handleIsReturnTypePresent();

    /**
     * True/false depending on whether or not the operation has a return type or not (i.e. a return
     * type of something other than void).
     * @return (boolean)handleIsReturnTypePresent()
     */
    public final boolean isReturnTypePresent()
    {
        boolean returnTypePresent7a = false;
        // returnTypePresent has no pre constraints
        returnTypePresent7a = handleIsReturnTypePresent();
        // returnTypePresent has no post constraints
        return returnTypePresent7a;
    }

   /**
    * @see OperationFacade#isExceptionsPresent()
    * @return boolean
    */
    protected abstract boolean handleIsExceptionsPresent();

    /**
     * True if the operation has (i.e. throws any exceptions) false otherwise.
     * @return (boolean)handleIsExceptionsPresent()
     */
    public final boolean isExceptionsPresent()
    {
        boolean exceptionsPresent8a = false;
        // exceptionsPresent has no pre constraints
        exceptionsPresent8a = handleIsExceptionsPresent();
        // exceptionsPresent has no post constraints
        return exceptionsPresent8a;
    }

   /**
    * @see OperationFacade#getArgumentNames()
    * @return String
    */
    protected abstract String handleGetArgumentNames();

    /**
     * A comma separated list of all argument names.
     * @return (String)handleGetArgumentNames()
     */
    public final String getArgumentNames()
    {
        String argumentNames9a = null;
        // argumentNames has no pre constraints
        argumentNames9a = handleGetArgumentNames();
        // argumentNames has no post constraints
        return argumentNames9a;
    }

   /**
    * @see OperationFacade#getArgumentTypeNames()
    * @return String
    */
    protected abstract String handleGetArgumentTypeNames();

    /**
     * A comma separated list of all types of each argument, in order.
     * @return (String)handleGetArgumentTypeNames()
     */
    public final String getArgumentTypeNames()
    {
        String argumentTypeNames10a = null;
        // argumentTypeNames has no pre constraints
        argumentTypeNames10a = handleGetArgumentTypeNames();
        // argumentTypeNames has no post constraints
        return argumentTypeNames10a;
    }

   /**
    * @see OperationFacade#isQuery()
    * @return boolean
    */
    protected abstract boolean handleIsQuery();

    /**
     * Indicates whether or not this operation is a query operation.
     * @return (boolean)handleIsQuery()
     */
    public final boolean isQuery()
    {
        boolean query11a = false;
        // query has no pre constraints
        query11a = handleIsQuery();
        // query has no post constraints
        return query11a;
    }

   /**
    * @see OperationFacade#getConcurrency()
    * @return String
    */
    protected abstract String handleGetConcurrency();

    /**
     * Returns the concurrency modifier for this operation (i.e. concurrent, guarded or sequential)
     * of the model element, will attempt a lookup for these values in the language mappings (if
     * any).
     * @return (String)handleGetConcurrency()
     */
    public final String getConcurrency()
    {
        String concurrency12a = null;
        // concurrency has no pre constraints
        concurrency12a = handleGetConcurrency();
        // concurrency has no post constraints
        return concurrency12a;
    }

   /**
    * @see OperationFacade#getPreconditionName()
    * @return String
    */
    protected abstract String handleGetPreconditionName();

    /**
     * The name of the operation that handles precondition constraints.
     * @return (String)handleGetPreconditionName()
     */
    public final String getPreconditionName()
    {
        String preconditionName13a = null;
        // preconditionName has no pre constraints
        preconditionName13a = handleGetPreconditionName();
        // preconditionName has no post constraints
        return preconditionName13a;
    }

   /**
    * @see OperationFacade#getPostconditionName()
    * @return String
    */
    protected abstract String handleGetPostconditionName();

    /**
     * The name of the operation that handles postcondition constraints.
     * @return (String)handleGetPostconditionName()
     */
    public final String getPostconditionName()
    {
        String postconditionName14a = null;
        // postconditionName has no pre constraints
        postconditionName14a = handleGetPostconditionName();
        // postconditionName has no post constraints
        return postconditionName14a;
    }

   /**
    * @see OperationFacade#getPreconditionSignature()
    * @return String
    */
    protected abstract String handleGetPreconditionSignature();

    /**
     * The signature of the precondition operation.
     * @return (String)handleGetPreconditionSignature()
     */
    public final String getPreconditionSignature()
    {
        String preconditionSignature15a = null;
        // preconditionSignature has no pre constraints
        preconditionSignature15a = handleGetPreconditionSignature();
        // preconditionSignature has no post constraints
        return preconditionSignature15a;
    }

   /**
    * @see OperationFacade#getPreconditionCall()
    * @return String
    */
    protected abstract String handleGetPreconditionCall();

    /**
     * The call to the precondition operation.
     * @return (String)handleGetPreconditionCall()
     */
    public final String getPreconditionCall()
    {
        String preconditionCall16a = null;
        // preconditionCall has no pre constraints
        preconditionCall16a = handleGetPreconditionCall();
        // preconditionCall has no post constraints
        return preconditionCall16a;
    }

   /**
    * @see OperationFacade#isPreconditionsPresent()
    * @return boolean
    */
    protected abstract boolean handleIsPreconditionsPresent();

    /**
     * Whether any precondition constraints are present on this operation.
     * @return (boolean)handleIsPreconditionsPresent()
     */
    public final boolean isPreconditionsPresent()
    {
        boolean preconditionsPresent17a = false;
        // preconditionsPresent has no pre constraints
        preconditionsPresent17a = handleIsPreconditionsPresent();
        // preconditionsPresent has no post constraints
        return preconditionsPresent17a;
    }

   /**
    * @see OperationFacade#isPostconditionsPresent()
    * @return boolean
    */
    protected abstract boolean handleIsPostconditionsPresent();

    /**
     * Whether any postcondition constraints are present on this operation.
     * @return (boolean)handleIsPostconditionsPresent()
     */
    public final boolean isPostconditionsPresent()
    {
        boolean postconditionsPresent18a = false;
        // postconditionsPresent has no pre constraints
        postconditionsPresent18a = handleIsPostconditionsPresent();
        // postconditionsPresent has no post constraints
        return postconditionsPresent18a;
    }

   /**
    * @see OperationFacade#getLower()
    * @return int
    */
    protected abstract int handleGetLower();

    /**
     * the lower value for the multiplicity
     * -only applicable for UML2
     * @return (int)handleGetLower()
     */
    public final int getLower()
    {
        int lower19a = 0;
        // lower has no pre constraints
        lower19a = handleGetLower();
        // lower has no post constraints
        return lower19a;
    }

   /**
    * @see OperationFacade#getUpper()
    * @return int
    */
    protected abstract int handleGetUpper();

    /**
     * the upper value for the multiplicity (will be -1 for *)
     * - only applicable for UML2
     * @return (int)handleGetUpper()
     */
    public final int getUpper()
    {
        int upper20a = 0;
        // upper has no pre constraints
        upper20a = handleGetUpper();
        // upper has no post constraints
        return upper20a;
    }

   /**
    * @see OperationFacade#getReturnParameter()
    * @return ParameterFacade
    */
    protected abstract ParameterFacade handleGetReturnParameter();

    /**
     * (UML2 Only). Get the actual return parameter (which may have stereotypes etc).
     * @return (ParameterFacade)handleGetReturnParameter()
     */
    public final ParameterFacade getReturnParameter()
    {
        ParameterFacade returnParameter21a = null;
        // returnParameter has no pre constraints
        returnParameter21a = handleGetReturnParameter();
        // returnParameter has no post constraints
        return returnParameter21a;
    }

   /**
    * @see OperationFacade#isOverriding()
    * @return boolean
    */
    protected abstract boolean handleIsOverriding();

    /**
     * True if this operation overrides an operation defined in an ancestor class. An operation
     * overrides when the names of the operations as well as the types of the arguments are equal.
     * The return type may be different and is, as well as any exceptions, ignored.
     * @return (boolean)handleIsOverriding()
     */
    public final boolean isOverriding()
    {
        boolean overriding22a = false;
        // overriding has no pre constraints
        overriding22a = handleIsOverriding();
        // overriding has no post constraints
        return overriding22a;
    }

   /**
    * @see OperationFacade#isOrdered()
    * @return boolean
    */
    protected abstract boolean handleIsOrdered();

    /**
     * UML2 only: If isMany (Collection type returned), is the type unique within the collection. 
     * Unique+Ordered determines CollectionType implementation of return result. Default=false.
     * @return (boolean)handleIsOrdered()
     */
    public final boolean isOrdered()
    {
        boolean ordered23a = false;
        // ordered has no pre constraints
        ordered23a = handleIsOrdered();
        // ordered has no post constraints
        return ordered23a;
    }

   /**
    * @see OperationFacade#getGetterSetterReturnTypeName()
    * @return String
    */
    protected abstract String handleGetGetterSetterReturnTypeName();

    /**
     * Return Type with multiplicity taken into account. UML14 does not allow multiplicity *.
     * @return (String)handleGetGetterSetterReturnTypeName()
     */
    public final String getGetterSetterReturnTypeName()
    {
        String getterSetterReturnTypeName24a = null;
        // getterSetterReturnTypeName has no pre constraints
        getterSetterReturnTypeName24a = handleGetGetterSetterReturnTypeName();
        // getterSetterReturnTypeName has no post constraints
        return getterSetterReturnTypeName24a;
    }

   /**
    * @see OperationFacade#isMany()
    * @return boolean
    */
    protected abstract boolean handleIsMany();

    /**
     * UML2 only. If the return type parameter multiplicity>1 OR the operation multiplicity>1.
     * Default=false.
     * @return (boolean)handleIsMany()
     */
    public final boolean isMany()
    {
        boolean many25a = false;
        // many has no pre constraints
        many25a = handleIsMany();
        // many has no post constraints
        return many25a;
    }

   /**
    * @see OperationFacade#isUnique()
    * @return boolean
    */
    protected abstract boolean handleIsUnique();

    /**
     * UML2 only: for Collection return type, is the type unique within the collection.
     * Unique+Ordered determines the returned CollectionType. Default=false.
     * @return (boolean)handleIsUnique()
     */
    public final boolean isUnique()
    {
        boolean unique26a = false;
        // unique has no pre constraints
        unique26a = handleIsUnique();
        // unique has no post constraints
        return unique26a;
    }

   /**
    * @see OperationFacade#isLeaf()
    * @return boolean
    */
    protected abstract boolean handleIsLeaf();

    /**
     * IsLeaf property in the operation. If true, operation is final, cannot be extended or
     * implemented by a descendant. Default=false.
     * @return (boolean)handleIsLeaf()
     */
    public final boolean isLeaf()
    {
        boolean leaf27a = false;
        // leaf has no pre constraints
        leaf27a = handleIsLeaf();
        // leaf has no post constraints
        return leaf27a;
    }

   /**
    * @see OperationFacade#getMethodBody()
    * @return String
    */
    protected abstract String handleGetMethodBody();

    /**
     * Returns the operation method body determined from UML sequence diagrams or other UML sources.
     * @return (String)handleGetMethodBody()
     */
    public final String getMethodBody()
    {
        String methodBody28a = null;
        // methodBody has no pre constraints
        methodBody28a = handleGetMethodBody();
        // methodBody has no post constraints
        return methodBody28a;
    }

   /**
    * @see OperationFacade#isStatic()
    * @return boolean
    */
    protected abstract boolean handleIsStatic();

    /**
     * True is the operation is static (only a single instance can be instantiated).
     * @return (boolean)handleIsStatic()
     */
    public final boolean isStatic()
    {
        boolean static29a = false;
        // static has no pre constraints
        static29a = handleIsStatic();
        // static has no post constraints
        return static29a;
    }

   /**
    * @see OperationFacade#getTestName()
    * @return String
    */
    protected abstract String handleGetTestName();

    /**
     * TODO: Model Documentation for OperationFacade.testName
     * @return (String)handleGetTestName()
     */
    public final String getTestName()
    {
        String testName30a = null;
        // testName has no pre constraints
        testName30a = handleGetTestName();
        // testName has no post constraints
        return testName30a;
    }

   /**
    * @see OperationFacade#getTestDisplayName()
    * @return String
    */
    protected abstract String handleGetTestDisplayName();

    /**
     * TODO: Model Documentation for OperationFacade.testDisplayName
     * @return (String)handleGetTestDisplayName()
     */
    public final String getTestDisplayName()
    {
        String testDisplayName31a = null;
        // testDisplayName has no pre constraints
        testDisplayName31a = handleGetTestDisplayName();
        // testDisplayName has no post constraints
        return testDisplayName31a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Searches the given feature for the specified tag.
     * If the follow boolean is set to true then the search will continue from the class operation
     * to the class itself and then up the class hierarchy.
     * @param name
     * @param follow
     * @return Object
     */
    protected abstract Object handleFindTaggedValue(String name, boolean follow);

    /**
     * Searches the given feature for the specified tag.
     * If the follow boolean is set to true then the search will continue from the class operation
     * to the class itself and then up the class hierarchy.
     * @param name String
     * The name of the tagged value to find.
     * @param follow boolean
     * TODO: Model Documentation for
     * OperationFacade.findTaggedValue(follow)
     * @return handleFindTaggedValue(name, follow)
     */
    public Object findTaggedValue(String name, boolean follow)
    {
        // findTaggedValue has no pre constraints
        Object returnValue = handleFindTaggedValue(name, follow);
        // findTaggedValue has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns a comma separated list of exceptions appended to the comma separated list of fully
     * qualified 'initialException' classes passed in to this method.
     * @param initialExceptions
     * @return String
     */
    protected abstract String handleGetExceptionList(String initialExceptions);

    /**
     * Returns a comma separated list of exceptions appended to the comma separated list of fully
     * qualified 'initialException' classes passed in to this method.
     * @param initialExceptions String
     * A comma separated list of fully qualified 'initialException' classes passed in to this
     * method.
     * @return handleGetExceptionList(initialExceptions)
     */
    public String getExceptionList(String initialExceptions)
    {
        // getExceptionList has no pre constraints
        String returnValue = handleGetExceptionList(initialExceptions);
        // getExceptionList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns the signature of the operation and optionally appends the argument names (if
     * withArgumentNames is true), otherwise returns the signature with just the types alone in the
     * signature.
     * @param withArgumentNames
     * @return String
     */
    protected abstract String handleGetSignature(boolean withArgumentNames);

    /**
     * Returns the signature of the operation and optionally appends the argument names (if
     * withArgumentNames is true), otherwise returns the signature with just the types alone in the
     * signature.
     * @param withArgumentNames boolean
     * TODO: Model Documentation for
     * OperationFacade.getSignature(withArgumentNames)
     * @return handleGetSignature(withArgumentNames)
     */
    public String getSignature(boolean withArgumentNames)
    {
        // getSignature has no pre constraints
        String returnValue = handleGetSignature(withArgumentNames);
        // getSignature has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * A comma-separated parameter list  (type and name of each parameter) of an operation with an
     * optional modifier (i.e final) before each parameter.
     * @param modifier
     * @return String
     */
    protected abstract String handleGetTypedArgumentList(String modifier);

    /**
     * A comma-separated parameter list  (type and name of each parameter) of an operation with an
     * optional modifier (i.e final) before each parameter.
     * @param modifier String
     * The modifier to prefix the arguments with (i.e. 'final')
     * @return handleGetTypedArgumentList(modifier)
     */
    public String getTypedArgumentList(String modifier)
    {
        // getTypedArgumentList has no pre constraints
        String returnValue = handleGetTypedArgumentList(modifier);
        // getTypedArgumentList has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns the signature of the operation and optionally appends the given 'argumentModifier' to
     * each argument.
     * @param argumentModifier
     * @return String
     */
    protected abstract String handleGetSignature(String argumentModifier);

    /**
     * Returns the signature of the operation and optionally appends the given 'argumentModifier' to
     * each argument.
     * @param argumentModifier String
     * The modifier to give the arguments (i.e. 'final').
     * @return handleGetSignature(argumentModifier)
     */
    public String getSignature(String argumentModifier)
    {
        // getSignature has no pre constraints
        String returnValue = handleGetSignature(argumentModifier);
        // getSignature has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the parameter on this operation having the given name, if no parameter is found, null
     * is returned instead.
     * @param name
     * @return ParameterFacade
     */
    protected abstract ParameterFacade handleFindParameter(String name);

    /**
     * Finds the parameter on this operation having the given name, if no parameter is found, null
     * is returned instead.
     * @param name String
     * The name of the parameter to find on the owner operation.
     * @return handleFindParameter(name)
     */
    public ParameterFacade findParameter(String name)
    {
        // findParameter has no pre constraints
        ParameterFacade returnValue = handleFindParameter(name);
        // findParameter has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * A behavioral feature of a classifier that specifies the name, type, parameters, and
     * constraints for
     * invoking an associated behavior. May invoke both the execution of method behaviors as well as
     * other
     * behavioral responses.
     * @return (Collection<ConstraintFacade>)handleGetPostconditions()
     */
    public final Collection<ConstraintFacade> getPostconditions()
    {
        Collection<ConstraintFacade> getPostconditions1r = null;
        // operationFacade has no pre constraints
         Collection result = handleGetPostconditions();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getPostconditions1r = (Collection<ConstraintFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getPostconditions Collection<ConstraintFacade> " + result + ": " + shieldedResult);
        }
        // operationFacade has no post constraints
        return getPostconditions1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetPostconditions();

    /**
     * A behavioral feature of a classifier that specifies the name, type, parameters, and
     * constraints for
     * invoking an associated behavior. May invoke both the execution of method behaviors as well as
     * other
     * behavioral responses.
     * @return (Collection<ParameterFacade>)handleGetArguments()
     */
    public final Collection<ParameterFacade> getArguments()
    {
        Collection<ParameterFacade> getArguments2r = null;
        // operationFacade has no pre constraints
         Collection result = handleGetArguments();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getArguments2r = (Collection<ParameterFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getArguments Collection<ParameterFacade> " + result + ": " + shieldedResult);
        }
        // operationFacade has no post constraints
        return getArguments2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetArguments();

    private OperationFacade __getOverriddenOperation3r;
    private boolean __getOverriddenOperation3rSet = false;

    /**
     * A behavioral feature of a classifier that specifies the name, type, parameters, and
     * constraints for
     * invoking an associated behavior. May invoke both the execution of method behaviors as well as
     * other
     * behavioral responses.
     * @return (OperationFacade)handleGetOverriddenOperation()
     */
    public final OperationFacade getOverriddenOperation()
    {
        OperationFacade getOverriddenOperation3r = this.__getOverriddenOperation3r;
        if (!this.__getOverriddenOperation3rSet)
        {
            // operationFacade has no pre constraints
            Object result = handleGetOverriddenOperation();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getOverriddenOperation3r = (OperationFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getOverriddenOperation OperationFacade " + result + ": " + shieldedResult);
            }
            // operationFacade has no post constraints
            this.__getOverriddenOperation3r = getOverriddenOperation3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOverriddenOperation3rSet = true;
            }
        }
        return getOverriddenOperation3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOverriddenOperation();

    /**
     * The operations owned by this classifier.
     * @return (ClassifierFacade)handleGetOwner()
     */
    public final ClassifierFacade getOwner()
    {
        ClassifierFacade getOwner4r = null;
        // operations has no pre constraints
        Object result = handleGetOwner();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOwner4r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getOwner ClassifierFacade " + result + ": " + shieldedResult);
        }
        // operations has no post constraints
        return getOwner4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOwner();

    /**
     * If this parameter is located on an operation, this will represent that operation.
     * @return (Collection<ParameterFacade>)handleGetParameters()
     */
    public final Collection<ParameterFacade> getParameters()
    {
        Collection<ParameterFacade> getParameters5r = null;
        // operation has no pre constraints
         Collection result = handleGetParameters();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getParameters5r = (Collection<ParameterFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getParameters Collection<ParameterFacade> " + result + ": " + shieldedResult);
        }
        // operation has no post constraints
        return getParameters5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetParameters();

    /**
     * A behavioral feature of a classifier that specifies the name, type, parameters, and
     * constraints for
     * invoking an associated behavior. May invoke both the execution of method behaviors as well as
     * other
     * behavioral responses.
     * @return (ClassifierFacade)handleGetReturnType()
     */
    public final ClassifierFacade getReturnType()
    {
        ClassifierFacade getReturnType6r = null;
        // operationFacade has no pre constraints
        Object result = handleGetReturnType();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getReturnType6r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getReturnType ClassifierFacade " + result + ": " + shieldedResult);
        }
        // operationFacade has no post constraints
        return getReturnType6r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetReturnType();

    /**
     * A behavioral feature of a classifier that specifies the name, type, parameters, and
     * constraints for
     * invoking an associated behavior. May invoke both the execution of method behaviors as well as
     * other
     * behavioral responses.
     * @return (Collection<ConstraintFacade>)handleGetPreconditions()
     */
    public final Collection<ConstraintFacade> getPreconditions()
    {
        Collection<ConstraintFacade> getPreconditions7r = null;
        // operationFacade has no pre constraints
         Collection result = handleGetPreconditions();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getPreconditions7r = (Collection<ConstraintFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationFacadeLogic.logger.warn("incorrect metafacade cast for OperationFacadeLogic.getPreconditions Collection<ConstraintFacade> " + result + ": " + shieldedResult);
        }
        // operationFacade has no post constraints
        return getPreconditions7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetPreconditions();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::operation needs a return type</p>
     * <p><b>Error:</b> Each operation needs a return type, you cannot leave the type unspecified, even if you want void
you'll need to explicitly specify it.</p>
     * <p><b>OCL:</b> context OperationFacade
inv: returnType.name->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::operation must have a name</p>
     * <p><b>Error:</b> Each operation must have a non-empty name.</p>
     * <p><b>OCL:</b> context OperationFacade 
inv: name -> notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::primitive operation return cannot be used in a Collection</p>
     * <p><b>Error:</b> Primitive return parameters cannot be used in Collections (multiplicity > 1). Use the wrapped type
or Array type instead.</p>
     * <p><b>OCL:</b> context OperationFacade inv: returnParameter.type.primitive implies (many = false)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::wrapped primitive operation return should not be required</p>
     * <p><b>Error:</b> Wrapped primitive operation return must have a multiplicity lower bound = 0 (must be optional). Use
the unwrapped type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context OperationFacade inv: returnParameter.type.wrappedPrimitive and many = false implies (lower = 0)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::primitive operation return must be required</p>
     * <p><b>Error:</b> Primitive operation return types must have a multiplicity lower bound > 0 (must be required). Use a
wrapped type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context OperationFacade inv: returnParameter.type.primitive implies (lower > 0)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::OperationFacade::operation multiplicity must match return parameter multiplicity</p>
     * <p><b>Error:</b> Operation return parameter with multiplicity greater than 1 must match the operation multiplicity
greater than 1.</p>
     * <p><b>OCL:</b> context OperationFacade
inv: many implies (returnParameter.many)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"returnType.name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::operation needs a return type",
                        "Each operation needs a return type, you cannot leave the type unspecified, even if you want void\nyou'll need to explicitly specify it."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::operation needs a return type' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::operation must have a name",
                        "Each operation must have a non-empty name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::operation must have a name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"returnParameter.type.primitive"))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::primitive operation return cannot be used in a Collection",
                        "Primitive return parameters cannot be used in Collections (multiplicity > 1). Use the wrapped type\nor Array type instead."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::primitive operation return cannot be used in a Collection' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"returnParameter.type.wrappedPrimitive"))).booleanValue()&&OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::wrapped primitive operation return should not be required",
                        "Wrapped primitive operation return must have a multiplicity lower bound = 0 (must be optional). Use\nthe unwrapped type, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::wrapped primitive operation return should not be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"returnParameter.type.primitive"))).booleanValue()?(OCLExpressions.greater(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::primitive operation return must be required",
                        "Primitive operation return types must have a multiplicity lower bound > 0 (must be required). Use a\nwrapped type, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::primitive operation return must be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"many"))).booleanValue()?(OCLIntrospector.invoke(contextElement,"returnParameter.many")):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::OperationFacade::operation multiplicity must match return parameter multiplicity",
                        "Operation return parameter with multiplicity greater than 1 must match the operation multiplicity\ngreater than 1."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::OperationFacade::operation multiplicity must match return parameter multiplicity' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}