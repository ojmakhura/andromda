// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActivityGraph;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndEvent;
import org.andromda.metafacades.uml.FrontEndForward;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndUseCase;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Transition;

/**
 * A front end forward is any transition between front-end states.
 * MetafacadeLogic for FrontEndForward
 *
 * @see FrontEndForward
 */
public abstract class FrontEndForwardLogic
    extends TransitionFacadeLogicImpl
    implements FrontEndForward
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndForwardLogic(Object metaObjectIn, String context)
    {
        super((Transition)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndForwardLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndForward if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndForward";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndForward
     */
    public boolean isFrontEndForwardMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndForward#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * Indicates if this forward is contained in a FrontEndUseCase.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase1a;
    }

   /**
    * @see FrontEndForward#getActionMethodName()
    * @return String
    */
    protected abstract String handleGetActionMethodName();

    /**
     * The method name used to delegate to this forward.
     * @return (String)handleGetActionMethodName()
     */
    public final String getActionMethodName()
    {
        String actionMethodName2a = null;
        // actionMethodName has no pre constraints
        actionMethodName2a = handleGetActionMethodName();
        // actionMethodName has no post constraints
        return actionMethodName2a;
    }

   /**
    * @see FrontEndForward#isEnteringView()
    * @return boolean
    */
    protected abstract boolean handleIsEnteringView();

    /**
     * Indicates if this action directly targets a "front-end" view, false otherwise.
     * @return (boolean)handleIsEnteringView()
     */
    public final boolean isEnteringView()
    {
        boolean enteringView3a = false;
        // enteringView has no pre constraints
        enteringView3a = handleIsEnteringView();
        // enteringView has no post constraints
        return enteringView3a;
    }

   /**
    * @see FrontEndForward#isExitingView()
    * @return boolean
    */
    protected abstract boolean handleIsExitingView();

    /**
     * Indicates if this forward (transition) is coming out of a front-end view.
     * @return (boolean)handleIsExitingView()
     */
    public final boolean isExitingView()
    {
        boolean exitingView4a = false;
        // exitingView has no pre constraints
        exitingView4a = handleIsExitingView();
        // exitingView has no post constraints
        return exitingView4a;
    }

   /**
    * @see FrontEndForward#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * The path to which this forward points.
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path5a = null;
        // path has no pre constraints
        path5a = handleGetPath();
        // path has no post constraints
        return path5a;
    }

   /**
    * @see FrontEndForward#isFinalStateTarget()
    * @return boolean
    */
    protected abstract boolean handleIsFinalStateTarget();

    /**
     * Indicates whether or not a final state is the target of this forward.
     * @return (boolean)handleIsFinalStateTarget()
     */
    public final boolean isFinalStateTarget()
    {
        boolean finalStateTarget6a = false;
        // finalStateTarget has no pre constraints
        finalStateTarget6a = handleIsFinalStateTarget();
        // finalStateTarget has no post constraints
        return finalStateTarget6a;
    }

   /**
    * @see FrontEndForward#getFromOutcome()
    * @return String
    */
    protected abstract String handleGetFromOutcome();

    /**
     * The name that corresponds to the from-outcome in an navigational rule.
     * @return (String)handleGetFromOutcome()
     */
    public final String getFromOutcome()
    {
        String fromOutcome7a = null;
        // fromOutcome has no pre constraints
        fromOutcome7a = handleGetFromOutcome();
        // fromOutcome has no post constraints
        return fromOutcome7a;
    }

   /**
    * @see FrontEndForward#getSuccessMessages()
    * @return Map
    */
    protected abstract Map handleGetSuccessMessages();

    /**
     * Messages used to indicate successful execution.
     * @return (Map)handleGetSuccessMessages()
     */
    public final Map getSuccessMessages()
    {
        Map successMessages8a = null;
        // successMessages has no pre constraints
        successMessages8a = handleGetSuccessMessages();
        // successMessages has no post constraints
        return successMessages8a;
    }

   /**
    * @see FrontEndForward#isSuccessMessagesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsSuccessMessagesPresent();

    /**
     * Indicates whether or not any success messags are present.
     * @return (boolean)handleIsSuccessMessagesPresent()
     */
    public final boolean isSuccessMessagesPresent()
    {
        boolean successMessagesPresent9a = false;
        // successMessagesPresent has no pre constraints
        successMessagesPresent9a = handleIsSuccessMessagesPresent();
        // successMessagesPresent has no post constraints
        return successMessagesPresent9a;
    }

   /**
    * @see FrontEndForward#getWarningMessages()
    * @return Map
    */
    protected abstract Map handleGetWarningMessages();

    /**
     * Any messages used to indicate a warning.
     * @return (Map)handleGetWarningMessages()
     */
    public final Map getWarningMessages()
    {
        Map warningMessages10a = null;
        // warningMessages has no pre constraints
        warningMessages10a = handleGetWarningMessages();
        // warningMessages has no post constraints
        return warningMessages10a;
    }

   /**
    * @see FrontEndForward#isWarningMessagesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsWarningMessagesPresent();

    /**
     * Whether or not any warning messages are present.
     * @return (boolean)handleIsWarningMessagesPresent()
     */
    public final boolean isWarningMessagesPresent()
    {
        boolean warningMessagesPresent11a = false;
        // warningMessagesPresent has no pre constraints
        warningMessagesPresent11a = handleIsWarningMessagesPresent();
        // warningMessagesPresent has no post constraints
        return warningMessagesPresent11a;
    }

    // ------------- associations ------------------

    private FrontEndUseCase __getUseCase1r;
    private boolean __getUseCase1rSet = false;

    /**
     * A front end forward is any transition between front-end states.
     * @return (FrontEndUseCase)handleGetUseCase()
     */
    public final FrontEndUseCase getUseCase()
    {
        FrontEndUseCase getUseCase1r = this.__getUseCase1r;
        if (!this.__getUseCase1rSet)
        {
            // frontEndForward has no pre constraints
            Object result = handleGetUseCase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getUseCase1r = (FrontEndUseCase)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getUseCase FrontEndUseCase " + result + ": " + shieldedResult);
            }
            // frontEndForward has no post constraints
            this.__getUseCase1r = getUseCase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase1rSet = true;
            }
        }
        return getUseCase1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetUseCase();

    private List<FrontEndAction> __getActions2r;
    private boolean __getActions2rSet = false;

    /**
     * All the transitions that make up this action, this directly maps onto the forwards.
     * @return (List<FrontEndAction>)handleGetActions()
     */
    public final List<FrontEndAction> getActions()
    {
        List<FrontEndAction> getActions2r = this.__getActions2r;
        if (!this.__getActions2rSet)
        {
            // transitions has no pre constraints
            List result = handleGetActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getActions2r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // transitions has no post constraints
            this.__getActions2r = getActions2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions2rSet = true;
            }
        }
        return getActions2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetActions();

    private FrontEndEvent __getDecisionTrigger3r;
    private boolean __getDecisionTrigger3rSet = false;

    /**
     * A front end forward is any transition between front-end states.
     * @return (FrontEndEvent)handleGetDecisionTrigger()
     */
    public final FrontEndEvent getDecisionTrigger()
    {
        FrontEndEvent getDecisionTrigger3r = this.__getDecisionTrigger3r;
        if (!this.__getDecisionTrigger3rSet)
        {
            // frontEndForward has no pre constraints
            Object result = handleGetDecisionTrigger();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getDecisionTrigger3r = (FrontEndEvent)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getDecisionTrigger FrontEndEvent " + result + ": " + shieldedResult);
            }
            // frontEndForward has no post constraints
            this.__getDecisionTrigger3r = getDecisionTrigger3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDecisionTrigger3rSet = true;
            }
        }
        return getDecisionTrigger3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetDecisionTrigger();

    private FrontEndControllerOperation __getOperationCall4r;
    private boolean __getOperationCall4rSet = false;

    /**
     * A front end forward is any transition between front-end states.
     * @return (FrontEndControllerOperation)handleGetOperationCall()
     */
    public final FrontEndControllerOperation getOperationCall()
    {
        FrontEndControllerOperation getOperationCall4r = this.__getOperationCall4r;
        if (!this.__getOperationCall4rSet)
        {
            // frontEndForward has no pre constraints
            Object result = handleGetOperationCall();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getOperationCall4r = (FrontEndControllerOperation)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getOperationCall FrontEndControllerOperation " + result + ": " + shieldedResult);
            }
            // frontEndForward has no post constraints
            this.__getOperationCall4r = getOperationCall4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOperationCall4rSet = true;
            }
        }
        return getOperationCall4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOperationCall();

    private List<FrontEndParameter> __getForwardParameters5r;
    private boolean __getForwardParameters5rSet = false;

    /**
     * A front end forward is any transition between front-end states.
     * @return (List<FrontEndParameter>)handleGetForwardParameters()
     */
    public final List<FrontEndParameter> getForwardParameters()
    {
        List<FrontEndParameter> getForwardParameters5r = this.__getForwardParameters5r;
        if (!this.__getForwardParameters5rSet)
        {
            // frontEndForward has no pre constraints
            List result = handleGetForwardParameters();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getForwardParameters5r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getForwardParameters List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndForward has no post constraints
            this.__getForwardParameters5r = getForwardParameters5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getForwardParameters5rSet = true;
            }
        }
        return getForwardParameters5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetForwardParameters();

    private FrontEndActivityGraph __getFrontEndActivityGraph6r;
    private boolean __getFrontEndActivityGraph6rSet = false;

    /**
     * A front end forward is any transition between front-end states.
     * @return (FrontEndActivityGraph)handleGetFrontEndActivityGraph()
     */
    public final FrontEndActivityGraph getFrontEndActivityGraph()
    {
        FrontEndActivityGraph getFrontEndActivityGraph6r = this.__getFrontEndActivityGraph6r;
        if (!this.__getFrontEndActivityGraph6rSet)
        {
            // frontEndForward has no pre constraints
            Object result = handleGetFrontEndActivityGraph();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getFrontEndActivityGraph6r = (FrontEndActivityGraph)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndForwardLogic.logger.warn("incorrect metafacade cast for FrontEndForwardLogic.getFrontEndActivityGraph FrontEndActivityGraph " + result + ": " + shieldedResult);
            }
            // frontEndForward has no post constraints
            this.__getFrontEndActivityGraph6r = getFrontEndActivityGraph6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndActivityGraph6rSet = true;
            }
        }
        return getFrontEndActivityGraph6r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetFrontEndActivityGraph();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see TransitionFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}