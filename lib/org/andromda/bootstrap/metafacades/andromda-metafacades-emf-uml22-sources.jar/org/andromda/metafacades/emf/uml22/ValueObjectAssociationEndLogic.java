// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ValueObjectAssociationEnd;

/**
 * Represents the association end of a ValueObject.
 * MetafacadeLogic for ValueObjectAssociationEnd
 *
 * @see ValueObjectAssociationEnd
 */
public abstract class ValueObjectAssociationEndLogic
    extends AssociationEndFacadeLogicImpl
    implements ValueObjectAssociationEnd
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ValueObjectAssociationEndLogic(Object metaObjectIn, String context)
    {
        super((AssociationEnd)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ValueObjectAssociationEnd if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ValueObjectAssociationEnd";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ValueObjectAssociationEnd
     */
    public boolean isValueObjectAssociationEndMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ValueObjectAssociationEnd#isValueObjectType()
    * @return boolean
    */
    protected abstract boolean handleIsValueObjectType();

    /**
     * Indicates if the type of this association is a value object or not.
     * @return (boolean)handleIsValueObjectType()
     */
    public final boolean isValueObjectType()
    {
        boolean valueObjectType1a = false;
        // valueObjectType has no pre constraints
        valueObjectType1a = handleIsValueObjectType();
        // valueObjectType has no post constraints
        return valueObjectType1a;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see AssociationEndFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}