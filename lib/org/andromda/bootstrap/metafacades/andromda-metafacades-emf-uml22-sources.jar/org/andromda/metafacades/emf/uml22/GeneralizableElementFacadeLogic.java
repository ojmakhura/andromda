// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.GeneralizableElementFacade;
import org.andromda.metafacades.uml.GeneralizationFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Element;

/**
 * The model element that represents an element that can be generalized or specialized.
 * MetafacadeLogic for GeneralizableElementFacade
 *
 * @see GeneralizableElementFacade
 */
public abstract class GeneralizableElementFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements GeneralizableElementFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected GeneralizableElementFacadeLogic(Object metaObjectIn, String context)
    {
        super((Element)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(GeneralizableElementFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to GeneralizableElementFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizableElementFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see GeneralizableElementFacade
     */
    public boolean isGeneralizableElementFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see GeneralizableElementFacade#getGeneralizationList()
    * @return String
    */
    protected abstract String handleGetGeneralizationList();

    /**
     * A comma separated list of the fully qualified names of all generalizations.
     * @return (String)handleGetGeneralizationList()
     */
    public final String getGeneralizationList()
    {
        String generalizationList1a = null;
        // generalizationList has no pre constraints
        generalizationList1a = handleGetGeneralizationList();
        // generalizationList has no post constraints
        return generalizationList1a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Finds the tagged value optional searching the entire inheritance hierarchy if 'follow' is set
     * to true.
     * @param tagName
     * @param follow
     * @return Object
     */
    protected abstract Object handleFindTaggedValue(String tagName, boolean follow);

    /**
     * Finds the tagged value optional searching the entire inheritance hierarchy if 'follow' is set
     * to true.
     * @param tagName String
     * The name of the tag of the tagged value to find.
     * @param follow boolean
     * Whether or not to 'follow' the inheritance hierarchy when searching for the tagged value.
     * @return handleFindTaggedValue(tagName, follow)
     */
    public Object findTaggedValue(String tagName, boolean follow)
    {
        // findTaggedValue has no pre constraints
        Object returnValue = handleFindTaggedValue(tagName, follow);
        // findTaggedValue has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (Collection<GeneralizationFacade>)handleGetGeneralizationLinks()
     */
    public final Collection<GeneralizationFacade> getGeneralizationLinks()
    {
        Collection<GeneralizationFacade> getGeneralizationLinks1r = null;
        // generalizableElementFacade has no pre constraints
         Collection result = handleGetGeneralizationLinks();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getGeneralizationLinks1r = (Collection<GeneralizationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getGeneralizationLinks Collection<GeneralizationFacade> " + result + ": " + shieldedResult);
        }
        // generalizableElementFacade has no post constraints
        return getGeneralizationLinks1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetGeneralizationLinks();

    private GeneralizableElementFacade __getGeneralizationRoot2r;
    private boolean __getGeneralizationRoot2rSet = false;

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (GeneralizableElementFacade)handleGetGeneralizationRoot()
     */
    public final GeneralizableElementFacade getGeneralizationRoot()
    {
        GeneralizableElementFacade getGeneralizationRoot2r = this.__getGeneralizationRoot2r;
        if (!this.__getGeneralizationRoot2rSet)
        {
            // generalizableElementFacade has no pre constraints
            Object result = handleGetGeneralizationRoot();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getGeneralizationRoot2r = (GeneralizableElementFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getGeneralizationRoot GeneralizableElementFacade " + result + ": " + shieldedResult);
            }
            // generalizableElementFacade has no post constraints
            this.__getGeneralizationRoot2r = getGeneralizationRoot2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getGeneralizationRoot2rSet = true;
            }
        }
        return getGeneralizationRoot2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetGeneralizationRoot();

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (Collection<GeneralizableElementFacade>)handleGetAllGeneralizations()
     */
    public final Collection<GeneralizableElementFacade> getAllGeneralizations()
    {
        Collection<GeneralizableElementFacade> getAllGeneralizations3r = null;
        // generalizableElementFacade has no pre constraints
         Collection result = handleGetAllGeneralizations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllGeneralizations3r = (Collection<GeneralizableElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getAllGeneralizations Collection<GeneralizableElementFacade> " + result + ": " + shieldedResult);
        }
        // generalizableElementFacade has no post constraints
        return getAllGeneralizations3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllGeneralizations();

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (Collection<GeneralizableElementFacade>)handleGetGeneralizations()
     */
    public final Collection<GeneralizableElementFacade> getGeneralizations()
    {
        Collection<GeneralizableElementFacade> getGeneralizations4r = null;
        // generalizableElementFacade has no pre constraints
         Collection result = handleGetGeneralizations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getGeneralizations4r = (Collection<GeneralizableElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getGeneralizations Collection<GeneralizableElementFacade> " + result + ": " + shieldedResult);
        }
        // generalizableElementFacade has no post constraints
        return getGeneralizations4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetGeneralizations();

    private Collection<GeneralizableElementFacade> __getSpecializations5r;
    private boolean __getSpecializations5rSet = false;

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (Collection<GeneralizableElementFacade>)handleGetSpecializations()
     */
    public final Collection<GeneralizableElementFacade> getSpecializations()
    {
        Collection<GeneralizableElementFacade> getSpecializations5r = this.__getSpecializations5r;
        if (!this.__getSpecializations5rSet)
        {
            // generalizableElementFacade has no pre constraints
             Collection result = handleGetSpecializations();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getSpecializations5r = (Collection<GeneralizableElementFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getSpecializations Collection<GeneralizableElementFacade> " + result + ": " + shieldedResult);
            }
            // generalizableElementFacade has no post constraints
            this.__getSpecializations5r = getSpecializations5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getSpecializations5rSet = true;
            }
        }
        return getSpecializations5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetSpecializations();

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (Collection<GeneralizableElementFacade>)handleGetAllSpecializations()
     */
    public final Collection<GeneralizableElementFacade> getAllSpecializations()
    {
        Collection<GeneralizableElementFacade> getAllSpecializations6r = null;
        // generalizableElementFacade has no pre constraints
         Collection result = handleGetAllSpecializations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllSpecializations6r = (Collection<GeneralizableElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getAllSpecializations Collection<GeneralizableElementFacade> " + result + ": " + shieldedResult);
        }
        // generalizableElementFacade has no post constraints
        return getAllSpecializations6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllSpecializations();

    /**
     * The model element that represents an element that can be generalized or specialized.
     * @return (GeneralizableElementFacade)handleGetGeneralization()
     */
    public final GeneralizableElementFacade getGeneralization()
    {
        GeneralizableElementFacade getGeneralization7r = null;
        // generalizableElementFacade has no pre constraints
        Object result = handleGetGeneralization();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getGeneralization7r = (GeneralizableElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizableElementFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizableElementFacadeLogic.getGeneralization GeneralizableElementFacade " + result + ": " + shieldedResult);
        }
        // generalizableElementFacade has no post constraints
        return getGeneralization7r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetGeneralization();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}