// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EntityAttribute;
import org.andromda.metafacades.uml.TypeMappings;

/**
 * Represents an attribute of an entity.
 * MetafacadeLogic for EntityAttribute
 *
 * @see EntityAttribute
 */
public abstract class EntityAttributeLogic
    extends AttributeFacadeLogicImpl
    implements EntityAttribute
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EntityAttributeLogic(Object metaObjectIn, String context)
    {
        super((Attribute)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EntityAttribute if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAttribute";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EntityAttribute
     */
    public boolean isEntityAttributeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see EntityAttribute#getColumnLength()
    * @return String
    */
    protected abstract String handleGetColumnLength();

    /**
     * The length of the column that persists this entity attribute.
     * @return (String)handleGetColumnLength()
     */
    public final String getColumnLength()
    {
        String columnLength1a = null;
        // columnLength has no pre constraints
        columnLength1a = handleGetColumnLength();
        // columnLength has no post constraints
        return columnLength1a;
    }

   /**
    * @see EntityAttribute#getColumnName()
    * @return String
    */
    protected abstract String handleGetColumnName();

    /**
     * The name of the table column to which this entity is mapped.
     * @return (String)handleGetColumnName()
     */
    public final String getColumnName()
    {
        String columnName2a = null;
        // columnName has no pre constraints
        columnName2a = handleGetColumnName();
        // columnName has no post constraints
        return columnName2a;
    }

   /**
    * @see EntityAttribute#getJdbcMappings()
    * @return TypeMappings
    */
    protected abstract TypeMappings handleGetJdbcMappings();

    /**
     * The PIM to language specific mappings for JDBC.
     * @return (TypeMappings)handleGetJdbcMappings()
     */
    public final TypeMappings getJdbcMappings()
    {
        TypeMappings jdbcMappings3a = null;
        // jdbcMappings has no pre constraints
        jdbcMappings3a = handleGetJdbcMappings();
        // jdbcMappings has no post constraints
        return jdbcMappings3a;
    }

   /**
    * @see EntityAttribute#getJdbcType()
    * @return String
    */
    protected abstract String handleGetJdbcType();

    /**
     * The JDBC type for this entity attribute.
     * @return (String)handleGetJdbcType()
     */
    public final String getJdbcType()
    {
        String jdbcType4a = null;
        // jdbcType has no pre constraints
        jdbcType4a = handleGetJdbcType();
        // jdbcType has no post constraints
        return jdbcType4a;
    }

   /**
    * @see EntityAttribute#getSqlMappings()
    * @return TypeMappings
    */
    protected abstract TypeMappings handleGetSqlMappings();

    /**
     * The SQL mappings (i.e. the mappings which provide PIM to SQL mappings).
     * @return (TypeMappings)handleGetSqlMappings()
     */
    public final TypeMappings getSqlMappings()
    {
        TypeMappings sqlMappings5a = null;
        // sqlMappings has no pre constraints
        sqlMappings5a = handleGetSqlMappings();
        // sqlMappings has no post constraints
        return sqlMappings5a;
    }

   /**
    * @see EntityAttribute#getSqlType()
    * @return String
    */
    protected abstract String handleGetSqlType();

    /**
     * The SQL type for this attribute.
     * @return (String)handleGetSqlType()
     */
    public final String getSqlType()
    {
        String sqlType6a = null;
        // sqlType has no pre constraints
        sqlType6a = handleGetSqlType();
        // sqlType has no post constraints
        return sqlType6a;
    }

   /**
    * @see EntityAttribute#isIdentifier()
    * @return boolean
    */
    protected abstract boolean handleIsIdentifier();

    /**
     * True if this attribute is an identifier for its entity.
     * @return (boolean)handleIsIdentifier()
     */
    public final boolean isIdentifier()
    {
        boolean identifier7a = false;
        // identifier has no pre constraints
        identifier7a = handleIsIdentifier();
        // identifier has no post constraints
        return identifier7a;
    }

   /**
    * @see EntityAttribute#getColumnIndex()
    * @return String
    */
    protected abstract String handleGetColumnIndex();

    /**
     * The name of the index to create on a column that persists the entity attribute.
     * @return (String)handleGetColumnIndex()
     */
    public final String getColumnIndex()
    {
        String columnIndex8a = null;
        // columnIndex has no pre constraints
        columnIndex8a = handleGetColumnIndex();
        // columnIndex has no post constraints
        return columnIndex8a;
    }

   /**
    * @see EntityAttribute#isTransient()
    * @return boolean
    */
    protected abstract boolean handleIsTransient();

    /**
     * Indicates this attribute should be ignored by the persistence layer.
     * @return (boolean)handleIsTransient()
     */
    public final boolean isTransient()
    {
        boolean transient9a = false;
        // transient has no pre constraints
        transient9a = handleIsTransient();
        // transient has no post constraints
        return transient9a;
    }

   /**
    * @see EntityAttribute#getUniqueGroup()
    * @return String
    */
    protected abstract String handleGetUniqueGroup();

    /**
     * The name of the unique-key that this unique attribute belongs
     * @return (String)handleGetUniqueGroup()
     */
    public final String getUniqueGroup()
    {
        String uniqueGroup10a = null;
        // uniqueGroup has no pre constraints
        uniqueGroup10a = handleGetUniqueGroup();
        // uniqueGroup has no post constraints
        return uniqueGroup10a;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see AttributeFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}