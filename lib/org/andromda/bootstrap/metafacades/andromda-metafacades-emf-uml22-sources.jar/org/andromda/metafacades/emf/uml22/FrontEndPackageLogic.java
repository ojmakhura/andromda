// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndController;
import org.andromda.metafacades.uml.FrontEndPackage;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Package;

/**
 * Represents a package storing "front-end" components.
 * MetafacadeLogic for FrontEndPackage
 *
 * @see FrontEndPackage
 */
public abstract class FrontEndPackageLogic
    extends PackageFacadeLogicImpl
    implements FrontEndPackage
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndPackageLogic(Object metaObjectIn, String context)
    {
        super((Package)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndPackageLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndPackage if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndPackage";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndPackage
     */
    public boolean isFrontEndPackageMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private List<FrontEndAction> __getFrontEndUseCases1r;
    private boolean __getFrontEndUseCases1rSet = false;

    /**
     * Represents a package storing "front-end" components.
     * @return (List<FrontEndAction>)handleGetFrontEndUseCases()
     */
    public final List<FrontEndAction> getFrontEndUseCases()
    {
        List<FrontEndAction> getFrontEndUseCases1r = this.__getFrontEndUseCases1r;
        if (!this.__getFrontEndUseCases1rSet)
        {
            // frontEndPackage has no pre constraints
             List result = handleGetFrontEndUseCases();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getFrontEndUseCases1r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndPackageLogic.logger.warn("incorrect metafacade cast for FrontEndPackageLogic.getFrontEndUseCases List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // frontEndPackage has no post constraints
            this.__getFrontEndUseCases1r = getFrontEndUseCases1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndUseCases1rSet = true;
            }
        }
        return getFrontEndUseCases1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetFrontEndUseCases();

    private List<FrontEndController> __getFrontEndControllers2r;
    private boolean __getFrontEndControllers2rSet = false;

    /**
     * Represents a package storing "front-end" components.
     * @return (List<FrontEndController>)handleGetFrontEndControllers()
     */
    public final List<FrontEndController> getFrontEndControllers()
    {
        List<FrontEndController> getFrontEndControllers2r = this.__getFrontEndControllers2r;
        if (!this.__getFrontEndControllers2rSet)
        {
            // frontEndPackage has no pre constraints
             List result = handleGetFrontEndControllers();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getFrontEndControllers2r = (List<FrontEndController>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndPackageLogic.logger.warn("incorrect metafacade cast for FrontEndPackageLogic.getFrontEndControllers List<FrontEndController> " + result + ": " + shieldedResult);
            }
            // frontEndPackage has no post constraints
            this.__getFrontEndControllers2r = getFrontEndControllers2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndControllers2rSet = true;
            }
        }
        return getFrontEndControllers2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetFrontEndControllers();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndPackage::no more than one controller per package</p>
     * <p><b>Error:</b> In order to avoid possible naming collisions at most one controller per package is allowed. It is
recommended to refactor your model.</p>
     * <p><b>OCL:</b> context FrontEndPackage inv: frontEndControllers->size() < 2</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndPackage::no more than one usecase per package</p>
     * <p><b>Error:</b> In order to avoid possible naming collisions at most one FrontEndUseCase per package is allowed. It
is recommended to refactor your model.</p>
     * <p><b>OCL:</b> context FrontEndPackage inv: frontEndUseCases->size() < 2</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see PackageFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLExpressions.less(OCLCollections.size(OCLIntrospector.invoke(contextElement,"frontEndControllers")),2));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndPackage::no more than one controller per package",
                        "In order to avoid possible naming collisions at most one controller per package is allowed. It is\nrecommended to refactor your model."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndPackage::no more than one controller per package' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLExpressions.less(OCLCollections.size(OCLIntrospector.invoke(contextElement,"frontEndUseCases")),2));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndPackage::no more than one usecase per package",
                        "In order to avoid possible naming collisions at most one FrontEndUseCase per package is allowed. It\nis recommended to refactor your model."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndPackage::no more than one usecase per package' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}