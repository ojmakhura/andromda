// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActivityGraphFacade;
import org.andromda.metafacades.uml.ExtendFacade;
import org.andromda.metafacades.uml.ExtensionPointFacade;
import org.andromda.metafacades.uml.IncludeFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.UseCase;

/**
 * The specification of a set of actions performed by a system, which yields an observable result
 * that is, typically, of value for one or more actors or other stakeholders of the system.
 * MetafacadeLogic for UseCaseFacade
 *
 * @see UseCaseFacade
 */
public abstract class UseCaseFacadeLogic
    extends NamespaceFacadeLogicImpl
    implements UseCaseFacade
{
    /**
     * The underlying UML object
     * @see UseCase
     */
    protected UseCase metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected UseCaseFacadeLogic(UseCase metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(UseCaseFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to UseCaseFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.UseCaseFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see UseCaseFacade
     */
    public boolean isUseCaseFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<ExtendFacade> __getExtends1r;
    private boolean __getExtends1rSet = false;

    /**
     * The base use-case.
     * @return (Collection<ExtendFacade>)handleGetExtends()
     */
    public final Collection<ExtendFacade> getExtends()
    {
        Collection<ExtendFacade> getExtends1r = this.__getExtends1r;
        if (!this.__getExtends1rSet)
        {
            // base has no pre constraints
            Collection result = handleGetExtends();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getExtends1r = (Collection<ExtendFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                UseCaseFacadeLogic.logger.warn("incorrect metafacade cast for UseCaseFacadeLogic.getExtends Collection<ExtendFacade> " + result + ": " + shieldedResult);
            }
            // base has no post constraints
            this.__getExtends1r = getExtends1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtends1rSet = true;
            }
        }
        return getExtends1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetExtends();

    /**
     * The specification of a set of actions performed by a system, which yields an observable
     * result that
     * is, typically, of value for one or more actors or other stakeholders of the system.
     * @return (Collection<IncludeFacade>)handleGetIncludes()
     */
    public final Collection<IncludeFacade> getIncludes()
    {
        Collection<IncludeFacade> getIncludes2r = null;
        // base has no pre constraints
        Collection result = handleGetIncludes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getIncludes2r = (Collection<IncludeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            UseCaseFacadeLogic.logger.warn("incorrect metafacade cast for UseCaseFacadeLogic.getIncludes Collection<IncludeFacade> " + result + ": " + shieldedResult);
        }
        // base has no post constraints
        return getIncludes2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetIncludes();

    private Collection<ExtensionPointFacade> __getExtensionPoints3r;
    private boolean __getExtensionPoints3rSet = false;

    /**
     * The specification of a set of actions performed by a system, which yields an observable
     * result that
     * is, typically, of value for one or more actors or other stakeholders of the system.
     * @return (Collection<ExtensionPointFacade>)handleGetExtensionPoints()
     */
    public final Collection<ExtensionPointFacade> getExtensionPoints()
    {
        Collection<ExtensionPointFacade> getExtensionPoints3r = this.__getExtensionPoints3r;
        if (!this.__getExtensionPoints3rSet)
        {
            // useCase has no pre constraints
            Collection result = handleGetExtensionPoints();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getExtensionPoints3r = (Collection<ExtensionPointFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                UseCaseFacadeLogic.logger.warn("incorrect metafacade cast for UseCaseFacadeLogic.getExtensionPoints Collection<ExtensionPointFacade> " + result + ": " + shieldedResult);
            }
            // useCase has no post constraints
            this.__getExtensionPoints3r = getExtensionPoints3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtensionPoints3rSet = true;
            }
        }
        return getExtensionPoints3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetExtensionPoints();

    /**
     * The use-case owning this activity graph.
     * @return (ActivityGraphFacade)handleGetFirstActivityGraph()
     */
    public final ActivityGraphFacade getFirstActivityGraph()
    {
        ActivityGraphFacade getFirstActivityGraph4r = null;
        // useCase has no pre constraints
        Object result = handleGetFirstActivityGraph();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getFirstActivityGraph4r = (ActivityGraphFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            UseCaseFacadeLogic.logger.warn("incorrect metafacade cast for UseCaseFacadeLogic.getFirstActivityGraph ActivityGraphFacade " + result + ": " + shieldedResult);
        }
        // useCase has no post constraints
        return getFirstActivityGraph4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetFirstActivityGraph();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see NamespaceFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}