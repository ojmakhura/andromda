// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActionFacade;
import org.andromda.metafacades.uml.EventFacade;
import org.andromda.metafacades.uml.GuardFacade;
import org.andromda.metafacades.uml.StateVertexFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Transition;

/**
 * A directed relationship between a source vertex and a target vertex. It may be part of a compound
 * transition, which takes the state machine from one state configuration to another, representing
 * the complete response of the state machine to an occurrence of an event of a particular type.
 * MetafacadeLogic for TransitionFacade
 *
 * @see TransitionFacade
 */
public abstract class TransitionFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements TransitionFacade
{
    /**
     * The underlying UML object
     * @see Transition
     */
    protected Transition metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected TransitionFacadeLogic(Transition metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(TransitionFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to TransitionFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TransitionFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see TransitionFacade
     */
    public boolean isTransitionFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see TransitionFacade#isTriggerPresent()
    * @return boolean
    */
    protected abstract boolean handleIsTriggerPresent();

    /**
     * TODO: Model Documentation for TransitionFacade.triggerPresent
     * @return (boolean)handleIsTriggerPresent()
     */
    public final boolean isTriggerPresent()
    {
        boolean triggerPresent1a = false;
        // triggerPresent has no pre constraints
        triggerPresent1a = handleIsTriggerPresent();
        // triggerPresent has no post constraints
        return triggerPresent1a;
    }

   /**
    * @see TransitionFacade#isExitingDecisionPoint()
    * @return boolean
    */
    protected abstract boolean handleIsExitingDecisionPoint();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.exitingDecisionPoint
     * @return (boolean)handleIsExitingDecisionPoint()
     */
    public final boolean isExitingDecisionPoint()
    {
        boolean exitingDecisionPoint2a = false;
        // exitingDecisionPoint has no pre constraints
        exitingDecisionPoint2a = handleIsExitingDecisionPoint();
        // exitingDecisionPoint has no post constraints
        return exitingDecisionPoint2a;
    }

   /**
    * @see TransitionFacade#isEnteringDecisionPoint()
    * @return boolean
    */
    protected abstract boolean handleIsEnteringDecisionPoint();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.enteringDecisionPoint
     * @return (boolean)handleIsEnteringDecisionPoint()
     */
    public final boolean isEnteringDecisionPoint()
    {
        boolean enteringDecisionPoint3a = false;
        // enteringDecisionPoint has no pre constraints
        enteringDecisionPoint3a = handleIsEnteringDecisionPoint();
        // enteringDecisionPoint has no post constraints
        return enteringDecisionPoint3a;
    }

   /**
    * @see TransitionFacade#isExitingActionState()
    * @return boolean
    */
    protected abstract boolean handleIsExitingActionState();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.exitingActionState
     * @return (boolean)handleIsExitingActionState()
     */
    public final boolean isExitingActionState()
    {
        boolean exitingActionState4a = false;
        // exitingActionState has no pre constraints
        exitingActionState4a = handleIsExitingActionState();
        // exitingActionState has no post constraints
        return exitingActionState4a;
    }

   /**
    * @see TransitionFacade#isEnteringActionState()
    * @return boolean
    */
    protected abstract boolean handleIsEnteringActionState();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.enteringActionState
     * @return (boolean)handleIsEnteringActionState()
     */
    public final boolean isEnteringActionState()
    {
        boolean enteringActionState5a = false;
        // enteringActionState has no pre constraints
        enteringActionState5a = handleIsEnteringActionState();
        // enteringActionState has no post constraints
        return enteringActionState5a;
    }

   /**
    * @see TransitionFacade#isExitingInitialState()
    * @return boolean
    */
    protected abstract boolean handleIsExitingInitialState();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.exitingInitialState
     * @return (boolean)handleIsExitingInitialState()
     */
    public final boolean isExitingInitialState()
    {
        boolean exitingInitialState6a = false;
        // exitingInitialState has no pre constraints
        exitingInitialState6a = handleIsExitingInitialState();
        // exitingInitialState has no post constraints
        return exitingInitialState6a;
    }

   /**
    * @see TransitionFacade#isEnteringFinalState()
    * @return boolean
    */
    protected abstract boolean handleIsEnteringFinalState();

    /**
     * TODO: Model Documentation for
     * TransitionFacade.enteringFinalState
     * @return (boolean)handleIsEnteringFinalState()
     */
    public final boolean isEnteringFinalState()
    {
        boolean enteringFinalState7a = false;
        // enteringFinalState has no pre constraints
        enteringFinalState7a = handleIsEnteringFinalState();
        // enteringFinalState has no post constraints
        return enteringFinalState7a;
    }

    // ------------- associations ------------------

    /**
     * A directed relationship between a source vertex and a target vertex. It may be part of a
     * compound
     * transition, which takes the state machine from one state configuration to another,
     * representing the
     * complete response of the state machine to an occurrence of an event of a particular type.
     * @return (GuardFacade)handleGetGuard()
     */
    public final GuardFacade getGuard()
    {
        GuardFacade getGuard1r = null;
        // transition has no pre constraints
        Object result = handleGetGuard();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getGuard1r = (GuardFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TransitionFacadeLogic.logger.warn("incorrect metafacade cast for TransitionFacadeLogic.getGuard GuardFacade " + result + ": " + shieldedResult);
        }
        // transition has no post constraints
        return getGuard1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetGuard();

    /**
     * If this event is located on a transition, this represents that transition.
     * @return (EventFacade)handleGetTrigger()
     */
    public final EventFacade getTrigger()
    {
        EventFacade getTrigger2r = null;
        // transition has no pre constraints
        Object result = handleGetTrigger();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTrigger2r = (EventFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TransitionFacadeLogic.logger.warn("incorrect metafacade cast for TransitionFacadeLogic.getTrigger EventFacade " + result + ": " + shieldedResult);
        }
        // transition has no post constraints
        return getTrigger2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTrigger();

    /**
     * A directed relationship between a source vertex and a target vertex. It may be part of a
     * compound
     * transition, which takes the state machine from one state configuration to another,
     * representing the
     * complete response of the state machine to an occurrence of an event of a particular type.
     * @return (StateVertexFacade)handleGetSource()
     */
    public final StateVertexFacade getSource()
    {
        StateVertexFacade getSource3r = null;
        // incomings has no pre constraints
        Object result = handleGetSource();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getSource3r = (StateVertexFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TransitionFacadeLogic.logger.warn("incorrect metafacade cast for TransitionFacadeLogic.getSource StateVertexFacade " + result + ": " + shieldedResult);
        }
        // incomings has no post constraints
        return getSource3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetSource();

    /**
     * A directed relationship between a source vertex and a target vertex. It may be part of a
     * compound
     * transition, which takes the state machine from one state configuration to another,
     * representing the
     * complete response of the state machine to an occurrence of an event of a particular type.
     * @return (StateVertexFacade)handleGetTarget()
     */
    public final StateVertexFacade getTarget()
    {
        StateVertexFacade getTarget4r = null;
        // outgoings has no pre constraints
        Object result = handleGetTarget();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTarget4r = (StateVertexFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TransitionFacadeLogic.logger.warn("incorrect metafacade cast for TransitionFacadeLogic.getTarget StateVertexFacade " + result + ": " + shieldedResult);
        }
        // outgoings has no post constraints
        return getTarget4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTarget();

    /**
     * If this action is located on a transition, this represents that transition.
     * @return (ActionFacade)handleGetEffect()
     */
    public final ActionFacade getEffect()
    {
        ActionFacade getEffect5r = null;
        // transition has no pre constraints
        Object result = handleGetEffect();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getEffect5r = (ActionFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TransitionFacadeLogic.logger.warn("incorrect metafacade cast for TransitionFacadeLogic.getEffect ActionFacade " + result + ": " + shieldedResult);
        }
        // transition has no post constraints
        return getEffect5r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetEffect();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}