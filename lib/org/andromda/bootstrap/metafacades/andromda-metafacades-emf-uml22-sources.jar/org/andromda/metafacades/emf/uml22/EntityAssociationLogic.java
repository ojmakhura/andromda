// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EntityAssociation;
import org.eclipse.uml2.uml.Association;

/**
 * Represents an association between entities.
 * MetafacadeLogic for EntityAssociation
 *
 * @see EntityAssociation
 */
public abstract class EntityAssociationLogic
    extends AssociationFacadeLogicImpl
    implements EntityAssociation
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EntityAssociationLogic(Object metaObjectIn, String context)
    {
        super((Association)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EntityAssociation if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAssociation";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EntityAssociation
     */
    public boolean isEntityAssociationMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see EntityAssociation#getTableName()
    * @return String
    */
    protected abstract String handleGetTableName();

    /**
     * The name of the table if this is a many-to-many association.  Otherwise it just returns null
     * if not part of a many-to-many association.
     * @return (String)handleGetTableName()
     */
    public final String getTableName()
    {
        String tableName1a = null;
        // tableName has no pre constraints
        tableName1a = handleGetTableName();
        // tableName has no post constraints
        return tableName1a;
    }

   /**
    * @see EntityAssociation#getSchema()
    * @return String
    */
    protected abstract String handleGetSchema();

    /**
     * The name of the schema that contains the database table
     * @return (String)handleGetSchema()
     */
    public final String getSchema()
    {
        String schema2a = null;
        // schema has no pre constraints
        schema2a = handleGetSchema();
        // schema has no post constraints
        return schema2a;
    }

   /**
    * @see EntityAssociation#isEntityAssociation()
    * @return boolean
    */
    protected abstract boolean handleIsEntityAssociation();

    /**
     * is this an EntityAssociation?
     * @return (boolean)handleIsEntityAssociation()
     */
    public final boolean isEntityAssociation()
    {
        boolean entityAssociation3a = false;
        // entityAssociation has no pre constraints
        entityAssociation3a = handleIsEntityAssociation();
        // entityAssociation has no post constraints
        return entityAssociation3a;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see AssociationFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}