// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import jakarta.validation.Valid;
import java.util.Collection;
import java.util.Set;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.FrontEndAttribute;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.ParameterFacade;

/**
 * TODO: Model Documentation for FrontEndAttribute
 * MetafacadeLogic for FrontEndAttribute
 *
 * @see FrontEndAttribute
 */
public abstract class FrontEndAttributeLogic
    extends AttributeFacadeLogicImpl
    implements FrontEndAttribute
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndAttributeLogic(Object metaObjectIn, String context)
    {
        super((Attribute)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndAttribute if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndAttribute";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndAttribute
     */
    public boolean isFrontEndAttributeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndAttribute#isStrictDateFormat()
    * @return boolean
    */
    protected abstract boolean handleIsStrictDateFormat();

    /**
     * Indicates where or not the date format is to be strictly respected. Otherwise the date
     * formatter used for the representation of this date is to be set to lenient.
     * @return (boolean)handleIsStrictDateFormat()
     */
    public final boolean isStrictDateFormat()
    {
        boolean strictDateFormat1a = false;
        // strictDateFormat has no pre constraints
        strictDateFormat1a = handleIsStrictDateFormat();
        // strictDateFormat has no post constraints
        return strictDateFormat1a;
    }

   /**
    * @see FrontEndAttribute#isInputCheckbox()
    * @return boolean
    */
    protected abstract boolean handleIsInputCheckbox();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputCheckbox()
     */
    public final boolean isInputCheckbox()
    {
        boolean inputCheckbox2a = false;
        // inputCheckbox has no pre constraints
        inputCheckbox2a = handleIsInputCheckbox();
        // inputCheckbox has no post constraints
        return inputCheckbox2a;
    }

   /**
    * @see FrontEndAttribute#getFormat()
    * @return String
    */
    protected abstract String handleGetFormat();

    /**
     * If this attributes represents a date or time this method will return the format in which it
     * must be represented. In the event this format has not been specified by the any tagged value
     * the default will be used.
     * @return (String)handleGetFormat()
     */
    public final String getFormat()
    {
        String format3a = null;
        // format has no pre constraints
        format3a = handleGetFormat();
        // format has no post constraints
        return format3a;
    }

   /**
    * @see FrontEndAttribute#isInputMultibox()
    * @return boolean
    */
    protected abstract boolean handleIsInputMultibox();

    /**
     * Indicates whether or not this type represents an input multibox.
     * @return (boolean)handleIsInputMultibox()
     */
    public final boolean isInputMultibox()
    {
        boolean inputMultibox4a = false;
        // inputMultibox has no pre constraints
        inputMultibox4a = handleIsInputMultibox();
        // inputMultibox has no post constraints
        return inputMultibox4a;
    }

   /**
    * @see FrontEndAttribute#isInputSecret()
    * @return boolean
    */
    protected abstract boolean handleIsInputSecret();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputSecret()
     */
    public final boolean isInputSecret()
    {
        boolean inputSecret5a = false;
        // inputSecret has no pre constraints
        inputSecret5a = handleIsInputSecret();
        // inputSecret has no post constraints
        return inputSecret5a;
    }

   /**
    * @see FrontEndAttribute#isEqualValidator()
    * @return boolean
    */
    protected abstract boolean handleIsEqualValidator();

    /**
     * Indicates whether or not this parameter uses the equal validator.
     * @return (boolean)handleIsEqualValidator()
     */
    public final boolean isEqualValidator()
    {
        boolean equalValidator6a = false;
        // equalValidator has no pre constraints
        equalValidator6a = handleIsEqualValidator();
        // equalValidator has no post constraints
        return equalValidator6a;
    }

   /**
    * @see FrontEndAttribute#isInputFile()
    * @return boolean
    */
    protected abstract boolean handleIsInputFile();

    /**
     * Indicates whether or not this is a file input type.
     * @return (boolean)handleIsInputFile()
     */
    public final boolean isInputFile()
    {
        boolean inputFile7a = false;
        // inputFile has no pre constraints
        inputFile7a = handleIsInputFile();
        // inputFile has no post constraints
        return inputFile7a;
    }

   /**
    * @see FrontEndAttribute#getValidWhen()
    * @return String
    */
    protected abstract String handleGetValidWhen();

    /**
     * The validator's 'validwhen' value, this is useful when the validation of a parameter depends
     * on the validation of others. See the apache commons-validator documentation for more
     * information.
     * @return (String)handleGetValidWhen()
     */
    public final String getValidWhen()
    {
        String validWhen8a = null;
        // validWhen has no pre constraints
        validWhen8a = handleGetValidWhen();
        // validWhen has no post constraints
        return validWhen8a;
    }

   /**
    * @see FrontEndAttribute#getMaxLength()
    * @return String
    */
    protected abstract String handleGetMaxLength();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMaxLength()
     */
    public final String getMaxLength()
    {
        String maxLength9a = null;
        // maxLength has no pre constraints
        maxLength9a = handleGetMaxLength();
        // maxLength has no post constraints
        return maxLength9a;
    }

   /**
    * @see FrontEndAttribute#getInputTableIdentifierColumns()
    * @return String
    */
    protected abstract String handleGetInputTableIdentifierColumns();

    /**
     * A comma separated list of the input table identifier columns (these are the columns that
     * uniquely define a row in an input table).
     * @return (String)handleGetInputTableIdentifierColumns()
     */
    public final String getInputTableIdentifierColumns()
    {
        String inputTableIdentifierColumns10a = null;
        // inputTableIdentifierColumns has no pre constraints
        inputTableIdentifierColumns10a = handleGetInputTableIdentifierColumns();
        // inputTableIdentifierColumns has no post constraints
        return inputTableIdentifierColumns10a;
    }

   /**
    * @see FrontEndAttribute#isValidationRequired()
    * @return boolean
    */
    protected abstract boolean handleIsValidationRequired();

    /**
     * Indicates whether or not this attribute requires some kind of validation (the collection of
     * validator types is not empty).
     * @return (boolean)handleIsValidationRequired()
     */
    public final boolean isValidationRequired()
    {
        boolean validationRequired11a = false;
        // validationRequired has no pre constraints
        validationRequired11a = handleIsValidationRequired();
        // validationRequired has no post constraints
        return validationRequired11a;
    }

   /**
    * @see FrontEndAttribute#isInputRadio()
    * @return boolean
    */
    protected abstract boolean handleIsInputRadio();

    /**
     * Indicates whether or not this parameter should be rendered as an input radio widget.
     * @return (boolean)handleIsInputRadio()
     */
    public final boolean isInputRadio()
    {
        boolean inputRadio12a = false;
        // inputRadio has no pre constraints
        inputRadio12a = handleIsInputRadio();
        // inputRadio has no post constraints
        return inputRadio12a;
    }

   /**
    * @see FrontEndAttribute#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * The message key for this attribute.
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey13a = null;
        // messageKey has no pre constraints
        messageKey13a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey13a;
    }

   /**
    * @see FrontEndAttribute#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * The default value for the message key.
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue14a = null;
        // messageValue has no pre constraints
        messageValue14a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue14a;
    }

   /**
    * @see FrontEndAttribute#isInputSelect()
    * @return boolean
    */
    protected abstract boolean handleIsInputSelect();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputSelect()
     */
    public final boolean isInputSelect()
    {
        boolean inputSelect15a = false;
        // inputSelect has no pre constraints
        inputSelect15a = handleIsInputSelect();
        // inputSelect has no post constraints
        return inputSelect15a;
    }

   /**
    * @see FrontEndAttribute#isInputTypePresent()
    * @return boolean
    */
    protected abstract boolean handleIsInputTypePresent();

    /**
     * Indicates whether or not there is an input type defined for this attribute.
     * @return (boolean)handleIsInputTypePresent()
     */
    public final boolean isInputTypePresent()
    {
        boolean inputTypePresent16a = false;
        // inputTypePresent has no pre constraints
        inputTypePresent16a = handleIsInputTypePresent();
        // inputTypePresent has no post constraints
        return inputTypePresent16a;
    }

   /**
    * @see FrontEndAttribute#getValueListDummyValue()
    * @return String
    */
    protected abstract String handleGetValueListDummyValue();

    /**
     * The dummy value for a value list.
     * @return (String)handleGetValueListDummyValue()
     */
    public final String getValueListDummyValue()
    {
        String valueListDummyValue17a = null;
        // valueListDummyValue has no pre constraints
        valueListDummyValue17a = handleGetValueListDummyValue();
        // valueListDummyValue has no post constraints
        return valueListDummyValue17a;
    }

   /**
    * @see FrontEndAttribute#getValidatorTypes()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorTypes();

    /**
     * All validator types for this attribute.
     * @return (Collection)handleGetValidatorTypes()
     */
    public final Collection getValidatorTypes()
    {
        Collection validatorTypes18a = null;
        // validatorTypes has no pre constraints
        validatorTypes18a = handleGetValidatorTypes();
        // validatorTypes has no post constraints
        return validatorTypes18a;
    }

   /**
    * @see FrontEndAttribute#isInputText()
    * @return boolean
    */
    protected abstract boolean handleIsInputText();

    /**
     * Indicates whether or not this parameter should be rendered as a text input widget.
     * @return (boolean)handleIsInputText()
     */
    public final boolean isInputText()
    {
        boolean inputText19a = false;
        // inputText has no pre constraints
        inputText19a = handleIsInputText();
        // inputText has no post constraints
        return inputText19a;
    }

   /**
    * @see FrontEndAttribute#getDummyValue()
    * @return String
    */
    protected abstract String handleGetDummyValue();

    /**
     * The dummy value to give the attribute when creating a dummy instance of this attribute's
     * owner.
     * @return (String)handleGetDummyValue()
     */
    public final String getDummyValue()
    {
        String dummyValue20a = null;
        // dummyValue has no pre constraints
        dummyValue20a = handleGetDummyValue();
        // dummyValue has no post constraints
        return dummyValue20a;
    }

   /**
    * @see FrontEndAttribute#isInputTextarea()
    * @return boolean
    */
    protected abstract boolean handleIsInputTextarea();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return (boolean)handleIsInputTextarea()
     */
    public final boolean isInputTextarea()
    {
        boolean inputTextarea21a = false;
        // inputTextarea has no pre constraints
        inputTextarea21a = handleIsInputTextarea();
        // inputTextarea has no post constraints
        return inputTextarea21a;
    }

   /**
    * @see FrontEndAttribute#isPlaintext()
    * @return boolean
    */
    protected abstract boolean handleIsPlaintext();

    /**
     * Indicates whether or not this attribute's value should be rendered as plain text (not as a
     * widget).
     * @return (boolean)handleIsPlaintext()
     */
    public final boolean isPlaintext()
    {
        boolean plaintext22a = false;
        // plaintext has no pre constraints
        plaintext22a = handleIsPlaintext();
        // plaintext has no post constraints
        return plaintext22a;
    }

   /**
    * @see FrontEndAttribute#isInputTable()
    * @return boolean
    */
    protected abstract boolean handleIsInputTable();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputTable()
     */
    public final boolean isInputTable()
    {
        boolean inputTable23a = false;
        // inputTable has no pre constraints
        inputTable23a = handleIsInputTable();
        // inputTable has no post constraints
        return inputTable23a;
    }

   /**
    * @see FrontEndAttribute#isInputHidden()
    * @return boolean
    */
    protected abstract boolean handleIsInputHidden();

    /**
     * Indicates whether or not this parameter represents a hidden input widget.
     * @return (boolean)handleIsInputHidden()
     */
    public final boolean isInputHidden()
    {
        boolean inputHidden24a = false;
        // inputHidden has no pre constraints
        inputHidden24a = handleIsInputHidden();
        // inputHidden has no post constraints
        return inputHidden24a;
    }

   /**
    * @see FrontEndAttribute#isReset()
    * @return boolean
    */
    protected abstract boolean handleIsReset();

    /**
     * Indicates if this parameter's value should be reset or not after an action has been performed
     * with this parameter.
     * @return (boolean)handleIsReset()
     */
    public final boolean isReset()
    {
        boolean reset25a = false;
        // reset has no pre constraints
        reset25a = handleIsReset();
        // reset has no post constraints
        return reset25a;
    }

   /**
    * @see FrontEndAttribute#getValidatorVars()
    * @return Collection
    */
    protected abstract Collection handleGetValidatorVars();

    /**
     * The validator variables.
     * @return (Collection)handleGetValidatorVars()
     */
    public final Collection getValidatorVars()
    {
        Collection validatorVars26a = null;
        // validatorVars has no pre constraints
        validatorVars26a = handleGetValidatorVars();
        // validatorVars has no post constraints
        return validatorVars26a;
    }

   /**
    * @see FrontEndAttribute#isInputButton()
    * @return boolean
    */
    protected abstract boolean handleIsInputButton();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputButton()
     */
    public final boolean isInputButton()
    {
        boolean inputButton27a = false;
        // inputButton has no pre constraints
        inputButton27a = handleIsInputButton();
        // inputButton has no post constraints
        return inputButton27a;
    }

   /**
    * @see FrontEndAttribute#isInputColor()
    * @return boolean
    */
    protected abstract boolean handleIsInputColor();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputColor()
     */
    public final boolean isInputColor()
    {
        boolean inputColor28a = false;
        // inputColor has no pre constraints
        inputColor28a = handleIsInputColor();
        // inputColor has no post constraints
        return inputColor28a;
    }

   /**
    * @see FrontEndAttribute#isInputDate()
    * @return boolean
    */
    protected abstract boolean handleIsInputDate();

    /**
     * Indicates whether or not this is an table input type.
     * @return (boolean)handleIsInputDate()
     */
    public final boolean isInputDate()
    {
        boolean inputDate29a = false;
        // inputDate has no pre constraints
        inputDate29a = handleIsInputDate();
        // inputDate has no post constraints
        return inputDate29a;
    }

   /**
    * @see FrontEndAttribute#isInputDatetimeLocal()
    * @return boolean
    */
    protected abstract boolean handleIsInputDatetimeLocal();

    /**
     * Indicates if this parameter represents as an input text area widget.
     * @return (boolean)handleIsInputDatetimeLocal()
     */
    public final boolean isInputDatetimeLocal()
    {
        boolean inputDatetimeLocal30a = false;
        // inputDatetimeLocal has no pre constraints
        inputDatetimeLocal30a = handleIsInputDatetimeLocal();
        // inputDatetimeLocal has no post constraints
        return inputDatetimeLocal30a;
    }

   /**
    * @see FrontEndAttribute#isInputEmail()
    * @return boolean
    */
    protected abstract boolean handleIsInputEmail();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputEmail()
     */
    public final boolean isInputEmail()
    {
        boolean inputEmail31a = false;
        // inputEmail has no pre constraints
        inputEmail31a = handleIsInputEmail();
        // inputEmail has no post constraints
        return inputEmail31a;
    }

   /**
    * @see FrontEndAttribute#isInputImage()
    * @return boolean
    */
    protected abstract boolean handleIsInputImage();

    /**
     * Indicates if this parameter represents a checkbox widget.
     * @return (boolean)handleIsInputImage()
     */
    public final boolean isInputImage()
    {
        boolean inputImage32a = false;
        // inputImage has no pre constraints
        inputImage32a = handleIsInputImage();
        // inputImage has no post constraints
        return inputImage32a;
    }

   /**
    * @see FrontEndAttribute#isInputMonth()
    * @return boolean
    */
    protected abstract boolean handleIsInputMonth();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputMonth()
     */
    public final boolean isInputMonth()
    {
        boolean inputMonth33a = false;
        // inputMonth has no pre constraints
        inputMonth33a = handleIsInputMonth();
        // inputMonth has no post constraints
        return inputMonth33a;
    }

   /**
    * @see FrontEndAttribute#isInputNumber()
    * @return boolean
    */
    protected abstract boolean handleIsInputNumber();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputNumber()
     */
    public final boolean isInputNumber()
    {
        boolean inputNumber34a = false;
        // inputNumber has no pre constraints
        inputNumber34a = handleIsInputNumber();
        // inputNumber has no post constraints
        return inputNumber34a;
    }

   /**
    * @see FrontEndAttribute#isInputRange()
    * @return boolean
    */
    protected abstract boolean handleIsInputRange();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputRange()
     */
    public final boolean isInputRange()
    {
        boolean inputRange35a = false;
        // inputRange has no pre constraints
        inputRange35a = handleIsInputRange();
        // inputRange has no post constraints
        return inputRange35a;
    }

   /**
    * @see FrontEndAttribute#isInputReset()
    * @return boolean
    */
    protected abstract boolean handleIsInputReset();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputReset()
     */
    public final boolean isInputReset()
    {
        boolean inputReset36a = false;
        // inputReset has no pre constraints
        inputReset36a = handleIsInputReset();
        // inputReset has no post constraints
        return inputReset36a;
    }

   /**
    * @see FrontEndAttribute#isInputSearch()
    * @return boolean
    */
    protected abstract boolean handleIsInputSearch();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputSearch()
     */
    public final boolean isInputSearch()
    {
        boolean inputSearch37a = false;
        // inputSearch has no pre constraints
        inputSearch37a = handleIsInputSearch();
        // inputSearch has no post constraints
        return inputSearch37a;
    }

   /**
    * @see FrontEndAttribute#isInputSubmit()
    * @return boolean
    */
    protected abstract boolean handleIsInputSubmit();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputSubmit()
     */
    public final boolean isInputSubmit()
    {
        boolean inputSubmit38a = false;
        // inputSubmit has no pre constraints
        inputSubmit38a = handleIsInputSubmit();
        // inputSubmit has no post constraints
        return inputSubmit38a;
    }

   /**
    * @see FrontEndAttribute#isInputTel()
    * @return boolean
    */
    protected abstract boolean handleIsInputTel();

    /**
     * Indicates whether or not this parameter represents an input "secret" widget (i.e. password).
     * @return (boolean)handleIsInputTel()
     */
    public final boolean isInputTel()
    {
        boolean inputTel39a = false;
        // inputTel has no pre constraints
        inputTel39a = handleIsInputTel();
        // inputTel has no post constraints
        return inputTel39a;
    }

   /**
    * @see FrontEndAttribute#isInputTime()
    * @return boolean
    */
    protected abstract boolean handleIsInputTime();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputTime()
     */
    public final boolean isInputTime()
    {
        boolean inputTime40a = false;
        // inputTime has no pre constraints
        inputTime40a = handleIsInputTime();
        // inputTime has no post constraints
        return inputTime40a;
    }

   /**
    * @see FrontEndAttribute#isInputUrl()
    * @return boolean
    */
    protected abstract boolean handleIsInputUrl();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputUrl()
     */
    public final boolean isInputUrl()
    {
        boolean inputUrl41a = false;
        // inputUrl has no pre constraints
        inputUrl41a = handleIsInputUrl();
        // inputUrl has no post constraints
        return inputUrl41a;
    }

   /**
    * @see FrontEndAttribute#isInputWeek()
    * @return boolean
    */
    protected abstract boolean handleIsInputWeek();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (boolean)handleIsInputWeek()
     */
    public final boolean isInputWeek()
    {
        boolean inputWeek42a = false;
        // inputWeek has no pre constraints
        inputWeek42a = handleIsInputWeek();
        // inputWeek has no post constraints
        return inputWeek42a;
    }

   /**
    * @see FrontEndAttribute#getInputAction()
    * @return String
    */
    protected abstract String handleGetInputAction();

    /**
     * Indicates whether or not this parameter represents an input select widget.
     * @return (String)handleGetInputAction()
     */
    public final String getInputAction()
    {
        String inputAction43a = null;
        // inputAction has no pre constraints
        inputAction43a = handleGetInputAction();
        // inputAction has no post constraints
        return inputAction43a;
    }

   /**
    * @see FrontEndAttribute#getInputType()
    * @return String
    */
    protected abstract String handleGetInputType();

    /**
     * TODO: Model Documentation for FrontEndAttribute.inputType
     * @return (String)handleGetInputType()
     */
    public final String getInputType()
    {
        String inputType44a = null;
        // inputType has no pre constraints
        inputType44a = handleGetInputType();
        // inputType has no post constraints
        return inputType44a;
    }

   /**
    * @see FrontEndAttribute#getFrontEndClasses()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetFrontEndClasses();

    /**
     * TODO: Model Documentation for FrontEndAttribute.frontEndClasses
     * @return (Set<String>)handleGetFrontEndClasses()
     */
    public final Set<String> getFrontEndClasses()
    {
        Set<String> frontEndClasses45a = null;
        // frontEndClasses has no pre constraints
        frontEndClasses45a = handleGetFrontEndClasses();
        // frontEndClasses has no post constraints
        return frontEndClasses45a;
    }

   /**
    * @see FrontEndAttribute#getTableColumnNames()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableColumnNames();

    /**
     * All the columns for this parameter if it represents a table variable. If a column is linked
     * by an event (action) a FrontEndParameter instance is included in the return value, otherwise
     * a plain String representing the column name.
     * @return (Set<String>)handleGetTableColumnNames()
     */
    public final Set<String> getTableColumnNames()
    {
        Set<String> tableColumnNames46a = null;
        // tableColumnNames has no pre constraints
        tableColumnNames46a = handleGetTableColumnNames();
        // tableColumnNames has no post constraints
        return tableColumnNames46a;
    }

   /**
    * @see FrontEndAttribute#getTableColumns()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableColumns();

    /**
     * A list of all attributes which make up the table columns of this table (this only contains
     * attributes when the table is represented by an array).
     * @return (Set<String>)handleGetTableColumns()
     */
    public final Set<String> getTableColumns()
    {
        Set<String> tableColumns47a = null;
        // tableColumns has no pre constraints
        tableColumns47a = handleGetTableColumns();
        // tableColumns has no post constraints
        return tableColumns47a;
    }

   /**
    * @see FrontEndAttribute#getTableAttributeNames()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetTableAttributeNames();

    /**
     * A collection of all possible attribute names of a table (this will only work when your table
     * is modeled as an array..not a collection).
     * @return (Set<String>)handleGetTableAttributeNames()
     */
    public final Set<String> getTableAttributeNames()
    {
        Set<String> tableAttributeNames48a = null;
        // tableAttributeNames has no pre constraints
        tableAttributeNames48a = handleGetTableAttributeNames();
        // tableAttributeNames has no post constraints
        return tableAttributeNames48a;
    }

   /**
    * @see FrontEndAttribute#getDisplayCondition()
    * @return String
    */
    protected abstract String handleGetDisplayCondition();

    /**
     * TODO: Model Documentation for FrontEndAttribute.displayCondition
     * @return (String)handleGetDisplayCondition()
     */
    public final String getDisplayCondition()
    {
        String displayCondition49a = null;
        // displayCondition has no pre constraints
        displayCondition49a = handleGetDisplayCondition();
        // displayCondition has no post constraints
        return displayCondition49a;
    }

   /**
    * @see FrontEndAttribute#getMinLength()
    * @return String
    */
    protected abstract String handleGetMinLength();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMinLength()
     */
    public final String getMinLength()
    {
        String minLength50a = null;
        // minLength has no pre constraints
        minLength50a = handleGetMinLength();
        // minLength has no post constraints
        return minLength50a;
    }

   /**
    * @see FrontEndAttribute#getMin()
    * @return String
    */
    protected abstract String handleGetMin();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMin()
     */
    public final String getMin()
    {
        String min51a = null;
        // min has no pre constraints
        min51a = handleGetMin();
        // min has no post constraints
        return min51a;
    }

   /**
    * @see FrontEndAttribute#getMax()
    * @return String
    */
    protected abstract String handleGetMax();

    /**
     * The max length allowed in the input component
     * @return (String)handleGetMax()
     */
    public final String getMax()
    {
        String max52a = null;
        // max has no pre constraints
        max52a = handleGetMax();
        // max has no post constraints
        return max52a;
    }

   /**
    * @see FrontEndAttribute#getComponent()
    * @return Boolean
    */
    protected abstract Boolean handleGetComponent();

    /**
     * TODO: Model Documentation for FrontEndAttribute.component
     * @return (Boolean)handleGetComponent()
     */
    public final Boolean getComponent()
    {
        Boolean component53a = null;
        // component has no pre constraints
        component53a = handleGetComponent();
        // component has no post constraints
        return component53a;
    }

   /**
    * @see FrontEndAttribute#getMappedComponent()
    * @return String
    */
    protected abstract String handleGetMappedComponent();

    /**
     * TODO: Model Documentation for FrontEndAttribute.mappedComponent
     * @return (String)handleGetMappedComponent()
     */
    public final String getMappedComponent()
    {
        String mappedComponent54a = null;
        // mappedComponent has no pre constraints
        mappedComponent54a = handleGetMappedComponent();
        // mappedComponent has no post constraints
        return mappedComponent54a;
    }

   /**
    * @see FrontEndAttribute#getTree()
    * @return Boolean
    */
    protected abstract Boolean handleGetTree();

    /**
     * TODO: Model Documentation for FrontEndAttribute.tree
     * @return (Boolean)handleGetTree()
     */
    public final Boolean getTree()
    {
        Boolean tree55a = null;
        // tree has no pre constraints
        tree55a = handleGetTree();
        // tree has no post constraints
        return tree55a;
    }

   /**
    * @see FrontEndAttribute#getDisplayAttributes()
    * @return Collection<AttributeFacade>
    */
    protected abstract Collection<AttributeFacade> handleGetDisplayAttributes();

    /**
     * A list of all attributes which make up the table columns of this table (this only contains
     * attributes when the table is represented by an array).
     * @return (Collection<AttributeFacade>)handleGetDisplayAttributes()
     */
    public final Collection<AttributeFacade> getDisplayAttributes()
    {
        Collection<AttributeFacade> displayAttributes56a = null;
        // displayAttributes has no pre constraints
        displayAttributes56a = handleGetDisplayAttributes();
        // displayAttributes has no post constraints
        return displayAttributes56a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Constructs and returns the backing value name given the 'ownerParameter'.
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetBackingValueName(@Valid ParameterFacade ownerParameter);

    /**
     * Constructs and returns the backing value name given the 'ownerParameter'.
     * @param ownerParameter ParameterFacade
     * The parameter that is the "owner" of this attribute (i.e. the parameter's type contains this
     * attribute).
     * @return handleGetBackingValueName(ownerParameter)
     */
    public String getBackingValueName(@Valid ParameterFacade ownerParameter)
    {
        // getBackingValueName has no pre constraints
        String returnValue = handleGetBackingValueName(ownerParameter);
        // getBackingValueName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the validator args for this attribute
     * @param ownerParameter
     * @return Collection
     */
    protected abstract Collection handleGetValidatorVars(@Valid FrontEndParameter ownerParameter);

    /**
     * Gets the validator args for this attribute
     * @param ownerParameter FrontEndParameter
     * TODO: Model Documentation for
     * FrontEndAttribute.getValidatorVars(ownerParameter)
     * @return handleGetValidatorVars(ownerParameter)
     */
    public Collection getValidatorVars(@Valid FrontEndParameter ownerParameter)
    {
        // getValidatorVars has no pre constraints
        Collection returnValue = handleGetValidatorVars(ownerParameter);
        // getValidatorVars has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the unique id of this attribute on the form.
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetFormPropertyId(@Valid ParameterFacade ownerParameter);

    /**
     * Gets the unique id of this attribute on the form.
     * @param ownerParameter ParameterFacade
     * The parameter that is the owner of this attribute.
     * @return handleGetFormPropertyId(ownerParameter)
     */
    public String getFormPropertyId(@Valid ParameterFacade ownerParameter)
    {
        // getFormPropertyId has no pre constraints
        String returnValue = handleGetFormPropertyId(ownerParameter);
        // getFormPropertyId has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Retrieves the name of the form property for this attribute by taking the name of the owner
     * property.
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetFormPropertyName(@Valid ParameterFacade ownerParameter);

    /**
     * Retrieves the name of the form property for this attribute by taking the name of the owner
     * property.
     * @param ownerParameter ParameterFacade
     * The parent that is the owner of this parameter.
     * @return handleGetFormPropertyName(ownerParameter)
     */
    public String getFormPropertyName(@Valid ParameterFacade ownerParameter)
    {
        // getFormPropertyName has no pre constraints
        String returnValue = handleGetFormPropertyName(ownerParameter);
        // getFormPropertyName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets backing list name for this attribute. This is useful if you want to be able to select
     * the attribute value from a list (i.e. a drop-down select input type).
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetBackingListName(@Valid ParameterFacade ownerParameter);

    /**
     * Gets backing list name for this attribute. This is useful if you want to be able to select
     * the attribute value from a list (i.e. a drop-down select input type).
     * @param ownerParameter ParameterFacade
     * The parameter that is the owner of this attribute.
     * @return handleGetBackingListName(ownerParameter)
     */
    public String getBackingListName(@Valid ParameterFacade ownerParameter)
    {
        // getBackingListName has no pre constraints
        String returnValue = handleGetBackingListName(ownerParameter);
        // getBackingListName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the name of the time formatter (if this parameter represents a time).
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetTimeFormatter(@Valid FrontEndParameter ownerParameter);

    /**
     * Gets the name of the time formatter (if this parameter represents a time).
     * @param ownerParameter FrontEndParameter
     * The parameter that is the 'owner' of this attribute.
     * @return handleGetTimeFormatter(ownerParameter)
     */
    public String getTimeFormatter(@Valid FrontEndParameter ownerParameter)
    {
        // getTimeFormatter has no pre constraints
        String returnValue = handleGetTimeFormatter(ownerParameter);
        // getTimeFormatter has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the name of the date formatter for this attribute by constructing the name from the
     * 'ownerParameter' (if this attribute represents a date).
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetDateFormatter(@Valid FrontEndParameter ownerParameter);

    /**
     * Gets the name of the date formatter for this attribute by constructing the name from the
     * 'ownerParameter' (if this attribute represents a date).
     * @param ownerParameter FrontEndParameter
     * The parameter that is the 'owner' of this attribute.
     * @return handleGetDateFormatter(ownerParameter)
     */
    public String getDateFormatter(@Valid FrontEndParameter ownerParameter)
    {
        // getDateFormatter has no pre constraints
        String returnValue = handleGetDateFormatter(ownerParameter);
        // getDateFormatter has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Indicates whether or not the backing value is required for this attribute (depending on the
     * 'ownerParameter').
     * @param ownerParameter
     * @return boolean
     */
    protected abstract boolean handleIsBackingValueRequired(@Valid FrontEndParameter ownerParameter);

    /**
     * Indicates whether or not the backing value is required for this attribute (depending on the
     * 'ownerParameter').
     * @param ownerParameter FrontEndParameter
     * The 'owner' of this attribute (i.e. the attrubte who's type has this attribute).
     * @return handleIsBackingValueRequired(ownerParameter)
     */
    public boolean isBackingValueRequired(@Valid FrontEndParameter ownerParameter)
    {
        // isBackingValueRequired has no pre constraints
        boolean returnValue = handleIsBackingValueRequired(ownerParameter);
        // isBackingValueRequired has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Indicates whether or not this attribute is selectable according to its 'ownerParameter'.
     * @param ownerParameter
     * @return boolean
     */
    protected abstract boolean handleIsSelectable(@Valid FrontEndParameter ownerParameter);

    /**
     * Indicates whether or not this attribute is selectable according to its 'ownerParameter'.
     * @param ownerParameter FrontEndParameter
     * The parameter that 'owns' this attribute.
     * @return handleIsSelectable(ownerParameter)
     */
    public boolean isSelectable(@Valid FrontEndParameter ownerParameter)
    {
        // isSelectable has no pre constraints
        boolean returnValue = handleIsSelectable(ownerParameter);
        // isSelectable has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the name of the label list for this parameter. The label list name is the name of the
     * list storing the labels for the possible values of this attribute (typically used for the
     * labels of a drop-down select lists).
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetLabelListName(@Valid ParameterFacade ownerParameter);

    /**
     * Gets the name of the label list for this parameter. The label list name is the name of the
     * list storing the labels for the possible values of this attribute (typically used for the
     * labels of a drop-down select lists).
     * @param ownerParameter ParameterFacade
     * The parameter that is the owner of this attribute.
     * @return handleGetLabelListName(ownerParameter)
     */
    public String getLabelListName(@Valid ParameterFacade ownerParameter)
    {
        // getLabelListName has no pre constraints
        String returnValue = handleGetLabelListName(ownerParameter);
        // getLabelListName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the name of the value list for this parameter; this list stores the possible values that
     * this attribute may be (typically used for the values of a drop-down select list).
     * @param ownerParameter
     * @return String
     */
    protected abstract String handleGetValueListName(@Valid ParameterFacade ownerParameter);

    /**
     * Gets the name of the value list for this parameter; this list stores the possible values that
     * this attribute may be (typically used for the values of a drop-down select list).
     * @param ownerParameter ParameterFacade
     * The parameter that is the owner of this attribute.
     * @return handleGetValueListName(ownerParameter)
     */
    public String getValueListName(@Valid ParameterFacade ownerParameter)
    {
        // getValueListName has no pre constraints
        String returnValue = handleGetValueListName(ownerParameter);
        // getValueListName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the arguments for this parameter's validators.
     * @param validatorType
     * @return Collection
     */
    protected abstract Collection handleGetValidatorArgs(String validatorType);

    /**
     * Gets the arguments for this parameter's validators.
     * @param validatorType String
     * The type of validator.
     * @return handleGetValidatorArgs(validatorType)
     */
    public Collection getValidatorArgs(String validatorType)
    {
        // getValidatorArgs has no pre constraints
        Collection returnValue = handleGetValidatorArgs(validatorType);
        // getValidatorArgs has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see AttributeFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}