// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.NamespaceFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * An element in a model that contains a set of named elements that can be identified by name.
 * MetafacadeLogic for NamespaceFacade
 *
 * @see NamespaceFacade
 */
public abstract class NamespaceFacadeLogic
    extends ClassifierFacadeLogicImpl
    implements NamespaceFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected NamespaceFacadeLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(NamespaceFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to NamespaceFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.NamespaceFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see NamespaceFacade
     */
    public boolean isNamespaceFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * Gets the namespace to which this model element belongs.
     * @return (Collection<ModelElementFacade>)handleGetOwnedElements()
     */
    public final Collection<ModelElementFacade> getOwnedElements()
    {
        Collection<ModelElementFacade> getOwnedElements1r = null;
        // namespace has no pre constraints
         Collection result = handleGetOwnedElements();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getOwnedElements1r = (Collection<ModelElementFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            NamespaceFacadeLogic.logger.warn("incorrect metafacade cast for NamespaceFacadeLogic.getOwnedElements Collection<ModelElementFacade> " + result + ": " + shieldedResult);
        }
        // namespace has no post constraints
        return getOwnedElements1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOwnedElements();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}