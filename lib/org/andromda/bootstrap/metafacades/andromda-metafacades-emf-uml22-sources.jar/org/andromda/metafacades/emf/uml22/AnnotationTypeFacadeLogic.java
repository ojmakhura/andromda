// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AnnotationTypeFacade;
import org.eclipse.uml2.uml.Classifier;

/**
 * TODO: Model Documentation for AnnotationTypeFacade
 * MetafacadeLogic for AnnotationTypeFacade
 *
 * @see AnnotationTypeFacade
 */
public abstract class AnnotationTypeFacadeLogic
    extends ClassifierFacadeLogicImpl
    implements AnnotationTypeFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected AnnotationTypeFacadeLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to AnnotationTypeFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AnnotationTypeFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see AnnotationTypeFacade
     */
    public boolean isAnnotationTypeFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see AnnotationTypeFacade#getRetention()
    * @return String
    */
    protected abstract String handleGetRetention();

    /**
     * TODO: Model Documentation for AnnotationTypeFacade.retention
     * @return (String)handleGetRetention()
     */
    public final String getRetention()
    {
        String retention1a = null;
        // retention has no pre constraints
        retention1a = handleGetRetention();
        // retention has no post constraints
        return retention1a;
    }

   /**
    * @see AnnotationTypeFacade#getTarget()
    * @return String
    */
    protected abstract String handleGetTarget();

    /**
     * Tartgets
     * @return (String)handleGetTarget()
     */
    public final String getTarget()
    {
        String target2a = null;
        // target has no pre constraints
        target2a = handleGetTarget();
        // target has no post constraints
        return target2a;
    }

   /**
    * @see AnnotationTypeFacade#isDocumented()
    * @return boolean
    */
    protected abstract boolean handleIsDocumented();

    /**
     * TODO: Model Documentation for AnnotationTypeFacade.documented
     * @return (boolean)handleIsDocumented()
     */
    public final boolean isDocumented()
    {
        boolean documented3a = false;
        // documented has no pre constraints
        documented3a = handleIsDocumented();
        // documented has no post constraints
        return documented3a;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}