// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AssociationEndFacade;
import org.andromda.metafacades.uml.AssociationFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Association;

/**
 * An association describes a set of tuples whose values refer to typed instances. An instance of an
 * association is called a link.
 * MetafacadeLogic for AssociationFacade
 *
 * @see AssociationFacade
 */
public abstract class AssociationFacadeLogic
    extends GeneralizableElementFacadeLogicImpl
    implements AssociationFacade
{
    /**
     * The underlying UML object
     * @see Association
     */
    protected Association metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected AssociationFacadeLogic(Association metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(AssociationFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to AssociationFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AssociationFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see AssociationFacade
     */
    public boolean isAssociationFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see AssociationFacade#getRelationName()
    * @return String
    */
    protected abstract String handleGetRelationName();

    /**
     * A name suited for naming this relationship. This name will be constructed from both
     * association ends.
     * @return (String)handleGetRelationName()
     */
    public final String getRelationName()
    {
        String relationName1a = null;
        // relationName has no pre constraints
        relationName1a = handleGetRelationName();
        // relationName has no post constraints
        return relationName1a;
    }

   /**
    * @see AssociationFacade#isMany2Many()
    * @return boolean
    */
    protected abstract boolean handleIsMany2Many();

    /**
     * Indicates whether or not this associations represents a many-to-many relation.
     * @return (boolean)handleIsMany2Many()
     */
    public final boolean isMany2Many()
    {
        boolean many2Many2a = false;
        // many2Many has no pre constraints
        many2Many2a = handleIsMany2Many();
        // many2Many has no post constraints
        return many2Many2a;
    }

   /**
    * @see AssociationFacade#isAssociationClass()
    * @return boolean
    */
    protected abstract boolean handleIsAssociationClass();

    /**
     * True if the AssociationFacade is an AssociationClass.
     * @return (boolean)handleIsAssociationClass()
     */
    public final boolean isAssociationClass()
    {
        boolean associationClass3a = false;
        // associationClass has no pre constraints
        associationClass3a = handleIsAssociationClass();
        // associationClass has no post constraints
        return associationClass3a;
    }

   /**
    * @see AssociationFacade#isAbstract()
    * @return boolean
    */
    protected abstract boolean handleIsAbstract();

    /**
     * Indicates if this association is 'abstract'.
     * @return (boolean)handleIsAbstract()
     */
    public final boolean isAbstract()
    {
        boolean abstract4a = false;
        // abstract has no pre constraints
        abstract4a = handleIsAbstract();
        // abstract has no post constraints
        return abstract4a;
    }

   /**
    * @see AssociationFacade#isLeaf()
    * @return boolean
    */
    protected abstract boolean handleIsLeaf();

    /**
     * True if this association cannot be extended and represent a leaf in the inheritance tree.
     * @return (boolean)handleIsLeaf()
     */
    public final boolean isLeaf()
    {
        boolean leaf5a = false;
        // leaf has no pre constraints
        leaf5a = handleIsLeaf();
        // leaf has no post constraints
        return leaf5a;
    }

   /**
    * @see AssociationFacade#isDerived()
    * @return boolean
    */
    protected abstract boolean handleIsDerived();

    /**
     * UML2: Returns the value of the 'Is Derived' attribute. The default value is "false". If
     * isDerived is true, the value of the attribute is derived from information elsewhere.
     * Specifies whether the Property is derived, i.e., whether its value or values can be computed
     * from other information.
     * @return (boolean)handleIsDerived()
     */
    public final boolean isDerived()
    {
        boolean derived6a = false;
        // derived has no pre constraints
        derived6a = handleIsDerived();
        // derived has no post constraints
        return derived6a;
    }

   /**
    * @see AssociationFacade#isBinary()
    * @return boolean
    */
    protected abstract boolean handleIsBinary();

    /**
     * UML2: Determines whether this association is a binary association, i.e. whether it has
     * exactly two member ends. UML2 allows association classes in the association itself (many2many
     * with association attributes). Default=true: only two member ends.
     * @return (boolean)handleIsBinary()
     */
    public final boolean isBinary()
    {
        boolean binary7a = false;
        // binary has no pre constraints
        binary7a = handleIsBinary();
        // binary has no post constraints
        return binary7a;
    }

    // ------------- associations ------------------

    private AssociationEndFacade __getAssociationEndA1r;
    private boolean __getAssociationEndA1rSet = false;

    /**
     * An association describes a set of tuples whose values refer to typed instances. An instance
     * of an
     * association is called a link.
     * @return (AssociationEndFacade)handleGetAssociationEndA()
     */
    public final AssociationEndFacade getAssociationEndA()
    {
        AssociationEndFacade getAssociationEndA1r = this.__getAssociationEndA1r;
        if (!this.__getAssociationEndA1rSet)
        {
            // associationFacade has no pre constraints
            Object result = handleGetAssociationEndA();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAssociationEndA1r = (AssociationEndFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AssociationFacadeLogic.logger.warn("incorrect metafacade cast for AssociationFacadeLogic.getAssociationEndA AssociationEndFacade " + result + ": " + shieldedResult);
            }
            // associationFacade has no post constraints
            this.__getAssociationEndA1r = getAssociationEndA1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAssociationEndA1rSet = true;
            }
        }
        return getAssociationEndA1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAssociationEndA();

    private AssociationEndFacade __getAssociationEndB2r;
    private boolean __getAssociationEndB2rSet = false;

    /**
     * An association describes a set of tuples whose values refer to typed instances. An instance
     * of an
     * association is called a link.
     * @return (AssociationEndFacade)handleGetAssociationEndB()
     */
    public final AssociationEndFacade getAssociationEndB()
    {
        AssociationEndFacade getAssociationEndB2r = this.__getAssociationEndB2r;
        if (!this.__getAssociationEndB2rSet)
        {
            // associationFacade has no pre constraints
            Object result = handleGetAssociationEndB();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAssociationEndB2r = (AssociationEndFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AssociationFacadeLogic.logger.warn("incorrect metafacade cast for AssociationFacadeLogic.getAssociationEndB AssociationEndFacade " + result + ": " + shieldedResult);
            }
            // associationFacade has no post constraints
            this.__getAssociationEndB2r = getAssociationEndB2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAssociationEndB2rSet = true;
            }
        }
        return getAssociationEndB2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAssociationEndB();

    /**
     * The association owning this association end.
     * @return (List<AssociationEndFacade>)handleGetAssociationEnds()
     */
    public final List<AssociationEndFacade> getAssociationEnds()
    {
        List<AssociationEndFacade> getAssociationEnds3r = null;
        // association has no pre constraints
        List result = handleGetAssociationEnds();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAssociationEnds3r = (List<AssociationEndFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            AssociationFacadeLogic.logger.warn("incorrect metafacade cast for AssociationFacadeLogic.getAssociationEnds List<AssociationEndFacade> " + result + ": " + shieldedResult);
        }
        // association has no post constraints
        return getAssociationEnds3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetAssociationEnds();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see GeneralizableElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}