// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.Destination;
import org.andromda.metafacades.uml.Role;
import org.andromda.metafacades.uml.Service;
import org.andromda.metafacades.uml.ServiceOperation;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Operation;

/**
 * Reprsents an operation of a service.
 * MetafacadeLogic for ServiceOperation
 *
 * @see ServiceOperation
 */
public abstract class ServiceOperationLogic
    extends OperationFacadeLogicImpl
    implements ServiceOperation
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ServiceOperationLogic(Object metaObjectIn, String context)
    {
        super((Operation)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ServiceOperationLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ServiceOperation if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ServiceOperation";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ServiceOperation
     */
    public boolean isServiceOperationMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ServiceOperation#isIncomingMessageOperation()
    * @return boolean
    */
    protected abstract boolean handleIsIncomingMessageOperation();

    /**
     * Whether or not this operation represents an "incoming" message operation (i.e. it receives
     * messages from Queues or Topics).
     * @return (boolean)handleIsIncomingMessageOperation()
     */
    public final boolean isIncomingMessageOperation()
    {
        boolean incomingMessageOperation1a = false;
        // incomingMessageOperation has no pre constraints
        incomingMessageOperation1a = handleIsIncomingMessageOperation();
        // incomingMessageOperation has no post constraints
        return incomingMessageOperation1a;
    }

   /**
    * @see ServiceOperation#isOutgoingMessageOperation()
    * @return boolean
    */
    protected abstract boolean handleIsOutgoingMessageOperation();

    /**
     * Whether or not this service operation represents an "outgoing" messaging operation (i.e. it
     * sends messages to Queues or Topics).
     * @return (boolean)handleIsOutgoingMessageOperation()
     */
    public final boolean isOutgoingMessageOperation()
    {
        boolean outgoingMessageOperation2a = false;
        // outgoingMessageOperation has no pre constraints
        outgoingMessageOperation2a = handleIsOutgoingMessageOperation();
        // outgoingMessageOperation has no post constraints
        return outgoingMessageOperation2a;
    }

   /**
    * @see ServiceOperation#isMessageOperation()
    * @return boolean
    */
    protected abstract boolean handleIsMessageOperation();

    /**
     * Whether or not this is operation accepts incoming or outgoing messages.
     * @return (boolean)handleIsMessageOperation()
     */
    public final boolean isMessageOperation()
    {
        boolean messageOperation3a = false;
        // messageOperation has no pre constraints
        messageOperation3a = handleIsMessageOperation();
        // messageOperation has no post constraints
        return messageOperation3a;
    }

    // ------------- associations ------------------

    /**
     * Reprsents an operation of a service.
     * @return (Destination)handleGetOutgoingDestination()
     */
    public final Destination getOutgoingDestination()
    {
        Destination getOutgoingDestination1r = null;
        // serviceOperation has no pre constraints
        Object result = handleGetOutgoingDestination();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOutgoingDestination1r = (Destination)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceOperationLogic.logger.warn("incorrect metafacade cast for ServiceOperationLogic.getOutgoingDestination Destination " + result + ": " + shieldedResult);
        }
        // serviceOperation has no post constraints
        return getOutgoingDestination1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOutgoingDestination();

    /**
     * Reprsents an operation of a service.
     * @return (Collection<Role>)handleGetRoles()
     */
    public final Collection<Role> getRoles()
    {
        Collection<Role> getRoles2r = null;
        // serviceOperation has no pre constraints
        Collection result = handleGetRoles();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getRoles2r = (Collection<Role>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceOperationLogic.logger.warn("incorrect metafacade cast for ServiceOperationLogic.getRoles Collection<Role> " + result + ": " + shieldedResult);
        }
        // serviceOperation has no post constraints
        return getRoles2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetRoles();

    /**
     * Reprsents an operation of a service.
     * @return (Service)handleGetService()
     */
    public final Service getService()
    {
        Service getService3r = null;
        // serviceOperation has no pre constraints
        Object result = handleGetService();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getService3r = (Service)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceOperationLogic.logger.warn("incorrect metafacade cast for ServiceOperationLogic.getService Service " + result + ": " + shieldedResult);
        }
        // serviceOperation has no post constraints
        return getService3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetService();

    /**
     * Reprsents an operation of a service.
     * @return (Destination)handleGetIncomingDestination()
     */
    public final Destination getIncomingDestination()
    {
        Destination getIncomingDestination4r = null;
        // serviceOperation has no pre constraints
        Object result = handleGetIncomingDestination();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getIncomingDestination4r = (Destination)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceOperationLogic.logger.warn("incorrect metafacade cast for ServiceOperationLogic.getIncomingDestination Destination " + result + ": " + shieldedResult);
        }
        // serviceOperation has no post constraints
        return getIncomingDestination4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetIncomingDestination();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see OperationFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}