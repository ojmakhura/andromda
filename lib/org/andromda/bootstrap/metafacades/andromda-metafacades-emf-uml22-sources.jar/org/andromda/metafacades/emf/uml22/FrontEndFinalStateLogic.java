// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndController;
import org.andromda.metafacades.uml.FrontEndFinalState;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.metafacades.uml.FrontEndUseCase;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.FinalState;

/**
 * A final state represents the end of a use-case, in a "front-end" application this means its the
 * transition into the next front-end use case.
 * MetafacadeLogic for FrontEndFinalState
 *
 * @see FrontEndFinalState
 */
public abstract class FrontEndFinalStateLogic
    extends FinalStateFacadeLogicImpl
    implements FrontEndFinalState
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndFinalStateLogic(Object metaObjectIn, String context)
    {
        super((FinalState)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndFinalStateLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndFinalState if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndFinalState";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndFinalState
     */
    public boolean isFrontEndFinalStateMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndFinalState#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * Indicates if this front end final state is contained within a FrontEndUseCase.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase1a;
    }

   /**
    * @see FrontEndFinalState#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * The path to which this final state points.
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path2a = null;
        // path has no pre constraints
        path2a = handleGetPath();
        // path has no post constraints
        return path2a;
    }

   /**
    * @see FrontEndFinalState#getTargetControllerFullyQualifiedName()
    * @return String
    */
    protected abstract String handleGetTargetControllerFullyQualifiedName();

    /**
     * The target controller to which this final state points.
     * @return (String)handleGetTargetControllerFullyQualifiedName()
     */
    public final String getTargetControllerFullyQualifiedName()
    {
        String targetControllerFullyQualifiedName3a = null;
        // targetControllerFullyQualifiedName has no pre constraints
        targetControllerFullyQualifiedName3a = handleGetTargetControllerFullyQualifiedName();
        // targetControllerFullyQualifiedName has no post constraints
        return targetControllerFullyQualifiedName3a;
    }

   /**
    * @see FrontEndFinalState#getTargetControllerBeanName()
    * @return String
    */
    protected abstract String handleGetTargetControllerBeanName();

    /**
     * The controller bean name to which this final state points.
     * @return (String)handleGetTargetControllerBeanName()
     */
    public final String getTargetControllerBeanName()
    {
        String targetControllerBeanName4a = null;
        // targetControllerBeanName has no pre constraints
        targetControllerBeanName4a = handleGetTargetControllerBeanName();
        // targetControllerBeanName has no post constraints
        return targetControllerBeanName4a;
    }

   /**
    * @see FrontEndFinalState#getTargetElement()
    * @return ModelElementFacade
    */
    protected abstract ModelElementFacade handleGetTargetElement();

    /**
     * The element to which this final state points.
     * @return (ModelElementFacade)handleGetTargetElement()
     */
    public final ModelElementFacade getTargetElement()
    {
        ModelElementFacade targetElement5a = null;
        // targetElement has no pre constraints
        targetElement5a = handleGetTargetElement();
        // targetElement has no post constraints
        return targetElement5a;
    }

   /**
    * @see FrontEndFinalState#getTargetController()
    * @return FrontEndController
    */
    protected abstract FrontEndController handleGetTargetController();

    /**
     * TODO: Model Documentation for
     * FrontEndFinalState.targetController
     * @return (FrontEndController)handleGetTargetController()
     */
    public final FrontEndController getTargetController()
    {
        FrontEndController targetController6a = null;
        // targetController has no pre constraints
        targetController6a = handleGetTargetController();
        // targetController has no post constraints
        return targetController6a;
    }

    // ------------- associations ------------------

    private FrontEndUseCase __getTargetUseCase1r;
    private boolean __getTargetUseCase1rSet = false;

    /**
     * The final states linking to this use case
     * @return (FrontEndUseCase)handleGetTargetUseCase()
     */
    public final FrontEndUseCase getTargetUseCase()
    {
        FrontEndUseCase getTargetUseCase1r = this.__getTargetUseCase1r;
        if (!this.__getTargetUseCase1rSet)
        {
            // referencingFinalStates has no pre constraints
            Object result = handleGetTargetUseCase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getTargetUseCase1r = (FrontEndUseCase)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndFinalStateLogic.logger.warn("incorrect metafacade cast for FrontEndFinalStateLogic.getTargetUseCase FrontEndUseCase " + result + ": " + shieldedResult);
            }
            // referencingFinalStates has no post constraints
            this.__getTargetUseCase1r = getTargetUseCase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTargetUseCase1rSet = true;
            }
        }
        return getTargetUseCase1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTargetUseCase();

    private List<FrontEndParameter> __getInterUseCaseParameters2r;
    private boolean __getInterUseCaseParameters2rSet = false;

    /**
     * A final state represents the end of a use-case, in a "front-end" application this means its
     * the
     * transition into the next front-end use case.
     * @return (List<FrontEndParameter>)handleGetInterUseCaseParameters()
     */
    public final List<FrontEndParameter> getInterUseCaseParameters()
    {
        List<FrontEndParameter> getInterUseCaseParameters2r = this.__getInterUseCaseParameters2r;
        if (!this.__getInterUseCaseParameters2rSet)
        {
            // frontEndFinalState has no pre constraints
            List result = handleGetInterUseCaseParameters();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getInterUseCaseParameters2r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndFinalStateLogic.logger.warn("incorrect metafacade cast for FrontEndFinalStateLogic.getInterUseCaseParameters List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // frontEndFinalState has no post constraints
            this.__getInterUseCaseParameters2r = getInterUseCaseParameters2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInterUseCaseParameters2rSet = true;
            }
        }
        return getInterUseCaseParameters2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetInterUseCaseParameters();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see FinalStateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}