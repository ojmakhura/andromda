// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.EnumerationFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;

/**
 * Represents an attribute on a classifier. UML2 maps both Attributes and AssociationEnds to
 * Property. A property is a structural feature of a classifier that characterizes instances of the
 * classifier. A property related by ownedAttribute to a classifier (other than an association)
 * represents an attribute and might also represent an association end. It relates an instance of
 * the class to a value or set of values of the type of the attribute. A property represents a set
 * of instances that are owned by a containing classifier instance. Property represents a declared
 * state of one or more instances in terms of a named relationship to a value or values. When a
 * property is an attribute of a classifier, the value or values are related to the instance of the
 * classifier by being held in slots of the instance. The range of valid values represented by the
 * property can be controlled by setting the property's type.
 * MetafacadeLogic for AttributeFacade
 *
 * @see AttributeFacade
 */
public abstract class AttributeFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements AttributeFacade
{
    /**
     * The underlying UML object
     * @see Attribute
     */
    protected Attribute metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected AttributeFacadeLogic(Attribute metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(AttributeFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to AttributeFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AttributeFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see AttributeFacade
     */
    public boolean isAttributeFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see AttributeFacade#getGetterName()
    * @return String
    */
    protected abstract String handleGetGetterName();

    /**
     * The name of the accessor operation that would retrieve this attribute's value.
     * @return (String)handleGetGetterName()
     */
    public final String getGetterName()
    {
        String getterName1a = null;
        // getterName has no pre constraints
        getterName1a = handleGetGetterName();
        // getterName has no post constraints
        return getterName1a;
    }

   /**
    * @see AttributeFacade#getSetterName()
    * @return String
    */
    protected abstract String handleGetSetterName();

    /**
     * The name of the mutator operation that would retrieve this attribute's value.
     * @return (String)handleGetSetterName()
     */
    public final String getSetterName()
    {
        String setterName2a = null;
        // setterName has no pre constraints
        setterName2a = handleGetSetterName();
        // setterName has no post constraints
        return setterName2a;
    }

   /**
    * @see AttributeFacade#isReadOnly()
    * @return boolean
    */
    protected abstract boolean handleIsReadOnly();

    /**
     * Whether or not this attribute can be modified.
     * @return (boolean)handleIsReadOnly()
     */
    public final boolean isReadOnly()
    {
        boolean readOnly3a = false;
        // readOnly has no pre constraints
        readOnly3a = handleIsReadOnly();
        // readOnly has no post constraints
        return readOnly3a;
    }

   /**
    * @see AttributeFacade#getDefaultValue()
    * @return String
    */
    protected abstract String handleGetDefaultValue();

    /**
     * The default value of the attribute.  This is the value given if no value is defined.
     * @return (String)handleGetDefaultValue()
     */
    public final String getDefaultValue()
    {
        String defaultValue4a = null;
        // defaultValue has no pre constraints
        defaultValue4a = handleGetDefaultValue();
        // defaultValue has no post constraints
        return defaultValue4a;
    }

   /**
    * @see AttributeFacade#isStatic()
    * @return boolean
    */
    protected abstract boolean handleIsStatic();

    /**
     * Indicates if this attribute is 'static', meaning it has a classifier scope.
     * @return (boolean)handleIsStatic()
     */
    public final boolean isStatic()
    {
        boolean static5a = false;
        // static has no pre constraints
        static5a = handleIsStatic();
        // static has no post constraints
        return static5a;
    }

   /**
    * @see AttributeFacade#isRequired()
    * @return boolean
    */
    protected abstract boolean handleIsRequired();

    /**
     * Whether or not the multiplicity of this attribute is 1.
     * @return (boolean)handleIsRequired()
     */
    public final boolean isRequired()
    {
        boolean required6a = false;
        // required has no pre constraints
        required6a = handleIsRequired();
        // required has no post constraints
        return required6a;
    }

   /**
    * @see AttributeFacade#isMany()
    * @return boolean
    */
    protected abstract boolean handleIsMany();

    /**
     * Whether or not this attribute has a multiplicity greater than 1.
     * @return (boolean)handleIsMany()
     */
    public final boolean isMany()
    {
        boolean many7a = false;
        // many has no pre constraints
        many7a = handleIsMany();
        // many has no post constraints
        return many7a;
    }

   /**
    * @see AttributeFacade#isChangeable()
    * @return boolean
    */
    protected abstract boolean handleIsChangeable();

    /**
     * True if this attribute can be modified.
     * @return (boolean)handleIsChangeable()
     */
    public final boolean isChangeable()
    {
        boolean changeable8a = false;
        // changeable has no pre constraints
        changeable8a = handleIsChangeable();
        // changeable has no post constraints
        return changeable8a;
    }

   /**
    * @see AttributeFacade#isAddOnly()
    * @return boolean
    */
    protected abstract boolean handleIsAddOnly();

    /**
     * True if this attribute can only be set.
     * @return (boolean)handleIsAddOnly()
     */
    public final boolean isAddOnly()
    {
        boolean addOnly9a = false;
        // addOnly has no pre constraints
        addOnly9a = handleIsAddOnly();
        // addOnly has no post constraints
        return addOnly9a;
    }

   /**
    * @see AttributeFacade#isEnumerationLiteral()
    * @return boolean
    */
    protected abstract boolean handleIsEnumerationLiteral();

    /**
     * True if this attribute is owned by an enumeration.
     * @return (boolean)handleIsEnumerationLiteral()
     */
    public final boolean isEnumerationLiteral()
    {
        boolean enumerationLiteral10a = false;
        // enumerationLiteral has no pre constraints
        enumerationLiteral10a = handleIsEnumerationLiteral();
        // enumerationLiteral has no post constraints
        return enumerationLiteral10a;
    }

   /**
    * @see AttributeFacade#getEnumerationValue()
    * @return String
    */
    protected abstract String handleGetEnumerationValue();

    /**
     * The value for this attribute if it is an enumeration literal, null otherwise. The default
     * value is returned as a String if it has been specified, if it's not specified this
     * attribute's name is assumed.
     * @return (String)handleGetEnumerationValue()
     */
    public final String getEnumerationValue()
    {
        String enumerationValue11a = null;
        // enumerationValue has no pre constraints
        enumerationValue11a = handleGetEnumerationValue();
        // enumerationValue has no post constraints
        return enumerationValue11a;
    }

   /**
    * @see AttributeFacade#getGetterSetterTypeName()
    * @return String
    */
    protected abstract String handleGetGetterSetterTypeName();

    /**
     * The name of the type that is returned on the accessor and mutator operations,  determined in
     * part by the multiplicity.
     * @return (String)handleGetGetterSetterTypeName()
     */
    public final String getGetterSetterTypeName()
    {
        String getterSetterTypeName12a = null;
        // getterSetterTypeName has no pre constraints
        getterSetterTypeName12a = handleGetGetterSetterTypeName();
        // getterSetterTypeName has no post constraints
        return getterSetterTypeName12a;
    }

   /**
    * @see AttributeFacade#isOrdered()
    * @return boolean
    */
    protected abstract boolean handleIsOrdered();

    /**
     * Indicates whether or not the attributes are ordered (if multiplicity is greater than 1).
     * @return (boolean)handleIsOrdered()
     */
    public final boolean isOrdered()
    {
        boolean ordered13a = false;
        // ordered has no pre constraints
        ordered13a = handleIsOrdered();
        // ordered has no post constraints
        return ordered13a;
    }

   /**
    * @see AttributeFacade#isDefaultValuePresent()
    * @return boolean
    */
    protected abstract boolean handleIsDefaultValuePresent();

    /**
     * Indicates if the default value is present.
     * @return (boolean)handleIsDefaultValuePresent()
     */
    public final boolean isDefaultValuePresent()
    {
        boolean defaultValuePresent14a = false;
        // defaultValuePresent has no pre constraints
        defaultValuePresent14a = handleIsDefaultValuePresent();
        // defaultValuePresent has no post constraints
        return defaultValuePresent14a;
    }

   /**
    * @see AttributeFacade#getUpper()
    * @return int
    */
    protected abstract int handleGetUpper();

    /**
     * the upper value for the multiplicity (will be -1 for *)
     * -only applicable for UML2
     * @return (int)handleGetUpper()
     */
    public final int getUpper()
    {
        int upper15a = 0;
        // upper has no pre constraints
        upper15a = handleGetUpper();
        // upper has no post constraints
        return upper15a;
    }

   /**
    * @see AttributeFacade#getLower()
    * @return int
    */
    protected abstract int handleGetLower();

    /**
     * the lower value for the multiplicity
     * -only applicable for UML2
     * @return (int)handleGetLower()
     */
    public final int getLower()
    {
        int lower16a = 0;
        // lower has no pre constraints
        lower16a = handleGetLower();
        // lower has no post constraints
        return lower16a;
    }

   /**
    * @see AttributeFacade#isEnumerationMember()
    * @return boolean
    */
    protected abstract boolean handleIsEnumerationMember();

    /**
     * True if this attribute is owned by an enumeration but is defined as a member variable (NOT a
     * literal).
     * @return (boolean)handleIsEnumerationMember()
     */
    public final boolean isEnumerationMember()
    {
        boolean enumerationMember17a = false;
        // enumerationMember has no pre constraints
        enumerationMember17a = handleIsEnumerationMember();
        // enumerationMember has no post constraints
        return enumerationMember17a;
    }

   /**
    * @see AttributeFacade#getEnumerationLiteralParameters()
    * @return String
    */
    protected abstract String handleGetEnumerationLiteralParameters();

    /**
     * Returns the enumeration literal parameters defined by tagged value as a comma separated list.
     * @return (String)handleGetEnumerationLiteralParameters()
     */
    public final String getEnumerationLiteralParameters()
    {
        String enumerationLiteralParameters18a = null;
        // enumerationLiteralParameters has no pre constraints
        enumerationLiteralParameters18a = handleGetEnumerationLiteralParameters();
        // enumerationLiteralParameters has no post constraints
        return enumerationLiteralParameters18a;
    }

   /**
    * @see AttributeFacade#isEnumerationLiteralParametersExist()
    * @return boolean
    */
    protected abstract boolean handleIsEnumerationLiteralParametersExist();

    /**
     * Returns true if enumeration literal parameters exist (defined by tagged value) for the
     * literal.
     * @return (boolean)handleIsEnumerationLiteralParametersExist()
     */
    public final boolean isEnumerationLiteralParametersExist()
    {
        boolean enumerationLiteralParametersExist19a = false;
        // enumerationLiteralParametersExist has no pre constraints
        enumerationLiteralParametersExist19a = handleIsEnumerationLiteralParametersExist();
        // enumerationLiteralParametersExist has no post constraints
        return enumerationLiteralParametersExist19a;
    }

   /**
    * @see AttributeFacade#isUnique()
    * @return boolean
    */
    protected abstract boolean handleIsUnique();

    /**
     * If the attribute is unique within the Collection type. UML2 only. UML14 always returns false.
     * Unique+Ordered determines the implementation Collection type. Default=false.
     * @return (boolean)handleIsUnique()
     */
    public final boolean isUnique()
    {
        boolean unique20a = false;
        // unique has no pre constraints
        unique20a = handleIsUnique();
        // unique has no post constraints
        return unique20a;
    }

   /**
    * @see AttributeFacade#isLeaf()
    * @return boolean
    */
    protected abstract boolean handleIsLeaf();

    /**
     * IsLeaf property in the operation. If true, operation is final, cannot be extended or
     * implemented by a descendant.
     * @return (boolean)handleIsLeaf()
     */
    public final boolean isLeaf()
    {
        boolean leaf21a = false;
        // leaf has no pre constraints
        leaf21a = handleIsLeaf();
        // leaf has no post constraints
        return leaf21a;
    }

   /**
    * @see AttributeFacade#isDerived()
    * @return boolean
    */
    protected abstract boolean handleIsDerived();

    /**
     * If the attribute is derived (its value is computed). UML2 only. UML14 always returns false.
     * Default=false.
     * @return (boolean)handleIsDerived()
     */
    public final boolean isDerived()
    {
        boolean derived22a = false;
        // derived has no pre constraints
        derived22a = handleIsDerived();
        // derived has no post constraints
        return derived22a;
    }

   /**
    * @see AttributeFacade#getEnumerationLiteralDisplay()
    * @return String
    */
    protected abstract String handleGetEnumerationLiteralDisplay();

    /**
     * Returns the enumeration literal parameters defined by tagged value as a comma separated list.
     * @return (String)handleGetEnumerationLiteralDisplay()
     */
    public final String getEnumerationLiteralDisplay()
    {
        String enumerationLiteralDisplay23a = null;
        // enumerationLiteralDisplay has no pre constraints
        enumerationLiteralDisplay23a = handleGetEnumerationLiteralDisplay();
        // enumerationLiteralDisplay has no post constraints
        return enumerationLiteralDisplay23a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Searches the given feature for the specified tag.
     * If the follow boolean is set to true then the search will continue from the class attribute
     * to the class itself and then up the class hierarchy.
     * @param name
     * @param follow
     * @return Object
     */
    protected abstract Object handleFindTaggedValue(String name, boolean follow);

    /**
     * Searches the given feature for the specified tag.
     * If the follow boolean is set to true then the search will continue from the class attribute
     * to the class itself and then up the class hierarchy.
     * @param name String
     * The name of the tagged value to find.
     * @param follow boolean
     * If true search should 'follow' the inheritance hierarchy, false otherwise.
     * @return handleFindTaggedValue(name, follow)
     */
    public Object findTaggedValue(String name, boolean follow)
    {
        // findTaggedValue has no pre constraints
        Object returnValue = handleFindTaggedValue(name, follow);
        // findTaggedValue has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * Represents an attribute on a classifier. UML2 maps both Attributes and AssociationEnds to
     * Property.
     * A property is a structural feature of a classifier that characterizes instances of the
     * classifier. A
     * property related by ownedAttribute to a classifier (other than an association) represents an
     * attribute and might also represent an association end. It relates an instance of the class to
     * a
     * value or set of values of the type of the attribute. A property represents a set of instances
     * that
     * are owned by a containing classifier instance. Property represents a declared state of one or
     * more
     * instances in terms of a named relationship to a value or values. When a property is an
     * attribute of
     * a classifier, the value or values are related to the instance of the classifier by being held
     * in
     * slots of the instance. The range of valid values represented by the property can be
     * controlled by
     * setting the property's type.
     * @return (ClassifierFacade)handleGetType()
     */
    public final ClassifierFacade getType()
    {
        ClassifierFacade getType1r = null;
        // attributeFacade has no pre constraints
        Object result = handleGetType();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getType1r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            AttributeFacadeLogic.logger.warn("incorrect metafacade cast for AttributeFacadeLogic.getType ClassifierFacade " + result + ": " + shieldedResult);
        }
        // attributeFacade has no post constraints
        return getType1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetType();

    /**
     * This enumeration's literals.
     * @return (EnumerationFacade)handleGetEnumeration()
     */
    public final EnumerationFacade getEnumeration()
    {
        EnumerationFacade getEnumeration2r = null;
        // literals has no pre constraints
        Object result = handleGetEnumeration();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getEnumeration2r = (EnumerationFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            AttributeFacadeLogic.logger.warn("incorrect metafacade cast for AttributeFacadeLogic.getEnumeration EnumerationFacade " + result + ": " + shieldedResult);
        }
        // literals has no post constraints
        return getEnumeration2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetEnumeration();

    /**
     * Gets the attributes that belong to the classifier.
     * @return (ClassifierFacade)handleGetOwner()
     */
    public final ClassifierFacade getOwner()
    {
        ClassifierFacade getOwner3r = null;
        // attributes has no pre constraints
        Object result = handleGetOwner();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOwner3r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            AttributeFacadeLogic.logger.warn("incorrect metafacade cast for AttributeFacadeLogic.getOwner ClassifierFacade " + result + ": " + shieldedResult);
        }
        // attributes has no post constraints
        return getOwner3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOwner();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::AttributeFacade::attribute needs a type</p>
     * <p><b>Error:</b> Each attribute needs a type, you cannot leave the type unspecified.</p>
     * <p><b>OCL:</b> context AttributeFacade inv: type.name->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::AttributeFacade::attribute must have a name</p>
     * <p><b>Error:</b> Each attribute must have a non-empty name.</p>
     * <p><b>OCL:</b> context AttributeFacade inv: name -> notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::AttributeFacade::primitive attribute must be required</p>
     * <p><b>Error:</b> Primitive attributes must have a multiplicity lower bound > 0 (must be required). Use a wrapped
type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context AttributeFacade inv: type.primitive implies (lower > 0)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::AttributeFacade::primitive attribute cannot be used in Collection</p>
     * <p><b>Error:</b> Primitive attributes cannot be used in Collections (multiplicity > 1). Use the wrapped type instead.</p>
     * <p><b>OCL:</b> context AttributeFacade inv: type.primitive implies (many = false)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::AttributeFacade::wrapped primitive attribute should not be required</p>
     * <p><b>Error:</b> Wrapped primitive attributes must have a multiplicity lower bound = 0 (must be optional). Use the
unwrapped type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context AttributeFacade inv: type.wrappedPrimitive and many = false implies (lower = 0)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"type.name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::AttributeFacade::attribute needs a type",
                        "Each attribute needs a type, you cannot leave the type unspecified."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::AttributeFacade::attribute needs a type' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::AttributeFacade::attribute must have a name",
                        "Each attribute must have a non-empty name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::AttributeFacade::attribute must have a name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.primitive"))).booleanValue()?(OCLExpressions.greater(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::AttributeFacade::primitive attribute must be required",
                        "Primitive attributes must have a multiplicity lower bound > 0 (must be required). Use a wrapped\ntype, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::AttributeFacade::primitive attribute must be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.primitive"))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::AttributeFacade::primitive attribute cannot be used in Collection",
                        "Primitive attributes cannot be used in Collections (multiplicity > 1). Use the wrapped type instead."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::AttributeFacade::primitive attribute cannot be used in Collection' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.wrappedPrimitive"))).booleanValue()&&OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::AttributeFacade::wrapped primitive attribute should not be required",
                        "Wrapped primitive attributes must have a multiplicity lower bound = 0 (must be optional). Use the\nunwrapped type, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::AttributeFacade::wrapped primitive attribute should not be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}