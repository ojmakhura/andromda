// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.IncludeFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Include;

/**
 * An include relationship defines that a use case contains the behavior defined in another use
 * case.
 * MetafacadeLogic for IncludeFacade
 *
 * @see IncludeFacade
 */
public abstract class IncludeFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements IncludeFacade
{
    /**
     * The underlying UML object
     * @see Include
     */
    protected Include metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected IncludeFacadeLogic(Include metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(IncludeFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to IncludeFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.IncludeFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see IncludeFacade
     */
    public boolean isIncludeFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * An include relationship defines that a use case contains the behavior defined in another use
     * case.
     * @return (UseCaseFacade)handleGetAddition()
     */
    public final UseCaseFacade getAddition()
    {
        UseCaseFacade getAddition1r = null;
        // includeFacade has no pre constraints
        Object result = handleGetAddition();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getAddition1r = (UseCaseFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            IncludeFacadeLogic.logger.warn("incorrect metafacade cast for IncludeFacadeLogic.getAddition UseCaseFacade " + result + ": " + shieldedResult);
        }
        // includeFacade has no post constraints
        return getAddition1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAddition();

    /**
     * The included instances related to this use-case.
     * @return (UseCaseFacade)handleGetBase()
     */
    public final UseCaseFacade getBase()
    {
        UseCaseFacade getBase2r = null;
        // includes has no pre constraints
        Object result = handleGetBase();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getBase2r = (UseCaseFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            IncludeFacadeLogic.logger.warn("incorrect metafacade cast for IncludeFacadeLogic.getBase UseCaseFacade " + result + ": " + shieldedResult);
        }
        // includes has no post constraints
        return getBase2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetBase();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}