// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EnumerationLiteralFacade;
import org.eclipse.uml2.uml.EnumerationLiteral;

/**
 * A user-defined data value for an enumeration.
 * MetafacadeLogic for EnumerationLiteralFacade
 *
 * @see EnumerationLiteralFacade
 */
public abstract class EnumerationLiteralFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements EnumerationLiteralFacade
{
    /**
     * The underlying UML object
     * @see EnumerationLiteral
     */
    protected EnumerationLiteral metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EnumerationLiteralFacadeLogic(EnumerationLiteral metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EnumerationLiteralFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EnumerationLiteralFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EnumerationLiteralFacade
     */
    public boolean isEnumerationLiteralFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see EnumerationLiteralFacade#getValue()
    * @return String
    */
    protected abstract String handleGetValue();

    /**
     * Returns the value of this enumeration literal, by default the value is the same as the name.
     * @return (String)handleGetValue()
     */
    public final String getValue()
    {
        String value1a = null;
        // value has no pre constraints
        value1a = handleGetValue();
        // value has no post constraints
        return value1a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Gets the name of the enumeration literal (if the "modelName" flag is true, then the actual
     * name of the literal in the model is returned - otherwise the name that has any masking
     * applied).
     * @param modelName
     * @return String
     */
    protected abstract String handleGetName(boolean modelName);

    /**
     * Gets the name of the enumeration literal (if the "modelName" flag is true, then the actual
     * name of the literal in the model is returned - otherwise the name that has any masking
     * applied).
     * @param modelName boolean
     * TODO: Model Documentation for
     * EnumerationLiteralFacade.getName(modelName)
     * @return handleGetName(modelName)
     */
    public String getName(boolean modelName)
    {
        // getName has no pre constraints
        String returnValue = handleGetName(modelName);
        // getName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the value of the enumeration literal  (if the "modelValue" flag is true, then the actual
     * value of the literal in the model is returned - otherwise the value that has any masking
     * applied is returned).
     * @param modelValue
     * @return String
     */
    protected abstract String handleGetValue(boolean modelValue);

    /**
     * Gets the value of the enumeration literal  (if the "modelValue" flag is true, then the actual
     * value of the literal in the model is returned - otherwise the value that has any masking
     * applied is returned).
     * @param modelValue boolean
     * TODO: Model Documentation for
     * EnumerationLiteralFacade.getValue(modelValue)
     * @return handleGetValue(modelValue)
     */
    public String getValue(boolean modelValue)
    {
        // getValue has no pre constraints
        String returnValue = handleGetValue(modelValue);
        // getValue has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the Literal's Value. This will be used to create the Literal's Instance.
     * @return String
     */
    protected abstract String handleGetEnumerationValue();

    /**
     * Gets the Literal's Value. This will be used to create the Literal's Instance.
     * @return handleGetEnumerationValue()
     */
    public String getEnumerationValue()
    {
        // getEnumerationValue has no pre constraints
        String returnValue = handleGetEnumerationValue();
        // getEnumerationValue has no post constraints
        return returnValue;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}