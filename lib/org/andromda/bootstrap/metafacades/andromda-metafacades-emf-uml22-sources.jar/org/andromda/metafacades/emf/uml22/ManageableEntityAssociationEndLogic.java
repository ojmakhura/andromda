// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EntityAttribute;
import org.andromda.metafacades.uml.ManageableEntityAssociationEnd;
import org.apache.log4j.Logger;

/**
 * TODO: Model Documentation for ManageableEntityAssociationEnd
 * MetafacadeLogic for ManageableEntityAssociationEnd
 *
 * @see ManageableEntityAssociationEnd
 */
public abstract class ManageableEntityAssociationEndLogic
    extends EntityAssociationEndLogicImpl
    implements ManageableEntityAssociationEnd
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ManageableEntityAssociationEndLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ManageableEntityAssociationEndLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ManageableEntityAssociationEnd if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAssociationEnd";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ManageableEntityAssociationEnd
     */
    public boolean isManageableEntityAssociationEndMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ManageableEntityAssociationEnd#isDisplay()
    * @return boolean
    */
    protected abstract boolean handleIsDisplay();

    /**
     * Whether or not this association end should be displayed.
     * @return (boolean)handleIsDisplay()
     */
    public final boolean isDisplay()
    {
        boolean display1a = false;
        // display has no pre constraints
        display1a = handleIsDisplay();
        // display has no post constraints
        return display1a;
    }

    // ------------- associations ------------------

    private EntityAttribute __getManageableIdentifier1r;
    private boolean __getManageableIdentifier1rSet = false;

    /**
     * TODO: Model Documentation for ManageableEntityAssociationEnd
     * @return (EntityAttribute)handleGetManageableIdentifier()
     */
    public final EntityAttribute getManageableIdentifier()
    {
        EntityAttribute getManageableIdentifier1r = this.__getManageableIdentifier1r;
        if (!this.__getManageableIdentifier1rSet)
        {
            // manageableEntityAssociationEnd has no pre constraints
            Object result = handleGetManageableIdentifier();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getManageableIdentifier1r = (EntityAttribute)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ManageableEntityAssociationEndLogic.logger.warn("incorrect metafacade cast for ManageableEntityAssociationEndLogic.getManageableIdentifier EntityAttribute " + result + ": " + shieldedResult);
            }
            // manageableEntityAssociationEnd has no post constraints
            this.__getManageableIdentifier1r = getManageableIdentifier1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableIdentifier1rSet = true;
            }
        }
        return getManageableIdentifier1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetManageableIdentifier();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see EntityAssociationEndLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}