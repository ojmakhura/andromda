// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.StateMachineFacade;
import org.andromda.metafacades.uml.SubactivityStateFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.State;

/**
 * State machines can be used to express the behavior of part of a system. Behavior is modeled as a
 * traversal of a graph of state nodes interconnected by one or more joined transition arcs that are
 * triggered by the dispatching of series of (event) occurrences. During this traversal, the state
 * machine executes a series of activities associated with various elements of the state machine.
 * Not implmented for UML2.
 * MetafacadeLogic for SubactivityStateFacade
 *
 * @see SubactivityStateFacade
 */
public abstract class SubactivityStateFacadeLogic
    extends StateFacadeLogicImpl
    implements SubactivityStateFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected SubactivityStateFacadeLogic(Object metaObjectIn, String context)
    {
        super((State)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(SubactivityStateFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to SubactivityStateFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.SubactivityStateFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see SubactivityStateFacade
     */
    public boolean isSubactivityStateFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see SubactivityStateFacade#isDynamic()
    * @return boolean
    */
    protected abstract boolean handleIsDynamic();

    /**
     * TODO: Model Documentation for SubactivityStateFacade.dynamic
     * @return (boolean)handleIsDynamic()
     */
    public final boolean isDynamic()
    {
        boolean dynamic1a = false;
        // dynamic has no pre constraints
        dynamic1a = handleIsDynamic();
        // dynamic has no post constraints
        return dynamic1a;
    }

    // ------------- associations ------------------

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine. Not
     * implmented for UML2.
     * @return (StateMachineFacade)handleGetSubmachine()
     */
    public final StateMachineFacade getSubmachine()
    {
        StateMachineFacade getSubmachine1r = null;
        // subactivityStateFacade has no pre constraints
        Object result = handleGetSubmachine();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getSubmachine1r = (StateMachineFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            SubactivityStateFacadeLogic.logger.warn("incorrect metafacade cast for SubactivityStateFacadeLogic.getSubmachine StateMachineFacade " + result + ": " + shieldedResult);
        }
        // subactivityStateFacade has no post constraints
        return getSubmachine1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetSubmachine();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}