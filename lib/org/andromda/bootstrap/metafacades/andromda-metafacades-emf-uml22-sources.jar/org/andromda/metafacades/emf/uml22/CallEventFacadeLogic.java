// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.CallEventFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Activity;

/**
 * A representation of the model object 'Activity'. The specification of parameterized behavior as
 * the coordinated sequencing of subordinate units whose individual elements are actions.
 * MetafacadeLogic for CallEventFacade
 *
 * @see CallEventFacade
 */
public abstract class CallEventFacadeLogic
    extends EventFacadeLogicImpl
    implements CallEventFacade
{
    /**
     * The underlying UML object
     * @see Activity
     */
    protected Activity metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected CallEventFacadeLogic(Activity metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(CallEventFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to CallEventFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.CallEventFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see CallEventFacade
     */
    public boolean isCallEventFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Activity'. The specification of parameterized behavior
     * as the
     * coordinated sequencing of subordinate units whose individual elements are actions.
     * @return (OperationFacade)handleGetOperation()
     */
    public final OperationFacade getOperation()
    {
        OperationFacade getOperation1r = null;
        // callEventFacade has no pre constraints
        Object result = handleGetOperation();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOperation1r = (OperationFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            CallEventFacadeLogic.logger.warn("incorrect metafacade cast for CallEventFacadeLogic.getOperation OperationFacade " + result + ": " + shieldedResult);
        }
        // callEventFacade has no post constraints
        return getOperation1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOperation();

    /**
     * A representation of the model object 'Activity'. The specification of parameterized behavior
     * as the
     * coordinated sequencing of subordinate units whose individual elements are actions.
     * @return (Collection<OperationFacade>)handleGetOperations()
     */
    public final Collection<OperationFacade> getOperations()
    {
        Collection<OperationFacade> getOperations2r = null;
        // callEventFacade has no pre constraints
        Collection result = handleGetOperations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getOperations2r = (Collection<OperationFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            CallEventFacadeLogic.logger.warn("incorrect metafacade cast for CallEventFacadeLogic.getOperations Collection<OperationFacade> " + result + ": " + shieldedResult);
        }
        // callEventFacade has no post constraints
        return getOperations2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOperations();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see EventFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}