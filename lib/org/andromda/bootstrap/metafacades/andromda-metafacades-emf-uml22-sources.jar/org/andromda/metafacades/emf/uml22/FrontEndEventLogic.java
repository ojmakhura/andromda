// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndEvent;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Activity;

/**
 * A front-end event is represented by some kind of even on some kind of front-end (hyperlink,
 * submit button, etc).
 * MetafacadeLogic for FrontEndEvent
 *
 * @see FrontEndEvent
 */
public abstract class FrontEndEventLogic
    extends EventFacadeLogicImpl
    implements FrontEndEvent
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndEventLogic(Object metaObjectIn, String context)
    {
        super((Activity)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndEventLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndEvent if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndEvent";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndEvent
     */
    public boolean isFrontEndEventMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndEvent#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * Indicates whether or not this front end event is contained within a FrontEndUseCase.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase1a;
    }

   /**
    * @see FrontEndEvent#getMessageValue()
    * @return String
    */
    protected abstract String handleGetMessageValue();

    /**
     * The resource message value  for this trigger, this would be the button label or hyperlink
     * name.
     * @return (String)handleGetMessageValue()
     */
    public final String getMessageValue()
    {
        String messageValue2a = null;
        // messageValue has no pre constraints
        messageValue2a = handleGetMessageValue();
        // messageValue has no post constraints
        return messageValue2a;
    }

   /**
    * @see FrontEndEvent#getResetMessageKey()
    * @return String
    */
    protected abstract String handleGetResetMessageKey();

    /**
     * The resource message key for the reset button.
     * @return (String)handleGetResetMessageKey()
     */
    public final String getResetMessageKey()
    {
        String resetMessageKey3a = null;
        // resetMessageKey has no pre constraints
        resetMessageKey3a = handleGetResetMessageKey();
        // resetMessageKey has no post constraints
        return resetMessageKey3a;
    }

   /**
    * @see FrontEndEvent#getResetMessageValue()
    * @return String
    */
    protected abstract String handleGetResetMessageValue();

    /**
     * The default value for the reset button's message.
     * @return (String)handleGetResetMessageValue()
     */
    public final String getResetMessageValue()
    {
        String resetMessageValue4a = null;
        // resetMessageValue has no pre constraints
        resetMessageValue4a = handleGetResetMessageValue();
        // resetMessageValue has no post constraints
        return resetMessageValue4a;
    }

   /**
    * @see FrontEndEvent#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * The resource message key for this trigger.
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey5a = null;
        // messageKey has no pre constraints
        messageKey5a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey5a;
    }

    // ------------- associations ------------------

    private FrontEndControllerOperation __getControllerCall1r;
    private boolean __getControllerCall1rSet = false;

    /**
     * A front-end event is represented by some kind of even on some kind of front-end (hyperlink,
     * submit
     * button, etc).
     * @return (FrontEndControllerOperation)handleGetControllerCall()
     */
    public final FrontEndControllerOperation getControllerCall()
    {
        FrontEndControllerOperation getControllerCall1r = this.__getControllerCall1r;
        if (!this.__getControllerCall1rSet)
        {
            // frontEndEvent has no pre constraints
            Object result = handleGetControllerCall();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getControllerCall1r = (FrontEndControllerOperation)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndEventLogic.logger.warn("incorrect metafacade cast for FrontEndEventLogic.getControllerCall FrontEndControllerOperation " + result + ": " + shieldedResult);
            }
            // frontEndEvent has no post constraints
            this.__getControllerCall1r = getControllerCall1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerCall1rSet = true;
            }
        }
        return getControllerCall1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetControllerCall();

    private FrontEndAction __getAction2r;
    private boolean __getAction2rSet = false;

    /**
     * A front-end event is represented by some kind of even on some kind of front-end (hyperlink,
     * submit
     * button, etc).
     * @return (FrontEndAction)handleGetAction()
     */
    public final FrontEndAction getAction()
    {
        FrontEndAction getAction2r = this.__getAction2r;
        if (!this.__getAction2rSet)
        {
            // frontEndEvent has no pre constraints
            Object result = handleGetAction();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAction2r = (FrontEndAction)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndEventLogic.logger.warn("incorrect metafacade cast for FrontEndEventLogic.getAction FrontEndAction " + result + ": " + shieldedResult);
            }
            // frontEndEvent has no post constraints
            this.__getAction2r = getAction2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAction2rSet = true;
            }
        }
        return getAction2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAction();

    /**
     * A front-end event is represented by some kind of even on some kind of front-end (hyperlink,
     * submit
     * button, etc).
     * @return (List<FrontEndControllerOperation>)handleGetControllerCalls()
     */
    public final List<FrontEndControllerOperation> getControllerCalls()
    {
        List<FrontEndControllerOperation> getControllerCalls3r = null;
        // frontEndEvent has no pre constraints
         List result = handleGetControllerCalls();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getControllerCalls3r = (List<FrontEndControllerOperation>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndEventLogic.logger.warn("incorrect metafacade cast for FrontEndEventLogic.getControllerCalls List<FrontEndControllerOperation> " + result + ": " + shieldedResult);
        }
        // frontEndEvent has no post constraints
        return getControllerCalls3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetControllerCalls();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see EventFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}