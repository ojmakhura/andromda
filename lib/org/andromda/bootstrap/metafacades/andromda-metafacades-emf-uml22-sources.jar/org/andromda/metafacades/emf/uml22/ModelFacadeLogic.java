// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.common.Introspector;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActionStateFacade;
import org.andromda.metafacades.uml.ActivityGraphFacade;
import org.andromda.metafacades.uml.ActorFacade;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.FinalStateFacade;
import org.andromda.metafacades.uml.ModelFacade;
import org.andromda.metafacades.uml.ObjectFlowStateFacade;
import org.andromda.metafacades.uml.PackageFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.resource.UMLResource;

/**
 * Captures a view of a physical system. It is an abstraction of the physical system, with a certain
 * purpose. This purpose determines what is to be included in the model and what is irrelevant. Thus
 * the model completely describes those aspects of the physical system that are relevant to the
 * purpose of the model, at the appropriate level of detail. May be a UML2 model or package.
 * MetafacadeLogic for ModelFacade
 *
 * @see ModelFacade
 */
public abstract class ModelFacadeLogic
    extends MetafacadeBase
    implements ModelFacade
{
    /**
     * The underlying UML object
     * @see UMLResource
     */
    protected UMLResource metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ModelFacadeLogic(UMLResource metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ModelFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ModelFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ModelFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ModelFacade
     */
    public boolean isModelFacadeMetaType()
    {
        return true;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Return the UseCase belonging to this model with the tagged value or hyperlink.
     * @param tag
     * @param value
     * @return UseCaseFacade
     */
    protected abstract UseCaseFacade handleFindUseCaseWithTaggedValueOrHyperlink(String tag, String value);

    /**
     * Return the UseCase belonging to this model with the tagged value or hyperlink.
     * @param tag String
     * TODO: Model Documentation for
     * ModelFacade.findUseCaseWithTaggedValueOrHyperlink(tag)
     * @param value String
     * TODO: Model Documentation for
     * ModelFacade.findUseCaseWithTaggedValueOrHyperlink(value)
     * @return handleFindUseCaseWithTaggedValueOrHyperlink(tag, value)
     */
    public UseCaseFacade findUseCaseWithTaggedValueOrHyperlink(String tag, String value)
    {
        // findUseCaseWithTaggedValueOrHyperlink has no pre constraints
        UseCaseFacade returnValue = handleFindUseCaseWithTaggedValueOrHyperlink(tag, value);
        // findUseCaseWithTaggedValueOrHyperlink has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Return the Class belonging to this model with the tagged value or hyperlink.
     * @param tag
     * @param value
     * @return ClassifierFacade
     */
    protected abstract ClassifierFacade handleFindClassWithTaggedValueOrHyperlink(String tag, String value);

    /**
     * Return the Class belonging to this model with the tagged value or hyperlink.
     * @param tag String
     * TODO: Model Documentation for
     * ModelFacade.findClassWithTaggedValueOrHyperlink(tag)
     * @param value String
     * TODO: Model Documentation for
     * ModelFacade.findClassWithTaggedValueOrHyperlink(value)
     * @return handleFindClassWithTaggedValueOrHyperlink(tag, value)
     */
    public ClassifierFacade findClassWithTaggedValueOrHyperlink(String tag, String value)
    {
        // findClassWithTaggedValueOrHyperlink has no pre constraints
        ClassifierFacade returnValue = handleFindClassWithTaggedValueOrHyperlink(tag, value);
        // findClassWithTaggedValueOrHyperlink has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the ActivityGraph with the Name.
     * @param name
     * @return ActivityGraphFacade
     */
    protected abstract ActivityGraphFacade handleFindActivityGraphByName(String name);

    /**
     * Finds the ActivityGraph with the Name.
     * @param name String
     * TODO: Model Documentation for
     * ModelFacade.findActivityGraphByName(name)
     * @return handleFindActivityGraphByName(name)
     */
    public ActivityGraphFacade findActivityGraphByName(String name)
    {
        // findActivityGraphByName has no pre constraints
        ActivityGraphFacade returnValue = handleFindActivityGraphByName(name);
        // findActivityGraphByName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the ActivityGraph with the Name and Stereotype.
     * @param name
     * @param stereotypeName
     * @return ActivityGraphFacade
     */
    protected abstract ActivityGraphFacade handleFindActivityGraphByNameAndStereotype(String name, String stereotypeName);

    /**
     * Finds the ActivityGraph with the Name and Stereotype.
     * @param name String
     * TODO: Model Documentation for
     * ModelFacade.findActivityGraphByNameAndStereotype(name)
     * @param stereotypeName String
     * TODO: Model Documentation for
     * ModelFacade.findActivityGraphByNameAndStereotype(stereotypeName)
     * @return handleFindActivityGraphByNameAndStereotype(name, stereotypeName)
     */
    public ActivityGraphFacade findActivityGraphByNameAndStereotype(String name, String stereotypeName)
    {
        // findActivityGraphByNameAndStereotype has no pre constraints
        ActivityGraphFacade returnValue = handleFindActivityGraphByNameAndStereotype(name, stereotypeName);
        // findActivityGraphByNameAndStereotype has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the UseCase with the Name.
     * @param name
     * @return UseCaseFacade
     */
    protected abstract UseCaseFacade handleFindUseCaseByName(String name);

    /**
     * Finds the UseCase with the Name.
     * @param name String
     * TODO: Model Documentation for
     * ModelFacade.findUseCaseByName(name)
     * @return handleFindUseCaseByName(name)
     */
    public UseCaseFacade findUseCaseByName(String name)
    {
        // findUseCaseByName has no pre constraints
        UseCaseFacade returnValue = handleFindUseCaseByName(name);
        // findUseCaseByName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the UseGraph with the Name and Stereotype.
     * @param name
     * @param stereotypeName
     * @return UseCaseFacade
     */
    protected abstract UseCaseFacade handleFindUseCaseWithNameAndStereotype(String name, String stereotypeName);

    /**
     * Finds the UseGraph with the Name and Stereotype.
     * @param name String
     * TODO: Model Documentation for
     * ModelFacade.findUseCaseWithNameAndStereotype(name)
     * @param stereotypeName String
     * TODO: Model Documentation for
     * ModelFacade.findUseCaseWithNameAndStereotype(stereotypeName)
     * @return handleFindUseCaseWithNameAndStereotype(name, stereotypeName)
     */
    public UseCaseFacade findUseCaseWithNameAndStereotype(String name, String stereotypeName)
    {
        // findUseCaseWithNameAndStereotype has no pre constraints
        UseCaseFacade returnValue = handleFindUseCaseWithNameAndStereotype(name, stereotypeName);
        // findUseCaseWithNameAndStereotype has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds the FinalState with the Name or Hyperlink.
     * @param useCase
     * @return Collection<FinalStateFacade>
     */
    protected abstract Collection<FinalStateFacade> handleFindFinalStatesWithNameOrHyperlink(UseCaseFacade useCase);

    /**
     * Finds the FinalState with the Name or Hyperlink.
     * @param useCase UseCaseFacade
     * TODO: Model Documentation for
     * ModelFacade.findFinalStatesWithNameOrHyperlink(useCase)
     * @return handleFindFinalStatesWithNameOrHyperlink(useCase)
     */
    public Collection<FinalStateFacade> findFinalStatesWithNameOrHyperlink(UseCaseFacade useCase)
    {
        // findFinalStatesWithNameOrHyperlink has no pre constraints
        Collection<FinalStateFacade> returnValue = handleFindFinalStatesWithNameOrHyperlink(useCase);
        // findFinalStatesWithNameOrHyperlink has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Finds all ActionStates with the Stereotype.
     * @param activityGraph
     * @param stereotypeName
     * @return Collection<ActionStateFacade>
     */
    protected abstract Collection<ActionStateFacade> handleGetAllActionStatesWithStereotype(ActivityGraphFacade activityGraph, String stereotypeName);

    /**
     * Finds all ActionStates with the Stereotype.
     * @param activityGraph ActivityGraphFacade
     * TODO: Model Documentation for
     * ModelFacade.getAllActionStatesWithStereotype(activityGraph)
     * @param stereotypeName String
     * TODO: Model Documentation for
     * ModelFacade.getAllActionStatesWithStereotype(stereotypeName)
     * @return handleGetAllActionStatesWithStereotype(activityGraph, stereotypeName)
     */
    public Collection<ActionStateFacade> getAllActionStatesWithStereotype(ActivityGraphFacade activityGraph, String stereotypeName)
    {
        // getAllActionStatesWithStereotype has no pre constraints
        Collection<ActionStateFacade> returnValue = handleGetAllActionStatesWithStereotype(activityGraph, stereotypeName);
        // getAllActionStatesWithStereotype has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    private Collection<ClassifierFacade> __getAllClasses1r;
    private boolean __getAllClasses1rSet = false;

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<ClassifierFacade>)handleGetAllClasses()
     */
    public final Collection<ClassifierFacade> getAllClasses()
    {
        Collection<ClassifierFacade> getAllClasses1r = this.__getAllClasses1r;
        if (!this.__getAllClasses1rSet)
        {
            // modelFacade has no pre constraints
            Collection result = handleGetAllClasses();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllClasses1r = (Collection<ClassifierFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllClasses Collection<ClassifierFacade> " + result + ": " + shieldedResult);
            }
            // modelFacade has no post constraints
            this.__getAllClasses1r = getAllClasses1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllClasses1rSet = true;
            }
        }
        return getAllClasses1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllClasses();

    private Collection<TransitionFacade> __getAllTransitions2r;
    private boolean __getAllTransitions2rSet = false;

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<TransitionFacade>)handleGetAllTransitions()
     */
    public final Collection<TransitionFacade> getAllTransitions()
    {
        Collection<TransitionFacade> getAllTransitions2r = this.__getAllTransitions2r;
        if (!this.__getAllTransitions2rSet)
        {
            // modelFacade has no pre constraints
            Collection result = handleGetAllTransitions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllTransitions2r = (Collection<TransitionFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllTransitions Collection<TransitionFacade> " + result + ": " + shieldedResult);
            }
            // modelFacade has no post constraints
            this.__getAllTransitions2r = getAllTransitions2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllTransitions2rSet = true;
            }
        }
        return getAllTransitions2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllTransitions();

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<ActorFacade>)handleGetAllActors()
     */
    public final Collection<ActorFacade> getAllActors()
    {
        Collection<ActorFacade> getAllActors3r = null;
        // modelFacade has no pre constraints
        Collection result = handleGetAllActors();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllActors3r = (Collection<ActorFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllActors Collection<ActorFacade> " + result + ": " + shieldedResult);
        }
        // modelFacade has no post constraints
        return getAllActors3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllActors();

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<UseCaseFacade>)handleGetAllUseCases()
     */
    public final Collection<UseCaseFacade> getAllUseCases()
    {
        Collection<UseCaseFacade> getAllUseCases4r = null;
        // modelFacade has no pre constraints
        Collection result = handleGetAllUseCases();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllUseCases4r = (Collection<UseCaseFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllUseCases Collection<UseCaseFacade> " + result + ": " + shieldedResult);
        }
        // modelFacade has no post constraints
        return getAllUseCases4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllUseCases();

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<ActionStateFacade>)handleGetAllActionStates()
     */
    public final Collection<ActionStateFacade> getAllActionStates()
    {
        Collection<ActionStateFacade> getAllActionStates5r = null;
        // modelFacade has no pre constraints
        Collection result = handleGetAllActionStates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllActionStates5r = (Collection<ActionStateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllActionStates Collection<ActionStateFacade> " + result + ": " + shieldedResult);
        }
        // modelFacade has no post constraints
        return getAllActionStates5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllActionStates();

    private Collection<ObjectFlowStateFacade> __getAllObjectFlowStates6r;
    private boolean __getAllObjectFlowStates6rSet = false;

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (Collection<ObjectFlowStateFacade>)handleGetAllObjectFlowStates()
     */
    public final Collection<ObjectFlowStateFacade> getAllObjectFlowStates()
    {
        Collection<ObjectFlowStateFacade> getAllObjectFlowStates6r = this.__getAllObjectFlowStates6r;
        if (!this.__getAllObjectFlowStates6rSet)
        {
            // modelFacade has no pre constraints
            Collection result = handleGetAllObjectFlowStates();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllObjectFlowStates6r = (Collection<ObjectFlowStateFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getAllObjectFlowStates Collection<ObjectFlowStateFacade> " + result + ": " + shieldedResult);
            }
            // modelFacade has no post constraints
            this.__getAllObjectFlowStates6r = getAllObjectFlowStates6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllObjectFlowStates6rSet = true;
            }
        }
        return getAllObjectFlowStates6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllObjectFlowStates();

    /**
     * Captures a view of a physical system. It is an abstraction of the physical system, with a
     * certain
     * purpose. This purpose determines what is to be included in the model and what is irrelevant.
     * Thus
     * the model completely describes those aspects of the physical system that are relevant to the
     * purpose
     * of the model, at the appropriate level of detail. May be a UML2 model or package.
     * @return (PackageFacade)handleGetRootPackage()
     */
    public final PackageFacade getRootPackage()
    {
        PackageFacade getRootPackage7r = null;
        // modelFacade has no pre constraints
        Object result = handleGetRootPackage();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getRootPackage7r = (PackageFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelFacadeLogic.logger.warn("incorrect metafacade cast for ModelFacadeLogic.getRootPackage PackageFacade " + result + ": " + shieldedResult);
        }
        // modelFacade has no post constraints
        return getRootPackage7r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetRootPackage();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see MetafacadeBase#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
    }

    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    private static final String FQNAME_PROPERTY = "fullyQualifiedName";

    /**
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuilder toString = new StringBuilder(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(Introspector.instance().getProperty(this, FQNAME_PROPERTY));
        }
        catch (final Throwable tryAgain)
        {
            try
            {
                toString.append(Introspector.instance().getProperty(this, NAME_PROPERTY));
            }
            catch (final Throwable ignore)
            {
                // - just ignore when the metafacade doesn't have a name or fullyQualifiedName property
            }
        }
        toString.append("]");
        return toString.toString();
    }
}