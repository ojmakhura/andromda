// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import jakarta.validation.Valid;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.andromda.core.common.Introspector;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ConstraintFacade;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.ModelFacade;
import org.andromda.metafacades.uml.PackageFacade;
import org.andromda.metafacades.uml.StateMachineFacade;
import org.andromda.metafacades.uml.StereotypeFacade;
import org.andromda.metafacades.uml.TaggedValueFacade;
import org.andromda.metafacades.uml.TemplateParameterFacade;
import org.andromda.metafacades.uml.TypeMappings;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Element;

/**
 * Represents a model element. It may be an Element or NamedElement. A named element is an element
 * in a model that may have a name. An element is a constituent of a model. As such, it has the
 * capability of owning other elements.
 * MetafacadeLogic for ModelElementFacade
 *
 * @see ModelElementFacade
 */
public abstract class ModelElementFacadeLogic
    extends MetafacadeBase
    implements ModelElementFacade
{
    /**
     * The underlying UML object
     * @see Element
     */
    protected Element metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ModelElementFacadeLogic(Element metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ModelElementFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ModelElementFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ModelElementFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ModelElementFacade
     */
    public boolean isModelElementFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ModelElementFacade#getVisibility()
    * @return String
    */
    protected abstract String handleGetVisibility();

    /**
     * The visibility (i.e. public, private, protected or package) of the model element, will
     * attempt a lookup for these values in the language mappings (if any).
     * @return (String)handleGetVisibility()
     */
    public final String getVisibility()
    {
        String visibility1a = null;
        // visibility has no pre constraints
        visibility1a = handleGetVisibility();
        // visibility has no post constraints
        return visibility1a;
    }

   /**
    * @see ModelElementFacade#getPackagePath()
    * @return String
    */
    protected abstract String handleGetPackagePath();

    /**
     * Returns the package as a path, the returned value always starts with out a slash '/'.
     * @return (String)handleGetPackagePath()
     */
    public final String getPackagePath()
    {
        String packagePath2a = null;
        // packagePath has no pre constraints
        packagePath2a = handleGetPackagePath();
        // packagePath has no post constraints
        return packagePath2a;
    }

   /**
    * @see ModelElementFacade#getName()
    * @return String
    */
    protected abstract String handleGetName();

    /**
     * The name of the model element.
     * @return (String)handleGetName()
     */
    public final String getName()
    {
        String name3a = null;
        // name has no pre constraints
        name3a = handleGetName();
        // name has no post constraints
        return name3a;
    }

   /**
    * @see ModelElementFacade#getPackageName()
    * @return String
    */
    protected abstract String handleGetPackageName();

    /**
     * The name of this model element's package.
     * @return (String)handleGetPackageName()
     */
    public final String getPackageName()
    {
        String packageName4a = null;
        // packageName has no pre constraints
        packageName4a = handleGetPackageName();
        // packageName has no post constraints
        return packageName4a;
    }

   /**
    * @see ModelElementFacade#getFullyQualifiedName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedName();

    /**
     * The fully qualified name of this model element.
     * @return (String)handleGetFullyQualifiedName()
     */
    public final String getFullyQualifiedName()
    {
        String fullyQualifiedName5a = null;
        // fullyQualifiedName has no pre constraints
        fullyQualifiedName5a = handleGetFullyQualifiedName();
        // fullyQualifiedName has no post constraints
        return fullyQualifiedName5a;
    }

   /**
    * @see ModelElementFacade#getFullyQualifiedNamePath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedNamePath();

    /**
     * Returns the fully qualified name as a path, the returned value always starts with out a slash
     * '/'.
     * @return (String)handleGetFullyQualifiedNamePath()
     */
    public final String getFullyQualifiedNamePath()
    {
        String fullyQualifiedNamePath6a = null;
        // fullyQualifiedNamePath has no pre constraints
        fullyQualifiedNamePath6a = handleGetFullyQualifiedNamePath();
        // fullyQualifiedNamePath has no post constraints
        return fullyQualifiedNamePath6a;
    }

   /**
    * @see ModelElementFacade#getLanguageMappings()
    * @return TypeMappings
    */
    protected abstract TypeMappings handleGetLanguageMappings();

    /**
     * The language mappings that have been set for this model element.
     * @return (TypeMappings)handleGetLanguageMappings()
     */
    public final TypeMappings getLanguageMappings()
    {
        TypeMappings languageMappings7a = null;
        // languageMappings has no pre constraints
        languageMappings7a = handleGetLanguageMappings();
        // languageMappings has no post constraints
        return languageMappings7a;
    }

   /**
    * @see ModelElementFacade#getStereotypeNames()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetStereotypeNames();

    /**
     * The collection of ALL stereotype names for this model element.
     * @return (Set<String>)handleGetStereotypeNames()
     */
    public final Set<String> getStereotypeNames()
    {
        Set<String> stereotypeNames8a = null;
        // stereotypeNames has no pre constraints
        stereotypeNames8a = handleGetStereotypeNames();
        // stereotypeNames has no post constraints
        return stereotypeNames8a;
    }

   /**
    * @see ModelElementFacade#getId()
    * @return String
    */
    protected abstract String handleGetId();

    /**
     * Gets the unique identifier of the underlying model element.
     * @return (String)handleGetId()
     */
    public final String getId()
    {
        String id9a = null;
        // id has no pre constraints
        id9a = handleGetId();
        // id has no post constraints
        return id9a;
    }

   /**
    * @see ModelElementFacade#isConstraintsPresent()
    * @return boolean
    */
    protected abstract boolean handleIsConstraintsPresent();

    /**
     * Indicates if any constraints are present on this model element.
     * @return (boolean)handleIsConstraintsPresent()
     */
    public final boolean isConstraintsPresent()
    {
        boolean constraintsPresent10a = false;
        // constraintsPresent has no pre constraints
        constraintsPresent10a = handleIsConstraintsPresent();
        // constraintsPresent has no post constraints
        return constraintsPresent10a;
    }

   /**
    * @see ModelElementFacade#isBindingDependenciesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsBindingDependenciesPresent();

    /**
     * True if there are target dependencies from this element that are instances of BindingFacade.
     * Deprecated in UML2: Use TemplateBinding parameters instead of dependencies.
     * @return (boolean)handleIsBindingDependenciesPresent()
     */
    public final boolean isBindingDependenciesPresent()
    {
        boolean bindingDependenciesPresent11a = false;
        // bindingDependenciesPresent has no pre constraints
        bindingDependenciesPresent11a = handleIsBindingDependenciesPresent();
        // bindingDependenciesPresent has no post constraints
        return bindingDependenciesPresent11a;
    }

   /**
    * @see ModelElementFacade#isTemplateParametersPresent()
    * @return boolean
    */
    protected abstract boolean handleIsTemplateParametersPresent();

    /**
     * True is there are template parameters on this model element. For UML2, applies to Class,
     * Operation, Property, and Parameter.
     * @return (boolean)handleIsTemplateParametersPresent()
     */
    public final boolean isTemplateParametersPresent()
    {
        boolean templateParametersPresent12a = false;
        // templateParametersPresent has no pre constraints
        templateParametersPresent12a = handleIsTemplateParametersPresent();
        // templateParametersPresent has no post constraints
        return templateParametersPresent12a;
    }

   /**
    * @see ModelElementFacade#getKeywords()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetKeywords();

    /**
     * UML2: Retrieves the keywords for this element. Used to modify implementation properties which
     * are not represented by other properties, i.e. native, transient, volatile, synchronized,
     * (added annotations) override, deprecated. Can also be used to suppress compiler warnings:
     * (added annotations) unchecked, fallthrough, path, serial, finally, all. Annotations require
     * JDK5 compiler level.
     * @return (Set<String>)handleGetKeywords()
     */
    public final Set<String> getKeywords()
    {
        Set<String> keywords13a = null;
        // keywords has no pre constraints
        keywords13a = handleGetKeywords();
        // keywords has no post constraints
        return keywords13a;
    }

   /**
    * @see ModelElementFacade#getLabel()
    * @return String
    */
    protected abstract String handleGetLabel();

    /**
     * UML2: Retrieves a localized label for this named element.
     * @return (String)handleGetLabel()
     */
    public final String getLabel()
    {
        String label14a = null;
        // label has no pre constraints
        label14a = handleGetLabel();
        // label has no post constraints
        return label14a;
    }

   /**
    * @see ModelElementFacade#getQualifiedName()
    * @return String
    */
    protected abstract String handleGetQualifiedName();

    /**
     * UML2: Returns the value of the 'Qualified Name' attribute. A name which allows the
     * NamedElement to be identified within a hierarchy of nested Namespaces. It is constructed from
     * the names of the containing namespaces starting at the root of the hierarchy and ending with
     * the name of the NamedElement itself.
     * @return (String)handleGetQualifiedName()
     */
    public final String getQualifiedName()
    {
        String qualifiedName15a = null;
        // qualifiedName has no pre constraints
        qualifiedName15a = handleGetQualifiedName();
        // qualifiedName has no post constraints
        return qualifiedName15a;
    }

   /**
    * @see ModelElementFacade#isReservedWord()
    * @return boolean
    */
    protected abstract boolean handleIsReservedWord();

    /**
     * True if this element name is a reserved word in Java, C#, ANSI or ISO C, C++, JavaScript.
     * @return (boolean)handleIsReservedWord()
     */
    public final boolean isReservedWord()
    {
        boolean reservedWord16a = false;
        // reservedWord has no pre constraints
        reservedWord16a = handleIsReservedWord();
        // reservedWord has no post constraints
        return reservedWord16a;
    }

   /**
    * @see ModelElementFacade#isDocumentationPresent()
    * @return boolean
    */
    protected abstract boolean handleIsDocumentationPresent();

    /**
     * Indicates if any documentation is present on this model element.
     * @return (boolean)handleIsDocumentationPresent()
     */
    public final boolean isDocumentationPresent()
    {
        boolean documentationPresent17a = false;
        // documentationPresent has no pre constraints
        documentationPresent17a = handleIsDocumentationPresent();
        // documentationPresent has no post constraints
        return documentationPresent17a;
    }

   /**
    * @see ModelElementFacade#isValidIdentifierName()
    * @return boolean
    */
    protected abstract boolean handleIsValidIdentifierName();

    /**
     * True if this element name is a valid identifier name in Java, C#, ANSI or ISO C, C++,
     * JavaScript. Contains no spaces, special characters etc. Constraint always applied on
     * Enumerations and Interfaces, optionally applies on other model elements.
     * @return (boolean)handleIsValidIdentifierName()
     */
    public final boolean isValidIdentifierName()
    {
        boolean validIdentifierName18a = false;
        // validIdentifierName has no pre constraints
        validIdentifierName18a = handleIsValidIdentifierName();
        // validIdentifierName has no post constraints
        return validIdentifierName18a;
    }

   /**
    * @see ModelElementFacade#getAdditionalAnnotations()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetAdditionalAnnotations();

    /**
     * Extra annotations not covered by the normal AndroMDA features. The list of these annotations
     * should be separated by semi colons.
     * @return (Set<String>)handleGetAdditionalAnnotations()
     */
    public final Set<String> getAdditionalAnnotations()
    {
        Set<String> additionalAnnotations19a = null;
        // additionalAnnotations has no pre constraints
        additionalAnnotations19a = handleGetAdditionalAnnotations();
        // additionalAnnotations has no post constraints
        return additionalAnnotations19a;
    }

   /**
    * @see ModelElementFacade#getAdditionalExtends()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetAdditionalExtends();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.additionalExtends
     * @return (Set<String>)handleGetAdditionalExtends()
     */
    public final Set<String> getAdditionalExtends()
    {
        Set<String> additionalExtends20a = null;
        // additionalExtends has no pre constraints
        additionalExtends20a = handleGetAdditionalExtends();
        // additionalExtends has no post constraints
        return additionalExtends20a;
    }

   /**
    * @see ModelElementFacade#getAdditionalImplements()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetAdditionalImplements();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.additionalImplements
     * @return (Set<String>)handleGetAdditionalImplements()
     */
    public final Set<String> getAdditionalImplements()
    {
        Set<String> additionalImplements21a = null;
        // additionalImplements has no pre constraints
        additionalImplements21a = handleGetAdditionalImplements();
        // additionalImplements has no post constraints
        return additionalImplements21a;
    }

   /**
    * @see ModelElementFacade#isGeneric()
    * @return boolean
    */
    protected abstract boolean handleIsGeneric();

    /**
     * TODO: Model Documentation for ModelElementFacade.generic
     * @return (boolean)handleIsGeneric()
     */
    public final boolean isGeneric()
    {
        boolean generic22a = false;
        // generic has no pre constraints
        generic22a = handleIsGeneric();
        // generic has no post constraints
        return generic22a;
    }

   /**
    * @see ModelElementFacade#getGenericParameters()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetGenericParameters();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.genericParameters
     * @return (Set<String>)handleGetGenericParameters()
     */
    public final Set<String> getGenericParameters()
    {
        Set<String> genericParameters23a = null;
        // genericParameters has no pre constraints
        genericParameters23a = handleGetGenericParameters();
        // genericParameters has no post constraints
        return genericParameters23a;
    }

   /**
    * @see ModelElementFacade#getGenericTypes()
    * @return Set<String>
    */
    protected abstract Set<String> handleGetGenericTypes();

    /**
     * TODO: Model Documentation for ModelElementFacade.genericTypes
     * @return (Set<String>)handleGetGenericTypes()
     */
    public final Set<String> getGenericTypes()
    {
        Set<String> genericTypes24a = null;
        // genericTypes has no pre constraints
        genericTypes24a = handleGetGenericTypes();
        // genericTypes has no post constraints
        return genericTypes24a;
    }

   /**
    * @see ModelElementFacade#isGenericDeclaration()
    * @return boolean
    */
    protected abstract boolean handleIsGenericDeclaration();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.genericDeclaration
     * @return (boolean)handleIsGenericDeclaration()
     */
    public final boolean isGenericDeclaration()
    {
        boolean genericDeclaration25a = false;
        // genericDeclaration has no pre constraints
        genericDeclaration25a = handleIsGenericDeclaration();
        // genericDeclaration has no post constraints
        return genericDeclaration25a;
    }

   /**
    * @see ModelElementFacade#getGenericTypeString()
    * @return String
    */
    protected abstract String handleGetGenericTypeString();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.genericTypeString
     * @return (String)handleGetGenericTypeString()
     */
    public final String getGenericTypeString()
    {
        String genericTypeString26a = null;
        // genericTypeString has no pre constraints
        genericTypeString26a = handleGetGenericTypeString();
        // genericTypeString has no post constraints
        return genericTypeString26a;
    }

   /**
    * @see ModelElementFacade#getGenericParameterString()
    * @return String
    */
    protected abstract String handleGetGenericParameterString();

    /**
     * TODO: Model Documentation for
     * ModelElementFacade.genericParameterString
     * @return (String)handleGetGenericParameterString()
     */
    public final String getGenericParameterString()
    {
        String genericParameterString27a = null;
        // genericParameterString has no pre constraints
        genericParameterString27a = handleGetGenericParameterString();
        // genericParameterString has no post constraints
        return genericParameterString27a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Finds the tagged value with the specified 'tagName'. In case there are more values the first
     * one found will be returned.
     * @param tagName
     * @return Object
     */
    protected abstract Object handleFindTaggedValue(String tagName);

    /**
     * Finds the tagged value with the specified 'tagName'. In case there are more values the first
     * one found will be returned.
     * @param tagName String
     * TODO: Model Documentation for
     * ModelElementFacade.findTaggedValue(tagName)
     * @return handleFindTaggedValue(tagName)
     */
    public Object findTaggedValue(String tagName)
    {
        // findTaggedValue has no pre constraints
        Object returnValue = handleFindTaggedValue(tagName);
        // findTaggedValue has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns true if the model element has the specified stereotype.  If the stereotype itself
     * does not match, then a search will be made up the stereotype inheritance hierarchy, and if
     * one of the stereotype's ancestors has a matching name this method will return true, false
     * otherwise.
     * For example, if we have a certain stereotype called <<exception>> and a model element has a
     * stereotype called <<applicationException>> which extends <<exception>>, when calling this
     * method with 'stereotypeName' defined as 'exception' the method would return true since
     * <<applicationException>> inherits from <<exception>>.  If you want to check if the model
     * element has the exact stereotype, then use the method 'hasExactStereotype' instead.
     * @param stereotypeName
     * @return boolean
     */
    protected abstract boolean handleHasStereotype(String stereotypeName);

    /**
     * Returns true if the model element has the specified stereotype.  If the stereotype itself
     * does not match, then a search will be made up the stereotype inheritance hierarchy, and if
     * one of the stereotype's ancestors has a matching name this method will return true, false
     * otherwise.
     * For example, if we have a certain stereotype called <<exception>> and a model element has a
     * stereotype called <<applicationException>> which extends <<exception>>, when calling this
     * method with 'stereotypeName' defined as 'exception' the method would return true since
     * <<applicationException>> inherits from <<exception>>.  If you want to check if the model
     * element has the exact stereotype, then use the method 'hasExactStereotype' instead.
     * @param stereotypeName String
     * TODO: Model Documentation for
     * ModelElementFacade.hasStereotype(stereotypeName)
     * @return handleHasStereotype(stereotypeName)
     */
    public boolean hasStereotype(String stereotypeName)
    {
        // hasStereotype has no pre constraints
        boolean returnValue = handleHasStereotype(stereotypeName);
        // hasStereotype has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the documentation for the model element, The indent argument is prefixed to each line.
     * By default this method wraps lines after 64 characters.
     * This method is equivalent to <code>getDocumentation(indent, 64)</code>.
     * @param indent
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent);

    /**
     * Gets the documentation for the model element, The indent argument is prefixed to each line.
     * By default this method wraps lines after 64 characters.
     * This method is equivalent to <code>getDocumentation(indent, 64)</code>.
     * @param indent String
     * <p>Specifies the amount to indent by.</p>
     * @return handleGetDocumentation(indent)
     */
    public String getDocumentation(String indent)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent);
        // getDocumentation has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element.  If modelName is true, then
     * the original name of the model element (the name contained within the model) will be the name
     * returned, otherwise a name from a language mapping will be returned.
     * @param modelName
     * @return String
     */
    protected abstract String handleGetFullyQualifiedName(boolean modelName);

    /**
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element.  If modelName is true, then
     * the original name of the model element (the name contained within the model) will be the name
     * returned, otherwise a name from a language mapping will be returned.
     * @param modelName boolean
     * If true, then the original model name will be returned regardless of any underlying language
     * mappings used.
     * @return handleGetFullyQualifiedName(modelName)
     */
    public String getFullyQualifiedName(boolean modelName)
    {
        // getFullyQualifiedName has no pre constraints
        String returnValue = handleGetFullyQualifiedName(modelName);
        // getFullyQualifiedName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. By default paragraphs are returned as HTML.
     * This method is equivalent to <code>getDocumentation(indent, lineLength, true)</code>.
     * @param indent
     * @param lineLength
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent, int lineLength);

    /**
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. By default paragraphs are returned as HTML.
     * This method is equivalent to <code>getDocumentation(indent, lineLength, true)</code>.
     * @param indent String
     * TODO: Model Documentation for
     * ModelElementFacade.getDocumentation(indent)
     * @param lineLength int
     * TODO: Model Documentation for
     * ModelElementFacade.getDocumentation(lineLength)
     * @return handleGetDocumentation(indent, lineLength)
     */
    public String getDocumentation(String indent, int lineLength)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent, lineLength);
        // getDocumentation has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns true if the model element has the exact stereotype (meaning no stereotype inheritance
     * is taken into account when searching for the stereotype), false otherwise.
     * @param stereotypeName
     * @return boolean
     */
    protected abstract boolean handleHasExactStereotype(String stereotypeName);

    /**
     * Returns true if the model element has the exact stereotype (meaning no stereotype inheritance
     * is taken into account when searching for the stereotype), false otherwise.
     * @param stereotypeName String
     * The name of the stereotype to check for.
     * @return handleHasExactStereotype(stereotypeName)
     */
    public boolean hasExactStereotype(String stereotypeName)
    {
        // hasExactStereotype has no pre constraints
        boolean returnValue = handleHasExactStereotype(stereotypeName);
        // hasExactStereotype has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Searches for the constraint with the specified 'name' on this model element, and if found
     * translates it using the specified 'translation' from a translation library discovered by the
     * framework.
     * @param name
     * @param translation
     * @return String
     */
    protected abstract String handleTranslateConstraint(String name, String translation);

    /**
     * Searches for the constraint with the specified 'name' on this model element, and if found
     * translates it using the specified 'translation' from a translation library discovered by the
     * framework.
     * @param name String
     * The name of the constraint to find.
     * @param translation String
     * The name of the translation to use.  This must be a translation within a translation library
     * discovered by the framework.
     * @return handleTranslateConstraint(name, translation)
     */
    public String translateConstraint(String name, String translation)
    {
        // translateConstraint has no pre constraints
        String returnValue = handleTranslateConstraint(name, translation);
        // translateConstraint has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Translates the constraints of the specified 'kind' belonging to this model element.
     * @param kind
     * @param translation
     * @return String[]
     */
    protected abstract String[] handleTranslateConstraints(String kind, String translation);

    /**
     * Translates the constraints of the specified 'kind' belonging to this model element.
     * @param kind String
     * The 'kind' of the constraint (i.e. inv, body, pre, post, etc.).
     * @param translation String
     * The name of the translation to use.  This must be a translation within a translation library
     * discovered by the framework.
     * @return handleTranslateConstraints(kind, translation)
     */
    public String[] translateConstraints(String kind, String translation)
    {
        // translateConstraints has no pre constraints
        String[] returnValue = handleTranslateConstraints(kind, translation);
        // translateConstraints has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Translates all constraints belonging to this model element with the given 'translation'.
     * @param translation
     * @return String[]
     */
    protected abstract String[] handleTranslateConstraints(String translation);

    /**
     * Translates all constraints belonging to this model element with the given 'translation'.
     * @param translation String
     * The name of the translation to use.  This must be a translation within a translation library
     * discovered by the framework.
     * @return handleTranslateConstraints(translation)
     */
    public String[] translateConstraints(String translation)
    {
        // translateConstraints has no pre constraints
        String[] returnValue = handleTranslateConstraints(translation);
        // translateConstraints has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns the constraints of the argument kind that have been placed onto this model. Typical
     * kinds are "inv", "pre" and "post". Other kinds are possible.
     * @param kind
     * @return Collection<ConstraintFacade>
     */
    protected abstract Collection<ConstraintFacade> handleGetConstraints(String kind);

    /**
     * Returns the constraints of the argument kind that have been placed onto this model. Typical
     * kinds are "inv", "pre" and "post". Other kinds are possible.
     * @param kind String
     * TODO: Model Documentation for
     * ModelElementFacade.getConstraints(kind)
     * @return handleGetConstraints(kind)
     */
    public Collection<ConstraintFacade> getConstraints(String kind)
    {
        // getConstraints has no pre constraints
        Collection<ConstraintFacade> returnValue = handleGetConstraints(kind);
        // getConstraints has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns all the values for the tagged value with the specified name. The returned collection
     * will contains only String instances, or will be empty. Never null.
     * @param tagName
     * @return Collection<Object>
     */
    protected abstract Collection<Object> handleFindTaggedValues(String tagName);

    /**
     * Returns all the values for the tagged value with the specified name. The returned collection
     * will contains only String instances, or will be empty. Never null.
     * @param tagName String
     * TODO: Model Documentation for
     * ModelElementFacade.findTaggedValues(tagName)
     * @return handleFindTaggedValues(tagName)
     */
    public Collection<Object> findTaggedValues(String tagName)
    {
        // findTaggedValues has no pre constraints
        Collection<Object> returnValue = handleFindTaggedValues(tagName);
        // findTaggedValues has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. HTML style determines if HTML Escaping is applied.
     * @param indent
     * @param lineLength
     * @param htmlStyle
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent, int lineLength, boolean htmlStyle);

    /**
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. HTML style determines if HTML Escaping is applied.
     * @param indent String
     * TODO: Model Documentation for
     * ModelElementFacade.getDocumentation(indent)
     * @param lineLength int
     * TODO: Model Documentation for
     * ModelElementFacade.getDocumentation(lineLength)
     * @param htmlStyle boolean
     * TODO: Model Documentation for
     * ModelElementFacade.getDocumentation(htmlStyle)
     * @return handleGetDocumentation(indent, lineLength, htmlStyle)
     */
    public String getDocumentation(String indent, int lineLength, boolean htmlStyle)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent, lineLength, htmlStyle);
        // getDocumentation has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets the package name (optionally providing the ability to retrieve the model name and not
     * the mapped name).
     * @param modelName
     * @return String
     */
    protected abstract String handleGetPackageName(boolean modelName);

    /**
     * Gets the package name (optionally providing the ability to retrieve the model name and not
     * the mapped name).
     * @param modelName boolean
     * A flag indicating whether or not the model name should be retrieved.
     * @return handleGetPackageName(modelName)
     */
    public String getPackageName(boolean modelName)
    {
        // getPackageName has no pre constraints
        String returnValue = handleGetPackageName(modelName);
        // getPackageName has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Copies all tagged values from the given ModelElementFacade to this model element facade.
     * @param element
     */
    protected abstract void handleCopyTaggedValues(@Valid ModelElementFacade element);

    /**
     * Copies all tagged values from the given ModelElementFacade to this model element facade.
     * @param element ModelElementFacade
     * The element from which to copy the tagged values.
     */
    public void copyTaggedValues(@Valid ModelElementFacade element)
    {
        // copyTaggedValues has no pre constraints
        handleCopyTaggedValues(element);
        // copyTaggedValues has no post constraints
    }

    /**
     * Method to be implemented in descendants
     * Get the template parameter for this model element having the parameterName
     * @param parameterName
     * @return Object
     */
    protected abstract Object handleGetTemplateParameter(String parameterName);

    /**
     * Get the template parameter for this model element having the parameterName
     * @param parameterName String
     * TODO: Model Documentation for
     * ModelElementFacade.getTemplateParameter(parameterName)
     * @return handleGetTemplateParameter(parameterName)
     */
    public Object getTemplateParameter(String parameterName)
    {
        // getTemplateParameter has no pre constraints
        Object returnValue = handleGetTemplateParameter(parameterName);
        // getTemplateParameter has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Does the UML Element contain the named Keyword? Keywords can be separated by space, comma,
     * pipe, semicolon, or << >>
     * @param keywordName
     * @return boolean
     */
    protected abstract boolean handleHasKeyword(String keywordName);

    /**
     * Does the UML Element contain the named Keyword? Keywords can be separated by space, comma,
     * pipe, semicolon, or << >>
     * @param keywordName String
     * Keyword to find in the list of UML Element Keywords.
     * @return handleHasKeyword(keywordName)
     */
    public boolean hasKeyword(String keywordName)
    {
        // hasKeyword has no pre constraints
        boolean returnValue = handleHasKeyword(keywordName);
        // hasKeyword has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element. The templates parameter will
     * be replaced by the correct one given the binding relation of the parameter to this element.
     * @param bindedElement
     * @return String
     */
    protected abstract String handleGetBindedFullyQualifiedName(@Valid ModelElementFacade bindedElement);

    /**
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element. The templates parameter will
     * be replaced by the correct one given the binding relation of the parameter to this element.
     * @param bindedElement ModelElementFacade
     * the element that will be used to find binding to the templates parameters of this element.
     * @return handleGetBindedFullyQualifiedName(bindedElement)
     */
    public String getBindedFullyQualifiedName(@Valid ModelElementFacade bindedElement)
    {
        // getBindedFullyQualifiedName has no pre constraints
        String returnValue = handleGetBindedFullyQualifiedName(bindedElement);
        // getBindedFullyQualifiedName has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * The source element of this dependency.
     * @return (Collection<DependencyFacade>)handleGetSourceDependencies()
     */
    public final Collection<DependencyFacade> getSourceDependencies()
    {
        Collection<DependencyFacade> getSourceDependencies1r = null;
        // sourceElement has no pre constraints
         Collection result = handleGetSourceDependencies();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getSourceDependencies1r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getSourceDependencies Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // sourceElement has no post constraints
        return getSourceDependencies1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetSourceDependencies();

    /**
     * Gets the element to which the dependencies belong.
     * @return (Collection<DependencyFacade>)handleGetTargetDependencies()
     */
    public final Collection<DependencyFacade> getTargetDependencies()
    {
        Collection<DependencyFacade> getTargetDependencies2r = null;
        // targetElement has no pre constraints
         Collection result = handleGetTargetDependencies();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTargetDependencies2r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getTargetDependencies Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // targetElement has no post constraints
        return getTargetDependencies2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTargetDependencies();

    /**
     * Gets the model element to which the constraint applies (i.e. is the context of).
     * @return (Collection<ConstraintFacade>)handleGetConstraints()
     */
    public final Collection<ConstraintFacade> getConstraints()
    {
        Collection<ConstraintFacade> getConstraints3r = null;
        // contextElement has no pre constraints
         Collection result = handleGetConstraints();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getConstraints3r = (Collection<ConstraintFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getConstraints Collection<ConstraintFacade> " + result + ": " + shieldedResult);
        }
        // contextElement has no post constraints
        return getConstraints3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetConstraints();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (Collection<StereotypeFacade>)handleGetStereotypes()
     */
    public final Collection<StereotypeFacade> getStereotypes()
    {
        Collection<StereotypeFacade> getStereotypes4r = null;
        // modelElementFacade has no pre constraints
         Collection result = handleGetStereotypes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getStereotypes4r = (Collection<StereotypeFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getStereotypes Collection<StereotypeFacade> " + result + ": " + shieldedResult);
        }
        // modelElementFacade has no post constraints
        return getStereotypes4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetStereotypes();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (ModelFacade)handleGetModel()
     */
    public final ModelFacade getModel()
    {
        ModelFacade getModel5r = null;
        // modelElementFacade has no pre constraints
        Object result = handleGetModel();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getModel5r = (ModelFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getModel ModelFacade " + result + ": " + shieldedResult);
        }
        // modelElementFacade has no post constraints
        return getModel5r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetModel();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (Collection<TaggedValueFacade>)handleGetTaggedValues()
     */
    public final Collection<TaggedValueFacade> getTaggedValues()
    {
        Collection<TaggedValueFacade> getTaggedValues6r = null;
        // modelElementFacade has no pre constraints
         Collection result = handleGetTaggedValues();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTaggedValues6r = (Collection<TaggedValueFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getTaggedValues Collection<TaggedValueFacade> " + result + ": " + shieldedResult);
        }
        // modelElementFacade has no post constraints
        return getTaggedValues6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTaggedValues();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (StateMachineFacade)handleGetStateMachineContext()
     */
    public final StateMachineFacade getStateMachineContext()
    {
        StateMachineFacade getStateMachineContext7r = null;
        // contextElement has no pre constraints
        Object result = handleGetStateMachineContext();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getStateMachineContext7r = (StateMachineFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getStateMachineContext StateMachineFacade " + result + ": " + shieldedResult);
        }
        // contextElement has no post constraints
        return getStateMachineContext7r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetStateMachineContext();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (Collection<TemplateParameterFacade>)handleGetTemplateParameters()
     */
    public final Collection<TemplateParameterFacade> getTemplateParameters()
    {
        Collection<TemplateParameterFacade> getTemplateParameters8r = null;
        // modelElementFacade has no pre constraints
         Collection result = handleGetTemplateParameters();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTemplateParameters8r = (Collection<TemplateParameterFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getTemplateParameters Collection<TemplateParameterFacade> " + result + ": " + shieldedResult);
        }
        // modelElementFacade has no post constraints
        return getTemplateParameters8r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTemplateParameters();

    /**
     * Represents a model element. It may be an Element or NamedElement. A named element is an
     * element in a
     * model that may have a name. An element is a constituent of a model. As such, it has the
     * capability
     * of owning other elements.
     * @return (ModelElementFacade)handleGetPackage()
     */
    public final ModelElementFacade getPackage()
    {
        ModelElementFacade getPackage9r = null;
        // modelElementFacade has no pre constraints
        Object result = handleGetPackage();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getPackage9r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getPackage ModelElementFacade " + result + ": " + shieldedResult);
        }
        // modelElementFacade has no post constraints
        return getPackage9r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetPackage();

    /**
     * Gets all the model elements belonging to the root package.
     * @return (PackageFacade)handleGetRootPackage()
     */
    public final PackageFacade getRootPackage()
    {
        PackageFacade getRootPackage10r = null;
        // modelElements has no pre constraints
        Object result = handleGetRootPackage();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getRootPackage10r = (PackageFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ModelElementFacadeLogic.logger.warn("incorrect metafacade cast for ModelElementFacadeLogic.getRootPackage PackageFacade " + result + ": " + shieldedResult);
        }
        // modelElements has no post constraints
        return getRootPackage10r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetRootPackage();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see MetafacadeBase#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
    }

    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    private static final String FQNAME_PROPERTY = "fullyQualifiedName";

    /**
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuilder toString = new StringBuilder(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(Introspector.instance().getProperty(this, FQNAME_PROPERTY));
        }
        catch (final Throwable tryAgain)
        {
            try
            {
                toString.append(Introspector.instance().getProperty(this, NAME_PROPERTY));
            }
            catch (final Throwable ignore)
            {
                // - just ignore when the metafacade doesn't have a name or fullyQualifiedName property
            }
        }
        toString.append("]");
        return toString.toString();
    }
}