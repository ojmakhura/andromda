// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.EntityQueryOperation;
import org.eclipse.uml2.uml.Operation;

/**
 * Represents a persistent entity finder method.
 * MetafacadeLogic for EntityQueryOperation
 *
 * @see EntityQueryOperation
 */
public abstract class EntityQueryOperationLogic
    extends OperationFacadeLogicImpl
    implements EntityQueryOperation
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected EntityQueryOperationLogic(Object metaObjectIn, String context)
    {
        super((Operation)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to EntityQueryOperation if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityQueryOperation";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see EntityQueryOperation
     */
    public boolean isEntityQueryOperationMetaType()
    {
        return true;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * The query string for this EntityFinderMethod.  The query returned is based on the
     * 'translation' passed in.  The translation must be one available to AndroMDA found with a
     * translation-library.
     * @param translation
     * @return String
     */
    protected abstract String handleGetQuery(String translation);

    /**
     * The query string for this EntityFinderMethod.  The query returned is based on the
     * 'translation' passed in.  The translation must be one available to AndroMDA found with a
     * translation-library.
     * @param translation String
     * TODO: Model Documentation for
     * EntityQueryOperation.getQuery(translation)
     * @return handleGetQuery(translation)
     */
    public String getQuery(String translation)
    {
        // getQuery has no pre constraints
        String returnValue = handleGetQuery(translation);
        // getQuery has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see OperationFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}