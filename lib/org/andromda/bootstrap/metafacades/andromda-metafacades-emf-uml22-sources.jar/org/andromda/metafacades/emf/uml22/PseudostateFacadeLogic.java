// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.PseudostateFacade;
import org.eclipse.uml2.uml.Pseudostate;

/**
 * An abstraction that encompasses different types of transient vertices in the state machine graph.
 * MetafacadeLogic for PseudostateFacade
 *
 * @see PseudostateFacade
 */
public abstract class PseudostateFacadeLogic
    extends StateVertexFacadeLogicImpl
    implements PseudostateFacade
{
    /**
     * The underlying UML object
     * @see Pseudostate
     */
    protected Pseudostate metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected PseudostateFacadeLogic(Pseudostate metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to PseudostateFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PseudostateFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see PseudostateFacade
     */
    public boolean isPseudostateFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see PseudostateFacade#isChoice()
    * @return boolean
    */
    protected abstract boolean handleIsChoice();

    /**
     * TODO: Model Documentation for PseudostateFacade.choice
     * @return (boolean)handleIsChoice()
     */
    public final boolean isChoice()
    {
        boolean choice1a = false;
        // choice has no pre constraints
        choice1a = handleIsChoice();
        // choice has no post constraints
        return choice1a;
    }

   /**
    * @see PseudostateFacade#isDecisionPoint()
    * @return boolean
    */
    protected abstract boolean handleIsDecisionPoint();

    /**
     * TODO: Model Documentation for PseudostateFacade.decisionPoint
     * @return (boolean)handleIsDecisionPoint()
     */
    public final boolean isDecisionPoint()
    {
        boolean decisionPoint2a = false;
        // decisionPoint has no pre constraints
        decisionPoint2a = handleIsDecisionPoint();
        // decisionPoint has no post constraints
        return decisionPoint2a;
    }

   /**
    * @see PseudostateFacade#isDeepHistory()
    * @return boolean
    */
    protected abstract boolean handleIsDeepHistory();

    /**
     * TODO: Model Documentation for PseudostateFacade.deepHistory
     * @return (boolean)handleIsDeepHistory()
     */
    public final boolean isDeepHistory()
    {
        boolean deepHistory3a = false;
        // deepHistory has no pre constraints
        deepHistory3a = handleIsDeepHistory();
        // deepHistory has no post constraints
        return deepHistory3a;
    }

   /**
    * @see PseudostateFacade#isFork()
    * @return boolean
    */
    protected abstract boolean handleIsFork();

    /**
     * TODO: Model Documentation for PseudostateFacade.fork
     * @return (boolean)handleIsFork()
     */
    public final boolean isFork()
    {
        boolean fork4a = false;
        // fork has no pre constraints
        fork4a = handleIsFork();
        // fork has no post constraints
        return fork4a;
    }

   /**
    * @see PseudostateFacade#isInitialState()
    * @return boolean
    */
    protected abstract boolean handleIsInitialState();

    /**
     * TODO: Model Documentation for PseudostateFacade.initialState
     * @return (boolean)handleIsInitialState()
     */
    public final boolean isInitialState()
    {
        boolean initialState5a = false;
        // initialState has no pre constraints
        initialState5a = handleIsInitialState();
        // initialState has no post constraints
        return initialState5a;
    }

   /**
    * @see PseudostateFacade#isJoin()
    * @return boolean
    */
    protected abstract boolean handleIsJoin();

    /**
     * TODO: Model Documentation for PseudostateFacade.join
     * @return (boolean)handleIsJoin()
     */
    public final boolean isJoin()
    {
        boolean join6a = false;
        // join has no pre constraints
        join6a = handleIsJoin();
        // join has no post constraints
        return join6a;
    }

   /**
    * @see PseudostateFacade#isJunction()
    * @return boolean
    */
    protected abstract boolean handleIsJunction();

    /**
     * TODO: Model Documentation for PseudostateFacade.junction
     * @return (boolean)handleIsJunction()
     */
    public final boolean isJunction()
    {
        boolean junction7a = false;
        // junction has no pre constraints
        junction7a = handleIsJunction();
        // junction has no post constraints
        return junction7a;
    }

   /**
    * @see PseudostateFacade#isMergePoint()
    * @return boolean
    */
    protected abstract boolean handleIsMergePoint();

    /**
     * TODO: Model Documentation for PseudostateFacade.mergePoint
     * @return (boolean)handleIsMergePoint()
     */
    public final boolean isMergePoint()
    {
        boolean mergePoint8a = false;
        // mergePoint has no pre constraints
        mergePoint8a = handleIsMergePoint();
        // mergePoint has no post constraints
        return mergePoint8a;
    }

   /**
    * @see PseudostateFacade#isShallowHistory()
    * @return boolean
    */
    protected abstract boolean handleIsShallowHistory();

    /**
     * TODO: Model Documentation for PseudostateFacade.shallowHistory
     * @return (boolean)handleIsShallowHistory()
     */
    public final boolean isShallowHistory()
    {
        boolean shallowHistory9a = false;
        // shallowHistory has no pre constraints
        shallowHistory9a = handleIsShallowHistory();
        // shallowHistory has no post constraints
        return shallowHistory9a;
    }

   /**
    * @see PseudostateFacade#isSplit()
    * @return boolean
    */
    protected abstract boolean handleIsSplit();

    /**
     * Denotes this pseudostate to be either a join or a fork with a single incoming transition and
     * more than one outgoing transition.
     * @return (boolean)handleIsSplit()
     */
    public final boolean isSplit()
    {
        boolean split10a = false;
        // split has no pre constraints
        split10a = handleIsSplit();
        // split has no post constraints
        return split10a;
    }

   /**
    * @see PseudostateFacade#isCollect()
    * @return boolean
    */
    protected abstract boolean handleIsCollect();

    /**
     * Denotes this pseudostate to be either a join or a fork with a single outgoing transition and
     * more than one incoming transition.
     * @return (boolean)handleIsCollect()
     */
    public final boolean isCollect()
    {
        boolean collect11a = false;
        // collect has no pre constraints
        collect11a = handleIsCollect();
        // collect has no post constraints
        return collect11a;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateVertexFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}