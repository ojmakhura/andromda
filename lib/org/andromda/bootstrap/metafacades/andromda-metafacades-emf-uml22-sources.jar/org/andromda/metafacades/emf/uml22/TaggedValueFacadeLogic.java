// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.TaggedValueFacade;

/**
 * UML2 Stereotype attribute, UML14 TaggedValue.
 * MetafacadeLogic for TaggedValueFacade
 *
 * @see TaggedValueFacade
 */
public abstract class TaggedValueFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements TaggedValueFacade
{
    /**
     * The underlying UML object
     * @see TagDefinition
     */
    protected TagDefinition metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected TaggedValueFacadeLogic(TagDefinition metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to TaggedValueFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TaggedValueFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see TaggedValueFacade
     */
    public boolean isTaggedValueFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see TaggedValueFacade#getValue()
    * @return Object
    */
    protected abstract Object handleGetValue();

    /**
     * The first value for this tagged value.
     * @return (Object)handleGetValue()
     */
    public final Object getValue()
    {
        Object value1a = null;
        // value has no pre constraints
        value1a = handleGetValue();
        // value has no post constraints
        return value1a;
    }

   /**
    * @see TaggedValueFacade#getValues()
    * @return Collection<Object>
    */
    protected abstract Collection<Object> handleGetValues();

    /**
     * The collection of values for this tagged value.
     * @return (Collection<Object>)handleGetValues()
     */
    public final Collection<Object> getValues()
    {
        Collection<Object> values2a = null;
        // values has no pre constraints
        values2a = handleGetValues();
        // values has no post constraints
        return values2a;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}