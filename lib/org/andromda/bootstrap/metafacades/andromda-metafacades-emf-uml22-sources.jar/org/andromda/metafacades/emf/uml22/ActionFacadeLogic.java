// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActionFacade;
import org.andromda.metafacades.uml.ActionStateFacade;
import org.andromda.metafacades.uml.TransitionFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Action;

/**
 * An action is a named element that is the fundamental unit of executable functionality. The
 * execution of an action represents some transformation or processing in the modeled system, be it
 * a computer system or otherwise. An action represents a single step within an activity, that is,
 * one that is not further decomposed within the activity. An action has pre- and post-conditions.
 * MetafacadeLogic for ActionFacade
 *
 * @see ActionFacade
 */
public abstract class ActionFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements ActionFacade
{
    /**
     * The underlying UML object
     * @see Action
     */
    protected Action metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ActionFacadeLogic(Action metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ActionFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ActionFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActionFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ActionFacade
     */
    public boolean isActionFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private ActionStateFacade __getActionState1r;
    private boolean __getActionState1rSet = false;

    /**
     * The entry action for this action state (if any).
     * @return (ActionStateFacade)handleGetActionState()
     */
    public final ActionStateFacade getActionState()
    {
        ActionStateFacade getActionState1r = this.__getActionState1r;
        if (!this.__getActionState1rSet)
        {
            // entry has no pre constraints
            Object result = handleGetActionState();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getActionState1r = (ActionStateFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ActionFacadeLogic.logger.warn("incorrect metafacade cast for ActionFacadeLogic.getActionState ActionStateFacade " + result + ": " + shieldedResult);
            }
            // entry has no post constraints
            this.__getActionState1r = getActionState1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActionState1rSet = true;
            }
        }
        return getActionState1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetActionState();

    /**
     * An action is a named element that is the fundamental unit of executable functionality. The
     * execution
     * of an action represents some transformation or processing in the modeled system, be it a
     * computer
     * system or otherwise. An action represents a single step within an activity, that is, one that
     * is not
     * further decomposed within the activity. An action has pre- and post-conditions.
     * @return (TransitionFacade)handleGetTransition()
     */
    public final TransitionFacade getTransition()
    {
        TransitionFacade getTransition2r = null;
        // effect has no pre constraints
        Object result = handleGetTransition();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTransition2r = (TransitionFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ActionFacadeLogic.logger.warn("incorrect metafacade cast for ActionFacadeLogic.getTransition TransitionFacade " + result + ": " + shieldedResult);
        }
        // effect has no post constraints
        return getTransition2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTransition();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}