// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ExtensionPointFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.ExtensionPoint;

/**
 * Identifies a point in the behavior of a use case where that behavior can be extended by the
 * behavior of some other (extending) use case, as specified by an extend relationship.
 * MetafacadeLogic for ExtensionPointFacade
 *
 * @see ExtensionPointFacade
 */
public abstract class ExtensionPointFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements ExtensionPointFacade
{
    /**
     * The underlying UML object
     * @see ExtensionPoint
     */
    protected ExtensionPoint metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ExtensionPointFacadeLogic(ExtensionPoint metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ExtensionPointFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ExtensionPointFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ExtensionPointFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ExtensionPointFacade
     */
    public boolean isExtensionPointFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private UseCaseFacade __getUseCase1r;
    private boolean __getUseCase1rSet = false;

    /**
     * The extension points related to this use-case.
     * @return (UseCaseFacade)handleGetUseCase()
     */
    public final UseCaseFacade getUseCase()
    {
        UseCaseFacade getUseCase1r = this.__getUseCase1r;
        if (!this.__getUseCase1rSet)
        {
            // extensionPoints has no pre constraints
            Object result = handleGetUseCase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getUseCase1r = (UseCaseFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ExtensionPointFacadeLogic.logger.warn("incorrect metafacade cast for ExtensionPointFacadeLogic.getUseCase UseCaseFacade " + result + ": " + shieldedResult);
            }
            // extensionPoints has no post constraints
            this.__getUseCase1r = getUseCase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase1rSet = true;
            }
        }
        return getUseCase1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetUseCase();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}