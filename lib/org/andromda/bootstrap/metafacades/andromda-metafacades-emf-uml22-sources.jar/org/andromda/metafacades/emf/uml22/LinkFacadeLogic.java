// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.LinkEndFacade;
import org.andromda.metafacades.uml.LinkFacade;
import org.apache.log4j.Logger;

/**
 * A representation of the model object 'Instance Specification'. Represents an instance in a
 * modeled system. Has the capability of being a deployment target in a deployment relationship, in
 * the case that it is an instance of a node. Has the capability of being a deployed artifact, if it
 * is an instance of an artifact.
 * MetafacadeLogic for LinkFacade
 *
 * @see LinkFacade
 */
public abstract class LinkFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements LinkFacade
{
    /**
     * The underlying UML object
     * @see LinkInstance
     */
    protected LinkInstance metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected LinkFacadeLogic(LinkInstance metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(LinkFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to LinkFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.LinkFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see LinkFacade
     */
    public boolean isLinkFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<LinkEndFacade> __getLinkEnds1r;
    private boolean __getLinkEnds1rSet = false;

    /**
     * The link owning this link end.
     * @return (Collection<LinkEndFacade>)handleGetLinkEnds()
     */
    public final Collection<LinkEndFacade> getLinkEnds()
    {
        Collection<LinkEndFacade> getLinkEnds1r = this.__getLinkEnds1r;
        if (!this.__getLinkEnds1rSet)
        {
            // link has no pre constraints
             Collection result = handleGetLinkEnds();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getLinkEnds1r = (Collection<LinkEndFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                LinkFacadeLogic.logger.warn("incorrect metafacade cast for LinkFacadeLogic.getLinkEnds Collection<LinkEndFacade> " + result + ": " + shieldedResult);
            }
            // link has no post constraints
            this.__getLinkEnds1r = getLinkEnds1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLinkEnds1rSet = true;
            }
        }
        return getLinkEnds1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetLinkEnds();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}