// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.InteractionFacade;
import org.eclipse.uml2.uml.Element;

/**
 * An interaction is a unit of behavior that focuses on the observable exchange of information
 * between connectable elements.
 * MetafacadeLogic for InteractionFacade
 *
 * @see InteractionFacade
 */
public abstract class InteractionFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements InteractionFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected InteractionFacadeLogic(Object metaObjectIn, String context)
    {
        super((Element)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to InteractionFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.InteractionFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see InteractionFacade
     */
    public boolean isInteractionFacadeMetaType()
    {
        return true;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}