// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FinalStateFacade;
import org.eclipse.uml2.uml.FinalState;

/**
 * A special kind of state signifying that the enclosing region is completed. If the enclosing
 * region is directly contained in a state machine and all other regions in the state machine also
 * are completed, then it means that the entire state machine is completed.
 * MetafacadeLogic for FinalStateFacade
 *
 * @see FinalStateFacade
 */
public abstract class FinalStateFacadeLogic
    extends StateFacadeLogicImpl
    implements FinalStateFacade
{
    /**
     * The underlying UML object
     * @see FinalState
     */
    protected FinalState metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FinalStateFacadeLogic(FinalState metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FinalStateFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FinalStateFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FinalStateFacade
     */
    public boolean isFinalStateFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}