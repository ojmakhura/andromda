// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActivityGraphFacade;
import org.andromda.metafacades.uml.PartitionFacade;
import org.andromda.metafacades.uml.StateVertexFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Region;

/**
 * A representation of the model object 'Region'. An orthogonal part of either a composite state or
 * a state machine. It contains states and transitions.
 * MetafacadeLogic for PartitionFacade
 *
 * @see PartitionFacade
 */
public abstract class PartitionFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements PartitionFacade
{
    /**
     * The underlying UML object
     * @see Region
     */
    protected Region metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected PartitionFacadeLogic(Region metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(PartitionFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to PartitionFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PartitionFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see PartitionFacade
     */
    public boolean isPartitionFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<StateVertexFacade> __getVertices1r;
    private boolean __getVertices1rSet = false;

    /**
     * The partition (if any) to which this vertex belongs.
     * @return (Collection<StateVertexFacade>)handleGetVertices()
     */
    public final Collection<StateVertexFacade> getVertices()
    {
        Collection<StateVertexFacade> getVertices1r = this.__getVertices1r;
        if (!this.__getVertices1rSet)
        {
            // partition has no pre constraints
            Collection result = handleGetVertices();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getVertices1r = (Collection<StateVertexFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                PartitionFacadeLogic.logger.warn("incorrect metafacade cast for PartitionFacadeLogic.getVertices Collection<StateVertexFacade> " + result + ": " + shieldedResult);
            }
            // partition has no post constraints
            this.__getVertices1r = getVertices1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getVertices1rSet = true;
            }
        }
        return getVertices1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetVertices();

    /**
     * The set of partitions contained in this activity graph. Partitions are also known as
     * swimlanes in UML.
     * @return (ActivityGraphFacade)handleGetActivityGraph()
     */
    public final ActivityGraphFacade getActivityGraph()
    {
        ActivityGraphFacade getActivityGraph2r = null;
        // partitions has no pre constraints
        Object result = handleGetActivityGraph();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getActivityGraph2r = (ActivityGraphFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            PartitionFacadeLogic.logger.warn("incorrect metafacade cast for PartitionFacadeLogic.getActivityGraph ActivityGraphFacade " + result + ": " + shieldedResult);
        }
        // partitions has no post constraints
        return getActivityGraph2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetActivityGraph();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}