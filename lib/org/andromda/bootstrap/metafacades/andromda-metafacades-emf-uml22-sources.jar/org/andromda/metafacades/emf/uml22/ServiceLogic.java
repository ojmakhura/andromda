// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.Destination;
import org.andromda.metafacades.uml.Role;
import org.andromda.metafacades.uml.Service;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * Represents a service.
 * MetafacadeLogic for Service
 *
 * @see Service
 */
public abstract class ServiceLogic
    extends ClassifierFacadeLogicImpl
    implements Service
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ServiceLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ServiceLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to Service if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Service";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see Service
     */
    public boolean isServiceMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * Represents a service.
     * @return (Collection<DependencyFacade>)handleGetServiceReferences()
     */
    public final Collection<DependencyFacade> getServiceReferences()
    {
        Collection<DependencyFacade> getServiceReferences1r = null;
        // service has no pre constraints
         Collection result = handleGetServiceReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getServiceReferences1r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getServiceReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getServiceReferences1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetServiceReferences();

    /**
     * Represents a service.
     * @return (Collection<DependencyFacade>)handleGetAllServiceReferences()
     */
    public final Collection<DependencyFacade> getAllServiceReferences()
    {
        Collection<DependencyFacade> getAllServiceReferences2r = null;
        // service has no pre constraints
         Collection result = handleGetAllServiceReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllServiceReferences2r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getAllServiceReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getAllServiceReferences2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllServiceReferences();

    /**
     * Represents a service.
     * @return (Collection<Destination>)handleGetAllMessagingDestinations()
     */
    public final Collection<Destination> getAllMessagingDestinations()
    {
        Collection<Destination> getAllMessagingDestinations3r = null;
        // service has no pre constraints
         Collection result = handleGetAllMessagingDestinations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllMessagingDestinations3r = (Collection<Destination>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getAllMessagingDestinations Collection<Destination> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getAllMessagingDestinations3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllMessagingDestinations();

    /**
     * Represents a service.
     * @return (Collection<Destination>)handleGetMessagingDestinations()
     */
    public final Collection<Destination> getMessagingDestinations()
    {
        Collection<Destination> getMessagingDestinations4r = null;
        // service has no pre constraints
         Collection result = handleGetMessagingDestinations();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getMessagingDestinations4r = (Collection<Destination>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getMessagingDestinations Collection<Destination> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getMessagingDestinations4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetMessagingDestinations();

    /**
     * Represents a service.
     * @return (Collection<DependencyFacade>)handleGetEntityReferences()
     */
    public final Collection<DependencyFacade> getEntityReferences()
    {
        Collection<DependencyFacade> getEntityReferences5r = null;
        // service has no pre constraints
         Collection result = handleGetEntityReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getEntityReferences5r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getEntityReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getEntityReferences5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetEntityReferences();

    /**
     * Represents a service.
     * @return (Collection<Role>)handleGetAllRoles()
     */
    public final Collection<Role> getAllRoles()
    {
        Collection<Role> getAllRoles6r = null;
        // service has no pre constraints
         Collection result = handleGetAllRoles();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllRoles6r = (Collection<Role>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getAllRoles Collection<Role> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getAllRoles6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllRoles();

    /**
     * Represents a service.
     * @return (Collection<DependencyFacade>)handleGetAllEntityReferences()
     */
    public final Collection<DependencyFacade> getAllEntityReferences()
    {
        Collection<DependencyFacade> getAllEntityReferences7r = null;
        // service has no pre constraints
         Collection result = handleGetAllEntityReferences();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getAllEntityReferences7r = (Collection<DependencyFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getAllEntityReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getAllEntityReferences7r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllEntityReferences();

    /**
     * Represents a service.
     * @return (Collection<Role>)handleGetRoles()
     */
    public final Collection<Role> getRoles()
    {
        Collection<Role> getRoles8r = null;
        // service has no pre constraints
         Collection result = handleGetRoles();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getRoles8r = (Collection<Role>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ServiceLogic.logger.warn("incorrect metafacade cast for ServiceLogic.getRoles Collection<Role> " + result + ": " + shieldedResult);
        }
        // service has no post constraints
        return getRoles8r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetRoles();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::Service::a service can only generalize another service</p>
     * <p><b>Error:</b> A service can only generalize another service.</p>
     * <p><b>OCL:</b> context Service 
inv : generalization -> notEmpty() implies generalization.oclIsKindOf(Service)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::Service::services can only specialize other service</p>
     * <p><b>Error:</b> A service can only specialize another service.</p>
     * <p><b>OCL:</b> context ServiceFacade inv : specializations -> notEmpty() implies specializations -> forAll(oclIsKindOf(Service))</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"generalization")))).booleanValue()?OCLIntrospector.invoke(contextElement,"generalization") instanceof Service:true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::Service::a service can only generalize another service",
                        "A service can only generalize another service."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::Service::a service can only generalize another service' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"specializations")))).booleanValue()?OCLCollections.forAll(OCLIntrospector.invoke(contextElement,"specializations"),new Predicate(){public boolean evaluate(Object object){return Boolean.valueOf(String.valueOf(object instanceof Service)).booleanValue();}}):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::Service::services can only specialize other service",
                        "A service can only specialize another service."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::Service::services can only specialize other service' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}