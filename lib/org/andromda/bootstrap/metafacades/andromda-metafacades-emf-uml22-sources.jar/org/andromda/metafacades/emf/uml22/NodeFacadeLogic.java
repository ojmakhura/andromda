// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.NodeFacade;
import org.eclipse.uml2.uml.Node;

/**
 * A computational resource upon which artifacts may be deployed for execution. Nodes can be
 * interconnected through communication paths to define network structures.
 * MetafacadeLogic for NodeFacade
 *
 * @see NodeFacade
 */
public abstract class NodeFacadeLogic
    extends ClassifierFacadeLogicImpl
    implements NodeFacade
{
    /**
     * The underlying UML object
     * @see Node
     */
    protected Node metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected NodeFacadeLogic(Node metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to NodeFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.NodeFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see NodeFacade
     */
    public boolean isNodeFacadeMetaType()
    {
        return true;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}