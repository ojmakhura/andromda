// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ObjectFlowStateFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.State;

/**
 * A representation of the model object 'Object Flow'. An object flow is an activity edge that can
 * have objects or data passing along it. Object flows have support for multicast/receive, token
 * selection from object nodes, and transformation of tokens. Not implemented in UML2.
 * MetafacadeLogic for ObjectFlowStateFacade
 *
 * @see ObjectFlowStateFacade
 */
public abstract class ObjectFlowStateFacadeLogic
    extends StateFacadeLogicImpl
    implements ObjectFlowStateFacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ObjectFlowStateFacadeLogic(Object metaObjectIn, String context)
    {
        super((State)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ObjectFlowStateFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ObjectFlowStateFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ObjectFlowStateFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ObjectFlowStateFacade
     */
    public boolean isObjectFlowStateFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Object Flow'. An object flow is an activity edge that
     * can have
     * objects or data passing along it. Object flows have support for multicast/receive, token
     * selection
     * from object nodes, and transformation of tokens. Not implemented in UML2.
     * @return (ClassifierFacade)handleGetType()
     */
    public final ClassifierFacade getType()
    {
        ClassifierFacade getType1r = null;
        // objectFlowStateFacade has no pre constraints
        Object result = handleGetType();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getType1r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ObjectFlowStateFacadeLogic.logger.warn("incorrect metafacade cast for ObjectFlowStateFacadeLogic.getType ClassifierFacade " + result + ": " + shieldedResult);
        }
        // objectFlowStateFacade has no post constraints
        return getType1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetType();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}