// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.DirectedRelationship;

/**
 * A representation of the model object 'Directed Relationship'.Represents a relationship between a
 * collection of source model elements and a collection of target model elements, a
 * dependency/reference.
 * MetafacadeLogic for DependencyFacade
 *
 * @see DependencyFacade
 */
public abstract class DependencyFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements DependencyFacade
{
    /**
     * The underlying UML object
     * @see DirectedRelationship
     */
    protected DirectedRelationship metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected DependencyFacadeLogic(DirectedRelationship metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(DependencyFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to DependencyFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.DependencyFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see DependencyFacade
     */
    public boolean isDependencyFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see DependencyFacade#getGetterName()
    * @return String
    */
    protected abstract String handleGetGetterName();

    /**
     * The "getter" name for this dependency.
     * @return (String)handleGetGetterName()
     */
    public final String getGetterName()
    {
        String getterName1a = null;
        // getterName has no pre constraints
        getterName1a = handleGetGetterName();
        // getterName has no post constraints
        return getterName1a;
    }

   /**
    * @see DependencyFacade#getSetterName()
    * @return String
    */
    protected abstract String handleGetSetterName();

    /**
     * The "setter" name for this dependency.
     * @return (String)handleGetSetterName()
     */
    public final String getSetterName()
    {
        String setterName2a = null;
        // setterName has no pre constraints
        setterName2a = handleGetSetterName();
        // setterName has no post constraints
        return setterName2a;
    }

    // ------------- associations ------------------

    /**
     * Gets the dependencies for which this model element is the source.
     * @return (ModelElementFacade)handleGetSourceElement()
     */
    public final ModelElementFacade getSourceElement()
    {
        ModelElementFacade getSourceElement1r = null;
        // sourceDependencies has no pre constraints
        Object result = handleGetSourceElement();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getSourceElement1r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            DependencyFacadeLogic.logger.warn("incorrect metafacade cast for DependencyFacadeLogic.getSourceElement ModelElementFacade " + result + ": " + shieldedResult);
        }
        // sourceDependencies has no post constraints
        return getSourceElement1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetSourceElement();

    /**
     * Gets the dependencies for which this model element is the target.
     * @return (ModelElementFacade)handleGetTargetElement()
     */
    public final ModelElementFacade getTargetElement()
    {
        ModelElementFacade getTargetElement2r = null;
        // targetDependencies has no pre constraints
        Object result = handleGetTargetElement();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getTargetElement2r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            DependencyFacadeLogic.logger.warn("incorrect metafacade cast for DependencyFacadeLogic.getTargetElement ModelElementFacade " + result + ": " + shieldedResult);
        }
        // targetDependencies has no post constraints
        return getTargetElement2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTargetElement();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}