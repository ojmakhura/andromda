// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActionStateFacade;
import org.andromda.metafacades.uml.ActivityGraphFacade;
import org.andromda.metafacades.uml.ObjectFlowStateFacade;
import org.andromda.metafacades.uml.PartitionFacade;
import org.andromda.metafacades.uml.UseCaseFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.StateMachine;

/**
 * State machines can be used to express the behavior of part of a system. Behavior is modeled as a
 * traversal of a graph of state nodes interconnected by one or more joined transition arcs that are
 * triggered by the dispatching of series of (event) occurrences. During this traversal, the state
 * machine executes a series of activities associated with various elements of the state machine.
 * MetafacadeLogic for ActivityGraphFacade
 *
 * @see ActivityGraphFacade
 */
public abstract class ActivityGraphFacadeLogic
    extends StateMachineFacadeLogicImpl
    implements ActivityGraphFacade
{
    /**
     * The underlying UML object
     * @see StateMachine
     */
    protected StateMachine metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ActivityGraphFacadeLogic(StateMachine metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ActivityGraphFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ActivityGraphFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActivityGraphFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ActivityGraphFacade
     */
    public boolean isActivityGraphFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<ObjectFlowStateFacade>)handleGetObjectFlowStates()
     */
    public final Collection<ObjectFlowStateFacade> getObjectFlowStates()
    {
        Collection<ObjectFlowStateFacade> getObjectFlowStates1r = null;
        // activityGraphFacade has no pre constraints
         Collection result = handleGetObjectFlowStates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getObjectFlowStates1r = (Collection<ObjectFlowStateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ActivityGraphFacadeLogic.logger.warn("incorrect metafacade cast for ActivityGraphFacadeLogic.getObjectFlowStates Collection<ObjectFlowStateFacade> " + result + ": " + shieldedResult);
        }
        // activityGraphFacade has no post constraints
        return getObjectFlowStates1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetObjectFlowStates();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<ActionStateFacade>)handleGetActionStates()
     */
    public final Collection<ActionStateFacade> getActionStates()
    {
        Collection<ActionStateFacade> getActionStates2r = null;
        // activityGraphFacade has no pre constraints
         Collection result = handleGetActionStates();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getActionStates2r = (Collection<ActionStateFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ActivityGraphFacadeLogic.logger.warn("incorrect metafacade cast for ActivityGraphFacadeLogic.getActionStates Collection<ActionStateFacade> " + result + ": " + shieldedResult);
        }
        // activityGraphFacade has no post constraints
        return getActionStates2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetActionStates();

    /**
     * The first activity graph directly owned by this use-case.
     * @return (UseCaseFacade)handleGetUseCase()
     */
    public final UseCaseFacade getUseCase()
    {
        UseCaseFacade getUseCase3r = null;
        // firstActivityGraph has no pre constraints
        Object result = handleGetUseCase();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getUseCase3r = (UseCaseFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ActivityGraphFacadeLogic.logger.warn("incorrect metafacade cast for ActivityGraphFacadeLogic.getUseCase UseCaseFacade " + result + ": " + shieldedResult);
        }
        // firstActivityGraph has no post constraints
        return getUseCase3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetUseCase();

    /**
     * State machines can be used to express the behavior of part of a system. Behavior is modeled
     * as a
     * traversal of a graph of state nodes interconnected by one or more joined transition arcs that
     * are
     * triggered by the dispatching of series of (event) occurrences. During this traversal, the
     * state
     * machine executes a series of activities associated with various elements of the state
     * machine.
     * @return (Collection<PartitionFacade>)handleGetPartitions()
     */
    public final Collection<PartitionFacade> getPartitions()
    {
        Collection<PartitionFacade> getPartitions4r = null;
        // activityGraph has no pre constraints
         Collection result = handleGetPartitions();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getPartitions4r = (Collection<PartitionFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ActivityGraphFacadeLogic.logger.warn("incorrect metafacade cast for ActivityGraphFacadeLogic.getPartitions Collection<PartitionFacade> " + result + ": " + shieldedResult);
        }
        // activityGraph has no post constraints
        return getPartitions4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetPartitions();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see StateMachineFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}