// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAttribute;
import org.andromda.metafacades.uml.FrontEndComponent;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * TODO: Model Documentation for FrontEndComponent
 * MetafacadeLogic for FrontEndComponent
 *
 * @see FrontEndComponent
 */
public abstract class FrontEndComponentLogic
    extends ClassifierFacadeLogicImpl
    implements FrontEndComponent
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndComponentLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndComponentLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndComponent if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndComponent";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndComponent
     */
    public boolean isFrontEndComponentMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndComponent#getGenerateTable()
    * @return Boolean
    */
    protected abstract Boolean handleGetGenerateTable();

    /**
     * TODO: Model Documentation for FrontEndComponent.generateTable
     * @return (Boolean)handleGetGenerateTable()
     */
    public final Boolean getGenerateTable()
    {
        Boolean generateTable1a = null;
        // generateTable has no pre constraints
        generateTable1a = handleGetGenerateTable();
        // generateTable has no post constraints
        return generateTable1a;
    }

   /**
    * @see FrontEndComponent#getTableColumnNames()
    * @return Collection<String>
    */
    protected abstract Collection<String> handleGetTableColumnNames();

    /**
     * TODO: Model Documentation for FrontEndComponent.tableColumnNames
     * @return (Collection<String>)handleGetTableColumnNames()
     */
    public final Collection<String> getTableColumnNames()
    {
        Collection<String> tableColumnNames2a = null;
        // tableColumnNames has no pre constraints
        tableColumnNames2a = handleGetTableColumnNames();
        // tableColumnNames has no post constraints
        return tableColumnNames2a;
    }

   /**
    * @see FrontEndComponent#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * TODO: Model Documentation for FrontEndComponent.path
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path3a = null;
        // path has no pre constraints
        path3a = handleGetPath();
        // path has no post constraints
        return path3a;
    }

   /**
    * @see FrontEndComponent#getMessageKey()
    * @return String
    */
    protected abstract String handleGetMessageKey();

    /**
     * TODO: Model Documentation for FrontEndComponent.messageKey
     * @return (String)handleGetMessageKey()
     */
    public final String getMessageKey()
    {
        String messageKey4a = null;
        // messageKey has no pre constraints
        messageKey4a = handleGetMessageKey();
        // messageKey has no post constraints
        return messageKey4a;
    }

   /**
    * @see FrontEndComponent#getBeanName()
    * @return String
    */
    protected abstract String handleGetBeanName();

    /**
     * TODO: Model Documentation for FrontEndComponent.beanName
     * @return (String)handleGetBeanName()
     */
    public final String getBeanName()
    {
        String beanName5a = null;
        // beanName has no pre constraints
        beanName5a = handleGetBeanName();
        // beanName has no post constraints
        return beanName5a;
    }

   /**
    * @see FrontEndComponent#getTableName()
    * @return String
    */
    protected abstract String handleGetTableName();

    /**
     * TODO: Model Documentation for FrontEndComponent.tableName
     * @return (String)handleGetTableName()
     */
    public final String getTableName()
    {
        String tableName6a = null;
        // tableName has no pre constraints
        tableName6a = handleGetTableName();
        // tableName has no post constraints
        return tableName6a;
    }

   /**
    * @see FrontEndComponent#getTablePath()
    * @return String
    */
    protected abstract String handleGetTablePath();

    /**
     * TODO: Model Documentation for FrontEndComponent.tablePath
     * @return (String)handleGetTablePath()
     */
    public final String getTablePath()
    {
        String tablePath7a = null;
        // tablePath has no pre constraints
        tablePath7a = handleGetTablePath();
        // tablePath has no post constraints
        return tablePath7a;
    }

   /**
    * @see FrontEndComponent#getMappedModel()
    * @return String
    */
    protected abstract String handleGetMappedModel();

    /**
     * TODO: Model Documentation for FrontEndComponent.mappedModel
     * @return (String)handleGetMappedModel()
     */
    public final String getMappedModel()
    {
        String mappedModel8a = null;
        // mappedModel has no pre constraints
        mappedModel8a = handleGetMappedModel();
        // mappedModel has no post constraints
        return mappedModel8a;
    }

   /**
    * @see FrontEndComponent#getTreePresent()
    * @return Boolean
    */
    protected abstract Boolean handleGetTreePresent();

    /**
     * TODO: Model Documentation for FrontEndComponent.treePresent
     * @return (Boolean)handleGetTreePresent()
     */
    public final Boolean getTreePresent()
    {
        Boolean treePresent9a = null;
        // treePresent has no pre constraints
        treePresent9a = handleGetTreePresent();
        // treePresent has no post constraints
        return treePresent9a;
    }

   /**
    * @see FrontEndComponent#isTableVariablesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsTableVariablesPresent();

    /**
     * Indicates whether or not any non-table view variables are present in this view.
     * @return (boolean)handleIsTableVariablesPresent()
     */
    public final boolean isTableVariablesPresent()
    {
        boolean tableVariablesPresent10a = false;
        // tableVariablesPresent has no pre constraints
        tableVariablesPresent10a = handleIsTableVariablesPresent();
        // tableVariablesPresent has no post constraints
        return tableVariablesPresent10a;
    }

    // ------------- associations ------------------

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetFrontEndAttributes()
     */
    public final Collection<FrontEndAttribute> getFrontEndAttributes()
    {
        Collection<FrontEndAttribute> getFrontEndAttributes1r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetFrontEndAttributes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getFrontEndAttributes1r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getFrontEndAttributes Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getFrontEndAttributes1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetFrontEndAttributes();

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetTableColumns()
     */
    public final Collection<FrontEndAttribute> getTableColumns()
    {
        Collection<FrontEndAttribute> getTableColumns2r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetTableColumns();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTableColumns2r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getTableColumns Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getTableColumns2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTableColumns();

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetTables()
     */
    public final Collection<FrontEndAttribute> getTables()
    {
        Collection<FrontEndAttribute> getTables3r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetTables();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getTables3r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getTables Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getTables3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTables();

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetNonTables()
     */
    public final Collection<FrontEndAttribute> getNonTables()
    {
        Collection<FrontEndAttribute> getNonTables4r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetNonTables();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getNonTables4r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getNonTables Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getNonTables4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetNonTables();

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetComplexes()
     */
    public final Collection<FrontEndAttribute> getComplexes()
    {
        Collection<FrontEndAttribute> getComplexes5r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetComplexes();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getComplexes5r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getComplexes Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getComplexes5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetComplexes();

    /**
     * TODO: Model Documentation for FrontEndComponent
     * @return (Collection<FrontEndAttribute>)handleGetChildComponents()
     */
    public final Collection<FrontEndAttribute> getChildComponents()
    {
        Collection<FrontEndAttribute> getChildComponents6r = null;
        // frontEndComponent has no pre constraints
         Collection result = handleGetChildComponents();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getChildComponents6r = (Collection<FrontEndAttribute>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            FrontEndComponentLogic.logger.warn("incorrect metafacade cast for FrontEndComponentLogic.getChildComponents Collection<FrontEndAttribute> " + result + ": " + shieldedResult);
        }
        // frontEndComponent has no post constraints
        return getChildComponents6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetChildComponents();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}