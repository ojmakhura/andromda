// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeFacade;
import org.andromda.metafacades.uml.AttributeLinkFacade;
import org.andromda.metafacades.uml.InstanceFacade;
import org.apache.log4j.Logger;

/**
 * A representation of the model object 'Slot'. A slot specifies that an entity modeled by an
 * instance specification has a value or values for a specific structural feature.
 * MetafacadeLogic for AttributeLinkFacade
 *
 * @see AttributeLinkFacade
 */
public abstract class AttributeLinkFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements AttributeLinkFacade
{
    /**
     * The underlying UML object
     * @see AttributeLink
     */
    protected AttributeLink metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected AttributeLinkFacadeLogic(AttributeLink metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(AttributeLinkFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to AttributeLinkFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AttributeLinkFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see AttributeLinkFacade
     */
    public boolean isAttributeLinkFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<InstanceFacade> __getValues1r;
    private boolean __getValues1rSet = false;

    /**
     * All slots for this instance, this includes the ones that map onto attributes and the ones
     * that map onto association ends. In fact, this feature holds the collection of both
     * InstanceFacade.attributeLinks and InstanceFacade.linkEnds.
     * @return (Collection<InstanceFacade>)handleGetValues()
     */
    public final Collection<InstanceFacade> getValues()
    {
        Collection<InstanceFacade> getValues1r = this.__getValues1r;
        if (!this.__getValues1rSet)
        {
            // slots has no pre constraints
            Collection result = handleGetValues();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getValues1r = (Collection<InstanceFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AttributeLinkFacadeLogic.logger.warn("incorrect metafacade cast for AttributeLinkFacadeLogic.getValues Collection<InstanceFacade> " + result + ": " + shieldedResult);
            }
            // slots has no post constraints
            this.__getValues1r = getValues1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getValues1rSet = true;
            }
        }
        return getValues1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetValues();

    private InstanceFacade __getInstance2r;
    private boolean __getInstance2rSet = false;

    /**
     * Returns those slots that map onto attributes.
     * @return (InstanceFacade)handleGetInstance()
     */
    public final InstanceFacade getInstance()
    {
        InstanceFacade getInstance2r = this.__getInstance2r;
        if (!this.__getInstance2rSet)
        {
            // attributeLinks has no pre constraints
            Object result = handleGetInstance();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInstance2r = (InstanceFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AttributeLinkFacadeLogic.logger.warn("incorrect metafacade cast for AttributeLinkFacadeLogic.getInstance InstanceFacade " + result + ": " + shieldedResult);
            }
            // attributeLinks has no post constraints
            this.__getInstance2r = getInstance2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInstance2rSet = true;
            }
        }
        return getInstance2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInstance();

    private InstanceFacade __getValue3r;
    private boolean __getValue3rSet = false;

    /**
     * A representation of the model object 'Slot'. A slot specifies that an entity modeled by an
     * instance
     * specification has a value or values for a specific structural feature.
     * @return (InstanceFacade)handleGetValue()
     */
    public final InstanceFacade getValue()
    {
        InstanceFacade getValue3r = this.__getValue3r;
        if (!this.__getValue3rSet)
        {
            // attributeLinkFacade has no pre constraints
            Object result = handleGetValue();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getValue3r = (InstanceFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AttributeLinkFacadeLogic.logger.warn("incorrect metafacade cast for AttributeLinkFacadeLogic.getValue InstanceFacade " + result + ": " + shieldedResult);
            }
            // attributeLinkFacade has no post constraints
            this.__getValue3r = getValue3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getValue3rSet = true;
            }
        }
        return getValue3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetValue();

    private AttributeFacade __getAttribute4r;
    private boolean __getAttribute4rSet = false;

    /**
     * A representation of the model object 'Slot'. A slot specifies that an entity modeled by an
     * instance
     * specification has a value or values for a specific structural feature.
     * @return (AttributeFacade)handleGetAttribute()
     */
    public final AttributeFacade getAttribute()
    {
        AttributeFacade getAttribute4r = this.__getAttribute4r;
        if (!this.__getAttribute4rSet)
        {
            // attributeLinkFacade has no pre constraints
            Object result = handleGetAttribute();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getAttribute4r = (AttributeFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                AttributeLinkFacadeLogic.logger.warn("incorrect metafacade cast for AttributeLinkFacadeLogic.getAttribute AttributeFacade " + result + ": " + shieldedResult);
            }
            // attributeLinkFacade has no post constraints
            this.__getAttribute4r = getAttribute4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAttribute4rSet = true;
            }
        }
        return getAttribute4r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetAttribute();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}