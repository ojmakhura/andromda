// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.EventFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.metafacades.uml.ParameterFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Parameter;

/**
 * Specification of an argument used to pass information into or out of an invocation of a
 * behavioral feature. Parameters are allowed to be treated as connectable elements. Parameters have
 * support for streaming, exceptions, and parameter sets.
 * MetafacadeLogic for ParameterFacade
 *
 * @see ParameterFacade
 */
public abstract class ParameterFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements ParameterFacade
{
    /**
     * The underlying UML object
     * @see Parameter
     */
    protected Parameter metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ParameterFacadeLogic(Parameter metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ParameterFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ParameterFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ParameterFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ParameterFacade
     */
    public boolean isParameterFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ParameterFacade#getDefaultValue()
    * @return String
    */
    protected abstract String handleGetDefaultValue();

    /**
     * TODO: Model Documentation for ParameterFacade.defaultValue
     * @return (String)handleGetDefaultValue()
     */
    public final String getDefaultValue()
    {
        String defaultValue1a = null;
        // defaultValue has no pre constraints
        defaultValue1a = handleGetDefaultValue();
        // defaultValue has no post constraints
        return defaultValue1a;
    }

   /**
    * @see ParameterFacade#isDefaultValuePresent()
    * @return boolean
    */
    protected abstract boolean handleIsDefaultValuePresent();

    /**
     * Indicates if the default value is present.
     * @return (boolean)handleIsDefaultValuePresent()
     */
    public final boolean isDefaultValuePresent()
    {
        boolean defaultValuePresent2a = false;
        // defaultValuePresent has no pre constraints
        defaultValuePresent2a = handleIsDefaultValuePresent();
        // defaultValuePresent has no post constraints
        return defaultValuePresent2a;
    }

   /**
    * @see ParameterFacade#getGetterName()
    * @return String
    */
    protected abstract String handleGetGetterName();

    /**
     * The name to use for accessors getting this parameter from a bean.
     * @return (String)handleGetGetterName()
     */
    public final String getGetterName()
    {
        String getterName3a = null;
        // getterName has no pre constraints
        getterName3a = handleGetGetterName();
        // getterName has no post constraints
        return getterName3a;
    }

   /**
    * @see ParameterFacade#getGetterSetterTypeName()
    * @return String
    */
    protected abstract String handleGetGetterSetterTypeName();

    /**
     * Fully Qualified TypeName, determined in part by multiplicity (for UML2). For UML14, same as
     * getterName.
     * @return (String)handleGetGetterSetterTypeName()
     */
    public final String getGetterSetterTypeName()
    {
        String getterSetterTypeName4a = null;
        // getterSetterTypeName has no pre constraints
        getterSetterTypeName4a = handleGetGetterSetterTypeName();
        // getterSetterTypeName has no post constraints
        return getterSetterTypeName4a;
    }

   /**
    * @see ParameterFacade#getGetterSetterTypeNameImpl()
    * @return String
    */
    protected abstract String handleGetGetterSetterTypeNameImpl();

    /**
     * Fully Qualified implementation class of TypeName, determined in part by multiplicity (for
     * UML2). If upper multiplicity =1, same as getterSetterTypeName.
     * @return (String)handleGetGetterSetterTypeNameImpl()
     */
    public final String getGetterSetterTypeNameImpl()
    {
        String getterSetterTypeNameImpl5a = null;
        // getterSetterTypeNameImpl has no pre constraints
        getterSetterTypeNameImpl5a = handleGetGetterSetterTypeNameImpl();
        // getterSetterTypeNameImpl has no post constraints
        return getterSetterTypeNameImpl5a;
    }

   /**
    * @see ParameterFacade#isRequired()
    * @return boolean
    */
    protected abstract boolean handleIsRequired();

    /**
     * Whether or not this parameter is considered required (i.e must a non-empty value).
     * @return (boolean)handleIsRequired()
     */
    public final boolean isRequired()
    {
        boolean required6a = false;
        // required has no pre constraints
        required6a = handleIsRequired();
        // required has no post constraints
        return required6a;
    }

   /**
    * @see ParameterFacade#isReturn()
    * @return boolean
    */
    protected abstract boolean handleIsReturn();

    /**
     * Whether or not this parameter represents a return parameter.
     * @return (boolean)handleIsReturn()
     */
    public final boolean isReturn()
    {
        boolean return7a = false;
        // return has no pre constraints
        return7a = handleIsReturn();
        // return has no post constraints
        return return7a;
    }

   /**
    * @see ParameterFacade#getSetterName()
    * @return String
    */
    protected abstract String handleGetSetterName();

    /**
     * The name to use for accessors getting this parameter in a bean.
     * @return (String)handleGetSetterName()
     */
    public final String getSetterName()
    {
        String setterName8a = null;
        // setterName has no pre constraints
        setterName8a = handleGetSetterName();
        // setterName has no post constraints
        return setterName8a;
    }

   /**
    * @see ParameterFacade#isReadable()
    * @return boolean
    */
    protected abstract boolean handleIsReadable();

    /**
     * True if this parameter is readable, aka an in-parameter, or this feature is unspecified.
     * @return (boolean)handleIsReadable()
     */
    public final boolean isReadable()
    {
        boolean readable9a = false;
        // readable has no pre constraints
        readable9a = handleIsReadable();
        // readable has no post constraints
        return readable9a;
    }

   /**
    * @see ParameterFacade#isWritable()
    * @return boolean
    */
    protected abstract boolean handleIsWritable();

    /**
     * True if this parameter is writable, aka an out-parameter, or this feature is unspecified.
     * @return (boolean)handleIsWritable()
     */
    public final boolean isWritable()
    {
        boolean writable10a = false;
        // writable has no pre constraints
        writable10a = handleIsWritable();
        // writable has no post constraints
        return writable10a;
    }

   /**
    * @see ParameterFacade#isInParameter()
    * @return boolean
    */
    protected abstract boolean handleIsInParameter();

    /**
     * True if this parameter is an 'in' parameter.
     * @return (boolean)handleIsInParameter()
     */
    public final boolean isInParameter()
    {
        boolean inParameter11a = false;
        // inParameter has no pre constraints
        inParameter11a = handleIsInParameter();
        // inParameter has no post constraints
        return inParameter11a;
    }

   /**
    * @see ParameterFacade#isOutParameter()
    * @return boolean
    */
    protected abstract boolean handleIsOutParameter();

    /**
     * True if this parameter is an 'out' parameter.
     * @return (boolean)handleIsOutParameter()
     */
    public final boolean isOutParameter()
    {
        boolean outParameter12a = false;
        // outParameter has no pre constraints
        outParameter12a = handleIsOutParameter();
        // outParameter has no post constraints
        return outParameter12a;
    }

   /**
    * @see ParameterFacade#isInoutParameter()
    * @return boolean
    */
    protected abstract boolean handleIsInoutParameter();

    /**
     * True if this parameter is an inout parameter.
     * @return (boolean)handleIsInoutParameter()
     */
    public final boolean isInoutParameter()
    {
        boolean inoutParameter13a = false;
        // inoutParameter has no pre constraints
        inoutParameter13a = handleIsInoutParameter();
        // inoutParameter has no post constraints
        return inoutParameter13a;
    }

   /**
    * @see ParameterFacade#getUpper()
    * @return int
    */
    protected abstract int handleGetUpper();

    /**
     * the upper value of the multiplicity (will be -1 for *)
     * -only applicable for UML2
     * @return (int)handleGetUpper()
     */
    public final int getUpper()
    {
        int upper14a = 0;
        // upper has no pre constraints
        upper14a = handleGetUpper();
        // upper has no post constraints
        return upper14a;
    }

   /**
    * @see ParameterFacade#getLower()
    * @return int
    */
    protected abstract int handleGetLower();

    /**
     * the lower value for the multiplicity
     * -only applicable for UML2
     * @return (int)handleGetLower()
     */
    public final int getLower()
    {
        int lower15a = 0;
        // lower has no pre constraints
        lower15a = handleGetLower();
        // lower has no post constraints
        return lower15a;
    }

   /**
    * @see ParameterFacade#isUnique()
    * @return boolean
    */
    protected abstract boolean handleIsUnique();

    /**
     * If Parameter type isMany (UML2), is the parameter unique within the Collection. Unique+Sorted
     * determines pareter implementation type. For UML14, always false.
     * @return (boolean)handleIsUnique()
     */
    public final boolean isUnique()
    {
        boolean unique16a = false;
        // unique has no pre constraints
        unique16a = handleIsUnique();
        // unique has no post constraints
        return unique16a;
    }

   /**
    * @see ParameterFacade#isOrdered()
    * @return boolean
    */
    protected abstract boolean handleIsOrdered();

    /**
     * UML2 Only: Is parameter ordered within the Collection type. Ordered+Unique determines the
     * implementation Collection Type. For UML14, always false.
     * @return (boolean)handleIsOrdered()
     */
    public final boolean isOrdered()
    {
        boolean ordered17a = false;
        // ordered has no pre constraints
        ordered17a = handleIsOrdered();
        // ordered has no post constraints
        return ordered17a;
    }

   /**
    * @see ParameterFacade#isMany()
    * @return boolean
    */
    protected abstract boolean handleIsMany();

    /**
     * If upper>1 or upper==unlimited. Only applies to UML2. For UML14, always false.
     * @return (boolean)handleIsMany()
     */
    public final boolean isMany()
    {
        boolean many18a = false;
        // many has no pre constraints
        many18a = handleIsMany();
        // many has no post constraints
        return many18a;
    }

   /**
    * @see ParameterFacade#isException()
    * @return boolean
    */
    protected abstract boolean handleIsException();

    /**
     * UML2: Returns the value of the 'Is Exception' attribute. The default value is "false". Tells
     * whether an output parameter may emit a value to the exclusion of the other outputs.
     * @return (boolean)handleIsException()
     */
    public final boolean isException()
    {
        boolean exception19a = false;
        // exception has no pre constraints
        exception19a = handleIsException();
        // exception has no post constraints
        return exception19a;
    }

   /**
    * @see ParameterFacade#getEffect()
    * @return String
    */
    protected abstract String handleGetEffect();

    /**
     * UML2: A representation of the literals of the enumeration 'Parameter Effect Kind': CREATE,
     * READ, UPDATE, DELETE. The datatype ParameterEffectKind is an enumeration that indicates the
     * effect of a behavior on values passed in or out of its parameters.
     * @return (String)handleGetEffect()
     */
    public final String getEffect()
    {
        String effect20a = null;
        // effect has no pre constraints
        effect20a = handleGetEffect();
        // effect has no post constraints
        return effect20a;
    }

    // ------------- associations ------------------

    /**
     * Specification of an argument used to pass information into or out of an invocation of a
     * behavioral
     * feature. Parameters are allowed to be treated as connectable elements. Parameters have
     * support for
     * streaming, exceptions, and parameter sets.
     * @return (ClassifierFacade)handleGetType()
     */
    public final ClassifierFacade getType()
    {
        ClassifierFacade getType1r = null;
        // parameterFacade has no pre constraints
        Object result = handleGetType();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getType1r = (ClassifierFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ParameterFacadeLogic.logger.warn("incorrect metafacade cast for ParameterFacadeLogic.getType ClassifierFacade " + result + ": " + shieldedResult);
        }
        // parameterFacade has no post constraints
        return getType1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetType();

    /**
     * The parameters to this event.
     * @return (EventFacade)handleGetEvent()
     */
    public final EventFacade getEvent()
    {
        EventFacade getEvent2r = null;
        // parameters has no pre constraints
        Object result = handleGetEvent();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getEvent2r = (EventFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ParameterFacadeLogic.logger.warn("incorrect metafacade cast for ParameterFacadeLogic.getEvent EventFacade " + result + ": " + shieldedResult);
        }
        // parameters has no post constraints
        return getEvent2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetEvent();

    /**
     * Return all parameters for the operation, including the return parameter.
     * @return (OperationFacade)handleGetOperation()
     */
    public final OperationFacade getOperation()
    {
        OperationFacade getOperation3r = null;
        // parameters has no pre constraints
        Object result = handleGetOperation();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOperation3r = (OperationFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            ParameterFacadeLogic.logger.warn("incorrect metafacade cast for ParameterFacadeLogic.getOperation OperationFacade " + result + ": " + shieldedResult);
        }
        // parameters has no post constraints
        return getOperation3r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOperation();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ParameterFacade::parameter needs a type</p>
     * <p><b>Error:</b> Each parameter needs a type, you cannot leave the type unspecified.</p>
     * <p><b>OCL:</b> context ParameterFacade
inv: return = false implies type.name->notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ParameterFacade::non return type parameters must be named</p>
     * <p><b>Error:</b> Each parameter that is NOT a return parameter must have a non-empty name.</p>
     * <p><b>OCL:</b> context ParameterFacade
inv: return = false 
implies name -> notEmpty()</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ParameterFacade::primitive parameter cannot be used in Collection</p>
     * <p><b>Error:</b> Primitive parameters cannot be used in Collections (multiplicity > 1). Use the wrapped type instead.</p>
     * <p><b>OCL:</b> context ParameterFacade inv: type.primitive implies (many = false)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ParameterFacade::primitive parameter must be required</p>
     * <p><b>Error:</b> Primitive operation parameters must have a multiplicity lower bound > 0 (must be required). Use a
wrapped type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context ParameterFacade inv: type.primitive implies (lower > 0)</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::ParameterFacade::wrapped primitive parameter should not be required</p>
     * <p><b>Error:</b> Wrapped primitive operation parameters must have a multiplicity lower bound = 0 (must be optional).
Use the unwrapped type, or change the multiplicity.</p>
     * <p><b>OCL:</b> context ParameterFacade inv: type.wrappedPrimitive and many = false implies (lower = 0)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"type.name")):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ParameterFacade::parameter needs a type",
                        "Each parameter needs a type, you cannot leave the type unspecified."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ParameterFacade::parameter needs a type' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name")):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ParameterFacade::non return type parameters must be named",
                        "Each parameter that is NOT a return parameter must have a non-empty name."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ParameterFacade::non return type parameters must be named' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.primitive"))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ParameterFacade::primitive parameter cannot be used in Collection",
                        "Primitive parameters cannot be used in Collections (multiplicity > 1). Use the wrapped type instead."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ParameterFacade::primitive parameter cannot be used in Collection' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.primitive"))).booleanValue()?(OCLExpressions.greater(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ParameterFacade::primitive parameter must be required",
                        "Primitive operation parameters must have a multiplicity lower bound > 0 (must be required). Use a\nwrapped type, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ParameterFacade::primitive parameter must be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(Boolean.valueOf(String.valueOf(OCLIntrospector.invoke(contextElement,"type.wrappedPrimitive"))).booleanValue()&&OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"many"),false))).booleanValue()?(OCLExpressions.equal(OCLIntrospector.invoke(contextElement,"lower"),0)):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ParameterFacade::wrapped primitive parameter should not be required",
                        "Wrapped primitive operation parameters must have a multiplicity lower bound = 0 (must be optional).\nUse the unwrapped type, or change the multiplicity."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::ParameterFacade::wrapped primitive parameter should not be required' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}