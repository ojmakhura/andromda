// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ValueObject;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * Represents a value object, a Classifier whose unique value is determined only by its attributes.
 * MetafacadeLogic for ValueObject
 *
 * @see ValueObject
 */
public abstract class ValueObjectLogic
    extends ClassifierFacadeLogicImpl
    implements ValueObject
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ValueObjectLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ValueObjectLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ValueObject if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ValueObject";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ValueObject
     */
    public boolean isValueObjectMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see ValueObject#getMappedComponent()
    * @return String
    */
    protected abstract String handleGetMappedComponent();

    /**
     * TODO: Model Documentation for ValueObject.mappedComponent
     * @return (String)handleGetMappedComponent()
     */
    public final String getMappedComponent()
    {
        String mappedComponent1a = null;
        // mappedComponent has no pre constraints
        mappedComponent1a = handleGetMappedComponent();
        // mappedComponent has no post constraints
        return mappedComponent1a;
    }

   /**
    * @see ValueObject#isJavaRecord()
    * @return boolean
    */
    protected abstract boolean handleIsJavaRecord();

    /**
     * TODO: Model Documentation for ValueObject.javaRecord
     * @return (boolean)handleIsJavaRecord()
     */
    public final boolean isJavaRecord()
    {
        boolean javaRecord2a = false;
        // javaRecord has no pre constraints
        javaRecord2a = handleIsJavaRecord();
        // javaRecord has no post constraints
        return javaRecord2a;
    }

    // ------------- associations ------------------

    private Collection<ValueObject> __getTypeSpecializations1r;
    private boolean __getTypeSpecializations1rSet = false;

    /**
     * Represents a value object, a Classifier whose unique value is determined only by its
     * attributes.
     * @return (Collection<ValueObject>)handleGetTypeSpecializations()
     */
    public final Collection<ValueObject> getTypeSpecializations()
    {
        Collection<ValueObject> getTypeSpecializations1r = this.__getTypeSpecializations1r;
        if (!this.__getTypeSpecializations1rSet)
        {
            // valueObject has no pre constraints
             Collection result = handleGetTypeSpecializations();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getTypeSpecializations1r = (Collection<ValueObject>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ValueObjectLogic.logger.warn("incorrect metafacade cast for ValueObjectLogic.getTypeSpecializations Collection<ValueObject> " + result + ": " + shieldedResult);
            }
            // valueObject has no post constraints
            this.__getTypeSpecializations1r = getTypeSpecializations1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTypeSpecializations1rSet = true;
            }
        }
        return getTypeSpecializations1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetTypeSpecializations();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}