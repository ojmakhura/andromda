// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.CallActionFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.CallOperationAction;

/**
 * A representation of the model object 'Call Operation Action'. An action that transmits an
 * operation call request to the target object, where it may cause the invocation of associated
 * behavior. The argument values of the action are available to the execution of the invoked
 * behavior. If the action is marked synchronous, the execution of the call operation action waits
 * until the execution of the invoked behavior completes and a reply transmission is returned to the
 * caller; otherwise execution of the action is complete when the invocation of the operation is
 * established and the execution of the invoked operation proceeds concurrently with the execution
 * of the calling behavior. Any values returned as part of the reply transmission are put on the
 * result output pins of the call operation action. Upon receipt of the reply transmission,
 * execution of the call operation action is complete.
 * MetafacadeLogic for CallActionFacade
 *
 * @see CallActionFacade
 */
public abstract class CallActionFacadeLogic
    extends ActionFacadeLogicImpl
    implements CallActionFacade
{
    /**
     * The underlying UML object
     * @see CallOperationAction
     */
    protected CallOperationAction metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected CallActionFacadeLogic(CallOperationAction metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(CallActionFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to CallActionFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.CallActionFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see CallActionFacade
     */
    public boolean isCallActionFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Call Operation Action'. An action that transmits an
     * operation
     * call request to the target object, where it may cause the invocation of associated behavior.
     * The
     * argument values of the action are available to the execution of the invoked behavior. If the
     * action
     * is marked synchronous, the execution of the call operation action waits until the execution
     * of the
     * invoked behavior completes and a reply transmission is returned to the caller; otherwise
     * execution
     * of the action is complete when the invocation of the operation is established and the
     * execution of
     * the invoked operation proceeds concurrently with the execution of the calling behavior. Any
     * values
     * returned as part of the reply transmission are put on the result output pins of the call
     * operation
     * action. Upon receipt of the reply transmission, execution of the call operation action is
     * complete.
     * @return (OperationFacade)handleGetOperation()
     */
    public final OperationFacade getOperation()
    {
        OperationFacade getOperation1r = null;
        // callActionFacade has no pre constraints
        Object result = handleGetOperation();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getOperation1r = (OperationFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            CallActionFacadeLogic.logger.warn("incorrect metafacade cast for CallActionFacadeLogic.getOperation OperationFacade " + result + ": " + shieldedResult);
        }
        // callActionFacade has no post constraints
        return getOperation1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetOperation();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ActionFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}