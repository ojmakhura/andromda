// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.AttributeLinkFacade;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.InstanceFacade;
import org.andromda.metafacades.uml.LinkEndFacade;
import org.andromda.metafacades.uml.LinkFacade;
import org.apache.log4j.Logger;

/**
 * A representation of the model object 'Instance Specification'. Represents an instance in a
 * modeled system. Has the capability of being a deployment target in a deployment relationship, in
 * the case that it is an instance of a node. Has the capability of being a deployed artifact, if it
 * is an instance of an artifact.
 * MetafacadeLogic for InstanceFacade
 *
 * @see InstanceFacade
 */
public abstract class InstanceFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements InstanceFacade
{
    /**
     * The underlying UML object
     * @see ObjectInstance
     */
    protected ObjectInstance metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected InstanceFacadeLogic(ObjectInstance metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(InstanceFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to InstanceFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.InstanceFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see InstanceFacade
     */
    public boolean isInstanceFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private Collection<LinkFacade> __getOwnedLinks1r;
    private boolean __getOwnedLinks1rSet = false;

    /**
     * A representation of the model object 'Instance Specification'. Represents an instance in a
     * modeled
     * system. Has the capability of being a deployment target in a deployment relationship, in the
     * case
     * that it is an instance of a node. Has the capability of being a deployed artifact, if it is
     * an
     * instance of an artifact.
     * @return (Collection<LinkFacade>)handleGetOwnedLinks()
     */
    public final Collection<LinkFacade> getOwnedLinks()
    {
        Collection<LinkFacade> getOwnedLinks1r = this.__getOwnedLinks1r;
        if (!this.__getOwnedLinks1rSet)
        {
            // instanceFacade has no pre constraints
             Collection result = handleGetOwnedLinks();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getOwnedLinks1r = (Collection<LinkFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getOwnedLinks Collection<LinkFacade> " + result + ": " + shieldedResult);
            }
            // instanceFacade has no post constraints
            this.__getOwnedLinks1r = getOwnedLinks1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOwnedLinks1rSet = true;
            }
        }
        return getOwnedLinks1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOwnedLinks();

    private Collection<InstanceFacade> __getOwnedInstances2r;
    private boolean __getOwnedInstances2rSet = false;

    /**
     * A representation of the model object 'Instance Specification'. Represents an instance in a
     * modeled
     * system. Has the capability of being a deployment target in a deployment relationship, in the
     * case
     * that it is an instance of a node. Has the capability of being a deployed artifact, if it is
     * an
     * instance of an artifact.
     * @return (Collection<InstanceFacade>)handleGetOwnedInstances()
     */
    public final Collection<InstanceFacade> getOwnedInstances()
    {
        Collection<InstanceFacade> getOwnedInstances2r = this.__getOwnedInstances2r;
        if (!this.__getOwnedInstances2rSet)
        {
            // instanceFacade has no pre constraints
             Collection result = handleGetOwnedInstances();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getOwnedInstances2r = (Collection<InstanceFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getOwnedInstances Collection<InstanceFacade> " + result + ": " + shieldedResult);
            }
            // instanceFacade has no post constraints
            this.__getOwnedInstances2r = getOwnedInstances2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOwnedInstances2rSet = true;
            }
        }
        return getOwnedInstances2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetOwnedInstances();

    /**
     * The instances this attribute link is attached too. An attribute link can have many instance
     * values when its defining feature is an attribute with a 'many' multiplicity.
     * @return (Collection<AttributeLinkFacade>)handleGetSlots()
     */
    public final Collection<AttributeLinkFacade> getSlots()
    {
        Collection<AttributeLinkFacade> getSlots3r = null;
        // values has no pre constraints
         Collection result = handleGetSlots();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getSlots3r = (Collection<AttributeLinkFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getSlots Collection<AttributeLinkFacade> " + result + ": " + shieldedResult);
        }
        // values has no post constraints
        return getSlots3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetSlots();

    private Collection<LinkEndFacade> __getLinkEnds4r;
    private boolean __getLinkEnds4rSet = false;

    /**
     * The first instance to which this link end is attached.
     * @return (Collection<LinkEndFacade>)handleGetLinkEnds()
     */
    public final Collection<LinkEndFacade> getLinkEnds()
    {
        Collection<LinkEndFacade> getLinkEnds4r = this.__getLinkEnds4r;
        if (!this.__getLinkEnds4rSet)
        {
            // instance has no pre constraints
             Collection result = handleGetLinkEnds();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getLinkEnds4r = (Collection<LinkEndFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getLinkEnds Collection<LinkEndFacade> " + result + ": " + shieldedResult);
            }
            // instance has no post constraints
            this.__getLinkEnds4r = getLinkEnds4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLinkEnds4rSet = true;
            }
        }
        return getLinkEnds4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetLinkEnds();

    private Collection<ClassifierFacade> __getClassifiers5r;
    private boolean __getClassifiers5rSet = false;

    /**
     * A representation of the model object 'Instance Specification'. Represents an instance in a
     * modeled
     * system. Has the capability of being a deployment target in a deployment relationship, in the
     * case
     * that it is an instance of a node. Has the capability of being a deployed artifact, if it is
     * an
     * instance of an artifact.
     * @return (Collection<ClassifierFacade>)handleGetClassifiers()
     */
    public final Collection<ClassifierFacade> getClassifiers()
    {
        Collection<ClassifierFacade> getClassifiers5r = this.__getClassifiers5r;
        if (!this.__getClassifiers5rSet)
        {
            // instanceFacade has no pre constraints
             Collection result = handleGetClassifiers();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getClassifiers5r = (Collection<ClassifierFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getClassifiers Collection<ClassifierFacade> " + result + ": " + shieldedResult);
            }
            // instanceFacade has no post constraints
            this.__getClassifiers5r = getClassifiers5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getClassifiers5rSet = true;
            }
        }
        return getClassifiers5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetClassifiers();

    private Collection<AttributeLinkFacade> __getAttributeLinks6r;
    private boolean __getAttributeLinks6rSet = false;

    /**
     * The owning instance for this link.
     * @return (Collection<AttributeLinkFacade>)handleGetAttributeLinks()
     */
    public final Collection<AttributeLinkFacade> getAttributeLinks()
    {
        Collection<AttributeLinkFacade> getAttributeLinks6r = this.__getAttributeLinks6r;
        if (!this.__getAttributeLinks6rSet)
        {
            // instance has no pre constraints
             Collection result = handleGetAttributeLinks();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAttributeLinks6r = (Collection<AttributeLinkFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                InstanceFacadeLogic.logger.warn("incorrect metafacade cast for InstanceFacadeLogic.getAttributeLinks Collection<AttributeLinkFacade> " + result + ": " + shieldedResult);
            }
            // instance has no post constraints
            this.__getAttributeLinks6r = getAttributeLinks6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAttributeLinks6rSet = true;
            }
        }
        return getAttributeLinks6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAttributeLinks();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}