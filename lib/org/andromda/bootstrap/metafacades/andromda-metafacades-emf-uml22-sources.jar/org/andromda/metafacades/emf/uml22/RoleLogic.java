// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.Role;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.commons.collections.Transformer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Actor;

/**
 * Represents a role a user may play within a system.  Provides access to things such as services
 * and service operations.
 * MetafacadeLogic for Role
 *
 * @see Role
 */
public abstract class RoleLogic
    extends ActorFacadeLogicImpl
    implements Role
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected RoleLogic(Object metaObjectIn, String context)
    {
        super((Actor)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(RoleLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to Role if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Role";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see Role
     */
    public boolean isRoleMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see Role#isReferencesPresent()
    * @return boolean
    */
    protected abstract boolean handleIsReferencesPresent();

    /**
     * Indicates if the necessary references are present for the Role.  This include any references
     * to a service, service operation or use case.
     * @return (boolean)handleIsReferencesPresent()
     */
    public final boolean isReferencesPresent()
    {
        boolean referencesPresent1a = false;
        // referencesPresent has no pre constraints
        referencesPresent1a = handleIsReferencesPresent();
        // referencesPresent has no post constraints
        return referencesPresent1a;
    }

    // ------------- associations ------------------

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::Role::non-empty unique role name</p>
     * <p><b>Error:</b> Each role must have a non-empty name that is unique among all other roles.</p>
     * <p><b>OCL:</b> context Role inv: name->notEmpty() and model.allActors->isUnique(name)</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ActorFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"name"))&&OCLCollections.isUnique(OCLIntrospector.invoke(contextElement,"model.allActors"),new Transformer(){public Object transform(Object object){return OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::Role::non-empty unique role name",
                        "Each role must have a non-empty name that is unique among all other roles."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::Role::non-empty unique role name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}