// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActivityGraph;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndParameter;
import org.andromda.translation.ocl.validation.OCLExpressions;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Operation;

/**
 * Represents an operation modeled on a controller.
 * MetafacadeLogic for FrontEndControllerOperation
 *
 * @see FrontEndControllerOperation
 */
public abstract class FrontEndControllerOperationLogic
    extends OperationFacadeLogicImpl
    implements FrontEndControllerOperation
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndControllerOperationLogic(Object metaObjectIn, String context)
    {
        super((Operation)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndControllerOperationLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndControllerOperation if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndControllerOperation";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndControllerOperation
     */
    public boolean isFrontEndControllerOperationMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndControllerOperation#isOwnerIsController()
    * @return boolean
    */
    protected abstract boolean handleIsOwnerIsController();

    /**
     * Indicates if the owner of this operation is a controller.
     * @return (boolean)handleIsOwnerIsController()
     */
    public final boolean isOwnerIsController()
    {
        boolean ownerIsController1a = false;
        // ownerIsController has no pre constraints
        ownerIsController1a = handleIsOwnerIsController();
        // ownerIsController has no post constraints
        return ownerIsController1a;
    }

   /**
    * @see FrontEndControllerOperation#isAllArgumentsHaveFormFields()
    * @return boolean
    */
    protected abstract boolean handleIsAllArgumentsHaveFormFields();

    /**
     * For each front-end controller operation argument there must exist a form field for each
     * action deferring to that operation. This form field must carry the same name and must be of
     * the same type. True if this is the case, false otherwise.
     * @return (boolean)handleIsAllArgumentsHaveFormFields()
     */
    public final boolean isAllArgumentsHaveFormFields()
    {
        boolean allArgumentsHaveFormFields2a = false;
        // allArgumentsHaveFormFields has no pre constraints
        allArgumentsHaveFormFields2a = handleIsAllArgumentsHaveFormFields();
        // allArgumentsHaveFormFields has no post constraints
        return allArgumentsHaveFormFields2a;
    }

   /**
    * @see FrontEndControllerOperation#getFullyQualifiedFormPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedFormPath();

    /**
     * The fully qualified path of the form file.
     * @return (String)handleGetFullyQualifiedFormPath()
     */
    public final String getFullyQualifiedFormPath()
    {
        String fullyQualifiedFormPath3a = null;
        // fullyQualifiedFormPath has no pre constraints
        fullyQualifiedFormPath3a = handleGetFullyQualifiedFormPath();
        // fullyQualifiedFormPath has no post constraints
        return fullyQualifiedFormPath3a;
    }

   /**
    * @see FrontEndControllerOperation#getFullyQualifiedFormName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedFormName();

    /**
     * The fully qualified form name.
     * @return (String)handleGetFullyQualifiedFormName()
     */
    public final String getFullyQualifiedFormName()
    {
        String fullyQualifiedFormName4a = null;
        // fullyQualifiedFormName has no pre constraints
        fullyQualifiedFormName4a = handleGetFullyQualifiedFormName();
        // fullyQualifiedFormName has no post constraints
        return fullyQualifiedFormName4a;
    }

   /**
    * @see FrontEndControllerOperation#getFormName()
    * @return String
    */
    protected abstract String handleGetFormName();

    /**
     * The form name the corresponds to this controller operation.
     * @return (String)handleGetFormName()
     */
    public final String getFormName()
    {
        String formName5a = null;
        // formName has no pre constraints
        formName5a = handleGetFormName();
        // formName has no post constraints
        return formName5a;
    }

   /**
    * @see FrontEndControllerOperation#getFormCall()
    * @return String
    */
    protected abstract String handleGetFormCall();

    /**
     * The operation call that takes the appropriate form as an argument.
     * @return (String)handleGetFormCall()
     */
    public final String getFormCall()
    {
        String formCall6a = null;
        // formCall has no pre constraints
        formCall6a = handleGetFormCall();
        // formCall has no post constraints
        return formCall6a;
    }

   /**
    * @see FrontEndControllerOperation#getFormSignature()
    * @return String
    */
    protected abstract String handleGetFormSignature();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return (String)handleGetFormSignature()
     */
    public final String getFormSignature()
    {
        String formSignature7a = null;
        // formSignature has no pre constraints
        formSignature7a = handleGetFormSignature();
        // formSignature has no post constraints
        return formSignature7a;
    }

   /**
    * @see FrontEndControllerOperation#getImplementationFormSignature()
    * @return String
    */
    protected abstract String handleGetImplementationFormSignature();

    /**
     * The controller implementation operation signature that takes the appropriate form (if this
     * operation has at least one form field) as an argument.
     * @return (String)handleGetImplementationFormSignature()
     */
    public final String getImplementationFormSignature()
    {
        String implementationFormSignature8a = null;
        // implementationFormSignature has no pre constraints
        implementationFormSignature8a = handleGetImplementationFormSignature();
        // implementationFormSignature has no post constraints
        return implementationFormSignature8a;
    }

   /**
    * @see FrontEndControllerOperation#getHandleFormSignature()
    * @return String
    */
    protected abstract String handleGetHandleFormSignature();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return (String)handleGetHandleFormSignature()
     */
    public final String getHandleFormSignature()
    {
        String handleFormSignature9a = null;
        // handleFormSignature has no pre constraints
        handleFormSignature9a = handleGetHandleFormSignature();
        // handleFormSignature has no post constraints
        return handleFormSignature9a;
    }

   /**
    * @see FrontEndControllerOperation#getHandleFormSignatureImplementation()
    * @return String
    */
    protected abstract String handleGetHandleFormSignatureImplementation();

    /**
     * The controller operation signature that takes the appropriate form (if this operation has at
     * least one form field) as an argument.
     * @return (String)handleGetHandleFormSignatureImplementation()
     */
    public final String getHandleFormSignatureImplementation()
    {
        String handleFormSignatureImplementation10a = null;
        // handleFormSignatureImplementation has no pre constraints
        handleFormSignatureImplementation10a = handleGetHandleFormSignatureImplementation();
        // handleFormSignatureImplementation has no post constraints
        return handleFormSignatureImplementation10a;
    }

   /**
    * @see FrontEndControllerOperation#isExposed()
    * @return boolean
    */
    protected abstract boolean handleIsExposed();

    /**
     * TODO: Model Documentation for
     * FrontEndControllerOperation.exposed
     * @return (boolean)handleIsExposed()
     */
    public final boolean isExposed()
    {
        boolean exposed11a = false;
        // exposed has no pre constraints
        exposed11a = handleIsExposed();
        // exposed has no post constraints
        return exposed11a;
    }

   /**
    * @see FrontEndControllerOperation#getRestPath()
    * @return String
    */
    protected abstract String handleGetRestPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetRestPath()
     */
    public final String getRestPath()
    {
        String restPath12a = null;
        // restPath has no pre constraints
        restPath12a = handleGetRestPath();
        // restPath has no post constraints
        return restPath12a;
    }

   /**
    * @see FrontEndControllerOperation#getAllowedRoles()
    * @return Collection
    */
    protected abstract Collection handleGetAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (Collection)handleGetAllowedRoles()
     */
    public final Collection getAllowedRoles()
    {
        Collection allowedRoles13a = null;
        // allowedRoles has no pre constraints
        allowedRoles13a = handleGetAllowedRoles();
        // allowedRoles has no post constraints
        return allowedRoles13a;
    }

    // ------------- associations ------------------

    private FrontEndActivityGraph __getActivityGraph1r;
    private boolean __getActivityGraph1rSet = false;

    /**
     * Represents an operation modeled on a controller.
     * @return (FrontEndActivityGraph)handleGetActivityGraph()
     */
    public final FrontEndActivityGraph getActivityGraph()
    {
        FrontEndActivityGraph getActivityGraph1r = this.__getActivityGraph1r;
        if (!this.__getActivityGraph1rSet)
        {
            // frontEndControllerOperation has no pre constraints
            Object result = handleGetActivityGraph();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getActivityGraph1r = (FrontEndActivityGraph)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerOperationLogic.logger.warn("incorrect metafacade cast for FrontEndControllerOperationLogic.getActivityGraph FrontEndActivityGraph " + result + ": " + shieldedResult);
            }
            // frontEndControllerOperation has no post constraints
            this.__getActivityGraph1r = getActivityGraph1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActivityGraph1rSet = true;
            }
        }
        return getActivityGraph1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetActivityGraph();

    private List<FrontEndParameter> __getFormFields2r;
    private boolean __getFormFields2rSet = false;

    /**
     * Gets the controller operation to which this parameter belongs.
     * @return (List<FrontEndParameter>)handleGetFormFields()
     */
    public final List<FrontEndParameter> getFormFields()
    {
        List<FrontEndParameter> getFormFields2r = this.__getFormFields2r;
        if (!this.__getFormFields2rSet)
        {
            // controllerOperation has no pre constraints
            List result = handleGetFormFields();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getFormFields2r = (List<FrontEndParameter>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerOperationLogic.logger.warn("incorrect metafacade cast for FrontEndControllerOperationLogic.getFormFields List<FrontEndParameter> " + result + ": " + shieldedResult);
            }
            // controllerOperation has no post constraints
            this.__getFormFields2r = getFormFields2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFormFields2rSet = true;
            }
        }
        return getFormFields2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetFormFields();

    private List<FrontEndAction> __getDeferringActions3r;
    private boolean __getDeferringActions3rSet = false;

    /**
     * The controller operations to which this action defers, the order is preserved.
     * @return (List<FrontEndAction>)handleGetDeferringActions()
     */
    public final List<FrontEndAction> getDeferringActions()
    {
        List<FrontEndAction> getDeferringActions3r = this.__getDeferringActions3r;
        if (!this.__getDeferringActions3rSet)
        {
            // deferredOperations has no pre constraints
            List result = handleGetDeferringActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getDeferringActions3r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerOperationLogic.logger.warn("incorrect metafacade cast for FrontEndControllerOperationLogic.getDeferringActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // deferredOperations has no post constraints
            this.__getDeferringActions3r = getDeferringActions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferringActions3rSet = true;
            }
        }
        return getDeferringActions3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetDeferringActions();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndControllerOperation::all arguments need an event parameter</p>
     * <p><b>Error:</b> For each controller operation argument there must exist a parameter for each action deferring to
that operation. This parameter must carry the same name and must be of the same type.</p>
     * <p><b>OCL:</b> context FrontEndControllerOperation inv: allArgumentsHaveFormFields</p>
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndControllerOperation::the operation name may not be the same as the use-case name</p>
     * <p><b>Error:</b> It is not allowed to give a controller operation the same name as the use-case for which it is
defined, please either rename your operation or your use-case.</p>
     * <p><b>OCL:</b> context FrontEndControllerOperation inv: name <> owner.useCase.name</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see OperationFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLIntrospector.invoke(contextElement,"allArgumentsHaveFormFields"));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndControllerOperation::all arguments need an event parameter",
                        "For each controller operation argument there must exist a parameter for each action deferring to\nthat operation. This parameter must carry the same name and must be of the same type."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndControllerOperation::all arguments need an event parameter' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLExpressions.notEqual(OCLIntrospector.invoke(contextElement,"name"),OCLIntrospector.invoke(contextElement,"owner.useCase.name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndControllerOperation::the operation name may not be the same as the use-case name",
                        "It is not allowed to give a controller operation the same name as the use-case for which it is\ndefined, please either rename your operation or your use-case."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndControllerOperation::the operation name may not be the same as the use-case name' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}