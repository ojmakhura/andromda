// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.common.Introspector;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.TemplateParameterFacade;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.TemplateParameter;

/**
 * Represents a UML template parameter. Exposes a parameterable element as a formal template
 * parameter of a template. Only UML2 TemplateParameter inherits from ModelElement, so the UML14
 * implementation cannot extend ModelElement. UML14 TemplateParameter.parameter inherits from
 * Parameter.
 * MetafacadeLogic for TemplateParameterFacade
 *
 * @see TemplateParameterFacade
 */
public abstract class TemplateParameterFacadeLogic
    extends MetafacadeBase
    implements TemplateParameterFacade
{
    /**
     * The underlying UML object
     * @see TemplateParameter
     */
    protected TemplateParameter metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected TemplateParameterFacadeLogic(TemplateParameter metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(TemplateParameterFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to TemplateParameterFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TemplateParameterFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see TemplateParameterFacade
     */
    public boolean isTemplateParameterFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see TemplateParameterFacade#getType()
    * @return ClassifierFacade
    */
    protected abstract ClassifierFacade handleGetType();

    /**
     * TemplateParameter may be of type Classifier, PackageableElement,
     * Operation or Property. Generally a Class parameter has a name and a type of Classifier.
     * @return (ClassifierFacade)handleGetType()
     */
    public final ClassifierFacade getType()
    {
        ClassifierFacade type1a = null;
        // type has no pre constraints
        type1a = handleGetType();
        // type has no post constraints
        return type1a;
    }

   /**
    * @see TemplateParameterFacade#getName()
    * @return String
    */
    protected abstract String handleGetName();

    /**
     * TODO: Model Documentation for TemplateParameterFacade.name
     * @return (String)handleGetName()
     */
    public final String getName()
    {
        String name2a = null;
        // name has no pre constraints
        name2a = handleGetName();
        // name has no post constraints
        return name2a;
    }

   /**
    * @see TemplateParameterFacade#getFullyQualifiedName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedName();

    /**
     * Return the fully qualified name of the template parameter: package + class + parameter name
     * @return (String)handleGetFullyQualifiedName()
     */
    public final String getFullyQualifiedName()
    {
        String fullyQualifiedName3a = null;
        // fullyQualifiedName has no pre constraints
        fullyQualifiedName3a = handleGetFullyQualifiedName();
        // fullyQualifiedName has no post constraints
        return fullyQualifiedName3a;
    }

   /**
    * @see TemplateParameterFacade#getGetterSetterTypeName()
    * @return String
    */
    protected abstract String handleGetGetterSetterTypeName();

    /**
     * The type of the template parameter.
     * @return (String)handleGetGetterSetterTypeName()
     */
    public final String getGetterSetterTypeName()
    {
        String getterSetterTypeName4a = null;
        // getterSetterTypeName has no pre constraints
        getterSetterTypeName4a = handleGetGetterSetterTypeName();
        // getterSetterTypeName has no post constraints
        return getterSetterTypeName4a;
    }

   /**
    * @see TemplateParameterFacade#getGetterName()
    * @return String
    */
    protected abstract String handleGetGetterName();

    /**
     * get + capitalized parameter name
     * @return (String)handleGetGetterName()
     */
    public final String getGetterName()
    {
        String getterName5a = null;
        // getterName has no pre constraints
        getterName5a = handleGetGetterName();
        // getterName has no post constraints
        return getterName5a;
    }

   /**
    * @see TemplateParameterFacade#getSetterName()
    * @return String
    */
    protected abstract String handleGetSetterName();

    /**
     * set + capitalized parameter name
     * @return (String)handleGetSetterName()
     */
    public final String getSetterName()
    {
        String setterName6a = null;
        // setterName has no pre constraints
        setterName6a = handleGetSetterName();
        // setterName has no post constraints
        return setterName6a;
    }

   /**
    * @see TemplateParameterFacade#getOwner()
    * @return ModelElementFacade
    */
    protected abstract ModelElementFacade handleGetOwner();

    /**
     * The ModelElement that owns this parameter. For UML14, the classifier package. For UML2, the
     * Classifier.
     * @return (ModelElementFacade)handleGetOwner()
     */
    public final ModelElementFacade getOwner()
    {
        ModelElementFacade owner7a = null;
        // owner has no pre constraints
        owner7a = handleGetOwner();
        // owner has no post constraints
        return owner7a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Gets the documentation for the model element, The indent argument is prefixed to each line.
     * By default this method wraps lines after 64 characters.
     * This method is equivalent to <code>getDocumentation(indent, 64)</code>.
     * @param indent
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent);

    /**
     * Gets the documentation for the model element, The indent argument is prefixed to each line.
     * By default this method wraps lines after 64 characters.
     * This method is equivalent to <code>getDocumentation(indent, 64)</code>.
     * @param indent String
     * <p>Specifies the amount to indent by.</p>
     * @return handleGetDocumentation(indent)
     */
    public String getDocumentation(String indent)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent);
        // getDocumentation has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. By default paragraphs are returned as HTML.
     * This method is equivalent to <code>getDocumentation(indent, lineLength, true)</code>.
     * @param indent
     * @param lineLength
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent, int lineLength);

    /**
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. By default paragraphs are returned as HTML.
     * This method is equivalent to <code>getDocumentation(indent, lineLength, true)</code>.
     * @param indent String
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation(indent)
     * @param lineLength int
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation(lineLength)
     * @return handleGetDocumentation(indent, lineLength)
     */
    public String getDocumentation(String indent, int lineLength)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent, lineLength);
        // getDocumentation has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation
     * @param indent
     * @param lineLength
     * @param htmlStyle
     * @return String
     */
    protected abstract String handleGetDocumentation(String indent, int lineLength, boolean htmlStyle);

    /**
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation
     * @param indent String
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation(indent)
     * @param lineLength int
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation(lineLength)
     * @param htmlStyle boolean
     * TODO: Model Documentation for
     * TemplateParameterFacade.getDocumentation(htmlStyle)
     * @return handleGetDocumentation(indent, lineLength, htmlStyle)
     */
    public String getDocumentation(String indent, int lineLength, boolean htmlStyle)
    {
        // getDocumentation has no pre constraints
        String returnValue = handleGetDocumentation(indent, lineLength, htmlStyle);
        // getDocumentation has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * Represents a UML template parameter. Exposes a parameterable element as a formal template
     * parameter
     * of a template. Only UML2 TemplateParameter inherits from ModelElement, so the UML14
     * implementation
     * cannot extend ModelElement. UML14 TemplateParameter.parameter inherits from Parameter.
     * @return (ModelElementFacade)handleGetDefaultElement()
     */
    public final ModelElementFacade getDefaultElement()
    {
        ModelElementFacade getDefaultElement1r = null;
        // templateParameterFacade has no pre constraints
        Object result = handleGetDefaultElement();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getDefaultElement1r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TemplateParameterFacadeLogic.logger.warn("incorrect metafacade cast for TemplateParameterFacadeLogic.getDefaultElement ModelElementFacade " + result + ": " + shieldedResult);
        }
        // templateParameterFacade has no post constraints
        return getDefaultElement1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetDefaultElement();

    /**
     * Represents a UML template parameter. Exposes a parameterable element as a formal template
     * parameter
     * of a template. Only UML2 TemplateParameter inherits from ModelElement, so the UML14
     * implementation
     * cannot extend ModelElement. UML14 TemplateParameter.parameter inherits from Parameter.
     * @return (ModelElementFacade)handleGetParameter()
     */
    public final ModelElementFacade getParameter()
    {
        ModelElementFacade getParameter2r = null;
        // templateParameterFacade has no pre constraints
        Object result = handleGetParameter();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getParameter2r = (ModelElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TemplateParameterFacadeLogic.logger.warn("incorrect metafacade cast for TemplateParameterFacadeLogic.getParameter ModelElementFacade " + result + ": " + shieldedResult);
        }
        // templateParameterFacade has no post constraints
        return getParameter2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetParameter();

    /**
     * Represents a UML template parameter. Exposes a parameterable element as a formal template
     * parameter
     * of a template. Only UML2 TemplateParameter inherits from ModelElement, so the UML14
     * implementation
     * cannot extend ModelElement. UML14 TemplateParameter.parameter inherits from Parameter.
     * @return (Collection<ClassifierFacade>)handleGetConstrainingClassifiers()
     */
    public final Collection<ClassifierFacade> getConstrainingClassifiers()
    {
        Collection<ClassifierFacade> getConstrainingClassifiers3r = null;
        // templateParameterFacade has no pre constraints
        Collection result = handleGetConstrainingClassifiers();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getConstrainingClassifiers3r = (Collection<ClassifierFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            TemplateParameterFacadeLogic.logger.warn("incorrect metafacade cast for TemplateParameterFacadeLogic.getConstrainingClassifiers Collection<ClassifierFacade> " + result + ": " + shieldedResult);
        }
        // templateParameterFacade has no post constraints
        return getConstrainingClassifiers3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetConstrainingClassifiers();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::TemplateParameterFacade::template parameter type must be specified</p>
     * <p><b>Error:</b> Template Parameter type must be specified.</p>
     * <p><b>OCL:</b> context TemplateParameterFacade inv: type.name->notEmpty()</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see MetafacadeBase#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"type.name")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::TemplateParameterFacade::template parameter type must be specified",
                        "Template Parameter type must be specified."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::TemplateParameterFacade::template parameter type must be specified' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }

    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    private static final String FQNAME_PROPERTY = "fullyQualifiedName";

    /**
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuilder toString = new StringBuilder(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(Introspector.instance().getProperty(this, FQNAME_PROPERTY));
        }
        catch (final Throwable tryAgain)
        {
            try
            {
                toString.append(Introspector.instance().getProperty(this, NAME_PROPERTY));
            }
            catch (final Throwable ignore)
            {
                // - just ignore when the metafacade doesn't have a name or fullyQualifiedName property
            }
        }
        toString.append("]");
        return toString.toString();
    }
}