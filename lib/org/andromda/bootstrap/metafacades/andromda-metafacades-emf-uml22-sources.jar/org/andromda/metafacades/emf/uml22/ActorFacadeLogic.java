// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ActorFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Actor;

/**
 * An actor specifies a role played by a user or any other system that interacts with the subject.
 * MetafacadeLogic for ActorFacade
 *
 * @see ActorFacade
 */
public abstract class ActorFacadeLogic
    extends ClassifierFacadeLogicImpl
    implements ActorFacade
{
    /**
     * The underlying UML object
     * @see Actor
     */
    protected Actor metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected ActorFacadeLogic(Actor metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(ActorFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to ActorFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActorFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see ActorFacade
     */
    public boolean isActorFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    private List<ActorFacade> __getGeneralizedByActors1r;
    private boolean __getGeneralizedByActors1rSet = false;

    /**
     * All actors generalized by this actor.
     * @return (List<ActorFacade>)handleGetGeneralizedByActors()
     */
    public final List<ActorFacade> getGeneralizedByActors()
    {
        List<ActorFacade> getGeneralizedByActors1r = this.__getGeneralizedByActors1r;
        if (!this.__getGeneralizedByActors1rSet)
        {
            // generalizedActors has no pre constraints
             List result = handleGetGeneralizedByActors();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getGeneralizedByActors1r = (List<ActorFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ActorFacadeLogic.logger.warn("incorrect metafacade cast for ActorFacadeLogic.getGeneralizedByActors List<ActorFacade> " + result + ": " + shieldedResult);
            }
            // generalizedActors has no post constraints
            this.__getGeneralizedByActors1r = getGeneralizedByActors1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getGeneralizedByActors1rSet = true;
            }
        }
        return getGeneralizedByActors1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetGeneralizedByActors();

    private List<ActorFacade> __getGeneralizedActors2r;
    private boolean __getGeneralizedActors2rSet = false;

    /**
     * The set of actors that generalize this actor.
     * @return (List<ActorFacade>)handleGetGeneralizedActors()
     */
    public final List<ActorFacade> getGeneralizedActors()
    {
        List<ActorFacade> getGeneralizedActors2r = this.__getGeneralizedActors2r;
        if (!this.__getGeneralizedActors2rSet)
        {
            // generalizedByActors has no pre constraints
             List result = handleGetGeneralizedActors();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getGeneralizedActors2r = (List<ActorFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                ActorFacadeLogic.logger.warn("incorrect metafacade cast for ActorFacadeLogic.getGeneralizedActors List<ActorFacade> " + result + ": " + shieldedResult);
            }
            // generalizedByActors has no post constraints
            this.__getGeneralizedActors2r = getGeneralizedActors2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getGeneralizedActors2rSet = true;
            }
        }
        return getGeneralizedActors2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetGeneralizedActors();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}