// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndPseudostate;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Pseudostate;

/**
 * Encapsulates a pseudostate and provides specific front-end services. This pseudostate can be a
 * decision point, junction or initial state.
 * MetafacadeLogic for FrontEndPseudostate
 *
 * @see FrontEndPseudostate
 */
public abstract class FrontEndPseudostateLogic
    extends PseudostateFacadeLogicImpl
    implements FrontEndPseudostate
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndPseudostateLogic(Object metaObjectIn, String context)
    {
        super((Pseudostate)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndPseudostateLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndPseudostate if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndPseudostate";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndPseudostate
     */
    public boolean isFrontEndPseudostateMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndPseudostate#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * Indicates if this "front-end" pseudo date is contained within a "front-end" use case.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private List<FrontEndAction> __getContainerActions1r;
    private boolean __getContainerActions1rSet = false;

    /**
     * Encapsulates a pseudostate and provides specific front-end services. This pseudostate can be
     * a
     * decision point, junction or initial state.
     * @return (List<FrontEndAction>)handleGetContainerActions()
     */
    public final List<FrontEndAction> getContainerActions()
    {
        List<FrontEndAction> getContainerActions1r = this.__getContainerActions1r;
        if (!this.__getContainerActions1rSet)
        {
            // frontEndPseudostate has no pre constraints
             List result = handleGetContainerActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getContainerActions1r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndPseudostateLogic.logger.warn("incorrect metafacade cast for FrontEndPseudostateLogic.getContainerActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // frontEndPseudostate has no post constraints
            this.__getContainerActions1r = getContainerActions1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getContainerActions1rSet = true;
            }
        }
        return getContainerActions1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetContainerActions();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see PseudostateFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}