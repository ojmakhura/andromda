// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndExceptionHandler;

/**
 * A front-end exception handler intercepts exceptions and delegates them into a front-end action
 * state that will handle it (for example by simply displaying it if the action state happened to be
 * a view) .
 * MetafacadeLogic for FrontEndExceptionHandler
 *
 * @see FrontEndExceptionHandler
 */
public abstract class FrontEndExceptionHandlerLogic
    extends FrontEndForwardLogicImpl
    implements FrontEndExceptionHandler
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndExceptionHandlerLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndExceptionHandler if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndExceptionHandler";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndExceptionHandler
     */
    public boolean isFrontEndExceptionHandlerMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndExceptionHandler#isFrontEndException()
    * @return boolean
    */
    protected abstract boolean handleIsFrontEndException();

    /**
     * Indicatesif this element carries the FrontEndException stereotype.
     * @return (boolean)handleIsFrontEndException()
     */
    public final boolean isFrontEndException()
    {
        boolean frontEndException1a = false;
        // frontEndException has no pre constraints
        frontEndException1a = handleIsFrontEndException();
        // frontEndException has no post constraints
        return frontEndException1a;
    }

    // ------------- associations ------------------

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see FrontEndForwardLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}