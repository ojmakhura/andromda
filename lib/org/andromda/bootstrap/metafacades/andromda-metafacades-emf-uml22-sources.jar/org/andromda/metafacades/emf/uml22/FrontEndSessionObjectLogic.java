// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndSessionObject;
import org.eclipse.uml2.uml.Classifier;

/**
 * Represents a JSF session object (a session object is an object that is stored in the session
 * during application execution).
 * MetafacadeLogic for FrontEndSessionObject
 *
 * @see FrontEndSessionObject
 */
public abstract class FrontEndSessionObjectLogic
    extends ClassifierFacadeLogicImpl
    implements FrontEndSessionObject
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndSessionObjectLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndSessionObject if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndSessionObject";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndSessionObject
     */
    public boolean isFrontEndSessionObjectMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndSessionObject#getFullPath()
    * @return String
    */
    protected abstract String handleGetFullPath();

    /**
     * The full path to the session object file name.
     * @return (String)handleGetFullPath()
     */
    public final String getFullPath()
    {
        String fullPath1a = null;
        // fullPath has no pre constraints
        fullPath1a = handleGetFullPath();
        // fullPath has no post constraints
        return fullPath1a;
    }

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}