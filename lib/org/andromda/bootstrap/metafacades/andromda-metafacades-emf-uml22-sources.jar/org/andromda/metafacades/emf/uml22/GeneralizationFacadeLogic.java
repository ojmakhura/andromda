// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.GeneralizableElementFacade;
import org.andromda.metafacades.uml.GeneralizationFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Generalization;

/**
 * A taxonomic relationship between a more general classifier and a more specific classifier. Each
 * instance of the specific classifier is also an indirect instance of the general classifier. Thus,
 * the specific classifier inherits the features of the more general classifier. A generalization
 * relates a specific classifier to a more general classifier, and is owned by the specific
 * classifier.
 * MetafacadeLogic for GeneralizationFacade
 *
 * @see GeneralizationFacade
 */
public abstract class GeneralizationFacadeLogic
    extends ModelElementFacadeLogicImpl
    implements GeneralizationFacade
{
    /**
     * The underlying UML object
     * @see Generalization
     */
    protected Generalization metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected GeneralizationFacadeLogic(Generalization metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(GeneralizationFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to GeneralizationFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizationFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see GeneralizationFacade
     */
    public boolean isGeneralizationFacadeMetaType()
    {
        return true;
    }

    // ------------- associations ------------------

    /**
     * A taxonomic relationship between a more general classifier and a more specific classifier.
     * Each
     * instance of the specific classifier is also an indirect instance of the general classifier.
     * Thus,
     * the specific classifier inherits the features of the more general classifier. A
     * generalization
     * relates a specific classifier to a more general classifier, and is owned by the specific
     * classifier.
     * @return (GeneralizableElementFacade)handleGetParent()
     */
    public final GeneralizableElementFacade getParent()
    {
        GeneralizableElementFacade getParent1r = null;
        // generalizationFacade has no pre constraints
        Object result = handleGetParent();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getParent1r = (GeneralizableElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizationFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizationFacadeLogic.getParent GeneralizableElementFacade " + result + ": " + shieldedResult);
        }
        // generalizationFacade has no post constraints
        return getParent1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetParent();

    /**
     * A taxonomic relationship between a more general classifier and a more specific classifier.
     * Each
     * instance of the specific classifier is also an indirect instance of the general classifier.
     * Thus,
     * the specific classifier inherits the features of the more general classifier. A
     * generalization
     * relates a specific classifier to a more general classifier, and is owned by the specific
     * classifier.
     * @return (GeneralizableElementFacade)handleGetChild()
     */
    public final GeneralizableElementFacade getChild()
    {
        GeneralizableElementFacade getChild2r = null;
        // generalizationFacade has no pre constraints
        Object result = handleGetChild();
        MetafacadeBase shieldedResult = this.shieldedElement(result);
        try
        {
            getChild2r = (GeneralizableElementFacade)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            GeneralizationFacadeLogic.logger.warn("incorrect metafacade cast for GeneralizationFacadeLogic.getChild GeneralizableElementFacade " + result + ": " + shieldedResult);
        }
        // generalizationFacade has no post constraints
        return getChild2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetChild();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ModelElementFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}