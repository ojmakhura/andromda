// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndController;
import org.andromda.metafacades.uml.FrontEndControllerOperation;
import org.andromda.metafacades.uml.FrontEndUseCase;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.Classifier;

/**
 * A front end controller is assigned as the context of a use-case. The controller provides the
 * "controlling" of the use case's activity.
 * MetafacadeLogic for FrontEndController
 *
 * @see FrontEndController
 */
public abstract class FrontEndControllerLogic
    extends ClassifierFacadeLogicImpl
    implements FrontEndController
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndControllerLogic(Object metaObjectIn, String context)
    {
        super((Classifier)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndControllerLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndController if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndController";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndController
     */
    public boolean isFrontEndControllerMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndController#getImplementationName()
    * @return String
    */
    protected abstract String handleGetImplementationName();

    /**
     * The implementation name of this controller.
     * @return (String)handleGetImplementationName()
     */
    public final String getImplementationName()
    {
        String implementationName1a = null;
        // implementationName has no pre constraints
        implementationName1a = handleGetImplementationName();
        // implementationName has no post constraints
        return implementationName1a;
    }

   /**
    * @see FrontEndController#getFullyQualifiedImplementationName()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedImplementationName();

    /**
     * The fully qualified implementation name of this controller.
     * @return (String)handleGetFullyQualifiedImplementationName()
     */
    public final String getFullyQualifiedImplementationName()
    {
        String fullyQualifiedImplementationName2a = null;
        // fullyQualifiedImplementationName has no pre constraints
        fullyQualifiedImplementationName2a = handleGetFullyQualifiedImplementationName();
        // fullyQualifiedImplementationName has no post constraints
        return fullyQualifiedImplementationName2a;
    }

   /**
    * @see FrontEndController#getFullyQualifiedImplementationPath()
    * @return String
    */
    protected abstract String handleGetFullyQualifiedImplementationPath();

    /**
     * The fully qualified path to the controller implemention file.
     * @return (String)handleGetFullyQualifiedImplementationPath()
     */
    public final String getFullyQualifiedImplementationPath()
    {
        String fullyQualifiedImplementationPath3a = null;
        // fullyQualifiedImplementationPath has no pre constraints
        fullyQualifiedImplementationPath3a = handleGetFullyQualifiedImplementationPath();
        // fullyQualifiedImplementationPath has no post constraints
        return fullyQualifiedImplementationPath3a;
    }

   /**
    * @see FrontEndController#getBeanName()
    * @return String
    */
    protected abstract String handleGetBeanName();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetBeanName()
     */
    public final String getBeanName()
    {
        String beanName4a = null;
        // beanName has no pre constraints
        beanName4a = handleGetBeanName();
        // beanName has no post constraints
        return beanName4a;
    }

   /**
    * @see FrontEndController#getControllerSerialVersionUID()
    * @return String
    */
    protected abstract String handleGetControllerSerialVersionUID();

    /**
     * The calculated serial version UID for this controller.
     * @return (String)handleGetControllerSerialVersionUID()
     */
    public final String getControllerSerialVersionUID()
    {
        String controllerSerialVersionUID5a = null;
        // controllerSerialVersionUID has no pre constraints
        controllerSerialVersionUID5a = handleGetControllerSerialVersionUID();
        // controllerSerialVersionUID has no post constraints
        return controllerSerialVersionUID5a;
    }

   /**
    * @see FrontEndController#getAllServices()
    * @return Collection
    */
    protected abstract Collection handleGetAllServices();

    /**
     * All services the controller needs.
     * @return (Collection)handleGetAllServices()
     */
    public final Collection getAllServices()
    {
        Collection allServices6a = null;
        // allServices has no pre constraints
        allServices6a = handleGetAllServices();
        // allServices has no post constraints
        return allServices6a;
    }

   /**
    * @see FrontEndController#getPath()
    * @return String
    */
    protected abstract String handleGetPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetPath()
     */
    public final String getPath()
    {
        String path7a = null;
        // path has no pre constraints
        path7a = handleGetPath();
        // path has no post constraints
        return path7a;
    }

   /**
    * @see FrontEndController#getRestPath()
    * @return String
    */
    protected abstract String handleGetRestPath();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetRestPath()
     */
    public final String getRestPath()
    {
        String restPath8a = null;
        // restPath has no pre constraints
        restPath8a = handleGetRestPath();
        // restPath has no post constraints
        return restPath8a;
    }

   /**
    * @see FrontEndController#getFilename()
    * @return String
    */
    protected abstract String handleGetFilename();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetFilename()
     */
    public final String getFilename()
    {
        String filename9a = null;
        // filename has no pre constraints
        filename9a = handleGetFilename();
        // filename has no post constraints
        return filename9a;
    }

   /**
    * @see FrontEndController#getTargetUrl()
    * @return String
    */
    protected abstract String handleGetTargetUrl();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (String)handleGetTargetUrl()
     */
    public final String getTargetUrl()
    {
        String targetUrl10a = null;
        // targetUrl has no pre constraints
        targetUrl10a = handleGetTargetUrl();
        // targetUrl has no post constraints
        return targetUrl10a;
    }

   /**
    * @see FrontEndController#getAllowedRoles()
    * @return Collection
    */
    protected abstract Collection handleGetAllowedRoles();

    /**
     * The bean name of this controller (this is what is stored in the JSF configuration file).
     * @return (Collection)handleGetAllowedRoles()
     */
    public final Collection getAllowedRoles()
    {
        Collection allowedRoles11a = null;
        // allowedRoles has no pre constraints
        allowedRoles11a = handleGetAllowedRoles();
        // allowedRoles has no post constraints
        return allowedRoles11a;
    }

    // ------------- associations ------------------

    private FrontEndUseCase __getUseCase1r;
    private boolean __getUseCase1rSet = false;

    /**
     * Returns the controller for this use-case.
     * @return (FrontEndUseCase)handleGetUseCase()
     */
    public final FrontEndUseCase getUseCase()
    {
        FrontEndUseCase getUseCase1r = this.__getUseCase1r;
        if (!this.__getUseCase1rSet)
        {
            // controller has no pre constraints
            Object result = handleGetUseCase();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getUseCase1r = (FrontEndUseCase)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getUseCase FrontEndUseCase " + result + ": " + shieldedResult);
            }
            // controller has no post constraints
            this.__getUseCase1r = getUseCase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase1rSet = true;
            }
        }
        return getUseCase1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetUseCase();

    private List<DependencyFacade> __getServiceReferences2r;
    private boolean __getServiceReferences2rSet = false;

    /**
     * A front end controller is assigned as the context of a use-case. The controller provides the
     * "controlling" of the use case's activity.
     * @return (List<DependencyFacade>)handleGetServiceReferences()
     */
    public final List<DependencyFacade> getServiceReferences()
    {
        List<DependencyFacade> getServiceReferences2r = this.__getServiceReferences2r;
        if (!this.__getServiceReferences2rSet)
        {
            // frontEndController has no pre constraints
             List result = handleGetServiceReferences();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getServiceReferences2r = (List<DependencyFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getServiceReferences List<DependencyFacade> " + result + ": " + shieldedResult);
            }
            // frontEndController has no post constraints
            this.__getServiceReferences2r = getServiceReferences2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getServiceReferences2rSet = true;
            }
        }
        return getServiceReferences2r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetServiceReferences();

    private List<FrontEndAction> __getDeferringActions3r;
    private boolean __getDeferringActions3rSet = false;

    /**
     * The controller that will handle the execution of this front-end action. This controller is
     * set as the context of the activity graph (and therefore also of the use-case).
     * @return (List<FrontEndAction>)handleGetDeferringActions()
     */
    public final List<FrontEndAction> getDeferringActions()
    {
        List<FrontEndAction> getDeferringActions3r = this.__getDeferringActions3r;
        if (!this.__getDeferringActions3rSet)
        {
            // controller has no pre constraints
             List result = handleGetDeferringActions();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getDeferringActions3r = (List<FrontEndAction>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getDeferringActions List<FrontEndAction> " + result + ": " + shieldedResult);
            }
            // controller has no post constraints
            this.__getDeferringActions3r = getDeferringActions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferringActions3rSet = true;
            }
        }
        return getDeferringActions3r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  List
     */
    protected abstract List handleGetDeferringActions();

    private Collection<FrontEndControllerOperation> __getAllowedOperations4r;
    private boolean __getAllowedOperations4rSet = false;

    /**
     * A front end controller is assigned as the context of a use-case. The controller provides the
     * "controlling" of the use case's activity.
     * @return (Collection<FrontEndControllerOperation>)handleGetAllowedOperations()
     */
    public final Collection<FrontEndControllerOperation> getAllowedOperations()
    {
        Collection<FrontEndControllerOperation> getAllowedOperations4r = this.__getAllowedOperations4r;
        if (!this.__getAllowedOperations4rSet)
        {
            // frontEndController has no pre constraints
             Collection result = handleGetAllowedOperations();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getAllowedOperations4r = (Collection<FrontEndControllerOperation>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getAllowedOperations Collection<FrontEndControllerOperation> " + result + ": " + shieldedResult);
            }
            // frontEndController has no post constraints
            this.__getAllowedOperations4r = getAllowedOperations4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllowedOperations4rSet = true;
            }
        }
        return getAllowedOperations4r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetAllowedOperations();

    private Collection<DependencyFacade> __getSessionObjectReferences5r;
    private boolean __getSessionObjectReferences5rSet = false;

    /**
     * A front end controller is assigned as the context of a use-case. The controller provides the
     * "controlling" of the use case's activity.
     * @return (Collection<DependencyFacade>)handleGetSessionObjectReferences()
     */
    public final Collection<DependencyFacade> getSessionObjectReferences()
    {
        Collection<DependencyFacade> getSessionObjectReferences5r = this.__getSessionObjectReferences5r;
        if (!this.__getSessionObjectReferences5rSet)
        {
            // frontEndController has no pre constraints
             Collection result = handleGetSessionObjectReferences();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getSessionObjectReferences5r = (Collection<DependencyFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getSessionObjectReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
            }
            // frontEndController has no post constraints
            this.__getSessionObjectReferences5r = getSessionObjectReferences5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getSessionObjectReferences5rSet = true;
            }
        }
        return getSessionObjectReferences5r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetSessionObjectReferences();

    private Collection<DependencyFacade> __getServicesPackagesReferences6r;
    private boolean __getServicesPackagesReferences6rSet = false;

    /**
     * A front end controller is assigned as the context of a use-case. The controller provides the
     * "controlling" of the use case's activity.
     * @return (Collection<DependencyFacade>)handleGetServicesPackagesReferences()
     */
    public final Collection<DependencyFacade> getServicesPackagesReferences()
    {
        Collection<DependencyFacade> getServicesPackagesReferences6r = this.__getServicesPackagesReferences6r;
        if (!this.__getServicesPackagesReferences6rSet)
        {
            // frontEndController has no pre constraints
             Collection result = handleGetServicesPackagesReferences();
            List shieldedResult = this.shieldedElements(result);
            try
            {
                getServicesPackagesReferences6r = (Collection<DependencyFacade>)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndControllerLogic.logger.warn("incorrect metafacade cast for FrontEndControllerLogic.getServicesPackagesReferences Collection<DependencyFacade> " + result + ": " + shieldedResult);
            }
            // frontEndController has no post constraints
            this.__getServicesPackagesReferences6r = getServicesPackagesReferences6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getServicesPackagesReferences6rSet = true;
            }
        }
        return getServicesPackagesReferences6r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetServicesPackagesReferences();

    /**
     * <p><b>Constraint:</b> org::andromda::metafacades::uml::FrontEndController::front-end controllers need a package</p>
     * <p><b>Error:</b> Each front-end controller is required to be modeled in a package, doing otherwise will result in
uncompileable code due to filename collisions.</p>
     * <p><b>OCL:</b> context FrontEndController inv: packageName->notEmpty()</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ClassifierFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.notEmpty(OCLIntrospector.invoke(contextElement,"packageName")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndController::front-end controllers need a package",
                        "Each front-end controller is required to be modeled in a package, doing otherwise will result in\nuncompileable code due to filename collisions."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::metafacades::uml::FrontEndController::front-end controllers need a package' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }
}