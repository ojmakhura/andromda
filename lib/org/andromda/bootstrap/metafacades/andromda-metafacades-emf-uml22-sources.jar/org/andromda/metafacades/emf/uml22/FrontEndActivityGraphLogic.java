// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.FrontEndAction;
import org.andromda.metafacades.uml.FrontEndActivityGraph;
import org.andromda.metafacades.uml.FrontEndController;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.StateMachine;

/**
 * Represents the activity graph describing the details of a presentation tier or "front end" use
 * case.
 * MetafacadeLogic for FrontEndActivityGraph
 *
 * @see FrontEndActivityGraph
 */
public abstract class FrontEndActivityGraphLogic
    extends ActivityGraphFacadeLogicImpl
    implements FrontEndActivityGraph
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected FrontEndActivityGraphLogic(Object metaObjectIn, String context)
    {
        super((StateMachine)metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(FrontEndActivityGraphLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to FrontEndActivityGraph if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndActivityGraph";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see FrontEndActivityGraph
     */
    public boolean isFrontEndActivityGraphMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see FrontEndActivityGraph#isContainedInFrontEndUseCase()
    * @return boolean
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    /**
     * True if this element is contained in a FrontEndUseCase.
     * @return (boolean)handleIsContainedInFrontEndUseCase()
     */
    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = false;
        // containedInFrontEndUseCase has no pre constraints
        containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
        // containedInFrontEndUseCase has no post constraints
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private FrontEndController __getController1r;
    private boolean __getController1rSet = false;

    /**
     * Represents the activity graph describing the details of a presentation tier or "front end"
     * use case.
     * @return (FrontEndController)handleGetController()
     */
    public final FrontEndController getController()
    {
        FrontEndController getController1r = this.__getController1r;
        if (!this.__getController1rSet)
        {
            // frontEndActivityGraph has no pre constraints
            Object result = handleGetController();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getController1r = (FrontEndController)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActivityGraphLogic.logger.warn("incorrect metafacade cast for FrontEndActivityGraphLogic.getController FrontEndController " + result + ": " + shieldedResult);
            }
            // frontEndActivityGraph has no post constraints
            this.__getController1r = getController1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController1rSet = true;
            }
        }
        return getController1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetController();

    private FrontEndAction __getInitialAction2r;
    private boolean __getInitialAction2rSet = false;

    /**
     * Represents the activity graph describing the details of a presentation tier or "front end"
     * use case.
     * @return (FrontEndAction)handleGetInitialAction()
     */
    public final FrontEndAction getInitialAction()
    {
        FrontEndAction getInitialAction2r = this.__getInitialAction2r;
        if (!this.__getInitialAction2rSet)
        {
            // frontEndActivityGraph has no pre constraints
            Object result = handleGetInitialAction();
            MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getInitialAction2r = (FrontEndAction)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                FrontEndActivityGraphLogic.logger.warn("incorrect metafacade cast for FrontEndActivityGraphLogic.getInitialAction FrontEndAction " + result + ": " + shieldedResult);
            }
            // frontEndActivityGraph has no post constraints
            this.__getInitialAction2r = getInitialAction2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialAction2rSet = true;
            }
        }
        return getInitialAction2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetInitialAction();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see ActivityGraphFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}