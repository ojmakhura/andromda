// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.metafacades.emf.uml22;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.BindingFacade;
import org.andromda.metafacades.uml.TemplateArgumentFacade;
import org.apache.log4j.Logger;
import org.eclipse.uml2.uml.TemplateBinding;

/**
 * A representation of the model object 'Template Binding'. Represents a relationship between a
 * templateable element and a template. Specifies the substitutions of actual parameters for the
 * formal parameters of the template.
 * MetafacadeLogic for BindingFacade
 *
 * @see BindingFacade
 */
public abstract class BindingFacadeLogic
    extends DependencyFacadeLogicImpl
    implements BindingFacade
{
    /**
     * The underlying UML object
     * @see TemplateBinding
     */
    protected TemplateBinding metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected BindingFacadeLogic(TemplateBinding metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(BindingFacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to BindingFacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.BindingFacade";
        }
        return context;
    }

    /** Reset context only for non-root metafacades
     * @param context
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
        }
    }

    /**
     * @return boolean true always
     * @see BindingFacade
     */
    public boolean isBindingFacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see BindingFacade#getArgumentsString()
    * @return String
    */
    protected abstract String handleGetArgumentsString();

    /**
     * TODO: Model Documentation for BindingFacade.argumentsString
     * @return (String)handleGetArgumentsString()
     */
    public final String getArgumentsString()
    {
        String argumentsString1a = null;
        // argumentsString has no pre constraints
        argumentsString1a = handleGetArgumentsString();
        // argumentsString has no post constraints
        return argumentsString1a;
    }

   /**
    * @see BindingFacade#getArgumentsMap()
    * @return Map
    */
    protected abstract Map handleGetArgumentsMap();

    /**
     * TODO: Model Documentation for BindingFacade.argumentsMap
     * @return (Map)handleGetArgumentsMap()
     */
    public final Map getArgumentsMap()
    {
        Map argumentsMap2a = null;
        // argumentsMap has no pre constraints
        argumentsMap2a = handleGetArgumentsMap();
        // argumentsMap has no post constraints
        return argumentsMap2a;
    }

    // ------------- associations ------------------

    /**
     * A representation of the model object 'Template Binding'. Represents a relationship between a
     * templateable element and a template. Specifies the substitutions of actual parameters for the
     * formal
     * parameters of the template.
     * @return (Collection<TemplateArgumentFacade>)handleGetArguments()
     */
    public final Collection<TemplateArgumentFacade> getArguments()
    {
        Collection<TemplateArgumentFacade> getArguments1r = null;
        // bindingFacade has no pre constraints
         Collection result = handleGetArguments();
        List shieldedResult = this.shieldedElements(result);
        try
        {
            getArguments1r = (Collection<TemplateArgumentFacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            BindingFacadeLogic.logger.warn("incorrect metafacade cast for BindingFacadeLogic.getArguments Collection<TemplateArgumentFacade> " + result + ": " + shieldedResult);
        }
        // bindingFacade has no post constraints
        return getArguments1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  Collection
     */
    protected abstract Collection handleGetArguments();

    /**
     * @param validationMessages Collection<ModelValidationMessage>
     * @see DependencyFacadeLogicImpl#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}