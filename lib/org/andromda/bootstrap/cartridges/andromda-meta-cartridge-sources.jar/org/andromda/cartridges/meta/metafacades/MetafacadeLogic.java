// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify! ================
//
package org.andromda.cartridges.meta.metafacades;

import java.util.Collection;
import org.andromda.core.common.Introspector;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.MetafacadeFactory;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.apache.log4j.Logger;

/**
 * Facade for use in the andromda-meta cartridge. It hides a Classifier that represents a
 * <<metafacade>> object.
 * MetafacadeLogic for Metafacade
 *
 * @see Metafacade
 */
public abstract class MetafacadeLogic
    extends MetafacadeBase
    implements Metafacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected MetafacadeLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.superClassifierFacade =
           (org.andromda.metafacades.uml.ClassifierFacade)
            MetafacadeFactory.getInstance().createFacadeImpl(
                    "org.andromda.metafacades.uml.ClassifierFacade",
                    metaObjectIn,
                    getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(MetafacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to Metafacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.metafacades.Metafacade";
        }
        return context;
    }

    private org.andromda.metafacades.uml.ClassifierFacade superClassifierFacade;
    private boolean superClassifierFacadeInitialized = false;

    /**
     * Gets the org.andromda.metafacades.uml.ClassifierFacade parent instance.
     * @return this.superClassifierFacade org.andromda.metafacades.uml.ClassifierFacade
     */
    private org.andromda.metafacades.uml.ClassifierFacade getSuperClassifierFacade()
    {
        if (!this.superClassifierFacadeInitialized)
        {
            ((MetafacadeBase)this.superClassifierFacade).setMetafacadeContext(this.getMetafacadeContext());
            this.superClassifierFacadeInitialized = true;
        }
        return this.superClassifierFacade;
    }

    /** Reset context only for non-root metafacades
     * @param context
     * @see org.andromda.core.metafacade.MetafacadeBase#resetMetafacadeContext(String context)
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
            if (this.superClassifierFacadeInitialized)
            {
                ((MetafacadeBase)this.superClassifierFacade).resetMetafacadeContext(context);
            }
        }
    }

    /**
     * @return boolean true always
     * @see Metafacade
     */
    public boolean isMetafacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getLogicName()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetLogicName();

    /**
     * The name of the metafacade 'Logic' class.
     * @return (java.lang.String)handleGetLogicName()
     */
    public final java.lang.String getLogicName()
    {
        java.lang.String logicName1a = null;
        // logicName has no pre constraints
        logicName1a = handleGetLogicName();
        // logicName has no post constraints
        return logicName1a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getLogicImplName()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetLogicImplName();

    /**
     * The name of the 'Logic' implementation name.
     * @return (java.lang.String)handleGetLogicImplName()
     */
    public final java.lang.String getLogicImplName()
    {
        java.lang.String logicImplName2a = null;
        // logicImplName has no pre constraints
        logicImplName2a = handleGetLogicImplName();
        // logicImplName has no post constraints
        return logicImplName2a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#isMetaclassDirectDependency()
    * @return boolean
    */
    protected abstract boolean handleIsMetaclassDirectDependency();

    /**
     * True/false depending on whether or not this class's metaclass is a direct dependency (true)
     * or an inherited dependency (false).
     * @return (boolean)handleIsMetaclassDirectDependency()
     */
    public final boolean isMetaclassDirectDependency()
    {
        boolean metaclassDirectDependency3a = false;
        // metaclassDirectDependency has no pre constraints
        metaclassDirectDependency3a = handleIsMetaclassDirectDependency();
        // metaclassDirectDependency has no post constraints
        return metaclassDirectDependency3a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getFullyQualifiedLogicImplName()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetFullyQualifiedLogicImplName();

    /**
     * The fully qualified name for the implementation of the metafacade.
     * @return (java.lang.String)handleGetFullyQualifiedLogicImplName()
     */
    public final java.lang.String getFullyQualifiedLogicImplName()
    {
        java.lang.String fullyQualifiedLogicImplName4a = null;
        // fullyQualifiedLogicImplName has no pre constraints
        fullyQualifiedLogicImplName4a = handleGetFullyQualifiedLogicImplName();
        // fullyQualifiedLogicImplName has no post constraints
        return fullyQualifiedLogicImplName4a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getFullyQualifiedLogicName()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetFullyQualifiedLogicName();

    /**
     * The fully qualified name for the metafacade "Logic" class.
     * @return (java.lang.String)handleGetFullyQualifiedLogicName()
     */
    public final java.lang.String getFullyQualifiedLogicName()
    {
        java.lang.String fullyQualifiedLogicName5a = null;
        // fullyQualifiedLogicName has no pre constraints
        fullyQualifiedLogicName5a = handleGetFullyQualifiedLogicName();
        // fullyQualifiedLogicName has no post constraints
        return fullyQualifiedLogicName5a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getLogicFile()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetLogicFile();

    /**
     * The 'Logic' file location.
     * @return (java.lang.String)handleGetLogicFile()
     */
    public final java.lang.String getLogicFile()
    {
        java.lang.String logicFile6a = null;
        // logicFile has no pre constraints
        logicFile6a = handleGetLogicFile();
        // logicFile has no post constraints
        return logicFile6a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getLogicImplFile()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetLogicImplFile();

    /**
     * The 'Logic' implementation file location.
     * @return (java.lang.String)handleGetLogicImplFile()
     */
    public final java.lang.String getLogicImplFile()
    {
        java.lang.String logicImplFile7a = null;
        // logicImplFile has no pre constraints
        logicImplFile7a = handleGetLogicImplFile();
        // logicImplFile has no post constraints
        return logicImplFile7a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getLogicPackageName()
    * @return java.lang.String
    */
    protected abstract java.lang.String handleGetLogicPackageName();

    /**
     * The package name to which the 'Logic' metafacade classes are generated.
     * @return (java.lang.String)handleGetLogicPackageName()
     */
    public final java.lang.String getLogicPackageName()
    {
        java.lang.String logicPackageName8a = null;
        // logicPackageName has no pre constraints
        logicPackageName8a = handleGetLogicPackageName();
        // logicPackageName has no post constraints
        return logicPackageName8a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#isRequiresInheritanceDelegatation()
    * @return boolean
    */
    protected abstract boolean handleIsRequiresInheritanceDelegatation();

    /**
     * Indicates if the metafacade requires a delegate for inheritance instead of actual
     * inheritance.  This is true, when the metafacade is inheriting from a metafacade from a
     * different package (since that means it will most likely be a cartridge metafacade inheriting
     * from a set of shared metafacades for a meta model).
     * @return (boolean)handleIsRequiresInheritanceDelegatation()
     */
    public final boolean isRequiresInheritanceDelegatation()
    {
        boolean requiresInheritanceDelegatation9a = false;
        // requiresInheritanceDelegatation has no pre constraints
        requiresInheritanceDelegatation9a = handleIsRequiresInheritanceDelegatation();
        // requiresInheritanceDelegatation has no post constraints
        return requiresInheritanceDelegatation9a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#isConstructorRequiresMetaclassCast()
    * @return boolean
    */
    protected abstract boolean handleIsConstructorRequiresMetaclassCast();

    /**
     * Indicates if the meta class construct argument requires a cast to the super metafacade's
     * metaclass.
     * @return (boolean)handleIsConstructorRequiresMetaclassCast()
     */
    public final boolean isConstructorRequiresMetaclassCast()
    {
        boolean constructorRequiresMetaclassCast10a = false;
        // constructorRequiresMetaclassCast has no pre constraints
        constructorRequiresMetaclassCast10a = handleIsConstructorRequiresMetaclassCast();
        // constructorRequiresMetaclassCast has no post constraints
        return constructorRequiresMetaclassCast10a;
    }

   /**
    * @see org.andromda.cartridges.meta.metafacades.Metafacade#getGeneralizationCount()
    * @return int
    */
    protected abstract int handleGetGeneralizationCount();

    /**
     * The number of parents this metafacade has.
     * @return (int)handleGetGeneralizationCount()
     */
    public final int getGeneralizationCount()
    {
        int generalizationCount11a = 0;
        // generalizationCount has no pre constraints
        generalizationCount11a = handleGetGeneralizationCount();
        // generalizationCount has no post constraints
        return generalizationCount11a;
    }

    // ---------------- business methods ----------------------

    /**
     * Method to be implemented in descendants
     * Gets all inherited method information as a collection of MethodData instances for the given
     * superMetafacade.
     * @param superMetafacade
     * @return java.util.Collection
     */
    protected abstract java.util.Collection handleGetMethodDataForPSM(@jakarta.validation.Valid org.andromda.metafacades.uml.ClassifierFacade superMetafacade);

    /**
     * Gets all inherited method information as a collection of MethodData instances for the given
     * superMetafacade.
     * @param superMetafacade org.andromda.metafacades.uml.ClassifierFacade
     * The super metafacade for which to retrieve the collection of method data.
     * @return handleGetMethodDataForPSM(superMetafacade)
     */
    public java.util.Collection getMethodDataForPSM(@jakarta.validation.Valid org.andromda.metafacades.uml.ClassifierFacade superMetafacade)
    {
        // getMethodDataForPSM has no pre constraints
        java.util.Collection returnValue = handleGetMethodDataForPSM(superMetafacade);
        // getMethodDataForPSM has no post constraints
        return returnValue;
    }

    /**
     * Method to be implemented in descendants
     * Gets all method information as a collection of MethodData instances for the metafacade.
     * @return java.util.Collection
     */
    protected abstract java.util.Collection handleGetMethodDataForPSM();

    /**
     * Gets all method information as a collection of MethodData instances for the metafacade.
     * @return handleGetMethodDataForPSM()
     */
    public java.util.Collection getMethodDataForPSM()
    {
        // getMethodDataForPSM has no pre constraints
        java.util.Collection returnValue = handleGetMethodDataForPSM();
        // getMethodDataForPSM has no post constraints
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * Facade for use in the andromda-meta cartridge. It hides a Classifier that represents a
     * <<metafacade>> object.
     * @return (java.util.Set<org.andromda.cartridges.meta.metafacades.Metafacade>)handleGetAllParents()
     */
    public final java.util.Set<org.andromda.cartridges.meta.metafacades.Metafacade> getAllParents()
    {
        java.util.Set<org.andromda.cartridges.meta.metafacades.Metafacade> getAllParents1r = null;
        // metafacade has no pre constraints
       java.util.Set result = handleGetAllParents();
       java.util.Set shieldedResult = new java.util.LinkedHashSet<>(this.shieldedElements(result));
        try
        {
            getAllParents1r = (java.util.Set<org.andromda.cartridges.meta.metafacades.Metafacade>)shieldedResult;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            MetafacadeLogic.logger.warn("incorrect metafacade cast for MetafacadeLogic.getAllParents java.util.Set<org.andromda.cartridges.meta.metafacades.Metafacade> " + result + ": " + shieldedResult);
        }
        // metafacade has no post constraints
        return getAllParents1r;
    }

    /**
     * UML Specific type is returned in Collection, transformed by shieldedElements to AndroMDA Metafacade type
     * @return  java.util.Collection
     */
    protected abstract java.util.Set handleGetAllParents();

    private org.andromda.metafacades.uml.ClassifierFacade __getMetaclass2r;
    private boolean __getMetaclass2rSet = false;

    /**
     * Facade for use in the andromda-meta cartridge. It hides a Classifier that represents a
     * <<metafacade>> object.
     * @return (org.andromda.metafacades.uml.ClassifierFacade)handleGetMetaclass()
     */
    public final org.andromda.metafacades.uml.ClassifierFacade getMetaclass()
    {
        org.andromda.metafacades.uml.ClassifierFacade getMetaclass2r = this.__getMetaclass2r;
        if (!this.__getMetaclass2rSet)
        {
            // metafacade has no pre constraints
            Object result = handleGetMetaclass();
            org.andromda.core.metafacade.MetafacadeBase shieldedResult = this.shieldedElement(result);
            try
            {
                getMetaclass2r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedResult;
            }
            catch (ClassCastException ex)
            {
                // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
                MetafacadeLogic.logger.warn("incorrect metafacade cast for MetafacadeLogic.getMetaclass org.andromda.metafacades.uml.ClassifierFacade " + result + ": " + shieldedResult);
            }
            // metafacade has no post constraints
            this.__getMetaclass2r = getMetaclass2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getMetaclass2rSet = true;
            }
        }
        return getMetaclass2r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetMetaclass();

    /**
     * @return true
     * @see org.andromda.metafacades.uml.ClassifierFacade
     */
    public boolean isClassifierFacadeMetaType()
    {
        return true;
    }

    /**
     * @return true
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade
     */
    public boolean isGeneralizableElementFacadeMetaType()
    {
        return true;
    }

    /**
     * @return true
     * @see org.andromda.metafacades.uml.ModelElementFacade
     */
    public boolean isModelElementFacadeMetaType()
    {
        return true;
    }

    // ----------- delegates to org.andromda.metafacades.uml.ClassifierFacade ------------
    /**
     * Return the attribute which name matches the parameter
     * @see org.andromda.metafacades.uml.ClassifierFacade#findAttribute(java.lang.String name)
     */
    public org.andromda.metafacades.uml.AttributeFacade findAttribute(java.lang.String name)
    {
        return this.getSuperClassifierFacade().findAttribute(name);
    }

    /**
     * Those abstraction dependencies for which this classifier is the client.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAbstractions()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ClassifierFacade> getAbstractions()
    {
        return this.getSuperClassifierFacade().getAbstractions();
    }

    /**
     * Lists all classes associated to this one and any ancestor classes (through generalization).
     * There will be no duplicates. The order of the elements is predictable.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAllAssociatedClasses()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ClassifierFacade> getAllAssociatedClasses()
    {
        return this.getSuperClassifierFacade().getAllAssociatedClasses();
    }

    /**
     * A collection containing all 'properties' of the classifier and its ancestors.  Properties are
     * any attributes and navigable connecting association ends.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAllProperties()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ModelElementFacade> getAllProperties()
    {
        return this.getSuperClassifierFacade().getAllProperties();
    }

    /**
     * A collection containing all required and/or read-only 'properties' of the classifier and its
     * ancestors. Properties are any attributes and navigable connecting association ends.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAllRequiredConstructorParameters()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ModelElementFacade> getAllRequiredConstructorParameters()
    {
        return this.getSuperClassifierFacade().getAllRequiredConstructorParameters();
    }

    /**
     * Gets the array type for this classifier.  If this classifier already represents an array, it
     * just returns itself.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getArray()
     */
    public org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        return this.getSuperClassifierFacade().getArray();
    }

    /**
     * The name of the classifier as an array.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getArrayName()
     */
    public java.lang.String getArrayName()
    {
        return this.getSuperClassifierFacade().getArrayName();
    }

    /**
     * Lists the classes associated to this one, there is no repitition of classes. The order of the
     * elements is predictable.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAssociatedClasses()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ClassifierFacade> getAssociatedClasses()
    {
        return this.getSuperClassifierFacade().getAssociatedClasses();
    }

    /**
     * Gets the association ends belonging to a classifier.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAssociationEnds()
     */
    public java.util.List<org.andromda.metafacades.uml.AssociationEndFacade> getAssociationEnds()
    {
        return this.getSuperClassifierFacade().getAssociationEnds();
    }

    /**
     * Gets the attributes that belong to the classifier.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAttributes()
     */
    public java.util.List<org.andromda.metafacades.uml.AttributeFacade> getAttributes()
    {
        return this.getSuperClassifierFacade().getAttributes();
    }

    /**
     * Gets all attributes for the classifier and if 'follow' is true goes up the inheritance
     * hierarchy and gets the attributes from the super classes as well.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAttributes(boolean follow)
     */
    public java.util.List<org.andromda.metafacades.uml.AttributeFacade> getAttributes(boolean follow)
    {
        return this.getSuperClassifierFacade().getAttributes(follow);
    }

    /**
     * The fully qualified name of the classifier as an array.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getFullyQualifiedArrayName()
     */
    public java.lang.String getFullyQualifiedArrayName()
    {
        return this.getSuperClassifierFacade().getFullyQualifiedArrayName();
    }

    /**
     * Returns all those operations that could be implemented at this classifier's level. This means
     * the operations owned by this classifier as well as any realized interface's operations
     * (recursively) in case this classifier itself is not already an interface, or generalized when
     * this classifier is an interface.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getImplementationOperations()
     */
    public java.util.Set<org.andromda.metafacades.uml.OperationFacade> getImplementationOperations()
    {
        return this.getSuperClassifierFacade().getImplementationOperations();
    }

    /**
     * A comma separated list of the fully qualified names of all implemented interfaces.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getImplementedInterfaceList()
     */
    public java.lang.String getImplementedInterfaceList()
    {
        return this.getSuperClassifierFacade().getImplementedInterfaceList();
    }

    /**
     * Those attributes that are scoped to an instance of this class.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getInstanceAttributes()
     */
    public java.util.List<org.andromda.metafacades.uml.AttributeFacade> getInstanceAttributes()
    {
        return this.getSuperClassifierFacade().getInstanceAttributes();
    }

    /**
     * Those operations that are scoped to an instance of this class.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getInstanceOperations()
     */
    public java.util.List<org.andromda.metafacades.uml.OperationFacade> getInstanceOperations()
    {
        return this.getSuperClassifierFacade().getInstanceOperations();
    }

    /**
     * Those interfaces that are abstractions of this classifier, this basically means this
     * classifier realizes them.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getInterfaceAbstractions()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ClassifierFacade> getInterfaceAbstractions()
    {
        return this.getSuperClassifierFacade().getInterfaceAbstractions();
    }

    /**
     * A String representing a new Constructor declaration for this classifier type to be used in a
     * Java environment.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getJavaNewString()
     */
    public java.lang.String getJavaNewString()
    {
        return this.getSuperClassifierFacade().getJavaNewString();
    }

    /**
     * A String representing the null-value for this classifier type to be used in a Java
     * environment.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getJavaNullString()
     */
    public java.lang.String getJavaNullString()
    {
        return this.getSuperClassifierFacade().getJavaNullString();
    }

    /**
     * The other ends of this classifier's association ends which are navigable.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getNavigableConnectingEnds()
     */
    public java.util.Collection<org.andromda.metafacades.uml.AssociationEndFacade> getNavigableConnectingEnds()
    {
        return this.getSuperClassifierFacade().getNavigableConnectingEnds();
    }

    /**
     * Get the other ends of this classifier's association ends which are navigable and if 'follow'
     * is true goes up the inheritance hierarchy and gets the super association ends as well.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getNavigableConnectingEnds(boolean follow)
     */
    public java.util.Collection<org.andromda.metafacades.uml.AssociationEndFacade> getNavigableConnectingEnds(boolean follow)
    {
        return this.getSuperClassifierFacade().getNavigableConnectingEnds(follow);
    }

    /**
     * Assuming that the classifier is an array, this will return the non array type of the
     * classifier from
     * the model.  If the classifier is NOT an array, it will just return itself.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getNonArray()
     */
    public org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        return this.getSuperClassifierFacade().getNonArray();
    }

    /**
     * The attributes from this classifier in the form of an operation call (this example would be
     * in Java): '(String attributeOne, String attributeTwo).  If there were no attributes on the
     * classifier, the result would be an empty '()'.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getOperationCallFromAttributes()
     */
    public java.lang.String getOperationCallFromAttributes()
    {
        return this.getSuperClassifierFacade().getOperationCallFromAttributes();
    }

    /**
     * The operations owned by this classifier.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getOperations()
     */
    public java.util.List<org.andromda.metafacades.uml.OperationFacade> getOperations()
    {
        return this.getSuperClassifierFacade().getOperations();
    }

    /**
     * A collection containing all 'properties' of the classifier.  Properties are any attributes
     * and navigable connecting association ends.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getProperties()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ModelElementFacade> getProperties()
    {
        return this.getSuperClassifierFacade().getProperties();
    }

    /**
     * Gets all properties (attributes and navigable association ends) for the classifier and if
     * 'follow' is true goes up the inheritance hierarchy and gets the properties from the super
     * classes as well.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getProperties(boolean follow)
     */
    public java.util.List getProperties(boolean follow)
    {
        return this.getSuperClassifierFacade().getProperties(follow);
    }

    /**
     * A collection containing all required and/or read-only 'properties' of the classifier. 
     * Properties are any attributes and navigable connecting association ends.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getRequiredConstructorParameters()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ModelElementFacade> getRequiredConstructorParameters()
    {
        return this.getSuperClassifierFacade().getRequiredConstructorParameters();
    }

    /**
     * Returns the serial version UID of the underlying model element.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getSerialVersionUID()
     */
    public long getSerialVersionUID()
    {
        return this.getSuperClassifierFacade().getSerialVersionUID();
    }

    /**
     * Those attributes that are scoped to the definition of this class.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getStaticAttributes()
     */
    public java.util.List<org.andromda.metafacades.uml.AttributeFacade> getStaticAttributes()
    {
        return this.getSuperClassifierFacade().getStaticAttributes();
    }

    /**
     * Those operations that are scoped to the definition of this class.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getStaticOperations()
     */
    public java.util.List<org.andromda.metafacades.uml.OperationFacade> getStaticOperations()
    {
        return this.getSuperClassifierFacade().getStaticOperations();
    }

    /**
     * This class' superclass, returns the generalization if it is a ClassifierFacade, null
     * otherwise.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getSuperClass()
     */
    public org.andromda.metafacades.uml.ClassifierFacade getSuperClass()
    {
        return this.getSuperClassifierFacade().getSuperClass();
    }

    /**
     * The wrapper name for this classifier if a mapped type has a defined wrapper class (ie. 'long'
     * maps to 'Long').  If the classifier doesn't have a wrapper defined for it, this method will
     * return a null.  Note that wrapper mappings must be defined for the namespace by defining the
     * 'wrapperMappingsUri', this property must point to the location of the mappings file which
     * maps the primitives to wrapper types.
     * @see org.andromda.metafacades.uml.ClassifierFacade#getWrapperName()
     */
    public java.lang.String getWrapperName()
    {
        return this.getSuperClassifierFacade().getWrapperName();
    }

    /**
     * Indicates if this classifier is 'abstract'.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isAbstract()
     */
    public boolean isAbstract()
    {
        return this.getSuperClassifierFacade().isAbstract();
    }

    /**
     * True if this classifier represents an array type. False otherwise.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isArrayType()
     */
    public boolean isArrayType()
    {
        return this.getSuperClassifierFacade().isArrayType();
    }

    /**
     * True if the ClassifierFacade is an AssociationClass.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isAssociationClass()
     */
    public boolean isAssociationClass()
    {
        return this.getSuperClassifierFacade().isAssociationClass();
    }

    /**
     * Returns true if this type represents a Blob type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isBlobType()
     */
    public boolean isBlobType()
    {
        return this.getSuperClassifierFacade().isBlobType();
    }

    /**
     * Indicates if this type represents a boolean type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isBooleanType()
     */
    public boolean isBooleanType()
    {
        return this.getSuperClassifierFacade().isBooleanType();
    }

    /**
     * Indicates if this type represents a char, Character, or java.lang.Character type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isCharacterType()
     */
    public boolean isCharacterType()
    {
        return this.getSuperClassifierFacade().isCharacterType();
    }

    /**
     * Returns true if this type represents a Clob type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isClobType()
     */
    public boolean isClobType()
    {
        return this.getSuperClassifierFacade().isClobType();
    }

    /**
     * True if this classifier represents a collection type. False otherwise.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isCollectionType()
     */
    public boolean isCollectionType()
    {
        return this.getSuperClassifierFacade().isCollectionType();
    }

    /**
     * True/false depending on whether or not this classifier represents a datatype. A data type is
     * a type whose instances are identified only by their value. A data type may contain attributes
     * to support the modeling of structured data types.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isDataType()
     */
    public boolean isDataType()
    {
        return this.getSuperClassifierFacade().isDataType();
    }

    /**
     * True when this classifier is a date type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isDateType()
     */
    public boolean isDateType()
    {
        return this.getSuperClassifierFacade().isDateType();
    }

    /**
     * Indicates if this type represents a Double type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isDoubleType()
     */
    public boolean isDoubleType()
    {
        return this.getSuperClassifierFacade().isDoubleType();
    }

    /**
     * Indicates whether or not this classifier represents an "EmbeddedValue'.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isEmbeddedValue()
     */
    public boolean isEmbeddedValue()
    {
        return this.getSuperClassifierFacade().isEmbeddedValue();
    }

    /**
     * True if this classifier is in fact marked as an enumeration.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isEnumeration()
     */
    public boolean isEnumeration()
    {
        return this.getSuperClassifierFacade().isEnumeration();
    }

    /**
     * Returns true if this type represents a 'file' type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isFileType()
     */
    public boolean isFileType()
    {
        return this.getSuperClassifierFacade().isFileType();
    }

    /**
     * Indicates if this type represents a Float type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isFloatType()
     */
    public boolean isFloatType()
    {
        return this.getSuperClassifierFacade().isFloatType();
    }

    /**
     * Indicates if this type represents an int or Integer or java.lang.Integer type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isIntegerType()
     */
    public boolean isIntegerType()
    {
        return this.getSuperClassifierFacade().isIntegerType();
    }

    /**
     * True/false depending on whether or not this Classifier represents an interface.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isInterface()
     */
    public boolean isInterface()
    {
        return this.getSuperClassifierFacade().isInterface();
    }

    /**
     * True if this classifier cannot be extended and represent a leaf in the inheritance tree.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isLeaf()
     */
    public boolean isLeaf()
    {
        return this.getSuperClassifierFacade().isLeaf();
    }

    /**
     * True if this classifier represents a list type. False otherwise.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isListType()
     */
    public boolean isListType()
    {
        return this.getSuperClassifierFacade().isListType();
    }

    /**
     * Indicates if this type represents a Long type or not.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isLongType()
     */
    public boolean isLongType()
    {
        return this.getSuperClassifierFacade().isLongType();
    }

    /**
     * Indicates whether or not this classifier represents a Map type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isMapType()
     */
    public boolean isMapType()
    {
        return this.getSuperClassifierFacade().isMapType();
    }

    /**
     * Indicates whether or not this classifier represents a primitive type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isPrimitive()
     */
    public boolean isPrimitive()
    {
        return this.getSuperClassifierFacade().isPrimitive();
    }

    /**
     * True if this classifier represents a set type. False otherwise.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isSetType()
     */
    public boolean isSetType()
    {
        return this.getSuperClassifierFacade().isSetType();
    }

    /**
     * Indicates whether or not this classifier represents a string type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isStringType()
     */
    public boolean isStringType()
    {
        return this.getSuperClassifierFacade().isStringType();
    }

    /**
     * Indicates whether or not this classifier represents a time type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isTimeType()
     */
    public boolean isTimeType()
    {
        return this.getSuperClassifierFacade().isTimeType();
    }

    /**
     * Returns true if this type is a wrapped primitive type.
     * @see org.andromda.metafacades.uml.ClassifierFacade#isWrappedPrimitive()
     */
    public boolean isWrappedPrimitive()
    {
        return this.getSuperClassifierFacade().isWrappedPrimitive();
    }

    /**
     * Finds the tagged value optional searching the entire inheritance hierarchy if 'follow' is set
     * to true.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#findTaggedValue(java.lang.String tagName, boolean follow)
     */
    public java.lang.Object findTaggedValue(java.lang.String tagName, boolean follow)
    {
        return this.getSuperClassifierFacade().findTaggedValue(tagName, follow);
    }

    /**
     * All generalizations for this generalizable element, goes up the inheritance tree.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getAllGeneralizations()
     */
    public java.util.Collection<org.andromda.metafacades.uml.GeneralizableElementFacade> getAllGeneralizations()
    {
        return this.getSuperClassifierFacade().getAllGeneralizations();
    }

    /**
     * All specializations (travels down the inheritance hierarchy).
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getAllSpecializations()
     */
    public java.util.Collection<org.andromda.metafacades.uml.GeneralizableElementFacade> getAllSpecializations()
    {
        return this.getSuperClassifierFacade().getAllSpecializations();
    }

    /**
     * Gets the direct generalization for this generalizable element.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralization()
     */
    public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        return this.getSuperClassifierFacade().getGeneralization();
    }

    /**
     * Gets the actual links that this generalization element is part of (it plays either the
     * specialization or generalization).
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizationLinks()
     */
    public java.util.Collection<org.andromda.metafacades.uml.GeneralizationFacade> getGeneralizationLinks()
    {
        return this.getSuperClassifierFacade().getGeneralizationLinks();
    }

    /**
     * A comma separated list of the fully qualified names of all generalizations.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizationList()
     */
    public java.lang.String getGeneralizationList()
    {
        return this.getSuperClassifierFacade().getGeneralizationList();
    }

    /**
     * The element found when you recursively follow the generalization path up to the root. If an
     * element has no generalization itself will be considered the root.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizationRoot()
     */
    public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralizationRoot()
    {
        return this.getSuperClassifierFacade().getGeneralizationRoot();
    }

    /**
     * Return all generalizations (ancestors) from this generalizable element.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizations()
     */
    public java.util.Collection<org.andromda.metafacades.uml.GeneralizableElementFacade> getGeneralizations()
    {
        return this.getSuperClassifierFacade().getGeneralizations();
    }

    /**
     * Gets the direct specializations (i.e. sub elements) for this generalizatble element.
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getSpecializations()
     */
    public java.util.Collection<org.andromda.metafacades.uml.GeneralizableElementFacade> getSpecializations()
    {
        return this.getSuperClassifierFacade().getSpecializations();
    }

    /**
     * Copies all tagged values from the given ModelElementFacade to this model element facade.
     * @see org.andromda.metafacades.uml.ModelElementFacade#copyTaggedValues(org.andromda.metafacades.uml.ModelElementFacade element)
     */
    public void copyTaggedValues(org.andromda.metafacades.uml.ModelElementFacade element)
    {
        this.getSuperClassifierFacade().copyTaggedValues(element);
    }

    /**
     * Finds the tagged value with the specified 'tagName'. In case there are more values the first
     * one found will be returned.
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValue(java.lang.String tagName)
     */
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        return this.getSuperClassifierFacade().findTaggedValue(tagName);
    }

    /**
     * Returns all the values for the tagged value with the specified name. The returned collection
     * will contains only String instances, or will be empty. Never null.
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValues(java.lang.String tagName)
     */
    public java.util.Collection<java.lang.Object> findTaggedValues(java.lang.String tagName)
    {
        return this.getSuperClassifierFacade().findTaggedValues(tagName);
    }

    /**
     * Extra annotations not covered by the normal AndroMDA features. The list of these annotations
     * should be separated by semi colons.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getAdditionalAnnotations()
     */
    public java.util.Set<java.lang.String> getAdditionalAnnotations()
    {
        return this.getSuperClassifierFacade().getAdditionalAnnotations();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.additionalExtends
     * @see org.andromda.metafacades.uml.ModelElementFacade#getAdditionalExtends()
     */
    public java.util.Set<java.lang.String> getAdditionalExtends()
    {
        return this.getSuperClassifierFacade().getAdditionalExtends();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.additionalImplements
     * @see org.andromda.metafacades.uml.ModelElementFacade#getAdditionalImplements()
     */
    public java.util.Set<java.lang.String> getAdditionalImplements()
    {
        return this.getSuperClassifierFacade().getAdditionalImplements();
    }

    /**
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element. The templates parameter will
     * be replaced by the correct one given the binding relation of the parameter to this element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getBindedFullyQualifiedName(org.andromda.metafacades.uml.ModelElementFacade bindedElement)
     */
    public java.lang.String getBindedFullyQualifiedName(org.andromda.metafacades.uml.ModelElementFacade bindedElement)
    {
        return this.getSuperClassifierFacade().getBindedFullyQualifiedName(bindedElement);
    }

    /**
     * Gets all constraints belonging to the model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints()
     */
    public java.util.Collection<org.andromda.metafacades.uml.ConstraintFacade> getConstraints()
    {
        return this.getSuperClassifierFacade().getConstraints();
    }

    /**
     * Returns the constraints of the argument kind that have been placed onto this model. Typical
     * kinds are "inv", "pre" and "post". Other kinds are possible.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints(java.lang.String kind)
     */
    public java.util.Collection<org.andromda.metafacades.uml.ConstraintFacade> getConstraints(java.lang.String kind)
    {
        return this.getSuperClassifierFacade().getConstraints(kind);
    }

    /**
     * Gets the documentation for the model element, The indent argument is prefixed to each line.
     * By default this method wraps lines after 64 characters.
     * This method is equivalent to <code>getDocumentation(indent, 64)</code>.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String indent)
     */
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        return this.getSuperClassifierFacade().getDocumentation(indent);
    }

    /**
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. By default paragraphs are returned as HTML.
     * This method is equivalent to <code>getDocumentation(indent, lineLength, true)</code>.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String indent, int lineLength)
     */
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        return this.getSuperClassifierFacade().getDocumentation(indent, lineLength);
    }

    /**
     * This method returns the documentation for this model element, with the lines wrapped after
     * the specified number of characters, values of less than 1 will indicate no line wrapping is
     * required. HTML style determines if HTML Escaping is applied.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
     */
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        return this.getSuperClassifierFacade().getDocumentation(indent, lineLength, htmlStyle);
    }

    /**
     * The fully qualified name of this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName()
     */
    public java.lang.String getFullyQualifiedName()
    {
        return this.getSuperClassifierFacade().getFullyQualifiedName();
    }

    /**
     * Returns the fully qualified name of the model element. The fully qualified name includes
     * complete package qualified name of the underlying model element.  If modelName is true, then
     * the original name of the model element (the name contained within the model) will be the name
     * returned, otherwise a name from a language mapping will be returned.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName(boolean modelName)
     */
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        return this.getSuperClassifierFacade().getFullyQualifiedName(modelName);
    }

    /**
     * Returns the fully qualified name as a path, the returned value always starts with out a slash
     * '/'.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedNamePath()
     */
    public java.lang.String getFullyQualifiedNamePath()
    {
        return this.getSuperClassifierFacade().getFullyQualifiedNamePath();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.genericParameterString
     * @see org.andromda.metafacades.uml.ModelElementFacade#getGenericParameterString()
     */
    public java.lang.String getGenericParameterString()
    {
        return this.getSuperClassifierFacade().getGenericParameterString();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.genericParameters
     * @see org.andromda.metafacades.uml.ModelElementFacade#getGenericParameters()
     */
    public java.util.Set<java.lang.String> getGenericParameters()
    {
        return this.getSuperClassifierFacade().getGenericParameters();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.genericTypeString
     * @see org.andromda.metafacades.uml.ModelElementFacade#getGenericTypeString()
     */
    public java.lang.String getGenericTypeString()
    {
        return this.getSuperClassifierFacade().getGenericTypeString();
    }

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.ModelElementFacade.genericTypes
     * @see org.andromda.metafacades.uml.ModelElementFacade#getGenericTypes()
     */
    public java.util.Set<java.lang.String> getGenericTypes()
    {
        return this.getSuperClassifierFacade().getGenericTypes();
    }

    /**
     * Gets the unique identifier of the underlying model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getId()
     */
    public java.lang.String getId()
    {
        return this.getSuperClassifierFacade().getId();
    }

    /**
     * UML2: Retrieves the keywords for this element. Used to modify implementation properties which
     * are not represented by other properties, i.e. native, transient, volatile, synchronized,
     * (added annotations) override, deprecated. Can also be used to suppress compiler warnings:
     * (added annotations) unchecked, fallthrough, path, serial, finally, all. Annotations require
     * JDK5 compiler level.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getKeywords()
     */
    public java.util.Set<java.lang.String> getKeywords()
    {
        return this.getSuperClassifierFacade().getKeywords();
    }

    /**
     * UML2: Retrieves a localized label for this named element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getLabel()
     */
    public java.lang.String getLabel()
    {
        return this.getSuperClassifierFacade().getLabel();
    }

    /**
     * The language mappings that have been set for this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getLanguageMappings()
     */
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        return this.getSuperClassifierFacade().getLanguageMappings();
    }

    /**
     * Return the model containing this model element (multiple models may be loaded and processed
     * at the same time).
     * @see org.andromda.metafacades.uml.ModelElementFacade#getModel()
     */
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        return this.getSuperClassifierFacade().getModel();
    }

    /**
     * The name of the model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getName()
     */
    public java.lang.String getName()
    {
        return this.getSuperClassifierFacade().getName();
    }

    /**
     * Gets the package to which this model element belongs.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackage()
     */
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        return this.getSuperClassifierFacade().getPackage();
    }

    /**
     * The name of this model element's package.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName()
     */
    public java.lang.String getPackageName()
    {
        return this.getSuperClassifierFacade().getPackageName();
    }

    /**
     * Gets the package name (optionally providing the ability to retrieve the model name and not
     * the mapped name).
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName(boolean modelName)
     */
    public java.lang.String getPackageName(boolean modelName)
    {
        return this.getSuperClassifierFacade().getPackageName(modelName);
    }

    /**
     * Returns the package as a path, the returned value always starts with out a slash '/'.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackagePath()
     */
    public java.lang.String getPackagePath()
    {
        return this.getSuperClassifierFacade().getPackagePath();
    }

    /**
     * UML2: Returns the value of the 'Qualified Name' attribute. A name which allows the
     * NamedElement to be identified within a hierarchy of nested Namespaces. It is constructed from
     * the names of the containing namespaces starting at the root of the hierarchy and ending with
     * the name of the NamedElement itself.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getQualifiedName()
     */
    public java.lang.String getQualifiedName()
    {
        return this.getSuperClassifierFacade().getQualifiedName();
    }

    /**
     * Gets the root package for the model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getRootPackage()
     */
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        return this.getSuperClassifierFacade().getRootPackage();
    }

    /**
     * Gets the dependencies for which this model element is the source.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getSourceDependencies()
     */
    public java.util.Collection<org.andromda.metafacades.uml.DependencyFacade> getSourceDependencies()
    {
        return this.getSuperClassifierFacade().getSourceDependencies();
    }

    /**
     * If this model element is the context of an activity graph, this represents that activity
     * graph.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStateMachineContext()
     */
    public org.andromda.metafacades.uml.StateMachineFacade getStateMachineContext()
    {
        return this.getSuperClassifierFacade().getStateMachineContext();
    }

    /**
     * The collection of ALL stereotype names for this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypeNames()
     */
    public java.util.Set<java.lang.String> getStereotypeNames()
    {
        return this.getSuperClassifierFacade().getStereotypeNames();
    }

    /**
     * Gets all stereotypes for this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypes()
     */
    public java.util.Collection<org.andromda.metafacades.uml.StereotypeFacade> getStereotypes()
    {
        return this.getSuperClassifierFacade().getStereotypes();
    }

    /**
     * Return the TaggedValues associated with this model element, under all stereotypes.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTaggedValues()
     */
    public java.util.Collection<org.andromda.metafacades.uml.TaggedValueFacade> getTaggedValues()
    {
        return this.getSuperClassifierFacade().getTaggedValues();
    }

    /**
     * Gets the dependencies for which this model element is the target.
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTargetDependencies()
     */
    public java.util.Collection<org.andromda.metafacades.uml.DependencyFacade> getTargetDependencies()
    {
        return this.getSuperClassifierFacade().getTargetDependencies();
    }

    /**
     * Get the template parameter for this model element having the parameterName
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTemplateParameter(java.lang.String parameterName)
     */
    public java.lang.Object getTemplateParameter(java.lang.String parameterName)
    {
        return this.getSuperClassifierFacade().getTemplateParameter(parameterName);
    }

    /**
     * Get the template parameters for this model element
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTemplateParameters()
     */
    public java.util.Collection<org.andromda.metafacades.uml.TemplateParameterFacade> getTemplateParameters()
    {
        return this.getSuperClassifierFacade().getTemplateParameters();
    }

    /**
     * The visibility (i.e. public, private, protected or package) of the model element, will
     * attempt a lookup for these values in the language mappings (if any).
     * @see org.andromda.metafacades.uml.ModelElementFacade#getVisibility()
     */
    public java.lang.String getVisibility()
    {
        return this.getSuperClassifierFacade().getVisibility();
    }

    /**
     * Returns true if the model element has the exact stereotype (meaning no stereotype inheritance
     * is taken into account when searching for the stereotype), false otherwise.
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasExactStereotype(java.lang.String stereotypeName)
     */
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperClassifierFacade().hasExactStereotype(stereotypeName);
    }

    /**
     * Does the UML Element contain the named Keyword? Keywords can be separated by space, comma,
     * pipe, semicolon, or << >>
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasKeyword(java.lang.String keywordName)
     */
    public boolean hasKeyword(java.lang.String keywordName)
    {
        return this.getSuperClassifierFacade().hasKeyword(keywordName);
    }

    /**
     * Returns true if the model element has the specified stereotype.  If the stereotype itself
     * does not match, then a search will be made up the stereotype inheritance hierarchy, and if
     * one of the stereotype's ancestors has a matching name this method will return true, false
     * otherwise.
     * For example, if we have a certain stereotype called <<exception>> and a model element has a
     * stereotype called <<applicationException>> which extends <<exception>>, when calling this
     * method with 'stereotypeName' defined as 'exception' the method would return true since
     * <<applicationException>> inherits from <<exception>>.  If you want to check if the model
     * element has the exact stereotype, then use the method 'hasExactStereotype' instead.
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasStereotype(java.lang.String stereotypeName)
     */
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperClassifierFacade().hasStereotype(stereotypeName);
    }

    /**
     * True if there are target dependencies from this element that are instances of BindingFacade.
     * Deprecated in UML2: Use TemplateBinding parameters instead of dependencies.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isBindingDependenciesPresent()
     */
    public boolean isBindingDependenciesPresent()
    {
        return this.getSuperClassifierFacade().isBindingDependenciesPresent();
    }

    /**
     * Indicates if any constraints are present on this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isConstraintsPresent()
     */
    public boolean isConstraintsPresent()
    {
        return this.getSuperClassifierFacade().isConstraintsPresent();
    }

    /**
     * Indicates if any documentation is present on this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isDocumentationPresent()
     */
    public boolean isDocumentationPresent()
    {
        return this.getSuperClassifierFacade().isDocumentationPresent();
    }

    /**
     * TODO: Model Documentation for org.andromda.metafacades.uml.ModelElementFacade.generic
     * @see org.andromda.metafacades.uml.ModelElementFacade#isGeneric()
     */
    public boolean isGeneric()
    {
        return this.getSuperClassifierFacade().isGeneric();
    }

    /**
     * TODO: Model Documentation for
     * org.andromda.metafacades.uml.ModelElementFacade.genericDeclaration
     * @see org.andromda.metafacades.uml.ModelElementFacade#isGenericDeclaration()
     */
    public boolean isGenericDeclaration()
    {
        return this.getSuperClassifierFacade().isGenericDeclaration();
    }

    /**
     * True if this element name is a reserved word in Java, C#, ANSI or ISO C, C++, JavaScript.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isReservedWord()
     */
    public boolean isReservedWord()
    {
        return this.getSuperClassifierFacade().isReservedWord();
    }

    /**
     * True is there are template parameters on this model element. For UML2, applies to Class,
     * Operation, Property, and Parameter.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isTemplateParametersPresent()
     */
    public boolean isTemplateParametersPresent()
    {
        return this.getSuperClassifierFacade().isTemplateParametersPresent();
    }

    /**
     * True if this element name is a valid identifier name in Java, C#, ANSI or ISO C, C++,
     * JavaScript. Contains no spaces, special characters etc. Constraint always applied on
     * Enumerations and Interfaces, optionally applies on other model elements.
     * @see org.andromda.metafacades.uml.ModelElementFacade#isValidIdentifierName()
     */
    public boolean isValidIdentifierName()
    {
        return this.getSuperClassifierFacade().isValidIdentifierName();
    }

    /**
     * Searches for the constraint with the specified 'name' on this model element, and if found
     * translates it using the specified 'translation' from a translation library discovered by the
     * framework.
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraint(java.lang.String name, java.lang.String translation)
     */
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        return this.getSuperClassifierFacade().translateConstraint(name, translation);
    }

    /**
     * Translates all constraints belonging to this model element with the given 'translation'.
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(java.lang.String translation)
     */
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        return this.getSuperClassifierFacade().translateConstraints(translation);
    }

    /**
     * Translates the constraints of the specified 'kind' belonging to this model element.
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(java.lang.String kind, java.lang.String translation)
     */
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        return this.getSuperClassifierFacade().translateConstraints(kind, translation);
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    @Override
    public void initialize()
    {
        this.getSuperClassifierFacade().initialize();
    }

    /**
     * @return Object getSuperClassifierFacade().getValidationOwner()
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    @Override
    public Object getValidationOwner()
    {
        Object owner = this.getSuperClassifierFacade().getValidationOwner();
        return owner;
    }

    /**
     * @return String getSuperClassifierFacade().getValidationName()
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    @Override
    public String getValidationName()
    {
        String name = this.getSuperClassifierFacade().getValidationName();
        return name;
    }

    /**
     * <p><b>Constraint:</b> org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only generalize another metafacade</p>
     * <p><b>Error:</b> A metafacade can only generalize another metafacade.</p>
     * <p><b>OCL:</b> context Metafacade
inv : generalization -> notEmpty() implies generalization.oclIsKindOf(Metafacade)</p>
     * <p><b>Constraint:</b> org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only specialize another metafacade</p>
     * <p><b>Error:</b> A metafacade can only specialize another metafacade.</p>
     * <p><b>OCL:</b> context Metafacade inv : 
specializations -> notEmpty() implies specializations -> forAll(oclIsKindOf(Metafacade))</p>
     * <p><b>Constraint:</b> org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade must either extend an existing metafacade or have a direct dependency to a metaclass</p>
     * <p><b>Error:</b> A metafacade must at the least, either extend an existing metafacade or have a direct dependency to
a metaclass.</p>
     * <p><b>OCL:</b> context Metafacade
inv: generalizations -> notEmpty() or sourceDependencies -> notEmpty()</p>
     * @param validationMessages Collection<ModelValidationMessage>
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        this.getSuperClassifierFacade().validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization")))).booleanValue()?org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization") instanceof org.andromda.cartridges.meta.metafacades.Metafacade:true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only generalize another metafacade",
                        "A metafacade can only generalize another metafacade."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only generalize another metafacade' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations")))).booleanValue()?org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations"),new org.apache.commons.collections.Predicate(){public boolean evaluate(Object object){return Boolean.valueOf(String.valueOf(object instanceof org.andromda.cartridges.meta.metafacades.Metafacade)).booleanValue();}}):true));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only specialize another metafacade",
                        "A metafacade can only specialize another metafacade."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade can only specialize another metafacade' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
        try
        {
            final Object contextElement = this.THIS();
            boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalizations"))||org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"sourceDependencies")));
            if (!constraintValid)
            {
                validationMessages.add(
                    new ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade must either extend an existing metafacade or have a direct dependency to a metaclass",
                        "A metafacade must at the least, either extend an existing metafacade or have a direct dependency to\na metaclass."));
            }
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::cartridges::meta::metafacades::Metafacade::a metafacade must either extend an existing metafacade or have a direct dependency to a metaclass' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }

    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    private static final String FQNAME_PROPERTY = "fullyQualifiedName";

    /**
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuilder toString = new StringBuilder(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(Introspector.instance().getProperty(this, FQNAME_PROPERTY));
        }
        catch (final Throwable tryAgain)
        {
            try
            {
                toString.append(Introspector.instance().getProperty(this, NAME_PROPERTY));
            }
            catch (final Throwable ignore)
            {
                // - just ignore when the metafacade doesn't have a name or fullyQualifiedName property
            }
        }
        toString.append("]");
        return toString.toString();
    }
}
