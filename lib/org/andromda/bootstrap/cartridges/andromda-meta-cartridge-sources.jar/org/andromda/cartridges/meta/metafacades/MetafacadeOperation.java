// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta.metafacades;

import org.andromda.metafacades.uml.OperationFacade;

/**
 * Represents a metafacade operation.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface MetafacadeOperation
    extends OperationFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isMetafacadeOperationMetaType();

    /**
     * The implementation name for the operation that handles the logic of the operation.
     * @return String
     */
    public String getImplementationName();
}