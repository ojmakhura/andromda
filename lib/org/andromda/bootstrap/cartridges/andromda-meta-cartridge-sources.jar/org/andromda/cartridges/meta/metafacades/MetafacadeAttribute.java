// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta.metafacades;

import org.andromda.metafacades.uml.AttributeFacade;

/**
 * Represents an attribute of a metafacade.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface MetafacadeAttribute
    extends AttributeFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isMetafacadeAttributeMetaType();

    /**
     * The implementation name for the operation that handles the logic of the attribute retrieval.
     * @return String
     */
    public String getImplementationOperationName();
}