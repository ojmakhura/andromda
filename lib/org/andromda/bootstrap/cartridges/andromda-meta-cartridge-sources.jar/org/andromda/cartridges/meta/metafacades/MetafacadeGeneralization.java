// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta.metafacades;

import org.andromda.metafacades.uml.GeneralizationFacade;

/**
 * Represents a generalization between two metafacades.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface MetafacadeGeneralization
    extends GeneralizationFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isMetafacadeGeneralizationMetaType();

    /**
     * The getter name to retrieve this generalization.
     * @return String
     */
    public String getGetterName();

    /**
     * The visibility of the getter name for accessing this generalization.
     * @return String
     */
    public String getGetterNameVisibility();

    /**
     * Stores the precedence of this generalization (this only matters when multiple inheritance is
     * taken into account).
     * @return Integer
     */
    public Integer getPrecedence();
}