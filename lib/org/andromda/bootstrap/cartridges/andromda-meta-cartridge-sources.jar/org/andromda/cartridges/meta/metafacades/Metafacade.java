// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta.metafacades;

import java.util.Collection;
import org.andromda.metafacades.uml.ClassifierFacade;

/**
 * Facade for use in the andromda-meta cartridge. It hides a Classifier that represents a
 * <<metafacade>> object.
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface Metafacade
    extends ClassifierFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isMetafacadeMetaType();

    /**
     * All generalization links (including all parents)
     * @return Collection<Metafacade>
     */
    public Collection<Metafacade> getAllParents();

    /**
     * The fully qualified name for the implementation of the metafacade.
     * @return String
     */
    public String getFullyQualifiedLogicImplName();

    /**
     * The fully qualified name for the metafacade "Logic" class.
     * @return String
     */
    public String getFullyQualifiedLogicName();

    /**
     * The number of parents this metafacade has.
     * @return int
     */
    public int getGeneralizationCount();

    /**
     * The 'Logic' file location.
     * @return String
     */
    public String getLogicFile();

    /**
     * The 'Logic' implementation file location.
     * @return String
     */
    public String getLogicImplFile();

    /**
     * The name of the 'Logic' implementation name.
     * @return String
     */
    public String getLogicImplName();

    /**
     * The name of the metafacade 'Logic' class.
     * @return String
     */
    public String getLogicName();

    /**
     * The package name to which the 'Logic' metafacade classes are generated.
     * @return String
     */
    public String getLogicPackageName();

    /**
     * A Classifier is a classification of instances - it describes a set of instances that have
     * features
     * in common. Can specify a generalization hierarchy by referencing its general classifiers. It
     * may be
     * a Class, DataType, PrimitiveType, Association, Collaboration, UseCase, etc. Can specify a
     * generalization hierarchy by referencing its general classifiers. Has the capability to own
     * collaboration uses. These collaboration uses link a collaboration with the classifier to give
     * a
     * description of the workings of the classifier. Classifier is defined to be a kind of
     * templateable
     * element so that a classifier can be parameterized. It is also defined to be a kind of
     * parameterable
     * element so that a classifier can be a formal template parameter.
     * @return ClassifierFacade
     */
    public ClassifierFacade getMetaclass();

    /**
     * Gets all method information as a collection of MethodData instances for the metafacade.
     * @return Collection
     */
    public Collection getMethodDataForPSM();

    /**
     * Gets all inherited method information as a collection of MethodData instances for the given
     * superMetafacade.
     * @param superMetafacade ClassifierFacade
     * @return Collection
     */
    public Collection getMethodDataForPSM(ClassifierFacade superMetafacade);

    /**
     * Indicates if the meta class construct argument requires a cast to the super metafacade's
     * metaclass.
     * @return boolean
     */
    public boolean isConstructorRequiresMetaclassCast();

    /**
     * True/false depending on whether or not this class's metaclass is a direct dependency (true)
     * or an inherited dependency (false).
     * @return boolean
     */
    public boolean isMetaclassDirectDependency();

    /**
     * Indicates if the metafacade requires a delegate for inheritance instead of actual
     * inheritance.  This is true, when the metafacade is inheriting from a metafacade from a
     * different package (since that means it will most likely be a cartridge metafacade inheriting
     * from a set of shared metafacades for a meta model).
     * @return boolean
     */
    public boolean isRequiresInheritanceDelegatation();
}