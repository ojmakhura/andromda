// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta.metafacades;

import org.andromda.metafacades.uml.AssociationEndFacade;

/**
 * Represents the association end of a metafacade
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface MetafacadeAssociationEnd
    extends AssociationEndFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isMetafacadeAssociationEndMetaType();

    /**
     * The implementation name for the operation that handles the logic of the association end
     * retrieval.
     * @return String
     */
    public String getImplementationOperationName();
}