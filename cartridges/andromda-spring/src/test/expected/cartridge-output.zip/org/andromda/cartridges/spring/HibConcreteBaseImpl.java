/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibConcreteBase
 */
public class HibConcreteBaseImpl
    extends org.andromda.cartridges.spring.HibConcreteBase
{
    /**
     * @see org.andromda.cartridges.spring.HibConcreteBaseDao#baseOp()
     */
    public java.lang.String baseOp()
    {
        //@todo implement public java.lang.String baseOp()
        return null;
    }

}
