/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

import java.util.Collection;
import java.util.Date;
import org.andromda.spring.ServiceLocator;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceOne}.
 *
 * @see ServiceOne
 */
public class ServiceOneWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceOne}
     */
    private final ServiceOne getServiceOne()
    {
        return ServiceLocator.instance().getServiceOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws ServiceTestException
    {
        try
        {
            getServiceOne().operationWithVoidReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof ServiceTestException)
            {
                throw (ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof ServiceTestException)
            {
                throw (ServiceTestException)cause;
            }
            throw new RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    public String operationWithSimpleReturnType()
        throws ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithSimpleReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof ServiceTestException)
            {
                throw (ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof ServiceTestException)
            {
                throw (ServiceTestException)cause;
            }
            throw new RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    public Collection operationWithComplexReturnType()
        throws ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithComplexReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof ServiceTestException)
            {
                throw (ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof ServiceTestException)
            {
                throw (ServiceTestException)cause;
            }
            throw new RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(Date)
     */
    public String operationWithSingleArgument(Date argumentOne)
        throws ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithSingleArgument(argumentOne);
        }
        catch (Exception exception)
        {
            if (exception instanceof ServiceTestException)
            {
                throw (ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof ServiceTestException)
            {
                throw (ServiceTestException)cause;
            }
            throw new RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(Long, Boolean)
     */
    public void operationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throws ServiceTestException, OperationTestException
    {
        try
        {
            getServiceOne().operationWithMultipleArguments(firstArgument, secondArgument);
        }
        catch (Exception exception)
        {
            if (exception instanceof ServiceTestException)
            {
                throw (ServiceTestException)exception;
            }
            if (exception instanceof OperationTestException)
            {
                throw (OperationTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof ServiceTestException)
            {
                throw (ServiceTestException)cause;
            }
            if (cause instanceof OperationTestException)
            {
                throw (OperationTestException)cause;
            }
            throw new RuntimeException(cause);
        }
    }

    /**
     * Finds the root cause of the parent exception
     * by traveling up the exception tree.
     */
    private static Throwable getRootCause(Throwable throwable)
    {
        if (throwable != null)
        {
            // Reflectively get any exception causes.
            try
            {
                Throwable targetException = null;

                // java.lang.reflect.InvocationTargetException
                String exceptionProperty = "targetException";
                if (PropertyUtils.isReadable(throwable, exceptionProperty))
                {
                    targetException = (Throwable)PropertyUtils.getProperty(throwable, exceptionProperty);
                }
                else
                {
                    exceptionProperty = "causedByException";
                    //javax.ejb.EJBException
                    if (PropertyUtils.isReadable(throwable, exceptionProperty))
                    {
                        targetException = (Throwable)PropertyUtils.getProperty(throwable, exceptionProperty);
                    }
                }
                if (targetException != null)
                {
                    throwable = targetException;
                }
            }
            catch (Exception exception)
            {
                // just print the exception and continue
                exception.printStackTrace();
            }
            if (throwable.getCause() != null)
            {
                throwable = throwable.getCause();
                throwable = getRootCause(throwable);
            }
        }
        return throwable;
    }
}