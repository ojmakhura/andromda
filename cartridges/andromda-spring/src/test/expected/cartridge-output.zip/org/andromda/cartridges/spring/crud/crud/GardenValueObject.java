/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.io.Serializable;
public class GardenValueObject
    implements Serializable
{
    private int integer;

    public int getInteger()
    {
        return this.integer;
    }

    public void setInteger(int integer)
    {
        this.integer = integer;
    }

    private Integer intWrapper;

    public Integer getIntWrapper()
    {
        return this.intWrapper;
    }

    public void setIntWrapper(Integer intWrapper)
    {
        this.intWrapper = intWrapper;
    }

    private Long id;

    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    private Long room;

    public Long getRoom()
    {
        return this.room;
    }

    public void setRoom(Long room)
    {
        this.room = room;
    }

    private Long[] houses;

    public Long[] getHouses()
    {
        return this.houses;
    }

    public void setHouses(Long[] houses)
    {
        this.houses = houses;
    }

}