/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityOne
 */
public class EntityOneDaoImpl
    extends org.andromda.cartridges.spring.EntityOneDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#toValueObject(org.andromda.cartridges.spring.EntityOne)
     */
    public org.andromda.cartridges.spring.TestValueObject toValueObject(org.andromda.cartridges.spring.EntityOne entity)
    {
        // put your implementation here
        return null;
    }

}
