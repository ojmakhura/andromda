/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.EntityOne
 */
public class EntityOneDaoImpl
    extends org.andromda.cartridges.hibernate.EntityOneDaoBase
{
    /**
     * @see org.andromda.cartridges.hibernate.EntityOneDaoBase#transformEntity(org.andromda.cartridges.hibernate.EntityOne)
     */ 
    protected Object transformFinderEntity(org.andromda.cartridges.hibernate.EntityOne entity)
    {
        /* 
         * This method provides the ability to transform 
         * your entity finder results into value objects.
         * If you aren't using value objects, and just
         * want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}
