/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceTwo
 */
public class ServiceTwoImpl
	extends org.andromda.cartridges.hibernate.ServiceTwoBase
{
    
	/**
	 * @see org.andromda.cartridges.hibernate.ServiceTwo#operationOne()
	 */
    public org.andromda.cartridges.hibernate.TestValueObject operationOne() 
    {
        //@todo implement public org.andromda.cartridges.hibernate.TestValueObject operationOne()
        return null;
    }
	
	/**
	 * @see org.andromda.cartridges.hibernate.ServiceTwo#operationTwo()
	 */
    public java.lang.String operationTwo() 
    {
        //@todo implement public java.lang.String operationTwo()
        return null;
    }
	
}
