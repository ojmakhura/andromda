/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

public final class GardenManageableDaoBase
    extends org.springframework.orm.hibernate.support.HibernateDaoSupport
    implements GardenManageableDao
{
    private org.andromda.cartridges.spring.crud.GardenDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.GardenDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.GardenDao getDao()
    {
        return this.dao;
    }

    private org.andromda.cartridges.spring.crud.RoomDao roomDao = null;

    public void setRoomDao(org.andromda.cartridges.spring.crud.RoomDao roomDao)
    {
        this.roomDao = roomDao;
    }

    protected org.andromda.cartridges.spring.crud.RoomDao getRoomDao()
    {
        return this.roomDao;
    }

    private org.andromda.cartridges.spring.crud.HouseDao housesDao = null;

    public void setHousesDao(org.andromda.cartridges.spring.crud.HouseDao housesDao)
    {
        this.housesDao = housesDao;
    }

    protected org.andromda.cartridges.spring.crud.HouseDao getHousesDao()
    {
        return this.housesDao;
    }

    protected java.util.Set findHouseByIds(java.lang.Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public void create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
    {
        final org.andromda.cartridges.spring.crud.Garden entity = new org.andromda.cartridges.spring.crud.GardenImpl();
        entity.setInteger(integer);
        entity.setIntWrapper(intWrapper);
        entity.setId(id);
        org.andromda.cartridges.spring.crud.Room roomEntity = null;
        if (room != null)
        {
            roomEntity = getRoomDao().load(room);
        }
        entity.setRoom(roomEntity);
        java.util.Set housesEntities = null;
        if (houses != null)
        {
            housesEntities = this.findHouseByIds(houses);
        }
        if (housesEntities != null)
        {
            entity.setHouses(housesEntities);
            // set the other ends of the many2many association too
            for (final java.util.Iterator iterator = housesEntities.iterator(); iterator.hasNext();)
            {
                final org.andromda.cartridges.spring.crud.House element = (org.andromda.cartridges.spring.crud.House)iterator.next();
                element.getGardens().add(entity);
            }
        }

        this.getDao().create(entity);
    }

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);

            criteria.add(Expression.eq("integer", new java.lang.Integer(integer)));
            if (intWrapper != null)
            criteria.add(Expression.eq("intWrapper", intWrapper));
            if (id != null)
            criteria.add(Expression.eq("id", id));
            if (room != null) criteria.createCriteria("room").add(Expression.eq("specificId", room));
            if (houses != null) criteria.createCriteria("houses").add(Expression.in("id", houses));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.Map readBackingLists()
    {
        final java.util.Map lists = new java.util.HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("room", session.createQuery("select item.specificId, item.specificId from org.andromda.cartridges.spring.crud.Room item order by item.specificId").list());
            lists.put("houses", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public void update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
    {
        final org.andromda.cartridges.spring.crud.Garden entity = this.getDao().load(id);

        entity.setInteger(integer);
        entity.setIntWrapper(intWrapper);
        org.andromda.cartridges.spring.crud.Room roomEntity = null;
        if (room != null)
        {
            roomEntity = getRoomDao().load(room);
        }
        entity.setRoom(roomEntity);
        java.util.Set housesEntities = null;
        if (houses != null)
        {
            housesEntities = this.findHouseByIds(houses);
        }
        if (housesEntities != null)
        {
            entity.setHouses(housesEntities);
            // set the other ends of the many2many association too
            for (final java.util.Iterator iterator = housesEntities.iterator(); iterator.hasNext();)
            {
                final org.andromda.cartridges.spring.crud.House element = (org.andromda.cartridges.spring.crud.House)iterator.next();
                element.getGardens().add(entity);
            }
        }

        this.getDao().update(entity);
    }

    public void delete(java.lang.Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            final java.util.List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}