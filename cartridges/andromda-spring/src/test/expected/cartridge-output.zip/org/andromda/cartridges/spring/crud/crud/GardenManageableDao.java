/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface GardenManageableDao
{
    public void create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public java.util.List readAll();

    public java.util.Map readBackingLists();

    public void update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public void delete(java.lang.Long[] ids);

}