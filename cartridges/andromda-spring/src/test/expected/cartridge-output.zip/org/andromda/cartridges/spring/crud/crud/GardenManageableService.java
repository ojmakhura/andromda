/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.List;
import java.util.Map;
public interface GardenManageableService
{
    public GardenValueObject create(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception;

    public GardenValueObject readById(Long id)
        throws Exception;

    public List read(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception;

    public List readAll()
        throws Exception;

    public Map readBackingLists()
        throws Exception;

    public GardenValueObject update(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception;

    public void delete(Long[] ids)
        throws Exception;

}
