/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibSubclass1
 */
public class HibSubclass1Impl
    extends org.andromda.cartridges.spring.HibSubclassBaseImpl
{
    /**
     * @see org.andromda.cartridges.spring.HibSubclass1Dao#sc1Op()
     */
    public java.lang.String sc1Op()
    {
        //@todo implement public java.lang.String sc1Op()
        return null;
    }

}
