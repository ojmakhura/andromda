/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Futurenum;
public interface MansionManageableService
{
    public MansionValueObject create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public MansionValueObject readById(Long id)
        throws Exception;

    public List read(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public List readAll()
        throws Exception;

    public Map readBackingLists()
        throws Exception;

    public MansionValueObject update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public void delete(Long[] ids)
        throws Exception;

}
