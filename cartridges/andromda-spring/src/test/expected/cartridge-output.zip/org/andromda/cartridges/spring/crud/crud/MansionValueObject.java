/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public class MansionValueObject
    extends HouseValueObject
{
    private String name;

    public String getName()
    {
        return this.name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    private Long[] houses;

    public Long[] getHouses()
    {
        return this.houses;
    }

    public void setHouses(Long[] houses)
    {
        this.houses = houses;
    }

}