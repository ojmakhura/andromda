/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

public final class RoomManageableDaoBase
    extends org.springframework.orm.hibernate.support.HibernateDaoSupport
    implements RoomManageableDao
{
    private org.andromda.cartridges.spring.crud.RoomDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.RoomDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.RoomDao getDao()
    {
        return this.dao;
    }

    private org.andromda.cartridges.spring.crud.GardenDao gardensDao = null;

    public void setGardensDao(org.andromda.cartridges.spring.crud.GardenDao gardensDao)
    {
        this.gardensDao = gardensDao;
    }

    protected org.andromda.cartridges.spring.crud.GardenDao getGardensDao()
    {
        return this.gardensDao;
    }

    private org.andromda.cartridges.spring.crud.HouseDao namedDao = null;

    public void setNamedDao(org.andromda.cartridges.spring.crud.HouseDao namedDao)
    {
        this.namedDao = namedDao;
    }

    protected org.andromda.cartridges.spring.crud.HouseDao getNamedDao()
    {
        return this.namedDao;
    }

    private org.andromda.cartridges.spring.crud.GardenDao hellosDao = null;

    public void setHellosDao(org.andromda.cartridges.spring.crud.GardenDao hellosDao)
    {
        this.hellosDao = hellosDao;
    }

    protected org.andromda.cartridges.spring.crud.GardenDao getHellosDao()
    {
        return this.hellosDao;
    }

    private java.util.Set findGardenByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findHouseByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public org.andromda.cartridges.spring.crud.Room create(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hellos)
    {
        final org.andromda.cartridges.spring.crud.Room entity = new org.andromda.cartridges.spring.crud.RoomImpl();
        entity.setDate(date);
        entity.setSpecificId(specificId);
        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        org.andromda.cartridges.spring.crud.House namedEntity = null;
        if (named != null)
        {
            namedEntity = (org.andromda.cartridges.spring.crud.House)getNamedDao().load(named);
        }

        entity.setNamed(namedEntity);

        final java.util.Set hellosEntities = (hellos != null && hellos.length > 0)
            ? this.findGardenByIds(hellos)
            : java.util.Collections.EMPTY_SET;

        entity.setHellos(hellosEntities);


        return (org.andromda.cartridges.spring.crud.Room)this.getDao().create(entity);
    }

    public org.andromda.cartridges.spring.crud.Room readById(java.lang.Long specificId)
    {
        return getDao().load(specificId);
    }

    public java.util.List read(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hellos)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);

            if (date != null)
            {
                // we check whether or not the user supplied time information within this particular date argument
                // if he/she didn't we assume he/she wishes to search in the scope of the entire day
                final java.util.Calendar calendar = new java.util.GregorianCalendar();
                calendar.setTime(date);
                if ( calendar.get(java.util.Calendar.HOUR) != 0
                     || calendar.get(java.util.Calendar.MINUTE) != 0
                     || calendar.get(java.util.Calendar.SECOND) != 0
                     || calendar.get(java.util.Calendar.MILLISECOND) != 0 )
                {
                    criteria.add(Expression.eq("date", date));
                }
                else
                {
                    calendar.add(java.util.Calendar.DATE, 1);
                    criteria.add(Expression.between("date", date, calendar.getTime()));
                }
            }
            if (specificId != null)
            criteria.add(Expression.eq("specificId", specificId));
            if (gardens != null && gardens.length > 0) criteria.createCriteria("gardens").add(Expression.in("id", gardens));
            if (named != null) criteria.createCriteria("named").add(Expression.eq("id", named));
            if (hellos != null && hellos.length > 0) criteria.createCriteria("hellos").add(Expression.in("id", hellos));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.Map readBackingLists()
    {
        final java.util.Map lists = new java.util.HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("gardens", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
            lists.put("named", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
            lists.put("hellos", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public org.andromda.cartridges.spring.crud.Room update(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hellos)
    {
        final org.andromda.cartridges.spring.crud.Room entity = this.getDao().load(specificId);

        entity.setDate(date);
        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        org.andromda.cartridges.spring.crud.House namedEntity = null;
        if (named != null)
        {
            namedEntity = getNamedDao().load(named);
        }

        entity.setNamed(namedEntity);

        final java.util.Set hellosEntities = (hellos != null && hellos.length > 0)
            ? this.findGardenByIds(hellos)
            : java.util.Collections.EMPTY_SET;

        entity.setHellos(hellosEntities);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(java.lang.Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            final java.util.List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}