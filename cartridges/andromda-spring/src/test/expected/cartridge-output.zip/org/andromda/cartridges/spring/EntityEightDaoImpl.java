/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityEight
 */
public class EntityEightDaoImpl
    extends org.andromda.cartridges.spring.EntityEightDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityEightDaoBase#transformEntity(org.andromda.cartridges.spring.EntityEight)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.EntityEight entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}