/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.EntityThree
 */
public class EntityThreeDaoImpl
    extends org.andromda.cartridges.hibernate.EntityThreeDaoBase
{
    /**
     * @see org.andromda.cartridges.hibernate.EntityThreeDaoBase#transformEntity(org.andromda.cartridges.hibernate.EntityThree)
     */ 
    protected Object transformEntity(org.andromda.cartridges.hibernate.EntityThree entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}
