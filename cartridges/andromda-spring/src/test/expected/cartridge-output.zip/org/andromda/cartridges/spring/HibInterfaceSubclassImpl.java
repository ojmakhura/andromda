/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibInterfaceSubclass
 */
public class HibInterfaceSubclassImpl
    extends org.andromda.cartridges.spring.HibInterfaceBaseImpl
{
    /**
     * @see org.andromda.cartridges.spring.HibInterfaceSubclassDao#scOp()
     */
    public long scOp()
    {
        //@todo implement public long scOp()
        return null;
    }

}
