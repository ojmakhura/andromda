/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see org.andromda.cartridges.spring.EntityThree
 */
public class EntityThreeDaoImpl
    extends org.andromda.cartridges.spring.EntityThreeDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#toAttributeTwo(org.andromda.cartridges.spring.EntityThree, java.lang.Long)
     */
    public void toAttributeTwo(
        org.andromda.cartridges.spring.EntityThree source,
        java.lang.Long target)
    {
        // @todo verify behavior of toAttributeTwo
        super.toAttributeTwo(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#toAttributeTwo(org.andromda.cartridges.spring.EntityThree)
     */
    public java.lang.Long toAttributeTwo(final org.andromda.cartridges.spring.EntityThree entity)
    {
        // @todo verify behavior of toAttributeTwo
        return super.toAttributeTwo(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.EntityThree loadEntityThreeFromLong(java.lang.Long attributeTwo)
    {
        // @todo implement loadEntityThreeFromLong
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityThreeFromLong(java.lang.Long) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.EntityThree entityThree = this.load(attributeTwo.getId());
        if (entityThree == null)
        {
            entityThree = org.andromda.cartridges.spring.EntityThree.Factory.newInstance();
        }
        return entityThree;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#attributeTwoToEntity(java.lang.Long)
     */
    public org.andromda.cartridges.spring.EntityThree attributeTwoToEntity(java.lang.Long attributeTwo)
    {
        // @todo verify behavior of attributeTwoToEntity
        org.andromda.cartridges.spring.EntityThree entity = this.loadEntityThreeFromLong(attributeTwo);
        this.attributeTwoToEntity(attributeTwo, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#attributeTwoToEntity(java.lang.Long, org.andromda.cartridges.spring.EntityThree)
     */
    public void attributeTwoToEntity(
        java.lang.Long source,
        org.andromda.cartridges.spring.EntityThree target,
        boolean copyIfNull)
    {
        // @todo verify behavior of attributeTwoToEntity
        super.attributeTwoToEntity(source, target, copyIfNull);
    }

}