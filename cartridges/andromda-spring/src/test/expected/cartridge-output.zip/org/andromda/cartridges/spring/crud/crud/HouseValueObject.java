/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public class HouseValueObject
    implements java.io.Serializable
{
    private java.lang.String something;

    public java.lang.String getSomething()
    {
        return this.something;
    }

    public void setSomething(java.lang.String something)
    {
        this.something = something;
    }

    private org.andromda.cartridges.spring.crud.Futurenum enumAttribute;

    public org.andromda.cartridges.spring.crud.Futurenum getEnumAttribute()
    {
        return this.enumAttribute;
    }

    public void setEnumAttribute(org.andromda.cartridges.spring.crud.Futurenum enumAttribute)
    {
        this.enumAttribute = enumAttribute;
    }

    private java.lang.Long id;

    public java.lang.Long getId()
    {
        return this.id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    private java.lang.Long room;

    public java.lang.Long getRoom()
    {
        return this.room;
    }

    public void setRoom(java.lang.Long room)
    {
        this.room = room;
    }

    private java.lang.Long[] gardens;

    public java.lang.Long[] getGardens()
    {
        return this.gardens;
    }

    public void setGardens(java.lang.Long[] gardens)
    {
        this.gardens = gardens;
    }

    private int[] gardensLabels;

    public int[] getGardensLabels()
    {
        return this.gardensLabels;
    }

    public void setGardensLabels(int[] gardensLabels)
    {
        this.gardensLabels = gardensLabels;
    }

    private java.lang.Long mansion;

    public java.lang.Long getMansion()
    {
        return this.mansion;
    }

    public void setMansion(java.lang.Long mansion)
    {
        this.mansion = mansion;
    }

}