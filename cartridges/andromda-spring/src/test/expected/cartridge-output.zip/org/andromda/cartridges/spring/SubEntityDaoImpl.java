/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SubEntity
 */
public class SubEntityDaoImpl
	extends org.andromda.cartridges.spring.SuperEntityDaoImpl
{

}