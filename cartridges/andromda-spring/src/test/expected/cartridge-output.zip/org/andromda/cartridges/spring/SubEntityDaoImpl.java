/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see SubEntity
 */
public class SubEntityDaoImpl
    extends SubEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO2(SubEntity, SubEntityVO2)
     */
    public void toSubEntityVO2(
        SubEntity source,
        SubEntityVO2 target)
    {
        // @todo verify behavior of toSubEntityVO2
        super.toSubEntityVO2(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO2(SubEntity)
     */
    public SubEntityVO2 toSubEntityVO2(final SubEntity entity)
    {
        // @todo verify behavior of toSubEntityVO2
        return super.toSubEntityVO2(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private SubEntity loadSubEntityFromSubEntityVO2(SubEntityVO2 subEntityVO2)
    {
        // @todo implement loadSubEntityFromSubEntityVO2
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadSubEntityFromSubEntityVO2(SubEntityVO2) not yet implemented.");

        /* A typical implementation looks like this:
        SubEntity subEntity = this.load(subEntityVO2.getId());
        if (subEntity == null)
        {
            subEntity = SubEntity.Factory.newInstance();
        }
        return subEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO2ToEntity(SubEntityVO2)
     */
    public SubEntity subEntityVO2ToEntity(SubEntityVO2 subEntityVO2)
    {
        // @todo verify behavior of subEntityVO2ToEntity
        SubEntity entity = this.loadSubEntityFromSubEntityVO2(subEntityVO2);
        this.subEntityVO2ToEntity(subEntityVO2, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO2ToEntity(SubEntityVO2, SubEntity)
     */
    public void subEntityVO2ToEntity(
        SubEntityVO2 source,
        SubEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of subEntityVO2ToEntity
        super.subEntityVO2ToEntity(source, target, copyIfNull);
    }

    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO1(SubEntity, SubEntityVO1)
     */
    public void toSubEntityVO1(
        SubEntity source,
        SubEntityVO1 target)
    {
        // @todo verify behavior of toSubEntityVO1
        super.toSubEntityVO1(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO1(SubEntity)
     */
    public SubEntityVO1 toSubEntityVO1(final SubEntity entity)
    {
        // @todo verify behavior of toSubEntityVO1
        return super.toSubEntityVO1(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private SubEntity loadSubEntityFromSubEntityVO1(SubEntityVO1 subEntityVO1)
    {
        // @todo implement loadSubEntityFromSubEntityVO1
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadSubEntityFromSubEntityVO1(SubEntityVO1) not yet implemented.");

        /* A typical implementation looks like this:
        SubEntity subEntity = this.load(subEntityVO1.getId());
        if (subEntity == null)
        {
            subEntity = SubEntity.Factory.newInstance();
        }
        return subEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO1ToEntity(SubEntityVO1)
     */
    public SubEntity subEntityVO1ToEntity(SubEntityVO1 subEntityVO1)
    {
        // @todo verify behavior of subEntityVO1ToEntity
        SubEntity entity = this.loadSubEntityFromSubEntityVO1(subEntityVO1);
        this.subEntityVO1ToEntity(subEntityVO1, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO1ToEntity(SubEntityVO1, SubEntity)
     */
    public void subEntityVO1ToEntity(
        SubEntityVO1 source,
        SubEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of subEntityVO1ToEntity
        super.subEntityVO1ToEntity(source, target, copyIfNull);
    }

}