/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Garden;
import org.andromda.cartridges.spring.crud.House;
import org.andromda.cartridges.spring.crud.Room;
public final class GardenManageableServiceBase
    implements GardenManageableService
{
    private GardenManageableDao dao;

    public void setDao(GardenManageableDao dao)
    {
        this.dao = dao;
    }

    protected GardenManageableDao getDao()
    {
        return this.dao;
    }

    public GardenValueObject create(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, Integer intWrapper, Long id, Long room, Long[] houses) - 'intWrapper' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, Integer intWrapper, Long id, Long room, Long[] houses) - 'room' can not be null");
        }

        return toValueObject(dao.create(integer, intWrapper, id, room, houses));
    }

    public GardenValueObject readById(Long id)
        throws Exception
    {
        return toValueObject(dao.readById(id));
    }

    public List read(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception
    {
        return toValueObjects(dao.read(integer, intWrapper, id, room, houses));
    }

    public List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public GardenValueObject update(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, Integer intWrapper, Long id, Long room, Long[] houses) - 'intWrapper' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, Integer intWrapper, Long id, Long room, Long[] houses) - 'id' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, Integer intWrapper, Long id, Long room, Long[] houses) - 'room' can not be null");
        }

        return toValueObject(dao.update(integer, intWrapper, id, room, houses));
    }

    public void delete(Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.delete(Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private static List toValueObjects(Collection entities)
    {
        final List list = new ArrayList();

        for (Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((Garden)iterator.next()));
        }

        return list;
    }

    private static GardenValueObject toValueObject(Garden entity)
    {
        final GardenValueObject valueObject = new GardenValueObject();

        valueObject.setInteger(entity.getInteger());
        valueObject.setIntWrapper(entity.getIntWrapper());
        valueObject.setId(entity.getId());

        final Room room = entity.getRoom();
        if (room != null)
        {
            valueObject.setRoom(room.getSpecificId());
        }

        final Collection houses = entity.getHouses();
        if (houses == null || houses.isEmpty())
        {
            valueObject.setHouses(null);
        }
        else
        {
            final Long[] values = new Long[houses.size()];
            int counter = 0;
            for (final Iterator iterator = houses.iterator(); iterator.hasNext();counter++)
            {
                final House element = (House)iterator.next();
                values[counter] = element.getId();
            }
            valueObject.setHouses(values);
        }

        return valueObject;
    }
}
