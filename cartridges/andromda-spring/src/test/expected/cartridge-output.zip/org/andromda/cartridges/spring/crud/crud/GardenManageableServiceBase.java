/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public final class GardenManageableServiceBase
    implements GardenManageableService
{
    private org.andromda.cartridges.spring.crud.crud.GardenManageableDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.crud.GardenManageableDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.crud.GardenManageableDao getDao()
    {
        return this.dao;
    }

    public org.andromda.cartridges.spring.crud.crud.GardenValueObject create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'intWrapper' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'room' can not be null");
        }

        return toValueObject(dao.create(integer, intWrapper, id, room, houses));
    }

    public org.andromda.cartridges.spring.crud.crud.GardenValueObject readById(java.lang.Long id)
        throws Exception
    {
        return toValueObject(dao.readById(id));
    }

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        return toValueObjects(dao.read(integer, intWrapper, id, room, houses));
    }

    public java.util.List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public java.util.Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public org.andromda.cartridges.spring.crud.crud.GardenValueObject update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'intWrapper' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'id' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'room' can not be null");
        }

        return toValueObject(dao.update(integer, intWrapper, id, room, houses));
    }

    public void delete(java.lang.Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.delete(java.lang.Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private static java.util.List toValueObjects(java.util.Collection entities)
    {
        final java.util.List list = new java.util.ArrayList();

        for (java.util.Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((org.andromda.cartridges.spring.crud.Garden)iterator.next()));
        }

        return list;
    }

    private static org.andromda.cartridges.spring.crud.crud.GardenValueObject toValueObject(org.andromda.cartridges.spring.crud.Garden entity)
    {
        final org.andromda.cartridges.spring.crud.crud.GardenValueObject valueObject = new org.andromda.cartridges.spring.crud.crud.GardenValueObject();

        valueObject.setInteger(entity.getInteger());
        valueObject.setIntWrapper(entity.getIntWrapper());
        valueObject.setId(entity.getId());

        final org.andromda.cartridges.spring.crud.Room room = entity.getRoom();
        if (room != null)
        {
            valueObject.setRoom(room.getSpecificId());
        }

        final java.util.Collection houses = entity.getHouses();
        if (houses == null || houses.isEmpty())
        {
            valueObject.setHouses(null);
        }
        else
        {
            final java.lang.Long[] values = new java.lang.Long[houses.size()];
            int counter = 0;
            for (final java.util.Iterator iterator = houses.iterator(); iterator.hasNext();counter++)
            {
                final org.andromda.cartridges.spring.crud.House element = (org.andromda.cartridges.spring.crud.House)iterator.next();
                values[counter] = element.getId();
            }
            valueObject.setHouses(values);
        }

        return valueObject;
    }
}
