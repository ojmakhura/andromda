/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 * TEMPLATE:    SpringServiceImpl.vsl in andromda-spring cartridge
 * MODEL CLASS: SpringCartridgeTestModel::org.andromda.cartridges.spring::BaseAbstractService
 * STEREOTYPE:  Service
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.BaseAbstractService
 */
public abstract class BaseAbstractServiceImpl
    extends BaseAbstractServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.BaseAbstractService#operationOne()
     */
    @Override
    protected  String handleOperationOne()
        throws Exception
    {
        // TODO implement protected  String handleOperationOne()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.BaseAbstractService.handleOperationOne() Not implemented!");
    }

}