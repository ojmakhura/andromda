/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.io.Serializable;
import java.util.Date;
public class RoomValueObject
    implements Serializable
{
    private Date date;

    public Date getDate()
    {
        return this.date;
    }

    public void setDate(Date date)
    {
        this.date = date;
    }

    private Long specificId;

    public Long getSpecificId()
    {
        return this.specificId;
    }

    public void setSpecificId(Long specificId)
    {
        this.specificId = specificId;
    }

    private Long[] gardens;

    public Long[] getGardens()
    {
        return this.gardens;
    }

    public void setGardens(Long[] gardens)
    {
        this.gardens = gardens;
    }

    private int[] gardensLabels;

    public int[] getGardensLabels()
    {
        return this.gardensLabels;
    }

    public void setGardensLabels(int[] gardensLabels)
    {
        this.gardensLabels = gardensLabels;
    }

    private Long named;

    public Long getNamed()
    {
        return this.named;
    }

    public void setNamed(Long named)
    {
        this.named = named;
    }

    private Long[] hellos;

    public Long[] getHellos()
    {
        return this.hellos;
    }

    public void setHellos(Long[] hellos)
    {
        this.hellos = hellos;
    }

    private int[] hellosLabels;

    public int[] getHellosLabels()
    {
        return this.hellosLabels;
    }

    public void setHellosLabels(int[] hellosLabels)
    {
        this.hellosLabels = hellosLabels;
    }

}