/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityFour
 */
public class EntityFourDaoImpl
    extends org.andromda.cartridges.spring.EntityFourDaoBase
{
	/**
	 * @see org.andromda.cartridges.spring.EntityFourDao#daoOperation(java.lang.String)
	 */
    public java.lang.Long handleDaoOperation(java.lang.String paramOne) 
    {
        //@todo implement public java.lang.Long handleDaoOperation(java.lang.String paramOne)
        return null;
    }
	

}