/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityFour
 */
public class EntityFourDaoImpl
    extends org.andromda.cartridges.spring.EntityFourDaoBase
{
	/**
	 * @see org.andromda.cartridges.spring.EntityFourDao#daoOperation(java.lang.String)
	 */
    public java.lang.Long daoOperation(java.lang.String paramOne) 
    {
        //@todo implement public java.lang.Long daoOperation(java.lang.String paramOne)
        return null;
    }
	
    /**
     * @see org.andromda.cartridges.spring.EntityFourDaoBase#transformEntity(org.andromda.cartridges.spring.EntityFour)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.EntityFour entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}