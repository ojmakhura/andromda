/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 * TEMPLATE:    SpringServiceImpl.vsl in andromda-spring cartridge
 * MODEL CLASS: SpringCartridgeTestModel::org.andromda.cartridges.spring::ServiceOne
 * STEREOTYPE:  Service
 * STEREOTYPE:  WebService
 */
package org.andromda.cartridges.spring;

import java.util.Collection;
import java.util.Date;

/**
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneImpl
    extends ServiceOneBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    protected  void handleOperationWithVoidReturnType()
        throws Exception
    {
        // TODO implement protected  void handleOperationWithVoidReturnType()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithVoidReturnType() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    protected  String handleOperationWithSimpleReturnType()
        throws Exception
    {
        // TODO implement protected  String handleOperationWithSimpleReturnType()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithSimpleReturnType() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    protected  Collection handleOperationWithComplexReturnType()
        throws Exception
    {
        // TODO implement protected  Collection handleOperationWithComplexReturnType()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithComplexReturnType() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(Date)
     */
    protected  String handleOperationWithSingleArgument(Date argumentOne)
        throws Exception
    {
        // TODO implement protected  String handleOperationWithSingleArgument(Date argumentOne)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithSingleArgument(Date argumentOne) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(Long, Boolean)
     */
    protected  void handleOperationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throws Exception
    {
        // TODO implement protected  void handleOperationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithMultipleArguments(Long firstArgument, Boolean secondArgument) Not implemented!");
    }

}