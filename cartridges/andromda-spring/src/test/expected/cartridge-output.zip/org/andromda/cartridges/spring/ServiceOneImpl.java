/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneImpl
	extends org.andromda.cartridges.spring.ServiceOneBase
{
    
	/**
	 * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
	 */
    public void handleOperationWithVoidReturnType() 
        throws java.lang.Exception
    {
        //@todo implement public void handleOperationWithVoidReturnType()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithVoidReturnType() Not implemented!");
    }
	
	/**
	 * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
	 */
    public java.lang.String handleOperationWithSimpleReturnType() 
        throws java.lang.Exception
    {
        //@todo implement public java.lang.String handleOperationWithSimpleReturnType()
        return null;
    }
	
	/**
	 * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
	 */
    public java.util.Collection handleOperationWithComplexReturnType() 
        throws java.lang.Exception
    {
        //@todo implement public java.util.Collection handleOperationWithComplexReturnType()
        return null;
    }
	
	/**
	 * @see org.andromda.cartridges.spring.ServiceOne#SoperationWithSingleArgument(java.util.Date)
	 */
    public java.lang.String handleSoperationWithSingleArgument(java.util.Date argumentOne) 
        throws java.lang.Exception
    {
        //@todo implement public java.lang.String handleSoperationWithSingleArgument(java.util.Date argumentOne)
        return null;
    }
	
	/**
	 * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
	 */
    public void handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument) 
        throws java.lang.Exception
    {
        //@todo implement public void handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument) Not implemented!");
    }
	
}
