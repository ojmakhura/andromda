/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneImpl
    extends org.andromda.cartridges.spring.ServiceOneBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    protected void handleOperationWithVoidReturnType()
        throws java.lang.Exception
    {
        //@todo implement protected void handleOperationWithVoidReturnType()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithVoidReturnType() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    protected java.lang.String handleOperationWithSimpleReturnType()
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleOperationWithSimpleReturnType()
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    protected java.util.Collection handleOperationWithComplexReturnType()
        throws java.lang.Exception
    {
        //@todo implement protected java.util.Collection handleOperationWithComplexReturnType()
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(java.util.Date)
     */
    protected java.lang.String handleOperationWithSingleArgument(java.util.Date argumentOne)
        throws java.lang.Exception
    {
        //@todo implement protected java.lang.String handleOperationWithSingleArgument(java.util.Date argumentOne)
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
     */
    protected void handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws java.lang.Exception
    {
        //@todo implement protected void handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.ServiceOne.handleOperationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument) Not implemented!");
    }

}