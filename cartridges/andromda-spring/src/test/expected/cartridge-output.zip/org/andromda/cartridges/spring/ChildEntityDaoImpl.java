/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ChildEntity
 */
public class ChildEntityDaoImpl
    extends org.andromda.cartridges.spring.ChildEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#toChildEntityVO(org.andromda.cartridges.spring.ChildEntity)
     */
    public org.andromda.cartridges.spring.ChildEntityVO toChildEntityVO(final org.andromda.cartridges.spring.ChildEntity entity)
    {
        // put your implementation here
        return null;
    }
    
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#childEntityVOToEntity(org.andromda.cartridges.spring.ChildEntityVO)
     */
    public org.andromda.cartridges.spring.ChildEntity childEntityVOToEntity(org.andromda.cartridges.spring.ChildEntityVO childEntityVO)
    {
        // put your implementation here
        return null;    
    }

}