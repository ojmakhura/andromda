/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see ChildEntity
 */
public class ChildEntityDaoImpl
    extends ChildEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#toChildEntityVO(ChildEntity, ChildEntityVO)
     */
    public void toChildEntityVO(
        ChildEntity source,
        ChildEntityVO target)
    {
        // @todo verify behavior of toChildEntityVO
        super.toChildEntityVO(source, target);
        // WARNING! No conversion for target.misMatchedAttribute (can't convert source.getMisMatchedAttribute():java.sql.Timestamp to java.lang.Float
    }


    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#toChildEntityVO(ChildEntity)
     */
    public ChildEntityVO toChildEntityVO(final ChildEntity entity)
    {
        // @todo verify behavior of toChildEntityVO
        return super.toChildEntityVO(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private ChildEntity loadChildEntityFromChildEntityVO(ChildEntityVO childEntityVO)
    {
        // @todo implement loadChildEntityFromChildEntityVO
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadChildEntityFromChildEntityVO(ChildEntityVO) not yet implemented.");

        /* A typical implementation looks like this:
        ChildEntity childEntity = this.load(childEntityVO.getId());
        if (childEntity == null)
        {
            childEntity = ChildEntity.Factory.newInstance();
        }
        return childEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#childEntityVOToEntity(ChildEntityVO)
     */
    public ChildEntity childEntityVOToEntity(ChildEntityVO childEntityVO)
    {
        // @todo verify behavior of childEntityVOToEntity
        ChildEntity entity = this.loadChildEntityFromChildEntityVO(childEntityVO);
        this.childEntityVOToEntity(childEntityVO, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#childEntityVOToEntity(ChildEntityVO, ChildEntity)
     */
    public void childEntityVOToEntity(
        ChildEntityVO source,
        ChildEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of childEntityVOToEntity
        super.childEntityVOToEntity(source, target, copyIfNull);
        // No conversion for target.misMatchedAttribute (can't convert source.getMisMatchedAttribute():java.lang.Float to java.sql.Timestamp
    }

}