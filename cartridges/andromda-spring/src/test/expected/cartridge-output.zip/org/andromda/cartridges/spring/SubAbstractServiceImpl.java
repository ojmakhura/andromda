/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SubAbstractService
 */
public class SubAbstractServiceImpl
    extends SubAbstractServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.SubAbstractService#operationTwo()
     */
    protected  String handleOperationTwo()
        throws Exception
    {
        // @todo implement protected  String handleOperationTwo()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.SubAbstractService.handleOperationTwo() Not implemented!");
    }

}