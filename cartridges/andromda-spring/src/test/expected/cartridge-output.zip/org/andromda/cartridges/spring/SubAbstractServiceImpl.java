/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SubAbstractService
 */
public class SubAbstractServiceImpl
    extends org.andromda.cartridges.spring.SubAbstractServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.SubAbstractService#operationTwo()
     */
    protected  java.lang.String handleOperationTwo()
        throws java.lang.Exception
    {
        // @todo implement protected  java.lang.String handleOperationTwo()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.SubAbstractService.handleOperationTwo() Not implemented!");
    }

}