/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

import org.andromda.spring.ServiceLocator;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceTwo}.
 *
 * @see ServiceTwo
 */
public class ServiceTwoWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceTwo}
     */
    private final ServiceTwo getServiceTwo()
    {
        return ServiceLocator.instance().getServiceTwo();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    public TestValueObject operationOne()
    {
        try
        {
            return getServiceTwo().operationOne();
        }
        catch (Exception exception)
        {
            final Throwable cause = getRootCause(exception);
            throw new RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    public boolean operationThree()
    {
        try
        {
            return getServiceTwo().operationThree();
        }
        catch (Exception exception)
        {
            final Throwable cause = getRootCause(exception);
            throw new RuntimeException(cause);
        }
    }

    /**
     * Finds the root cause of the parent exception
     * by traveling up the exception tree.
     */
    private static Throwable getRootCause(Throwable throwable)
    {
        if (throwable != null)
        {
            // Reflectively get any exception causes.
            try
            {
                Throwable targetException = null;

                // java.lang.reflect.InvocationTargetException
                String exceptionProperty = "targetException";
                if (PropertyUtils.isReadable(throwable, exceptionProperty))
                {
                    targetException = (Throwable)PropertyUtils.getProperty(throwable, exceptionProperty);
                }
                else
                {
                    exceptionProperty = "causedByException";
                    //javax.ejb.EJBException
                    if (PropertyUtils.isReadable(throwable, exceptionProperty))
                    {
                        targetException = (Throwable)PropertyUtils.getProperty(throwable, exceptionProperty);
                    }
                }
                if (targetException != null)
                {
                    throwable = targetException;
                }
            }
            catch (Exception exception)
            {
                // just print the exception and continue
                exception.printStackTrace();
            }
            if (throwable.getCause() != null)
            {
                throwable = throwable.getCause();
                throwable = getRootCause(throwable);
            }
        }
        return throwable;
    }
}