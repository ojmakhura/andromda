/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceTwo}.
 *
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceTwo}
     */
    private final org.andromda.cartridges.spring.ServiceTwo getServiceTwo()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceTwo();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    public org.andromda.cartridges.spring.TestValueObject operationOne()
    {
        try
        {
            return getServiceTwo().operationOne();
        }
        catch (Exception exception)
        {
            final Throwable cause = getRootCause(exception);
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    public boolean operationThree()
    {
        try
        {
            return getServiceTwo().operationThree();
        }
        catch (Exception exception)
        {
            final Throwable cause = getRootCause(exception);
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * Finds the root cause of the parent exception
     * by traveling up the exception tree.
     */
    private static Throwable getRootCause(Throwable throwable)
    {
        if (throwable != null)
        {
            // Reflectively get any exception causes.
            try
            {
                Throwable targetException = null;

                // java.lang.reflect.InvocationTargetException
                String exceptionProperty = "targetException";
                if (org.apache.commons.beanutils.PropertyUtils.isReadable(throwable, exceptionProperty))
                {
                    targetException = (Throwable)org.apache.commons.beanutils.PropertyUtils.getProperty(throwable, exceptionProperty);
                }
                else
                {
                    exceptionProperty = "causedByException";
                    //javax.ejb.EJBException
                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(throwable, exceptionProperty))
                    {
                        targetException = (Throwable)org.apache.commons.beanutils.PropertyUtils.getProperty(throwable, exceptionProperty);
                    }
                }
                if (targetException != null)
                {
                    throwable = targetException;
                }
            }
            catch (Exception exception)
            {
                // just print the exception and continue
                exception.printStackTrace();
            }
            if (throwable.getCause() != null)
            {
                throwable = throwable.getCause();
                throwable = getRootCause(throwable);
            }
        }
        return throwable;
    }
}