/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceTwo}.
 *
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceTwo}
     */
    private final org.andromda.cartridges.spring.ServiceTwo getServiceTwo()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceTwo();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    public org.andromda.cartridges.spring.TestValueObject operationOne()
    {
        return getServiceTwo().operationOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    public boolean operationThree()
    {
        return getServiceTwo().operationThree();
    }

}