/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.Date;
import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Room;
public interface RoomManageableDao
{
    public Room create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos);

    public Room readById(Long specificId);

    public List read(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos);

    public List readAll();

    public Map readBackingLists();

    public Room update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos);

    public void delete(Long[] ids);

}