/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see SuperEntity
 */
public class SuperEntityDaoImpl
    extends SuperEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO2(SuperEntity, SuperEntityVO2)
     */
    public void toSuperEntityVO2(
        SuperEntity source,
        SuperEntityVO2 target)
    {
        // @todo verify behavior of toSuperEntityVO2
        super.toSuperEntityVO2(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO2(SuperEntity)
     */
    public SuperEntityVO2 toSuperEntityVO2(final SuperEntity entity)
    {
        // @todo verify behavior of toSuperEntityVO2
        return super.toSuperEntityVO2(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private SuperEntity loadSuperEntityFromSuperEntityVO2(SuperEntityVO2 superEntityVO2)
    {
        // @todo implement loadSuperEntityFromSuperEntityVO2
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadSuperEntityFromSuperEntityVO2(SuperEntityVO2) not yet implemented.");

        /* A typical implementation looks like this:
        SuperEntity superEntity = this.load(superEntityVO2.getId());
        if (superEntity == null)
        {
            superEntity = SuperEntity.Factory.newInstance();
        }
        return superEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO2ToEntity(SuperEntityVO2)
     */
    public SuperEntity superEntityVO2ToEntity(SuperEntityVO2 superEntityVO2)
    {
        // @todo verify behavior of superEntityVO2ToEntity
        SuperEntity entity = this.loadSuperEntityFromSuperEntityVO2(superEntityVO2);
        this.superEntityVO2ToEntity(superEntityVO2, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO2ToEntity(SuperEntityVO2, SuperEntity)
     */
    public void superEntityVO2ToEntity(
        SuperEntityVO2 source,
        SuperEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of superEntityVO2ToEntity
        super.superEntityVO2ToEntity(source, target, copyIfNull);
    }

    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO1(SuperEntity, SuperEntityVO1)
     */
    public void toSuperEntityVO1(
        SuperEntity source,
        SuperEntityVO1 target)
    {
        // @todo verify behavior of toSuperEntityVO1
        super.toSuperEntityVO1(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO1(SuperEntity)
     */
    public SuperEntityVO1 toSuperEntityVO1(final SuperEntity entity)
    {
        // @todo verify behavior of toSuperEntityVO1
        return super.toSuperEntityVO1(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private SuperEntity loadSuperEntityFromSuperEntityVO1(SuperEntityVO1 superEntityVO1)
    {
        // @todo implement loadSuperEntityFromSuperEntityVO1
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadSuperEntityFromSuperEntityVO1(SuperEntityVO1) not yet implemented.");

        /* A typical implementation looks like this:
        SuperEntity superEntity = this.load(superEntityVO1.getId());
        if (superEntity == null)
        {
            superEntity = SuperEntity.Factory.newInstance();
        }
        return superEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO1ToEntity(SuperEntityVO1)
     */
    public SuperEntity superEntityVO1ToEntity(SuperEntityVO1 superEntityVO1)
    {
        // @todo verify behavior of superEntityVO1ToEntity
        SuperEntity entity = this.loadSuperEntityFromSuperEntityVO1(superEntityVO1);
        this.superEntityVO1ToEntity(superEntityVO1, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO1ToEntity(SuperEntityVO1, SuperEntity)
     */
    public void superEntityVO1ToEntity(
        SuperEntityVO1 source,
        SuperEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of superEntityVO1ToEntity
        super.superEntityVO1ToEntity(source, target, copyIfNull);
    }

}