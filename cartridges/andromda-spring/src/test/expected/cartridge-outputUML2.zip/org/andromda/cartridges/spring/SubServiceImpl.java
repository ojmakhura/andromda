/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 * TEMPLATE:    SpringServiceImpl.vsl in andromda-spring cartridge
 * MODEL CLASS: SpringCartridgeTestModel::org.andromda.cartridges.spring::SubService
 * STEREOTYPE:  Service
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SubService
 */
public class SubServiceImpl
    extends SubServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.SubService#subOperation(String)
     */
    @Override
    protected  Long handleSubOperation(String paramString)
        throws Exception
    {
        // TODO implement protected  Long handleSubOperation(String paramString)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.SubService.handleSubOperation(String paramString) Not implemented!");
    }

}