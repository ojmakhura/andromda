/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 * TEMPLATE:    SpringServiceImpl.vsl in andromda-spring cartridge
 * MODEL CLASS: SpringCartridgeTestModel::org.andromda.cartridges.spring::MessagingService
 * STEREOTYPE:  Service
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.MessagingService
 */
public class MessagingServiceImpl
    extends MessagingServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.MessagingService#outgoingMessageOperation1(TestValueObject)
     */
    @Override
    protected  void handleOutgoingMessageOperation1(TestValueObject valueObject)
        throws Exception
    {
        // TODO implement protected  void handleOutgoingMessageOperation1(TestValueObject valueObject)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleOutgoingMessageOperation1(TestValueObject valueObject) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#outgoingMessageOperation2(String, Long)
     */
    @Override
    protected  void handleOutgoingMessageOperation2(String param1, Long param2)
        throws Exception
    {
        // TODO implement protected  void handleOutgoingMessageOperation2(String param1, Long param2)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleOutgoingMessageOperation2(String param1, Long param2) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingMessageOperation1()
     */
    @Override
    protected  TestValueObject handleIncomingMessageOperation1()
        throws Exception
    {
        // TODO implement protected  TestValueObject handleIncomingMessageOperation1()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleIncomingMessageOperation1() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingMessageOperation2(String)
     */
    @Override
    protected  Long handleIncomingMessageOperation2(String paramString)
        throws Exception
    {
        // TODO implement protected  Long handleIncomingMessageOperation2(String paramString)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleIncomingMessageOperation2(String paramString) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingTopic1MessageOperation(String)
     */
    @Override
    protected  void handleIncomingTopic1MessageOperation(String test)
        throws Exception
    {
        // TODO implement protected  void handleIncomingTopic1MessageOperation(String test)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleIncomingTopic1MessageOperation(String test) Not implemented!");
    }

}