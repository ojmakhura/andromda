/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice;

/**
 * @see org.andromda.cartridges.webservice.BasicWebServiceTest
 */
public class BasicWebServiceTestImpl
    extends BasicWebServiceTest
{

	/**
	 * Constructor for BasicWebServiceTest.
	 *
	 * @param testName name of the test.
	 */
	public BasicWebServiceTestImpl(String testName) 
	{
		super(testName);
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithArrayParameter()
     */ 
	public void handleTestOperationWithArrayParameter()
	    throws Exception
	{
        org.andromda.cartridges.webservice.ArrayOfbyte arrayParam = null;
        this.service.operationWithArrayParameter(arrayParam);
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithArrayParameter()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithComplexReturnType()
     */ 
	public void handleTestOperationWithComplexReturnType()
	    throws Exception
	{
        this.service.operationWithComplexReturnType();
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithComplexReturnType()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithMultipleArguments()
     */ 
	public void handleTestOperationWithMultipleArguments()
	    throws Exception
	{
        java.lang.Long firstArgument = null;
        java.lang.Boolean secondArgument = null;
        java.lang.String requiredArgument = null;
        this.service.operationWithMultipleArguments(firstArgument, secondArgument, requiredArgument);
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithMultipleArguments()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithSimpleReturnType()
     */ 
	public void handleTestOperationWithSimpleReturnType()
	    throws Exception
	{
        this.service.operationWithSimpleReturnType();
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithSimpleReturnType()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithSingleArgument()
     */ 
	public void handleTestOperationWithSingleArgument()
	    throws Exception
	{
        java.util.Date argumentOne = null;
        this.service.operationWithSingleArgument(argumentOne);
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithSingleArgument()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithSingleComplexReturnTypeNoParameters()
     */ 
	public void handleTestOperationWithSingleComplexReturnTypeNoParameters()
	    throws Exception
	{
        this.service.operationWithSingleComplexReturnTypeNoParameters();
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithSingleComplexReturnTypeNoParameters()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithSingleRelatedComplexTypeAndOneParameter()
     */ 
	public void handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()
	    throws Exception
	{
        java.lang.String parameterOne = null;
        this.service.operationWithSingleRelatedComplexTypeAndOneParameter(parameterOne);
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()  
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.BasicWebServiceTest#testOperationWithVoidReturnType()
     */ 
	public void handleTestOperationWithVoidReturnType()
	    throws Exception
	{
        this.service.operationWithVoidReturnType();
		// @todo implement org.andromda.cartridges.webservice.BasicWebServiceTest.handleTestOperationWithVoidReturnType()  
	}
	
}
