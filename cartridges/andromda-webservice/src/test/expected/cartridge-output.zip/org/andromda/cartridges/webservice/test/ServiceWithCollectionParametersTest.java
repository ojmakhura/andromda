/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.webservice.test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;
import org.andromda.webservice.test.TestServiceLocator;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.ServiceWithCollectionParameters WSDL
 *   using axis's java2wsdl tool in order to run these tests.
 * </p>
 *
 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters
 */
public abstract class ServiceWithCollectionParametersTest
    extends TestCase
{

    /**
     * Constructor for ServiceWithCollectionParametersTest.
     *
     * @param testName name of the test.
     */
    public ServiceWithCollectionParametersTest(String testName)
    {
        super(testName);
    }

    /**
     * Allows the ServiceWithCollectionParametersTest to be run by JUnit as a suite.
     */
    public static Test suite()
    {
           return new TestSuite(ServiceWithCollectionParametersTestImpl.class);
    }

    /**
     * Runs the ServiceWithCollectionParametersTest test case.
     */
    public static void main(String[] args)
    {
        TestRunner.main(new String[] {ServiceWithCollectionParametersTestImpl.class.getName()});
    }

    /**
     * The service under test.
     */
    private ServiceWithCollectionParametersSoapBindingStub service = null;

    /**
     * Returns the service under test {@link org.andromda.cartridges.webservice.test.ServiceWithCollectionParameters}
     */
    protected ServiceWithCollectionParametersSoapBindingStub getService()
        throws Exception
    {
        if (this.username != null || this.password != null)
        {
            this.service = TestServiceLocator.instance().getServiceWithCollectionParameters(username, password);
        }
        else
        {
            this.service = TestServiceLocator.instance().getServiceWithCollectionParameters();
        }
        return this.service;
    }

    /**
     * The username providing access to the service under test.
     */
    private String username;

    /**
     * Sets the <code>username</code> providing access to the
     * service under test.
     *
     * @param username the username providing access to the
     *        service under test.
     */
    protected void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * The password providing access to the service under test.
     */
    private String password;

    /**
     * Sets the <code>password</code> for the service under test.
     *
     * @param password the password for the service under test.
     */
    protected void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Tests: {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionReturnType()}
     *
     * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionReturnType()
     */
    public void testOperationWithCollectionReturnType()
        throws Exception
    {
        this.handleTestOperationWithCollectionReturnType();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithCollectionReturnType()}
     */
    protected abstract void handleTestOperationWithCollectionReturnType()
        throws Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionTypeParameter(java.util.Collection invalidParameter)}
     *
     * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionTypeParameter(java.util.Collection invalidParameter)
     */
    public void testOperationWithCollectionTypeParameter()
        throws Exception
    {
        this.handleTestOperationWithCollectionTypeParameter();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithCollectionTypeParameter(java.util.Collection invalidParameter)}
     */
    protected abstract void handleTestOperationWithCollectionTypeParameter()
        throws Exception;

}