package org.andromda.cartridges.webservice;


import org.andromda.cartridges.webservice.test.TestServiceWithCollectionServiceLocator;
import org.andromda.cartridges.webservice.test.TestServiceWithCollection;
import org.andromda.cartridges.webservice.test.TestServiceWithCollectionSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test for web service 'org.andromda.cartridges.webservice.TestServiceWithCollection'.
 *
 * @see org.andromda.cartridges.webservice.TestServiceWithCollection
 */
public class TestServiceWithCollectionTest
    extends TestCase 
{

	private TestServiceWithCollection service = null;

	/**
	 * Constructor for TestServiceWithCollectionTest.
	 *
	 * @param testName name of the test.
	 */
	public TestServiceWithCollectionTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the TestServiceWithCollection client.
	 */
	public void setUp() {
		try 
		{
			TestServiceWithCollectionServiceLocator locator = 
				new TestServiceWithCollectionServiceLocator();
			this.service = locator.getTestServiceWithCollection();
			TestServiceWithCollectionSoapBindingStub stub = 
				(TestServiceWithCollectionSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the TestServiceWithCollectionTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(TestServiceWithCollectionTest.class);
	}

	/**
	 * Runs the TestServiceWithCollectionTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {TestServiceWithCollectionTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.TestServiceWithCollection.exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)()
     */ 
	public void testExposedOperationWithCollectionReturnType() 
	{
        java.lang.String nonRequiredParameter = null;
        java.lang.String requiredParameter = null;
		try 
		{
			this.service.exposedOperationWithCollectionReturnType(nonRequiredParameter, requiredParameter);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement TestServiceWithCollectionTest.testExposedOperationWithCollectionReturnType()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.TestServiceWithCollection.testUniqueName(java.lang.String paramOne)
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#testUniqueName(java.lang.String paramOne)()
     */ 
	public void testTestUniqueName() 
	{
        java.lang.String paramOne = null;
		try 
		{
			this.service.testUniqueName(paramOne);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement TestServiceWithCollectionTest.testTestUniqueName()  
	}
	

}
