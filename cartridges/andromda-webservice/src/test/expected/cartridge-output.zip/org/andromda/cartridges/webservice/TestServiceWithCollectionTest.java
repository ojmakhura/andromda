package org.andromda.cartridges.webservice;


import org.andromda.cartridges.webservice.test.TestServiceWithCollectionServiceLocator;
import org.andromda.cartridges.webservice.test.TestServiceWithCollection;
import org.andromda.cartridges.webservice.test.TestServiceWithCollectionSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test for web service 'org.andromda.cartridges.webservice.TestServiceWithCollection'.
 *
 * @see org.andromda.cartridges.webservice.TestServiceWithCollection
 */
public class TestServiceWithCollectionTest
    extends TestCase 
{

	private TestServiceWithCollection service = null;

	/**
	 * Constructor for TestServiceWithCollectionTest.
	 *
	 * @param testName name of the test.
	 */
	public TestServiceWithCollectionTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the TestServiceWithCollection client.
	 */
	public void setUp() {
		try 
		{
			TestServiceWithCollectionServiceLocator locator = 
				new TestServiceWithCollectionServiceLocator();
			this.service = locator.getTestServiceWithCollection();
			TestServiceWithCollectionSoapBindingStub stub = 
				(TestServiceWithCollectionSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the TestServiceWithCollectionTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(TestServiceWithCollectionTest.class);
	}

	/**
	 * Runs the TestServiceWithCollectionTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {TestServiceWithCollectionTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.TestServiceWithCollection.exposedOperationWithCollectionReturnType()
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType()()
     */ 
	public void testExposedOperationWithCollectionReturnType() 
	{
		try 
		{
			this.service.exposedOperationWithCollectionReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement TestServiceWithCollectionTest.testExposedOperationWithCollectionReturnType()  
	}
	

}
