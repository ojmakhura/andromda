package org.andromda.cartridges.webservice;

import org.andromda.cartridges.webservice.TestServiceWithCollectionServiceLocator;
import org.andromda.cartridges.webservice.TestServiceWithCollection;
import org.andromda.cartridges.webservice.TestServiceWithCollectionSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.TestServiceWithCollection}.
 *
 * @see org.andromda.cartridges.webservice.TestServiceWithCollection
 */
public abstract class TestServiceWithCollectionTest
    extends TestCase 
{

	protected TestServiceWithCollection service = null;

	/**
	 * Constructor for TestServiceWithCollectionTest.
	 *
	 * @param testName name of the test.
	 */
	public TestServiceWithCollectionTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the TestServiceWithCollection client.
	 */
	public void setUp() {
		try 
		{
			TestServiceWithCollectionServiceLocator locator = 
				new TestServiceWithCollectionServiceLocator();
			this.service = locator.getTestServiceWithCollection();
			TestServiceWithCollectionSoapBindingStub stub = 
				(TestServiceWithCollectionSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the TestServiceWithCollectionTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(TestServiceWithCollectionTestImpl.class);
	}

	/**
	 * Runs the TestServiceWithCollectionTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {TestServiceWithCollectionTestImpl.class.getName()});
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)}
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)
     */ 
	public void testExposedOperationWithCollectionReturnType()
	{
		try 
		{
			this.handleTestExposedOperationWithCollectionReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)}
	 */ 
	protected abstract void handleTestExposedOperationWithCollectionReturnType()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.TestServiceWithCollection#testUniqueName(java.lang.String paramOne)}
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#testUniqueName(java.lang.String paramOne)
     */ 
	public void testTestUniqueName()
	{
		try 
		{
			this.handleTestTestUniqueName();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #testUniqueName(java.lang.String paramOne)}
	 */ 
	protected abstract void handleTestTestUniqueName()
	    throws Exception;
	
}
