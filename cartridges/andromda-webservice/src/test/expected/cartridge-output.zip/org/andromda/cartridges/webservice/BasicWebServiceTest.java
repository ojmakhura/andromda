package org.andromda.cartridges.webservice;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.BasicWebService}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.BasicWebService WSDL 
 *   using axis's java2wsdl tool in order to run these tests. 
 * </p>
 *
 * @see org.andromda.cartridges.webservice.BasicWebService
 */
public abstract class BasicWebServiceTest
    extends TestCase 
{

	protected BasicWebService service = null;

	/**
	 * Constructor for BasicWebServiceTest.
	 *
	 * @param testName name of the test.
	 */
	public BasicWebServiceTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the BasicWebService client.
	 */
	public void setUp() {
		try 
		{
			this.service = org.andromda.webservice.test.TestServiceLocator.instance().getBasicWebService();	
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Allows the BasicWebServiceTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(BasicWebServiceTestImpl.class);
	}

	/**
	 * Runs the BasicWebServiceTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {BasicWebServiceTestImpl.class.getName()});
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithArrayParameter(byte[] arrayParam)}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithArrayParameter(byte[] arrayParam)
     */ 
	public void testOperationWithArrayParameter()
	{
		try 
		{
			this.handleTestOperationWithArrayParameter();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithArrayParameter(byte[] arrayParam)}
	 */ 
	protected abstract void handleTestOperationWithArrayParameter()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithComplexReturnType()}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithComplexReturnType()
     */ 
	public void testOperationWithComplexReturnType()
	{
		try 
		{
			this.handleTestOperationWithComplexReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithComplexReturnType()}
	 */ 
	protected abstract void handleTestOperationWithComplexReturnType()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)
     */ 
	public void testOperationWithMultipleArguments()
	{
		try 
		{
			this.handleTestOperationWithMultipleArguments();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)}
	 */ 
	protected abstract void handleTestOperationWithMultipleArguments()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSimpleReturnType()}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSimpleReturnType()
     */ 
	public void testOperationWithSimpleReturnType()
	{
		try 
		{
			this.handleTestOperationWithSimpleReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithSimpleReturnType()}
	 */ 
	protected abstract void handleTestOperationWithSimpleReturnType()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleArgument(java.util.Date argumentOne)}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleArgument(java.util.Date argumentOne)
     */ 
	public void testOperationWithSingleArgument()
	{
		try 
		{
			this.handleTestOperationWithSingleArgument();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithSingleArgument(java.util.Date argumentOne)}
	 */ 
	protected abstract void handleTestOperationWithSingleArgument()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleComplexReturnTypeNoParameters()}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleComplexReturnTypeNoParameters()
     */ 
	public void testOperationWithSingleComplexReturnTypeNoParameters()
	{
		try 
		{
			this.handleTestOperationWithSingleComplexReturnTypeNoParameters();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithSingleComplexReturnTypeNoParameters()}
	 */ 
	protected abstract void handleTestOperationWithSingleComplexReturnTypeNoParameters()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)
     */ 
	public void testOperationWithSingleRelatedComplexTypeAndOneParameter()
	{
		try 
		{
			this.handleTestOperationWithSingleRelatedComplexTypeAndOneParameter();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)}
	 */ 
	protected abstract void handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithVoidReturnType()}
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithVoidReturnType()
     */ 
	public void testOperationWithVoidReturnType()
	{
		try 
		{
			this.handleTestOperationWithVoidReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithVoidReturnType()}
	 */ 
	protected abstract void handleTestOperationWithVoidReturnType()
	    throws Exception;
	
}
