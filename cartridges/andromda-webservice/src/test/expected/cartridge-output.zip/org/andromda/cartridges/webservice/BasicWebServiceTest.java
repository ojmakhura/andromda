package org.andromda.cartridges.webservice;

import org.andromda.cartridges.webservice.BasicWebServiceServiceLocator;
import org.andromda.cartridges.webservice.BasicWebService;
import org.andromda.cartridges.webservice.BasicWebServiceSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.BasicWebService}.
 *
 * @see org.andromda.cartridges.webservice.BasicWebService
 */
public class BasicWebServiceTest
    extends TestCase 
{

	private BasicWebService service = null;

	/**
	 * Constructor for BasicWebServiceTest.
	 *
	 * @param testName name of the test.
	 */
	public BasicWebServiceTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the BasicWebService client.
	 */
	public void setUp() {
		try 
		{
			BasicWebServiceServiceLocator locator = 
				new BasicWebServiceServiceLocator();
			this.service = locator.getBasicWebService();
			BasicWebServiceSoapBindingStub stub = 
				(BasicWebServiceSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the BasicWebServiceTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(BasicWebServiceTest.class);
	}

	/**
	 * Runs the BasicWebServiceTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {BasicWebServiceTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithComplexReturnType()
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithComplexReturnType()()
     */ 
	public void testOperationWithComplexReturnType() 
	{
		try 
		{
			this.service.operationWithComplexReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithComplexReturnType()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)()
     */ 
	public void testOperationWithMultipleArguments() 
	{
        java.lang.Long firstArgument = null;
        java.lang.Boolean secondArgument = null;
        java.lang.String requiredArgument = null;
		try 
		{
			this.service.operationWithMultipleArguments(firstArgument, secondArgument, requiredArgument);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithMultipleArguments()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithSimpleReturnType()
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSimpleReturnType()()
     */ 
	public void testOperationWithSimpleReturnType() 
	{
		try 
		{
			this.service.operationWithSimpleReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithSimpleReturnType()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithSingleArgument(java.util.Date argumentOne)
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleArgument(java.util.Date argumentOne)()
     */ 
	public void testOperationWithSingleArgument() 
	{
        java.util.Date argumentOne = null;
		try 
		{
			this.service.operationWithSingleArgument(argumentOne);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithSingleArgument()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithSingleComplexReturnTypeNoParameters()
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleComplexReturnTypeNoParameters()()
     */ 
	public void testOperationWithSingleComplexReturnTypeNoParameters() 
	{
		try 
		{
			this.service.operationWithSingleComplexReturnTypeNoParameters();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithSingleComplexReturnTypeNoParameters()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)()
     */ 
	public void testOperationWithSingleRelatedComplexTypeAndOneParameter() 
	{
        java.lang.String parameterOne = null;
		try 
		{
			this.service.operationWithSingleRelatedComplexTypeAndOneParameter(parameterOne);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithSingleRelatedComplexTypeAndOneParameter()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.BasicWebService.operationWithVoidReturnType()
	 *
	 * @see org.andromda.cartridges.webservice.BasicWebService#operationWithVoidReturnType()()
     */ 
	public void testOperationWithVoidReturnType() 
	{
		try 
		{
			this.service.operationWithVoidReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement BasicWebServiceTest.testOperationWithVoidReturnType()  
	}
	
}
