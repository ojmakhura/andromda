/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.ServiceWithIncorrectArray}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.ServiceWithIncorrectArray WSDL
 *   using axis's java2wsdl tool in order to run these tests.
 * </p>
 *
 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray
 */
public abstract class ServiceWithIncorrectArrayTest
    extends TestCase
{

    /**
     * Constructor for ServiceWithIncorrectArrayTest.
     *
     * @param testName name of the test.
     */
    public ServiceWithIncorrectArrayTest(String testName)
    {
        super(testName);
    }

    /**
     * Allows the ServiceWithIncorrectArrayTest to be run by JUnit as a suite.
     */
    public static Test suite()
    {
           return new TestSuite(ServiceWithIncorrectArrayTestImpl.class);
    }

    /**
     * Runs the ServiceWithIncorrectArrayTest test case.
     */
    public static void main(String[] args)
    {
        junit.textui.TestRunner.main(new String[] {ServiceWithIncorrectArrayTestImpl.class.getName()});
    }

    /**
     * The service under test.
     */
    private org.andromda.cartridges.webservice.test.ServiceWithIncorrectArray service = null;

    /**
     * Returns the service under test {@link org.andromda.cartridges.webservice.test.ServiceWithIncorrectArray}
     */
    protected org.andromda.cartridges.webservice.test.ServiceWithIncorrectArray getService()
        throws Exception
    {
        if (this.username != null || this.password != null)
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getServiceWithIncorrectArray(username, password);
        }
        else
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getServiceWithIncorrectArray();
        }
        return this.service;
    }

    /**
     * The username providing access to the service under test.
     */
    private String username;

    /**
     * Sets the <code>username</code> providing access to the
     * service under test.
     *
     * @param username the username providing access to the
     *        service under test.
     */
    protected void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * The password providing access to the service under test.
     */
    private String password;

    /**
     * Sets the <code>password</code> for the service under test.
     *
     * @param password the password for the service under test.
     */
    protected void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Tests: {@link org.andromda.cartridges.webservice.ServiceWithIncorrectArray#exposedOperationWithNoNonArrayType()}
     *
     * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray#exposedOperationWithNoNonArrayType()
     */
    public void testExposedOperationWithNoNonArrayType()
        throws java.lang.Exception
    {
        this.handleTestExposedOperationWithNoNonArrayType();
    }

    /**
     * Provides the actual test implementation for {@link #exposedOperationWithNoNonArrayType()}
     */
    protected abstract void handleTestExposedOperationWithNoNonArrayType()
        throws java.lang.Exception;

}