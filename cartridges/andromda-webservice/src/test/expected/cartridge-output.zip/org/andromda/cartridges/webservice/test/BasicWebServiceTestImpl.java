/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest
 */
public class BasicWebServiceTestImpl
    extends BasicWebServiceTest
{

    /**
     * Constructor for BasicWebServiceTest.
     *
     * @param testName name of the test.
     */
    public BasicWebServiceTestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithArrayParameter()
     */
    public void handleTestOperationWithArrayParameter()
        throws Exception
    {
        org.andromda.cartridges.webservice.test.ArrayOfbyte arrayParam = null;
        this.getService().operationWithArrayParameter(arrayParam);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithArrayParameter()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithComplexReturnType()
     */
    public void handleTestOperationWithComplexReturnType()
        throws Exception
    {
        this.getService().operationWithComplexReturnType();
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithComplexReturnType()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithInheritedArrayTypes()
     */
    public void handleTestOperationWithInheritedArrayTypes()
        throws Exception
    {
        org.andromda.cartridges.webservice.test.ArrayOfTestComplexType4 param = null;
        this.getService().operationWithInheritedArrayTypes(param);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithInheritedArrayTypes()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithInheritedTypes()
     */
    public void handleTestOperationWithInheritedTypes()
        throws Exception
    {
        org.andromda.cartridges.webservice.test.TestComplexType4 param = null;
        this.getService().operationWithInheritedTypes(param);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithInheritedTypes()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithMultipleArguments()
     */
    public void handleTestOperationWithMultipleArguments()
        throws Exception
    {
        java.lang.Long firstArgument = null;
        java.lang.Boolean secondArgument = null;
        java.lang.String requiredArgument = null;
        org.andromda.cartridges.webservice.test.TestEnumeration enumArgument = null;
        this.getService().operationWithMultipleArguments(firstArgument, secondArgument, requiredArgument, enumArgument);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithMultipleArguments()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithSimpleReturnType()
     */
    public void handleTestOperationWithSimpleReturnType()
        throws Exception
    {
        this.getService().operationWithSimpleReturnType();
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithSimpleReturnType()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithSingleArgument()
     */
    public void handleTestOperationWithSingleArgument()
        throws Exception
    {
        java.util.Date argumentOne = null;
        this.getService().operationWithSingleArgument(argumentOne);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithSingleArgument()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithSingleComplexReturnTypeNoParameters()
     */
    public void handleTestOperationWithSingleComplexReturnTypeNoParameters()
        throws Exception
    {
        this.getService().operationWithSingleComplexReturnTypeNoParameters();
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithSingleComplexReturnTypeNoParameters()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithSingleRelatedComplexTypeAndOneParameter()
     */
    public void handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()
        throws Exception
    {
        java.lang.String parameterOne = null;
        this.getService().operationWithSingleRelatedComplexTypeAndOneParameter(parameterOne);
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.BasicWebServiceTest#testOperationWithVoidReturnType()
     */
    public void handleTestOperationWithVoidReturnType()
        throws Exception
    {
        this.getService().operationWithVoidReturnType();
        // @todo implement org.andromda.cartridges.webservice.test.BasicWebServiceTest.handleTestOperationWithVoidReturnType()
    }

}