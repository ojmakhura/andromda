package org.andromda.cartridges.webservice;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.ServiceWithExposedOperations}.
 *
 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations
 */
public abstract class ServiceWithExposedOperationsTest
    extends TestCase 
{

	protected ServiceWithExposedOperations service = null;

	/**
	 * Constructor for ServiceWithExposedOperationsTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithExposedOperationsTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithExposedOperations client.
	 */
	public void setUp() {
		try 
		{
			this.service = org.andromda.webservice.test.TestServiceLocator.instance().getServiceWithExposedOperations();	
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithExposedOperationsTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithExposedOperationsTestImpl.class);
	}

	/**
	 * Runs the ServiceWithExposedOperationsTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithExposedOperationsTestImpl.class.getName()});
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithExposedOperations#exposedOperation()}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#exposedOperation()
     */ 
	public void testExposedOperation()
	{
		try 
		{
			this.handleTestExposedOperation();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #exposedOperation()}
	 */ 
	protected abstract void handleTestExposedOperation()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName()}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName()
     */ 
	public void testTestUniqueName()
	{
		try 
		{
			this.handleTestTestUniqueName();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #testUniqueName()}
	 */ 
	protected abstract void handleTestTestUniqueName()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName(java.lang.Long paramOne)}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName(java.lang.Long paramOne)
     */ 
	public void testTestUniqueName()
	{
		try 
		{
			this.handleTestTestUniqueName();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #testUniqueName(java.lang.Long paramOne)}
	 */ 
	protected abstract void handleTestTestUniqueName()
	    throws Exception;
	
}
