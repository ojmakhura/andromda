package org.andromda.cartridges.webservice;


import org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsServiceLocator;
import org.andromda.cartridges.webservice.test.ServiceWithExposedOperations;
import org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test for web service 'org.andromda.cartridges.webservice.ServiceWithExposedOperations'.
 *
 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations
 */
public class ServiceWithExposedOperationsTest
    extends TestCase 
{

	private ServiceWithExposedOperations service = null;

	/**
	 * Constructor for ServiceWithExposedOperationsTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithExposedOperationsTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithExposedOperations client.
	 */
	public void setUp() {
		try 
		{
			ServiceWithExposedOperationsServiceLocator locator = 
				new ServiceWithExposedOperationsServiceLocator();
			this.service = locator.getServiceWithExposedOperations();
			ServiceWithExposedOperationsSoapBindingStub stub = 
				(ServiceWithExposedOperationsSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithExposedOperationsTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithExposedOperationsTest.class);
	}

	/**
	 * Runs the ServiceWithExposedOperationsTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithExposedOperationsTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithExposedOperations.exposedOperation()
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#exposedOperation()()
     */ 
	public void testExposedOperation() 
	{
		try 
		{
			this.service.exposedOperation();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithExposedOperationsTest.testExposedOperation()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithExposedOperations.testUniqueName()
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName()()
     */ 
	public void testTestUniqueName() 
	{
		try 
		{
			this.service.testUniqueName();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithExposedOperationsTest.testTestUniqueName()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithExposedOperations.testUniqueName(java.lang.Long paramOne)
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithExposedOperations#testUniqueName(java.lang.Long paramOne)()
     */ 
	public void testTestUniqueName() 
	{
        java.lang.Long paramOne = null;
		try 
		{
			this.service.testUniqueName(paramOne);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithExposedOperationsTest.testTestUniqueName()  
	}
	

}
