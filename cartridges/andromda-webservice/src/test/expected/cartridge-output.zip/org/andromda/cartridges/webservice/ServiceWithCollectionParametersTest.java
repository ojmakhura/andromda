package org.andromda.cartridges.webservice;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters}.
 *
 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters
 */
public abstract class ServiceWithCollectionParametersTest
    extends TestCase 
{

	protected ServiceWithCollectionParameters service = null;

	/**
	 * Constructor for ServiceWithCollectionParametersTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithCollectionParametersTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithCollectionParameters client.
	 */
	public void setUp() {
		try 
		{
			this.service = org.andromda.webservice.test.TestServiceLocator.instance().getServiceWithCollectionParameters();	
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithCollectionParametersTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithCollectionParametersTestImpl.class);
	}

	/**
	 * Runs the ServiceWithCollectionParametersTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithCollectionParametersTestImpl.class.getName()});
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionReturnType()}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionReturnType()
     */ 
	public void testOperationWithCollectionReturnType()
	{
		try 
		{
			this.handleTestOperationWithCollectionReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithCollectionReturnType()}
	 */ 
	protected abstract void handleTestOperationWithCollectionReturnType()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionTypeParameter(java.util.Collection invalidParameter)}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionTypeParameter(java.util.Collection invalidParameter)
     */ 
	public void testOperationWithCollectionTypeParameter()
	{
		try 
		{
			this.handleTestOperationWithCollectionTypeParameter();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithCollectionTypeParameter(java.util.Collection invalidParameter)}
	 */ 
	protected abstract void handleTestOperationWithCollectionTypeParameter()
	    throws Exception;
	
}
