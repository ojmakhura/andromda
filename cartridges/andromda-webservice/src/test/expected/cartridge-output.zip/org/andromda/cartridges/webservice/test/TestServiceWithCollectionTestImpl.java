/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.TestServiceWithCollectionTest
 */
public class TestServiceWithCollectionTestImpl
    extends TestServiceWithCollectionTest
{
    /**
     * Constructor for TestServiceWithCollectionTest.
     *
     * @param testName name of the test.
     */
    public TestServiceWithCollectionTestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestServiceWithCollectionTest#testExposedOperationWithCollectionReturnType()
     */
    public void handleTestExposedOperationWithCollectionReturnType()
        throws Exception
    {
        String nonRequiredParameter = null;
        String requiredParameter = null;
        this.getService().exposedOperationWithCollectionReturnType(nonRequiredParameter, requiredParameter);
        // @todo implement org.andromda.cartridges.webservice.test.TestServiceWithCollectionTest.handleTestExposedOperationWithCollectionReturnType()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestServiceWithCollectionTest#testTestUniqueName()
     */
    public void handleTestTestUniqueName()
        throws Exception
    {
        String paramOne = null;
        this.getService().testUniqueName(paramOne);
        // @todo implement org.andromda.cartridges.webservice.test.TestServiceWithCollectionTest.handleTestTestUniqueName()
    }

}