/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice;

/**
 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArrayTest
 */
public class ServiceWithIncorrectArrayTestImpl
    extends ServiceWithIncorrectArrayTest
{

	/**
	 * Constructor for ServiceWithIncorrectArrayTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithIncorrectArrayTestImpl(String testName) 
	{
		super(testName);
	}
	
	/**
	 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArrayTest#testExposedOperationWithNoNonArrayType()
     */ 
	public void handleTestExposedOperationWithNoNonArrayType()
	    throws Exception
	{
        this.service.exposedOperationWithNoNonArrayType();
		// @todo implement org.andromda.cartridges.webservice.ServiceWithIncorrectArrayTest.handleTestExposedOperationWithNoNonArrayType()  
	}
	
}
