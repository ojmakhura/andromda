/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.TestWebService2Test
 */
public class TestWebService2TestImpl
    extends TestWebService2Test
{

    /**
     * Constructor for TestWebService2Test.
     *
     * @param testName name of the test.
     */
    public TestWebService2TestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestWebService2Test#testFirstComplexTypeOperation()
     */
    public void handleTestFirstComplexTypeOperation()
        throws Exception
    {
        java.lang.Integer paramOne = null;
        java.lang.String paramTwo = null;
        this.getService().firstComplexTypeOperation(paramOne, paramTwo);
        // @todo implement org.andromda.cartridges.webservice.test.TestWebService2Test.handleTestFirstComplexTypeOperation()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestWebService2Test#testFourComplexTypeOperation()
     */
    public void handleTestFourComplexTypeOperation()
        throws Exception
    {
        this.getService().fourComplexTypeOperation();
        // @todo implement org.andromda.cartridges.webservice.test.TestWebService2Test.handleTestFourComplexTypeOperation()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestWebService2Test#testSecondComplexTypeOperation()
     */
    public void handleTestSecondComplexTypeOperation()
        throws Exception
    {
        java.lang.Integer paramOne = null;
        java.lang.String paramTwo = null;
        this.getService().secondComplexTypeOperation(paramOne, paramTwo);
        // @todo implement org.andromda.cartridges.webservice.test.TestWebService2Test.handleTestSecondComplexTypeOperation()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.TestWebService2Test#testThirdComplexTypeOperation()
     */
    public void handleTestThirdComplexTypeOperation()
        throws Exception
    {
        this.getService().thirdComplexTypeOperation();
        // @todo implement org.andromda.cartridges.webservice.test.TestWebService2Test.handleTestThirdComplexTypeOperation()
    }

}