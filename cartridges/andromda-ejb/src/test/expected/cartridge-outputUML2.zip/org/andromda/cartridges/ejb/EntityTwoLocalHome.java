/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 * Home interface for the EntityTwo entity bean.
 * Tests generation with a primary key defined.
 */
public interface EntityTwoLocalHome
    extends EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityTwo/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityTwo/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityTwo findByPrimaryKey(Long key)
            throws FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param name Value for the name property
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     */
    public EntityTwo create(String name, Long attributeOne, Long id)
           throws CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param name Value for the name property
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     * @param entityThree Value for the entityThree relation role
     */
    public EntityTwo create(String name, Long attributeOne, Long id, EntityThree entityThree)
           throws CreateException;

}