/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

/**
 * @see org.andromda.cartridges.ejb.EntityNBean
 */
public abstract class EntityNBeanImpl
    extends EntityNBean
{
}