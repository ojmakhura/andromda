/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityThree entity bean.
 * 
 */
public interface EntityThreeLocalHome
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityThree/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityThree/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityThree findByPrimaryKey(java.lang.Long key)
            throws javax.ejb.FinderException;

   /**
    * 
    */
    public java.util.Collection findByTestAttributes(java.lang.Boolean testAttribute, java.lang.Long testAttributeTwo)
           throws javax.ejb.FinderException;

   /**
    * <p>
    * Tests a finder with the finder defined as a tagged value having
    * new lines in it.
    * </p>
    */
    public java.util.Collection findByTestAttribute(java.lang.Boolean testAttribute)
           throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param testAttribute Value for the testAttribute property
     * @param testAttributeTwo Value for the testAttributeTwo property
     * @param id Value for the id property
     */
    public EntityThree create(java.lang.Boolean testAttribute, java.lang.Long testAttributeTwo, java.lang.Long id)
           throws javax.ejb.CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param testAttribute Value for the testAttribute property
     * @param testAttributeTwo Value for the testAttributeTwo property
     * @param id Value for the id property
     * @param entityTwos Value for the entityTwos relation role
     */
    public EntityThree create(java.lang.Boolean testAttribute, java.lang.Long testAttributeTwo, java.lang.Long id, java.util.Collection entityTwos)
           throws javax.ejb.CreateException;

}