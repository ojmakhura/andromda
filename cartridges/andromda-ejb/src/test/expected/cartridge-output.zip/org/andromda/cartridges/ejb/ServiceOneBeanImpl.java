/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.SessionContext;

import java.util.Collection;
import java.util.Date;
/**
 * @see org.andromda.cartridges.ejb.ServiceOneBean
 */
public class ServiceOneBeanImpl 
    extends ServiceOneBean 
{
    /**
     * <p>
     * Tests a void operation
     * </p>
     * @throws TestException
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
    }

    /**
     * <p>
     * Tests an operation with a single return type.
     * </p>
     * @return String
     * @throws TestException
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithSimpleReturnType()
     */
    public String operationWithSimpleReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * <p>
     * Tests generation of a return type for a complex type.
     * </p>
     * @return Collection
     * @throws TestException
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithComplexReturnType()
     */
    public Collection operationWithComplexReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * 
     * @param argumentOne
     * @return String
     * @throws TestException
     * @see org.andromda.cartridges.ejb.ServiceOne#SoperationWithSingleArgument(Date)
     */
    public String SoperationWithSingleArgument(Date argumentOne)
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * 
     * @param firstArgument
     * @param secondArgument
     * @throws TestException
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithMultipleArguments(Long, Boolean)
     */
    public void operationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throws TestException
    {
        //TODO: put your implementation here.
    }

}
