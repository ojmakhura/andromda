package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityN entity bean.
 * 
 */
public interface EntityNLocalHome  
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
	public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityN/Local";
	public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityN/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityN findByPrimaryKey(int key)
            throws javax.ejb.FinderException;

   /**
    * 
    */
    public void findByBla()
           throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param nId Value for the nId property
     * @param n2Id Value for the n2Id property
     * @param myFunnyAttribute Value for the myFunnyAttribute property
     */
    public EntityN create(int nId, java.lang.Integer n2Id, java.lang.String myFunnyAttribute)
           throws javax.ejb.CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param nId Value for the nId property
     * @param n2Id Value for the n2Id property
     * @param myFunnyAttribute Value for the myFunnyAttribute property
     * @param many2manyM Value for the many2manyM relation role
     * @param one2manyMany Value for the one2manyMany relation role
     * @param many2oneOne Value for the many2oneOne relation role
     * @param one2oneM Value for the one2oneM relation role
     */
    public EntityN create(int nId, java.lang.Integer n2Id, java.lang.String myFunnyAttribute, java.util.Collection many2manyM, java.util.Collection one2manyMany, org.andromda.cartridges.ejb.EntityM many2oneOne, org.andromda.cartridges.ejb.EntityM one2oneM)
           throws javax.ejb.CreateException;
           
}
