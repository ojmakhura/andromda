/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityWithAutoKey entity bean.
 * 
 */
public interface EntityWithAutoKeyLocalHome
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityWithAutoKey/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityWithAutoKey/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityWithAutoKey findByPrimaryKey(java.lang.Integer key)
            throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param integerPrimary Value for the integerPrimary property
     * @param someText Value for the someText property
     */
    public EntityWithAutoKey create(java.lang.Integer integerPrimary, java.lang.String someText)
           throws javax.ejb.CreateException;
}
