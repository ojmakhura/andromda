/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.EntityContext;
import javax.ejb.RemoveException;

/**
 * @see org.andromda.cartridges.ejb.EntityTwoBean
 */
public abstract class EntityTwoBeanImpl
    extends EntityTwoBean
{
}
