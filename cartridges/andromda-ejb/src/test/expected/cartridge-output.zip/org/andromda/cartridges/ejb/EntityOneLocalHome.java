/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityOne entity bean.
 * <p>
 * Tests the generation with the default identifer (since no
 * identifier is defined)
 * </p>
 */
public interface EntityOneLocalHome
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityOne/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityOne/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityOne findByPrimaryKey(java.lang.Long key)
            throws javax.ejb.FinderException;

   /**
    * <p>
    * Tests automatic finder generation.
    * </p>
    */
    public java.util.Collection findByAttributeOne(java.lang.String attributeOne)
           throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     */
    public EntityOne create(java.lang.String attributeOne, java.lang.Long id)
           throws javax.ejb.CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     * @param entityTwos Value for the entityTwos relation role
     */
    public EntityOne create(java.lang.String attributeOne, java.lang.Long id, java.util.Collection entityTwos)
           throws javax.ejb.CreateException;

}