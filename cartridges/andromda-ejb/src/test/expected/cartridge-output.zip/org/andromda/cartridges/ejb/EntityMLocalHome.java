/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;
/**
 * Home interface for the EntityM entity bean.
 * 
 */
public interface EntityMLocalHome
    extends EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityM/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityM/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityM findByPrimaryKey(Long key)
            throws FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param mId Value for the mId property
     * @param m2Id Value for the m2Id property
     * @param id Value for the id property
     */
    public EntityM create(Integer mId, Integer m2Id, Long id)
           throws CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param mId Value for the mId property
     * @param m2Id Value for the m2Id property
     * @param id Value for the id property
     * @param many2manyNs Value for the many2manyNs relation role
     * @param one2manyOne Value for the one2manyOne relation role
     * @param many2oneManies Value for the many2oneManies relation role
     * @param one2oneN Value for the one2oneN relation role
     */
    public EntityM create(Integer mId, Integer m2Id, Long id, Collection many2manyNs, EntityN one2manyOne, Collection many2oneManies, EntityN one2oneN)
           throws CreateException;

}