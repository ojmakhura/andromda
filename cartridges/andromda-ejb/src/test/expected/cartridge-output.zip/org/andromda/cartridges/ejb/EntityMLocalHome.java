package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityM entity bean.
 * 
 */
public interface EntityMLocalHome  
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
	public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityM/Local";
	public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityM/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityM findByPrimaryKey(java.lang.Integer key)
            throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param mId Value for the mId property
     * @param m2Id Value for the m2Id property
     */
    public EntityM create(java.lang.Integer mId, java.lang.Integer m2Id)
           throws javax.ejb.CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param mId Value for the mId property
     * @param m2Id Value for the m2Id property
     * @param many2manyN Value for the many2manyN relation role
     * @param one2manyOne Value for the one2manyOne relation role
     * @param many2oneMany Value for the many2oneMany relation role
     * @param one2oneN Value for the one2oneN relation role
     */
    public EntityM create(java.lang.Integer mId, java.lang.Integer m2Id, java.util.Collection many2manyN, org.andromda.cartridges.ejb.EntityN one2manyOne, java.util.Collection many2oneMany, org.andromda.cartridges.ejb.EntityN one2oneN)
           throws javax.ejb.CreateException;
           
}
