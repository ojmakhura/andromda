package org.andromda.cartridges.bpm4struts.tests.widgets;

public interface PreloadSelectsForm
{
    public java.lang.String getSubmitRadioButtonsTest();
    public void setSubmitRadioButtonsTest(java.lang.String submitRadioButtonsTest);

    public java.lang.String getSubmitRadioButtonsTest2();
    public void setSubmitRadioButtonsTest2(java.lang.String submitRadioButtonsTest2);

    public java.lang.String getSubmitTextAreaTest();
    public void setSubmitTextAreaTest(java.lang.String submitTextAreaTest);

    public java.lang.String getSubmitPasswordFieldTest();
    public void setSubmitPasswordFieldTest(java.lang.String submitPasswordFieldTest);

    public boolean getSubmitCheckboxTest();
    public void setSubmitCheckboxTest(boolean submitCheckboxTest);

    public java.lang.String getSubmitHiddenTest();
    public void setSubmitHiddenTest(java.lang.String submitHiddenTest);

    public java.lang.String getSubmitRadioButtonsTest3();
    public void setSubmitRadioButtonsTest3(java.lang.String submitRadioButtonsTest3);

    public java.lang.String getSubmitTextFieldTest2();
    public void setSubmitTextFieldTest2(java.lang.String submitTextFieldTest2);

    public java.lang.String getSubmitSelectTest();
    public void setSubmitSelectTest(java.lang.String submitSelectTest);

    public java.lang.String getSubmitTextFieldTest();
    public void setSubmitTextFieldTest(java.lang.String submitTextFieldTest);

}