package org.andromda.cartridges.bpm4struts.tests.messages;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class MessagesActivity extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = _one(mapping, form, request, response);
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269903336");
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269903337");
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269903335");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482620623");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482620622");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482620624");
        return forward;
    }

    /**
     * 
     */
    private ActionForward _four(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269897571");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482614858");
        return _one(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward _one(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269902376");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482620624");
        return _two(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward _two(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269901415");
        ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482618702");
        return doSomething(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final String value = String.valueOf(ControllerFactory.getControllerInstance().doSomething(mapping, (MessagesActivityForm)form, request, response));

        if (value.equals("true"))
        {
            ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269900454");
            ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482617741");
            return mapping.findForward("three");
        }
        if (value.equals("false"))
        {
            ControllerFactory.getControllerInstance().saveSuccessMessage(request, "messages.activity.success.-1269899493");
            ControllerFactory.getControllerInstance().saveWarningMessage(request, "messages.activity.warning.-482616780");
            return _four(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _four(mapping, form, request, response);
    }

}
