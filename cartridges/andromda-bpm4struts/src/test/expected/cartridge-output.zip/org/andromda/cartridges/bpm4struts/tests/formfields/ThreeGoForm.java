/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formfields;

public class ThreeGoForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String text;
    private Object[] textValueList;
    private Object[] textLabelList;
    private java.lang.String title;
    private Object[] titleValueList;
    private Object[] titleLabelList;
    private java.util.Collection multiSelect;
    private Object[] multiSelectValueList;
    private Object[] multiSelectLabelList;
    private org.apache.struts.upload.FormFile file = null;
    private Object[] fileValueList;
    private Object[] fileLabelList;
    private java.util.Collection collection;
    private Object[] collectionValueList;
    private Object[] collectionLabelList;
    private java.util.Date date;
    private final static java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] dateValueList;
    private Object[] dateLabelList;
    private boolean bool;
    private Object[] boolValueList;
    private Object[] boolLabelList;
    private java.lang.String selectable;
    private Object[] selectableValueList;
    private Object[] selectableLabelList;
    private int number;
    private Object[] numberValueList;
    private Object[] numberLabelList;

    public ThreeGoForm()
    {
        dateDateFormatter.setLenient(true);
    }

    /**
     * Resets the given <code>text</code>.
     */
    public void resetText()
    {
        this.text = null;
    }
    
    public void setText(java.lang.String text)
    {
        this.text = text;
    }

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }
    

    public Object[] getTextBackingList()
    {
        Object[] values = this.textValueList;
        Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    /**
     * Resets the given <code>title</code>.
     */
    public void resetTitle()
    {
        this.title = null;
    }
    
    public void setTitle(java.lang.String title)
    {
        this.title = title;
    }

    /**
     * <p>
     *  should not conflict with the use-cases title property in the
     *  resource bundle
     * </p>
     */
    public java.lang.String getTitle()
    {
        return this.title;
    }
    

    public Object[] getTitleBackingList()
    {
        Object[] values = this.titleValueList;
        Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    /**
     * Resets the given <code>multiSelect</code>.
     */
    public void resetMultiSelect()
    {
        this.multiSelect = null;
    }
    
    public void setMultiSelect(java.util.Collection multiSelect)
    {
        this.multiSelect = multiSelect;
    }

    /**
     * 
     */
    public java.util.Collection getMultiSelect()
    {
        return this.multiSelect;
    }

    public void setMultiSelectAsArray(Object[] multiSelect)
    {
        this.multiSelect = (multiSelect == null) ? null : java.util.Arrays.asList(multiSelect);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getMultiSelect
     */
    public Object[] getMultiSelectAsArray()
    {
        return (multiSelect == null) ? null : multiSelect.toArray();
    }
    

    public Object[] getMultiSelectBackingList()
    {
        Object[] values = this.multiSelectValueList;
        Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    /**
     * Resets the given <code>file</code>.
     */
    public void resetFile()
    {
        this.file = null;
    }
    
    public void setFile(org.apache.struts.upload.FormFile file)
    {
        this.file = file;
    }

    /**
     * 
     */
    public org.apache.struts.upload.FormFile getFile()
    {
        return this.file;
    }

    public Object[] getFileBackingList()
    {
        Object[] values = this.fileValueList;
        Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    /**
     * Resets the given <code>collection</code>.
     */
    public void resetCollection()
    {
        this.collection = null;
    }
    
    public void setCollection(java.util.Collection collection)
    {
        this.collection = collection;
    }

    /**
     * 
     */
    public java.util.Collection getCollection()
    {
        return this.collection;
    }

    public void setCollectionAsArray(Object[] collection)
    {
        this.collection = (collection == null) ? null : java.util.Arrays.asList(collection);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getCollection
     */
    public Object[] getCollectionAsArray()
    {
        return (collection == null) ? null : collection.toArray();
    }
    

    public Object[] getCollectionBackingList()
    {
        Object[] values = this.collectionValueList;
        Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    /**
     * Resets the given <code>date</code>.
     */
    public void resetDate()
    {
        this.date = null;
    }
    
    public void setDateAsDate(java.util.Date date)
    {
        this.date = date;
    }

    /**
     * Returns the Date instance representing the <code>date</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate#ateFormatter
     */
    public java.util.Date getDateAsDate()
    {
        return this.date;
    }

    public void setDate(java.lang.String date)
    {
        if (date == null || date.trim().length()==0)
        {
            this.date = null;
        }
        else
        {
            try
            {
                this.date = dateDateFormatter.parse(date);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate#sDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate#ateFormatter
     */
    public java.lang.String getDate()
    {
        return (date == null) ? null : dateDateFormatter.format(date);
    }

    /**
     * Returns the date formatter used for the <code>date</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoForm#getDate#sDate
     */
    public final static java.text.DateFormat getDateDateFormatter()
    {
        return ThreeGoForm.dateDateFormatter;
    }


    public Object[] getDateBackingList()
    {
        Object[] values = this.dateValueList;
        Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    /**
     * Resets the given <code>bool</code>.
     */
    public void resetBool()
    {
        this.bool = false;
    }
    
    public void setBool(boolean bool)
    {
        this.bool = bool;
    }

    /**
     * 
     */
    public boolean getBool()
    {
        return this.bool;
    }
    

    public Object[] getBoolBackingList()
    {
        Object[] values = this.boolValueList;
        Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    /**
     * Resets the given <code>selectable</code>.
     */
    public void resetSelectable()
    {
        this.selectable = null;
    }
    
    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
    }

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }
    

    public Object[] getSelectableBackingList()
    {
        Object[] values = this.selectableValueList;
        Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    /**
     * Resets the given <code>number</code>.
     */
    public void resetNumber()
    {
        this.number = 0;
    }
    
    public void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }
    

    public Object[] getNumberBackingList()
    {
        Object[] values = this.numberValueList;
        Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.multiSelect = null;
        this.multiSelectValueList = new Object[0];
        this.multiSelectLabelList = new Object[0];
        this.file = null;
        this.collection = null;
        this.collectionValueList = new Object[0];
        this.collectionLabelList = new Object[0];
        this.bool = false;
        this.selectable = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("text", this.text);
        builder.append("title", this.title);
        builder.append("multiSelect", this.multiSelect);
        builder.append("file", this.file);
        builder.append("collection", this.collection);
        builder.append("date", this.date);
        builder.append("bool", this.bool);
        builder.append("selectable", this.selectable);
        builder.append("number", this.number);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.text = null;
        this.title = null;
        this.multiSelect = null;
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        this.file = null;
        this.collection = null;
        this.collectionValueList = null;
        this.collectionLabelList = null;
        this.date = null;
        this.bool = false;
        this.selectable = null;
        this.selectableValueList = null;
        this.selectableLabelList = null;
        this.number = 0;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}