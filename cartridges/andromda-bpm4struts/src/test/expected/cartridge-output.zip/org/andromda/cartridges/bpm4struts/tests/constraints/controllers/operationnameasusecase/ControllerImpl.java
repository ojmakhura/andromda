/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.Controller#OperationNameAsUseCase(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.OperationNameAsUseCaseForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void OperationNameAsUseCase(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.OperationNameAsUseCaseForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

}
