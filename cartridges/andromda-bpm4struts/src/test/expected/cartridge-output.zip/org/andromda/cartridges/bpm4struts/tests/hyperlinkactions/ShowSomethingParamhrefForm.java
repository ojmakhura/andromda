/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.hyperlinkactions;

public class ShowSomethingParamhrefForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String someParameter;
    private Object[] someParameterValueList;
    private Object[] someParameterLabelList;

    public ShowSomethingParamhrefForm()
    {
    }

    /**
     * Resets the given <code>someParameter</code>.
     */
    public void resetSomeParameter()
    {
        this.someParameter = null;
    }
    
    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
    }

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }
    

    public Object[] getSomeParameterBackingList()
    {
        Object[] values = this.someParameterValueList;
        Object[] labels = this.someParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSomeParameterValueList()
    {
        return this.someParameterValueList;
    }

    public void setSomeParameterValueList(Object[] someParameterValueList)
    {
        this.someParameterValueList = someParameterValueList;
    }

    public Object[] getSomeParameterLabelList()
    {
        return this.someParameterLabelList;
    }

    public void setSomeParameterLabelList(Object[] someParameterLabelList)
    {
        this.someParameterLabelList = someParameterLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("someParameter", this.someParameter);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.someParameter = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}