package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public interface Operation3Form
{
}
