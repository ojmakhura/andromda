/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.interactionstate;

public class Page1SubmitFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String param;
    private Object[] paramValueList;
    private Object[] paramLabelList;
    private int interActionStateParam;
    private Object[] interActionStateParamValueList;
    private Object[] interActionStateParamLabelList;

    public Page1SubmitFormImpl()
    {
    }

    /**
     * Resets the given <code>param</code>.
     */
    public void resetParam()
    {
        this.param = null;
    }
    
    public void setParam(java.lang.String param)
    {
        this.param = param;
    }

    /**
     * 
     */
    public java.lang.String getParam()
    {
        return this.param;
    }
    

    public Object[] getParamBackingList()
    {
        Object[] values = this.paramValueList;
        Object[] labels = this.paramLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getParamValueList()
    {
        return this.paramValueList;
    }

    public void setParamValueList(Object[] paramValueList)
    {
        this.paramValueList = paramValueList;
    }

    public Object[] getParamLabelList()
    {
        return this.paramLabelList;
    }

    public void setParamLabelList(Object[] paramLabelList)
    {
        this.paramLabelList = paramLabelList;
    }

    public void setParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("Page1SubmitFormImpl.setParamBackingList requires non-null property arguments");
        }

        this.paramValueList = null;
        this.paramLabelList = null;

        if (items != null)
        {
            this.paramValueList = new Object[items.size()];
            this.paramLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.paramValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.paramLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("Page1SubmitFormImpl.setParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>interActionStateParam</code>.
     */
    public void resetInterActionStateParam()
    {
        this.interActionStateParam = 0;
    }
    
    public void setInterActionStateParam(int interActionStateParam)
    {
        this.interActionStateParam = interActionStateParam;
    }

    /**
     * 
     */
    public int getInterActionStateParam()
    {
        return this.interActionStateParam;
    }
    

    public Object[] getInterActionStateParamBackingList()
    {
        Object[] values = this.interActionStateParamValueList;
        Object[] labels = this.interActionStateParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getInterActionStateParamValueList()
    {
        return this.interActionStateParamValueList;
    }

    public void setInterActionStateParamValueList(Object[] interActionStateParamValueList)
    {
        this.interActionStateParamValueList = interActionStateParamValueList;
    }

    public Object[] getInterActionStateParamLabelList()
    {
        return this.interActionStateParamLabelList;
    }

    public void setInterActionStateParamLabelList(Object[] interActionStateParamLabelList)
    {
        this.interActionStateParamLabelList = interActionStateParamLabelList;
    }

    public void setInterActionStateParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("Page1SubmitFormImpl.setInterActionStateParamBackingList requires non-null property arguments");
        }

        this.interActionStateParamValueList = null;
        this.interActionStateParamLabelList = null;

        if (items != null)
        {
            this.interActionStateParamValueList = new Object[items.size()];
            this.interActionStateParamLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.interActionStateParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.interActionStateParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("Page1SubmitFormImpl.setInterActionStateParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("param", this.param);
        builder.append("interActionStateParam", this.interActionStateParam);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.param = null;
        this.interActionStateParam = 0;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}