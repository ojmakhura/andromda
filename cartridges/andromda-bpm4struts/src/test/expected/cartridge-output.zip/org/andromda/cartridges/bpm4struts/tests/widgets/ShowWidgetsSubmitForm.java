/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.widgets;

public class ShowWidgetsSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String textAreaTest;
    private Object[] textAreaTestValueList;
    private Object[] textAreaTestLabelList;
    private java.lang.String radioButtonsTest3;
    private Object[] radioButtonsTest3ValueList;
    private Object[] radioButtonsTest3LabelList;
    private java.lang.String radioButtonsTest;
    private Object[] radioButtonsTestValueList;
    private Object[] radioButtonsTestLabelList;
    private boolean checkboxTest;
    private Object[] checkboxTestValueList;
    private Object[] checkboxTestLabelList;
    private java.lang.String textFieldTest2;
    private Object[] textFieldTest2ValueList;
    private Object[] textFieldTest2LabelList;
    private java.lang.String selectTest;
    private Object[] selectTestValueList;
    private Object[] selectTestLabelList;
    private java.lang.String textFieldTest;
    private Object[] textFieldTestValueList;
    private Object[] textFieldTestLabelList;
    private java.lang.String hiddenTest;
    private Object[] hiddenTestValueList;
    private Object[] hiddenTestLabelList;
    private java.lang.String passwordFieldTest;
    private Object[] passwordFieldTestValueList;
    private Object[] passwordFieldTestLabelList;
    private java.lang.String radioButtonsTest2;
    private Object[] radioButtonsTest2ValueList;
    private Object[] radioButtonsTest2LabelList;

    public ShowWidgetsSubmitForm()
    {
    }

    /**
     * Resets the given <code>textAreaTest</code>.
     */
    public void resetTextAreaTest()
    {
        this.textAreaTest = null;
    }
    
    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
    }

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }
    

    public Object[] getTextAreaTestBackingList()
    {
        Object[] values = this.textAreaTestValueList;
        Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    /**
     * Resets the given <code>radioButtonsTest3</code>.
     */
    public void resetRadioButtonsTest3()
    {
        this.radioButtonsTest3 = null;
    }
    
    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }
    

    public Object[] getRadioButtonsTest3BackingList()
    {
        Object[] values = this.radioButtonsTest3ValueList;
        Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    /**
     * Resets the given <code>radioButtonsTest</code>.
     */
    public void resetRadioButtonsTest()
    {
        this.radioButtonsTest = null;
    }
    
    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }
    

    public Object[] getRadioButtonsTestBackingList()
    {
        Object[] values = this.radioButtonsTestValueList;
        Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    /**
     * Resets the given <code>checkboxTest</code>.
     */
    public void resetCheckboxTest()
    {
        this.checkboxTest = false;
    }
    
    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
    }

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }
    

    public Object[] getCheckboxTestBackingList()
    {
        Object[] values = this.checkboxTestValueList;
        Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    /**
     * Resets the given <code>textFieldTest2</code>.
     */
    public void resetTextFieldTest2()
    {
        this.textFieldTest2 = null;
    }
    
    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }
    

    public Object[] getTextFieldTest2BackingList()
    {
        Object[] values = this.textFieldTest2ValueList;
        Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    /**
     * Resets the given <code>selectTest</code>.
     */
    public void resetSelectTest()
    {
        this.selectTest = null;
    }
    
    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
    }

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }
    

    public Object[] getSelectTestBackingList()
    {
        Object[] values = this.selectTestValueList;
        Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    /**
     * Resets the given <code>textFieldTest</code>.
     */
    public void resetTextFieldTest()
    {
        this.textFieldTest = null;
    }
    
    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }
    

    public Object[] getTextFieldTestBackingList()
    {
        Object[] values = this.textFieldTestValueList;
        Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    /**
     * Resets the given <code>hiddenTest</code>.
     */
    public void resetHiddenTest()
    {
        this.hiddenTest = null;
    }
    
    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
    }

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }
    

    public Object[] getHiddenTestBackingList()
    {
        Object[] values = this.hiddenTestValueList;
        Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    /**
     * Resets the given <code>passwordFieldTest</code>.
     */
    public void resetPasswordFieldTest()
    {
        this.passwordFieldTest = null;
    }
    
    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }
    

    public Object[] getPasswordFieldTestBackingList()
    {
        Object[] values = this.passwordFieldTestValueList;
        Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    /**
     * Resets the given <code>radioButtonsTest2</code>.
     */
    public void resetRadioButtonsTest2()
    {
        this.radioButtonsTest2 = null;
    }
    
    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }
    

    public Object[] getRadioButtonsTest2BackingList()
    {
        Object[] values = this.radioButtonsTest2ValueList;
        Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.checkboxTest = false;
        this.selectTest = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("textAreaTest", this.textAreaTest);
        builder.append("radioButtonsTest3", this.radioButtonsTest3);
        builder.append("radioButtonsTest", this.radioButtonsTest);
        builder.append("checkboxTest", this.checkboxTest);
        builder.append("textFieldTest2", this.textFieldTest2);
        builder.append("selectTest", this.selectTest);
        builder.append("textFieldTest", this.textFieldTest);
        builder.append("hiddenTest", this.hiddenTest);
        builder.append("passwordFieldTest", "***");
        builder.append("radioButtonsTest2", this.radioButtonsTest2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.textAreaTest = null;
        this.radioButtonsTest3 = null;
        this.radioButtonsTest = null;
        this.checkboxTest = false;
        this.textFieldTest2 = null;
        this.selectTest = null;
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        this.textFieldTest = null;
        this.hiddenTest = null;
        this.passwordFieldTest = null;
        this.radioButtonsTest2 = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}