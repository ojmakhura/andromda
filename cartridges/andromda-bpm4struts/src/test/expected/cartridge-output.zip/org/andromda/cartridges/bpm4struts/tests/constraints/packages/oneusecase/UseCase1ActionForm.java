package org.andromda.cartridges.bpm4struts.tests.constraints.packages.oneusecase;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="useCase1UseCase1ActionForm"
 */
public class UseCase1ActionForm extends ValidatorForm implements Serializable
    
{

    public UseCase1ActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
