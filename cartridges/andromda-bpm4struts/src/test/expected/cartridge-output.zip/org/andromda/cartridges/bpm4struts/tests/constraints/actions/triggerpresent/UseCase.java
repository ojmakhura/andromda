package org.andromda.cartridges.bpm4struts.tests.constraints.actions.triggerpresent;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/UseCase/UseCase"
 *        name="useCaseUseCaseActionForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="some.page"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/triggerpresent/some-page.jsp"
 *    redirect="false"
 *
 */
public final class UseCase extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = doSomething(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("some.page");
    }

}
