/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.validation;

public class EnterDataValidateFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String minLengthOnPasswordTest;
    private Object[] minLengthOnPasswordTestValueList;
    private Object[] minLengthOnPasswordTestLabelList;
    private java.lang.String requiredTest;
    private Object[] requiredTestValueList;
    private Object[] requiredTestLabelList;
    private java.lang.String emailTest;
    private Object[] emailTestValueList;
    private Object[] emailTestLabelList;
    private int intRangeTest;
    private Object[] intRangeTestValueList;
    private Object[] intRangeTestLabelList;
    private double doubleRangeTest;
    private Object[] doubleRangeTestValueList;
    private Object[] doubleRangeTestLabelList;
    private java.util.Date hiddenNotValidated;
    private final static java.text.DateFormat hiddenNotValidatedDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] hiddenNotValidatedValueList;
    private Object[] hiddenNotValidatedLabelList;
    private java.lang.String maxlengthTest;
    private Object[] maxlengthTestValueList;
    private Object[] maxlengthTestLabelList;
    private java.lang.String patternTest;
    private Object[] patternTestValueList;
    private Object[] patternTestLabelList;
    private java.lang.Float floatWrapperRangeTest;
    private Object[] floatWrapperRangeTestValueList;
    private Object[] floatWrapperRangeTestLabelList;
    private java.lang.Integer intWrapperRangeTest;
    private Object[] intWrapperRangeTestValueList;
    private Object[] intWrapperRangeTestLabelList;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private Object[] lenientDateTestValueList;
    private Object[] lenientDateTestLabelList;
    private java.net.URL urlTest;
    private Object[] urlTestValueList;
    private Object[] urlTestLabelList;
    private java.lang.String minlengthTest;
    private Object[] minlengthTestValueList;
    private Object[] minlengthTestLabelList;
    private float floatRangeTest;
    private Object[] floatRangeTestValueList;
    private Object[] floatRangeTestLabelList;
    private java.lang.Double doubleWrapperRangeTest;
    private Object[] doubleWrapperRangeTestValueList;
    private Object[] doubleWrapperRangeTestLabelList;
    private java.lang.String creditcardTest;
    private Object[] creditcardTestValueList;
    private Object[] creditcardTestLabelList;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] strictDateTestValueList;
    private Object[] strictDateTestLabelList;

    public EnterDataValidateFormImpl()
    {
        hiddenNotValidatedDateFormatter.setLenient(true);
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    /**
     * Resets the given <code>minLengthOnPasswordTest</code>.
     */
    public void resetMinLengthOnPasswordTest()
    {
        this.minLengthOnPasswordTest = null;
    }
    
    public void setMinLengthOnPasswordTest(java.lang.String minLengthOnPasswordTest)
    {
        this.minLengthOnPasswordTest = minLengthOnPasswordTest;
    }

    /**
     * 
     */
    public java.lang.String getMinLengthOnPasswordTest()
    {
        return this.minLengthOnPasswordTest;
    }
    

    public Object[] getMinLengthOnPasswordTestBackingList()
    {
        Object[] values = this.minLengthOnPasswordTestValueList;
        Object[] labels = this.minLengthOnPasswordTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMinLengthOnPasswordTestValueList()
    {
        return this.minLengthOnPasswordTestValueList;
    }

    public void setMinLengthOnPasswordTestValueList(Object[] minLengthOnPasswordTestValueList)
    {
        this.minLengthOnPasswordTestValueList = minLengthOnPasswordTestValueList;
    }

    public Object[] getMinLengthOnPasswordTestLabelList()
    {
        return this.minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestLabelList(Object[] minLengthOnPasswordTestLabelList)
    {
        this.minLengthOnPasswordTestLabelList = minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMinLengthOnPasswordTestBackingList requires non-null property arguments");
        }

        this.minLengthOnPasswordTestValueList = null;
        this.minLengthOnPasswordTestLabelList = null;

        if (items != null)
        {
            this.minLengthOnPasswordTestValueList = new java.lang.Object[items.size()];
            this.minLengthOnPasswordTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.minLengthOnPasswordTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.minLengthOnPasswordTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setMinLengthOnPasswordTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>requiredTest</code>.
     */
    public void resetRequiredTest()
    {
        this.requiredTest = null;
    }
    
    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }
    

    public Object[] getRequiredTestBackingList()
    {
        Object[] values = this.requiredTestValueList;
        Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    public void setRequiredTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setRequiredTestBackingList requires non-null property arguments");
        }

        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;

        if (items != null)
        {
            this.requiredTestValueList = new java.lang.Object[items.size()];
            this.requiredTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.requiredTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.requiredTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setRequiredTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>emailTest</code>.
     */
    public void resetEmailTest()
    {
        this.emailTest = null;
    }
    
    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }
    

    public Object[] getEmailTestBackingList()
    {
        Object[] values = this.emailTestValueList;
        Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    public void setEmailTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setEmailTestBackingList requires non-null property arguments");
        }

        this.emailTestValueList = null;
        this.emailTestLabelList = null;

        if (items != null)
        {
            this.emailTestValueList = new java.lang.Object[items.size()];
            this.emailTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.emailTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.emailTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setEmailTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intRangeTest</code>.
     */
    public void resetIntRangeTest()
    {
        this.intRangeTest = 0;
    }
    
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }
    

    public Object[] getIntRangeTestBackingList()
    {
        Object[] values = this.intRangeTestValueList;
        Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    public void setIntRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setIntRangeTestBackingList requires non-null property arguments");
        }

        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;

        if (items != null)
        {
            this.intRangeTestValueList = new java.lang.Object[items.size()];
            this.intRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.intRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setIntRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleRangeTest</code>.
     */
    public void resetDoubleRangeTest()
    {
        this.doubleRangeTest = 0;
    }
    
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }
    

    public Object[] getDoubleRangeTestBackingList()
    {
        Object[] values = this.doubleRangeTestValueList;
        Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setDoubleRangeTestBackingList requires non-null property arguments");
        }

        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.doubleRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setDoubleRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hiddenNotValidated</code>.
     */
    public void resetHiddenNotValidated()
    {
        this.hiddenNotValidated = null;
    }
    
    public void setHiddenNotValidatedAsDate(java.util.Date hiddenNotValidated)
    {
        this.hiddenNotValidated = hiddenNotValidated;
    }

    /**
     * Returns the Date instance representing the <code>hiddenNotValidated</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getHiddenNotValidated
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#hiddenNotValidatedDateFormatter
     */
    public java.util.Date getHiddenNotValidatedAsDate()
    {
        return this.hiddenNotValidated;
    }

    public void setHiddenNotValidated(java.lang.String hiddenNotValidated)
    {
        if (hiddenNotValidated == null || hiddenNotValidated.trim().length() == 0)
        {
            this.hiddenNotValidated = null;
        }
        else
        {
            try
            {
                this.hiddenNotValidated = hiddenNotValidatedDateFormatter.parse(hiddenNotValidated);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.hiddenNotValidated = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getHiddenNotValidatedAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getHiddenNotValidatedDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getHiddenNotValidatedAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getHiddenNotValidatedDateFormatter
     */
    public java.lang.String getHiddenNotValidated()
    {
        return (hiddenNotValidated == null) ? null : hiddenNotValidatedDateFormatter.format(hiddenNotValidated);
    }

    /**
     * Returns the date formatter used for the <code>hiddenNotValidated</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getHiddenNotValidated
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getHiddenNotValidatedAsDate
     */
    public final static java.text.DateFormat getHiddenNotValidatedDateFormatter()
    {
        return EnterDataValidateFormImpl.hiddenNotValidatedDateFormatter;
    }


    public Object[] getHiddenNotValidatedBackingList()
    {
        Object[] values = this.hiddenNotValidatedValueList;
        Object[] labels = this.hiddenNotValidatedLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getHiddenNotValidatedValueList()
    {
        return this.hiddenNotValidatedValueList;
    }

    public void setHiddenNotValidatedValueList(Object[] hiddenNotValidatedValueList)
    {
        this.hiddenNotValidatedValueList = hiddenNotValidatedValueList;
    }

    public Object[] getHiddenNotValidatedLabelList()
    {
        return this.hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedLabelList(Object[] hiddenNotValidatedLabelList)
    {
        this.hiddenNotValidatedLabelList = hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setHiddenNotValidatedBackingList requires non-null property arguments");
        }

        this.hiddenNotValidatedValueList = null;
        this.hiddenNotValidatedLabelList = null;

        if (items != null)
        {
            this.hiddenNotValidatedValueList = new java.lang.Object[items.size()];
            this.hiddenNotValidatedLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.hiddenNotValidatedValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hiddenNotValidatedLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setHiddenNotValidatedBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>maxlengthTest</code>.
     */
    public void resetMaxlengthTest()
    {
        this.maxlengthTest = null;
    }
    
    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }
    

    public Object[] getMaxlengthTestBackingList()
    {
        Object[] values = this.maxlengthTestValueList;
        Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    public void setMaxlengthTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMaxlengthTestBackingList requires non-null property arguments");
        }

        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;

        if (items != null)
        {
            this.maxlengthTestValueList = new java.lang.Object[items.size()];
            this.maxlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.maxlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.maxlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setMaxlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>patternTest</code>.
     */
    public void resetPatternTest()
    {
        this.patternTest = null;
    }
    
    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }
    

    public Object[] getPatternTestBackingList()
    {
        Object[] values = this.patternTestValueList;
        Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    public void setPatternTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setPatternTestBackingList requires non-null property arguments");
        }

        this.patternTestValueList = null;
        this.patternTestLabelList = null;

        if (items != null)
        {
            this.patternTestValueList = new java.lang.Object[items.size()];
            this.patternTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.patternTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.patternTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setPatternTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatWrapperRangeTest</code>.
     */
    public void resetFloatWrapperRangeTest()
    {
        this.floatWrapperRangeTest = null;
    }
    
    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }
    

    public Object[] getFloatWrapperRangeTestBackingList()
    {
        Object[] values = this.floatWrapperRangeTestValueList;
        Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setFloatWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.floatWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.floatWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.floatWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setFloatWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intWrapperRangeTest</code>.
     */
    public void resetIntWrapperRangeTest()
    {
        this.intWrapperRangeTest = null;
    }
    
    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }
    

    public Object[] getIntWrapperRangeTestBackingList()
    {
        Object[] values = this.intWrapperRangeTestValueList;
        Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setIntWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.intWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.intWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.intWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setIntWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>lenientDateTest</code>.
     */
    public void resetLenientDateTest()
    {
        this.lenientDateTest = null;
    }
    
    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    /**
     * Returns the Date instance representing the <code>lenientDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#lenientDateTestDateFormatter
     */
    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length() == 0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.lenientDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getLenientDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getLenientDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getLenientDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getLenientDateTestDateFormatter
     */
    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    /**
     * Returns the date formatter used for the <code>lenientDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getLenientDateTestAsDate
     */
    public final static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return EnterDataValidateFormImpl.lenientDateTestDateFormatter;
    }


    public Object[] getLenientDateTestBackingList()
    {
        Object[] values = this.lenientDateTestValueList;
        Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    public void setLenientDateTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setLenientDateTestBackingList requires non-null property arguments");
        }

        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;

        if (items != null)
        {
            this.lenientDateTestValueList = new java.lang.Object[items.size()];
            this.lenientDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.lenientDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.lenientDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setLenientDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>urlTest</code>.
     */
    public void resetUrlTest()
    {
        this.urlTest = null;
    }
    
    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }
    

    public Object[] getUrlTestBackingList()
    {
        Object[] values = this.urlTestValueList;
        Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    public void setUrlTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setUrlTestBackingList requires non-null property arguments");
        }

        this.urlTestValueList = null;
        this.urlTestLabelList = null;

        if (items != null)
        {
            this.urlTestValueList = new java.lang.Object[items.size()];
            this.urlTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.urlTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.urlTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setUrlTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>minlengthTest</code>.
     */
    public void resetMinlengthTest()
    {
        this.minlengthTest = null;
    }
    
    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }
    

    public Object[] getMinlengthTestBackingList()
    {
        Object[] values = this.minlengthTestValueList;
        Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    public void setMinlengthTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMinlengthTestBackingList requires non-null property arguments");
        }

        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;

        if (items != null)
        {
            this.minlengthTestValueList = new java.lang.Object[items.size()];
            this.minlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.minlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.minlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setMinlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatRangeTest</code>.
     */
    public void resetFloatRangeTest()
    {
        this.floatRangeTest = 0;
    }
    
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }
    

    public Object[] getFloatRangeTestBackingList()
    {
        Object[] values = this.floatRangeTestValueList;
        Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    public void setFloatRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setFloatRangeTestBackingList requires non-null property arguments");
        }

        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;

        if (items != null)
        {
            this.floatRangeTestValueList = new java.lang.Object[items.size()];
            this.floatRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.floatRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setFloatRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleWrapperRangeTest</code>.
     */
    public void resetDoubleWrapperRangeTest()
    {
        this.doubleWrapperRangeTest = null;
    }
    
    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }
    

    public Object[] getDoubleWrapperRangeTestBackingList()
    {
        Object[] values = this.doubleWrapperRangeTestValueList;
        Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setDoubleWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.doubleWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setDoubleWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>creditcardTest</code>.
     */
    public void resetCreditcardTest()
    {
        this.creditcardTest = null;
    }
    
    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }
    

    public Object[] getCreditcardTestBackingList()
    {
        Object[] values = this.creditcardTestValueList;
        Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    public void setCreditcardTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setCreditcardTestBackingList requires non-null property arguments");
        }

        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;

        if (items != null)
        {
            this.creditcardTestValueList = new java.lang.Object[items.size()];
            this.creditcardTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.creditcardTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.creditcardTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setCreditcardTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>strictDateTest</code>.
     */
    public void resetStrictDateTest()
    {
        this.strictDateTest = null;
    }
    
    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    /**
     * Returns the Date instance representing the <code>strictDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#strictDateTestDateFormatter
     */
    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length() == 0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.strictDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getStrictDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getStrictDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getStrictDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getStrictDateTestDateFormatter
     */
    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    /**
     * Returns the date formatter used for the <code>strictDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.EnterDataValidateFormImpl#getStrictDateTestAsDate
     */
    public final static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return EnterDataValidateFormImpl.strictDateTestDateFormatter;
    }


    public Object[] getStrictDateTestBackingList()
    {
        Object[] values = this.strictDateTestValueList;
        Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    public void setStrictDateTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setStrictDateTestBackingList requires non-null property arguments");
        }

        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;

        if (items != null)
        {
            this.strictDateTestValueList = new java.lang.Object[items.size()];
            this.strictDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.strictDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.strictDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("EnterDataValidateFormImpl.setStrictDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("minLengthOnPasswordTest", "***");
        builder.append("requiredTest", this.requiredTest);
        builder.append("emailTest", this.emailTest);
        builder.append("intRangeTest", this.intRangeTest);
        builder.append("doubleRangeTest", this.doubleRangeTest);
        builder.append("hiddenNotValidated", this.hiddenNotValidated);
        builder.append("maxlengthTest", this.maxlengthTest);
        builder.append("patternTest", this.patternTest);
        builder.append("floatWrapperRangeTest", this.floatWrapperRangeTest);
        builder.append("intWrapperRangeTest", this.intWrapperRangeTest);
        builder.append("lenientDateTest", this.lenientDateTest);
        builder.append("urlTest", this.urlTest);
        builder.append("minlengthTest", this.minlengthTest);
        builder.append("floatRangeTest", this.floatRangeTest);
        builder.append("doubleWrapperRangeTest", this.doubleWrapperRangeTest);
        builder.append("creditcardTest", this.creditcardTest);
        builder.append("strictDateTest", this.strictDateTest);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.minLengthOnPasswordTest = null;
        this.requiredTest = null;
        this.emailTest = null;
        this.intRangeTest = 0;
        this.doubleRangeTest = 0;
        this.hiddenNotValidated = null;
        this.maxlengthTest = null;
        this.patternTest = null;
        this.floatWrapperRangeTest = null;
        this.intWrapperRangeTest = null;
        this.lenientDateTest = null;
        this.urlTest = null;
        this.minlengthTest = null;
        this.floatRangeTest = 0;
        this.doubleWrapperRangeTest = null;
        this.creditcardTest = null;
        this.strictDateTest = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}