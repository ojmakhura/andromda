package org.andromda.cartridges.bpm4struts.tests.messages;

/**
 * @struts.form
 *      name="messagesActivityMessagesActivityForm"
 */
public class MessagesActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , DoSomethingForm
{

    public MessagesActivityForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
