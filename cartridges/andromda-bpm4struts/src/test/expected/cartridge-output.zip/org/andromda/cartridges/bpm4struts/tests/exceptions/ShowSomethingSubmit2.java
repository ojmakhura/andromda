package org.andromda.cartridges.bpm4struts.tests.exceptions;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/ExceptionsActivity/ShowSomethingSubmit2"
 *        name="exceptionsActivityShowSomethingSubmit2Form"
 *       input="/ExceptionsActivity/ExceptionsActivity.do"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="unknown"
 *        path=".do"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="exceptions.activity.exception"
 *        type="some.custom.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/exceptions/enter-info.jsp"
 *       scope="request"
 *
 */
public final class ShowSomethingSubmit2 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = _stopUsecase(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _stopUsecase(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("unknown");
    }

}
