package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public interface DeferringOperationsForm
{
    public void setTestParam2(java.lang.String testParam2);
    public java.lang.String getTestParam2();
    public void resetTestParam2();

    public Object[] getTestParam2BackingList();
    public Object[] getTestParam2ValueList();
    public void setTestParam2ValueList(Object[] testParam2ValueList);
    public Object[] getTestParam2LabelList();
    public void setTestParam2LabelList(Object[] testParam2LabelList);

}
