package org.andromda.cartridges.bpm4struts.tests.finalstates.hyperlinked;

/**
 * @struts.form
 *      name="hyperlinkedHyperlinkedForm"
 */
public class HyperlinkedForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public HyperlinkedForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
