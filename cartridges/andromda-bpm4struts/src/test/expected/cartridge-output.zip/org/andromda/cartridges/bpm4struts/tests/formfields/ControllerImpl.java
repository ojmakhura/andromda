package org.andromda.cartridges.bpm4struts.tests.formfields;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void someOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.formfields.SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setDateAsDate(new java.util.Date());
        form.setNumber((int)-1034364087);
        form.setCollection(java.util.Arrays.asList(new Object[] {"collection-1", "collection-2", "collection-3", "collection-4", "collection-5"}));
        form.setCollectionValueList(new Object[] {"collection-1", "collection-2", "collection-3", "collection-4", "collection-5"});
        form.setCollectionLabelList(form.getCollectionValueList());
        form.setSelectable("selectable-test");
    }

    /**
     * 
     */
    public final void anotherOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.formfields.AnotherOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setNotused("notused-test");
        form.setUnusedNumber((int)-263744321);
    }

}
