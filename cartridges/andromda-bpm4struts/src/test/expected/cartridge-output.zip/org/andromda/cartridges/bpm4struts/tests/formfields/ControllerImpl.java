/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formfields;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller#someOperation(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.formfields.SomeOperationForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void someOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.formfields.SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setDateAsDate(new java.util.Date());
        form.setNumber((int)-1034364087);
        form.setCollection(java.util.Arrays.asList(new Object[] {"collection-1", "collection-2", "collection-3", "collection-4", "collection-5"}));
        form.setCollectionValueList(new Object[] {"collection-1", "collection-2", "collection-3", "collection-4", "collection-5"});
        form.setCollectionLabelList(form.getCollectionValueList());
        form.setSelectable("selectable-test");
        form.setSelectableValueList(new Object[] {"selectable-1", "selectable-2", "selectable-3", "selectable-4", "selectable-5"});
        form.setSelectableLabelList(form.getSelectableValueList());
        form.setFile(null);
        form.setIntegerClass(new Integer((int)-1019064614));
        form.setSetClass(new java.util.HashSet(java.util.Arrays.asList(new Object[] {"setClass-1", "setClass-2", "setClass-3", "setClass-4", "setClass-5"})));
        form.setSetClassValueList(new Object[] {"setClass-1", "setClass-2", "setClass-3", "setClass-4", "setClass-5"});
        form.setSetClassLabelList(form.getSetClassValueList());
        form.setMapClass(null);
        form.setBooleanClass(Boolean.FALSE);
        form.setBool(false);
        form.setFloatClass(new Float((float)-399754));
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller#anotherOperation(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.formfields.AnotherOperationForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void anotherOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.formfields.AnotherOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setNotused("notused-test");
        form.setUnusedNumber((int)-263744321);
    }

}
