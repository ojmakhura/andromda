/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State4NullForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , TestPageToPageForm
{

    private int decisionTestParam;
    private Object[] decisionTestParamValueList;
    private Object[] decisionTestParamLabelList;

    public State4NullForm()
    {
    }

    /**
     * Resets the given <code>decisionTestParam</code>.
     */
    public void resetDecisionTestParam()
    {
        this.decisionTestParam = 0;
    }
    
    public void setDecisionTestParam(int decisionTestParam)
    {
        this.decisionTestParam = decisionTestParam;
    }

    /**
     * 
     */
    public int getDecisionTestParam()
    {
        return this.decisionTestParam;
    }
    

    public Object[] getDecisionTestParamBackingList()
    {
        Object[] values = this.decisionTestParamValueList;
        Object[] labels = this.decisionTestParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDecisionTestParamValueList()
    {
        return this.decisionTestParamValueList;
    }

    public void setDecisionTestParamValueList(Object[] decisionTestParamValueList)
    {
        this.decisionTestParamValueList = decisionTestParamValueList;
    }

    public Object[] getDecisionTestParamLabelList()
    {
        return this.decisionTestParamLabelList;
    }

    public void setDecisionTestParamLabelList(Object[] decisionTestParamLabelList)
    {
        this.decisionTestParamLabelList = decisionTestParamLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("decisionTestParam", this.decisionTestParam);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.decisionTestParam = 0;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}