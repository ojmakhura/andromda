package org.andromda.cartridges.bpm4struts.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>someOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller#someOperation
 */
public interface SomeOperationForm
{
    /**
     * This field is a date type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setDate(java.lang.String)
     */
    public void setDateAsDate(java.util.Date date);
    
    /**
     * This field is a date type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getDate()
     */
    public java.util.Date getDateAsDate();

    /**
     * This field is a date type, and this method allows you to set it into the form as a String.
     *
     * 
     *
     * @see #setDate#sDate(java.util.Date)
     */
    public void setDate(java.lang.String date);
    
    /**
     * This field is a date type, and this method allows you to get it from the form as a String.
     *
     * 
     *
     * @see #getDate#sDate()
     */
    public java.lang.String getDate();
    
    /**
     * Resets the <code>date</code> field.
     */
    public void resetDate();

    /**
     * Sets the <code>number</code> field.
     *
     * 
     */
    public void setNumber(int number);
    
    /**
     * Gets the <code>number</code> field.
     *
     * 
     */
    public int getNumber();
    
    /**
     * Resets the <code>number</code> field.
     */
    public void resetNumber();

    /**
     * This field is a collection type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setCollection#sArray(Object[])
     */
    public void setCollection(java.util.Collection collection);
    
    /**
     * This field is a collection type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getCollection#sArray()
     */
    public java.util.Collection getCollection();

    /**
     * This field is a collection type, and this method allows you to set it as an
     * array into the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #setCollection(java.util.Collection)
     */
    public void setCollectionAsArray(Object[] collection);
    
    /**
     * This field is a collection type, and this method allows you to get it as an
     * array from the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #getCollection()
     */
    public Object[] getCollectionAsArray();
    
    /**
     * Resets the <code>collection</code> field.
     */
    public void resetCollection();

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getCollection()
     * @see #getCollectionValueList()
     * @see #getCollectionLabelList()
     */
    public Object[] getCollectionBackingList();
    
    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public Object[] getCollectionValueList();
    
    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public void setCollectionValueList(Object[] collectionValueList);
    
    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public Object[] getCollectionLabelList();
    
    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public void setCollectionLabelList(Object[] collectionLabelList);

    /**
     * Sets the <code>selectable</code> field.
     *
     * 
     */
    public void setSelectable(java.lang.String selectable);
    
    /**
     * Gets the <code>selectable</code> field.
     *
     * 
     */
    public java.lang.String getSelectable();
    
    /**
     * Resets the <code>selectable</code> field.
     */
    public void resetSelectable();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     */
    public Object[] getSelectableBackingList();
    
    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public Object[] getSelectableValueList();
    
    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableValueList(Object[] selectableValueList);
    
    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public Object[] getSelectableLabelList();
    
    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableLabelList(Object[] selectableLabelList);

}
