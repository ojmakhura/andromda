package org.andromda.cartridges.bpm4struts.tests.hyperlinkactions;

/**
 * @struts.form
 *      name="hyperlinkactionsShowSomethingNoparamhrefForm"
 */
public class ShowSomethingNoparamhrefForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String someParameter;

    public ShowSomethingNoparamhrefForm()
    {
    }

    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
    }

    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("someParameter=");
        buffer.append(String.valueOf(this.getSomeParameter()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.someParameter = null;
    }

}
