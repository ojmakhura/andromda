package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class Controller implements ControllerInterface
{

    /**
     * 
     * <p/>
     * This method does not receive any parameters through the form bean.
     */
    public final void loadTableData(ActionMapping mapping, NoTableLinkActivityForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        /*
         * By default this method populates the complete form, it is up to you to replace this
         * by those fields that are required (this cannot be determined here because it might be
         * the case that many action call this controller method, each with their own set of
         * parameters)
         */
        populateForm(form);
    }

    /**
     * This method exists solely to make the application work at runtime by populating
     * the complete form with default values.
     * <p/>
     * You may remove everything under here, including this comment. Simply make sure
     * you properly populate the form when implementing the operations.
     */
    private void populateForm(NoTableLinkActivityForm form)
    {
        form.setTableData(tableDataDummyList);
    }

    private final java.util.Collection tableDataDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataDummyItem("first-1", "second-1", "third-1", "fourth-1"),
            new TableDataDummyItem("first-2", "second-2", "third-2", "fourth-2"),
            new TableDataDummyItem("first-3", "second-3", "third-3", "fourth-3"),
            new TableDataDummyItem("first-4", "second-4", "third-4", "fourth-4"),
            new TableDataDummyItem("first-5", "second-5", "third-5", "fourth-5")
        } );

    public final class TableDataDummyItem implements java.io.Serializable
    {
        private String first = null;
        private String second = null;
        private String third = null;
        private String fourth = null;

        public TableDataDummyItem(String first, String second, String third, String fourth)
        {
            this.first = first;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
        }

        public void setFirst(String first)
        {
            this.first = first;
        }

        public String getFirst()
        {
            return this.first;
        }

        public void setSecond(String second)
        {
            this.second = second;
        }

        public String getSecond()
        {
            return this.second;
        }

        public void setThird(String third)
        {
            this.third = third;
        }

        public String getThird()
        {
            return this.third;
        }

        public void setFourth(String fourth)
        {
            this.fourth = fourth;
        }

        public String getFourth()
        {
            return this.fourth;
        }
    }

}
