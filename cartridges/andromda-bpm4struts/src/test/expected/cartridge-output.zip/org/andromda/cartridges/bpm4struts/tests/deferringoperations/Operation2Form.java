/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>operation2</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation2
 */
public interface Operation2Form
{
    /**
     * Sets the <code>testParam2</code> field.
     *
     * 
     */
    public void setTestParam2(int testParam2);

    /**
     * Gets the <code>testParam2</code> field.
     *
     * 
     */
    public int getTestParam2();
    
    /**
     * Resets the <code>testParam2</code> field.
     */
    public void resetTestParam2();

}
