/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>OperationNameAsUseCase</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase.Controller#OperationNameAsUseCase
 */
public interface OperationNameAsUseCaseForm
{
}
