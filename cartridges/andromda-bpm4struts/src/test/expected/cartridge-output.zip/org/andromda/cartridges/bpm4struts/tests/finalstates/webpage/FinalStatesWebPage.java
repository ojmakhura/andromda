/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.finalstates.webpage;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class FinalStatesWebPage extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = mapping.findForward("something");
        if (this.errorsNotPresent(request))
        {
            request.getSession().setAttribute("form", form);       
        }
        return forward;
    }


    /**
     * Returns true if <strong>NO</strong> errors
     * are present in the request.  This includes default validation
     * errors produced by the struts framework and the exception 
     * handler errors caught by the pattern matching 
     * exception handler.
     * 
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(HttpServletRequest request)
    {
        return this.getExceptionHandlerErrors(request).isEmpty() &&
        	(this.getErrors(request) == null || this.getErrors(request).isEmpty());
    }

    /**
     * <p>
     *  Retrieves the exception handler messages (if any).  Creates a new
     *  ActionMessages instance and returns that if one doesn't already exist.
     * </p>
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = 
            (org.apache.struts.action.ActionMessages)request.getAttribute(
                "org.andromda.bpm4struts.errormessages");
        if (errors == null)
        {
            errors = new org.apache.struts.action.ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", errors);
        }
        return errors;
    }
}
