package org.andromda.cartridges.bpm4struts.tests.pagevariables;

/**
 * @struts.form
 *      name="pageVariablesShowSomethingSubmitForm"
 */
public class ShowSomethingSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public ShowSomethingSubmitForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
