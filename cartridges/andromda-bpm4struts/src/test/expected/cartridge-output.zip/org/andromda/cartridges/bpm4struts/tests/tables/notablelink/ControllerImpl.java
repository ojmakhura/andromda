package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void loadTableData(ActionMapping mapping, ControllerLoadTableData form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTableData(tableDataDummyList);
    }

    private final java.util.Collection tableDataDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataDummy("first-1", "second-1", "third-1", "fourth-1"),
            new TableDataDummy("first-2", "second-2", "third-2", "fourth-2"),
            new TableDataDummy("first-3", "second-3", "third-3", "fourth-3"),
            new TableDataDummy("first-4", "second-4", "third-4", "fourth-4"),
            new TableDataDummy("first-5", "second-5", "third-5", "fourth-5")
        } );

    public final class TableDataDummy implements java.io.Serializable
    {
        private String first = null;
        private String second = null;
        private String third = null;
        private String fourth = null;

        public TableDataDummy(String first, String second, String third, String fourth)
        {
            this.first = first;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
        }

        public void setFirst(String first)
        {
            this.first = first;
        }

        public String getFirst()
        {
            return this.first;
        }

        public void setSecond(String second)
        {
            this.second = second;
        }

        public String getSecond()
        {
            return this.second;
        }

        public void setThird(String third)
        {
            this.third = third;
        }

        public String getThird()
        {
            return this.third;
        }

        public void setFourth(String fourth)
        {
            this.fourth = fourth;
        }

        public String getFourth()
        {
            return this.fourth;
        }
    }

}
