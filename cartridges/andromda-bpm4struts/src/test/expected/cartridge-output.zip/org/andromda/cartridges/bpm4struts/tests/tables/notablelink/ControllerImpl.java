/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.tables.notablelink.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.tables.notablelink.Controller#loadTableData(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.tables.notablelink.LoadTableDataForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void loadTableData(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.tables.notablelink.LoadTableDataForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * This dummy variable is used to populate the "tableData" table.
     * You may delete it when you add you own code in this controller.
     */
    private final java.util.Collection tableDataDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataDummy("first.name-1", "second-1", "third-1", "fourth-1", "fifth.name-1"),
            new TableDataDummy("first.name-2", "second-2", "third-2", "fourth-2", "fifth.name-2"),
            new TableDataDummy("first.name-3", "second-3", "third-3", "fourth-3", "fifth.name-3"),
            new TableDataDummy("first.name-4", "second-4", "third-4", "fourth-4", "fifth.name-4"),
            new TableDataDummy("first.name-5", "second-5", "third-5", "fourth-5", "fifth.name-5")
        } );

    /**
     * This inner class is used in the dummy implementation in order to get the web application
     * running without any manual programming.
     * You may delete this class when you add you own code in this controller.
     */
    public final class TableDataDummy implements java.io.Serializable
    {
        private String firstName = null;
        private String second = null;
        private String third = null;
        private String fourth = null;
        private String fifthName = null;

        public TableDataDummy(String firstName, String second, String third, String fourth, String fifthName)
        {
            this.firstName = firstName;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
            this.fifthName = fifthName;
        }
        
        public void setFirstName(String firstName)
        {
            this.firstName = firstName;
        }

        public String getFirstName()
        {
            return this.firstName;
        }
        
        public void setSecond(String second)
        {
            this.second = second;
        }

        public String getSecond()
        {
            return this.second;
        }
        
        public void setThird(String third)
        {
            this.third = third;
        }

        public String getThird()
        {
            return this.third;
        }
        
        public void setFourth(String fourth)
        {
            this.fourth = fourth;
        }

        public String getFourth()
        {
            return this.fourth;
        }
        
        public void setFifthName(String fifthName)
        {
            this.fifthName = fifthName;
        }

        public String getFifthName()
        {
            return this.fifthName;
        }
        
    }

}