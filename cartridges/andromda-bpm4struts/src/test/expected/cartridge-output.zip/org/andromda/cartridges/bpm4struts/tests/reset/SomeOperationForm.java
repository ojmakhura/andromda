/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.reset;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>someOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.reset.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.reset.Controller#someOperation
 */
public interface SomeOperationForm
{
    /**
     * Sets the <code>firstParam</code> field.
     *
     * 
     */
    public void setFirstParam(java.lang.String firstParam);

    /**
     * Gets the <code>firstParam</code> field.
     *
     * 
     */
    public java.lang.String getFirstParam();
    
    /**
     * Resets the <code>firstParam</code> field.
     */
    public void resetFirstParam();

}
