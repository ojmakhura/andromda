package org.andromda.cartridges.bpm4struts.tests.reset;

public interface SomeOperationForm
{
    public void setFirstParam(java.lang.String firstParam);
    public java.lang.String getFirstParam();
    public void resetFirstParam();

}
