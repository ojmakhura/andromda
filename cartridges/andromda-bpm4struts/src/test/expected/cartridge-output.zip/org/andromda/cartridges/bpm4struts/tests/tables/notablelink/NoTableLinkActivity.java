package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/NoTableLinkActivity/NoTableLinkActivity"
 *        name="noTableLinkActivityForm"
 *    validate="false"
 *       scope="session"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="show.table.data"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *    redirect="false"
 *
 */
public final class NoTableLinkActivity extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        /*
         * Since this action is the first one for this use-case, we need to clean the session-scoped
         * form from any stale data. It is not a good idea to keep data floating between use-cases.
         * If you really need to transfer data between use-cases you should use the
         * HttpServletRequest.setAttribute(String,Object) method for that.
         */
        ((NoTableLinkActivityForm)form).clean();

        final ActionForward forward = loadTableData(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward loadTableData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().loadTableData(mapping, (NoTableLinkActivityForm)form, request, response);
        return mapping.findForward("show.table.data");
    }

}
