package org.andromda.cartridges.bpm4struts.tests.finalstates.nohrefnoname;

/**
 * @struts.form
 *      name="nohrefnonameNohrefnonameForm"
 */
public class NohrefnonameForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public NohrefnonameForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
