package org.andromda.cartridges.bpm4struts.tests.widgets;

/**
 * @struts.form
 *      name="widgetsActivityWidgetsActivityForm"
 */
public class WidgetsActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String submitRadioButtonsTest2;
    private java.lang.String submitPasswordFieldTest;
    private java.lang.String submitRadioButtonsTest;
    private java.lang.String submitTextAreaTest;
    private java.lang.String submitRadioButtonsTest3;
    private java.lang.String submitSelectTest;
    private Object[] submitSelectTestValueList;
    private Object[] submitSelectTestLabelList;
    private java.lang.String submitTextFieldTest;
    private java.lang.String submitHiddenTest;
    private java.lang.String submitTextFieldTest2;
    private boolean submitCheckboxTest;

    public WidgetsActivityForm()
    {
    }

    public void setSubmitRadioButtonsTest2(java.lang.String submitRadioButtonsTest2)
    {
        this.submitRadioButtonsTest2 = submitRadioButtonsTest2;
    }

    public java.lang.String getSubmitRadioButtonsTest2()
    {
        return this.submitRadioButtonsTest2;
    }

    public void setSubmitPasswordFieldTest(java.lang.String submitPasswordFieldTest)
    {
        this.submitPasswordFieldTest = submitPasswordFieldTest;
    }

    public java.lang.String getSubmitPasswordFieldTest()
    {
        return this.submitPasswordFieldTest;
    }

    public void setSubmitRadioButtonsTest(java.lang.String submitRadioButtonsTest)
    {
        this.submitRadioButtonsTest = submitRadioButtonsTest;
    }

    public java.lang.String getSubmitRadioButtonsTest()
    {
        return this.submitRadioButtonsTest;
    }

    public void setSubmitTextAreaTest(java.lang.String submitTextAreaTest)
    {
        this.submitTextAreaTest = submitTextAreaTest;
    }

    public java.lang.String getSubmitTextAreaTest()
    {
        return this.submitTextAreaTest;
    }

    public void setSubmitRadioButtonsTest3(java.lang.String submitRadioButtonsTest3)
    {
        this.submitRadioButtonsTest3 = submitRadioButtonsTest3;
    }

    public java.lang.String getSubmitRadioButtonsTest3()
    {
        return this.submitRadioButtonsTest3;
    }

    public void setSubmitSelectTest(java.lang.String submitSelectTest)
    {
        this.submitSelectTest = submitSelectTest;
    }

    public java.lang.String getSubmitSelectTest()
    {
        return this.submitSelectTest;
    }

    public Object[] getSubmitSelectTestBackingList()
    {
        Object[] values = this.submitSelectTestValueList;
        Object[] labels = this.submitSelectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSubmitSelectTestValueList()
    {
        return this.submitSelectTestValueList;
    }

    public void setSubmitSelectTestValueList(Object[] submitSelectTestValueList)
    {
        this.submitSelectTestValueList = submitSelectTestValueList;
    }

    public Object[] getSubmitSelectTestLabelList()
    {
        return this.submitSelectTestLabelList;
    }

    public void setSubmitSelectTestLabelList(Object[] submitSelectTestLabelList)
    {
        this.submitSelectTestLabelList = submitSelectTestLabelList;
    }

    public void setSubmitTextFieldTest(java.lang.String submitTextFieldTest)
    {
        this.submitTextFieldTest = submitTextFieldTest;
    }

    public java.lang.String getSubmitTextFieldTest()
    {
        return this.submitTextFieldTest;
    }

    public void setSubmitHiddenTest(java.lang.String submitHiddenTest)
    {
        this.submitHiddenTest = submitHiddenTest;
    }

    public java.lang.String getSubmitHiddenTest()
    {
        return this.submitHiddenTest;
    }

    public void setSubmitTextFieldTest2(java.lang.String submitTextFieldTest2)
    {
        this.submitTextFieldTest2 = submitTextFieldTest2;
    }

    public java.lang.String getSubmitTextFieldTest2()
    {
        return this.submitTextFieldTest2;
    }

    public void setSubmitCheckboxTest(boolean submitCheckboxTest)
    {
        this.submitCheckboxTest = submitCheckboxTest;
    }

    public boolean getSubmitCheckboxTest()
    {
        return this.submitCheckboxTest;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.submitCheckboxTest = false;
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("submitRadioButtonsTest2=");
        buffer.append(String.valueOf(this.getSubmitRadioButtonsTest2()));
        buffer.append(",submitPasswordFieldTest=");
        buffer.append(String.valueOf(this.getSubmitPasswordFieldTest()));
        buffer.append(",submitRadioButtonsTest=");
        buffer.append(String.valueOf(this.getSubmitRadioButtonsTest()));
        buffer.append(",submitTextAreaTest=");
        buffer.append(String.valueOf(this.getSubmitTextAreaTest()));
        buffer.append(",submitRadioButtonsTest3=");
        buffer.append(String.valueOf(this.getSubmitRadioButtonsTest3()));
        buffer.append(",submitSelectTest=");
        buffer.append(String.valueOf(this.getSubmitSelectTest()));
        buffer.append(",submitTextFieldTest=");
        buffer.append(String.valueOf(this.getSubmitTextFieldTest()));
        buffer.append(",submitHiddenTest=");
        buffer.append(String.valueOf(this.getSubmitHiddenTest()));
        buffer.append(",submitTextFieldTest2=");
        buffer.append(String.valueOf(this.getSubmitTextFieldTest2()));
        buffer.append(",submitCheckboxTest=");
        buffer.append(String.valueOf(this.getSubmitCheckboxTest()));

        return buffer.append("]").toString();
    }

    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    public void clean()
    {
        this.submitRadioButtonsTest2 = null;
        this.submitPasswordFieldTest = null;
        this.submitRadioButtonsTest = null;
        this.submitTextAreaTest = null;
        this.submitRadioButtonsTest3 = null;
        this.submitSelectTest = null;
        this.submitTextFieldTest = null;
        this.submitHiddenTest = null;
        this.submitTextFieldTest2 = null;
        this.submitCheckboxTest = false;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}
