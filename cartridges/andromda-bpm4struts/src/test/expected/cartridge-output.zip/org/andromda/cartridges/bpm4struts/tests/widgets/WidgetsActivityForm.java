/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.widgets;

public class WidgetsActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , PreloadSelectsForm
{

    private java.lang.String textAreaTest;
    private Object[] textAreaTestValueList;
    private Object[] textAreaTestLabelList;
    private java.lang.String radioButtonsTest3;
    private Object[] radioButtonsTest3ValueList;
    private Object[] radioButtonsTest3LabelList;
    private java.lang.String radioButtonsTest;
    private Object[] radioButtonsTestValueList;
    private Object[] radioButtonsTestLabelList;
    private boolean checkboxTest;
    private Object[] checkboxTestValueList;
    private Object[] checkboxTestLabelList;
    private java.lang.String textFieldTest2;
    private Object[] textFieldTest2ValueList;
    private Object[] textFieldTest2LabelList;
    private java.lang.String selectTest;
    private Object[] selectTestValueList;
    private Object[] selectTestLabelList;
    private java.lang.String textFieldTest;
    private Object[] textFieldTestValueList;
    private Object[] textFieldTestLabelList;
    private java.lang.String hiddenTest;
    private Object[] hiddenTestValueList;
    private Object[] hiddenTestLabelList;
    private java.lang.String passwordFieldTest;
    private Object[] passwordFieldTestValueList;
    private Object[] passwordFieldTestLabelList;
    private java.lang.String radioButtonsTest2;
    private Object[] radioButtonsTest2ValueList;
    private Object[] radioButtonsTest2LabelList;

    public WidgetsActivityForm()
    {
    }

    /**
     * Resets the given <code>textAreaTest</code>.
     */
    public void resetTextAreaTest()
    {
        this.textAreaTest = null;
    }
    
    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
    }

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }
    

    public Object[] getTextAreaTestBackingList()
    {
        Object[] values = this.textAreaTestValueList;
        Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * textAreaTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the textAreaTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setTextAreaTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setTextAreaTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setTextAreaTestBackingList requires non-null property arguments");
        }

        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;

        if (items != null)
        {
            this.textAreaTestValueList = new Object[items.size()];
            this.textAreaTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.textAreaTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textAreaTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setTextAreaTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest3</code>.
     */
    public void resetRadioButtonsTest3()
    {
        this.radioButtonsTest3 = null;
    }
    
    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }
    

    public Object[] getRadioButtonsTest3BackingList()
    {
        Object[] values = this.radioButtonsTest3ValueList;
        Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * radioButtonsTest3 property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the radioButtonsTest3 backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setRadioButtonsTest3BackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setRadioButtonsTest3BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTest3BackingList requires non-null property arguments");
        }

        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;

        if (items != null)
        {
            this.radioButtonsTest3ValueList = new Object[items.size()];
            this.radioButtonsTest3LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.radioButtonsTest3ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTest3LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTest3BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest</code>.
     */
    public void resetRadioButtonsTest()
    {
        this.radioButtonsTest = null;
    }
    
    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }
    

    public Object[] getRadioButtonsTestBackingList()
    {
        Object[] values = this.radioButtonsTestValueList;
        Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * radioButtonsTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the radioButtonsTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setRadioButtonsTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setRadioButtonsTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTestBackingList requires non-null property arguments");
        }

        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;

        if (items != null)
        {
            this.radioButtonsTestValueList = new Object[items.size()];
            this.radioButtonsTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.radioButtonsTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>checkboxTest</code>.
     */
    public void resetCheckboxTest()
    {
        this.checkboxTest = false;
    }
    
    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
    }

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }
    

    public Object[] getCheckboxTestBackingList()
    {
        Object[] values = this.checkboxTestValueList;
        Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * checkboxTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the checkboxTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setCheckboxTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setCheckboxTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setCheckboxTestBackingList requires non-null property arguments");
        }

        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;

        if (items != null)
        {
            this.checkboxTestValueList = new Object[items.size()];
            this.checkboxTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.checkboxTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.checkboxTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setCheckboxTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>textFieldTest2</code>.
     */
    public void resetTextFieldTest2()
    {
        this.textFieldTest2 = null;
    }
    
    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }
    

    public Object[] getTextFieldTest2BackingList()
    {
        Object[] values = this.textFieldTest2ValueList;
        Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * textFieldTest2 property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the textFieldTest2 backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setTextFieldTest2BackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setTextFieldTest2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setTextFieldTest2BackingList requires non-null property arguments");
        }

        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;

        if (items != null)
        {
            this.textFieldTest2ValueList = new Object[items.size()];
            this.textFieldTest2LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.textFieldTest2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textFieldTest2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setTextFieldTest2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>selectTest</code>.
     */
    public void resetSelectTest()
    {
        this.selectTest = null;
    }
    
    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
    }

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }
    

    public Object[] getSelectTestBackingList()
    {
        Object[] values = this.selectTestValueList;
        Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * selectTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the selectTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSelectTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setSelectTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setSelectTestBackingList requires non-null property arguments");
        }

        this.selectTestValueList = null;
        this.selectTestLabelList = null;

        if (items != null)
        {
            this.selectTestValueList = new Object[items.size()];
            this.selectTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.selectTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.selectTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setSelectTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>textFieldTest</code>.
     */
    public void resetTextFieldTest()
    {
        this.textFieldTest = null;
    }
    
    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }
    

    public Object[] getTextFieldTestBackingList()
    {
        Object[] values = this.textFieldTestValueList;
        Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * textFieldTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the textFieldTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setTextFieldTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setTextFieldTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setTextFieldTestBackingList requires non-null property arguments");
        }

        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;

        if (items != null)
        {
            this.textFieldTestValueList = new Object[items.size()];
            this.textFieldTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.textFieldTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textFieldTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setTextFieldTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hiddenTest</code>.
     */
    public void resetHiddenTest()
    {
        this.hiddenTest = null;
    }
    
    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
    }

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }
    

    public Object[] getHiddenTestBackingList()
    {
        Object[] values = this.hiddenTestValueList;
        Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * hiddenTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the hiddenTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setHiddenTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setHiddenTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setHiddenTestBackingList requires non-null property arguments");
        }

        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;

        if (items != null)
        {
            this.hiddenTestValueList = new Object[items.size()];
            this.hiddenTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.hiddenTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hiddenTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setHiddenTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>passwordFieldTest</code>.
     */
    public void resetPasswordFieldTest()
    {
        this.passwordFieldTest = null;
    }
    
    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }
    

    public Object[] getPasswordFieldTestBackingList()
    {
        Object[] values = this.passwordFieldTestValueList;
        Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * passwordFieldTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the passwordFieldTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setPasswordFieldTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setPasswordFieldTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setPasswordFieldTestBackingList requires non-null property arguments");
        }

        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;

        if (items != null)
        {
            this.passwordFieldTestValueList = new Object[items.size()];
            this.passwordFieldTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.passwordFieldTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.passwordFieldTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setPasswordFieldTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest2</code>.
     */
    public void resetRadioButtonsTest2()
    {
        this.radioButtonsTest2 = null;
    }
    
    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }
    

    public Object[] getRadioButtonsTest2BackingList()
    {
        Object[] values = this.radioButtonsTest2ValueList;
        Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * radioButtonsTest2 property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the radioButtonsTest2 backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setRadioButtonsTest2BackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *      will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *      the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>, or if one
     *      of the items in the collection is <code>null</code>, if the caller does not have access one of the object's
     *      properties, if an exception was thrown while accessing a property or if the property does not exist on at
     *      least one of the items
     */
    public void setRadioButtonsTest2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTest2BackingList requires non-null property arguments");
        }

        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;

        if (items != null)
        {
            this.radioButtonsTest2ValueList = new Object[items.size()];
            this.radioButtonsTest2LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.radioButtonsTest2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTest2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new IllegalArgumentException("WidgetsActivityForm.setRadioButtonsTest2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.checkboxTest = false;
        this.selectTest = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("textAreaTest", this.textAreaTest);
        builder.append("radioButtonsTest3", this.radioButtonsTest3);
        builder.append("radioButtonsTest", this.radioButtonsTest);
        builder.append("checkboxTest", this.checkboxTest);
        builder.append("textFieldTest2", this.textFieldTest2);
        builder.append("selectTest", this.selectTest);
        builder.append("textFieldTest", this.textFieldTest);
        builder.append("hiddenTest", this.hiddenTest);
        builder.append("passwordFieldTest", "***");
        builder.append("radioButtonsTest2", this.radioButtonsTest2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.textAreaTest = null;
        this.radioButtonsTest3 = null;
        this.radioButtonsTest = null;
        this.checkboxTest = false;
        this.textFieldTest2 = null;
        this.selectTest = null;
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        this.textFieldTest = null;
        this.hiddenTest = null;
        this.passwordFieldTest = null;
        this.radioButtonsTest2 = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}