/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.pagevariables;

public class PageVariablesFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String a;
    private Object[] aValueList;
    private Object[] aLabelList;
    private java.util.Date c;
    private final static java.text.DateFormat cDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] cValueList;
    private Object[] cLabelList;
    private int b;
    private Object[] bValueList;
    private Object[] bLabelList;

    public PageVariablesFormImpl()
    {
        cDateFormatter.setLenient(true);
    }

    /**
     * Resets the given <code>a</code>.
     */
    public void resetA()
    {
        this.a = null;
    }
    
    public void setA(java.lang.String a)
    {
        this.a = a;
    }

    /**
     * 
     */
    public java.lang.String getA()
    {
        return this.a;
    }
    

    public Object[] getABackingList()
    {
        Object[] values = this.aValueList;
        Object[] labels = this.aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getAValueList()
    {
        return this.aValueList;
    }

    public void setAValueList(Object[] aValueList)
    {
        this.aValueList = aValueList;
    }

    public Object[] getALabelList()
    {
        return this.aLabelList;
    }

    public void setALabelList(Object[] aLabelList)
    {
        this.aLabelList = aLabelList;
    }

    public void setABackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setABackingList requires non-null property arguments");
        }

        this.aValueList = null;
        this.aLabelList = null;

        if (items != null)
        {
            this.aValueList = new Object[items.size()];
            this.aLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.aValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.aLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("PageVariablesFormImpl.setABackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>c</code>.
     */
    public void resetC()
    {
        this.c = null;
    }
    
    public void setCAsDate(java.util.Date c)
    {
        this.c = c;
    }

    /**
     * Returns the Date instance representing the <code>c</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#getC
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#cDateFormatter
     */
    public java.util.Date getCAsDate()
    {
        return this.c;
    }

    public void setC(java.lang.String c)
    {
        if (c == null || c.trim().length() == 0)
        {
            this.c = null;
        }
        else
        {
            try
            {
                this.c = cDateFormatter.parse(c);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.c = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getCAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getCDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#getCAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#getCDateFormatter
     */
    public java.lang.String getC()
    {
        return (c == null) ? null : cDateFormatter.format(c);
    }

    /**
     * Returns the date formatter used for the <code>c</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#getC
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesFormImpl#getCAsDate
     */
    public final static java.text.DateFormat getCDateFormatter()
    {
        return PageVariablesFormImpl.cDateFormatter;
    }


    public Object[] getCBackingList()
    {
        Object[] values = this.cValueList;
        Object[] labels = this.cLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCValueList()
    {
        return this.cValueList;
    }

    public void setCValueList(Object[] cValueList)
    {
        this.cValueList = cValueList;
    }

    public Object[] getCLabelList()
    {
        return this.cLabelList;
    }

    public void setCLabelList(Object[] cLabelList)
    {
        this.cLabelList = cLabelList;
    }

    public void setCBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setCBackingList requires non-null property arguments");
        }

        this.cValueList = null;
        this.cLabelList = null;

        if (items != null)
        {
            this.cValueList = new Object[items.size()];
            this.cLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.cValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.cLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("PageVariablesFormImpl.setCBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>b</code>.
     */
    public void resetB()
    {
        this.b = 0;
    }
    
    public void setB(int b)
    {
        this.b = b;
    }

    /**
     * 
     */
    public int getB()
    {
        return this.b;
    }
    

    public Object[] getBBackingList()
    {
        Object[] values = this.bValueList;
        Object[] labels = this.bLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getBValueList()
    {
        return this.bValueList;
    }

    public void setBValueList(Object[] bValueList)
    {
        this.bValueList = bValueList;
    }

    public Object[] getBLabelList()
    {
        return this.bLabelList;
    }

    public void setBLabelList(Object[] bLabelList)
    {
        this.bLabelList = bLabelList;
    }

    public void setBBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setBBackingList requires non-null property arguments");
        }

        this.bValueList = null;
        this.bLabelList = null;

        if (items != null)
        {
            this.bValueList = new Object[items.size()];
            this.bLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.bValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.bLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("PageVariablesFormImpl.setBBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("a", this.a);
        builder.append("c", this.c);
        builder.append("b", this.b);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.a = null;
        this.c = null;
        this.b = 0;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}