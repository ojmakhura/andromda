/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class TableLinkActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , LoadTableDataForm
{

    private java.util.Collection tableDataNoExportTypes;
    private Object[] tableDataNoExportTypesValueList;
    private Object[] tableDataNoExportTypesLabelList;
    private java.util.Collection tableDataDefaultExportTypes;
    private Object[] tableDataDefaultExportTypesValueList;
    private Object[] tableDataDefaultExportTypesLabelList;
    private java.lang.String first;
    private Object[] firstValueList;
    private Object[] firstLabelList;
    private java.lang.String[] multiboxThing;
    private Object[] multiboxThingValueList;
    private Object[] multiboxThingLabelList;
    private java.util.Collection tableData;
    private Object[] tableDataValueList;
    private Object[] tableDataLabelList;
    private java.lang.String third;
    private Object[] thirdValueList;
    private Object[] thirdLabelList;
    private java.lang.String fourth;
    private Object[] fourthValueList;
    private Object[] fourthLabelList;
    private java.lang.String second;
    private Object[] secondValueList;
    private Object[] secondLabelList;

    public TableLinkActivityForm()
    {
    }

    /**
     * Resets the given <code>tableDataNoExportTypes</code>.
     */
    public void resetTableDataNoExportTypes()
    {
        this.tableDataNoExportTypes = null;
    }
    
    public void setTableDataNoExportTypes(java.util.Collection tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    public void setTableDataNoExportTypesAsArray(Object[] tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = (tableDataNoExportTypes == null) ? null : java.util.Arrays.asList(tableDataNoExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm#getTableDataNoExportTypes
     */
    public Object[] getTableDataNoExportTypesAsArray()
    {
        return (tableDataNoExportTypes == null) ? null : tableDataNoExportTypes.toArray();
    }
    

    public Object[] getTableDataNoExportTypesBackingList()
    {
        Object[] values = this.tableDataNoExportTypesValueList;
        Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    /**
     * Resets the given <code>tableDataDefaultExportTypes</code>.
     */
    public void resetTableDataDefaultExportTypes()
    {
        this.tableDataDefaultExportTypes = null;
    }
    
    public void setTableDataDefaultExportTypes(java.util.Collection tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    public void setTableDataDefaultExportTypesAsArray(Object[] tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = (tableDataDefaultExportTypes == null) ? null : java.util.Arrays.asList(tableDataDefaultExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm#getTableDataDefaultExportTypes
     */
    public Object[] getTableDataDefaultExportTypesAsArray()
    {
        return (tableDataDefaultExportTypes == null) ? null : tableDataDefaultExportTypes.toArray();
    }
    

    public Object[] getTableDataDefaultExportTypesBackingList()
    {
        Object[] values = this.tableDataDefaultExportTypesValueList;
        Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    /**
     * Resets the given <code>first</code>.
     */
    public void resetFirst()
    {
        this.first = null;
    }
    
    public void setFirst(java.lang.String first)
    {
        this.first = first;
    }

    /**
     * 
     */
    public java.lang.String getFirst()
    {
        return this.first;
    }
    

    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    /**
     * Resets the given <code>multiboxThing</code>.
     */
    public void resetMultiboxThing()
    {
        this.multiboxThing = null;
    }
    
    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
    }

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }
    

    public Object[] getMultiboxThingBackingList()
    {
        Object[] values = this.multiboxThingValueList;
        Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = null;
    }
    
    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm#getTableData
     */
    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    

    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    /**
     * Resets the given <code>third</code>.
     */
    public void resetThird()
    {
        this.third = null;
    }
    
    public void setThird(java.lang.String third)
    {
        this.third = third;
    }

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }
    

    public Object[] getThirdBackingList()
    {
        Object[] values = this.thirdValueList;
        Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    /**
     * Resets the given <code>fourth</code>.
     */
    public void resetFourth()
    {
        this.fourth = null;
    }
    
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
    }

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }
    

    public Object[] getFourthBackingList()
    {
        Object[] values = this.fourthValueList;
        Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }
    
    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    

    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.multiboxThing = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("tableDataNoExportTypes", this.tableDataNoExportTypes);
        builder.append("tableDataDefaultExportTypes", this.tableDataDefaultExportTypes);
        builder.append("first", this.first);
        builder.append("multiboxThing", this.multiboxThing);
        builder.append("tableData", this.tableData);
        builder.append("third", this.third);
        builder.append("fourth", this.fourth);
        builder.append("second", this.second);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableDataNoExportTypes = null;
        this.tableDataDefaultExportTypes = null;
        this.first = null;
        this.multiboxThing = null;
        this.tableData = null;
        this.third = null;
        this.fourth = null;
        this.second = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}