/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.returntypevoid;

/**
 * 
 */
public final class DecisionsReturnTypeVoid extends org.apache.struts.action.Action
{
    public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        return _something(mapping, form, request, response);
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward _something(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        org.apache.struts.action.ActionForward forward = null;
        forward = __voidReturnTypeOperation(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward __voidReturnTypeOperation(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        // we pass an empty form implementation to the controller, we know there are no parameters on this operation because the
        // cartridge would have issued a model validation error
        final String value = String.valueOf(ControllerFactory.getControllerInstance().voidReturnTypeOperation(mapping, new VoidReturnTypeOperationForm(){}, request, response));

        if (value.equals("someGuard"))
        {
            return _something(mapping, form, request, response);
        }
        if (value.equals("anotherGuard"))
        {
            return _something(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _something(mapping, form, request, response);
    }

}
