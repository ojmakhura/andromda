package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.returntypevoid;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class DecisionsReturnTypeVoid extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("form", form);
        final ActionForward forward = _something(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _something(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;
        forward = voidReturnTypeOperation(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward voidReturnTypeOperation(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final String value = String.valueOf(ControllerFactory.getControllerInstance().voidReturnTypeOperation(mapping, (DecisionsReturnTypeVoidForm)form, request, response));

        if (value.equals("someGuard"))
        {
            return _something(mapping, form, request, response);
        }
        if (value.equals("anotherGuard"))
        {
            return _something(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _something(mapping, form, request, response);
    }


    /**
     * <p>
     *  Retrieves the exception handler messages (if any).  Creates a new
     *  ActionMessages instance and returns that if one doesn't already exist.
     * </p>
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = 
            (org.apache.struts.action.ActionMessages)request.getAttribute(
                "org.andromda.bpm4struts.errormessages");
        if (errors == null)
        {
            errors = new org.apache.struts.action.ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", errors);
        }
        return errors;
    }
}
