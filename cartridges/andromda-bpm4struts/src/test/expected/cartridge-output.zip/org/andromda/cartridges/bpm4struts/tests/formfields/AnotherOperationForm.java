package org.andromda.cartridges.bpm4struts.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anotherOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller#anotherOperation
 */
public interface AnotherOperationForm
{
    /**
     * Sets the <code>notused</code> field.
     *
     * 
     */
    public void setNotused(java.lang.String notused);
    /**
     * Gets the <code>notused</code> field.
     *
     * 
     */
    public java.lang.String getNotused();
    /**
     * Resets the <code>notused</code> field.
     */
    public void resetNotused();

    /**
     * Sets the <code>unusedNumber</code> field.
     *
     * 
     */
    public void setUnusedNumber(int unusedNumber);
    /**
     * Gets the <code>unusedNumber</code> field.
     *
     * 
     */
    public int getUnusedNumber();
    /**
     * Resets the <code>unusedNumber</code> field.
     */
    public void resetUnusedNumber();

}
