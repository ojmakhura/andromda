/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.crud.crud;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

public final class ManageRoom extends DispatchAction
{
    public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("manageableForm", actionForm);
        return super.execute(mapping, actionForm, request, response);
    }

    public ActionForward create(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm)actionForm;

System.out.println(request.getParameter("date"));
System.out.println(request.getParameter("specificId"));
System.out.println(request.getParameter("named"));
        .create(
            (StringUtils.isBlank(request.getParameter("dateAsString"))) ? null : form.getDate()
            , (StringUtils.isBlank(request.getParameter("specificId"))) ? null : form.getSpecificId()
            , (StringUtils.isBlank(request.getParameter("named"))) ? null : form.getNamed()
        );

        return preload(mapping, actionForm, request, response);
    }

    public ActionForward read(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm)actionForm;

        final java.util.List list = .read(
            (StringUtils.isBlank(request.getParameter("dateAsString"))) ? null : form.getDate()
            , (StringUtils.isBlank(request.getParameter("specificId"))) ? null : form.getSpecificId()
            , (StringUtils.isBlank(request.getParameter("named"))) ? null : form.getNamed()
        );
        form.setManageableList(list);

        if (list.size() >= 250)
        {
            saveMaxResultsWarning(request);
        }

        final java.util.Map backingLists = .readBackingLists();
        form.setNamedBackingList((java.util.List)backingLists.get("named"));

        return mapping.getInputForward();
    }

    public ActionForward preload(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm)actionForm;

        final java.util.List list = .readAll();
        form.setManageableList(list);


        if (list.size() >= 250)
        {
            saveMaxResultsWarning(request);
        }

        final java.util.Map backingLists = .readBackingLists();
        if (StringUtils.isNotBlank(request.getParameter("ref_House")))
        {
            form.setNamed(new java.lang.Long(request.getParameter("ref_House")));
        }
        form.setNamedBackingList((java.util.List)backingLists.get("named"));

        return mapping.getInputForward();
    }

    protected ActionForward unspecified(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return preload(mapping, actionForm, request, response);
    }

    public ActionForward update(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm) actionForm;

        .update(
            (StringUtils.isBlank(request.getParameter("dateAsString"))) ? null : form.getDate()
            , (StringUtils.isBlank(request.getParameter("specificId"))) ? null : form.getSpecificId()
            , (StringUtils.isBlank(request.getParameter("named"))) ? null : form.getNamed()
        );

        return preload(mapping, actionForm, request, response);
    }

    public ActionForward delete(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.RoomForm) actionForm;

        final java.lang.Long[] selectedRows = form.getSelectedRows();
        if (selectedRows != null && selectedRows.length > 0)
        {
            .delete(selectedRows);
        }

        return preload(mapping, actionForm, request, response);
    }

    private void saveMaxResultsWarning(HttpServletRequest request)
    {
        final HttpSession session = request.getSession();

        ActionMessages messages = (ActionMessages)session.getAttribute(org.apache.struts.Globals.MESSAGE_KEY);
        if (messages == null)
        {
            messages = new ActionMessages();
            session.setAttribute(org.apache.struts.Globals.MESSAGE_KEY, messages);
        }
        messages.add("org.andromda.bpm4struts.warningmessages", new ActionMessage("maximum.results.fetched.warning", "250"));
    }

}
