package org.andromda.cartridges.bpm4struts.tests.finalstates.nohrefnoname;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/Nohrefnoname/Nohrefnoname"
 *        name="nohrefnonameNohrefnonameForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="unknown"
 *        path=".do"
 *    redirect="false"
 *
 */
public final class Nohrefnoname extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _doSomething(mapping, form, request, response);
        request.setAttribute("form", form);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        return mapping.findForward("unknown");
    }

}
