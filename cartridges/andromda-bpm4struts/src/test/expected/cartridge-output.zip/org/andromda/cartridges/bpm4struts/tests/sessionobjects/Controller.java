package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

/**
 * 
 */
public abstract class Controller implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void someOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.sessionobjects.SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    /**
     * Returns the current SessionObject from the session found in the argument request.
     * <p/>
     * In case an object was found in the session but it was not of the correct type, this method
     * will return <code>null</code>.
     * <p/>
     * If there is no session, it will be created; if the session would not contain a session-object
     * the object will be instantiated and subsequently stored in the session.
     */
    protected final org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject getSessionObject(HttpServletRequest request)
    {
        org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject object = null;
        HttpSession session = request.getSession(true);

        Object attribute = session.getAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject.SESSION_KEY);
        if (attribute instanceof org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject)
        {
            object = (org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject)attribute;
        }
        else if (attribute == null)
        {
            object = new org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject ();
            setSessionObject(request, object);
        }

        return object;
    }

    /**
     * Set the argument SessionObject object in the session corresponding with the argument request.
     * In case the session would not exist it will be created.
     */
    protected final void setSessionObject(HttpServletRequest request, org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject object)
    {
        setSessionObject(request, object, true);
    }

    /**
     * Set the argument SessionObject object in the session corresponding with the argument request. Any existing
     * object will be overwritten.
     *
     * @param createSession denotes whether or not the session should be created automatically in case it would
     *                      not yet exist
     */
    protected final void setSessionObject(HttpServletRequest request, org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject object, boolean createSession)
    {
        HttpSession session = request.getSession(createSession);
        if (session != null)
        {
            session.setAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject.SESSION_KEY, object);
        }
    }

    /**
     * Removes the argument SessionObject object from the session corresponding with the argument request.
     * In any of the following cases this method will do nothing:
     * <ul>
     *   <li>No session corresponds to the argument request</li>
     *   <li>No SessionObject object could be found in the request</li>
     *   <li>The object is not of the correct type</li>
     * </ul>
     */
    protected final void removeSessionObject(HttpServletRequest request)
    {
        HttpSession session = request.getSession(false);
        if (session != null)
        {
            Object attribute = session.getAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject.SESSION_KEY);
            if (attribute instanceof org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject)
            {
                session.removeAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.SessionObject.SESSION_KEY);
            }
        }
    }

    /**
     * Stores a warning message in the request, if any other warning messages would exist this one
     * would simply be added.
     */
    protected final void saveWarningMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.warningmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.warningmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }

    /**
     * Stores a success message in the request, if any other success messages would exist this one
     * would simply be added.
     */
    protected final void saveSuccessMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.successmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.successmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }

}
