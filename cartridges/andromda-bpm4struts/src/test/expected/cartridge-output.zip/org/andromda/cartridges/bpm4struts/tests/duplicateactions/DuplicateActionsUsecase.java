package org.andromda.cartridges.bpm4struts.tests.duplicateactions;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/DuplicateActionsUsecase/DuplicateActionsUsecase"
 *        name="duplicateActionsUsecaseDuplicateActionsUsecaseForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="show.something"
 *        path="/org/andromda/cartridges/bpm4struts/tests/duplicateactions/show-something.jsp"
 *    redirect="false"
 *
 */
public final class DuplicateActionsUsecase extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _doSomething(mapping, form, request, response);
        request.setAttribute("form", form);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        return mapping.findForward("show.something");
    }

}
