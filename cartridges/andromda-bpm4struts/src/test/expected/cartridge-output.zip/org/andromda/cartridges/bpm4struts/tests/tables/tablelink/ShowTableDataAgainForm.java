package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgainForm"
 */
public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String second;

    public ShowTableDataAgainForm()
    {
    }

    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    public java.lang.String getSecond()
    {
        return this.second;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("second=");
        buffer.append(String.valueOf(this.getSecond()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.second = null;
    }

}
