package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String tableMultibox;
    private java.lang.String tableTextField;
    private java.lang.String second;

    public ShowTableDataAgainForm()
    {
    }

    public void setTableMultibox(java.lang.String tableMultibox)
    {
        this.tableMultibox = tableMultibox;
    }

    /**
     * 
     */
    public java.lang.String getTableMultibox()
    {
        return this.tableMultibox;
    }
    
    /**
     * Resets the given <code>tableMultibox</code>.
     */
    public void resetTableMultibox()
    {
        tableMultibox = null;
    }

    public void setTableTextField(java.lang.String tableTextField)
    {
        this.tableTextField = tableTextField;
    }

    /**
     * 
     */
    public java.lang.String getTableTextField()
    {
        return this.tableTextField;
    }
    
    /**
     * Resets the given <code>tableTextField</code>.
     */
    public void resetTableTextField()
    {
        tableTextField = null;
    }

    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    
    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        second = null;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("tableMultibox=");
        buffer.append(String.valueOf(this.getTableMultibox()));
        buffer.append(",tableTextField=");
        buffer.append(String.valueOf(this.getTableTextField()));
        buffer.append(",second=");
        buffer.append(String.valueOf(this.getSecond()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableMultibox = null;
        this.tableTextField = null;
        this.second = null;
    }

}
