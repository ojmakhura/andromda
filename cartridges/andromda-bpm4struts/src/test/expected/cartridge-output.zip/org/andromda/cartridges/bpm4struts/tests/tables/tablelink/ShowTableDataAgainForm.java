package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private final static Object[] EMPTY_ARRAY = new Object[0];

    private java.lang.String tableMultibox;
    private Object[] tableMultiboxValueList;
    private Object[] tableMultiboxLabelList;
    private java.lang.String tableTextField;
    private Object[] tableTextFieldValueList;
    private Object[] tableTextFieldLabelList;
    private java.lang.String second;
    private Object[] secondValueList;
    private Object[] secondLabelList;

    public ShowTableDataAgainForm()
    {
    }

    /**
     * Resets the given <code>tableMultibox</code>.
     */
    public void resetTableMultibox()
    {
        this.tableMultibox = null;
    }
    
    public void setTableMultibox(java.lang.String tableMultibox)
    {
        this.tableMultibox = tableMultibox;
    }

    /**
     * 
     */
    public java.lang.String getTableMultibox()
    {
        return this.tableMultibox;
    }
    

    public Object[] getTableMultiboxBackingList()
    {
        Object[] values = this.tableMultiboxValueList;
        Object[] labels = this.tableMultiboxLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableMultiboxValueList()
    {
        return this.tableMultiboxValueList;
    }

    public void setTableMultiboxValueList(Object[] tableMultiboxValueList)
    {
        this.tableMultiboxValueList = tableMultiboxValueList;
    }

    public Object[] getTableMultiboxLabelList()
    {
        return this.tableMultiboxLabelList;
    }

    public void setTableMultiboxLabelList(Object[] tableMultiboxLabelList)
    {
        this.tableMultiboxLabelList = tableMultiboxLabelList;
    }

    /**
     * Resets the given <code>tableTextField</code>.
     */
    public void resetTableTextField()
    {
        this.tableTextField = null;
    }
    
    public void setTableTextField(java.lang.String tableTextField)
    {
        this.tableTextField = tableTextField;
    }

    /**
     * 
     */
    public java.lang.String getTableTextField()
    {
        return this.tableTextField;
    }
    

    public Object[] getTableTextFieldBackingList()
    {
        Object[] values = this.tableTextFieldValueList;
        Object[] labels = this.tableTextFieldLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableTextFieldValueList()
    {
        return this.tableTextFieldValueList;
    }

    public void setTableTextFieldValueList(Object[] tableTextFieldValueList)
    {
        this.tableTextFieldValueList = tableTextFieldValueList;
    }

    public Object[] getTableTextFieldLabelList()
    {
        return this.tableTextFieldLabelList;
    }

    public void setTableTextFieldLabelList(Object[] tableTextFieldLabelList)
    {
        this.tableTextFieldLabelList = tableTextFieldLabelList;
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }
    
    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    

    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("tableMultibox", this.tableMultibox);
        builder.append("tableTextField", this.tableTextField);
        builder.append("second", this.second);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableMultibox = null;
        this.tableTextField = null;
        this.second = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}