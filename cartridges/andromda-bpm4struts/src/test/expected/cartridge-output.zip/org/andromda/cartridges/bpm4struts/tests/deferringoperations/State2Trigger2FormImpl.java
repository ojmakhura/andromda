/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State2Trigger2FormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , Operation2Form
        , Operation3Form
{
    private int decisionTestParam;
    private java.lang.Object[] decisionTestParamValueList;
    private java.lang.Object[] decisionTestParamLabelList;
    private int param4;
    private java.lang.Object[] param4ValueList;
    private java.lang.Object[] param4LabelList;
    private java.lang.String testParam;
    private java.lang.Object[] testParamValueList;
    private java.lang.Object[] testParamLabelList;
    private java.lang.String testParam2;
    private java.lang.Object[] testParam2ValueList;
    private java.lang.Object[] testParam2LabelList;

    public State2Trigger2FormImpl()
    {
    }

    /**
     * Resets the given <code>decisionTestParam</code>.
     */
    public void resetDecisionTestParam()
    {
        this.decisionTestParam = 0;
    }

    public void setDecisionTestParam(int decisionTestParam)
    {
        this.decisionTestParam = decisionTestParam;
    }

    /**
     * 
     */
    public int getDecisionTestParam()
    {
        return this.decisionTestParam;
    }
    
    public Object[] getDecisionTestParamBackingList()
    {
        Object[] values = this.decisionTestParamValueList;
        Object[] labels = this.decisionTestParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDecisionTestParamValueList()
    {
        return this.decisionTestParamValueList;
    }

    public void setDecisionTestParamValueList(Object[] decisionTestParamValueList)
    {
        this.decisionTestParamValueList = decisionTestParamValueList;
    }

    public Object[] getDecisionTestParamLabelList()
    {
        return this.decisionTestParamLabelList;
    }

    public void setDecisionTestParamLabelList(Object[] decisionTestParamLabelList)
    {
        this.decisionTestParamLabelList = decisionTestParamLabelList;
    }

    public void setDecisionTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setDecisionTestParamBackingList requires non-null property arguments");
        }

        this.decisionTestParamValueList = null;
        this.decisionTestParamLabelList = null;

        if (items != null)
        {
            this.decisionTestParamValueList = new java.lang.Object[items.size()];
            this.decisionTestParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.decisionTestParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.decisionTestParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("State2Trigger2FormImpl.setDecisionTestParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>param4</code>.
     */
    public void resetParam4()
    {
        this.param4 = 0;
    }

    public void setParam4(int param4)
    {
        this.param4 = param4;
    }

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }
    
    public Object[] getParam4BackingList()
    {
        Object[] values = this.param4ValueList;
        Object[] labels = this.param4LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getParam4ValueList()
    {
        return this.param4ValueList;
    }

    public void setParam4ValueList(Object[] param4ValueList)
    {
        this.param4ValueList = param4ValueList;
    }

    public Object[] getParam4LabelList()
    {
        return this.param4LabelList;
    }

    public void setParam4LabelList(Object[] param4LabelList)
    {
        this.param4LabelList = param4LabelList;
    }

    public void setParam4BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setParam4BackingList requires non-null property arguments");
        }

        this.param4ValueList = null;
        this.param4LabelList = null;

        if (items != null)
        {
            this.param4ValueList = new java.lang.Object[items.size()];
            this.param4LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.param4ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.param4LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("State2Trigger2FormImpl.setParam4BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        this.testParam = null;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }
    
    public Object[] getTestParamBackingList()
    {
        Object[] values = this.testParamValueList;
        Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    public void setTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setTestParamBackingList requires non-null property arguments");
        }

        this.testParamValueList = null;
        this.testParamLabelList = null;

        if (items != null)
        {
            this.testParamValueList = new java.lang.Object[items.size()];
            this.testParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.testParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.testParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("State2Trigger2FormImpl.setTestParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>testParam2</code>.
     */
    public void resetTestParam2()
    {
        this.testParam2 = null;
    }

    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }
    
    public Object[] getTestParam2BackingList()
    {
        Object[] values = this.testParam2ValueList;
        Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    public void setTestParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setTestParam2BackingList requires non-null property arguments");
        }

        this.testParam2ValueList = null;
        this.testParam2LabelList = null;

        if (items != null)
        {
            this.testParam2ValueList = new java.lang.Object[items.size()];
            this.testParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.testParam2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.testParam2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("State2Trigger2FormImpl.setTestParam2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.testParam2 = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("decisionTestParam", this.decisionTestParam);
        builder.append("param4", this.param4);
        builder.append("testParam", this.testParam);
        builder.append("testParam2", this.testParam2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.decisionTestParam = 0;
        this.decisionTestParamValueList = null;
        this.decisionTestParamLabelList = null;
        this.param4 = 0;
        this.param4ValueList = null;
        this.param4LabelList = null;
        this.testParam = null;
        this.testParamValueList = null;
        this.testParamLabelList = null;
        this.testParam2 = null;
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}