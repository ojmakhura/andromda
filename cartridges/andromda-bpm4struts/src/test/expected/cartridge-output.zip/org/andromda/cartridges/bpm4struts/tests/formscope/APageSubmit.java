/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formscope;

/**
 * 
 */
public final class APageSubmit extends org.apache.struts.action.Action
{
    public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        final org.apache.struts.action.ActionForward forward = mapping.findForward("submit");
        return forward;
    }


    /**
     * Returns true if <strong>NO</strong> errors are present in the session.  This includes default validation
     * errors produced by the struts framework and the exception handler errors caught by the pattern matching
     * exception handler.
     *
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionMessages errors = this.getErrors(request);
        return (errors == null || errors.isEmpty()) && this.getExceptionHandlerErrors(request).isEmpty();
    }

    /**
     * Retrieves the exception handler messages (if any). Creates a new
     * <code>org.apache.struts.action.ActionMessages</code> instance and returns that if one doesn't already exist.
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(javax.servlet.http.HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = null;

        final javax.servlet.http.HttpSession session = request.getSession();
        if (session != null)
        {
            errors = (org.apache.struts.action.ActionMessages)session.getAttribute(org.apache.struts.Globals.MESSAGE_KEY);
            if (errors == null)
            {
                errors = new org.apache.struts.action.ActionMessages();
                session.setAttribute(org.apache.struts.Globals.MESSAGE_KEY, errors);
            }
        }

        return errors;
    }
}
