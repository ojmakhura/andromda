package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingguard;

public interface OperationForm
{
}
