package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/WidgetsActivity/WidgetsActivity"
 *        name="widgetsActivityWidgetsActivityForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="show.widgets"
 *        path="/org/andromda/cartridges/bpm4struts/tests/widgets/show-widgets.jsp"
 *    redirect="false"
 *
 */
public final class WidgetsActivity extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = _preloading(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _preloading(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().preloadSelects(mapping, (WidgetsActivityForm)form, request, response);
        return mapping.findForward("show.widgets");
    }

}
