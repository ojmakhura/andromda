package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import java.io.Serializable;


/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgainActionForm"
 */
public final class ShowTableDataAgainActionForm extends TableLinkActivityForm implements Serializable
{
    public void setAgainSecond(java.lang.String againSecond)
    {
        super.setAgainSecond(againSecond);
    }

}
