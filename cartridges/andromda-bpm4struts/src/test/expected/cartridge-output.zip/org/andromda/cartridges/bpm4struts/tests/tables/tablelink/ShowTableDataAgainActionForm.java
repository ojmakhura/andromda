package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgainActionForm"
 */
public class ShowTableDataAgainActionForm extends ValidatorForm implements Serializable
    
{
    private java.lang.String againSecond;

    public ShowTableDataAgainActionForm()
    {
    }

    public void setAgainSecond(java.lang.String againSecond)
    {
        this.againSecond = againSecond;
    }

    public java.lang.String getAgainSecond()
    {
        return this.againSecond;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("againSecond=");
        buffer.append(String.valueOf(this.getAgainSecond()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.againSecond = null;
    }

}
