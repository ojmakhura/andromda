package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="useCaseSomePageSubmitActionForm"
 */
public class SomePageSubmitActionForm extends ValidatorForm implements Serializable
    
{

    public SomePageSubmitActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
