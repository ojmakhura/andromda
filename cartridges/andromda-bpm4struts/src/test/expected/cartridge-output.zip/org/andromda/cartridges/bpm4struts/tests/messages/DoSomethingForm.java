package org.andromda.cartridges.bpm4struts.tests.messages;

public interface DoSomethingForm
{
}
