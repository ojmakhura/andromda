package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.returntypevoid;

public interface VoidReturnTypeOperationForm
{
}
