package org.andromda.cartridges.bpm4struts.tests.validation;

/**
 * @struts.form
 *      name="validationActivityEnterDataValidateForm"
 */
public class EnterDataValidateForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String requiredTest;
    private java.lang.String emailTest;
    private int intRangeTest;
    private double doubleRangeTest;
    private java.lang.String maxlengthTest;
    private java.lang.String patternTest;
    private java.lang.Float floatWrapperRangeTest;
    private java.lang.Integer intWrapperRangeTest;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.net.URL urlTest;
    private java.lang.String minlengthTest;
    private float floatRangeTest;
    private java.lang.Double doubleWrapperRangeTest;
    private java.lang.String creditcardTest;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");

    public EnterDataValidateForm()
    {
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    /**
     * @struts.validator
     *          type="required"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.required.test"
     *
     */
    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }

    /**
     * @struts.validator
     *          type="email"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.email.test"
     *
     */
    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }

    /**
     * @struts.validator
     *          type="integer"
     *
     * @struts.validator
     *          type="intRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="5"
     *
     * @struts.validator-var
     *          name="max"
     *         value="10"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.int.range.test"
     *
     */
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }

    /**
     * @struts.validator
     *          type="double"
     *
     * @struts.validator
     *          type="doubleRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="321.123"
     *
     * @struts.validator-var
     *          name="max"
     *         value="987.78985"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.double.range.test"
     *
     */
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }

    /**
     * @struts.validator
     *          type="maxlength"
     *     arg1value="${var:maxlength}"
     *
     * @struts.validator-var
     *          name="maxlength"
     *         value="8"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.maxlength.test"
     *
     */
    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }

    /**
     * @struts.validator
     *          type="mask"
     *
     * @struts.validator-var
     *          name="mask"
     *         value="^[a-zA-Z]$"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.pattern.test"
     *
     */
    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }

    /**
     * @struts.validator
     *          type="float"
     *
     * @struts.validator
     *          type="floatRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="23.333"
     *
     * @struts.validator-var
     *          name="max"
     *         value="33.22222"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.float.wrapper.range.test"
     *
     */
    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }

    /**
     * @struts.validator
     *          type="integer"
     *
     * @struts.validator
     *          type="intRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="1000"
     *
     * @struts.validator-var
     *          name="max"
     *         value="2000"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.int.wrapper.range.test"
     *
     */
    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }

    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    /**
     * @struts.validator
     *          type="date"
     *
     * @struts.validator-var
     *          name="datePattern"
     *         value="dd/MMM/yyyy"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.lenient.date.test"
     *
     */
    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length()==0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    public final static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return EnterDataValidateForm.lenientDateTestDateFormatter;
    }

    /**
     * @struts.validator
     *          type="url"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.url.test"
     *
     */
    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }

    /**
     * @struts.validator
     *          type="minlength"
     *     arg1value="${var:minlength}"
     *
     * @struts.validator-var
     *          name="minlength"
     *         value="4"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.minlength.test"
     *
     */
    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }

    /**
     * @struts.validator
     *          type="float"
     *
     * @struts.validator
     *          type="floatRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="1.10"
     *
     * @struts.validator-var
     *          name="max"
     *         value="7.555"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.float.range.test"
     *
     */
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }

    /**
     * @struts.validator
     *          type="double"
     *
     * @struts.validator
     *          type="doubleRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="10001.111111"
     *
     * @struts.validator-var
     *          name="max"
     *         value="2343223.432234324"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.double.wrapper.range.test"
     *
     */
    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }

    /**
     * @struts.validator
     *          type="creditCard"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.creditcard.test"
     *
     */
    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }

    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    /**
     * @struts.validator
     *          type="date"
     *
     * @struts.validator-var
     *          name="datePatternStrict"
     *         value="dd/MM/yyyy"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.strict.date.test"
     *
     */
    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length()==0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    public final static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return EnterDataValidateForm.strictDateTestDateFormatter;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("requiredTest=");
        buffer.append(String.valueOf(this.getRequiredTest()));
        buffer.append(",emailTest=");
        buffer.append(String.valueOf(this.getEmailTest()));
        buffer.append(",intRangeTest=");
        buffer.append(String.valueOf(this.getIntRangeTest()));
        buffer.append(",doubleRangeTest=");
        buffer.append(String.valueOf(this.getDoubleRangeTest()));
        buffer.append(",maxlengthTest=");
        buffer.append(String.valueOf(this.getMaxlengthTest()));
        buffer.append(",patternTest=");
        buffer.append(String.valueOf(this.getPatternTest()));
        buffer.append(",floatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getFloatWrapperRangeTest()));
        buffer.append(",intWrapperRangeTest=");
        buffer.append(String.valueOf(this.getIntWrapperRangeTest()));
        buffer.append(",lenientDateTest=");
        buffer.append(String.valueOf(this.getLenientDateTest()));
        buffer.append(",urlTest=");
        buffer.append(String.valueOf(this.getUrlTest()));
        buffer.append(",minlengthTest=");
        buffer.append(String.valueOf(this.getMinlengthTest()));
        buffer.append(",floatRangeTest=");
        buffer.append(String.valueOf(this.getFloatRangeTest()));
        buffer.append(",doubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getDoubleWrapperRangeTest()));
        buffer.append(",creditcardTest=");
        buffer.append(String.valueOf(this.getCreditcardTest()));
        buffer.append(",strictDateTest=");
        buffer.append(String.valueOf(this.getStrictDateTest()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.requiredTest = null;
        this.emailTest = null;
        this.intRangeTest = 0;
        this.doubleRangeTest = 0;
        this.maxlengthTest = null;
        this.patternTest = null;
        this.floatWrapperRangeTest = null;
        this.intWrapperRangeTest = null;
        this.lenientDateTest = null;
        this.urlTest = null;
        this.minlengthTest = null;
        this.floatRangeTest = 0;
        this.doubleWrapperRangeTest = null;
        this.creditcardTest = null;
        this.strictDateTest = null;
    }

}
