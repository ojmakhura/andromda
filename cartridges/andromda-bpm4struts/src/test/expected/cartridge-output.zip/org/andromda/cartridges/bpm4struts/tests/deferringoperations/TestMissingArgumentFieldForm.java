/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>testMissingArgumentField</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 *  The action deferring to this operation has no form field with
 *  the same name and type.
 * </p>
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#testMissingArgumentField
 */
public interface TestMissingArgumentFieldForm
{
    /**
     * Sets the <code>thisArgumentIsMissingFromTheActionForm</code> field.
     *
     * 
     */
    public void setThisArgumentIsMissingFromTheActionForm(java.lang.String thisArgumentIsMissingFromTheActionForm);

    /**
     * Gets the <code>thisArgumentIsMissingFromTheActionForm</code> field.
     *
     * 
     */
    public java.lang.String getThisArgumentIsMissingFromTheActionForm();
    
    /**
     * Resets the <code>thisArgumentIsMissingFromTheActionForm</code> field.
     */
    public void resetThisArgumentIsMissingFromTheActionForm();

}
