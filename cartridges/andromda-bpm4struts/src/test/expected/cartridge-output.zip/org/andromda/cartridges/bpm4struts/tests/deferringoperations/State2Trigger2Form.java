package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * @struts.form
 *      name="deferringOperationsState2Trigger2Form"
 */
public class State2Trigger2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private int trigger4Param4;
    private java.lang.String trigger4TestParam2;
    private java.lang.String trigger2TestParam;

    public State2Trigger2Form()
    {
    }

    public void setTrigger4Param4(int trigger4Param4)
    {
        this.trigger4Param4 = trigger4Param4;
    }

    public int getTrigger4Param4()
    {
        return this.trigger4Param4;
    }

    public void setTrigger4TestParam2(java.lang.String trigger4TestParam2)
    {
        this.trigger4TestParam2 = trigger4TestParam2;
    }

    public java.lang.String getTrigger4TestParam2()
    {
        return this.trigger4TestParam2;
    }

    public void setTrigger2TestParam(java.lang.String trigger2TestParam)
    {
        this.trigger2TestParam = trigger2TestParam;
    }

    public java.lang.String getTrigger2TestParam()
    {
        return this.trigger2TestParam;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("trigger4Param4=");
        buffer.append(String.valueOf(this.getTrigger4Param4()));
        buffer.append(",trigger4TestParam2=");
        buffer.append(String.valueOf(this.getTrigger4TestParam2()));
        buffer.append(",trigger2TestParam=");
        buffer.append(String.valueOf(this.getTrigger2TestParam()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.trigger4Param4 = 0;
        this.trigger4TestParam2 = null;
        this.trigger2TestParam = null;
    }

}
