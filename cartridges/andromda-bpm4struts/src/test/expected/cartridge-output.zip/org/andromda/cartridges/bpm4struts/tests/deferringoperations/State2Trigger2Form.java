package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * @struts.form
 *      name="deferringOperationsState2Trigger2Form"
 */
public class State2Trigger2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , Operation2Form
        , Operation3Form
{
    private int param4;
    private java.lang.String testParam;
    private java.lang.String testParam2;

    public State2Trigger2Form()
    {
    }

    public void setParam4(int param4)
    {
        this.param4 = param4;
    }

    public int getParam4()
    {
        return this.param4;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
    }

    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("param4=");
        buffer.append(String.valueOf(this.getParam4()));
        buffer.append(",testParam=");
        buffer.append(String.valueOf(this.getTestParam()));
        buffer.append(",testParam2=");
        buffer.append(String.valueOf(this.getTestParam2()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.param4 = 0;
        this.testParam = null;
        this.testParam2 = null;
    }

}
