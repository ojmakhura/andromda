package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/WidgetsActivity/ShowWidgetsSubmit"
 *        name="widgetsActivityShowWidgetsSubmitForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/widgets/show-widgets.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="table.link.activity"
 *        path="/TableLinkActivity/TableLinkActivity.do"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="widgets.activity.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/widgets/show-widgets.jsp"
 *       scope="request"
 *
 */
public final class ShowWidgetsSubmit extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _doSomethingElse(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _doSomethingElse(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("table.link.activity");
    }

}
