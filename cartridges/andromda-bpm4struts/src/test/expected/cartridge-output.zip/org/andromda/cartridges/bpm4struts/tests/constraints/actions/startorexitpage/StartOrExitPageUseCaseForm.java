package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

/**
 * @struts.form
 *      name="startOrExitPageUseCaseStartOrExitPageUseCaseForm"
 */
public class StartOrExitPageUseCaseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public StartOrExitPageUseCaseForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
