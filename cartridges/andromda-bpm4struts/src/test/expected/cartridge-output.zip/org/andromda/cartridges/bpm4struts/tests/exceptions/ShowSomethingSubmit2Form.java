package org.andromda.cartridges.bpm4struts.tests.exceptions;

/**
 * @struts.form
 *      name="exceptionsActivityShowSomethingSubmit2Form"
 */
public class ShowSomethingSubmit2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public ShowSomethingSubmit2Form()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
