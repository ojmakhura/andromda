package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgain2Form"
 */
public class ShowTableDataAgain2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String again2OtherName;

    public ShowTableDataAgain2Form()
    {
    }

    public void setAgain2OtherName(java.lang.String again2OtherName)
    {
        this.again2OtherName = again2OtherName;
    }

    public java.lang.String getAgain2OtherName()
    {
        return this.again2OtherName;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("again2OtherName=");
        buffer.append(String.valueOf(this.getAgain2OtherName()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.again2OtherName = null;
    }

}
