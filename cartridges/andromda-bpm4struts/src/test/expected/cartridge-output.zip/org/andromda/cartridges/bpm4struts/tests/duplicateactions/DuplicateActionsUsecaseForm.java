package org.andromda.cartridges.bpm4struts.tests.duplicateactions;

public class DuplicateActionsUsecaseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String testParam;
    private Object[] testParamValueList;
    private Object[] testParamLabelList;

    public DuplicateActionsUsecaseForm()
    {
    }

    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        this.testParam = null;
    }
    
    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }
    

    public Object[] getTestParamBackingList()
    {
        Object[] values = this.testParamValueList;
        Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("testParam", this.testParam);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.testParam = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}