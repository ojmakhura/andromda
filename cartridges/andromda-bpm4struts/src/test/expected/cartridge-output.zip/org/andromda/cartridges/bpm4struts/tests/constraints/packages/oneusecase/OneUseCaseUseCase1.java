package org.andromda.cartridges.bpm4struts.tests.constraints.packages.oneusecase;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/OneUseCaseUseCase1/OneUseCaseUseCase1"
 *        name="oneUseCaseUseCase1OneUseCaseUseCase1Form"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="one.use.case.use.case1"
 *        path="/OneUseCaseUseCase1/OneUseCaseUseCase1.do"
 *    redirect="false"
 *
 */
public final class OneUseCaseUseCase1 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _nothing(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _nothing(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("one.use.case.use.case1");
    }

}
