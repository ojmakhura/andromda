package org.andromda.cartridges.bpm4struts.tests.interusecase.source;

public class SourceSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private int sourceParam1;
    private java.lang.String sourceParam2;

    public SourceSubmitForm()
    {
    }

    /**
     * Resets the given <code>sourceParam1</code>.
     */
    public void resetSourceParam1()
    {
        this.sourceParam1 = 0;
    }

    public void setSourceParam1(int sourceParam1)
    {
        this.sourceParam1 = sourceParam1;
    }

    /**
     * 
     */
    public int getSourceParam1()
    {
        return this.sourceParam1;
    }

    /**
     * Resets the given <code>sourceParam2</code>.
     */
    public void resetSourceParam2()
    {
        this.sourceParam2 = null;
    }

    public void setSourceParam2(java.lang.String sourceParam2)
    {
        this.sourceParam2 = sourceParam2;
    }

    /**
     * 
     */
    public java.lang.String getSourceParam2()
    {
        return this.sourceParam2;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("sourceParam1=");
        buffer.append(String.valueOf(this.getSourceParam1()));
        buffer.append(",sourceParam2=");
        buffer.append(String.valueOf(this.getSourceParam2()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.sourceParam1 = 0;
        this.sourceParam2 = null;
    }

}
