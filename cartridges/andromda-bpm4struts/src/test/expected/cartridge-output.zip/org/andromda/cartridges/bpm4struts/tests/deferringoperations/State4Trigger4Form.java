package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * @struts.form
 *      name="deferringOperationsState4Trigger4Form"
 */
public class State4Trigger4Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private int trigger2bTestParam2;
    private java.lang.String trigger2bTestParam;
    private java.lang.String pageVariable;
    private int trigger4Param4;
    private java.lang.String trigger4TestParam2;
    private java.lang.String trigger2bParam2a;
    private java.lang.String trigger2TestParam;

    public State4Trigger4Form()
    {
    }

    public void setTrigger2bTestParam2(int trigger2bTestParam2)
    {
        this.trigger2bTestParam2 = trigger2bTestParam2;
    }

    public int getTrigger2bTestParam2()
    {
        return this.trigger2bTestParam2;
    }

    public void setTrigger2bTestParam(java.lang.String trigger2bTestParam)
    {
        this.trigger2bTestParam = trigger2bTestParam;
    }

    public java.lang.String getTrigger2bTestParam()
    {
        return this.trigger2bTestParam;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }

    /**
     * @struts.validator
     *          type="integer"
     *
     * @struts.validator-args
     *  arg0resource="deferring.operations.trigger4.param4"
     *
     */
    public void setTrigger4Param4(int trigger4Param4)
    {
        this.trigger4Param4 = trigger4Param4;
    }

    public int getTrigger4Param4()
    {
        return this.trigger4Param4;
    }

    public void setTrigger4TestParam2(java.lang.String trigger4TestParam2)
    {
        this.trigger4TestParam2 = trigger4TestParam2;
    }

    public java.lang.String getTrigger4TestParam2()
    {
        return this.trigger4TestParam2;
    }

    public void setTrigger2bParam2a(java.lang.String trigger2bParam2a)
    {
        this.trigger2bParam2a = trigger2bParam2a;
    }

    public java.lang.String getTrigger2bParam2a()
    {
        return this.trigger2bParam2a;
    }

    public void setTrigger2TestParam(java.lang.String trigger2TestParam)
    {
        this.trigger2TestParam = trigger2TestParam;
    }

    public java.lang.String getTrigger2TestParam()
    {
        return this.trigger2TestParam;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("trigger2bTestParam2=");
        buffer.append(String.valueOf(this.getTrigger2bTestParam2()));
        buffer.append(",trigger2bTestParam=");
        buffer.append(String.valueOf(this.getTrigger2bTestParam()));
        buffer.append(",pageVariable=");
        buffer.append(String.valueOf(this.getPageVariable()));
        buffer.append(",trigger4Param4=");
        buffer.append(String.valueOf(this.getTrigger4Param4()));
        buffer.append(",trigger4TestParam2=");
        buffer.append(String.valueOf(this.getTrigger4TestParam2()));
        buffer.append(",trigger2bParam2a=");
        buffer.append(String.valueOf(this.getTrigger2bParam2a()));
        buffer.append(",trigger2TestParam=");
        buffer.append(String.valueOf(this.getTrigger2TestParam()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.trigger2bTestParam2 = 0;
        this.trigger2bTestParam = null;
        this.pageVariable = null;
        this.trigger4Param4 = 0;
        this.trigger4TestParam2 = null;
        this.trigger2bParam2a = null;
        this.trigger2TestParam = null;
    }

}
