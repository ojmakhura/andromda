package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State4Trigger4Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , Operation1Form
        , Operation2Form
        , DeferringOperationsForm
        , TestMissingArgumentFieldForm
{
    private int param4;
    private java.lang.String testParam;
    private java.lang.String param2a;
    private java.lang.String pageVariable;
    private java.lang.String testParam2;

    public State4Trigger4Form()
    {
    }

    public void setParam4(int param4)
    {
        this.param4 = param4;
    }

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    public void setParam2a(java.lang.String param2a)
    {
        this.param2a = param2a;
    }

    /**
     * 
     */
    public java.lang.String getParam2a()
    {
        return this.param2a;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    /**
     * 
     */
    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }

    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("param4=");
        buffer.append(String.valueOf(this.getParam4()));
        buffer.append(",testParam=");
        buffer.append(String.valueOf(this.getTestParam()));
        buffer.append(",param2a=");
        buffer.append(String.valueOf(this.getParam2a()));
        buffer.append(",pageVariable=");
        buffer.append(String.valueOf(this.getPageVariable()));
        buffer.append(",testParam2=");
        buffer.append(String.valueOf(this.getTestParam2()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>.
     */
    public void clean()
    {
        this.param4 = 0;
        this.testParam = null;
        this.param2a = null;
        this.pageVariable = null;
        this.testParam2 = null;
    }

}
