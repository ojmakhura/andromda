/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataHyperlinkActionDuplicatingParameterFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;
    private Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    private Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    private java.lang.String first;
    private Object[] firstValueList;
    private Object[] firstLabelList;
    private java.lang.String[] multiboxThing;
    private Object[] multiboxThingValueList;
    private Object[] multiboxThingLabelList;
    private java.lang.String third;
    private Object[] thirdValueList;
    private Object[] thirdLabelList;
    private java.util.Collection tableData;
    private Object[] tableDataValueList;
    private Object[] tableDataLabelList;
    private java.lang.String second;
    private Object[] secondValueList;
    private Object[] secondLabelList;
    private java.lang.String formParam2;
    private Object[] formParam2ValueList;
    private Object[] formParam2LabelList;
    private java.util.Collection tableDataNoExportTypes;
    private Object[] tableDataNoExportTypesValueList;
    private Object[] tableDataNoExportTypesLabelList;
    private java.lang.String two;
    private Object[] twoValueList;
    private Object[] twoLabelList;
    private java.util.Collection tableDataDefaultExportTypes;
    private Object[] tableDataDefaultExportTypesValueList;
    private Object[] tableDataDefaultExportTypesLabelList;
    private int formParam1;
    private Object[] formParam1ValueList;
    private Object[] formParam1LabelList;
    private java.lang.String unknownParameter;
    private Object[] unknownParameterValueList;
    private Object[] unknownParameterLabelList;
    private java.util.Collection tableDataNotSortable;
    private Object[] tableDataNotSortableValueList;
    private Object[] tableDataNotSortableLabelList;
    private java.lang.String fourth;
    private Object[] fourthValueList;
    private Object[] fourthLabelList;

    public ShowTableDataHyperlinkActionDuplicatingParameterFormImpl()
    {
    }

    /**
     * Resets the given <code>thisParameterNameDoesNotExistAsTableColumn</code>.
     */
    public void resetThisParameterNameDoesNotExistAsTableColumn()
    {
        this.thisParameterNameDoesNotExistAsTableColumn = null;
    }
    
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }
    

    public Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList requires non-null property arguments");
        }

        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;

        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.thisParameterNameDoesNotExistAsTableColumnValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>first</code>.
     */
    public void resetFirst()
    {
        this.first = null;
    }
    
    public void setFirst(java.lang.String first)
    {
        this.first = first;
    }

    /**
     * 
     */
    public java.lang.String getFirst()
    {
        return this.first;
    }
    

    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    public void setFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFirstBackingList requires non-null property arguments");
        }

        this.firstValueList = null;
        this.firstLabelList = null;

        if (items != null)
        {
            this.firstValueList = new Object[items.size()];
            this.firstLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.firstValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.firstLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFirstBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiboxThing</code>.
     */
    public void resetMultiboxThing()
    {
        this.multiboxThing = null;
    }
    
    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
    }

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }
    

    public Object[] getMultiboxThingBackingList()
    {
        Object[] values = this.multiboxThingValueList;
        Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    public void setMultiboxThingBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setMultiboxThingBackingList requires non-null property arguments");
        }

        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;

        if (items != null)
        {
            this.multiboxThingValueList = new Object[items.size()];
            this.multiboxThingLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.multiboxThingValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiboxThingLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setMultiboxThingBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>third</code>.
     */
    public void resetThird()
    {
        this.third = null;
    }
    
    public void setThird(java.lang.String third)
    {
        this.third = third;
    }

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }
    

    public Object[] getThirdBackingList()
    {
        Object[] values = this.thirdValueList;
        Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setThirdBackingList requires non-null property arguments");
        }

        this.thirdValueList = null;
        this.thirdLabelList = null;

        if (items != null)
        {
            this.thirdValueList = new Object[items.size()];
            this.thirdLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.thirdValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thirdLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setThirdBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = null;
    }
    
    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl#getTableData
     */
    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    

    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    public void setTableDataBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataBackingList requires non-null property arguments");
        }

        this.tableDataValueList = null;
        this.tableDataLabelList = null;

        if (items != null)
        {
            this.tableDataValueList = new Object[items.size()];
            this.tableDataLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.tableDataValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }
    
    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    

    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setSecondBackingList requires non-null property arguments");
        }

        this.secondValueList = null;
        this.secondLabelList = null;

        if (items != null)
        {
            this.secondValueList = new Object[items.size()];
            this.secondLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.secondValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.secondLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setSecondBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>formParam2</code>.
     */
    public void resetFormParam2()
    {
        this.formParam2 = null;
    }
    
    public void setFormParam2(java.lang.String formParam2)
    {
        this.formParam2 = formParam2;
    }

    /**
     * 
     */
    public java.lang.String getFormParam2()
    {
        return this.formParam2;
    }
    

    public Object[] getFormParam2BackingList()
    {
        Object[] values = this.formParam2ValueList;
        Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    public void setFormParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFormParam2BackingList requires non-null property arguments");
        }

        this.formParam2ValueList = null;
        this.formParam2LabelList = null;

        if (items != null)
        {
            this.formParam2ValueList = new Object[items.size()];
            this.formParam2LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.formParam2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFormParam2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataNoExportTypes</code>.
     */
    public void resetTableDataNoExportTypes()
    {
        this.tableDataNoExportTypes = null;
    }
    
    public void setTableDataNoExportTypes(java.util.Collection tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    public void setTableDataNoExportTypesAsArray(Object[] tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = (tableDataNoExportTypes == null) ? null : java.util.Arrays.asList(tableDataNoExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl#getTableDataNoExportTypes
     */
    public Object[] getTableDataNoExportTypesAsArray()
    {
        return (tableDataNoExportTypes == null) ? null : tableDataNoExportTypes.toArray();
    }
    

    public Object[] getTableDataNoExportTypesBackingList()
    {
        Object[] values = this.tableDataNoExportTypesValueList;
        Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataNoExportTypesBackingList requires non-null property arguments");
        }

        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;

        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new Object[items.size()];
            this.tableDataNoExportTypesLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.tableDataNoExportTypesValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNoExportTypesLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataNoExportTypesBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>two</code>.
     */
    public void resetTwo()
    {
        this.two = null;
    }
    
    public void setTwo(java.lang.String two)
    {
        this.two = two;
    }

    /**
     * 
     */
    public java.lang.String getTwo()
    {
        return this.two;
    }
    

    public Object[] getTwoBackingList()
    {
        Object[] values = this.twoValueList;
        Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    public void setTwoBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTwoBackingList requires non-null property arguments");
        }

        this.twoValueList = null;
        this.twoLabelList = null;

        if (items != null)
        {
            this.twoValueList = new Object[items.size()];
            this.twoLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.twoValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.twoLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTwoBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataDefaultExportTypes</code>.
     */
    public void resetTableDataDefaultExportTypes()
    {
        this.tableDataDefaultExportTypes = null;
    }
    
    public void setTableDataDefaultExportTypes(java.util.Collection tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    public void setTableDataDefaultExportTypesAsArray(Object[] tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = (tableDataDefaultExportTypes == null) ? null : java.util.Arrays.asList(tableDataDefaultExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl#getTableDataDefaultExportTypes
     */
    public Object[] getTableDataDefaultExportTypesAsArray()
    {
        return (tableDataDefaultExportTypes == null) ? null : tableDataDefaultExportTypes.toArray();
    }
    

    public Object[] getTableDataDefaultExportTypesBackingList()
    {
        Object[] values = this.tableDataDefaultExportTypesValueList;
        Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataDefaultExportTypesBackingList requires non-null property arguments");
        }

        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;

        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.tableDataDefaultExportTypesValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataDefaultExportTypesLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataDefaultExportTypesBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>formParam1</code>.
     */
    public void resetFormParam1()
    {
        this.formParam1 = 0;
    }
    
    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
    }

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }
    

    public Object[] getFormParam1BackingList()
    {
        Object[] values = this.formParam1ValueList;
        Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    public void setFormParam1BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFormParam1BackingList requires non-null property arguments");
        }

        this.formParam1ValueList = null;
        this.formParam1LabelList = null;

        if (items != null)
        {
            this.formParam1ValueList = new Object[items.size()];
            this.formParam1LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.formParam1ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam1LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFormParam1BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>unknownParameter</code>.
     */
    public void resetUnknownParameter()
    {
        this.unknownParameter = null;
    }
    
    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
    }

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }
    

    public Object[] getUnknownParameterBackingList()
    {
        Object[] values = this.unknownParameterValueList;
        Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    public void setUnknownParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setUnknownParameterBackingList requires non-null property arguments");
        }

        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;

        if (items != null)
        {
            this.unknownParameterValueList = new Object[items.size()];
            this.unknownParameterLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.unknownParameterValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.unknownParameterLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setUnknownParameterBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataNotSortable</code>.
     */
    public void resetTableDataNotSortable()
    {
        this.tableDataNotSortable = null;
    }
    
    public void setTableDataNotSortable(java.util.Collection tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }

    public void setTableDataNotSortableAsArray(Object[] tableDataNotSortable)
    {
        this.tableDataNotSortable = (tableDataNotSortable == null) ? null : java.util.Arrays.asList(tableDataNotSortable);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl#getTableDataNotSortable
     */
    public Object[] getTableDataNotSortableAsArray()
    {
        return (tableDataNotSortable == null) ? null : tableDataNotSortable.toArray();
    }
    

    public Object[] getTableDataNotSortableBackingList()
    {
        Object[] values = this.tableDataNotSortableValueList;
        Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataNotSortableBackingList requires non-null property arguments");
        }

        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;

        if (items != null)
        {
            this.tableDataNotSortableValueList = new Object[items.size()];
            this.tableDataNotSortableLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.tableDataNotSortableValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNotSortableLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setTableDataNotSortableBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>fourth</code>.
     */
    public void resetFourth()
    {
        this.fourth = null;
    }
    
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
    }

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }
    

    public Object[] getFourthBackingList()
    {
        Object[] values = this.fourthValueList;
        Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFourthBackingList requires non-null property arguments");
        }

        this.fourthValueList = null;
        this.fourthLabelList = null;

        if (items != null)
        {
            this.fourthValueList = new Object[items.size()];
            this.fourthLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.fourthValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fourthLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ShowTableDataHyperlinkActionDuplicatingParameterFormImpl.setFourthBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.multiboxThing = null;
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("thisParameterNameDoesNotExistAsTableColumn", this.thisParameterNameDoesNotExistAsTableColumn);
        builder.append("first", this.first);
        builder.append("multiboxThing", this.multiboxThing);
        builder.append("third", this.third);
        builder.append("tableData", this.tableData);
        builder.append("second", this.second);
        builder.append("formParam2", this.formParam2);
        builder.append("tableDataNoExportTypes", this.tableDataNoExportTypes);
        builder.append("two", this.two);
        builder.append("tableDataDefaultExportTypes", this.tableDataDefaultExportTypes);
        builder.append("formParam1", this.formParam1);
        builder.append("unknownParameter", this.unknownParameter);
        builder.append("tableDataNotSortable", this.tableDataNotSortable);
        builder.append("fourth", this.fourth);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.thisParameterNameDoesNotExistAsTableColumn = null;
        this.first = null;
        this.multiboxThing = null;
        this.third = null;
        this.tableData = null;
        this.second = null;
        this.formParam2 = null;
        this.tableDataNoExportTypes = null;
        this.two = null;
        this.tableDataDefaultExportTypes = null;
        this.formParam1 = 0;
        this.unknownParameter = null;
        this.tableDataNotSortable = null;
        this.fourth = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}