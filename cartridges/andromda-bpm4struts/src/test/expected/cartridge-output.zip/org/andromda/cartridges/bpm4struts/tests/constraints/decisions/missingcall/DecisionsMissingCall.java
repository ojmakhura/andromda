/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingcall;

/**
 * 
 */
public final class DecisionsMissingCall extends org.apache.struts.action.Action
{
    public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        final org.apache.struts.action.ActionForward forward = _something(mapping, form, request, response);
        if (this.errorsNotPresent(request))
        {
            request.getSession().setAttribute("form", form);
        }
        else
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward _something(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        org.apache.struts.action.ActionForward forward = null;
        forward = __${transition.operationCall.name}(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward __$controllerMethodName(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        final String value = String.valueOf(ControllerFactory.getControllerInstance().${controllerMethodName}(mapping, (DecisionsMissingCallFormImpl)form, request, response));

        if (value.equals("someGuard"))
        {
            return _something(mapping, form, request, response);
        }
        if (value.equals("anotherGuard"))
        {
            return _something(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _something(mapping, form, request, response);
    }


    /**
     * Returns true if <strong>NO</strong> errors are present in the session.  This includes default validation
     * errors produced by the struts framework and the exception handler errors caught by the pattern matching
     * exception handler.
     *
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionMessages errors = this.getErrors(request);
        return (errors == null || errors.isEmpty()) && this.getExceptionHandlerErrors(request).isEmpty();
    }

    /**
     * Retrieves the exception handler messages (if any). Creates a new
     * <code>org.apache.struts.action.ActionMessages</code> instance and returns that if one doesn't already exist.
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(javax.servlet.http.HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = null;

        final javax.servlet.http.HttpSession session = request.getSession();
        if (session != null)
        {
            errors = (org.apache.struts.action.ActionMessages)session.getAttribute(org.apache.struts.Globals.MESSAGE_KEY);
            if (errors == null)
            {
                errors = new org.apache.struts.action.ActionMessages();
                session.setAttribute(org.apache.struts.Globals.MESSAGE_KEY, errors);
            }
        }

        return errors;
    }
}
