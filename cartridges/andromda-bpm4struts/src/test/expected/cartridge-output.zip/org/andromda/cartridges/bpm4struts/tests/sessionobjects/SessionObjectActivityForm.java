package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

/**
 * @struts.form
 *      name="sessionObjectActivitySessionObjectActivityForm"
 */
public class SessionObjectActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public SessionObjectActivityForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
