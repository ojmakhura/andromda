package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void preloadSelects(ActionMapping mapping, PreloadSelectsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setSubmitRadioButtonsTest("submitRadioButtonsTest-test");
        form.setSubmitRadioButtonsTest2("submitRadioButtonsTest2-test");
        form.setSubmitTextAreaTest("submitTextAreaTest-test");
        form.setSubmitPasswordFieldTest("submitPasswordFieldTest-test");
        form.setSubmitCheckboxTest(false);
        form.setSubmitHiddenTest("submitHiddenTest-test");
        form.setSubmitRadioButtonsTest3("submitRadioButtonsTest3-test");
        form.setSubmitTextFieldTest2("submitTextFieldTest2-test");
        form.setSubmitSelectTest("submitSelectTest-test");
        form.setSubmitTextFieldTest("submitTextFieldTest-test");
    }











}
