package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void preloadSelects(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.widgets.PreloadSelectsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

}
