package org.andromda.cartridges.bpm4struts.tests.hyperlinkactions;

public class HyperlinkactionsForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String someParameter;

    public HyperlinkactionsForm()
    {
    }

    /**
     * Resets the given <code>someParameter</code>.
     */
    public void resetSomeParameter()
    {
        this.someParameter = null;
    }

    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
    }

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("someParameter=");
        buffer.append(String.valueOf(this.getSomeParameter()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.someParameter = null;
    }

}
