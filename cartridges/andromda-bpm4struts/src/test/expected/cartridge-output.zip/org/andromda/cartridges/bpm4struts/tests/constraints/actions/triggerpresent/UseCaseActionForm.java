package org.andromda.cartridges.bpm4struts.tests.constraints.actions.triggerpresent;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="useCaseUseCaseActionForm"
 */
public class UseCaseActionForm extends ValidatorForm implements Serializable
    
{

    public UseCaseActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
