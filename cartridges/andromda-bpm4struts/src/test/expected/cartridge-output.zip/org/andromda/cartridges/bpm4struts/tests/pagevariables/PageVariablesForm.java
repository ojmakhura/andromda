package org.andromda.cartridges.bpm4struts.tests.pagevariables;

public class PageVariablesForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String a;
    private java.util.Date c;
    private final static java.text.DateFormat cDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private int b;

    public PageVariablesForm()
    {
        cDateFormatter.setLenient(true);
    }

    /**
     * Resets the given <code>a</code>.
     */
    public void resetA()
    {
        this.a = null;
    }

    public void setA(java.lang.String a)
    {
        this.a = a;
    }

    /**
     * 
     */
    public java.lang.String getA()
    {
        return this.a;
    }

    /**
     * Resets the given <code>c</code>.
     */
    public void resetC()
    {
        this.c = null;
    }

    public void setCAsDate(java.util.Date c)
    {
        this.c = c;
    }

    /**
     * Returns the Date instance representing the <code>c</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getC
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getCDateFormatter
     */
    public java.util.Date getCAsDate()
    {
        return this.c;
    }

    public void setC(java.lang.String c)
    {
        if (c == null || c.trim().length()==0)
        {
            this.c = null;
        }
        else
        {
            try
            {
                this.c = cDateFormatter.parse(c);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getCAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getCDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getCAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getCDateFormatter
     */
    public java.lang.String getC()
    {
        return (c == null) ? null : cDateFormatter.format(c);
    }

    /**
     * Returns the date formatter used for the <code>c</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getC
     * @see org.andromda.cartridges.bpm4struts.tests.pagevariables.PageVariablesForm#getCAsDate
     */
    public final static java.text.DateFormat getCDateFormatter()
    {
        return PageVariablesForm.cDateFormatter;
    }


    /**
     * Resets the given <code>b</code>.
     */
    public void resetB()
    {
        this.b = 0;
    }

    public void setB(int b)
    {
        this.b = b;
    }

    /**
     * 
     */
    public int getB()
    {
        return this.b;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("a=");
        buffer.append(String.valueOf(this.getA()));
        buffer.append(",c=");
        buffer.append(String.valueOf(this.getC()));
        buffer.append(",b=");
        buffer.append(String.valueOf(this.getB()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.a = null;
        this.c = null;
        this.b = 0;
    }

}
