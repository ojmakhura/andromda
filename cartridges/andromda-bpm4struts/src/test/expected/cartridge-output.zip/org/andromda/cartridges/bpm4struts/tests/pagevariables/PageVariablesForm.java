package org.andromda.cartridges.bpm4struts.tests.pagevariables;

/**
 * @struts.form
 *      name="pageVariablesPageVariablesForm"
 */
public class PageVariablesForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public PageVariablesForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
