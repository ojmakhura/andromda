package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="noTableLinkActivityNoTableLinkActivityActionForm"
 */
public class NoTableLinkActivityActionForm extends ValidatorForm implements Serializable
    , ControllerLoadTableData
{
    private java.util.Collection tableData;

    public NoTableLinkActivityActionForm()
    {
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("tableData=");
        buffer.append(toString(this.getTableData()));

        return buffer.append("]").toString();
    }

    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        else
        {
            final StringBuffer buffer = new StringBuffer("[");
            String prefix = "";
            for (int i=0; i<objects.length; i++)
            {
                buffer.append(prefix);
                buffer.append(objects[i]);
                prefix = ",";
            }
            return buffer.append("]").toString();
        }
    }

    public void clean()
    {
        this.tableData = null;
    }

}
