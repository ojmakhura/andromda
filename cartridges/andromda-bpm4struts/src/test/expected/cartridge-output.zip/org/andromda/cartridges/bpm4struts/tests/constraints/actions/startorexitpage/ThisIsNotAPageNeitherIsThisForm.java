package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

/**
 * @struts.form
 *      name="startOrExitPageUseCaseThisIsNotAPageNeitherIsThisForm"
 */
public class ThisIsNotAPageNeitherIsThisForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public ThisIsNotAPageNeitherIsThisForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
