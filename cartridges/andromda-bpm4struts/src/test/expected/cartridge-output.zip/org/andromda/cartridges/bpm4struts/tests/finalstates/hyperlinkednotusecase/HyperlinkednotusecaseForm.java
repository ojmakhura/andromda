package org.andromda.cartridges.bpm4struts.tests.finalstates.hyperlinkednotusecase;

/**
 * @struts.form
 *      name="hyperlinkednotusecaseHyperlinkednotusecaseForm"
 */
public class HyperlinkednotusecaseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public HyperlinkednotusecaseForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
