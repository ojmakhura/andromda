package org.andromda.cartridges.bpm4struts.tests.duplicateactions;

/**
 * @struts.form
 *      name="duplicateActionsUsecaseShowSomethingSendForm"
 */
public class ShowSomethingSendForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String submitTestParam;

    public ShowSomethingSendForm()
    {
    }

    public void setSubmitTestParam(java.lang.String submitTestParam)
    {
        this.submitTestParam = submitTestParam;
    }

    public java.lang.String getSubmitTestParam()
    {
        return this.submitTestParam;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("submitTestParam=");
        buffer.append(String.valueOf(this.getSubmitTestParam()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.submitTestParam = null;
    }

}
