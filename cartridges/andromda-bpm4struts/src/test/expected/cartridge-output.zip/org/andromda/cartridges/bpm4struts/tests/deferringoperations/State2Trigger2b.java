package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/DeferringOperations/State2Trigger2b"
 *        name="deferringOperationsState2Trigger2bForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *    validate="true"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="state2"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="deferring.operations.state2.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *       scope="request"
 *
 */
public final class State2Trigger2b extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = state1(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward state1(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().operation1(mapping, (State2Trigger2bForm)form, request, response);
        ControllerFactory.getControllerInstance().operation2(mapping, (State2Trigger2bForm)form, request, response);
        return mapping.findForward("state2");
    }

}
