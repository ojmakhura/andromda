package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State2Trigger2bForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , Operation1Form
        , Operation2Form
{
    private java.lang.String testParam;
    private java.lang.String param2a;
    private java.lang.String pageVariable;
    private int testParam2;

    public State2Trigger2bForm()
    {
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }
    
    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        testParam = null;
    }

    public void setParam2a(java.lang.String param2a)
    {
        this.param2a = param2a;
    }

    /**
     * 
     */
    public java.lang.String getParam2a()
    {
        return this.param2a;
    }
    
    /**
     * Resets the given <code>param2a</code>.
     */
    public void resetParam2a()
    {
        param2a = null;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    /**
     * 
     */
    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }
    
    /**
     * Resets the given <code>pageVariable</code>.
     */
    public void resetPageVariable()
    {
        pageVariable = null;
    }

    public void setTestParam2(int testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public int getTestParam2()
    {
        return this.testParam2;
    }
    
    /**
     * Resets the given <code>testParam2</code>.
     */
    public void resetTestParam2()
    {
        testParam2 = 0;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("testParam=");
        buffer.append(String.valueOf(this.getTestParam()));
        buffer.append(",param2a=");
        buffer.append(String.valueOf(this.getParam2a()));
        buffer.append(",pageVariable=");
        buffer.append(String.valueOf(this.getPageVariable()));
        buffer.append(",testParam2=");
        buffer.append(String.valueOf(this.getTestParam2()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.testParam = null;
        this.param2a = null;
        this.pageVariable = null;
        this.testParam2 = 0;
    }

}
