/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataNullForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String first;
    private Object[] firstValueList;
    private Object[] firstLabelList;

    public ShowTableDataNullForm()
    {
    }

    /**
     * Resets the given <code>first</code>.
     */
    public void resetFirst()
    {
        this.first = null;
    }
    
    public void setFirst(java.lang.String first)
    {
        this.first = first;
    }

    /**
     * 
     */
    public java.lang.String getFirst()
    {
        return this.first;
    }
    

    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("first", this.first);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.first = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}