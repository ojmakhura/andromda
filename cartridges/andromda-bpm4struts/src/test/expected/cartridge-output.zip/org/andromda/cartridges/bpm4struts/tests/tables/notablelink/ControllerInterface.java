package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 */
public interface ControllerInterface
{
    /**
     * 
     * <p/>
     * This method does not receive any parameters through the form bean.
     */
    public void loadTableData(ActionMapping mapping, NoTableLinkActivityForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

}

