package org.andromda.cartridges.bpm4struts.tests.constraints.actions.triggerpresent;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/TriggerPresentUseCase/SomePageDoSomethingElse"
 *        name="triggerPresentUseCaseSomePageDoSomethingElseForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/triggerpresent/some-page.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="some.page"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/triggerpresent/some-page.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="trigger.present.use.case.some.page.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/triggerpresent/some-page.jsp"
 *       scope="request"
 *
 */
public final class SomePageDoSomethingElse extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = doSomethingElse(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward doSomethingElse(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return doSomething(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("some.page");
    }

}
