package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

/**
 * 
 */
public abstract class Controller implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void preloadSelects(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.widgets.PreloadSelectsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    /**
     * Stores a warning message in the request, if any other warning messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     * @arguments any arguments used within the message
     */
    protected final void saveWarningMessage(HttpServletRequest request, String message, String[] arguments)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.warningmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.warningmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message, arguments));
    }
    
    /**
     * Stores a warning message in the request, if any other warning messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     */
    protected final void saveWarningMessage(HttpServletRequest request, String message)
    {
        this.saveWarningMessage(request, message, null);
    }

    /**
     * Stores a success message in the request, if any other success messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     * @arguments any arguments used within the message
     */
    protected final void saveSuccessMessage(HttpServletRequest request, String message, String[] arguments)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.successmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.successmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message, arguments));
    }
    
    /**
     * Stores a success message in the request, if any other success messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     */
    protected final void saveSuccessMessage(HttpServletRequest request, String message)
    {
        this.saveSuccessMessage(request, message, null);
    }
    
    /**
     * Stores a error message in the request, if any other error messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     * @arguments any arguments used within the message
     */
    protected final void saveErrorMessage(HttpServletRequest request, String message, String[] arguments)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.errormessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message, arguments));
    }
    
    /**
     * Stores a error message in the request, if any other error messages exist, this one
     * is simply added.
     *
     * @param request the request to which the messages will be saved/retrieved.
     */
    protected final void saveErrorMessage(HttpServletRequest request, String message)
    {
        this.saveErrorMessage(request, message, null);
    }

}
