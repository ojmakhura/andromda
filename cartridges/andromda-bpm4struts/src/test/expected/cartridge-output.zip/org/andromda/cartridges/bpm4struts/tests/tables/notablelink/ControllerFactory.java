package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

public class ControllerFactory
{
    private final static Controller INSTANCE = new Controller();

    public final static ControllerInterface getControllerInstance()
    {
        return INSTANCE;
    }
}
