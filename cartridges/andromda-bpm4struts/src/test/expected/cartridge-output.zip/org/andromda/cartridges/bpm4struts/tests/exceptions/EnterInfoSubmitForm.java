package org.andromda.cartridges.bpm4struts.tests.exceptions;

/**
 * @struts.form
 *      name="exceptionsActivityEnterInfoSubmitForm"
 */
public class EnterInfoSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public EnterInfoSubmitForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
