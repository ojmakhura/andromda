package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/TableLinkActivity/TableLinkActivity"
 *        name="tableLinkActivityTableLinkActivityForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="show.table.data"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/tablelink/show-table-data.jsp"
 *    redirect="false"
 *
 */
public final class TableLinkActivity extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _loadTableData(mapping, form, request, response);
        request.setAttribute("form", form);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _loadTableData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().loadTableData(mapping, (TableLinkActivityForm)form, request, response);
        request.setAttribute("form", form);
        return mapping.findForward("show.table.data");
    }

}
