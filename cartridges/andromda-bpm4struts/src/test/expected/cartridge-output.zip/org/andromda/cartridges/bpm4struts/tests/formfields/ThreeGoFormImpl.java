/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formfields;

public class ThreeGoFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String title;
    private Object[] titleValueList;
    private Object[] titleLabelList;
    private org.apache.struts.upload.FormFile file = null;
    private Object[] fileValueList;
    private Object[] fileLabelList;
    private java.lang.String hasCustomValidator;
    private Object[] hasCustomValidatorValueList;
    private Object[] hasCustomValidatorLabelList;
    private java.lang.String multiFormat;
    private Object[] multiFormatValueList;
    private Object[] multiFormatLabelList;
    private java.util.Date date;
    private final static java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] dateValueList;
    private Object[] dateLabelList;
    private boolean bool;
    private Object[] boolValueList;
    private Object[] boolLabelList;
    private java.util.Set setClass;
    private Object[] setClassValueList;
    private Object[] setClassLabelList;
    private java.lang.String selectable;
    private Object[] selectableValueList;
    private Object[] selectableLabelList;
    private java.lang.Boolean booleanClass;
    private Object[] booleanClassValueList;
    private Object[] booleanClassLabelList;
    private java.lang.String text;
    private Object[] textValueList;
    private Object[] textLabelList;
    private java.util.Map mapClass = new java.util.HashMap();
    private Object[] mapClassValueList;
    private Object[] mapClassLabelList;
    private java.util.Collection multiSelect;
    private Object[] multiSelectValueList;
    private Object[] multiSelectLabelList;
    private java.util.Date dateWithoutCalendar;
    private final static java.text.DateFormat dateWithoutCalendarDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] dateWithoutCalendarValueList;
    private Object[] dateWithoutCalendarLabelList;
    private java.util.Date dateWithTime;
    private final static java.text.DateFormat dateWithTimeDateFormatter = new java.text.SimpleDateFormat("dddd/MM/yyyy HH:mm:ss");
    private Object[] dateWithTimeValueList;
    private Object[] dateWithTimeLabelList;
    private java.lang.Float floatClass;
    private Object[] floatClassValueList;
    private Object[] floatClassLabelList;
    private java.util.Collection collection;
    private Object[] collectionValueList;
    private Object[] collectionLabelList;
    private java.lang.Integer integerClass;
    private Object[] integerClassValueList;
    private Object[] integerClassLabelList;
    private int number;
    private Object[] numberValueList;
    private Object[] numberLabelList;

    public ThreeGoFormImpl()
    {
        dateDateFormatter.setLenient(true);
        dateWithoutCalendarDateFormatter.setLenient(true);
        dateWithTimeDateFormatter.setLenient(true);
    }

    /**
     * Resets the given <code>title</code>.
     */
    public void resetTitle()
    {
        this.title = null;
    }
    
    public void setTitle(java.lang.String title)
    {
        this.title = title;
    }

    /**
     * <p>
     *  should not conflict with the use-cases title property in the
     *  resource bundle
     * </p>
     */
    public java.lang.String getTitle()
    {
        return this.title;
    }
    

    public Object[] getTitleBackingList()
    {
        Object[] values = this.titleValueList;
        Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * title property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the title backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setTitleBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setTitleBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setTitleBackingList requires non-null property arguments");
        }

        this.titleValueList = null;
        this.titleLabelList = null;

        if (items != null)
        {
            this.titleValueList = new Object[items.size()];
            this.titleLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.titleValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.titleLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setTitleBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>file</code>.
     */
    public void resetFile()
    {
        this.file = null;
    }
    
    public void setFile(org.apache.struts.upload.FormFile file)
    {
        this.file = file;
    }

    /**
     * 
     */
    public org.apache.struts.upload.FormFile getFile()
    {
        return this.file;
    }

    public Object[] getFileBackingList()
    {
        Object[] values = this.fileValueList;
        Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * file property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the file backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setFileBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setFileBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setFileBackingList requires non-null property arguments");
        }

        this.fileValueList = null;
        this.fileLabelList = null;

        if (items != null)
        {
            this.fileValueList = new Object[items.size()];
            this.fileLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.fileValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fileLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setFileBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hasCustomValidator</code>.
     */
    public void resetHasCustomValidator()
    {
        this.hasCustomValidator = null;
    }
    
    public void setHasCustomValidator(java.lang.String hasCustomValidator)
    {
        this.hasCustomValidator = hasCustomValidator;
    }

    /**
     * 
     */
    public java.lang.String getHasCustomValidator()
    {
        return this.hasCustomValidator;
    }
    

    public Object[] getHasCustomValidatorBackingList()
    {
        Object[] values = this.hasCustomValidatorValueList;
        Object[] labels = this.hasCustomValidatorLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getHasCustomValidatorValueList()
    {
        return this.hasCustomValidatorValueList;
    }

    public void setHasCustomValidatorValueList(Object[] hasCustomValidatorValueList)
    {
        this.hasCustomValidatorValueList = hasCustomValidatorValueList;
    }

    public Object[] getHasCustomValidatorLabelList()
    {
        return this.hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorLabelList(Object[] hasCustomValidatorLabelList)
    {
        this.hasCustomValidatorLabelList = hasCustomValidatorLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * hasCustomValidator property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the hasCustomValidator backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setHasCustomValidatorBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setHasCustomValidatorBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setHasCustomValidatorBackingList requires non-null property arguments");
        }

        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;

        if (items != null)
        {
            this.hasCustomValidatorValueList = new Object[items.size()];
            this.hasCustomValidatorLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.hasCustomValidatorValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hasCustomValidatorLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setHasCustomValidatorBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiFormat</code>.
     */
    public void resetMultiFormat()
    {
        this.multiFormat = null;
    }
    
    public void setMultiFormat(java.lang.String multiFormat)
    {
        this.multiFormat = multiFormat;
    }

    /**
     * 
     */
    public java.lang.String getMultiFormat()
    {
        return this.multiFormat;
    }
    

    public Object[] getMultiFormatBackingList()
    {
        Object[] values = this.multiFormatValueList;
        Object[] labels = this.multiFormatLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiFormatValueList()
    {
        return this.multiFormatValueList;
    }

    public void setMultiFormatValueList(Object[] multiFormatValueList)
    {
        this.multiFormatValueList = multiFormatValueList;
    }

    public Object[] getMultiFormatLabelList()
    {
        return this.multiFormatLabelList;
    }

    public void setMultiFormatLabelList(Object[] multiFormatLabelList)
    {
        this.multiFormatLabelList = multiFormatLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * multiFormat property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the multiFormat backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setMultiFormatBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setMultiFormatBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setMultiFormatBackingList requires non-null property arguments");
        }

        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;

        if (items != null)
        {
            this.multiFormatValueList = new Object[items.size()];
            this.multiFormatLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.multiFormatValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiFormatLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setMultiFormatBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>date</code>.
     */
    public void resetDate()
    {
        this.date = null;
    }
    
    public void setDateAsDate(java.util.Date date)
    {
        this.date = date;
    }

    /**
     * Returns the Date instance representing the <code>date</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateDateFormatter
     */
    public java.util.Date getDateAsDate()
    {
        return this.date;
    }

    public void setDate(java.lang.String date)
    {
        if (date == null || date.trim().length()==0)
        {
            this.date = null;
        }
        else
        {
            try
            {
                this.date = dateDateFormatter.parse(date);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.date = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateDateFormatter
     */
    public java.lang.String getDate()
    {
        return (date == null) ? null : dateDateFormatter.format(date);
    }

    /**
     * Returns the date formatter used for the <code>date</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateAsDate
     */
    public final static java.text.DateFormat getDateDateFormatter()
    {
        return ThreeGoFormImpl.dateDateFormatter;
    }


    public Object[] getDateBackingList()
    {
        Object[] values = this.dateValueList;
        Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * date property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the date backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDateBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDateBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setDateBackingList requires non-null property arguments");
        }

        this.dateValueList = null;
        this.dateLabelList = null;

        if (items != null)
        {
            this.dateValueList = new Object[items.size()];
            this.dateLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.dateValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setDateBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>bool</code>.
     */
    public void resetBool()
    {
        this.bool = false;
    }
    
    public void setBool(boolean bool)
    {
        this.bool = bool;
    }

    /**
     * 
     */
    public boolean isBool()
    {
        return this.bool;
    }
    

    public Object[] getBoolBackingList()
    {
        Object[] values = this.boolValueList;
        Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * bool property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the bool backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setBoolBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setBoolBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setBoolBackingList requires non-null property arguments");
        }

        this.boolValueList = null;
        this.boolLabelList = null;

        if (items != null)
        {
            this.boolValueList = new Object[items.size()];
            this.boolLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.boolValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.boolLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setBoolBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>setClass</code>.
     */
    public void resetSetClass()
    {
        this.setClass = null;
    }
    
    public void setSetClass(java.util.Set setClass)
    {
        this.setClass = setClass;
    }

    /**
     * 
     */
    public java.util.Set getSetClass()
    {
        return this.setClass;
    }

    public void setSetClassAsArray(Object[] setClass)
    {
        this.setClass = (setClass == null) ? null : java.util.Arrays.asList(setClass);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getSetClass
     */
    public Object[] getSetClassAsArray()
    {
        return (setClass == null) ? null : setClass.toArray();
    }
    

    public Object[] getSetClassBackingList()
    {
        Object[] values = this.setClassValueList;
        Object[] labels = this.setClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSetClassValueList()
    {
        return this.setClassValueList;
    }

    public void setSetClassValueList(Object[] setClassValueList)
    {
        this.setClassValueList = setClassValueList;
    }

    public Object[] getSetClassLabelList()
    {
        return this.setClassLabelList;
    }

    public void setSetClassLabelList(Object[] setClassLabelList)
    {
        this.setClassLabelList = setClassLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * setClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the setClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSetClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setSetClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setSetClassBackingList requires non-null property arguments");
        }

        this.setClassValueList = null;
        this.setClassLabelList = null;

        if (items != null)
        {
            this.setClassValueList = new Object[items.size()];
            this.setClassLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.setClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.setClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setSetClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>selectable</code>.
     */
    public void resetSelectable()
    {
        this.selectable = null;
    }
    
    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
    }

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }
    

    public Object[] getSelectableBackingList()
    {
        Object[] values = this.selectableValueList;
        Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * selectable property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the selectable backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSelectableBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setSelectableBackingList requires non-null property arguments");
        }

        this.selectableValueList = null;
        this.selectableLabelList = null;

        if (items != null)
        {
            this.selectableValueList = new Object[items.size()];
            this.selectableLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.selectableValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.selectableLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setSelectableBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>booleanClass</code>.
     */
    public void resetBooleanClass()
    {
        this.booleanClass = null;
    }
    
    public void setBooleanClass(java.lang.Boolean booleanClass)
    {
        this.booleanClass = booleanClass;
    }

    /**
     * 
     */
    public java.lang.Boolean isBooleanClass()
    {
        return this.booleanClass;
    }
    

    public Object[] getBooleanClassBackingList()
    {
        Object[] values = this.booleanClassValueList;
        Object[] labels = this.booleanClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getBooleanClassValueList()
    {
        return this.booleanClassValueList;
    }

    public void setBooleanClassValueList(Object[] booleanClassValueList)
    {
        this.booleanClassValueList = booleanClassValueList;
    }

    public Object[] getBooleanClassLabelList()
    {
        return this.booleanClassLabelList;
    }

    public void setBooleanClassLabelList(Object[] booleanClassLabelList)
    {
        this.booleanClassLabelList = booleanClassLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * booleanClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the booleanClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setBooleanClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setBooleanClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setBooleanClassBackingList requires non-null property arguments");
        }

        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;

        if (items != null)
        {
            this.booleanClassValueList = new Object[items.size()];
            this.booleanClassLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.booleanClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.booleanClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setBooleanClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>text</code>.
     */
    public void resetText()
    {
        this.text = null;
    }
    
    public void setText(java.lang.String text)
    {
        this.text = text;
    }

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }
    

    public Object[] getTextBackingList()
    {
        Object[] values = this.textValueList;
        Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * text property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the text backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setTextBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setTextBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setTextBackingList requires non-null property arguments");
        }

        this.textValueList = null;
        this.textLabelList = null;

        if (items != null)
        {
            this.textValueList = new Object[items.size()];
            this.textLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.textValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setTextBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>mapClass</code>.
     */
    public void resetMapClass()
    {
        this.mapClass.clear();
    }
    
	public void setMapClassValue(java.lang.String key, java.lang.Object value) 
	{
		this.mapClass.put(key, value);
	}

	public java.lang.Object getMapClassValue(String key) 
	{
		return mapClass.get(key);
	}
	
    public void setMapClass(java.util.Map mapClass)
    {
        this.mapClass = mapClass;
    }

    /**
     * 
     */
    public java.util.Map getMapClass()
    {
        return this.mapClass;
    }


    public Object[] getMapClassBackingList()
    {
        Object[] values = this.mapClassValueList;
        Object[] labels = this.mapClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMapClassValueList()
    {
        return this.mapClassValueList;
    }

    public void setMapClassValueList(Object[] mapClassValueList)
    {
        this.mapClassValueList = mapClassValueList;
    }

    public Object[] getMapClassLabelList()
    {
        return this.mapClassLabelList;
    }

    public void setMapClassLabelList(Object[] mapClassLabelList)
    {
        this.mapClassLabelList = mapClassLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * mapClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the mapClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setMapClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setMapClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setMapClassBackingList requires non-null property arguments");
        }

        this.mapClassValueList = null;
        this.mapClassLabelList = null;

        if (items != null)
        {
            this.mapClassValueList = new Object[items.size()];
            this.mapClassLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.mapClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.mapClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setMapClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiSelect</code>.
     */
    public void resetMultiSelect()
    {
        this.multiSelect = null;
    }
    
    public void setMultiSelect(java.util.Collection multiSelect)
    {
        this.multiSelect = multiSelect;
    }

    /**
     * 
     */
    public java.util.Collection getMultiSelect()
    {
        return this.multiSelect;
    }

    public void setMultiSelectAsArray(Object[] multiSelect)
    {
        this.multiSelect = (multiSelect == null) ? null : java.util.Arrays.asList(multiSelect);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getMultiSelect
     */
    public Object[] getMultiSelectAsArray()
    {
        return (multiSelect == null) ? null : multiSelect.toArray();
    }
    

    public Object[] getMultiSelectBackingList()
    {
        Object[] values = this.multiSelectValueList;
        Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * multiSelect property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the multiSelect backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setMultiSelectBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setMultiSelectBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setMultiSelectBackingList requires non-null property arguments");
        }

        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;

        if (items != null)
        {
            this.multiSelectValueList = new Object[items.size()];
            this.multiSelectLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.multiSelectValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiSelectLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setMultiSelectBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>dateWithoutCalendar</code>.
     */
    public void resetDateWithoutCalendar()
    {
        this.dateWithoutCalendar = null;
    }
    
    public void setDateWithoutCalendarAsDate(java.util.Date dateWithoutCalendar)
    {
        this.dateWithoutCalendar = dateWithoutCalendar;
    }

    /**
     * Returns the Date instance representing the <code>dateWithoutCalendar</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendar
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendarDateFormatter
     */
    public java.util.Date getDateWithoutCalendarAsDate()
    {
        return this.dateWithoutCalendar;
    }

    public void setDateWithoutCalendar(java.lang.String dateWithoutCalendar)
    {
        if (dateWithoutCalendar == null || dateWithoutCalendar.trim().length()==0)
        {
            this.dateWithoutCalendar = null;
        }
        else
        {
            try
            {
                this.dateWithoutCalendar = dateWithoutCalendarDateFormatter.parse(dateWithoutCalendar);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.dateWithoutCalendar = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateWithoutCalendarAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateWithoutCalendarDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendarAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendarDateFormatter
     */
    public java.lang.String getDateWithoutCalendar()
    {
        return (dateWithoutCalendar == null) ? null : dateWithoutCalendarDateFormatter.format(dateWithoutCalendar);
    }

    /**
     * Returns the date formatter used for the <code>dateWithoutCalendar</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendar
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithoutCalendarAsDate
     */
    public final static java.text.DateFormat getDateWithoutCalendarDateFormatter()
    {
        return ThreeGoFormImpl.dateWithoutCalendarDateFormatter;
    }


    public Object[] getDateWithoutCalendarBackingList()
    {
        Object[] values = this.dateWithoutCalendarValueList;
        Object[] labels = this.dateWithoutCalendarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDateWithoutCalendarValueList()
    {
        return this.dateWithoutCalendarValueList;
    }

    public void setDateWithoutCalendarValueList(Object[] dateWithoutCalendarValueList)
    {
        this.dateWithoutCalendarValueList = dateWithoutCalendarValueList;
    }

    public Object[] getDateWithoutCalendarLabelList()
    {
        return this.dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarLabelList(Object[] dateWithoutCalendarLabelList)
    {
        this.dateWithoutCalendarLabelList = dateWithoutCalendarLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * dateWithoutCalendar property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the dateWithoutCalendar backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDateWithoutCalendarBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDateWithoutCalendarBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setDateWithoutCalendarBackingList requires non-null property arguments");
        }

        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;

        if (items != null)
        {
            this.dateWithoutCalendarValueList = new Object[items.size()];
            this.dateWithoutCalendarLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.dateWithoutCalendarValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateWithoutCalendarLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setDateWithoutCalendarBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>dateWithTime</code>.
     */
    public void resetDateWithTime()
    {
        this.dateWithTime = null;
    }
    
    public void setDateWithTimeAsDate(java.util.Date dateWithTime)
    {
        this.dateWithTime = dateWithTime;
    }

    /**
     * Returns the Date instance representing the <code>dateWithTime</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTimeDateFormatter
     */
    public java.util.Date getDateWithTimeAsDate()
    {
        return this.dateWithTime;
    }

    public void setDateWithTime(java.lang.String dateWithTime)
    {
        if (dateWithTime == null || dateWithTime.trim().length()==0)
        {
            this.dateWithTime = null;
        }
        else
        {
            try
            {
                this.dateWithTime = dateWithTimeDateFormatter.parse(dateWithTime);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.dateWithTime = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateWithTimeAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateWithTimeDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTimeAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTimeDateFormatter
     */
    public java.lang.String getDateWithTime()
    {
        return (dateWithTime == null) ? null : dateWithTimeDateFormatter.format(dateWithTime);
    }

    /**
     * Returns the date formatter used for the <code>dateWithTime</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getDateWithTimeAsDate
     */
    public final static java.text.DateFormat getDateWithTimeDateFormatter()
    {
        return ThreeGoFormImpl.dateWithTimeDateFormatter;
    }


    public Object[] getDateWithTimeBackingList()
    {
        Object[] values = this.dateWithTimeValueList;
        Object[] labels = this.dateWithTimeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDateWithTimeValueList()
    {
        return this.dateWithTimeValueList;
    }

    public void setDateWithTimeValueList(Object[] dateWithTimeValueList)
    {
        this.dateWithTimeValueList = dateWithTimeValueList;
    }

    public Object[] getDateWithTimeLabelList()
    {
        return this.dateWithTimeLabelList;
    }

    public void setDateWithTimeLabelList(Object[] dateWithTimeLabelList)
    {
        this.dateWithTimeLabelList = dateWithTimeLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * dateWithTime property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the dateWithTime backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDateWithTimeBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDateWithTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setDateWithTimeBackingList requires non-null property arguments");
        }

        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;

        if (items != null)
        {
            this.dateWithTimeValueList = new Object[items.size()];
            this.dateWithTimeLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.dateWithTimeValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateWithTimeLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setDateWithTimeBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatClass</code>.
     */
    public void resetFloatClass()
    {
        this.floatClass = null;
    }
    
    public void setFloatClass(java.lang.Float floatClass)
    {
        this.floatClass = floatClass;
    }

    /**
     * 
     */
    public java.lang.Float getFloatClass()
    {
        return this.floatClass;
    }
    

    public Object[] getFloatClassBackingList()
    {
        Object[] values = this.floatClassValueList;
        Object[] labels = this.floatClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatClassValueList()
    {
        return this.floatClassValueList;
    }

    public void setFloatClassValueList(Object[] floatClassValueList)
    {
        this.floatClassValueList = floatClassValueList;
    }

    public Object[] getFloatClassLabelList()
    {
        return this.floatClassLabelList;
    }

    public void setFloatClassLabelList(Object[] floatClassLabelList)
    {
        this.floatClassLabelList = floatClassLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * floatClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the floatClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setFloatClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setFloatClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setFloatClassBackingList requires non-null property arguments");
        }

        this.floatClassValueList = null;
        this.floatClassLabelList = null;

        if (items != null)
        {
            this.floatClassValueList = new Object[items.size()];
            this.floatClassLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.floatClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setFloatClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>collection</code>.
     */
    public void resetCollection()
    {
        this.collection = null;
    }
    
    public void setCollection(java.util.Collection collection)
    {
        this.collection = collection;
    }

    /**
     * 
     */
    public java.util.Collection getCollection()
    {
        return this.collection;
    }

    public void setCollectionAsArray(Object[] collection)
    {
        this.collection = (collection == null) ? null : java.util.Arrays.asList(collection);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.ThreeGoFormImpl#getCollection
     */
    public Object[] getCollectionAsArray()
    {
        return (collection == null) ? null : collection.toArray();
    }
    

    public Object[] getCollectionBackingList()
    {
        Object[] values = this.collectionValueList;
        Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * collection property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the collection backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setCollectionBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setCollectionBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setCollectionBackingList requires non-null property arguments");
        }

        this.collectionValueList = null;
        this.collectionLabelList = null;

        if (items != null)
        {
            this.collectionValueList = new Object[items.size()];
            this.collectionLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.collectionValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.collectionLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setCollectionBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>integerClass</code>.
     */
    public void resetIntegerClass()
    {
        this.integerClass = null;
    }
    
    public void setIntegerClass(java.lang.Integer integerClass)
    {
        this.integerClass = integerClass;
    }

    /**
     * 
     */
    public java.lang.Integer getIntegerClass()
    {
        return this.integerClass;
    }
    

    public Object[] getIntegerClassBackingList()
    {
        Object[] values = this.integerClassValueList;
        Object[] labels = this.integerClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntegerClassValueList()
    {
        return this.integerClassValueList;
    }

    public void setIntegerClassValueList(Object[] integerClassValueList)
    {
        this.integerClassValueList = integerClassValueList;
    }

    public Object[] getIntegerClassLabelList()
    {
        return this.integerClassLabelList;
    }

    public void setIntegerClassLabelList(Object[] integerClassLabelList)
    {
        this.integerClassLabelList = integerClassLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * integerClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the integerClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setIntegerClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setIntegerClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setIntegerClassBackingList requires non-null property arguments");
        }

        this.integerClassValueList = null;
        this.integerClassLabelList = null;

        if (items != null)
        {
            this.integerClassValueList = new Object[items.size()];
            this.integerClassLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.integerClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.integerClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setIntegerClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>number</code>.
     */
    public void resetNumber()
    {
        this.number = 0;
    }
    
    public void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }
    

    public Object[] getNumberBackingList()
    {
        Object[] values = this.numberValueList;
        Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * number property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the number backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setNumberBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setNumberBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ThreeGoFormImpl.setNumberBackingList requires non-null property arguments");
        }

        this.numberValueList = null;
        this.numberLabelList = null;

        if (items != null)
        {
            this.numberValueList = new Object[items.size()];
            this.numberLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.numberValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.numberLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ThreeGoFormImpl.setNumberBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.file = null;
        this.bool = false;
        this.setClass = null;
        this.setClassValueList = new Object[0];
        this.setClassLabelList = new Object[0];
        this.selectable = null;
        this.booleanClass = null;
        this.multiSelect = null;
        this.multiSelectValueList = new Object[0];
        this.multiSelectLabelList = new Object[0];
        this.collection = null;
        this.collectionValueList = new Object[0];
        this.collectionLabelList = new Object[0];
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("title", this.title);
        builder.append("file", this.file);
        builder.append("hasCustomValidator", this.hasCustomValidator);
        builder.append("multiFormat", this.multiFormat);
        builder.append("date", this.date);
        builder.append("bool", this.bool);
        builder.append("setClass", this.setClass);
        builder.append("selectable", this.selectable);
        builder.append("booleanClass", this.booleanClass);
        builder.append("text", this.text);
        builder.append("mapClass", this.mapClass);
        builder.append("multiSelect", this.multiSelect);
        builder.append("dateWithoutCalendar", this.dateWithoutCalendar);
        builder.append("dateWithTime", this.dateWithTime);
        builder.append("floatClass", this.floatClass);
        builder.append("collection", this.collection);
        builder.append("integerClass", this.integerClass);
        builder.append("number", this.number);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.title = null;
        this.file = null;
        this.hasCustomValidator = null;
        this.multiFormat = null;
        this.date = null;
        this.bool = false;
        this.setClass = null;
        this.setClassValueList = null;
        this.setClassLabelList = null;
        this.selectable = null;
        this.selectableValueList = null;
        this.selectableLabelList = null;
        this.booleanClass = null;
        this.text = null;
        this.mapClass = null;
        this.multiSelect = null;
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        this.dateWithoutCalendar = null;
        this.dateWithTime = null;
        this.floatClass = null;
        this.collection = null;
        this.collectionValueList = null;
        this.collectionLabelList = null;
        this.integerClass = null;
        this.number = 0;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}