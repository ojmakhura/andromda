package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation1
     */
    public final void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation1Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation2
     */
    public final void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation3
     */
    public final void operation3(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation3Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }


}
