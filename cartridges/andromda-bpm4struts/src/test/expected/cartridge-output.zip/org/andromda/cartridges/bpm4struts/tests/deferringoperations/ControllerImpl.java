package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation1
     */
    public final void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation1Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation2
     */
    public final void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation3
     */
    public final void operation3(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation3Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#deferringOperations
     */
    public final void deferringOperations(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#testMissingArgumentField
     */
    public final void testMissingArgumentField(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestMissingArgumentFieldForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setThisArgumentIsMissingFromTheActionForm("thisArgumentIsMissingFromTheActionForm-test");
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#missingArgumentName
     */
    public final void missingArgumentName(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.MissingArgumentNameForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setnull("null-test");
    }


}
