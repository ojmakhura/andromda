package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }

    /**
     * 
     */
    public final false operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2bForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
    }

    /**
     * 
     */
    public final false operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State4Trigger4Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger4Param4((int)-161531421);
        form.setTrigger4TestParam2("trigger4TestParam2-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }

    /**
     * 
     */
    public final void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }

    /**
     * 
     */
    public final false operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger4Param4((int)-161531421);
        form.setTrigger4TestParam2("trigger4TestParam2-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }

    /**
     * 
     */
    public final false operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2bForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
    }

    /**
     * 
     */
    public final false operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State4Trigger4Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger2bTestParam2((int)1669991615);
        form.setTrigger2bTestParam("trigger2bTestParam-test");
        form.setPageVariable("pageVariable-test");
        form.setTrigger4Param4((int)-161531421);
        form.setTrigger4TestParam2("trigger4TestParam2-test");
        form.setTrigger2bParam2a("trigger2bParam2a-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }

    /**
     * 
     */
    public final void operation3(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTrigger4Param4((int)-161531421);
        form.setTrigger4TestParam2("trigger4TestParam2-test");
        form.setTrigger2TestParam("trigger2TestParam-test");
    }


}
