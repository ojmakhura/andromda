package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/NoTableLinkActivity/ShowTableDataAgain"
 *        name="noTableLinkActivityShowTableDataAgainForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="show.table.data"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="no.table.link.activity.show.table.data.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *       scope="request"
 *
 */
public final class ShowTableDataAgain extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = loadTableData(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward loadTableData(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().loadTableData(mapping, (ShowTableDataAgainForm)form, request, response);
        return mapping.findForward("show.table.data");
    }

}
