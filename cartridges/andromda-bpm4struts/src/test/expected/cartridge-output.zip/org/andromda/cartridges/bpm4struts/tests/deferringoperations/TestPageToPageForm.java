/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>testPageToPage</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#testPageToPage
 */
public interface TestPageToPageForm
{
    /**
     * Sets the <code>decisionTestParam</code> field.
     *
     * 
     */
    public void setDecisionTestParam(int decisionTestParam);

    /**
     * Gets the <code>decisionTestParam</code> field.
     *
     * 
     */
    public int getDecisionTestParam();
    
    /**
     * Resets the <code>decisionTestParam</code> field.
     */
    public void resetDecisionTestParam();

}
