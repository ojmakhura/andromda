package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/DeferringOperations/State2Trigger2"
 *        name="deferringOperationsState2Trigger2Form"
 *       input="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="state4"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state4.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="deferring.operations.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *       scope="request"
 *
 */
public final class State2Trigger2 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _state3(mapping, form, request, response);
        request.setAttribute("form", form);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _state3(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().operation2(mapping, (State2Trigger2Form)form, request, response);
        ControllerFactory.getControllerInstance().operation3(mapping, (State2Trigger2Form)form, request, response);
        request.setAttribute("form", form);
        return mapping.findForward("state4");
    }

}
