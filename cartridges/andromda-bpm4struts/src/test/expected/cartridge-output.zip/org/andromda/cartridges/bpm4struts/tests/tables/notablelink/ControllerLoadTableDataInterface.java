package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

public interface ControllerLoadTableDataInterface
{
}