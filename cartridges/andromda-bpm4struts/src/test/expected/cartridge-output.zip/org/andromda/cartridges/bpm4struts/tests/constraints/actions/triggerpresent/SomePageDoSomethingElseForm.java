package org.andromda.cartridges.bpm4struts.tests.constraints.actions.triggerpresent;

/**
 * @struts.form
 *      name="triggerPresentUseCaseSomePageDoSomethingElseForm"
 */
public class SomePageDoSomethingElseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public SomePageDoSomethingElseForm()
    {
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>.
     */
    public void clean()
    {
    }

}
