package org.andromda.cartridges.bpm4struts.tests.constraints.actions.triggerpresent;

/**
 * @struts.form
 *      name="triggerPresentUseCaseSomePageDoSomethingElseForm"
 */
public class SomePageDoSomethingElseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public SomePageDoSomethingElseForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
