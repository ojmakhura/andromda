/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package ;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>something</code> method, which is located on the
 * <code>NotInAnyPackageController</code> controller.
 *
 * 
 *
 * @see NotInAnyPackageController#something
 */
public interface SomethingForm
{
}
