/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.ejb3;

/**
 * @see org.andromda.cartridges.ejb3.TheEmbeddedDataType
 */
public class TheEmbeddedDataTypeImpl
    extends org.andromda.cartridges.ejb3.TheEmbeddedDataType
    implements java.io.Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = -4166629332131042829L;
    
    /**
     * @see org.andromda.cartridges.ejb3.TheEmbeddedDataType#someConversion()
     */
    public void someConversion()
    {
        // ${toDoTag} implement public void someConversion()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.ejb3.TheEmbeddedDataType.someConversion() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.ejb3.TheEmbeddedDataType#normalize()
     */
    public void normalize()
    {
        // ${toDoTag} implement public void normalize()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.ejb3.TheEmbeddedDataType.normalize() Not implemented!");
    }

}