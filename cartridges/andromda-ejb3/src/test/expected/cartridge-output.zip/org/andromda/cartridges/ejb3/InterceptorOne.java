/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

/**
 * Interceptor class InterceptorOne
 */
public class InterceptorOne
{
    /**
     * Default interceptor execution method
     *
     * @param ctx the invocation context
     * @return
     */
    @AroundInvoke
    public Object execute(InvocationContext ctx)
        throws Exception
    {
        // Add implementation

        try
        {
            return ctx.proceed();
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}