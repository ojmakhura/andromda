/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntitySeventeen
 *
 * @see org.andromda.cartridges.ejb3.EntitySeventeen
 */
public class EntitySeventeenListener 
{
    /**
     * Default public no-args constructor
     */
    public EntitySeventeenListener() 
    {
        // empty constructor
    }
    
    @javax.persistence.PrePersist
    public void prePersist(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(org.andromda.cartridges.ejb3.EntitySeventeen entitySeventeen) 
	{
		// post load implementation
	}
}
