// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto9.a;

/**
 * @see org.andromda.test.howto9.a.Car
 */
public class CarDaoImpl
    extends CarDaoBase
{
    /**
     * @see org.andromda.test.howto9.a.CarDao#allCarsAreRented()
     */
    protected boolean handleAllCarsAreRented()
    {
        // TODO implement public boolean handleAllCarsAreRented()
        return false;
    }

}