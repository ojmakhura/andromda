// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

import org.andromda.metafacades.uml.OperationFacade;

/**
 * TODO: Model Documentation for org.andromda.cartridges.meta.OperationTestMetafacade
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface OperationTestMetafacade
    extends OperationFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isOperationTestMetafacadeMetaType();

    /**
     * TODO: Model Documentation for ClassifierTestMetafacade
     * @return ClassifierTestMetafacade
     */
    public ClassifierTestMetafacade getTestClassifier();

    /**
     * TODO: Model Documentation for
     * org.andromda.cartridges.meta.OperationTestMetafacade.testAttribute
     * @return boolean
     */
    public boolean isTestAttribute();
}