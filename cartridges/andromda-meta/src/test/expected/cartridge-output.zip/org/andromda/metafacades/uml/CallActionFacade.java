//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface CallActionFacade
       extends org.andromda.metafacades.uml.ActionFacade
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.OperationFacade getOperation();

}
