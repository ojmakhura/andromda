package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ClassifierFacade.
 *
 * @see org.andromda.metafacades.uml.ClassifierFacade
 */
public class ClassifierFacadeLogicImpl
       extends ClassifierFacadeLogic
       implements org.andromda.metafacades.uml.ClassifierFacade
{
    // ---------------- constructor -------------------------------

    public ClassifierFacadeLogicImpl (org.omg.uml.foundation.core.Classifier metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isPrimitiveType()
     */
    public boolean handleIsPrimitiveType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getOperationCallFromAttributes()
     */
    public java.lang.String handleGetOperationCallFromAttributes() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getInstanceAttributes()
     */
    public java.util.Collection handleGetInstanceAttributes() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getStaticAttributes()
     */
    public java.util.Collection handleGetStaticAttributes() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAbstractions()
     */
    public java.util.Collection handleGetAbstractions() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isAbstract()
     */
    public boolean handleIsAbstract() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAttributes(boolean)
     */
    public java.util.Collection handleGetAttributes(boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getProperties()
     */
    public java.util.Collection handleGetProperties() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isDatatype()
     */
    public boolean handleIsDatatype() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isArrayType()
     */
    public boolean handleIsArrayType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isCollectionType()
     */
    public boolean handleIsCollectionType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isEnumeration()
     */
    public boolean handleIsEnumeration() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getWrapperName()
     */
    public java.lang.String handleGetWrapperName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isDateType()
     */
    public boolean handleIsDateType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#isInterface()
     */
    public boolean handleIsInterface() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getJavaNullString()
     */
    public java.lang.String handleGetJavaNullString() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getOperations()
     */
    public java.util.Collection handleGetOperations()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAttributes()
     */
    public java.util.Collection handleGetAttributes()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getAssociationEnds()
     */
    public java.util.Collection handleGetAssociationEnds()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getNonArray()
     */
    public java.lang.Object handleGetNonArray()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ClassifierFacade#getArray()
     */
    public java.lang.Object handleGetArray()
    {
        // TODO: add your implementation here!
        return null;
    }

}
