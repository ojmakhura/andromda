package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EventFacade.
 *
 * @see org.andromda.metafacades.uml.EventFacade
 */
public class EventFacadeLogicImpl
    extends EventFacadeLogic
{
    // ---------------- constructor -------------------------------

    public EventFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.Event metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.EventFacade#getTransition()
     */
    protected java.lang.Object handleGetTransition()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EventFacade#getParameters()
     */
    protected java.util.Collection handleGetParameters()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EventFacade#getActionState()
     */
    protected java.lang.Object handleGetActionState()
    {
        // TODO: add your implementation here!
        return null;
    }

}
