//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAssociationEnd
 *
 * @see org.andromda.metafacades.uml.EntityAssociationEnd
 */
public abstract class EntityAssociationEndLogic
    extends org.andromda.metafacades.uml.AssociationEndFacadeLogicImpl
    implements org.andromda.metafacades.uml.EntityAssociationEnd
{

    protected Object metaObject;

    public EntityAssociationEndLogic(Object metaObject, String context)
    {  
        super((org.omg.uml.foundation.core.AssociationEnd)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAssociationEnd";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEnd#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName1aPreCondition()
    {
    }

    private void handleGetColumnName1aPostCondition()
    {
    }

    private java.lang.String __columnName1a;
    private boolean __columnName1aSet = false;

    public final java.lang.String getColumnName()
    {
        java.lang.String columnName1a = this.__columnName1a;
        if (!this.__columnName1aSet)
        {
            handleGetColumnName1aPreCondition();
            columnName1a = handleGetColumnName();
            handleGetColumnName1aPostCondition();
            this.__columnName1a = columnName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__columnName1aSet = true;
            }
        }
        return columnName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEnd#getForeignKeySuffix()
    */
    protected abstract java.lang.String handleGetForeignKeySuffix();

    private void handleGetForeignKeySuffix2aPreCondition()
    {
    }

    private void handleGetForeignKeySuffix2aPostCondition()
    {
    }

    private java.lang.String __foreignKeySuffix2a;
    private boolean __foreignKeySuffix2aSet = false;

    public final java.lang.String getForeignKeySuffix()
    {
        java.lang.String foreignKeySuffix2a = this.__foreignKeySuffix2a;
        if (!this.__foreignKeySuffix2aSet)
        {
            handleGetForeignKeySuffix2aPreCondition();
            foreignKeySuffix2a = handleGetForeignKeySuffix();
            handleGetForeignKeySuffix2aPostCondition();
            this.__foreignKeySuffix2a = foreignKeySuffix2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__foreignKeySuffix2aSet = true;
            }
        }
        return foreignKeySuffix2a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEnd#isForeignIdentifier()
    */
    protected abstract boolean handleIsForeignIdentifier();

    private void handleIsForeignIdentifier3aPreCondition()
    {
    }

    private void handleIsForeignIdentifier3aPostCondition()
    {
    }

    private boolean __foreignIdentifier3a;
    private boolean __foreignIdentifier3aSet = false;

    public final boolean isForeignIdentifier()
    {
        boolean foreignIdentifier3a = this.__foreignIdentifier3a;
        if (!this.__foreignIdentifier3aSet)
        {
            handleIsForeignIdentifier3aPreCondition();
            foreignIdentifier3a = handleIsForeignIdentifier();
            handleIsForeignIdentifier3aPostCondition();
            this.__foreignIdentifier3a = foreignIdentifier3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__foreignIdentifier3aSet = true;
            }
        }
        return foreignIdentifier3a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEnd#getForeignKeyConstraintName()
    */
    protected abstract java.lang.String handleGetForeignKeyConstraintName();

    private void handleGetForeignKeyConstraintName4aPreCondition()
    {
    }

    private void handleGetForeignKeyConstraintName4aPostCondition()
    {
    }

    private java.lang.String __foreignKeyConstraintName4a;
    private boolean __foreignKeyConstraintName4aSet = false;

    public final java.lang.String getForeignKeyConstraintName()
    {
        java.lang.String foreignKeyConstraintName4a = this.__foreignKeyConstraintName4a;
        if (!this.__foreignKeyConstraintName4aSet)
        {
            handleGetForeignKeyConstraintName4aPreCondition();
            foreignKeyConstraintName4a = handleGetForeignKeyConstraintName();
            handleGetForeignKeyConstraintName4aPostCondition();
            this.__foreignKeyConstraintName4a = foreignKeyConstraintName4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__foreignKeyConstraintName4aSet = true;
            }
        }
        return foreignKeyConstraintName4a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEnd#getColumnIndex()
    */
    protected abstract java.lang.String handleGetColumnIndex();

    private void handleGetColumnIndex5aPreCondition()
    {
    }

    private void handleGetColumnIndex5aPostCondition()
    {
    }

    private java.lang.String __columnIndex5a;
    private boolean __columnIndex5aSet = false;

    public final java.lang.String getColumnIndex()
    {
        java.lang.String columnIndex5a = this.__columnIndex5a;
        if (!this.__columnIndex5aSet)
        {
            handleGetColumnIndex5aPreCondition();
            columnIndex5a = handleGetColumnIndex();
            handleGetColumnIndex5aPostCondition();
            this.__columnIndex5a = columnIndex5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__columnIndex5aSet = true;
            }
        }
        return columnIndex5a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"foreignIdentifier"))).booleanValue()?(Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"one2One"))).booleanValue()&&Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"child"))).booleanValue()&&org.andromda.translation.ocl.validation.OCLCollections.one(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"type.associationEnds"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"foreignIdentifier"))).booleanValue();}})):true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Only ONE association end on an entity can be flagged as having a foreign identifier at any given time. It also MUST be the child end (the other side is flagged as having composite aggregation) of a one-to-one association."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}