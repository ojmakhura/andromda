//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntity
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public abstract class ManageableEntityLogic
    extends org.andromda.metafacades.uml.EntityLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntity
{

    protected Object metaObject;

    public ManageableEntityLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntity";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackageName()
    */
    protected abstract java.lang.String handleGetCrudPackageName();

    private void handleGetCrudPackageName1aPreCondition()
    {
    }

    private void handleGetCrudPackageName1aPostCondition()
    {
    }

    private java.lang.String __crudPackageName1a;
    private boolean __crudPackageName1aSet = false;

    public final java.lang.String getCrudPackageName()
    {
        java.lang.String crudPackageName1a = this.__crudPackageName1a;
        if (!this.__crudPackageName1aSet)
        {
            handleGetCrudPackageName1aPreCondition();
            crudPackageName1a = handleGetCrudPackageName();
            handleGetCrudPackageName1aPostCondition();
            this.__crudPackageName1a = crudPackageName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudPackageName1aSet = true;
            }
        }
        return crudPackageName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceAccessorCall()
    */
    protected abstract java.lang.String handleGetCrudServiceAccessorCall();

    private void handleGetCrudServiceAccessorCall2aPreCondition()
    {
    }

    private void handleGetCrudServiceAccessorCall2aPostCondition()
    {
    }

    private java.lang.String __crudServiceAccessorCall2a;
    private boolean __crudServiceAccessorCall2aSet = false;

    public final java.lang.String getCrudServiceAccessorCall()
    {
        java.lang.String crudServiceAccessorCall2a = this.__crudServiceAccessorCall2a;
        if (!this.__crudServiceAccessorCall2aSet)
        {
            handleGetCrudServiceAccessorCall2aPreCondition();
            crudServiceAccessorCall2a = handleGetCrudServiceAccessorCall();
            handleGetCrudServiceAccessorCall2aPostCondition();
            this.__crudServiceAccessorCall2a = crudServiceAccessorCall2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudServiceAccessorCall2aSet = true;
            }
        }
        return crudServiceAccessorCall2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
    */
    protected abstract boolean handleIsRead();

    private void handleIsRead3aPreCondition()
    {
    }

    private void handleIsRead3aPostCondition()
    {
    }

    private boolean __read3a;
    private boolean __read3aSet = false;

    public final boolean isRead()
    {
        boolean read3a = this.__read3a;
        if (!this.__read3aSet)
        {
            handleIsRead3aPreCondition();
            read3a = handleIsRead();
            handleIsRead3aPostCondition();
            this.__read3a = read3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__read3aSet = true;
            }
        }
        return read3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
    */
    protected abstract boolean handleIsCreate();

    private void handleIsCreate4aPreCondition()
    {
    }

    private void handleIsCreate4aPostCondition()
    {
    }

    private boolean __create4a;
    private boolean __create4aSet = false;

    public final boolean isCreate()
    {
        boolean create4a = this.__create4a;
        if (!this.__create4aSet)
        {
            handleIsCreate4aPreCondition();
            create4a = handleIsCreate();
            handleIsCreate4aPostCondition();
            this.__create4a = create4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__create4aSet = true;
            }
        }
        return create4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
    */
    protected abstract boolean handleIsUpdate();

    private void handleIsUpdate5aPreCondition()
    {
    }

    private void handleIsUpdate5aPostCondition()
    {
    }

    private boolean __update5a;
    private boolean __update5aSet = false;

    public final boolean isUpdate()
    {
        boolean update5a = this.__update5a;
        if (!this.__update5aSet)
        {
            handleIsUpdate5aPreCondition();
            update5a = handleIsUpdate();
            handleIsUpdate5aPostCondition();
            this.__update5a = update5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__update5aSet = true;
            }
        }
        return update5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
    */
    protected abstract boolean handleIsDelete();

    private void handleIsDelete6aPreCondition()
    {
    }

    private void handleIsDelete6aPostCondition()
    {
    }

    private boolean __delete6a;
    private boolean __delete6aSet = false;

    public final boolean isDelete()
    {
        boolean delete6a = this.__delete6a;
        if (!this.__delete6aSet)
        {
            handleIsDelete6aPreCondition();
            delete6a = handleIsDelete();
            handleIsDelete6aPostCondition();
            this.__delete6a = delete6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__delete6aSet = true;
            }
        }
        return delete6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackagePath()
    */
    protected abstract java.lang.String handleGetCrudPackagePath();

    private void handleGetCrudPackagePath7aPreCondition()
    {
    }

    private void handleGetCrudPackagePath7aPostCondition()
    {
    }

    private java.lang.String __crudPackagePath7a;
    private boolean __crudPackagePath7aSet = false;

    public final java.lang.String getCrudPackagePath()
    {
        java.lang.String crudPackagePath7a = this.__crudPackagePath7a;
        if (!this.__crudPackagePath7aSet)
        {
            handleGetCrudPackagePath7aPreCondition();
            crudPackagePath7a = handleGetCrudPackagePath();
            handleGetCrudPackagePath7aPostCondition();
            this.__crudPackagePath7a = crudPackagePath7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudPackagePath7aSet = true;
            }
        }
        return crudPackagePath7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceName()
    */
    protected abstract java.lang.String handleGetCrudServiceName();

    private void handleGetCrudServiceName8aPreCondition()
    {
    }

    private void handleGetCrudServiceName8aPostCondition()
    {
    }

    private java.lang.String __crudServiceName8a;
    private boolean __crudServiceName8aSet = false;

    public final java.lang.String getCrudServiceName()
    {
        java.lang.String crudServiceName8a = this.__crudServiceName8a;
        if (!this.__crudServiceName8aSet)
        {
            handleGetCrudServiceName8aPreCondition();
            crudServiceName8a = handleGetCrudServiceName();
            handleGetCrudServiceName8aPostCondition();
            this.__crudServiceName8a = crudServiceName8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudServiceName8aSet = true;
            }
        }
        return crudServiceName8a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getFullyQualifiedCrudServiceName()
    */
    protected abstract java.lang.String handleGetFullyQualifiedCrudServiceName();

    private void handleGetFullyQualifiedCrudServiceName9aPreCondition()
    {
    }

    private void handleGetFullyQualifiedCrudServiceName9aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedCrudServiceName9a;
    private boolean __fullyQualifiedCrudServiceName9aSet = false;

    public final java.lang.String getFullyQualifiedCrudServiceName()
    {
        java.lang.String fullyQualifiedCrudServiceName9a = this.__fullyQualifiedCrudServiceName9a;
        if (!this.__fullyQualifiedCrudServiceName9aSet)
        {
            handleGetFullyQualifiedCrudServiceName9aPreCondition();
            fullyQualifiedCrudServiceName9a = handleGetFullyQualifiedCrudServiceName();
            handleGetFullyQualifiedCrudServiceName9aPostCondition();
            this.__fullyQualifiedCrudServiceName9a = fullyQualifiedCrudServiceName9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullyQualifiedCrudServiceName9aSet = true;
            }
        }
        return fullyQualifiedCrudServiceName9a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceFullPath()
    */
    protected abstract java.lang.String handleGetCrudServiceFullPath();

    private void handleGetCrudServiceFullPath10aPreCondition()
    {
    }

    private void handleGetCrudServiceFullPath10aPostCondition()
    {
    }

    private java.lang.String __crudServiceFullPath10a;
    private boolean __crudServiceFullPath10aSet = false;

    public final java.lang.String getCrudServiceFullPath()
    {
        java.lang.String crudServiceFullPath10a = this.__crudServiceFullPath10a;
        if (!this.__crudServiceFullPath10aSet)
        {
            handleGetCrudServiceFullPath10aPreCondition();
            crudServiceFullPath10a = handleGetCrudServiceFullPath();
            handleGetCrudServiceFullPath10aPostCondition();
            this.__crudServiceFullPath10a = crudServiceFullPath10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudServiceFullPath10aSet = true;
            }
        }
        return crudServiceFullPath10a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudMembers()
    */
    protected abstract java.util.List handleGetCrudMembers();

    private void handleGetCrudMembers11aPreCondition()
    {
    }

    private void handleGetCrudMembers11aPostCondition()
    {
    }

    private java.util.List __crudMembers11a;
    private boolean __crudMembers11aSet = false;

    public final java.util.List getCrudMembers()
    {
        java.util.List crudMembers11a = this.__crudMembers11a;
        if (!this.__crudMembers11aSet)
        {
            handleGetCrudMembers11aPreCondition();
            crudMembers11a = handleGetCrudMembers();
            handleGetCrudMembers11aPostCondition();
            this.__crudMembers11a = crudMembers11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudMembers11aSet = true;
            }
        }
        return crudMembers11a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleListCrudMembers(boolean withTypes, boolean useCollectionTypes);

    private void handleListCrudMembers1oPreCondition()
    {
    }

    private void handleListCrudMembers1oPostCondition()
    {
    }

    public java.lang.String listCrudMembers(boolean withTypes, boolean useCollectionTypes)
    {
        handleListCrudMembers1oPreCondition();
        java.lang.String returnValue = handleListCrudMembers(withTypes, useCollectionTypes);
        handleListCrudMembers1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetManageableAssociationEnds1rPreCondition()
    {
    }

    private void handleGetManageableAssociationEnds1rPostCondition()
    {
    }

    private java.util.List __getManageableAssociationEnds1r;
    private boolean __getManageableAssociationEnds1rSet = false;

    public final java.util.List getManageableAssociationEnds()
    {
        java.util.List getManageableAssociationEnds1r = this.__getManageableAssociationEnds1r;
        if (!this.__getManageableAssociationEnds1rSet)
        {
            handleGetManageableAssociationEnds1rPreCondition();
            Object result = this.shieldedElements(handleGetManageableAssociationEnds());
            try
            {
                getManageableAssociationEnds1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetManageableAssociationEnds1rPostCondition();
            this.__getManageableAssociationEnds1r = getManageableAssociationEnds1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableAssociationEnds1rSet = true;
            }
        }
        return getManageableAssociationEnds1r;
    }

    protected abstract java.util.Collection handleGetManageableAssociationEnds();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}