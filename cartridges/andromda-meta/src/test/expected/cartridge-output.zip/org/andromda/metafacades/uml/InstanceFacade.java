//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface InstanceFacade
    extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.util.Collection getClassifiers();

   /**
    * 
    */
    public java.util.Collection getLinkEnds();

   /**
    * 
    */
    public java.util.Collection getOwnedInstances();

   /**
    * 
    */
    public java.util.Collection getOwnedLinks();

   /**
    * 
    */
    public java.util.Collection getSlots();

}