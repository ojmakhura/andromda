//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ServiceOperationFacade
 *
 * @see org.andromda.metafacades.uml.ServiceOperationFacade
 */
public abstract class ServiceOperationFacadeLogic
    extends org.andromda.metafacades.uml.OperationFacadeLogicImpl
    implements org.andromda.metafacades.uml.ServiceOperationFacade
{

    protected Object metaObject;

    public ServiceOperationFacadeLogic (Object metaObject, String context)
    {
        super ((org.omg.uml.foundation.core.Operation)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ServiceOperationFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ServiceOperationFacade#getTransactionType()
    */
    protected abstract java.lang.String handleGetTransactionType();

    private void handleGetTransactionType1aPreCondition()
    {
    }

    private void handleGetTransactionType1aPostCondition()
    {
    }

    public final java.lang.String getTransactionType()
    {
        java.lang.String transactionType1a = null;
        handleGetTransactionType1aPreCondition();
        transactionType1a = handleGetTransactionType();
        handleGetTransactionType1aPostCondition();
        return transactionType1a;
    }

    // ------------- associations ------------------

    private void handleGetRoles1rPreCondition()
    {
    }

    private void handleGetRoles1rPostCondition()
    {
    }

    public final java.util.Collection getRoles()
    {
        java.util.Collection getRoles1r = null;
        handleGetRoles1rPreCondition();
        Object result = this.shieldedElements(handleGetRoles());
        try
        {
            getRoles1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetRoles1rPostCondition();
        return getRoles1r;
    }

    protected abstract java.util.Collection handleGetRoles();

    private void handleGetService2rPreCondition()
    {
    }

    private void handleGetService2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ServiceFacade getService()
    {
        org.andromda.metafacades.uml.ServiceFacade getService2r = null;
        handleGetService2rPreCondition();
        Object result = this.shieldedElement(handleGetService());
        try
        {
            getService2r = (org.andromda.metafacades.uml.ServiceFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetService2rPostCondition();
        return getService2r;
    }

    protected abstract java.lang.Object handleGetService();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
