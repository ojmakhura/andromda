//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface EnumerationFacade
       extends org.andromda.metafacades.uml.ClassifierFacade
{

   /**
    * 
    */
    public java.util.Collection getLiterals();

}
