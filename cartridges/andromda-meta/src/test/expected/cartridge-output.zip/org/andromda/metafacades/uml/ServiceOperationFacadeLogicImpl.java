package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ServiceOperationFacade.
 *
 * @see org.andromda.metafacades.uml.ServiceOperationFacade
 */
public class ServiceOperationFacadeLogicImpl
       extends ServiceOperationFacadeLogic
       implements org.andromda.metafacades.uml.ServiceOperationFacade
{
    // ---------------- constructor -------------------------------

    public ServiceOperationFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ServiceOperationFacade#getTransactionType()
     */
    public java.lang.String handleGetTransactionType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.ServiceOperationFacade#getRoles()
     */
    public java.util.Collection handleGetRoles()
    {
        // TODO: add your implementation here!
        return null;
    }

}
