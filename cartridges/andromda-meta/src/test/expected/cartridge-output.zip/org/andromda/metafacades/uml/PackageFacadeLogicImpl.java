package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.PackageFacade.
 *
 * @see org.andromda.metafacades.uml.PackageFacade
 */
public class PackageFacadeLogicImpl
       extends PackageFacadeLogic
       implements org.andromda.metafacades.uml.PackageFacade
{
    // ---------------- constructor -------------------------------

    public PackageFacadeLogicImpl (org.omg.uml.modelmanagement.UmlPackage metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.PackageFacade#findModelElement(java.lang.String)
     */
    protected org.andromda.metafacades.uml.ModelElementFacade handleFindModelElement(java.lang.String fullyQualifiedName)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getClasses()
     */
    protected java.util.Collection handleGetClasses()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getSubPackages()
     */
    protected java.util.Collection handleGetSubPackages()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getModelElements()
     */
    protected java.util.Collection handleGetModelElements()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getOwnedElements()
     */
    protected java.util.Collection handleGetOwnedElements()
    {
        // TODO: add your implementation here!
        return null;
    }

}
