//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityQueryOperation
 *
 * @see org.andromda.metafacades.uml.EntityQueryOperation
 */
public abstract class EntityQueryOperationLogic
    extends org.andromda.metafacades.uml.OperationFacadeLogicImpl
    implements org.andromda.metafacades.uml.EntityQueryOperation
{

    protected Object metaObject;

    public EntityQueryOperationLogic(Object metaObject, String context)
    {  
        super((org.omg.uml.foundation.core.Operation)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityQueryOperation";
        }
        return context;
    }
    
    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetQuery(java.lang.String translation);

    private void handleGetQuery1oPreCondition()
    {
    }

    private void handleGetQuery1oPostCondition()
    {
    }

    public java.lang.String getQuery(java.lang.String translation)
    {
        handleGetQuery1oPreCondition();
        java.lang.String returnValue = handleGetQuery(translation);
        handleGetQuery1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}