//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ExtendFacade
 *
 * @see org.andromda.metafacades.uml.ExtendFacade
 */
public abstract class ExtendFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ExtendFacade
{

    protected org.omg.uml.behavioralelements.usecases.Extend metaObject;

    public ExtendFacadeLogic(org.omg.uml.behavioralelements.usecases.Extend metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ExtendFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetBase1rPreCondition()
    {
    }

    private void handleGetBase1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.UseCaseFacade __getBase1r;
    private boolean __getBase1rSet = false;

    public final org.andromda.metafacades.uml.UseCaseFacade getBase()
    {
        org.andromda.metafacades.uml.UseCaseFacade getBase1r = this.__getBase1r;
        if (!this.__getBase1rSet)
        {
            handleGetBase1rPreCondition();
            Object result = this.shieldedElement(handleGetBase());
            try
            {
                getBase1r = (org.andromda.metafacades.uml.UseCaseFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetBase1rPostCondition();
            this.__getBase1r = getBase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getBase1rSet = true;
            }
        }
        return getBase1r;
    }

    protected abstract java.lang.Object handleGetBase();

    private void handleGetExtensionPoints2rPreCondition()
    {
    }

    private void handleGetExtensionPoints2rPostCondition()
    {
    }

    private java.util.List __getExtensionPoints2r;
    private boolean __getExtensionPoints2rSet = false;

    public final java.util.List getExtensionPoints()
    {
        java.util.List getExtensionPoints2r = this.__getExtensionPoints2r;
        if (!this.__getExtensionPoints2rSet)
        {
            handleGetExtensionPoints2rPreCondition();
            Object result = this.shieldedElements(handleGetExtensionPoints());
            try
            {
                getExtensionPoints2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetExtensionPoints2rPostCondition();
            this.__getExtensionPoints2r = getExtensionPoints2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtensionPoints2rSet = true;
            }
        }
        return getExtensionPoints2r;
    }

    protected abstract java.util.List handleGetExtensionPoints();

    private void handleGetExtension3rPreCondition()
    {
    }

    private void handleGetExtension3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.UseCaseFacade __getExtension3r;
    private boolean __getExtension3rSet = false;

    public final org.andromda.metafacades.uml.UseCaseFacade getExtension()
    {
        org.andromda.metafacades.uml.UseCaseFacade getExtension3r = this.__getExtension3r;
        if (!this.__getExtension3rSet)
        {
            handleGetExtension3rPreCondition();
            Object result = this.shieldedElement(handleGetExtension());
            try
            {
                getExtension3r = (org.andromda.metafacades.uml.UseCaseFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetExtension3rPostCondition();
            this.__getExtension3r = getExtension3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtension3rSet = true;
            }
        }
        return getExtension3r;
    }

    protected abstract java.lang.Object handleGetExtension();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}