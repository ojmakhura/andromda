//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.RoleFacade
 *
 * @see org.andromda.metafacades.uml.RoleFacade
 */
public abstract class RoleFacadeLogic
    extends org.andromda.metafacades.uml.ActorFacadeLogicImpl
    implements org.andromda.metafacades.uml.RoleFacade
{

    protected Object metaObject;

    public RoleFacadeLogic (Object metaObject, String context)
    {
        super ((org.omg.uml.behavioralelements.usecases.Actor)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.RoleFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.RoleFacade#isServiceReferencesPresent()
    */
    protected abstract boolean handleIsServiceReferencesPresent();

    private void handleIsServiceReferencesPresent1aPreCondition()
    {
    }

    private void handleIsServiceReferencesPresent1aPostCondition()
    {
    }

    public final boolean isServiceReferencesPresent()
    {
        boolean serviceReferencesPresent1a = false;
        handleIsServiceReferencesPresent1aPreCondition();
        serviceReferencesPresent1a = handleIsServiceReferencesPresent();
        handleIsServiceReferencesPresent1aPostCondition();
        return serviceReferencesPresent1a;
    }

   /**
    * @see org.andromda.metafacades.uml.RoleFacade#isServiceOperationReferencesPresent()
    */
    protected abstract boolean handleIsServiceOperationReferencesPresent();

    private void handleIsServiceOperationReferencesPresent2aPreCondition()
    {
    }

    private void handleIsServiceOperationReferencesPresent2aPostCondition()
    {
    }

    public final boolean isServiceOperationReferencesPresent()
    {
        boolean serviceOperationReferencesPresent2a = false;
        handleIsServiceOperationReferencesPresent2aPreCondition();
        serviceOperationReferencesPresent2a = handleIsServiceOperationReferencesPresent();
        handleIsServiceOperationReferencesPresent2aPostCondition();
        return serviceOperationReferencesPresent2a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
