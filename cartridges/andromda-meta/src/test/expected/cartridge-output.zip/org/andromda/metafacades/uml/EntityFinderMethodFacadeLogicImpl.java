package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityFinderMethodFacade.
 *
 * @see org.andromda.metafacades.uml.EntityFinderMethodFacade
 */
public class EntityFinderMethodFacadeLogicImpl
       extends EntityFinderMethodFacadeLogic
       implements org.andromda.metafacades.uml.EntityFinderMethodFacade
{
    // ---------------- constructor -------------------------------

    public EntityFinderMethodFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.EntityFinderMethodFacade#getQuery(java.lang.String)
     */
    protected java.lang.String handleGetQuery(java.lang.String translation)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

}
