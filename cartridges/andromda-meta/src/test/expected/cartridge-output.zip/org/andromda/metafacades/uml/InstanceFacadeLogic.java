//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.InstanceFacade
 *
 * @see org.andromda.metafacades.uml.InstanceFacade
 */
public abstract class InstanceFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.InstanceFacade
{

    protected org.omg.uml.behavioralelements.commonbehavior.Instance metaObject;

    public InstanceFacadeLogic(org.omg.uml.behavioralelements.commonbehavior.Instance metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.InstanceFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetClassifiers1rPreCondition()
    {
    }

    private void handleGetClassifiers1rPostCondition()
    {
    }

    private java.util.Collection __getClassifiers1r;
    private boolean __getClassifiers1rSet = false;

    public final java.util.Collection getClassifiers()
    {
        java.util.Collection getClassifiers1r = this.__getClassifiers1r;
        if (!this.__getClassifiers1rSet)
        {
            handleGetClassifiers1rPreCondition();
            Object result = this.shieldedElements(handleGetClassifiers());
            try
            {
                getClassifiers1r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetClassifiers1rPostCondition();
            this.__getClassifiers1r = getClassifiers1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getClassifiers1rSet = true;
            }
        }
        return getClassifiers1r;
    }

    protected abstract java.util.Collection handleGetClassifiers();

    private void handleGetLinkEnds2rPreCondition()
    {
    }

    private void handleGetLinkEnds2rPostCondition()
    {
    }

    private java.util.Collection __getLinkEnds2r;
    private boolean __getLinkEnds2rSet = false;

    public final java.util.Collection getLinkEnds()
    {
        java.util.Collection getLinkEnds2r = this.__getLinkEnds2r;
        if (!this.__getLinkEnds2rSet)
        {
            handleGetLinkEnds2rPreCondition();
            Object result = this.shieldedElements(handleGetLinkEnds());
            try
            {
                getLinkEnds2r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetLinkEnds2rPostCondition();
            this.__getLinkEnds2r = getLinkEnds2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLinkEnds2rSet = true;
            }
        }
        return getLinkEnds2r;
    }

    protected abstract java.util.Collection handleGetLinkEnds();

    private void handleGetOwnedInstances3rPreCondition()
    {
    }

    private void handleGetOwnedInstances3rPostCondition()
    {
    }

    private java.util.Collection __getOwnedInstances3r;
    private boolean __getOwnedInstances3rSet = false;

    public final java.util.Collection getOwnedInstances()
    {
        java.util.Collection getOwnedInstances3r = this.__getOwnedInstances3r;
        if (!this.__getOwnedInstances3rSet)
        {
            handleGetOwnedInstances3rPreCondition();
            Object result = this.shieldedElements(handleGetOwnedInstances());
            try
            {
                getOwnedInstances3r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetOwnedInstances3rPostCondition();
            this.__getOwnedInstances3r = getOwnedInstances3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOwnedInstances3rSet = true;
            }
        }
        return getOwnedInstances3r;
    }

    protected abstract java.util.Collection handleGetOwnedInstances();

    private void handleGetOwnedLinks5rPreCondition()
    {
    }

    private void handleGetOwnedLinks5rPostCondition()
    {
    }

    private java.util.Collection __getOwnedLinks5r;
    private boolean __getOwnedLinks5rSet = false;

    public final java.util.Collection getOwnedLinks()
    {
        java.util.Collection getOwnedLinks5r = this.__getOwnedLinks5r;
        if (!this.__getOwnedLinks5rSet)
        {
            handleGetOwnedLinks5rPreCondition();
            Object result = this.shieldedElements(handleGetOwnedLinks());
            try
            {
                getOwnedLinks5r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetOwnedLinks5rPostCondition();
            this.__getOwnedLinks5r = getOwnedLinks5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOwnedLinks5rSet = true;
            }
        }
        return getOwnedLinks5r;
    }

    protected abstract java.util.Collection handleGetOwnedLinks();

    private void handleGetSlots8rPreCondition()
    {
    }

    private void handleGetSlots8rPostCondition()
    {
    }

    public final java.util.Collection getSlots()
    {
        java.util.Collection getSlots8r = null;
        handleGetSlots8rPreCondition();
        Object result = this.shieldedElements(handleGetSlots());
        try
        {
            getSlots8r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSlots8rPostCondition();
        return getSlots8r;
    }

    protected abstract java.util.Collection handleGetSlots();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}