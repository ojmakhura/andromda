//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ActivityGraphFacade
 *
 * @see org.andromda.metafacades.uml.ActivityGraphFacade
 */
public abstract class ActivityGraphFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ActivityGraphFacade
{

    protected org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject;

    public ActivityGraphFacadeLogic(org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActivityGraphFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetPseudostates1rPreCondition()
    {
    }

    private void handleGetPseudostates1rPostCondition()
    {
    }

    public final java.util.Collection getPseudostates()
    {
        java.util.Collection getPseudostates1r = null;
        handleGetPseudostates1rPreCondition();
        Object result = this.shieldedElements(handleGetPseudostates());
        try
        {
            getPseudostates1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetPseudostates1rPostCondition();
        return getPseudostates1r;
    }

    protected abstract java.util.Collection handleGetPseudostates();

    private void handleGetActionStates2rPreCondition()
    {
    }

    private void handleGetActionStates2rPostCondition()
    {
    }

    public final java.util.Collection getActionStates()
    {
        java.util.Collection getActionStates2r = null;
        handleGetActionStates2rPreCondition();
        Object result = this.shieldedElements(handleGetActionStates());
        try
        {
            getActionStates2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActionStates2rPostCondition();
        return getActionStates2r;
    }

    protected abstract java.util.Collection handleGetActionStates();

    private void handleGetObjectFlowStates3rPreCondition()
    {
    }

    private void handleGetObjectFlowStates3rPostCondition()
    {
    }

    public final java.util.Collection getObjectFlowStates()
    {
        java.util.Collection getObjectFlowStates3r = null;
        handleGetObjectFlowStates3rPreCondition();
        Object result = this.shieldedElements(handleGetObjectFlowStates());
        try
        {
            getObjectFlowStates3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetObjectFlowStates3rPostCondition();
        return getObjectFlowStates3r;
    }

    protected abstract java.util.Collection handleGetObjectFlowStates();

    private void handleGetInitialStates4rPreCondition()
    {
    }

    private void handleGetInitialStates4rPostCondition()
    {
    }

    public final java.util.Collection getInitialStates()
    {
        java.util.Collection getInitialStates4r = null;
        handleGetInitialStates4rPreCondition();
        Object result = this.shieldedElements(handleGetInitialStates());
        try
        {
            getInitialStates4r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetInitialStates4rPostCondition();
        return getInitialStates4r;
    }

    protected abstract java.util.Collection handleGetInitialStates();

    private void handleGetFinalStates5rPreCondition()
    {
    }

    private void handleGetFinalStates5rPostCondition()
    {
    }

    public final java.util.Collection getFinalStates()
    {
        java.util.Collection getFinalStates5r = null;
        handleGetFinalStates5rPreCondition();
        Object result = this.shieldedElements(handleGetFinalStates());
        try
        {
            getFinalStates5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetFinalStates5rPostCondition();
        return getFinalStates5r;
    }

    protected abstract java.util.Collection handleGetFinalStates();

    private void handleGetContextElement7rPreCondition()
    {
    }

    private void handleGetContextElement7rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getContextElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getContextElement7r = null;
        handleGetContextElement7rPreCondition();
        Object result = this.shieldedElement(handleGetContextElement());
        try
        {
            getContextElement7r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetContextElement7rPostCondition();
        return getContextElement7r;
    }

    protected abstract java.lang.Object handleGetContextElement();

    private void handleGetTransitions8rPreCondition()
    {
    }

    private void handleGetTransitions8rPostCondition()
    {
    }

    public final java.util.Collection getTransitions()
    {
        java.util.Collection getTransitions8r = null;
        handleGetTransitions8rPreCondition();
        Object result = this.shieldedElements(handleGetTransitions());
        try
        {
            getTransitions8r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTransitions8rPostCondition();
        return getTransitions8r;
    }

    protected abstract java.util.Collection handleGetTransitions();

    private void handleGetUseCase9rPreCondition()
    {
    }

    private void handleGetUseCase9rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.UseCaseFacade getUseCase()
    {
        org.andromda.metafacades.uml.UseCaseFacade getUseCase9r = null;
        handleGetUseCase9rPreCondition();
        Object result = this.shieldedElement(handleGetUseCase());
        try
        {
            getUseCase9r = (org.andromda.metafacades.uml.UseCaseFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetUseCase9rPostCondition();
        return getUseCase9r;
    }

    protected abstract java.lang.Object handleGetUseCase();

    private void handleGetPartitions11rPreCondition()
    {
    }

    private void handleGetPartitions11rPostCondition()
    {
    }

    public final java.util.Collection getPartitions()
    {
        java.util.Collection getPartitions11r = null;
        handleGetPartitions11rPreCondition();
        Object result = this.shieldedElements(handleGetPartitions());
        try
        {
            getPartitions11r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetPartitions11rPostCondition();
        return getPartitions11r;
    }

    protected abstract java.util.Collection handleGetPartitions();

    private void handleGetInitialTransition12rPreCondition()
    {
    }

    private void handleGetInitialTransition12rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.TransitionFacade __getInitialTransition12r;
    private boolean __getInitialTransition12rSet = false;

    public final org.andromda.metafacades.uml.TransitionFacade getInitialTransition()
    {
        org.andromda.metafacades.uml.TransitionFacade getInitialTransition12r = this.__getInitialTransition12r;
        if (!this.__getInitialTransition12rSet)
        {
            handleGetInitialTransition12rPreCondition();
            Object result = this.shieldedElement(handleGetInitialTransition());
            try
            {
                getInitialTransition12r = (org.andromda.metafacades.uml.TransitionFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialTransition12rPostCondition();
            this.__getInitialTransition12r = getInitialTransition12r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialTransition12rSet = true;
            }
        }
        return getInitialTransition12r;
    }

    protected abstract java.lang.Object handleGetInitialTransition();

    private void handleGetInitialState13rPreCondition()
    {
    }

    private void handleGetInitialState13rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.PseudostateFacade __getInitialState13r;
    private boolean __getInitialState13rSet = false;

    public final org.andromda.metafacades.uml.PseudostateFacade getInitialState()
    {
        org.andromda.metafacades.uml.PseudostateFacade getInitialState13r = this.__getInitialState13r;
        if (!this.__getInitialState13rSet)
        {
            handleGetInitialState13rPreCondition();
            Object result = this.shieldedElement(handleGetInitialState());
            try
            {
                getInitialState13r = (org.andromda.metafacades.uml.PseudostateFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialState13rPostCondition();
            this.__getInitialState13r = getInitialState13r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialState13rSet = true;
            }
        }
        return getInitialState13r;
    }

    protected abstract java.lang.Object handleGetInitialState();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}