//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ActivityGraphFacade
 *
 * @see org.andromda.metafacades.uml.ActivityGraphFacade
 */
public abstract class ActivityGraphFacadeLogic
    extends org.andromda.metafacades.uml.StateMachineFacadeLogicImpl
    implements org.andromda.metafacades.uml.ActivityGraphFacade
{

    protected org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject;

    public ActivityGraphFacadeLogic(org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActivityGraphFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetActionStates1rPreCondition()
    {
    }

    private void handleGetActionStates1rPostCondition()
    {
    }

    public final java.util.Collection getActionStates()
    {
        java.util.Collection getActionStates1r = null;
        handleGetActionStates1rPreCondition();
        Object result = this.shieldedElements(handleGetActionStates());
        try
        {
            getActionStates1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActionStates1rPostCondition();
        return getActionStates1r;
    }

    protected abstract java.util.Collection handleGetActionStates();

    private void handleGetObjectFlowStates2rPreCondition()
    {
    }

    private void handleGetObjectFlowStates2rPostCondition()
    {
    }

    public final java.util.Collection getObjectFlowStates()
    {
        java.util.Collection getObjectFlowStates2r = null;
        handleGetObjectFlowStates2rPreCondition();
        Object result = this.shieldedElements(handleGetObjectFlowStates());
        try
        {
            getObjectFlowStates2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetObjectFlowStates2rPostCondition();
        return getObjectFlowStates2r;
    }

    protected abstract java.util.Collection handleGetObjectFlowStates();

    private void handleGetUseCase3rPreCondition()
    {
    }

    private void handleGetUseCase3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.UseCaseFacade getUseCase()
    {
        org.andromda.metafacades.uml.UseCaseFacade getUseCase3r = null;
        handleGetUseCase3rPreCondition();
        Object result = this.shieldedElement(handleGetUseCase());
        try
        {
            getUseCase3r = (org.andromda.metafacades.uml.UseCaseFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetUseCase3rPostCondition();
        return getUseCase3r;
    }

    protected abstract java.lang.Object handleGetUseCase();

    private void handleGetPartitions4rPreCondition()
    {
    }

    private void handleGetPartitions4rPostCondition()
    {
    }

    public final java.util.Collection getPartitions()
    {
        java.util.Collection getPartitions4r = null;
        handleGetPartitions4rPreCondition();
        Object result = this.shieldedElements(handleGetPartitions());
        try
        {
            getPartitions4r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetPartitions4rPostCondition();
        return getPartitions4r;
    }

    protected abstract java.util.Collection handleGetPartitions();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}