//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.InterfaceFacade
 *
 * @see org.andromda.metafacades.uml.InterfaceFacade
 */
public abstract class InterfaceFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.InterfaceFacade
{

    protected org.omg.uml.foundation.core.Interface metaObject;

    public InterfaceFacadeLogic(org.omg.uml.foundation.core.Interface metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.InterfaceFacade";
        }
        return context;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}