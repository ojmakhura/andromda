//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AssociationEndFacade
 *
 * @see org.andromda.metafacades.uml.AssociationEndFacade
 */
public abstract class AssociationEndFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.AssociationEndFacade
{

    protected org.omg.uml.foundation.core.AssociationEnd metaObject;

    public AssociationEndFacadeLogic(org.omg.uml.foundation.core.AssociationEnd metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AssociationEndFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2One()
    */
    protected abstract boolean handleIsOne2One();

    private void handleIsOne2One1aPreCondition()
    {
    }

    private void handleIsOne2One1aPostCondition()
    {
    }

    private boolean __one2One1a;
    private boolean __one2One1aSet = false;

    public final boolean isOne2One()
    {
        boolean one2One1a = this.__one2One1a;
        if (!this.__one2One1aSet)
        {
            handleIsOne2One1aPreCondition();
            one2One1a = handleIsOne2One();
            handleIsOne2One1aPostCondition();
            this.__one2One1a = one2One1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__one2One1aSet = true;
            }
        }
        return one2One1a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2Many()
    */
    protected abstract boolean handleIsOne2Many();

    private void handleIsOne2Many2aPreCondition()
    {
    }

    private void handleIsOne2Many2aPostCondition()
    {
    }

    private boolean __one2Many2a;
    private boolean __one2Many2aSet = false;

    public final boolean isOne2Many()
    {
        boolean one2Many2a = this.__one2Many2a;
        if (!this.__one2Many2aSet)
        {
            handleIsOne2Many2aPreCondition();
            one2Many2a = handleIsOne2Many();
            handleIsOne2Many2aPostCondition();
            this.__one2Many2a = one2Many2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__one2Many2aSet = true;
            }
        }
        return one2Many2a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2One()
    */
    protected abstract boolean handleIsMany2One();

    private void handleIsMany2One3aPreCondition()
    {
    }

    private void handleIsMany2One3aPostCondition()
    {
    }

    private boolean __many2One3a;
    private boolean __many2One3aSet = false;

    public final boolean isMany2One()
    {
        boolean many2One3a = this.__many2One3a;
        if (!this.__many2One3aSet)
        {
            handleIsMany2One3aPreCondition();
            many2One3a = handleIsMany2One();
            handleIsMany2One3aPostCondition();
            this.__many2One3a = many2One3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__many2One3aSet = true;
            }
        }
        return many2One3a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2Many()
    */
    protected abstract boolean handleIsMany2Many();

    private void handleIsMany2Many4aPreCondition()
    {
    }

    private void handleIsMany2Many4aPostCondition()
    {
    }

    private boolean __many2Many4a;
    private boolean __many2Many4aSet = false;

    public final boolean isMany2Many()
    {
        boolean many2Many4a = this.__many2Many4a;
        if (!this.__many2Many4aSet)
        {
            handleIsMany2Many4aPreCondition();
            many2Many4a = handleIsMany2Many();
            handleIsMany2Many4aPostCondition();
            this.__many2Many4a = many2Many4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__many2Many4aSet = true;
            }
        }
        return many2Many4a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isAggregation()
    */
    protected abstract boolean handleIsAggregation();

    private void handleIsAggregation5aPreCondition()
    {
    }

    private void handleIsAggregation5aPostCondition()
    {
    }

    private boolean __aggregation5a;
    private boolean __aggregation5aSet = false;

    public final boolean isAggregation()
    {
        boolean aggregation5a = this.__aggregation5a;
        if (!this.__aggregation5aSet)
        {
            handleIsAggregation5aPreCondition();
            aggregation5a = handleIsAggregation();
            handleIsAggregation5aPostCondition();
            this.__aggregation5a = aggregation5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__aggregation5aSet = true;
            }
        }
        return aggregation5a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isComposition()
    */
    protected abstract boolean handleIsComposition();

    private void handleIsComposition6aPreCondition()
    {
    }

    private void handleIsComposition6aPostCondition()
    {
    }

    private boolean __composition6a;
    private boolean __composition6aSet = false;

    public final boolean isComposition()
    {
        boolean composition6a = this.__composition6a;
        if (!this.__composition6aSet)
        {
            handleIsComposition6aPreCondition();
            composition6a = handleIsComposition();
            handleIsComposition6aPostCondition();
            this.__composition6a = composition6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__composition6aSet = true;
            }
        }
        return composition6a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isOrdered()
    */
    protected abstract boolean handleIsOrdered();

    private void handleIsOrdered7aPreCondition()
    {
    }

    private void handleIsOrdered7aPostCondition()
    {
    }

    private boolean __ordered7a;
    private boolean __ordered7aSet = false;

    public final boolean isOrdered()
    {
        boolean ordered7a = this.__ordered7a;
        if (!this.__ordered7aSet)
        {
            handleIsOrdered7aPreCondition();
            ordered7a = handleIsOrdered();
            handleIsOrdered7aPostCondition();
            this.__ordered7a = ordered7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__ordered7aSet = true;
            }
        }
        return ordered7a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isReadOnly()
    */
    protected abstract boolean handleIsReadOnly();

    private void handleIsReadOnly8aPreCondition()
    {
    }

    private void handleIsReadOnly8aPostCondition()
    {
    }

    private boolean __readOnly8a;
    private boolean __readOnly8aSet = false;

    public final boolean isReadOnly()
    {
        boolean readOnly8a = this.__readOnly8a;
        if (!this.__readOnly8aSet)
        {
            handleIsReadOnly8aPreCondition();
            readOnly8a = handleIsReadOnly();
            handleIsReadOnly8aPostCondition();
            this.__readOnly8a = readOnly8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__readOnly8aSet = true;
            }
        }
        return readOnly8a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isNavigable()
    */
    protected abstract boolean handleIsNavigable();

    private void handleIsNavigable9aPreCondition()
    {
    }

    private void handleIsNavigable9aPostCondition()
    {
    }

    private boolean __navigable9a;
    private boolean __navigable9aSet = false;

    public final boolean isNavigable()
    {
        boolean navigable9a = this.__navigable9a;
        if (!this.__navigable9aSet)
        {
            handleIsNavigable9aPreCondition();
            navigable9a = handleIsNavigable();
            handleIsNavigable9aPostCondition();
            this.__navigable9a = navigable9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__navigable9aSet = true;
            }
        }
        return navigable9a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName10aPreCondition()
    {
    }

    private void handleGetGetterName10aPostCondition()
    {
    }

    private java.lang.String __getterName10a;
    private boolean __getterName10aSet = false;

    public final java.lang.String getGetterName()
    {
        java.lang.String getterName10a = this.__getterName10a;
        if (!this.__getterName10aSet)
        {
            handleGetGetterName10aPreCondition();
            getterName10a = handleGetGetterName();
            handleGetGetterName10aPostCondition();
            this.__getterName10a = getterName10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterName10aSet = true;
            }
        }
        return getterName10a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName11aPreCondition()
    {
    }

    private void handleGetSetterName11aPostCondition()
    {
    }

    private java.lang.String __setterName11a;
    private boolean __setterName11aSet = false;

    public final java.lang.String getSetterName()
    {
        java.lang.String setterName11a = this.__setterName11a;
        if (!this.__setterName11aSet)
        {
            handleGetSetterName11aPreCondition();
            setterName11a = handleGetSetterName();
            handleGetSetterName11aPostCondition();
            this.__setterName11a = setterName11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__setterName11aSet = true;
            }
        }
        return setterName11a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterSetterTypeName()
    */
    protected abstract java.lang.String handleGetGetterSetterTypeName();

    private void handleGetGetterSetterTypeName12aPreCondition()
    {
    }

    private void handleGetGetterSetterTypeName12aPostCondition()
    {
    }

    private java.lang.String __getterSetterTypeName12a;
    private boolean __getterSetterTypeName12aSet = false;

    public final java.lang.String getGetterSetterTypeName()
    {
        java.lang.String getterSetterTypeName12a = this.__getterSetterTypeName12a;
        if (!this.__getterSetterTypeName12aSet)
        {
            handleGetGetterSetterTypeName12aPreCondition();
            getterSetterTypeName12a = handleGetGetterSetterTypeName();
            handleGetGetterSetterTypeName12aPostCondition();
            this.__getterSetterTypeName12a = getterSetterTypeName12a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterSetterTypeName12aSet = true;
            }
        }
        return getterSetterTypeName12a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany()
    */
    protected abstract boolean handleIsMany();

    private void handleIsMany13aPreCondition()
    {
    }

    private void handleIsMany13aPostCondition()
    {
    }

    private boolean __many13a;
    private boolean __many13aSet = false;

    public final boolean isMany()
    {
        boolean many13a = this.__many13a;
        if (!this.__many13aSet)
        {
            handleIsMany13aPreCondition();
            many13a = handleIsMany();
            handleIsMany13aPostCondition();
            this.__many13a = many13a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__many13aSet = true;
            }
        }
        return many13a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired14aPreCondition()
    {
    }

    private void handleIsRequired14aPostCondition()
    {
    }

    private boolean __required14a;
    private boolean __required14aSet = false;

    public final boolean isRequired()
    {
        boolean required14a = this.__required14a;
        if (!this.__required14aSet)
        {
            handleIsRequired14aPreCondition();
            required14a = handleIsRequired();
            handleIsRequired14aPostCondition();
            this.__required14a = required14a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__required14aSet = true;
            }
        }
        return required14a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationEndFacade#isChild()
    */
    protected abstract boolean handleIsChild();

    private void handleIsChild15aPreCondition()
    {
    }

    private void handleIsChild15aPostCondition()
    {
    }

    private boolean __child15a;
    private boolean __child15aSet = false;

    public final boolean isChild()
    {
        boolean child15a = this.__child15a;
        if (!this.__child15aSet)
        {
            handleIsChild15aPreCondition();
            child15a = handleIsChild();
            handleIsChild15aPostCondition();
            this.__child15a = child15a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__child15aSet = true;
            }
        }
        return child15a;
    }

    // ------------- associations ------------------

    private void handleGetOtherEnd1rPreCondition()
    {
    }

    private void handleGetOtherEnd1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd()
    {
        org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd1r = null;
        handleGetOtherEnd1rPreCondition();
        Object result = this.shieldedElement(handleGetOtherEnd());
        try
        {
            getOtherEnd1r = (org.andromda.metafacades.uml.AssociationEndFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOtherEnd1rPostCondition();
        return getOtherEnd1r;
    }

    protected abstract java.lang.Object handleGetOtherEnd();

    private void handleGetAssociation4rPreCondition()
    {
    }

    private void handleGetAssociation4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.AssociationFacade getAssociation()
    {
        org.andromda.metafacades.uml.AssociationFacade getAssociation4r = null;
        handleGetAssociation4rPreCondition();
        Object result = this.shieldedElement(handleGetAssociation());
        try
        {
            getAssociation4r = (org.andromda.metafacades.uml.AssociationFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAssociation4rPostCondition();
        return getAssociation4r;
    }

    protected abstract java.lang.Object handleGetAssociation();

    private void handleGetType5rPreCondition()
    {
    }

    private void handleGetType5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType5r = null;
        handleGetType5rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType5r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType5rPostCondition();
        return getType5r;
    }

    protected abstract java.lang.Object handleGetType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"type"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "org::andromda::metafacades::uml::AssociationEndFacade::association end needs a type",
                        "Each association end needs a type, you cannot leave the type unspecified."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}