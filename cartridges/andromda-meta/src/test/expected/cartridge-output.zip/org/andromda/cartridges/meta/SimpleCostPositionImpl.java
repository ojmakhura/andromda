// license-header java merge-point
/**
 * This is only generated once by PSMmetaclassImpl.vsl! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see org.andromda.cartridges.meta.SimpleCostPosition
 */
public class SimpleCostPositionImpl
    extends org.andromda.cartridges.meta.SimpleCostPosition
{
    /**
     * Public default constructor for SimpleCostPositionImpl
     */
    public SimpleCostPositionImpl()
    {
        super();
    }

    /**
     * Public constructor for SimpleCostPositionImpl with all properties.
     * @param nameIn java.lang.String 
     * @param priceIn double 
     */
    public SimpleCostPositionImpl(java.lang.String name, double price)
    {
        super(name, price);
    }

    /**
     * Copy-constructor from other SimpleCostPosition
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public SimpleCostPositionImpl(SimpleCostPosition otherBean)
    {
        this(otherBean.getName(), otherBean.getPrice());
    }

    /**
     * @see org.andromda.cartridges.meta.SimpleCostPosition#calcTotal()
     */
    public double calcTotal()
    {
        // TODO implement public double calcTotal()
        throw new UnsupportedOperationException("org.andromda.cartridges.meta.SimpleCostPosition.calcTotal() Not implemented!");
    }

}
