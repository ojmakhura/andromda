//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAttributeFacade
 *
 * @see org.andromda.metafacades.uml.EntityAttributeFacade
 */
public abstract class EntityAttributeFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.EntityAttributeFacade
{
    protected Object metaObject;
    private org.andromda.metafacades.uml.AttributeFacade super_;

    public EntityAttributeFacadeLogic (Object metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.AttributeFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.AttributeFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.EntityAttributeFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    public abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName1oPreCondition()
    {
    }

    private void handleGetColumnName1oPostCondition()
    {
    }

    public final java.lang.String getColumnName()
    {
        handleGetColumnName1oPreCondition();
        java.lang.String returnValue = handleGetColumnName();
        handleGetColumnName1oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsIdentifier();

    private void handleIsIdentifier2oPreCondition()
    {
    }

    private void handleIsIdentifier2oPostCondition()
    {
    }

    public final boolean isIdentifier()
    {
        handleIsIdentifier2oPreCondition();
        boolean returnValue = handleIsIdentifier();
        handleIsIdentifier2oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetJdbcType();

    private void handleGetJdbcType3oPreCondition()
    {
    }

    private void handleGetJdbcType3oPostCondition()
    {
    }

    public final java.lang.String getJdbcType()
    {
        handleGetJdbcType3oPreCondition();
        java.lang.String returnValue = handleGetJdbcType();
        handleGetJdbcType3oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetSqlType();

    private void handleGetSqlType4oPreCondition()
    {
    }

    private void handleGetSqlType4oPostCondition()
    {
    }

    public final java.lang.String getSqlType()
    {
        handleGetSqlType4oPreCondition();
        java.lang.String returnValue = handleGetSqlType();
        handleGetSqlType4oPostCondition();
        return returnValue;
    }

    public abstract org.andromda.core.mapping.Mappings handleGetSqlMappings();

    private void handleGetSqlMappings5oPreCondition()
    {
    }

    private void handleGetSqlMappings5oPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getSqlMappings()
    {
        handleGetSqlMappings5oPreCondition();
        org.andromda.core.mapping.Mappings returnValue = handleGetSqlMappings();
        handleGetSqlMappings5oPostCondition();
        return returnValue;
    }

    public abstract org.andromda.core.mapping.Mappings handleGetJdbcMappings();

    private void handleGetJdbcMappings6oPreCondition()
    {
    }

    private void handleGetJdbcMappings6oPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getJdbcMappings()
    {
        handleGetJdbcMappings6oPreCondition();
        org.andromda.core.mapping.Mappings returnValue = handleGetJdbcMappings();
        handleGetJdbcMappings6oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetColumnLength();

    private void handleGetColumnLength7oPreCondition()
    {
    }

    private void handleGetColumnLength7oPostCondition()
    {
    }

    public final java.lang.String getColumnLength()
    {
        handleGetColumnLength7oPreCondition();
        java.lang.String returnValue = handleGetColumnLength();
        handleGetColumnLength7oPostCondition();
        return returnValue;
    }

    // ----------- delegates to org.andromda.metafacades.uml.AttributeFacade ------------
    // from org.andromda.metafacades.uml.AttributeFacade
	public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
	{
        return super_.findTaggedValue(name, follow);
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public java.lang.String getDefaultValue()
	{
        return super_.getDefaultValue();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public java.lang.String getGetterName()
	{
        return super_.getGetterName();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public org.andromda.metafacades.uml.ClassifierFacade getOwner()
	{
        return super_.getOwner();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public java.lang.String getSetterName()
	{
        return super_.getSetterName();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public org.andromda.metafacades.uml.ClassifierFacade getType()
	{
        return super_.getType();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public boolean isMany()
	{
        return super_.isMany();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public boolean isReadOnly()
	{
        return super_.isReadOnly();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public boolean isRequired()
	{
        return super_.isRequired();
	}
	
    // from org.andromda.metafacades.uml.AttributeFacade
	public boolean isStatic()
	{
        return super_.isStatic();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
