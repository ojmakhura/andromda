package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ObjectFlowStateFacade.
 *
 * @see org.andromda.metafacades.uml.ObjectFlowStateFacade
 */
public class ObjectFlowStateFacadeLogicImpl
    extends ObjectFlowStateFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ObjectFlowStateFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ObjectFlowState metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ObjectFlowStateFacade#getType()
     */
    protected java.lang.Object handleGetObjectFlowStateFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

}