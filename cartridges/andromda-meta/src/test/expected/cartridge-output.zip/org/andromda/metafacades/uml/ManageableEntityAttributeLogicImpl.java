package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntityAttribute.
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public class ManageableEntityAttributeLogicImpl
    extends ManageableEntityAttributeLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityAttributeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableGetterName()
     */
    protected java.lang.String handleGetManageableGetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableName()
     */
    protected java.lang.String handleGetManageableName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableSetterName()
     */
    protected java.lang.String handleGetManageableSetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

}