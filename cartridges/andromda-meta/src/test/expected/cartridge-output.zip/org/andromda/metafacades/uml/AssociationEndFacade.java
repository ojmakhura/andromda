//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AssociationEndFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.AssociationFacade getAssociation();

   /**
    * 
    */
    public java.lang.String getGetterName();

   /**
    * 
    */
    public java.lang.String getGetterSetterTypeName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd();

   /**
    * 
    */
    public java.lang.String getSetterName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * 
    */
    public boolean isAggregation();

   /**
    * 
    */
    public boolean isComposition();

   /**
    * 
    */
    public boolean isMany();

   /**
    * 
    */
    public boolean isMany2Many();

   /**
    * 
    */
    public boolean isMany2One();

   /**
    * 
    */
    public boolean isNavigable();

   /**
    * 
    */
    public boolean isOne2Many();

   /**
    * 
    */
    public boolean isOne2One();

   /**
    * 
    */
    public boolean isOrdered();

   /**
    * 
    */
    public boolean isReadOnly();

   /**
    * 
    */
    public boolean isRequired();

}
