package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActivityGraphFacade.
 *
 * @see org.andromda.metafacades.uml.ActivityGraphFacade
 */
public class ActivityGraphFacadeLogicImpl
       extends ActivityGraphFacadeLogic
       implements org.andromda.metafacades.uml.ActivityGraphFacade
{
    // ---------------- constructor -------------------------------

    public ActivityGraphFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getPseudostates()
     */
    protected java.util.Collection handleGetPseudostates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getActionStates()
     */
    protected java.util.Collection handleGetActionStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getObjectFlowStates()
     */
    protected java.util.Collection handleGetObjectFlowStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getInitialStates()
     */
    protected java.util.Collection handleGetInitialStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getFinalStates()
     */
    protected java.util.Collection handleGetFinalStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getContextElement()
     */
    protected java.lang.Object handleGetContextElement()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getTransitions()
     */
    protected java.util.Collection handleGetTransitions()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getUseCase()
     */
    protected java.lang.Object handleGetUseCase()
    {
        // TODO: add your implementation here!
        return null;
    }

}
