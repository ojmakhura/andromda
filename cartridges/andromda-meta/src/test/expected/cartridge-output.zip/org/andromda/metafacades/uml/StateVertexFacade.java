//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface StateVertexFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph();

   /**
    * 
    */
    public java.util.Collection getIncoming();

   /**
    * 
    */
    public java.util.Collection getOutgoing();

}
