//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.Service
 *
 * @see org.andromda.metafacades.uml.Service
 */
public abstract class ServiceLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.Service
{

    protected Object metaObject;

    public ServiceLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Service";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetServiceReferences1rPreCondition()
    {
    }

    private void handleGetServiceReferences1rPostCondition()
    {
    }

    public final java.util.Collection getServiceReferences()
    {
        java.util.Collection getServiceReferences1r = null;
        handleGetServiceReferences1rPreCondition();
        Object result = this.shieldedElements(handleGetServiceReferences());
        try
        {
            getServiceReferences1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetServiceReferences1rPostCondition();
        return getServiceReferences1r;
    }

    protected abstract java.util.Collection handleGetServiceReferences();

    private void handleGetEntityReferences2rPreCondition()
    {
    }

    private void handleGetEntityReferences2rPostCondition()
    {
    }

    public final java.util.Collection getEntityReferences()
    {
        java.util.Collection getEntityReferences2r = null;
        handleGetEntityReferences2rPreCondition();
        Object result = this.shieldedElements(handleGetEntityReferences());
        try
        {
            getEntityReferences2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEntityReferences2rPostCondition();
        return getEntityReferences2r;
    }

    protected abstract java.util.Collection handleGetEntityReferences();

    private void handleGetRoles3rPreCondition()
    {
    }

    private void handleGetRoles3rPostCondition()
    {
    }

    public final java.util.Collection getRoles()
    {
        java.util.Collection getRoles3r = null;
        handleGetRoles3rPreCondition();
        Object result = this.shieldedElements(handleGetRoles());
        try
        {
            getRoles3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetRoles3rPostCondition();
        return getRoles3r;
    }

    protected abstract java.util.Collection handleGetRoles();

    private void handleGetAllRoles4rPreCondition()
    {
    }

    private void handleGetAllRoles4rPostCondition()
    {
    }

    public final java.util.Collection getAllRoles()
    {
        java.util.Collection getAllRoles4r = null;
        handleGetAllRoles4rPreCondition();
        Object result = this.shieldedElements(handleGetAllRoles());
        try
        {
            getAllRoles4r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllRoles4rPostCondition();
        return getAllRoles4r;
    }

    protected abstract java.util.Collection handleGetAllRoles();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization")))).booleanValue()?org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization") instanceof org.andromda.metafacades.uml.Service:true)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "A service can only generalize another service."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations")))).booleanValue()?org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(object instanceof org.andromda.metafacades.uml.Service)).booleanValue();}}):true)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "A service can only specialize another service."));
        }
    }
}