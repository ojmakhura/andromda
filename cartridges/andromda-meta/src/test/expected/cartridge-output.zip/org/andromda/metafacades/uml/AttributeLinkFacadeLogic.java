//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AttributeLinkFacade
 *
 * @see org.andromda.metafacades.uml.AttributeLinkFacade
 */
public abstract class AttributeLinkFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.AttributeLinkFacade
{

    protected org.omg.uml.behavioralelements.commonbehavior.AttributeLink metaObject;

    public AttributeLinkFacadeLogic(org.omg.uml.behavioralelements.commonbehavior.AttributeLink metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AttributeLinkFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetAttribute1rPreCondition()
    {
    }

    private void handleGetAttribute1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.AttributeFacade __getAttribute1r;
    private boolean __getAttribute1rSet = false;

    public final org.andromda.metafacades.uml.AttributeFacade getAttribute()
    {
        org.andromda.metafacades.uml.AttributeFacade getAttribute1r = this.__getAttribute1r;
        if (!this.__getAttribute1rSet)
        {
            handleGetAttribute1rPreCondition();
            Object result = this.shieldedElement(handleGetAttribute());
            try
            {
                getAttribute1r = (org.andromda.metafacades.uml.AttributeFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAttribute1rPostCondition();
            this.__getAttribute1r = getAttribute1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAttribute1rSet = true;
            }
        }
        return getAttribute1r;
    }

    protected abstract java.lang.Object handleGetAttribute();

    private void handleGetLinkEnd2rPreCondition()
    {
    }

    private void handleGetLinkEnd2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.LinkEndFacade __getLinkEnd2r;
    private boolean __getLinkEnd2rSet = false;

    public final org.andromda.metafacades.uml.LinkEndFacade getLinkEnd()
    {
        org.andromda.metafacades.uml.LinkEndFacade getLinkEnd2r = this.__getLinkEnd2r;
        if (!this.__getLinkEnd2rSet)
        {
            handleGetLinkEnd2rPreCondition();
            Object result = this.shieldedElement(handleGetLinkEnd());
            try
            {
                getLinkEnd2r = (org.andromda.metafacades.uml.LinkEndFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetLinkEnd2rPostCondition();
            this.__getLinkEnd2r = getLinkEnd2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLinkEnd2rSet = true;
            }
        }
        return getLinkEnd2r;
    }

    protected abstract java.lang.Object handleGetLinkEnd();

    private void handleGetInstance3rPreCondition()
    {
    }

    private void handleGetInstance3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.InstanceFacade __getInstance3r;
    private boolean __getInstance3rSet = false;

    public final org.andromda.metafacades.uml.InstanceFacade getInstance()
    {
        org.andromda.metafacades.uml.InstanceFacade getInstance3r = this.__getInstance3r;
        if (!this.__getInstance3rSet)
        {
            handleGetInstance3rPreCondition();
            Object result = this.shieldedElement(handleGetInstance());
            try
            {
                getInstance3r = (org.andromda.metafacades.uml.InstanceFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInstance3rPostCondition();
            this.__getInstance3r = getInstance3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInstance3rSet = true;
            }
        }
        return getInstance3r;
    }

    protected abstract java.lang.Object handleGetInstance();

    private void handleGetValue4rPreCondition()
    {
    }

    private void handleGetValue4rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.InstanceFacade __getValue4r;
    private boolean __getValue4rSet = false;

    public final org.andromda.metafacades.uml.InstanceFacade getValue()
    {
        org.andromda.metafacades.uml.InstanceFacade getValue4r = this.__getValue4r;
        if (!this.__getValue4rSet)
        {
            handleGetValue4rPreCondition();
            Object result = this.shieldedElement(handleGetValue());
            try
            {
                getValue4r = (org.andromda.metafacades.uml.InstanceFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetValue4rPostCondition();
            this.__getValue4r = getValue4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getValue4rSet = true;
            }
        }
        return getValue4r;
    }

    protected abstract java.lang.Object handleGetValue();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}