//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.OperationFacade
 *
 * @see org.andromda.metafacades.uml.OperationFacade
 */
public abstract class OperationFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.OperationFacade
{
    protected org.omg.uml.foundation.core.Operation metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public OperationFacadeLogic (org.omg.uml.foundation.core.Operation metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.OperationFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getSignature()
    */
    protected abstract java.lang.String handleGetSignature();

    private void handleGetSignature1aPreCondition()
    {
    }

    private void handleGetSignature1aPostCondition()
    {
    }

    public final java.lang.String getSignature()
    {
        handleGetSignature1aPreCondition();
        java.lang.String signature1a = handleGetSignature();
        handleGetSignature1aPostCondition();
        return signature1a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getCall()
    */
    protected abstract java.lang.String handleGetCall();

    private void handleGetCall2aPreCondition()
    {
    }

    private void handleGetCall2aPostCondition()
    {
    }

    public final java.lang.String getCall()
    {
        handleGetCall2aPreCondition();
        java.lang.String call2a = handleGetCall();
        handleGetCall2aPostCondition();
        return call2a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getTypedArgumentList()
    */
    protected abstract java.lang.String handleGetTypedArgumentList();

    private void handleGetTypedArgumentList3aPreCondition()
    {
    }

    private void handleGetTypedArgumentList3aPostCondition()
    {
    }

    public final java.lang.String getTypedArgumentList()
    {
        handleGetTypedArgumentList3aPreCondition();
        java.lang.String typedArgumentList3a = handleGetTypedArgumentList();
        handleGetTypedArgumentList3aPostCondition();
        return typedArgumentList3a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#isStatic()
    */
    protected abstract boolean handleIsStatic();

    private void handleIsStatic4aPreCondition()
    {
    }

    private void handleIsStatic4aPostCondition()
    {
    }

    public final boolean isStatic()
    {
        handleIsStatic4aPreCondition();
        boolean static4a = handleIsStatic();
        handleIsStatic4aPostCondition();
        return static4a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#isAbstract()
    */
    protected abstract boolean handleIsAbstract();

    private void handleIsAbstract5aPreCondition()
    {
    }

    private void handleIsAbstract5aPostCondition()
    {
    }

    public final boolean isAbstract()
    {
        handleIsAbstract5aPreCondition();
        boolean abstract5a = handleIsAbstract();
        handleIsAbstract5aPostCondition();
        return abstract5a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getExceptionList()
    */
    protected abstract java.lang.String handleGetExceptionList();

    private void handleGetExceptionList6aPreCondition()
    {
    }

    private void handleGetExceptionList6aPostCondition()
    {
    }

    public final java.lang.String getExceptionList()
    {
        handleGetExceptionList6aPreCondition();
        java.lang.String exceptionList6a = handleGetExceptionList();
        handleGetExceptionList6aPostCondition();
        return exceptionList6a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getExceptions()
    */
    protected abstract java.util.Collection handleGetExceptions();

    private void handleGetExceptions7aPreCondition()
    {
    }

    private void handleGetExceptions7aPostCondition()
    {
    }

    public final java.util.Collection getExceptions()
    {
        handleGetExceptions7aPreCondition();
        java.util.Collection exceptions7a = handleGetExceptions();
        handleGetExceptions7aPostCondition();
        return exceptions7a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#isReturnTypePresent()
    */
    protected abstract boolean handleIsReturnTypePresent();

    private void handleIsReturnTypePresent8aPreCondition()
    {
    }

    private void handleIsReturnTypePresent8aPostCondition()
    {
    }

    public final boolean isReturnTypePresent()
    {
        handleIsReturnTypePresent8aPreCondition();
        boolean returnTypePresent8a = handleIsReturnTypePresent();
        handleIsReturnTypePresent8aPostCondition();
        return returnTypePresent8a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getArguments()
    */
    protected abstract java.util.Collection handleGetArguments();

    private void handleGetArguments9aPreCondition()
    {
    }

    private void handleGetArguments9aPostCondition()
    {
    }

    public final java.util.Collection getArguments()
    {
        handleGetArguments9aPreCondition();
        java.util.Collection arguments9a = handleGetArguments();
        handleGetArguments9aPostCondition();
        return arguments9a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#isExceptionsPresent()
    */
    protected abstract boolean handleIsExceptionsPresent();

    private void handleIsExceptionsPresent10aPreCondition()
    {
    }

    private void handleIsExceptionsPresent10aPostCondition()
    {
    }

    public final boolean isExceptionsPresent()
    {
        handleIsExceptionsPresent10aPreCondition();
        boolean exceptionsPresent10a = handleIsExceptionsPresent();
        handleIsExceptionsPresent10aPostCondition();
        return exceptionsPresent10a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getArgumentNames()
    */
    protected abstract java.lang.String handleGetArgumentNames();

    private void handleGetArgumentNames11aPreCondition()
    {
    }

    private void handleGetArgumentNames11aPostCondition()
    {
    }

    public final java.lang.String getArgumentNames()
    {
        handleGetArgumentNames11aPreCondition();
        java.lang.String argumentNames11a = handleGetArgumentNames();
        handleGetArgumentNames11aPostCondition();
        return argumentNames11a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#getArgumentTypeNames()
    */
    protected abstract java.lang.String handleGetArgumentTypeNames();

    private void handleGetArgumentTypeNames12aPreCondition()
    {
    }

    private void handleGetArgumentTypeNames12aPostCondition()
    {
    }

    public final java.lang.String getArgumentTypeNames()
    {
        handleGetArgumentTypeNames12aPreCondition();
        java.lang.String argumentTypeNames12a = handleGetArgumentTypeNames();
        handleGetArgumentTypeNames12aPostCondition();
        return argumentTypeNames12a;
    }

   /**
	* @see org.andromda.metafacades.uml.OperationFacade#isQuery()
    */
    protected abstract boolean handleIsQuery();

    private void handleIsQuery13aPreCondition()
    {
    }

    private void handleIsQuery13aPostCondition()
    {
    }

    public final boolean isQuery()
    {
        handleIsQuery13aPreCondition();
        boolean query13a = handleIsQuery();
        handleIsQuery13aPostCondition();
        return query13a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(name, follow);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetExceptionList(java.lang.String initialExceptions);

    private void handleGetExceptionList2oPreCondition()
    {
    }

    private void handleGetExceptionList2oPostCondition()
    {
    }

    public java.lang.String getExceptionList(java.lang.String initialExceptions)
    {
        handleGetExceptionList2oPreCondition();
        java.lang.String returnValue = handleGetExceptionList(initialExceptions);
        handleGetExceptionList2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetSignature(boolean withArgumentNames);

    private void handleGetSignature3oPreCondition()
    {
    }

    private void handleGetSignature3oPostCondition()
    {
    }

    public java.lang.String getSignature(boolean withArgumentNames)
    {
        handleGetSignature3oPreCondition();
        java.lang.String returnValue = handleGetSignature(withArgumentNames);
        handleGetSignature3oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetTypedArgumentList(java.lang.String modifier);

    private void handleGetTypedArgumentList4oPreCondition()
    {
    }

    private void handleGetTypedArgumentList4oPostCondition()
    {
    }

    public java.lang.String getTypedArgumentList(java.lang.String modifier)
    {
        handleGetTypedArgumentList4oPreCondition();
        java.lang.String returnValue = handleGetTypedArgumentList(modifier);
        handleGetTypedArgumentList4oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetSignature(java.lang.String argumentModifier);

    private void handleGetSignature5oPreCondition()
    {
    }

    private void handleGetSignature5oPostCondition()
    {
    }

    public java.lang.String getSignature(java.lang.String argumentModifier)
    {
        handleGetSignature5oPreCondition();
        java.lang.String returnValue = handleGetSignature(argumentModifier);
        handleGetSignature5oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOwner1rPreCondition()
    {
    }

    private void handleGetOwner1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        handleGetOwner1rPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade getOwner1r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetOwner());
        handleGetOwner1rPostCondition();
        return getOwner1r;
    }

    protected abstract java.lang.Object handleGetOwner();

    private void handleGetParameters2rPreCondition()
    {
    }

    private void handleGetParameters2rPostCondition()
    {
    }

    public final java.util.Collection getParameters()
    {
        handleGetParameters2rPreCondition();
        java.util.Collection getParameters2r = shieldedElements(handleGetParameters());
        handleGetParameters2rPostCondition();
        return getParameters2r;
    }

    protected abstract java.util.Collection handleGetParameters();

    private void handleGetReturnType5rPreCondition()
    {
    }

    private void handleGetReturnType5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getReturnType()
    {
        handleGetReturnType5rPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade getReturnType5r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetReturnType());
        handleGetReturnType5rPostCondition();
        return getReturnType5r;
    }

    protected abstract java.lang.Object handleGetReturnType();

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
	{
        return super_.getActivityGraphContext();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getSourceDependencies()
	{
        return super_.getSourceDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTargetDependencies()
	{
        return super_.getTargetDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        return super_.getValidationOwner();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        return super_.getValidationName();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"returnType")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each operation needs a return type, you cannot leave the type unspecified, even if you want void you'll need to explicitely specify it."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each operation must have a non-empty name."));
        }
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");  
        } 
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }      
        return toString.toString();
    }      
}
