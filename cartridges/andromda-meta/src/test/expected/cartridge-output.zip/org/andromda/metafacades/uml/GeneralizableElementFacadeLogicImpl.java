package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.GeneralizableElementFacade.
 *
 * @see org.andromda.metafacades.uml.GeneralizableElementFacade
 */
public class GeneralizableElementFacadeLogicImpl
       extends GeneralizableElementFacadeLogic
       implements org.andromda.metafacades.uml.GeneralizableElementFacade
{
    // ---------------- constructor -------------------------------

    public GeneralizableElementFacadeLogicImpl (org.omg.uml.foundation.core.GeneralizableElement metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getAllGeneralizations()
     */
    public java.util.Collection handleGetAllGeneralizations() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralization()
     */
    public java.lang.Object handleGetGeneralization()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizations()
     */
    public java.util.Collection handleGetGeneralizations()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getSpecializations()
     */
    public java.util.Collection handleGetSpecializations()
    {
        // TODO: add your implementation here!
        return null;
    }

}
