//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndAction
 *
 * @see org.andromda.metafacades.uml.FrontEndAction
 */
public abstract class FrontEndActionLogic
    extends org.andromda.metafacades.uml.FrontEndForwardLogicImpl
    implements org.andromda.metafacades.uml.FrontEndAction
{

    protected Object metaObject;

    public FrontEndActionLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndAction";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetInput1rPreCondition()
    {
    }

    private void handleGetInput1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndView __getInput1r;
    private boolean __getInput1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndView getInput()
    {
        org.andromda.metafacades.uml.FrontEndView getInput1r = this.__getInput1r;
        if (!this.__getInput1rSet)
        {
            handleGetInput1rPreCondition();
            Object result = this.shieldedElement(handleGetInput());
            try
            {
                getInput1r = (org.andromda.metafacades.uml.FrontEndView)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInput1rPostCondition();
            this.__getInput1r = getInput1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInput1rSet = true;
            }
        }
        return getInput1r;
    }

    protected abstract java.lang.Object handleGetInput();

    private void handleGetParameters2rPreCondition()
    {
    }

    private void handleGetParameters2rPostCondition()
    {
    }

    private java.util.List __getParameters2r;
    private boolean __getParameters2rSet = false;

    public final java.util.List getParameters()
    {
        java.util.List getParameters2r = this.__getParameters2r;
        if (!this.__getParameters2rSet)
        {
            handleGetParameters2rPreCondition();
            Object result = this.shieldedElements(handleGetParameters());
            try
            {
                getParameters2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetParameters2rPostCondition();
            this.__getParameters2r = getParameters2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getParameters2rSet = true;
            }
        }
        return getParameters2r;
    }

    protected abstract java.util.List handleGetParameters();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}