//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndAction
 *
 * @see org.andromda.metafacades.uml.FrontEndAction
 */
public abstract class FrontEndActionLogic
    extends org.andromda.metafacades.uml.FrontEndForwardLogicImpl
    implements org.andromda.metafacades.uml.FrontEndAction
{

    protected Object metaObject;

    public FrontEndActionLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndAction";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndAction#isUseCaseStart()
    */
    protected abstract boolean handleIsUseCaseStart();

    private void handleIsUseCaseStart1aPreCondition()
    {
    }

    private void handleIsUseCaseStart1aPostCondition()
    {
    }

    private boolean __useCaseStart1a;
    private boolean __useCaseStart1aSet = false;

    public final boolean isUseCaseStart()
    {
        boolean useCaseStart1a = this.__useCaseStart1a;
        if (!this.__useCaseStart1aSet)
        {
            handleIsUseCaseStart1aPreCondition();
            useCaseStart1a = handleIsUseCaseStart();
            handleIsUseCaseStart1aPostCondition();
            this.__useCaseStart1a = useCaseStart1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__useCaseStart1aSet = true;
            }
        }
        return useCaseStart1a;
    }

    // ---------------- business methods ----------------------

    protected abstract org.andromda.metafacades.uml.ParameterFacade handleFindParameter(java.lang.String name);

    private void handleFindParameter1oPreCondition()
    {
    }

    private void handleFindParameter1oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ParameterFacade findParameter(java.lang.String name)
    {
        handleFindParameter1oPreCondition();
        org.andromda.metafacades.uml.ParameterFacade returnValue = handleFindParameter(name);
        handleFindParameter1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetInput1rPreCondition()
    {
    }

    private void handleGetInput1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndView __getInput1r;
    private boolean __getInput1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndView getInput()
    {
        org.andromda.metafacades.uml.FrontEndView getInput1r = this.__getInput1r;
        if (!this.__getInput1rSet)
        {
            handleGetInput1rPreCondition();
            Object result = this.shieldedElement(handleGetInput());
            try
            {
                getInput1r = (org.andromda.metafacades.uml.FrontEndView)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInput1rPostCondition();
            this.__getInput1r = getInput1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInput1rSet = true;
            }
        }
        return getInput1r;
    }

    protected abstract java.lang.Object handleGetInput();

    private void handleGetParameters2rPreCondition()
    {
    }

    private void handleGetParameters2rPostCondition()
    {
    }

    private java.util.List __getParameters2r;
    private boolean __getParameters2rSet = false;

    public final java.util.List getParameters()
    {
        java.util.List getParameters2r = this.__getParameters2r;
        if (!this.__getParameters2rSet)
        {
            handleGetParameters2rPreCondition();
            Object result = this.shieldedElements(handleGetParameters());
            try
            {
                getParameters2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetParameters2rPostCondition();
            this.__getParameters2r = getParameters2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getParameters2rSet = true;
            }
        }
        return getParameters2r;
    }

    protected abstract java.util.List handleGetParameters();

    private void handleGetDeferredOperations4rPreCondition()
    {
    }

    private void handleGetDeferredOperations4rPostCondition()
    {
    }

    private java.util.List __getDeferredOperations4r;
    private boolean __getDeferredOperations4rSet = false;

    public final java.util.List getDeferredOperations()
    {
        java.util.List getDeferredOperations4r = this.__getDeferredOperations4r;
        if (!this.__getDeferredOperations4rSet)
        {
            handleGetDeferredOperations4rPreCondition();
            Object result = this.shieldedElements(handleGetDeferredOperations());
            try
            {
                getDeferredOperations4r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDeferredOperations4rPostCondition();
            this.__getDeferredOperations4r = getDeferredOperations4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferredOperations4rSet = true;
            }
        }
        return getDeferredOperations4r;
    }

    protected abstract java.util.List handleGetDeferredOperations();

    private void handleGetController5rPreCondition()
    {
    }

    private void handleGetController5rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndController __getController5r;
    private boolean __getController5rSet = false;

    public final org.andromda.metafacades.uml.FrontEndController getController()
    {
        org.andromda.metafacades.uml.FrontEndController getController5r = this.__getController5r;
        if (!this.__getController5rSet)
        {
            handleGetController5rPreCondition();
            Object result = this.shieldedElement(handleGetController());
            try
            {
                getController5r = (org.andromda.metafacades.uml.FrontEndController)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetController5rPostCondition();
            this.__getController5r = getController5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController5rSet = true;
            }
        }
        return getController5r;
    }

    protected abstract java.lang.Object handleGetController();

    private void handleGetActionStates6rPreCondition()
    {
    }

    private void handleGetActionStates6rPostCondition()
    {
    }

    private java.util.List __getActionStates6r;
    private boolean __getActionStates6rSet = false;

    public final java.util.List getActionStates()
    {
        java.util.List getActionStates6r = this.__getActionStates6r;
        if (!this.__getActionStates6rSet)
        {
            handleGetActionStates6rPreCondition();
            Object result = this.shieldedElements(handleGetActionStates());
            try
            {
                getActionStates6r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActionStates6rPostCondition();
            this.__getActionStates6r = getActionStates6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActionStates6rSet = true;
            }
        }
        return getActionStates6r;
    }

    protected abstract java.util.List handleGetActionStates();

    private void handleGetDecisionTransitions8rPreCondition()
    {
    }

    private void handleGetDecisionTransitions8rPostCondition()
    {
    }

    private java.util.List __getDecisionTransitions8r;
    private boolean __getDecisionTransitions8rSet = false;

    public final java.util.List getDecisionTransitions()
    {
        java.util.List getDecisionTransitions8r = this.__getDecisionTransitions8r;
        if (!this.__getDecisionTransitions8rSet)
        {
            handleGetDecisionTransitions8rPreCondition();
            Object result = this.shieldedElements(handleGetDecisionTransitions());
            try
            {
                getDecisionTransitions8r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDecisionTransitions8rPostCondition();
            this.__getDecisionTransitions8r = getDecisionTransitions8r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDecisionTransitions8rSet = true;
            }
        }
        return getDecisionTransitions8r;
    }

    protected abstract java.util.List handleGetDecisionTransitions();

    private void handleGetTransitions11rPreCondition()
    {
    }

    private void handleGetTransitions11rPostCondition()
    {
    }

    private java.util.List __getTransitions11r;
    private boolean __getTransitions11rSet = false;

    public final java.util.List getTransitions()
    {
        java.util.List getTransitions11r = this.__getTransitions11r;
        if (!this.__getTransitions11rSet)
        {
            handleGetTransitions11rPreCondition();
            Object result = this.shieldedElements(handleGetTransitions());
            try
            {
                getTransitions11r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetTransitions11rPostCondition();
            this.__getTransitions11r = getTransitions11r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTransitions11rSet = true;
            }
        }
        return getTransitions11r;
    }

    protected abstract java.util.List handleGetTransitions();

    private void handleGetFormFields12rPreCondition()
    {
    }

    private void handleGetFormFields12rPostCondition()
    {
    }

    private java.util.List __getFormFields12r;
    private boolean __getFormFields12rSet = false;

    public final java.util.List getFormFields()
    {
        java.util.List getFormFields12r = this.__getFormFields12r;
        if (!this.__getFormFields12rSet)
        {
            handleGetFormFields12rPreCondition();
            Object result = this.shieldedElements(handleGetFormFields());
            try
            {
                getFormFields12r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFormFields12rPostCondition();
            this.__getFormFields12r = getFormFields12r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFormFields12rSet = true;
            }
        }
        return getFormFields12r;
    }

    protected abstract java.util.List handleGetFormFields();

    private void handleGetActionForwards13rPreCondition()
    {
    }

    private void handleGetActionForwards13rPostCondition()
    {
    }

    private java.util.List __getActionForwards13r;
    private boolean __getActionForwards13rSet = false;

    public final java.util.List getActionForwards()
    {
        java.util.List getActionForwards13r = this.__getActionForwards13r;
        if (!this.__getActionForwards13rSet)
        {
            handleGetActionForwards13rPreCondition();
            Object result = this.shieldedElements(handleGetActionForwards());
            try
            {
                getActionForwards13r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActionForwards13rPostCondition();
            this.__getActionForwards13r = getActionForwards13r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActionForwards13rSet = true;
            }
        }
        return getActionForwards13r;
    }

    protected abstract java.util.List handleGetActionForwards();

    private void handleGetTargetViews14rPreCondition()
    {
    }

    private void handleGetTargetViews14rPostCondition()
    {
    }

    private java.util.List __getTargetViews14r;
    private boolean __getTargetViews14rSet = false;

    public final java.util.List getTargetViews()
    {
        java.util.List getTargetViews14r = this.__getTargetViews14r;
        if (!this.__getTargetViews14rSet)
        {
            handleGetTargetViews14rPreCondition();
            Object result = this.shieldedElements(handleGetTargetViews());
            try
            {
                getTargetViews14r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetTargetViews14rPostCondition();
            this.__getTargetViews14r = getTargetViews14r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getTargetViews14rSet = true;
            }
        }
        return getTargetViews14r;
    }

    protected abstract java.util.List handleGetTargetViews();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"parameters"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}})); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "org::andromda::metafacades::uml::FrontEndAction::parameters must be unique",
                        "Each front-end action parameter must have a unique name."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"exitingView"))).booleanValue())).booleanValue()?Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"triggerPresent"))).booleanValue():true)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "org::andromda::metafacades::uml::FrontEndAction::each action must carry a trigger",
                        "Each action transition coming out of a view must have a trigger (the name is sufficient), it is recommended to add a trigger of type 'signal'."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}