//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a "front-end" action. An action is some action that
 *  is taken when a front-end even occurs.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndAction
    extends org.andromda.metafacades.uml.FrontEndForward
{

   /**
    * <p>
    *  The view on which this action can be triggered.
    * </p>
    */
    public org.andromda.metafacades.uml.FrontEndView getInput();

}