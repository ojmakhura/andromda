//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a role a user may play within a system. Provides
 *  access to things such as services and service operations.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface RoleFacade
       extends org.andromda.metafacades.uml.ActorFacade
{

   /**
    * <p>
    *  Indicates that this role has at least one or more service
    *  operation references present.
    * </p>
    */
    public boolean isServiceOperationReferencesPresent();

   /**
    * <p>
    *  Indicates that this role has at least one or more service
    *  references present.
    * </p>
    */
    public boolean isServiceReferencesPresent();

}
