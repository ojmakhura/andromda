//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelElementFacade
 *
 * @see org.andromda.metafacades.uml.ModelElementFacade
 */
public abstract class ModelElementFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.ModelElementFacade
{
    protected org.omg.uml.foundation.core.ModelElement metaObject;

    public ModelElementFacadeLogic (org.omg.uml.foundation.core.ModelElement metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ModelElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getVisibility()
    */
    protected abstract java.lang.String handleGetVisibility();

    private void handleGetVisibility1aPreCondition()
    {
    }

    private void handleGetVisibility1aPostCondition()
    {
    }

    private java.lang.String __visibility1a;
    private boolean __visibility1aSet = false;

    public final java.lang.String getVisibility()
    {
        if (!this.__visibility1aSet)
        {
            handleGetVisibility1aPreCondition();
            this.__visibility1a = handleGetVisibility();
            handleGetVisibility1aPostCondition();
            this.__visibility1aSet = true;
        }
        return this.__visibility1a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getPackagePath()
    */
    protected abstract java.lang.String handleGetPackagePath();

    private void handleGetPackagePath2aPreCondition()
    {
    }

    private void handleGetPackagePath2aPostCondition()
    {
    }

    private java.lang.String __packagePath2a;
    private boolean __packagePath2aSet = false;

    public final java.lang.String getPackagePath()
    {
        if (!this.__packagePath2aSet)
        {
            handleGetPackagePath2aPreCondition();
            this.__packagePath2a = handleGetPackagePath();
            handleGetPackagePath2aPostCondition();
            this.__packagePath2aSet = true;
        }
        return this.__packagePath2a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getName()
    */
    protected abstract java.lang.String handleGetName();

    private void handleGetName3aPreCondition()
    {
    }

    private void handleGetName3aPostCondition()
    {
    }

    private java.lang.String __name3a;
    private boolean __name3aSet = false;

    public final java.lang.String getName()
    {
        if (!this.__name3aSet)
        {
            handleGetName3aPreCondition();
            this.__name3a = handleGetName();
            handleGetName3aPostCondition();
            this.__name3aSet = true;
        }
        return this.__name3a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName()
    */
    protected abstract java.lang.String handleGetPackageName();

    private void handleGetPackageName4aPreCondition()
    {
    }

    private void handleGetPackageName4aPostCondition()
    {
    }

    private java.lang.String __packageName4a;
    private boolean __packageName4aSet = false;

    public final java.lang.String getPackageName()
    {
        if (!this.__packageName4aSet)
        {
            handleGetPackageName4aPreCondition();
            this.__packageName4a = handleGetPackageName();
            handleGetPackageName4aPostCondition();
            this.__packageName4aSet = true;
        }
        return this.__packageName4a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName()
    */
    protected abstract java.lang.String handleGetFullyQualifiedName();

    private void handleGetFullyQualifiedName5aPreCondition()
    {
    }

    private void handleGetFullyQualifiedName5aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedName5a;
    private boolean __fullyQualifiedName5aSet = false;

    public final java.lang.String getFullyQualifiedName()
    {
        if (!this.__fullyQualifiedName5aSet)
        {
            handleGetFullyQualifiedName5aPreCondition();
            this.__fullyQualifiedName5a = handleGetFullyQualifiedName();
            handleGetFullyQualifiedName5aPostCondition();
            this.__fullyQualifiedName5aSet = true;
        }
        return this.__fullyQualifiedName5a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedNamePath()
    */
    protected abstract java.lang.String handleGetFullyQualifiedNamePath();

    private void handleGetFullyQualifiedNamePath6aPreCondition()
    {
    }

    private void handleGetFullyQualifiedNamePath6aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedNamePath6a;
    private boolean __fullyQualifiedNamePath6aSet = false;

    public final java.lang.String getFullyQualifiedNamePath()
    {
        if (!this.__fullyQualifiedNamePath6aSet)
        {
            handleGetFullyQualifiedNamePath6aPreCondition();
            this.__fullyQualifiedNamePath6a = handleGetFullyQualifiedNamePath();
            handleGetFullyQualifiedNamePath6aPostCondition();
            this.__fullyQualifiedNamePath6aSet = true;
        }
        return this.__fullyQualifiedNamePath6a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getLanguageMappings()
    */
    protected abstract org.andromda.core.mapping.Mappings handleGetLanguageMappings();

    private void handleGetLanguageMappings7aPreCondition()
    {
    }

    private void handleGetLanguageMappings7aPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getLanguageMappings()
    {
        handleGetLanguageMappings7aPreCondition();
        org.andromda.core.mapping.Mappings languageMappings7a = handleGetLanguageMappings();
        handleGetLanguageMappings7aPostCondition();
        return languageMappings7a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypeNames()
    */
    protected abstract java.util.Collection handleGetStereotypeNames();

    private void handleGetStereotypeNames8aPreCondition()
    {
    }

    private void handleGetStereotypeNames8aPostCondition()
    {
    }

    public final java.util.Collection getStereotypeNames()
    {
        handleGetStereotypeNames8aPreCondition();
        java.util.Collection stereotypeNames8a = handleGetStereotypeNames();
        handleGetStereotypeNames8aPostCondition();
        return stereotypeNames8a;
    }

   /**
	* @see org.andromda.metafacades.uml.ModelElementFacade#getId()
    */
    protected abstract java.lang.String handleGetId();

    private void handleGetId9aPreCondition()
    {
    }

    private void handleGetId9aPostCondition()
    {
    }

    private java.lang.String __id9a;
    private boolean __id9aSet = false;

    public final java.lang.String getId()
    {
        if (!this.__id9aSet)
        {
            handleGetId9aPreCondition();
            this.__id9a = handleGetId();
            handleGetId9aPostCondition();
            this.__id9aSet = true;
        }
        return this.__id9a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String tagName);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(tagName);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    protected abstract boolean handleHasStereotype(java.lang.String stereotypeName);

    private void handleHasStereotype2oPreCondition()
    {
    }

    private void handleHasStereotype2oPostCondition()
    {
    }

    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        handleHasStereotype2oPreCondition();
        boolean returnValue = handleHasStereotype(stereotypeName);
        handleHasStereotype2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent);

    private void handleGetDocumentation3oPreCondition()
    {
    }

    private void handleGetDocumentation3oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent)
    {
        handleGetDocumentation3oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent);
        handleGetDocumentation3oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetFullyQualifiedName(boolean modelName);

    private void handleGetFullyQualifiedName4oPreCondition()
    {
    }

    private void handleGetFullyQualifiedName4oPostCondition()
    {
    }

    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        handleGetFullyQualifiedName4oPreCondition();
        java.lang.String returnValue = handleGetFullyQualifiedName(modelName);
        handleGetFullyQualifiedName4oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength);

    private void handleGetDocumentation5oPreCondition()
    {
    }

    private void handleGetDocumentation5oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        handleGetDocumentation5oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength);
        handleGetDocumentation5oPostCondition();
        return returnValue;
    }

    protected abstract boolean handleHasExactStereotype(java.lang.String stereotypeName);

    private void handleHasExactStereotype6oPreCondition()
    {
    }

    private void handleHasExactStereotype6oPostCondition()
    {
    }

    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        handleHasExactStereotype6oPreCondition();
        boolean returnValue = handleHasExactStereotype(stereotypeName);
        handleHasExactStereotype6oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleTranslateConstraint(java.lang.String name, java.lang.String translation);

    private void handleTranslateConstraint7oPreCondition()
    {
    }

    private void handleTranslateConstraint7oPostCondition()
    {
    }

    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        handleTranslateConstraint7oPreCondition();
        java.lang.String returnValue = handleTranslateConstraint(name, translation);
        handleTranslateConstraint7oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String[] handleTranslateConstraints(java.lang.String kind, java.lang.String translation);

    private void handleTranslateConstraints8oPreCondition()
    {
    }

    private void handleTranslateConstraints8oPostCondition()
    {
    }

    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        handleTranslateConstraints8oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(kind, translation);
        handleTranslateConstraints8oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String[] handleTranslateConstraints(java.lang.String translation);

    private void handleTranslateConstraints9oPreCondition()
    {
    }

    private void handleTranslateConstraints9oPostCondition()
    {
    }

    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        handleTranslateConstraints9oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(translation);
        handleTranslateConstraints9oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetConstraints(java.lang.String kind);

    private void handleGetConstraints10oPreCondition()
    {
    }

    private void handleGetConstraints10oPostCondition()
    {
    }

    public java.util.Collection getConstraints(java.lang.String kind)
    {
        handleGetConstraints10oPreCondition();
        java.util.Collection returnValue = handleGetConstraints(kind);
        handleGetConstraints10oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleFindTaggedValues(java.lang.String tagName);

    private void handleFindTaggedValues11oPreCondition()
    {
    }

    private void handleFindTaggedValues11oPostCondition()
    {
    }

    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        handleFindTaggedValues11oPreCondition();
        java.util.Collection returnValue = handleFindTaggedValues(tagName);
        handleFindTaggedValues11oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle);

    private void handleGetDocumentation12oPreCondition()
    {
    }

    private void handleGetDocumentation12oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        handleGetDocumentation12oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength, htmlStyle);
        handleGetDocumentation12oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetTaggedValues1rPreCondition()
    {
    }

    private void handleGetTaggedValues1rPostCondition()
    {
    }

    public final java.util.Collection getTaggedValues()
    {
        handleGetTaggedValues1rPreCondition();
        java.util.Collection getTaggedValues1r = shieldedElements(handleGetTaggedValues());
        handleGetTaggedValues1rPostCondition();
        return getTaggedValues1r;
    }

    protected abstract java.util.Collection handleGetTaggedValues();

    private void handleGetPackage2rPreCondition()
    {
    }

    private void handleGetPackage2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        handleGetPackage2rPreCondition();
        org.andromda.metafacades.uml.ModelElementFacade getPackage2r = (org.andromda.metafacades.uml.ModelElementFacade)shieldedElement(handleGetPackage());
        handleGetPackage2rPostCondition();
        return getPackage2r;
    }

    protected abstract java.lang.Object handleGetPackage();

    private void handleGetRootPackage4rPreCondition()
    {
    }

    private void handleGetRootPackage4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        handleGetRootPackage4rPreCondition();
        org.andromda.metafacades.uml.PackageFacade getRootPackage4r = (org.andromda.metafacades.uml.PackageFacade)shieldedElement(handleGetRootPackage());
        handleGetRootPackage4rPostCondition();
        return getRootPackage4r;
    }

    protected abstract java.lang.Object handleGetRootPackage();

    private void handleGetTargetDependencies5rPreCondition()
    {
    }

    private void handleGetTargetDependencies5rPostCondition()
    {
    }

    public final java.util.Collection getTargetDependencies()
    {
        handleGetTargetDependencies5rPreCondition();
        java.util.Collection getTargetDependencies5r = shieldedElements(handleGetTargetDependencies());
        handleGetTargetDependencies5rPostCondition();
        return getTargetDependencies5r;
    }

    protected abstract java.util.Collection handleGetTargetDependencies();

    private void handleGetNameSpace6rPreCondition()
    {
    }

    private void handleGetNameSpace6rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        handleGetNameSpace6rPreCondition();
        org.andromda.metafacades.uml.NamespaceFacade getNameSpace6r = (org.andromda.metafacades.uml.NamespaceFacade)shieldedElement(handleGetNameSpace());
        handleGetNameSpace6rPostCondition();
        return getNameSpace6r;
    }

    protected abstract java.lang.Object handleGetNameSpace();

    private void handleGetActivityGraphContext7rPreCondition()
    {
    }

    private void handleGetActivityGraphContext7rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        handleGetActivityGraphContext7rPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext7r = (org.andromda.metafacades.uml.ActivityGraphFacade)shieldedElement(handleGetActivityGraphContext());
        handleGetActivityGraphContext7rPostCondition();
        return getActivityGraphContext7r;
    }

    protected abstract java.lang.Object handleGetActivityGraphContext();

    private void handleGetModel8rPreCondition()
    {
    }

    private void handleGetModel8rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelFacade getModel()
    {
        handleGetModel8rPreCondition();
        org.andromda.metafacades.uml.ModelFacade getModel8r = (org.andromda.metafacades.uml.ModelFacade)shieldedElement(handleGetModel());
        handleGetModel8rPostCondition();
        return getModel8r;
    }

    protected abstract java.lang.Object handleGetModel();

    private void handleGetStereotypes9rPreCondition()
    {
    }

    private void handleGetStereotypes9rPostCondition()
    {
    }

    public final java.util.Collection getStereotypes()
    {
        handleGetStereotypes9rPreCondition();
        java.util.Collection getStereotypes9r = shieldedElements(handleGetStereotypes());
        handleGetStereotypes9rPostCondition();
        return getStereotypes9r;
    }

    protected abstract java.util.Collection handleGetStereotypes();

    private void handleGetConstraints10rPreCondition()
    {
    }

    private void handleGetConstraints10rPostCondition()
    {
    }

    public final java.util.Collection getConstraints()
    {
        handleGetConstraints10rPreCondition();
        java.util.Collection getConstraints10r = shieldedElements(handleGetConstraints());
        handleGetConstraints10rPostCondition();
        return getConstraints10r;
    }

    protected abstract java.util.Collection handleGetConstraints();

    private void handleGetSourceDependencies12rPreCondition()
    {
    }

    private void handleGetSourceDependencies12rPostCondition()
    {
    }

    public final java.util.Collection getSourceDependencies()
    {
        handleGetSourceDependencies12rPreCondition();
        java.util.Collection getSourceDependencies12r = shieldedElements(handleGetSourceDependencies());
        handleGetSourceDependencies12rPostCondition();
        return getSourceDependencies12r;
    }

    protected abstract java.util.Collection handleGetSourceDependencies();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        return super.getValidationOwner();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        return super.getValidationName();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");  
        } 
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }      
        return toString.toString();
    }      
}
