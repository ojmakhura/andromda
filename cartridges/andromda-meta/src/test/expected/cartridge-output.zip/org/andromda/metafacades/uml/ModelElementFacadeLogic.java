//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelElementFacade
 *
 * @see org.andromda.metafacades.uml.ModelElementFacade
 */
public abstract class ModelElementFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ModelElementFacade
{
    protected org.omg.uml.foundation.core.ModelElement metaObject;

    public ModelElementFacadeLogic (org.omg.uml.foundation.core.ModelElement metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ModelElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see java.lang.String#getVisibility()
    */
    public abstract java.lang.String handleGetVisibility();

    private java.lang.String visibility1a;

    private void handleGetVisibility1aPreCondition()
    {
    }

    private void handleGetVisibility1aPostCondition()
    {
    }

    public final java.lang.String getVisibility()
    {
        handleGetVisibility1aPreCondition();
        visibility1a = handleGetVisibility();
        handleGetVisibility1aPostCondition();
        return visibility1a;
    }

   /**
	* @see java.lang.String#getPackagePath()
    */
    public abstract java.lang.String handleGetPackagePath();

    private java.lang.String packagePath2a;

    private void handleGetPackagePath2aPreCondition()
    {
    }

    private void handleGetPackagePath2aPostCondition()
    {
    }

    public final java.lang.String getPackagePath()
    {
        handleGetPackagePath2aPreCondition();
        packagePath2a = handleGetPackagePath();
        handleGetPackagePath2aPostCondition();
        return packagePath2a;
    }

   /**
	* @see java.lang.String#getName()
    */
    public abstract java.lang.String handleGetName();

    private java.lang.String name3a;

    private void handleGetName3aPreCondition()
    {
    }

    private void handleGetName3aPostCondition()
    {
    }

    public final java.lang.String getName()
    {
        handleGetName3aPreCondition();
        name3a = handleGetName();
        handleGetName3aPostCondition();
        return name3a;
    }

   /**
	* @see java.lang.String#getPackageName()
    */
    public abstract java.lang.String handleGetPackageName();

    private java.lang.String packageName4a;

    private void handleGetPackageName4aPreCondition()
    {
    }

    private void handleGetPackageName4aPostCondition()
    {
    }

    public final java.lang.String getPackageName()
    {
        handleGetPackageName4aPreCondition();
        packageName4a = handleGetPackageName();
        handleGetPackageName4aPostCondition();
        return packageName4a;
    }

   /**
	* @see java.lang.String#getFullyQualifiedName()
    */
    public abstract java.lang.String handleGetFullyQualifiedName();

    private java.lang.String fullyQualifiedName5a;

    private void handleGetFullyQualifiedName5aPreCondition()
    {
    }

    private void handleGetFullyQualifiedName5aPostCondition()
    {
    }

    public final java.lang.String getFullyQualifiedName()
    {
        handleGetFullyQualifiedName5aPreCondition();
        fullyQualifiedName5a = handleGetFullyQualifiedName();
        handleGetFullyQualifiedName5aPostCondition();
        return fullyQualifiedName5a;
    }

   /**
	* @see java.lang.String#getFullyQualifiedNamePath()
    */
    public abstract java.lang.String handleGetFullyQualifiedNamePath();

    private java.lang.String fullyQualifiedNamePath6a;

    private void handleGetFullyQualifiedNamePath6aPreCondition()
    {
    }

    private void handleGetFullyQualifiedNamePath6aPostCondition()
    {
    }

    public final java.lang.String getFullyQualifiedNamePath()
    {
        handleGetFullyQualifiedNamePath6aPreCondition();
        fullyQualifiedNamePath6a = handleGetFullyQualifiedNamePath();
        handleGetFullyQualifiedNamePath6aPostCondition();
        return fullyQualifiedNamePath6a;
    }

    // ---------------- business methods ----------------------

    public abstract java.lang.Object handleFindTaggedValue(java.lang.String tagName);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public final java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(tagName);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    public abstract boolean handleHasStereotype(java.lang.String stereotypeName);

    private void handleHasStereotype2oPreCondition()
    {
    }

    private void handleHasStereotype2oPostCondition()
    {
    }

    public final boolean hasStereotype(java.lang.String stereotypeName)
    {
        handleHasStereotype2oPreCondition();
        boolean returnValue = handleHasStereotype(stereotypeName);
        handleHasStereotype2oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetDocumentation(java.lang.String indent);

    private void handleGetDocumentation3oPreCondition()
    {
    }

    private void handleGetDocumentation3oPostCondition()
    {
    }

    public final java.lang.String getDocumentation(java.lang.String indent)
    {
        handleGetDocumentation3oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent);
        handleGetDocumentation3oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetStereotypeNames();

    private void handleGetStereotypeNames4oPreCondition()
    {
    }

    private void handleGetStereotypeNames4oPostCondition()
    {
    }

    public final java.util.Collection getStereotypeNames()
    {
        handleGetStereotypeNames4oPreCondition();
        java.util.Collection returnValue = handleGetStereotypeNames();
        handleGetStereotypeNames4oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetFullyQualifiedName(boolean modelName);

    private void handleGetFullyQualifiedName5oPreCondition()
    {
    }

    private void handleGetFullyQualifiedName5oPostCondition()
    {
    }

    public final java.lang.String getFullyQualifiedName(boolean modelName)
    {
        handleGetFullyQualifiedName5oPreCondition();
        java.lang.String returnValue = handleGetFullyQualifiedName(modelName);
        handleGetFullyQualifiedName5oPostCondition();
        return returnValue;
    }

    public abstract org.andromda.core.mapping.Mappings handleGetLanguageMappings();

    private void handleGetLanguageMappings6oPreCondition()
    {
    }

    private void handleGetLanguageMappings6oPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getLanguageMappings()
    {
        handleGetLanguageMappings6oPreCondition();
        org.andromda.core.mapping.Mappings returnValue = handleGetLanguageMappings();
        handleGetLanguageMappings6oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength);

    private void handleGetDocumentation7oPreCondition()
    {
    }

    private void handleGetDocumentation7oPostCondition()
    {
    }

    public final java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        handleGetDocumentation7oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength);
        handleGetDocumentation7oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle);

    private void handleGetDocumentation8oPreCondition()
    {
    }

    private void handleGetDocumentation8oPostCondition()
    {
    }

    public final java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        handleGetDocumentation8oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength, htmlStyle);
        handleGetDocumentation8oPostCondition();
        return returnValue;
    }

    public abstract boolean handleHasExactStereotype(java.lang.String stereotypeName);

    private void handleHasExactStereotype9oPreCondition()
    {
    }

    private void handleHasExactStereotype9oPostCondition()
    {
    }

    public final boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        handleHasExactStereotype9oPreCondition();
        boolean returnValue = handleHasExactStereotype(stereotypeName);
        handleHasExactStereotype9oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleTranslateConstraint(java.lang.String name, java.lang.String translation);

    private void handleTranslateConstraint10oPreCondition()
    {
    }

    private void handleTranslateConstraint10oPostCondition()
    {
    }

    public final java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        handleTranslateConstraint10oPreCondition();
        java.lang.String returnValue = handleTranslateConstraint(name, translation);
        handleTranslateConstraint10oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String[] handleTranslateConstraints(java.lang.String kind, java.lang.String translation);

    private void handleTranslateConstraints11oPreCondition()
    {
    }

    private void handleTranslateConstraints11oPostCondition()
    {
    }

    public final java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        handleTranslateConstraints11oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(kind, translation);
        handleTranslateConstraints11oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String[] handleTranslateConstraints(java.lang.String translation);

    private void handleTranslateConstraints12oPreCondition()
    {
    }

    private void handleTranslateConstraints12oPostCondition()
    {
    }

    public final java.lang.String[] translateConstraints(java.lang.String translation)
    {
        handleTranslateConstraints12oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(translation);
        handleTranslateConstraints12oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetConstraints(java.lang.String kind);

    private void handleGetConstraints13oPreCondition()
    {
    }

    private void handleGetConstraints13oPostCondition()
    {
    }

    public final java.util.Collection getConstraints(java.lang.String kind)
    {
        handleGetConstraints13oPreCondition();
        java.util.Collection returnValue = handleGetConstraints(kind);
        handleGetConstraints13oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleFindTaggedValues(java.lang.String tagName);

    private void handleFindTaggedValues14oPreCondition()
    {
    }

    private void handleFindTaggedValues14oPostCondition()
    {
    }

    public final java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        handleFindTaggedValues14oPreCondition();
        java.util.Collection returnValue = handleFindTaggedValues(tagName);
        handleFindTaggedValues14oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private java.util.Collection getTaggedValues1r;

    private void handleGetTaggedValues1rPreCondition()
    {
    }

    private void handleGetTaggedValues1rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetTaggedValues();

    public final java.util.Collection getTaggedValues()
    {
        handleGetTaggedValues1rPreCondition();
        getTaggedValues1r = shieldedElements(handleGetTaggedValues());
        handleGetTaggedValues1rPostCondition();
        return getTaggedValues1r;
    }

    private org.andromda.metafacades.uml.ModelElementFacade getPackage2r;

    private void handleGetPackage2rPreCondition()
    {
    }

    private void handleGetPackage2rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetPackage();

    public final org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        handleGetPackage2rPreCondition();
        getPackage2r = (org.andromda.metafacades.uml.ModelElementFacade)shieldedElement(handleGetPackage());
        handleGetPackage2rPostCondition();
        return getPackage2r;
    }

    private org.andromda.metafacades.uml.PackageFacade getRootPackage4r;

    private void handleGetRootPackage4rPreCondition()
    {
    }

    private void handleGetRootPackage4rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetRootPackage();

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        handleGetRootPackage4rPreCondition();
        getRootPackage4r = (org.andromda.metafacades.uml.PackageFacade)shieldedElement(handleGetRootPackage());
        handleGetRootPackage4rPostCondition();
        return getRootPackage4r;
    }

    private java.util.Collection getDependencies5r;

    private void handleGetDependencies5rPreCondition()
    {
    }

    private void handleGetDependencies5rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetDependencies();

    public final java.util.Collection getDependencies()
    {
        handleGetDependencies5rPreCondition();
        getDependencies5r = shieldedElements(handleGetDependencies());
        handleGetDependencies5rPostCondition();
        return getDependencies5r;
    }

    private org.andromda.metafacades.uml.NamespaceFacade getNameSpace6r;

    private void handleGetNameSpace6rPreCondition()
    {
    }

    private void handleGetNameSpace6rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetNameSpace();

    public final org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        handleGetNameSpace6rPreCondition();
        getNameSpace6r = (org.andromda.metafacades.uml.NamespaceFacade)shieldedElement(handleGetNameSpace());
        handleGetNameSpace6rPostCondition();
        return getNameSpace6r;
    }

    private org.andromda.metafacades.uml.ModelFacade getModel8r;

    private void handleGetModel8rPreCondition()
    {
    }

    private void handleGetModel8rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetModel();

    public final org.andromda.metafacades.uml.ModelFacade getModel()
    {
        handleGetModel8rPreCondition();
        getModel8r = (org.andromda.metafacades.uml.ModelFacade)shieldedElement(handleGetModel());
        handleGetModel8rPostCondition();
        return getModel8r;
    }

    private java.util.Collection getStereotypes9r;

    private void handleGetStereotypes9rPreCondition()
    {
    }

    private void handleGetStereotypes9rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetStereotypes();

    public final java.util.Collection getStereotypes()
    {
        handleGetStereotypes9rPreCondition();
        getStereotypes9r = shieldedElements(handleGetStereotypes());
        handleGetStereotypes9rPostCondition();
        return getStereotypes9r;
    }

    private java.util.Collection getConstraints10r;

    private void handleGetConstraints10rPreCondition()
    {
    }

    private void handleGetConstraints10rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetConstraints();

    public final java.util.Collection getConstraints()
    {
        handleGetConstraints10rPreCondition();
        getConstraints10r = shieldedElements(handleGetConstraints());
        handleGetConstraints10rPostCondition();
        return getConstraints10r;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }
}
