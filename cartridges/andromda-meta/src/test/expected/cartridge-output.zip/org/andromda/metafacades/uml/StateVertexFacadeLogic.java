//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.StateVertexFacade
 *
 * @see org.andromda.metafacades.uml.StateVertexFacade
 */
public abstract class StateVertexFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.StateVertexFacade
{

    protected org.omg.uml.behavioralelements.statemachines.StateVertex metaObject;

    public StateVertexFacadeLogic(org.omg.uml.behavioralelements.statemachines.StateVertex metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateVertexFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetOutgoing1rPreCondition()
    {
    }

    private void handleGetOutgoing1rPostCondition()
    {
    }

    public final java.util.Collection getOutgoing()
    {
        java.util.Collection getOutgoing1r = null;
        handleGetOutgoing1rPreCondition();
        Object result = this.shieldedElements(handleGetOutgoing());
        try
        {
            getOutgoing1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOutgoing1rPostCondition();
        return getOutgoing1r;
    }

    protected abstract java.util.Collection handleGetOutgoing();

    private void handleGetIncoming2rPreCondition()
    {
    }

    private void handleGetIncoming2rPostCondition()
    {
    }

    public final java.util.Collection getIncoming()
    {
        java.util.Collection getIncoming2r = null;
        handleGetIncoming2rPreCondition();
        Object result = this.shieldedElements(handleGetIncoming());
        try
        {
            getIncoming2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetIncoming2rPostCondition();
        return getIncoming2r;
    }

    protected abstract java.util.Collection handleGetIncoming();

    private void handleGetContainer3rPreCondition()
    {
    }

    private void handleGetContainer3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateFacade getContainer()
    {
        org.andromda.metafacades.uml.StateFacade getContainer3r = null;
        handleGetContainer3rPreCondition();
        Object result = this.shieldedElement(handleGetContainer());
        try
        {
            getContainer3r = (org.andromda.metafacades.uml.StateFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetContainer3rPostCondition();
        return getContainer3r;
    }

    protected abstract java.lang.Object handleGetContainer();

    private void handleGetPartition4rPreCondition()
    {
    }

    private void handleGetPartition4rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.PartitionFacade __getPartition4r;
    private boolean __getPartition4rSet = false;

    public final org.andromda.metafacades.uml.PartitionFacade getPartition()
    {
        org.andromda.metafacades.uml.PartitionFacade getPartition4r = this.__getPartition4r;
        if (!this.__getPartition4rSet)
        {
            handleGetPartition4rPreCondition();
            Object result = this.shieldedElement(handleGetPartition());
            try
            {
                getPartition4r = (org.andromda.metafacades.uml.PartitionFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetPartition4rPostCondition();
            this.__getPartition4r = getPartition4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getPartition4rSet = true;
            }
        }
        return getPartition4r;
    }

    protected abstract java.lang.Object handleGetPartition();

    private void handleGetStateMachine5rPreCondition()
    {
    }

    private void handleGetStateMachine5rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.StateMachineFacade __getStateMachine5r;
    private boolean __getStateMachine5rSet = false;

    public final org.andromda.metafacades.uml.StateMachineFacade getStateMachine()
    {
        org.andromda.metafacades.uml.StateMachineFacade getStateMachine5r = this.__getStateMachine5r;
        if (!this.__getStateMachine5rSet)
        {
            handleGetStateMachine5rPreCondition();
            Object result = this.shieldedElement(handleGetStateMachine());
            try
            {
                getStateMachine5r = (org.andromda.metafacades.uml.StateMachineFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetStateMachine5rPostCondition();
            this.__getStateMachine5r = getStateMachine5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getStateMachine5rSet = true;
            }
        }
        return getStateMachine5r;
    }

    protected abstract java.lang.Object handleGetStateMachine();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}