//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ParameterFacade
 *
 * @see org.andromda.metafacades.uml.ParameterFacade
 */
public abstract class ParameterFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ParameterFacade
{

    protected org.omg.uml.foundation.core.Parameter metaObject;

    public ParameterFacadeLogic (org.omg.uml.foundation.core.Parameter metaObject, String context)
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ParameterFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#getDefaultValue()
    */
    protected abstract java.lang.String handleGetDefaultValue();

    private void handleGetDefaultValue1aPreCondition()
    {
    }

    private void handleGetDefaultValue1aPostCondition()
    {
    }

    public final java.lang.String getDefaultValue()
    {
        java.lang.String defaultValue1a = null;
        handleGetDefaultValue1aPreCondition();
        defaultValue1a = handleGetDefaultValue();
        handleGetDefaultValue1aPostCondition();
        return defaultValue1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isReturn()
    */
    protected abstract boolean handleIsReturn();

    private void handleIsReturn2aPreCondition()
    {
    }

    private void handleIsReturn2aPostCondition()
    {
    }

    public final boolean isReturn()
    {
        boolean return2a = false;
        handleIsReturn2aPreCondition();
        return2a = handleIsReturn();
        handleIsReturn2aPostCondition();
        return return2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired3aPreCondition()
    {
    }

    private void handleIsRequired3aPostCondition()
    {
    }

    public final boolean isRequired()
    {
        boolean required3a = false;
        handleIsRequired3aPreCondition();
        required3a = handleIsRequired();
        handleIsRequired3aPostCondition();
        return required3a;
    }

    // ------------- associations ------------------

    private void handleGetOperation1rPreCondition()
    {
    }

    private void handleGetOperation1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.OperationFacade getOperation()
    {
        org.andromda.metafacades.uml.OperationFacade getOperation1r = null;
        handleGetOperation1rPreCondition();
        Object result = this.shieldedElement(handleGetOperation());
        try
        {
            getOperation1r = (org.andromda.metafacades.uml.OperationFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOperation1rPostCondition();
        return getOperation1r;
    }

    protected abstract java.lang.Object handleGetOperation();

    private void handleGetEvent2rPreCondition()
    {
    }

    private void handleGetEvent2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EventFacade getEvent()
    {
        org.andromda.metafacades.uml.EventFacade getEvent2r = null;
        handleGetEvent2rPreCondition();
        Object result = this.shieldedElement(handleGetEvent());
        try
        {
            getEvent2r = (org.andromda.metafacades.uml.EventFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEvent2rPostCondition();
        return getEvent2r;
    }

    protected abstract java.lang.Object handleGetEvent();

    private void handleGetType3rPreCondition()
    {
    }

    private void handleGetType3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType3r = null;
        handleGetType3rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType3r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType3rPostCondition();
        return getType3r;
    }

    protected abstract java.lang.Object handleGetType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLExpressions.equal(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"type")):true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each parameter needs a type, you cannot leave the type unspecified."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLExpressions.equal(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")):true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each parameter that is NOT a return parameter must have a non-empty name."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
