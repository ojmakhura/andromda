//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.Role
 *
 * @see org.andromda.metafacades.uml.Role
 */
public abstract class RoleLogic
    extends org.andromda.metafacades.uml.ActorFacadeLogicImpl
    implements org.andromda.metafacades.uml.Role
{

    protected Object metaObject;

    public RoleLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.usecases.Actor)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Role";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.Role#isReferencesPresent()
    */
    protected abstract boolean handleIsReferencesPresent();

    private void handleIsReferencesPresent1aPreCondition()
    {
    }

    private void handleIsReferencesPresent1aPostCondition()
    {
    }

    private boolean __referencesPresent1a;
    private boolean __referencesPresent1aSet = false;

    public final boolean isReferencesPresent()
    {
        boolean referencesPresent1a = this.__referencesPresent1a;
        if (!this.__referencesPresent1aSet)
        {
            handleIsReferencesPresent1aPreCondition();
            referencesPresent1a = handleIsReferencesPresent();
            handleIsReferencesPresent1aPostCondition();
            this.__referencesPresent1a = referencesPresent1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__referencesPresent1aSet = true;
            }
        }
        return referencesPresent1a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name"))&&org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"model.allActors"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each role must have a non-empty name that is unique among all other roles."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}