//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * MetafacadeLogic for org.andromda.cartridges.meta.ClassifierTestMetafacade
 *
 * @see org.andromda.cartridges.meta.ClassifierTestMetafacade
 */
public abstract class ClassifierTestMetafacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.cartridges.meta.ClassifierTestMetafacade
{

    protected Object metaObject;

    public ClassifierTestMetafacadeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.superClassifierFacade =
           (org.andromda.metafacades.uml.ClassifierFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ClassifierFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.ClassifierTestMetafacade";
        }
        return context;
    }

    private org.andromda.metafacades.uml.ClassifierFacade superClassifierFacade;
    private boolean superClassifierFacadeInitialized = false;

    /**
     * Gets the org.andromda.metafacades.uml.ClassifierFacade parent instance.
     */
    private org.andromda.metafacades.uml.ClassifierFacade getSuperSuperClassifierFacade()
    {
        if (!this.superClassifierFacadeInitialized)
        {
            ((org.andromda.core.metafacade.MetafacadeBase)superClassifierFacade).setMetafacadeContext(this.getMetafacadeContext());
            this.superClassifierFacadeInitialized = true;
        }
        return superClassifierFacade;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.ClassifierTestMetafacade#getTestAttribute()
    */
    protected abstract java.lang.String handleGetTestAttribute();

    private void handleGetTestAttribute1aPreCondition()
    {
    }

    private void handleGetTestAttribute1aPostCondition()
    {
    }

    private java.lang.String __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    public final java.lang.String getTestAttribute()
    {
        java.lang.String testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            handleGetTestAttribute1aPreCondition();
            testAttribute1a = handleGetTestAttribute();
            handleGetTestAttribute1aPostCondition();
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ---------------- business methods ----------------------

    protected abstract boolean handleIsTestMetafacade();

    private void handleIsTestMetafacade1oPreCondition()
    {
    }

    private void handleIsTestMetafacade1oPostCondition()
    {
    }

    public boolean isTestMetafacade()
    {
        handleIsTestMetafacade1oPreCondition();
        boolean returnValue = handleIsTestMetafacade();
        handleIsTestMetafacade1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetTestOperations1rPreCondition()
    {
    }

    private void handleGetTestOperations1rPostCondition()
    {
    }

    public final java.util.Collection getTestOperations()
    {
        java.util.Collection getTestOperations1r = null;
        handleGetTestOperations1rPreCondition();
        Object result = this.shieldedElements(handleGetTestOperations());
        try
        {
            getTestOperations1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTestOperations1rPostCondition();
        return getTestOperations1r;
    }

    protected abstract java.util.Collection handleGetTestOperations();

    // ----------- delegates to org.andromda.metafacades.uml.ClassifierFacade ------------
    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.AttributeFacade findAttribute(java.lang.String name)
    {
        return this.getSuperSuperClassifierFacade().findAttribute(name);
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAbstractions()
    {
        return this.getSuperSuperClassifierFacade().getAbstractions();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        return this.getSuperSuperClassifierFacade().getArray();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getArrayName()
    {
        return this.getSuperSuperClassifierFacade().getArrayName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAssociationEnds()
    {
        return this.getSuperSuperClassifierFacade().getAssociationEnds();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAttributes()
    {
        return this.getSuperSuperClassifierFacade().getAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAttributes(boolean follow)
    {
        return this.getSuperSuperClassifierFacade().getAttributes(follow);
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getFullyQualifiedArrayName()
    {
        return this.getSuperSuperClassifierFacade().getFullyQualifiedArrayName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getInstanceAttributes()
    {
        return this.getSuperSuperClassifierFacade().getInstanceAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getInstanceOperations()
    {
        return this.getSuperSuperClassifierFacade().getInstanceOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getJavaNullString()
    {
        return this.getSuperSuperClassifierFacade().getJavaNullString();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        return this.getSuperSuperClassifierFacade().getNonArray();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getOperationCallFromAttributes()
    {
        return this.getSuperSuperClassifierFacade().getOperationCallFromAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getOperations()
    {
        return this.getSuperSuperClassifierFacade().getOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getProperties()
    {
        return this.getSuperSuperClassifierFacade().getProperties();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getStaticAttributes()
    {
        return this.getSuperSuperClassifierFacade().getStaticAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getStaticOperations()
    {
        return this.getSuperSuperClassifierFacade().getStaticOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getWrapperName()
    {
        return this.getSuperSuperClassifierFacade().getWrapperName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isAbstract()
    {
        return this.getSuperSuperClassifierFacade().isAbstract();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isArrayType()
    {
        return this.getSuperSuperClassifierFacade().isArrayType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isCollectionType()
    {
        return this.getSuperSuperClassifierFacade().isCollectionType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isDataType()
    {
        return this.getSuperSuperClassifierFacade().isDataType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isDateType()
    {
        return this.getSuperSuperClassifierFacade().isDateType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isEnumeration()
    {
        return this.getSuperSuperClassifierFacade().isEnumeration();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isFileType()
    {
        return this.getSuperSuperClassifierFacade().isFileType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isInterface()
    {
        return this.getSuperSuperClassifierFacade().isInterface();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isListType()
    {
        return this.getSuperSuperClassifierFacade().isListType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isMapType()
    {
        return this.getSuperSuperClassifierFacade().isMapType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isPrimitive()
    {
        return this.getSuperSuperClassifierFacade().isPrimitive();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isSetType()
    {
        return this.getSuperSuperClassifierFacade().isSetType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isStringType()
    {
        return this.getSuperSuperClassifierFacade().isStringType();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getAllGeneralizations()
    {
        return this.getSuperSuperClassifierFacade().getAllGeneralizations();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        return this.getSuperSuperClassifierFacade().getGeneralization();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getGeneralizationLinks()
    {
        return this.getSuperSuperClassifierFacade().getGeneralizationLinks();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.lang.String getGeneralizationList()
    {
        return this.getSuperSuperClassifierFacade().getGeneralizationList();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getGeneralizations()
    {
        return this.getSuperSuperClassifierFacade().getGeneralizations();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getSpecializations()
    {
        return this.getSuperSuperClassifierFacade().getSpecializations();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        return this.getSuperSuperClassifierFacade().findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        return this.getSuperSuperClassifierFacade().findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        return this.getSuperSuperClassifierFacade().getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        return this.getSuperSuperClassifierFacade().getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        return this.getSuperSuperClassifierFacade().getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        return this.getSuperSuperClassifierFacade().getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        return this.getSuperSuperClassifierFacade().getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        return this.getSuperSuperClassifierFacade().getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        return this.getSuperSuperClassifierFacade().getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        return this.getSuperSuperClassifierFacade().getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        return this.getSuperSuperClassifierFacade().getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        return this.getSuperSuperClassifierFacade().getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        return this.getSuperSuperClassifierFacade().getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        return this.getSuperSuperClassifierFacade().getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        return this.getSuperSuperClassifierFacade().getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        return this.getSuperSuperClassifierFacade().getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        return this.getSuperSuperClassifierFacade().getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName(boolean modelName)
    {
        return this.getSuperSuperClassifierFacade().getPackageName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        return this.getSuperSuperClassifierFacade().getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        return this.getSuperSuperClassifierFacade().getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        return this.getSuperSuperClassifierFacade().getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        return this.getSuperSuperClassifierFacade().getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        return this.getSuperSuperClassifierFacade().getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        return this.getSuperSuperClassifierFacade().getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        return this.getSuperSuperClassifierFacade().getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        return this.getSuperSuperClassifierFacade().getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        return this.getSuperSuperClassifierFacade().getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperSuperClassifierFacade().hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperSuperClassifierFacade().hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean isConstraintsPresent()
    {
        return this.getSuperSuperClassifierFacade().isConstraintsPresent();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        return this.getSuperSuperClassifierFacade().translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        return this.getSuperSuperClassifierFacade().translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        return this.getSuperSuperClassifierFacade().translateConstraints(kind, translation);
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        this.getSuperSuperClassifierFacade().initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        Object owner = this.getSuperSuperClassifierFacade().getValidationOwner();
        return owner;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        String name = this.getSuperSuperClassifierFacade().getValidationName();
        return name;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        this.getSuperSuperClassifierFacade().validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}