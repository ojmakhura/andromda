//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * MetafacadeLogic for org.andromda.cartridges.meta.ClassifierTestMetafacade
 *
 * @see org.andromda.cartridges.meta.ClassifierTestMetafacade
 */
public abstract class ClassifierTestMetafacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.cartridges.meta.ClassifierTestMetafacade
{

    protected Object metaObject;
    private org.andromda.metafacades.uml.ClassifierFacade super_1;

    public ClassifierTestMetafacadeLogic(Object metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.super_1 =
           (org.andromda.metafacades.uml.ClassifierFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ClassifierFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.ClassifierTestMetafacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.ClassifierTestMetafacade#getTestAttribute()
    */
    protected abstract java.lang.String handleGetTestAttribute();

    private void handleGetTestAttribute1aPreCondition()
    {
    }

    private void handleGetTestAttribute1aPostCondition()
    {
    }

    private java.lang.String __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    public final java.lang.String getTestAttribute()
    {
        java.lang.String testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            handleGetTestAttribute1aPreCondition();
            testAttribute1a = handleGetTestAttribute();
            handleGetTestAttribute1aPostCondition();
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ---------------- business methods ----------------------

    protected abstract boolean handleIsTestMetafacade();

    private void handleIsTestMetafacade1oPreCondition()
    {
    }

    private void handleIsTestMetafacade1oPostCondition()
    {
    }

    public boolean isTestMetafacade()
    {
        handleIsTestMetafacade1oPreCondition();
        boolean returnValue = handleIsTestMetafacade();
        handleIsTestMetafacade1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetTestOperations1rPreCondition()
    {
    }

    private void handleGetTestOperations1rPostCondition()
    {
    }

    public final java.util.Collection getTestOperations()
    {
        java.util.Collection getTestOperations1r = null;
        handleGetTestOperations1rPreCondition();
        Object result = this.shieldedElements(handleGetTestOperations());
        try
        {
            getTestOperations1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTestOperations1rPostCondition();
        return getTestOperations1r;
    }

    protected abstract java.util.Collection handleGetTestOperations();

    // ----------- delegates to org.andromda.metafacades.uml.ClassifierFacade ------------
    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.AttributeFacade findAttribute(java.lang.String name)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.findAttribute(name);
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAbstractions()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getAbstractions();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getArray();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getArrayName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getArrayName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAssociationEnds()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getAssociationEnds();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAttributes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getAttributes(boolean follow)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getAttributes(follow);
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getFullyQualifiedArrayName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getFullyQualifiedArrayName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getInstanceAttributes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getInstanceAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getInstanceOperations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getInstanceOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getJavaNullString()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getJavaNullString();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getNonArray();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getOperationCallFromAttributes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getOperationCallFromAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getOperations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getProperties()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getProperties();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getStaticAttributes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getStaticAttributes();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.util.Collection getStaticOperations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getStaticOperations();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public java.lang.String getWrapperName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getWrapperName();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isAbstract()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isAbstract();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isArrayType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isArrayType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isCollectionType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isCollectionType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isDataType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isDataType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isDateType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isDateType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isEnumeration()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isEnumeration();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isFileType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isFileType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isInterface()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isInterface();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isListType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isListType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isMapType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isMapType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isPrimitive()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isPrimitive();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isSetType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isSetType();
    }

    // from org.andromda.metafacades.uml.ClassifierFacade
    public boolean isStringType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isStringType();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getAllGeneralizations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getAllGeneralizations();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getGeneralization();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.lang.String getGeneralizationList()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getGeneralizationList();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getGeneralizations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getGeneralizations();
    }

    // from org.andromda.metafacades.uml.GeneralizableElementFacade
    public java.util.Collection getSpecializations()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getSpecializations();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName(boolean modelName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getPackageName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean isConstraintsPresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.isConstraintsPresent();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1.translateConstraints(kind, translation);
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_1.initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        Object owner = super_1.getValidationOwner();
        return owner;
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        String name = super_1.getValidationName();
        return name;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_1.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}