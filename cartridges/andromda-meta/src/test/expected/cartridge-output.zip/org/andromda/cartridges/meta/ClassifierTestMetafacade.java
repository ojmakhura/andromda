// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ClassifierTestMetafacade
    extends org.andromda.metafacades.uml.ClassifierFacade
{

    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isClassifierTestMetafacadeMetaType();

   /**
    * 
    * @return java.lang.String
    */
    public java.lang.String getTestAttribute();

   /**
    * 
    * @return java.util.Collection
    */
    public java.util.Collection getTestOperations();

   /**
    * 
    * @return boolean
    */
    public boolean isTestMetafacade();
}