//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAssociationEndFacade
 *
 * @see org.andromda.metafacades.uml.EntityAssociationEndFacade
 */
public abstract class EntityAssociationEndFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.EntityAssociationEndFacade
{
    protected Object metaObject;
    private org.andromda.metafacades.uml.AssociationEndFacade super_;

    public EntityAssociationEndFacadeLogic (Object metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.AssociationEndFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.AssociationEndFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.EntityAssociationEndFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName1aPreCondition()
    {
    }

    private void handleGetColumnName1aPostCondition()
    {
    }

    public final java.lang.String getColumnName()
    {
        handleGetColumnName1aPreCondition();
        java.lang.String columnName1a = handleGetColumnName();
        handleGetColumnName1aPostCondition();
        return columnName1a;
    }

   /**
	* @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getForeignKeySuffix()
    */
    protected abstract java.lang.String handleGetForeignKeySuffix();

    private void handleGetForeignKeySuffix2aPreCondition()
    {
    }

    private void handleGetForeignKeySuffix2aPostCondition()
    {
    }

    public final java.lang.String getForeignKeySuffix()
    {
        handleGetForeignKeySuffix2aPreCondition();
        java.lang.String foreignKeySuffix2a = handleGetForeignKeySuffix();
        handleGetForeignKeySuffix2aPostCondition();
        return foreignKeySuffix2a;
    }

    // ------------- associations ------------------

    // ----------- delegates to org.andromda.metafacades.uml.AssociationEndFacade ------------
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public org.andromda.metafacades.uml.AssociationFacade getAssociation()
	{
        return super_.getAssociation();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public java.lang.String getGetterName()
	{
        return super_.getGetterName();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public java.lang.String getGetterSetterTypeName()
	{
        return super_.getGetterSetterTypeName();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd()
	{
        return super_.getOtherEnd();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public java.lang.String getSetterName()
	{
        return super_.getSetterName();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public org.andromda.metafacades.uml.ClassifierFacade getType()
	{
        return super_.getType();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isAggregation()
	{
        return super_.isAggregation();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isChild()
	{
        return super_.isChild();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isComposition()
	{
        return super_.isComposition();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isMany()
	{
        return super_.isMany();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isMany2Many()
	{
        return super_.isMany2Many();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isMany2One()
	{
        return super_.isMany2One();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isNavigable()
	{
        return super_.isNavigable();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isOne2Many()
	{
        return super_.isOne2Many();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isOne2One()
	{
        return super_.isOne2One();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isOrdered()
	{
        return super_.isOrdered();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isReadOnly()
	{
        return super_.isReadOnly();
	}
	
    // from org.andromda.metafacades.uml.AssociationEndFacade
	public boolean isRequired()
	{
        return super_.isRequired();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
