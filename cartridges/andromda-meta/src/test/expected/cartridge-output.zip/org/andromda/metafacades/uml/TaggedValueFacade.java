//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface TaggedValueFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.util.Collection formatHTMLStringAsParagraphs();

   /**
    * <p>
    *  Returns the first value for this tagged value.
    * </p>
    */
    public java.lang.Object getValue();

   /**
    * <p>
    *  Returns the collection of values for this tagged value.
    * </p>
    */
    public java.util.Collection getValues();

}
