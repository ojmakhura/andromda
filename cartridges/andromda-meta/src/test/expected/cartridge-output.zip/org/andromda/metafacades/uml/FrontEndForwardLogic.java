//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndForward
 *
 * @see org.andromda.metafacades.uml.FrontEndForward
 */
public abstract class FrontEndForwardLogic
    extends org.andromda.metafacades.uml.TransitionFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndForward
{

    protected Object metaObject;

    public FrontEndForwardLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.statemachines.Transition)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndForward";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndForward#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase1aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase1aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase1a;
    private boolean __containedInFrontEndUseCase1aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = this.__containedInFrontEndUseCase1a;
        if (!this.__containedInFrontEndUseCase1aSet)
        {
            handleIsContainedInFrontEndUseCase1aPreCondition();
            containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase1aPostCondition();
            this.__containedInFrontEndUseCase1a = containedInFrontEndUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase1aSet = true;
            }
        }
        return containedInFrontEndUseCase1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndForward#getActionMethodName()
    */
    protected abstract java.lang.String handleGetActionMethodName();

    private void handleGetActionMethodName2aPreCondition()
    {
    }

    private void handleGetActionMethodName2aPostCondition()
    {
    }

    private java.lang.String __actionMethodName2a;
    private boolean __actionMethodName2aSet = false;

    public final java.lang.String getActionMethodName()
    {
        java.lang.String actionMethodName2a = this.__actionMethodName2a;
        if (!this.__actionMethodName2aSet)
        {
            handleGetActionMethodName2aPreCondition();
            actionMethodName2a = handleGetActionMethodName();
            handleGetActionMethodName2aPostCondition();
            this.__actionMethodName2a = actionMethodName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__actionMethodName2aSet = true;
            }
        }
        return actionMethodName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndForward#isEnteringView()
    */
    protected abstract boolean handleIsEnteringView();

    private void handleIsEnteringView3aPreCondition()
    {
    }

    private void handleIsEnteringView3aPostCondition()
    {
    }

    private boolean __enteringView3a;
    private boolean __enteringView3aSet = false;

    public final boolean isEnteringView()
    {
        boolean enteringView3a = this.__enteringView3a;
        if (!this.__enteringView3aSet)
        {
            handleIsEnteringView3aPreCondition();
            enteringView3a = handleIsEnteringView();
            handleIsEnteringView3aPostCondition();
            this.__enteringView3a = enteringView3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enteringView3aSet = true;
            }
        }
        return enteringView3a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndForward#isExitingView()
    */
    protected abstract boolean handleIsExitingView();

    private void handleIsExitingView4aPreCondition()
    {
    }

    private void handleIsExitingView4aPostCondition()
    {
    }

    private boolean __exitingView4a;
    private boolean __exitingView4aSet = false;

    public final boolean isExitingView()
    {
        boolean exitingView4a = this.__exitingView4a;
        if (!this.__exitingView4aSet)
        {
            handleIsExitingView4aPreCondition();
            exitingView4a = handleIsExitingView();
            handleIsExitingView4aPostCondition();
            this.__exitingView4a = exitingView4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exitingView4aSet = true;
            }
        }
        return exitingView4a;
    }

    // ------------- associations ------------------

    private void handleGetFrontEndActivityGraph2rPreCondition()
    {
    }

    private void handleGetFrontEndActivityGraph2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndActivityGraph __getFrontEndActivityGraph2r;
    private boolean __getFrontEndActivityGraph2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndActivityGraph getFrontEndActivityGraph()
    {
        org.andromda.metafacades.uml.FrontEndActivityGraph getFrontEndActivityGraph2r = this.__getFrontEndActivityGraph2r;
        if (!this.__getFrontEndActivityGraph2rSet)
        {
            handleGetFrontEndActivityGraph2rPreCondition();
            Object result = this.shieldedElement(handleGetFrontEndActivityGraph());
            try
            {
                getFrontEndActivityGraph2r = (org.andromda.metafacades.uml.FrontEndActivityGraph)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFrontEndActivityGraph2rPostCondition();
            this.__getFrontEndActivityGraph2r = getFrontEndActivityGraph2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndActivityGraph2rSet = true;
            }
        }
        return getFrontEndActivityGraph2r;
    }

    protected abstract java.lang.Object handleGetFrontEndActivityGraph();

    private void handleGetUseCase3rPreCondition()
    {
    }

    private void handleGetUseCase3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndUseCase __getUseCase3r;
    private boolean __getUseCase3rSet = false;

    public final org.andromda.metafacades.uml.FrontEndUseCase getUseCase()
    {
        org.andromda.metafacades.uml.FrontEndUseCase getUseCase3r = this.__getUseCase3r;
        if (!this.__getUseCase3rSet)
        {
            handleGetUseCase3rPreCondition();
            Object result = this.shieldedElement(handleGetUseCase());
            try
            {
                getUseCase3r = (org.andromda.metafacades.uml.FrontEndUseCase)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetUseCase3rPostCondition();
            this.__getUseCase3r = getUseCase3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase3rSet = true;
            }
        }
        return getUseCase3r;
    }

    protected abstract java.lang.Object handleGetUseCase();

    private void handleGetDecisionTrigger5rPreCondition()
    {
    }

    private void handleGetDecisionTrigger5rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndEvent __getDecisionTrigger5r;
    private boolean __getDecisionTrigger5rSet = false;

    public final org.andromda.metafacades.uml.FrontEndEvent getDecisionTrigger()
    {
        org.andromda.metafacades.uml.FrontEndEvent getDecisionTrigger5r = this.__getDecisionTrigger5r;
        if (!this.__getDecisionTrigger5rSet)
        {
            handleGetDecisionTrigger5rPreCondition();
            Object result = this.shieldedElement(handleGetDecisionTrigger());
            try
            {
                getDecisionTrigger5r = (org.andromda.metafacades.uml.FrontEndEvent)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDecisionTrigger5rPostCondition();
            this.__getDecisionTrigger5r = getDecisionTrigger5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDecisionTrigger5rSet = true;
            }
        }
        return getDecisionTrigger5r;
    }

    protected abstract java.lang.Object handleGetDecisionTrigger();

    private void handleGetActions6rPreCondition()
    {
    }

    private void handleGetActions6rPostCondition()
    {
    }

    private java.util.List __getActions6r;
    private boolean __getActions6rSet = false;

    public final java.util.List getActions()
    {
        java.util.List getActions6r = this.__getActions6r;
        if (!this.__getActions6rSet)
        {
            handleGetActions6rPreCondition();
            Object result = this.shieldedElements(handleGetActions());
            try
            {
                getActions6r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActions6rPostCondition();
            this.__getActions6r = getActions6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions6rSet = true;
            }
        }
        return getActions6r;
    }

    protected abstract java.util.List handleGetActions();

    private void handleGetForwardParameters7rPreCondition()
    {
    }

    private void handleGetForwardParameters7rPostCondition()
    {
    }

    private java.util.List __getForwardParameters7r;
    private boolean __getForwardParameters7rSet = false;

    public final java.util.List getForwardParameters()
    {
        java.util.List getForwardParameters7r = this.__getForwardParameters7r;
        if (!this.__getForwardParameters7rSet)
        {
            handleGetForwardParameters7rPreCondition();
            Object result = this.shieldedElements(handleGetForwardParameters());
            try
            {
                getForwardParameters7r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetForwardParameters7rPostCondition();
            this.__getForwardParameters7r = getForwardParameters7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getForwardParameters7rSet = true;
            }
        }
        return getForwardParameters7r;
    }

    protected abstract java.util.List handleGetForwardParameters();

    private void handleGetOperationCall9rPreCondition()
    {
    }

    private void handleGetOperationCall9rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndControllerOperation __getOperationCall9r;
    private boolean __getOperationCall9rSet = false;

    public final org.andromda.metafacades.uml.FrontEndControllerOperation getOperationCall()
    {
        org.andromda.metafacades.uml.FrontEndControllerOperation getOperationCall9r = this.__getOperationCall9r;
        if (!this.__getOperationCall9rSet)
        {
            handleGetOperationCall9rPreCondition();
            Object result = this.shieldedElement(handleGetOperationCall());
            try
            {
                getOperationCall9r = (org.andromda.metafacades.uml.FrontEndControllerOperation)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetOperationCall9rPostCondition();
            this.__getOperationCall9r = getOperationCall9r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getOperationCall9rSet = true;
            }
        }
        return getOperationCall9r;
    }

    protected abstract java.lang.Object handleGetOperationCall();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}