// license-header java merge-point
/**
 * This is only generated once by PSMmetaclassImpl.vsl! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see org.andromda.cartridges.meta.CostPosition
 */
public abstract class CostPositionImpl
    extends org.andromda.cartridges.meta.CostPosition
{
    /**
     * Public default constructor for CostPositionImpl
     */
    public CostPositionImpl()
    {
        super();
    }

    /**
     * Public constructor for CostPositionImpl with all properties.
     * @param nameIn java.lang.String 
     * @param priceIn double 
     */
    public CostPositionImpl(java.lang.String name, double price)
    {
        super(name, price);
    }

    /**
     * Copy-constructor from other CostPosition
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public CostPositionImpl(CostPosition otherBean)
    {
        this(otherBean.getName(), otherBean.getPrice());
    }

}
