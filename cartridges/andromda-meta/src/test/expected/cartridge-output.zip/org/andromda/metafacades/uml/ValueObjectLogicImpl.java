package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ValueObject.
 *
 * @see org.andromda.metafacades.uml.ValueObject
 */
public class ValueObjectLogicImpl
    extends ValueObjectLogic
{

    public ValueObjectLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}