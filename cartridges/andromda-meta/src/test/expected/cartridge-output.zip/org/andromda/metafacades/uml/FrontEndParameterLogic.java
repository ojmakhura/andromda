//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndParameter
 *
 * @see org.andromda.metafacades.uml.FrontEndParameter
 */
public abstract class FrontEndParameterLogic
    extends org.andromda.metafacades.uml.ParameterFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndParameter
{

    protected Object metaObject;

    public FrontEndParameterLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Parameter)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndParameter";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isControllerOperationArgument()
    */
    protected abstract boolean handleIsControllerOperationArgument();

    private void handleIsControllerOperationArgument1aPreCondition()
    {
    }

    private void handleIsControllerOperationArgument1aPostCondition()
    {
    }

    private boolean __controllerOperationArgument1a;
    private boolean __controllerOperationArgument1aSet = false;

    public final boolean isControllerOperationArgument()
    {
        boolean controllerOperationArgument1a = this.__controllerOperationArgument1a;
        if (!this.__controllerOperationArgument1aSet)
        {
            handleIsControllerOperationArgument1aPreCondition();
            controllerOperationArgument1a = handleIsControllerOperationArgument();
            handleIsControllerOperationArgument1aPostCondition();
            this.__controllerOperationArgument1a = controllerOperationArgument1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__controllerOperationArgument1aSet = true;
            }
        }
        return controllerOperationArgument1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase2aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase2aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase2a;
    private boolean __containedInFrontEndUseCase2aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase2a = this.__containedInFrontEndUseCase2a;
        if (!this.__containedInFrontEndUseCase2aSet)
        {
            handleIsContainedInFrontEndUseCase2aPreCondition();
            containedInFrontEndUseCase2a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase2aPostCondition();
            this.__containedInFrontEndUseCase2a = containedInFrontEndUseCase2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase2aSet = true;
            }
        }
        return containedInFrontEndUseCase2a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isActionParameter()
    */
    protected abstract boolean handleIsActionParameter();

    private void handleIsActionParameter3aPreCondition()
    {
    }

    private void handleIsActionParameter3aPostCondition()
    {
    }

    private boolean __actionParameter3a;
    private boolean __actionParameter3aSet = false;

    public final boolean isActionParameter()
    {
        boolean actionParameter3a = this.__actionParameter3a;
        if (!this.__actionParameter3aSet)
        {
            handleIsActionParameter3aPreCondition();
            actionParameter3a = handleIsActionParameter();
            handleIsActionParameter3aPostCondition();
            this.__actionParameter3a = actionParameter3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__actionParameter3aSet = true;
            }
        }
        return actionParameter3a;
    }

    // ------------- associations ------------------

    private void handleGetControllerOperation1rPreCondition()
    {
    }

    private void handleGetControllerOperation1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndControllerOperation __getControllerOperation1r;
    private boolean __getControllerOperation1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndControllerOperation getControllerOperation()
    {
        org.andromda.metafacades.uml.FrontEndControllerOperation getControllerOperation1r = this.__getControllerOperation1r;
        if (!this.__getControllerOperation1rSet)
        {
            handleGetControllerOperation1rPreCondition();
            Object result = this.shieldedElement(handleGetControllerOperation());
            try
            {
                getControllerOperation1r = (org.andromda.metafacades.uml.FrontEndControllerOperation)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetControllerOperation1rPostCondition();
            this.__getControllerOperation1r = getControllerOperation1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerOperation1rSet = true;
            }
        }
        return getControllerOperation1r;
    }

    protected abstract java.lang.Object handleGetControllerOperation();

    private void handleGetView2rPreCondition()
    {
    }

    private void handleGetView2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndView __getView2r;
    private boolean __getView2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndView getView()
    {
        org.andromda.metafacades.uml.FrontEndView getView2r = this.__getView2r;
        if (!this.__getView2rSet)
        {
            handleGetView2rPreCondition();
            Object result = this.shieldedElement(handleGetView());
            try
            {
                getView2r = (org.andromda.metafacades.uml.FrontEndView)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetView2rPostCondition();
            this.__getView2r = getView2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getView2rSet = true;
            }
        }
        return getView2r;
    }

    protected abstract java.lang.Object handleGetView();

    private void handleGetAction3rPreCondition()
    {
    }

    private void handleGetAction3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndAction __getAction3r;
    private boolean __getAction3rSet = false;

    public final org.andromda.metafacades.uml.FrontEndAction getAction()
    {
        org.andromda.metafacades.uml.FrontEndAction getAction3r = this.__getAction3r;
        if (!this.__getAction3rSet)
        {
            handleGetAction3rPreCondition();
            Object result = this.shieldedElement(handleGetAction());
            try
            {
                getAction3r = (org.andromda.metafacades.uml.FrontEndAction)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAction3rPostCondition();
            this.__getAction3r = getAction3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAction3rSet = true;
            }
        }
        return getAction3r;
    }

    protected abstract java.lang.Object handleGetAction();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}