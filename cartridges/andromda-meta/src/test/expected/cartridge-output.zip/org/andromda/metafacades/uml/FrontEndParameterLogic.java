//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndParameter
 *
 * @see org.andromda.metafacades.uml.FrontEndParameter
 */
public abstract class FrontEndParameterLogic
    extends org.andromda.metafacades.uml.ParameterFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndParameter
{

    protected Object metaObject;

    public FrontEndParameterLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Parameter)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndParameter";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isControllerOperationArgument()
    */
    protected abstract boolean handleIsControllerOperationArgument();

    private void handleIsControllerOperationArgument1aPreCondition()
    {
    }

    private void handleIsControllerOperationArgument1aPostCondition()
    {
    }

    private boolean __controllerOperationArgument1a;
    private boolean __controllerOperationArgument1aSet = false;

    public final boolean isControllerOperationArgument()
    {
        boolean controllerOperationArgument1a = this.__controllerOperationArgument1a;
        if (!this.__controllerOperationArgument1aSet)
        {
            handleIsControllerOperationArgument1aPreCondition();
            controllerOperationArgument1a = handleIsControllerOperationArgument();
            handleIsControllerOperationArgument1aPostCondition();
            this.__controllerOperationArgument1a = controllerOperationArgument1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__controllerOperationArgument1aSet = true;
            }
        }
        return controllerOperationArgument1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase2aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase2aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase2a;
    private boolean __containedInFrontEndUseCase2aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase2a = this.__containedInFrontEndUseCase2a;
        if (!this.__containedInFrontEndUseCase2aSet)
        {
            handleIsContainedInFrontEndUseCase2aPreCondition();
            containedInFrontEndUseCase2a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase2aPostCondition();
            this.__containedInFrontEndUseCase2a = containedInFrontEndUseCase2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase2aSet = true;
            }
        }
        return containedInFrontEndUseCase2a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isActionParameter()
    */
    protected abstract boolean handleIsActionParameter();

    private void handleIsActionParameter3aPreCondition()
    {
    }

    private void handleIsActionParameter3aPostCondition()
    {
    }

    private boolean __actionParameter3a;
    private boolean __actionParameter3aSet = false;

    public final boolean isActionParameter()
    {
        boolean actionParameter3a = this.__actionParameter3a;
        if (!this.__actionParameter3aSet)
        {
            handleIsActionParameter3aPreCondition();
            actionParameter3a = handleIsActionParameter();
            handleIsActionParameter3aPostCondition();
            this.__actionParameter3a = actionParameter3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__actionParameter3aSet = true;
            }
        }
        return actionParameter3a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#isTable()
    */
    protected abstract boolean handleIsTable();

    private void handleIsTable4aPreCondition()
    {
    }

    private void handleIsTable4aPostCondition()
    {
    }

    private boolean __table4a;
    private boolean __table4aSet = false;

    public final boolean isTable()
    {
        boolean table4a = this.__table4a;
        if (!this.__table4aSet)
        {
            handleIsTable4aPreCondition();
            table4a = handleIsTable();
            handleIsTable4aPostCondition();
            this.__table4a = table4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__table4aSet = true;
            }
        }
        return table4a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#getTableColumnNames()
    */
    protected abstract java.util.Collection handleGetTableColumnNames();

    private void handleGetTableColumnNames5aPreCondition()
    {
    }

    private void handleGetTableColumnNames5aPostCondition()
    {
    }

    private java.util.Collection __tableColumnNames5a;
    private boolean __tableColumnNames5aSet = false;

    public final java.util.Collection getTableColumnNames()
    {
        java.util.Collection tableColumnNames5a = this.__tableColumnNames5a;
        if (!this.__tableColumnNames5aSet)
        {
            handleGetTableColumnNames5aPreCondition();
            tableColumnNames5a = handleGetTableColumnNames();
            handleGetTableColumnNames5aPostCondition();
            this.__tableColumnNames5a = tableColumnNames5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__tableColumnNames5aSet = true;
            }
        }
        return tableColumnNames5a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndParameter#getTableAttributeNames()
    */
    protected abstract java.util.Collection handleGetTableAttributeNames();

    private void handleGetTableAttributeNames6aPreCondition()
    {
    }

    private void handleGetTableAttributeNames6aPostCondition()
    {
    }

    private java.util.Collection __tableAttributeNames6a;
    private boolean __tableAttributeNames6aSet = false;

    public final java.util.Collection getTableAttributeNames()
    {
        java.util.Collection tableAttributeNames6a = this.__tableAttributeNames6a;
        if (!this.__tableAttributeNames6aSet)
        {
            handleGetTableAttributeNames6aPreCondition();
            tableAttributeNames6a = handleGetTableAttributeNames();
            handleGetTableAttributeNames6aPostCondition();
            this.__tableAttributeNames6a = tableAttributeNames6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__tableAttributeNames6aSet = true;
            }
        }
        return tableAttributeNames6a;
    }

    // ------------- associations ------------------

    private void handleGetControllerOperation1rPreCondition()
    {
    }

    private void handleGetControllerOperation1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndControllerOperation __getControllerOperation1r;
    private boolean __getControllerOperation1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndControllerOperation getControllerOperation()
    {
        org.andromda.metafacades.uml.FrontEndControllerOperation getControllerOperation1r = this.__getControllerOperation1r;
        if (!this.__getControllerOperation1rSet)
        {
            handleGetControllerOperation1rPreCondition();
            Object result = this.shieldedElement(handleGetControllerOperation());
            try
            {
                getControllerOperation1r = (org.andromda.metafacades.uml.FrontEndControllerOperation)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetControllerOperation1rPostCondition();
            this.__getControllerOperation1r = getControllerOperation1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerOperation1rSet = true;
            }
        }
        return getControllerOperation1r;
    }

    protected abstract java.lang.Object handleGetControllerOperation();

    private void handleGetView2rPreCondition()
    {
    }

    private void handleGetView2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndView __getView2r;
    private boolean __getView2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndView getView()
    {
        org.andromda.metafacades.uml.FrontEndView getView2r = this.__getView2r;
        if (!this.__getView2rSet)
        {
            handleGetView2rPreCondition();
            Object result = this.shieldedElement(handleGetView());
            try
            {
                getView2r = (org.andromda.metafacades.uml.FrontEndView)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetView2rPostCondition();
            this.__getView2r = getView2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getView2rSet = true;
            }
        }
        return getView2r;
    }

    protected abstract java.lang.Object handleGetView();

    private void handleGetAction3rPreCondition()
    {
    }

    private void handleGetAction3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndAction __getAction3r;
    private boolean __getAction3rSet = false;

    public final org.andromda.metafacades.uml.FrontEndAction getAction()
    {
        org.andromda.metafacades.uml.FrontEndAction getAction3r = this.__getAction3r;
        if (!this.__getAction3rSet)
        {
            handleGetAction3rPreCondition();
            Object result = this.shieldedElement(handleGetAction());
            try
            {
                getAction3r = (org.andromda.metafacades.uml.FrontEndAction)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAction3rPostCondition();
            this.__getAction3r = getAction3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAction3rSet = true;
            }
        }
        return getAction3r;
    }

    protected abstract java.lang.Object handleGetAction();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}