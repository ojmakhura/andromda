package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ValueObjectFacade.
 *
 * @see org.andromda.metafacades.uml.ValueObjectFacade
 */
public class ValueObjectFacadeLogicImpl
    extends ValueObjectFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ValueObjectFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}
