package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.InterfaceFacade.
 *
 * @see org.andromda.metafacades.uml.InterfaceFacade
 */
public class InterfaceFacadeLogicImpl
    extends InterfaceFacadeLogic
{

    public InterfaceFacadeLogicImpl (org.omg.uml.foundation.core.Interface metaObject, String context)
    {
        super (metaObject, context);
    }
}