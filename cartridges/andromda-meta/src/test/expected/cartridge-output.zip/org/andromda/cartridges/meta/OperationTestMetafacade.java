//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface OperationTestMetafacade
    extends org.andromda.metafacades.uml.OperationFacade
{

   /**
    * 
    */
    public org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier();

   /**
    * 
    */
    public boolean isTestAttribute();

}