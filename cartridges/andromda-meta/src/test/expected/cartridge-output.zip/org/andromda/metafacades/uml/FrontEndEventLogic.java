//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndEvent
 *
 * @see org.andromda.metafacades.uml.FrontEndEvent
 */
public abstract class FrontEndEventLogic
    extends org.andromda.metafacades.uml.EventFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndEvent
{

    protected Object metaObject;

    public FrontEndEventLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.statemachines.Event)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndEvent";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndEvent#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase1aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase1aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase1a;
    private boolean __containedInFrontEndUseCase1aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = this.__containedInFrontEndUseCase1a;
        if (!this.__containedInFrontEndUseCase1aSet)
        {
            handleIsContainedInFrontEndUseCase1aPreCondition();
            containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase1aPostCondition();
            this.__containedInFrontEndUseCase1a = containedInFrontEndUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase1aSet = true;
            }
        }
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private void handleGetControllerCall1rPreCondition()
    {
    }

    private void handleGetControllerCall1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndControllerOperation __getControllerCall1r;
    private boolean __getControllerCall1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndControllerOperation getControllerCall()
    {
        org.andromda.metafacades.uml.FrontEndControllerOperation getControllerCall1r = this.__getControllerCall1r;
        if (!this.__getControllerCall1rSet)
        {
            handleGetControllerCall1rPreCondition();
            Object result = this.shieldedElement(handleGetControllerCall());
            try
            {
                getControllerCall1r = (org.andromda.metafacades.uml.FrontEndControllerOperation)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetControllerCall1rPostCondition();
            this.__getControllerCall1r = getControllerCall1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerCall1rSet = true;
            }
        }
        return getControllerCall1r;
    }

    protected abstract java.lang.Object handleGetControllerCall();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}