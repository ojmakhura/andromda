package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ServiceOperation.
 *
 * @see org.andromda.metafacades.uml.ServiceOperation
 */
public class ServiceOperationLogicImpl
    extends ServiceOperationLogic
{
    // ---------------- constructor -------------------------------

    public ServiceOperationLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ServiceOperation#getRoles()
     */
    protected java.util.Collection handleGetServiceOperation()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ServiceOperation#getService()
     */
    protected java.lang.Object handleGetServiceOperation()
    {
        // TODO: add your implementation here!
        return null;
    }

}