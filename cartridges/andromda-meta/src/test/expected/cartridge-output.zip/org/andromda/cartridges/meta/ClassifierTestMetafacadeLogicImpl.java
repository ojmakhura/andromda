package org.andromda.cartridges.meta;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.meta.ClassifierTestMetafacade.
 *
 * @see org.andromda.cartridges.meta.ClassifierTestMetafacade
 */
public class ClassifierTestMetafacadeLogicImpl
    extends ClassifierTestMetafacadeLogic
{
    // ---------------- constructor -------------------------------

    public ClassifierTestMetafacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.meta.ClassifierTestMetafacade#getTestAttribute()
     */
    protected java.lang.String handleGetTestAttribute()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.cartridges.meta.ClassifierTestMetafacade#isTestMetafacade()
     */
    protected boolean handleIsTestMetafacade()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.meta.ClassifierTestMetafacade#getTestOperations()
     */
    protected java.util.Collection handleGetTestClassifier()
    {
        // TODO: add your implementation here!
        return null;
    }

}