package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.StateVertexFacade.
 *
 * @see org.andromda.metafacades.uml.StateVertexFacade
 */
public class StateVertexFacadeLogicImpl
       extends StateVertexFacadeLogic
       implements org.andromda.metafacades.uml.StateVertexFacade
{
    // ---------------- constructor -------------------------------

    public StateVertexFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.StateVertex metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getActivityGraph()
     */
    public java.lang.Object handleGetActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getOutgoing()
     */
    public java.util.Collection handleGetOutgoing()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getIncoming()
     */
    public java.util.Collection handleGetIncoming()
    {
        // TODO: add your implementation here!
        return null;
    }

}
