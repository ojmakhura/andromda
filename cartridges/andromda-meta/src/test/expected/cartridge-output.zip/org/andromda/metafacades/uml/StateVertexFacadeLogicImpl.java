package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.StateVertexFacade.
 *
 * @see org.andromda.metafacades.uml.StateVertexFacade
 */
public class StateVertexFacadeLogicImpl
    extends StateVertexFacadeLogic
{
    // ---------------- constructor -------------------------------

    public StateVertexFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.StateVertex metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getActivityGraph()
     */
    protected java.lang.Object handleGetActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getOutgoing()
     */
    protected java.util.Collection handleGetOutgoing()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateVertexFacade#getIncoming()
     */
    protected java.util.Collection handleGetIncoming()
    {
        // TODO: add your implementation here!
        return null;
    }

}
