package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.PseudostateFacade.
 *
 * @see org.andromda.metafacades.uml.PseudostateFacade
 */
public class PseudostateFacadeLogicImpl
       extends PseudostateFacadeLogic
       implements org.andromda.metafacades.uml.PseudostateFacade
{
    // ---------------- constructor -------------------------------

    public PseudostateFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isChoice()
     */
    public boolean handleIsChoice() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isInitialState()
     */
    public boolean handleIsInitialState() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isJoin()
     */
    public boolean handleIsJoin() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isDeepHistory()
     */
    public boolean handleIsDeepHistory() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isFork()
     */
    public boolean handleIsFork() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isJunction()
     */
    public boolean handleIsJunction() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isShallowHistory()
     */
    public boolean handleIsShallowHistory() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isDecisionPoint()
     */
    public boolean handleIsDecisionPoint() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.PseudostateFacade#isMergePoint()
     */
    public boolean handleIsMergePoint() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

}
