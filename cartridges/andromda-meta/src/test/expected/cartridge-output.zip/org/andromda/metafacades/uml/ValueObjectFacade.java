//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a value object.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ValueObjectFacade
       extends org.andromda.metafacades.uml.ClassifierFacade
{

}
