//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndActivityGraph
 *
 * @see org.andromda.metafacades.uml.FrontEndActivityGraph
 */
public abstract class FrontEndActivityGraphLogic
    extends org.andromda.metafacades.uml.ActivityGraphFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndActivityGraph
{

    protected Object metaObject;

    public FrontEndActivityGraphLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.activitygraphs.ActivityGraph)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndActivityGraph";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndActivityGraph#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase1aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase1aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase1a;
    private boolean __containedInFrontEndUseCase1aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = this.__containedInFrontEndUseCase1a;
        if (!this.__containedInFrontEndUseCase1aSet)
        {
            handleIsContainedInFrontEndUseCase1aPreCondition();
            containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase1aPostCondition();
            this.__containedInFrontEndUseCase1a = containedInFrontEndUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase1aSet = true;
            }
        }
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private void handleGetController2rPreCondition()
    {
    }

    private void handleGetController2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndController __getController2r;
    private boolean __getController2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndController getController()
    {
        org.andromda.metafacades.uml.FrontEndController getController2r = this.__getController2r;
        if (!this.__getController2rSet)
        {
            handleGetController2rPreCondition();
            Object result = this.shieldedElement(handleGetController());
            try
            {
                getController2r = (org.andromda.metafacades.uml.FrontEndController)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetController2rPostCondition();
            this.__getController2r = getController2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController2rSet = true;
            }
        }
        return getController2r;
    }

    protected abstract java.lang.Object handleGetController();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"controller")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "An activity graph must have a controller class context to which (optionally) operations can be deferred. Make sure this graph's use-case has the FrontEndUseCase stereotype."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}