//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EnumerationLiteralFacade
 *
 * @see org.andromda.metafacades.uml.EnumerationLiteralFacade
 */
public abstract class EnumerationLiteralFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.EnumerationLiteralFacade
{

    protected org.omg.uml.foundation.core.EnumerationLiteral metaObject;

    public EnumerationLiteralFacadeLogic(org.omg.uml.foundation.core.EnumerationLiteral metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EnumerationLiteralFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EnumerationLiteralFacade#getValue()
    */
    protected abstract java.lang.String handleGetValue();

    private void handleGetValue1aPreCondition()
    {
    }

    private void handleGetValue1aPostCondition()
    {
    }

    private java.lang.String __value1a;
    private boolean __value1aSet = false;

    public final java.lang.String getValue()
    {
        java.lang.String value1a = this.__value1a;
        if (!this.__value1aSet)
        {
            handleGetValue1aPreCondition();
            value1a = handleGetValue();
            handleGetValue1aPostCondition();
            this.__value1a = value1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__value1aSet = true;
            }
        }
        return value1a;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}