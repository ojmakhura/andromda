//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PseudostateFacade
 *
 * @see org.andromda.metafacades.uml.PseudostateFacade
 */
public abstract class PseudostateFacadeLogic
    extends org.andromda.metafacades.uml.StateVertexFacadeLogicImpl
    implements org.andromda.metafacades.uml.PseudostateFacade
{

    protected org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject;

    public PseudostateFacadeLogic(org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PseudostateFacade";
        }
        return context;
    }
    

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isChoice()
    */
    protected abstract boolean handleIsChoice();

    private void handleIsChoice1aPreCondition()
    {
    }

    private void handleIsChoice1aPostCondition()
    {
    }

    private boolean __choice1a;
    private boolean __choice1aSet = false;

    public final boolean isChoice()
    {
        boolean choice1a = this.__choice1a;
        if (!this.__choice1aSet)
        {
            handleIsChoice1aPreCondition();
            choice1a = handleIsChoice();
            handleIsChoice1aPostCondition();
            this.__choice1a = choice1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__choice1aSet = true;
            }
        }
        return choice1a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isDecisionPoint()
    */
    protected abstract boolean handleIsDecisionPoint();

    private void handleIsDecisionPoint2aPreCondition()
    {
    }

    private void handleIsDecisionPoint2aPostCondition()
    {
    }

    private boolean __decisionPoint2a;
    private boolean __decisionPoint2aSet = false;

    public final boolean isDecisionPoint()
    {
        boolean decisionPoint2a = this.__decisionPoint2a;
        if (!this.__decisionPoint2aSet)
        {
            handleIsDecisionPoint2aPreCondition();
            decisionPoint2a = handleIsDecisionPoint();
            handleIsDecisionPoint2aPostCondition();
            this.__decisionPoint2a = decisionPoint2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__decisionPoint2aSet = true;
            }
        }
        return decisionPoint2a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isDeepHistory()
    */
    protected abstract boolean handleIsDeepHistory();

    private void handleIsDeepHistory3aPreCondition()
    {
    }

    private void handleIsDeepHistory3aPostCondition()
    {
    }

    private boolean __deepHistory3a;
    private boolean __deepHistory3aSet = false;

    public final boolean isDeepHistory()
    {
        boolean deepHistory3a = this.__deepHistory3a;
        if (!this.__deepHistory3aSet)
        {
            handleIsDeepHistory3aPreCondition();
            deepHistory3a = handleIsDeepHistory();
            handleIsDeepHistory3aPostCondition();
            this.__deepHistory3a = deepHistory3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__deepHistory3aSet = true;
            }
        }
        return deepHistory3a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isFork()
    */
    protected abstract boolean handleIsFork();

    private void handleIsFork4aPreCondition()
    {
    }

    private void handleIsFork4aPostCondition()
    {
    }

    private boolean __fork4a;
    private boolean __fork4aSet = false;

    public final boolean isFork()
    {
        boolean fork4a = this.__fork4a;
        if (!this.__fork4aSet)
        {
            handleIsFork4aPreCondition();
            fork4a = handleIsFork();
            handleIsFork4aPostCondition();
            this.__fork4a = fork4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fork4aSet = true;
            }
        }
        return fork4a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isInitialState()
    */
    protected abstract boolean handleIsInitialState();

    private void handleIsInitialState5aPreCondition()
    {
    }

    private void handleIsInitialState5aPostCondition()
    {
    }

    private boolean __initialState5a;
    private boolean __initialState5aSet = false;

    public final boolean isInitialState()
    {
        boolean initialState5a = this.__initialState5a;
        if (!this.__initialState5aSet)
        {
            handleIsInitialState5aPreCondition();
            initialState5a = handleIsInitialState();
            handleIsInitialState5aPostCondition();
            this.__initialState5a = initialState5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__initialState5aSet = true;
            }
        }
        return initialState5a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isJoin()
    */
    protected abstract boolean handleIsJoin();

    private void handleIsJoin6aPreCondition()
    {
    }

    private void handleIsJoin6aPostCondition()
    {
    }

    private boolean __join6a;
    private boolean __join6aSet = false;

    public final boolean isJoin()
    {
        boolean join6a = this.__join6a;
        if (!this.__join6aSet)
        {
            handleIsJoin6aPreCondition();
            join6a = handleIsJoin();
            handleIsJoin6aPostCondition();
            this.__join6a = join6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__join6aSet = true;
            }
        }
        return join6a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isJunction()
    */
    protected abstract boolean handleIsJunction();

    private void handleIsJunction7aPreCondition()
    {
    }

    private void handleIsJunction7aPostCondition()
    {
    }

    private boolean __junction7a;
    private boolean __junction7aSet = false;

    public final boolean isJunction()
    {
        boolean junction7a = this.__junction7a;
        if (!this.__junction7aSet)
        {
            handleIsJunction7aPreCondition();
            junction7a = handleIsJunction();
            handleIsJunction7aPostCondition();
            this.__junction7a = junction7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__junction7aSet = true;
            }
        }
        return junction7a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isMergePoint()
    */
    protected abstract boolean handleIsMergePoint();

    private void handleIsMergePoint8aPreCondition()
    {
    }

    private void handleIsMergePoint8aPostCondition()
    {
    }

    private boolean __mergePoint8a;
    private boolean __mergePoint8aSet = false;

    public final boolean isMergePoint()
    {
        boolean mergePoint8a = this.__mergePoint8a;
        if (!this.__mergePoint8aSet)
        {
            handleIsMergePoint8aPreCondition();
            mergePoint8a = handleIsMergePoint();
            handleIsMergePoint8aPostCondition();
            this.__mergePoint8a = mergePoint8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__mergePoint8aSet = true;
            }
        }
        return mergePoint8a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isShallowHistory()
    */
    protected abstract boolean handleIsShallowHistory();

    private void handleIsShallowHistory9aPreCondition()
    {
    }

    private void handleIsShallowHistory9aPostCondition()
    {
    }

    private boolean __shallowHistory9a;
    private boolean __shallowHistory9aSet = false;

    public final boolean isShallowHistory()
    {
        boolean shallowHistory9a = this.__shallowHistory9a;
        if (!this.__shallowHistory9aSet)
        {
            handleIsShallowHistory9aPreCondition();
            shallowHistory9a = handleIsShallowHistory();
            handleIsShallowHistory9aPostCondition();
            this.__shallowHistory9a = shallowHistory9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__shallowHistory9aSet = true;
            }
        }
        return shallowHistory9a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}