//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PseudostateFacade
 *
 * @see org.andromda.metafacades.uml.PseudostateFacade
 */
public abstract class PseudostateFacadeLogic
    extends org.andromda.metafacades.uml.StateVertexFacadeLogicImpl
    implements org.andromda.metafacades.uml.PseudostateFacade
{

    protected org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject;

    public PseudostateFacadeLogic (org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject, String context)
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PseudostateFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isChoice()
    */
    protected abstract boolean handleIsChoice();

    private void handleIsChoice1aPreCondition()
    {
    }

    private void handleIsChoice1aPostCondition()
    {
    }

    public final boolean isChoice()
    {
        boolean choice1a = false;
        handleIsChoice1aPreCondition();
        choice1a = handleIsChoice();
        handleIsChoice1aPostCondition();
        return choice1a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isDecisionPoint()
    */
    protected abstract boolean handleIsDecisionPoint();

    private void handleIsDecisionPoint2aPreCondition()
    {
    }

    private void handleIsDecisionPoint2aPostCondition()
    {
    }

    public final boolean isDecisionPoint()
    {
        boolean decisionPoint2a = false;
        handleIsDecisionPoint2aPreCondition();
        decisionPoint2a = handleIsDecisionPoint();
        handleIsDecisionPoint2aPostCondition();
        return decisionPoint2a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isDeepHistory()
    */
    protected abstract boolean handleIsDeepHistory();

    private void handleIsDeepHistory3aPreCondition()
    {
    }

    private void handleIsDeepHistory3aPostCondition()
    {
    }

    public final boolean isDeepHistory()
    {
        boolean deepHistory3a = false;
        handleIsDeepHistory3aPreCondition();
        deepHistory3a = handleIsDeepHistory();
        handleIsDeepHistory3aPostCondition();
        return deepHistory3a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isFork()
    */
    protected abstract boolean handleIsFork();

    private void handleIsFork4aPreCondition()
    {
    }

    private void handleIsFork4aPostCondition()
    {
    }

    public final boolean isFork()
    {
        boolean fork4a = false;
        handleIsFork4aPreCondition();
        fork4a = handleIsFork();
        handleIsFork4aPostCondition();
        return fork4a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isInitialState()
    */
    protected abstract boolean handleIsInitialState();

    private void handleIsInitialState5aPreCondition()
    {
    }

    private void handleIsInitialState5aPostCondition()
    {
    }

    public final boolean isInitialState()
    {
        boolean initialState5a = false;
        handleIsInitialState5aPreCondition();
        initialState5a = handleIsInitialState();
        handleIsInitialState5aPostCondition();
        return initialState5a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isJoin()
    */
    protected abstract boolean handleIsJoin();

    private void handleIsJoin6aPreCondition()
    {
    }

    private void handleIsJoin6aPostCondition()
    {
    }

    public final boolean isJoin()
    {
        boolean join6a = false;
        handleIsJoin6aPreCondition();
        join6a = handleIsJoin();
        handleIsJoin6aPostCondition();
        return join6a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isJunction()
    */
    protected abstract boolean handleIsJunction();

    private void handleIsJunction7aPreCondition()
    {
    }

    private void handleIsJunction7aPostCondition()
    {
    }

    public final boolean isJunction()
    {
        boolean junction7a = false;
        handleIsJunction7aPreCondition();
        junction7a = handleIsJunction();
        handleIsJunction7aPostCondition();
        return junction7a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isMergePoint()
    */
    protected abstract boolean handleIsMergePoint();

    private void handleIsMergePoint8aPreCondition()
    {
    }

    private void handleIsMergePoint8aPostCondition()
    {
    }

    public final boolean isMergePoint()
    {
        boolean mergePoint8a = false;
        handleIsMergePoint8aPreCondition();
        mergePoint8a = handleIsMergePoint();
        handleIsMergePoint8aPostCondition();
        return mergePoint8a;
    }

   /**
    * @see org.andromda.metafacades.uml.PseudostateFacade#isShallowHistory()
    */
    protected abstract boolean handleIsShallowHistory();

    private void handleIsShallowHistory9aPreCondition()
    {
    }

    private void handleIsShallowHistory9aPostCondition()
    {
    }

    public final boolean isShallowHistory()
    {
        boolean shallowHistory9a = false;
        handleIsShallowHistory9aPreCondition();
        shallowHistory9a = handleIsShallowHistory();
        handleIsShallowHistory9aPostCondition();
        return shallowHistory9a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
