//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ConstraintFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * <p>
    *  Gets the 'body' or text of this constraint.
    * </p>
    */
    public java.lang.String getBody();

   /**
    * <p>
    *  Gets the model element to which the constraint applies (i.e. is
    *  the context of).
    * </p>
    */
    public org.andromda.metafacades.uml.ModelElementFacade getContextElement();

   /**
    * 
    */
    public java.lang.String getTranslation(java.lang.String language);

   /**
    * <p>
    *  True if this constraint denotes a body expression. For example:
    *  <pre> context CustomerCard:getTransaction(from:Date,
    *  until:Date) body: transactions->select(date.isAfter(from) and
    *  date.isBefore(until)) </pre> False otherwise.
    * </p>
    */
    public boolean isBodyExpression();

   /**
    * <p>
    *  True if this constraint denotes a definition. For example:
    *  <pre> context CustomerCard def: getTotalPoints(d: date) :
    *  Integer = transaction->select(date.isAfter(d)).points->sum()
    *  </pre> False otherwise.
    * </p>
    */
    public boolean isDefinition();

   /**
    * <p>
    *  True if this constraint denotes an invariant. For example:
    *  <pre> context LivingAnimal inv: alive = true </pre> False
    *  otherwise.
    * </p>
    */
    public boolean isInvariant();

   /**
    * <p>
    *  True if this constraint denotes a postcondition. For example:
    *  <pre> context LivingAnimal::getNumberOfLegs() post:
    *  numberOfLegs >= 0 </pre> False otherwise.
    * </p>
    */
    public boolean isPostCondition();

   /**
    * <p>
    *  True if this constraint denotes a precondition. For example:
    *  <pre> context LivingAnimal::canFly() pre: hasWings = true
    *  </pre> False otherwise.
    * </p>
    */
    public boolean isPreCondition();

}
