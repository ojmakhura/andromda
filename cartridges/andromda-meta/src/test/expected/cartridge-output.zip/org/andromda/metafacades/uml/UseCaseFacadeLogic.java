//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.UseCaseFacade
 *
 * @see org.andromda.metafacades.uml.UseCaseFacade
 */
public abstract class UseCaseFacadeLogic
    extends org.andromda.metafacades.uml.NamespaceFacadeLogicImpl
    implements org.andromda.metafacades.uml.UseCaseFacade
{

    protected org.omg.uml.behavioralelements.usecases.UseCase metaObject;

    public UseCaseFacadeLogic(org.omg.uml.behavioralelements.usecases.UseCase metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.UseCaseFacade";
        }
        return context;
    }
    

    // ------------- associations ------------------

    private void handleGetFirstActivityGraph2rPreCondition()
    {
    }

    private void handleGetFirstActivityGraph2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getFirstActivityGraph()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getFirstActivityGraph2r = null;
        handleGetFirstActivityGraph2rPreCondition();
        Object result = this.shieldedElement(handleGetFirstActivityGraph());
        try
        {
            getFirstActivityGraph2r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetFirstActivityGraph2rPostCondition();
        return getFirstActivityGraph2r;
    }

    protected abstract java.lang.Object handleGetFirstActivityGraph();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}