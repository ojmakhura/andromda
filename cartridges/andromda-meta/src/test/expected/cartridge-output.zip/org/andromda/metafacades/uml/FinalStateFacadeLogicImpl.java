package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.FinalStateFacade.
 *
 * @see org.andromda.metafacades.uml.FinalStateFacade
 */
public class FinalStateFacadeLogicImpl
    extends FinalStateFacadeLogic
{
    // ---------------- constructor -------------------------------

    public FinalStateFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.FinalState metaObject, String context)
    {
        super (metaObject, context);
    }
}