package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.AttributeFacade.
 *
 * @see org.andromda.metafacades.uml.AttributeFacade
 */
public class AttributeFacadeLogicImpl
       extends AttributeFacadeLogic
       implements org.andromda.metafacades.uml.AttributeFacade
{
    // ---------------- constructor -------------------------------

    public AttributeFacadeLogicImpl (org.omg.uml.foundation.core.Attribute metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#getGetterName()
     */
    public java.lang.String handleGetGetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#getSetterName()
     */
    public java.lang.String handleGetSetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isReadOnly()
     */
    public boolean handleIsReadOnly() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#getDefaultValue()
     */
    public java.lang.String handleGetDefaultValue() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isStatic()
     */
    public boolean handleIsStatic() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isRequired()
     */
    public boolean handleIsRequired() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isMany()
     */
    public boolean handleIsMany() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isChangeable()
     */
    public boolean handleIsChangeable() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#isAddOnly()
     */
    public boolean handleIsAddOnly() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#findTaggedValue(java.lang.String, boolean)
     */
    public java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#getOwner()
     */
    public java.lang.Object handleGetOwner()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AttributeFacade#getType()
     */
    public java.lang.Object handleGetType()
    {
        // TODO: add your implementation here!
        return null;
    }

}
