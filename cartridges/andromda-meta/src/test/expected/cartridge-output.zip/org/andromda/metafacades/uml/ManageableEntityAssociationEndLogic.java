//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public abstract class ManageableEntityAssociationEndLogic
    extends org.andromda.metafacades.uml.EntityAssociationEndLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAssociationEnd
{

    protected Object metaObject;

    public ManageableEntityAssociationEndLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAssociationEnd";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getManageableName()
    */
    protected abstract java.lang.String handleGetManageableName();

    private void handleGetManageableName1aPreCondition()
    {
    }

    private void handleGetManageableName1aPostCondition()
    {
    }

    private java.lang.String __manageableName1a;
    private boolean __manageableName1aSet = false;

    public final java.lang.String getManageableName()
    {
        java.lang.String manageableName1a = this.__manageableName1a;
        if (!this.__manageableName1aSet)
        {
            handleGetManageableName1aPreCondition();
            manageableName1a = handleGetManageableName();
            handleGetManageableName1aPostCondition();
            this.__manageableName1a = manageableName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableName1aSet = true;
            }
        }
        return manageableName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getManageableGetterName()
    */
    protected abstract java.lang.String handleGetManageableGetterName();

    private void handleGetManageableGetterName2aPreCondition()
    {
    }

    private void handleGetManageableGetterName2aPostCondition()
    {
    }

    private java.lang.String __manageableGetterName2a;
    private boolean __manageableGetterName2aSet = false;

    public final java.lang.String getManageableGetterName()
    {
        java.lang.String manageableGetterName2a = this.__manageableGetterName2a;
        if (!this.__manageableGetterName2aSet)
        {
            handleGetManageableGetterName2aPreCondition();
            manageableGetterName2a = handleGetManageableGetterName();
            handleGetManageableGetterName2aPostCondition();
            this.__manageableGetterName2a = manageableGetterName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableGetterName2aSet = true;
            }
        }
        return manageableGetterName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getManageableSetterName()
    */
    protected abstract java.lang.String handleGetManageableSetterName();

    private void handleGetManageableSetterName3aPreCondition()
    {
    }

    private void handleGetManageableSetterName3aPostCondition()
    {
    }

    private java.lang.String __manageableSetterName3a;
    private boolean __manageableSetterName3aSet = false;

    public final java.lang.String getManageableSetterName()
    {
        java.lang.String manageableSetterName3a = this.__manageableSetterName3a;
        if (!this.__manageableSetterName3aSet)
        {
            handleGetManageableSetterName3aPreCondition();
            manageableSetterName3a = handleGetManageableSetterName();
            handleGetManageableSetterName3aPostCondition();
            this.__manageableSetterName3a = manageableSetterName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableSetterName3aSet = true;
            }
        }
        return manageableSetterName3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#isDisplay()
    */
    protected abstract boolean handleIsDisplay();

    private void handleIsDisplay4aPreCondition()
    {
    }

    private void handleIsDisplay4aPostCondition()
    {
    }

    private boolean __display4a;
    private boolean __display4aSet = false;

    public final boolean isDisplay()
    {
        boolean display4a = this.__display4a;
        if (!this.__display4aSet)
        {
            handleIsDisplay4aPreCondition();
            display4a = handleIsDisplay();
            handleIsDisplay4aPostCondition();
            this.__display4a = display4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__display4aSet = true;
            }
        }
        return display4a;
    }

    // ------------- associations ------------------

    private void handleGetManageableIdentifier2rPreCondition()
    {
    }

    private void handleGetManageableIdentifier2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.EntityAttribute __getManageableIdentifier2r;
    private boolean __getManageableIdentifier2rSet = false;

    public final org.andromda.metafacades.uml.EntityAttribute getManageableIdentifier()
    {
        org.andromda.metafacades.uml.EntityAttribute getManageableIdentifier2r = this.__getManageableIdentifier2r;
        if (!this.__getManageableIdentifier2rSet)
        {
            handleGetManageableIdentifier2rPreCondition();
            Object result = this.shieldedElement(handleGetManageableIdentifier());
            try
            {
                getManageableIdentifier2r = (org.andromda.metafacades.uml.EntityAttribute)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetManageableIdentifier2rPostCondition();
            this.__getManageableIdentifier2r = getManageableIdentifier2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableIdentifier2rSet = true;
            }
        }
        return getManageableIdentifier2r;
    }

    protected abstract java.lang.Object handleGetManageableIdentifier();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}