//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public abstract class ManageableEntityAssociationEndLogic
    extends org.andromda.metafacades.uml.EntityAssociationEndLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAssociationEnd
{

    protected Object metaObject;

    public ManageableEntityAssociationEndLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAssociationEnd";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#isDisplay()
    */
    protected abstract boolean handleIsDisplay();

    private void handleIsDisplay1aPreCondition()
    {
    }

    private void handleIsDisplay1aPostCondition()
    {
    }

    private boolean __display1a;
    private boolean __display1aSet = false;

    public final boolean isDisplay()
    {
        boolean display1a = this.__display1a;
        if (!this.__display1aSet)
        {
            handleIsDisplay1aPreCondition();
            display1a = handleIsDisplay();
            handleIsDisplay1aPostCondition();
            this.__display1a = display1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__display1aSet = true;
            }
        }
        return display1a;
    }

    // ------------- associations ------------------

    private void handleGetManageableIdentifier2rPreCondition()
    {
    }

    private void handleGetManageableIdentifier2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.EntityAttribute __getManageableIdentifier2r;
    private boolean __getManageableIdentifier2rSet = false;

    public final org.andromda.metafacades.uml.EntityAttribute getManageableIdentifier()
    {
        org.andromda.metafacades.uml.EntityAttribute getManageableIdentifier2r = this.__getManageableIdentifier2r;
        if (!this.__getManageableIdentifier2rSet)
        {
            handleGetManageableIdentifier2rPreCondition();
            Object result = this.shieldedElement(handleGetManageableIdentifier());
            try
            {
                getManageableIdentifier2r = (org.andromda.metafacades.uml.EntityAttribute)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetManageableIdentifier2rPostCondition();
            this.__getManageableIdentifier2r = getManageableIdentifier2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableIdentifier2rSet = true;
            }
        }
        return getManageableIdentifier2r;
    }

    protected abstract java.lang.Object handleGetManageableIdentifier();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}