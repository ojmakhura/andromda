//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public abstract class ManageableEntityAssociationEndLogic
    extends org.andromda.metafacades.uml.EntityAssociationEndLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAssociationEnd
{

    protected Object metaObject;

    public ManageableEntityAssociationEndLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAssociationEnd";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudName()
    */
    protected abstract java.lang.String handleGetCrudName();

    private void handleGetCrudName1aPreCondition()
    {
    }

    private void handleGetCrudName1aPostCondition()
    {
    }

    private java.lang.String __crudName1a;
    private boolean __crudName1aSet = false;

    public final java.lang.String getCrudName()
    {
        java.lang.String crudName1a = this.__crudName1a;
        if (!this.__crudName1aSet)
        {
            handleGetCrudName1aPreCondition();
            crudName1a = handleGetCrudName();
            handleGetCrudName1aPostCondition();
            this.__crudName1a = crudName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudName1aSet = true;
            }
        }
        return crudName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudGetterName()
    */
    protected abstract java.lang.String handleGetCrudGetterName();

    private void handleGetCrudGetterName2aPreCondition()
    {
    }

    private void handleGetCrudGetterName2aPostCondition()
    {
    }

    private java.lang.String __crudGetterName2a;
    private boolean __crudGetterName2aSet = false;

    public final java.lang.String getCrudGetterName()
    {
        java.lang.String crudGetterName2a = this.__crudGetterName2a;
        if (!this.__crudGetterName2aSet)
        {
            handleGetCrudGetterName2aPreCondition();
            crudGetterName2a = handleGetCrudGetterName();
            handleGetCrudGetterName2aPostCondition();
            this.__crudGetterName2a = crudGetterName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudGetterName2aSet = true;
            }
        }
        return crudGetterName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudSetterName()
    */
    protected abstract java.lang.String handleGetCrudSetterName();

    private void handleGetCrudSetterName3aPreCondition()
    {
    }

    private void handleGetCrudSetterName3aPostCondition()
    {
    }

    private java.lang.String __crudSetterName3a;
    private boolean __crudSetterName3aSet = false;

    public final java.lang.String getCrudSetterName()
    {
        java.lang.String crudSetterName3a = this.__crudSetterName3a;
        if (!this.__crudSetterName3aSet)
        {
            handleGetCrudSetterName3aPreCondition();
            crudSetterName3a = handleGetCrudSetterName();
            handleGetCrudSetterName3aPostCondition();
            this.__crudSetterName3a = crudSetterName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudSetterName3aSet = true;
            }
        }
        return crudSetterName3a;
    }

    // ------------- associations ------------------

    private void handleGetCrudType2rPreCondition()
    {
    }

    private void handleGetCrudType2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.ClassifierFacade __getCrudType2r;
    private boolean __getCrudType2rSet = false;

    public final org.andromda.metafacades.uml.ClassifierFacade getCrudType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getCrudType2r = this.__getCrudType2r;
        if (!this.__getCrudType2rSet)
        {
            handleGetCrudType2rPreCondition();
            Object result = this.shieldedElement(handleGetCrudType());
            try
            {
                getCrudType2r = (org.andromda.metafacades.uml.ClassifierFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetCrudType2rPostCondition();
            this.__getCrudType2r = getCrudType2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getCrudType2rSet = true;
            }
        }
        return getCrudType2r;
    }

    protected abstract java.lang.Object handleGetCrudType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}