package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ServiceFacade.
 *
 * @see org.andromda.metafacades.uml.ServiceFacade
 */
public class ServiceFacadeLogicImpl
       extends ServiceFacadeLogic
       implements org.andromda.metafacades.uml.ServiceFacade
{
    // ---------------- constructor -------------------------------

    public ServiceFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ServiceFacade#getServiceReferences()
     */
    public java.util.Collection handleGetServiceReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ServiceFacade#getEntityReferences()
     */
    public java.util.Collection handleGetEntityReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ServiceFacade#getRoles()
     */
    public java.util.Collection handleGetRoles()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ServiceFacade#getAllRoles()
     */
    public java.util.Collection handleGetAllRoles()
    {
        // TODO: add your implementation here!
        return null;
    }

}
