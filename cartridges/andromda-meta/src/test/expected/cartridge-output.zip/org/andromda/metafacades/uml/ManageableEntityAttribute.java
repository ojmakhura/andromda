//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntityAttribute
    extends org.andromda.metafacades.uml.EntityAttribute
{

   /**
    * 
    */
    public java.lang.String getManageableGetterName();

   /**
    * 
    */
    public java.lang.String getManageableName();

   /**
    * 
    */
    public java.lang.String getManageableSetterName();

   /**
    * <p>
    *  Whether or not this attribute should be displayed.
    * </p>
    */
    public boolean isDisplay();

}