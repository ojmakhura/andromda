//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntity
    extends org.andromda.metafacades.uml.Entity
{

   /**
    * 
    */
    public java.util.List getCrudMembers();

   /**
    * 
    */
    public java.lang.String getCrudPackageName();

   /**
    * 
    */
    public java.lang.String getCrudPackagePath();

   /**
    * 
    */
    public java.lang.String getFullyQualifiedServiceName();

   /**
    * 
    */
    public java.util.List getManageableAssociationEnds();

   /**
    * 
    */
    public java.lang.String getServiceAccessorCall();

   /**
    * 
    */
    public java.lang.String getServiceFullPath();

   /**
    * 
    */
    public java.lang.String getServiceName();

   /**
    * 
    */
    public boolean isCreate();

   /**
    * 
    */
    public boolean isDelete();

   /**
    * 
    */
    public boolean isRead();

   /**
    * 
    */
    public boolean isUpdate();

   /**
    * 
    */
    public java.lang.String listCrudMembers(boolean withTypes, boolean useCollectionTypes);

}