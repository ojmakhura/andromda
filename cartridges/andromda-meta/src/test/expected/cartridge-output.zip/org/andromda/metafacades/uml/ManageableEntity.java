//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntity
    extends org.andromda.metafacades.uml.Entity
{

   /**
    * 
    */
    public java.lang.String getFullyQualifiedManageableServiceName();

   /**
    * 
    */
    public java.util.List getManageableAssociationEnds();

   /**
    * 
    */
    public java.util.List getManageableMembers();

   /**
    * 
    */
    public java.lang.String getManageablePackageName();

   /**
    * 
    */
    public java.lang.String getManageablePackagePath();

   /**
    * 
    */
    public java.lang.String getManageableServiceAccessorCall();

   /**
    * 
    */
    public java.lang.String getManageableServiceFullPath();

   /**
    * 
    */
    public java.lang.String getManageableServiceName();

   /**
    * 
    */
    public boolean isCreate();

   /**
    * 
    */
    public boolean isDelete();

   /**
    * 
    */
    public boolean isRead();

   /**
    * 
    */
    public boolean isUpdate();

   /**
    * 
    */
    public java.lang.String listManageableMembers(boolean withTypes, boolean useCollectionTypes);

}