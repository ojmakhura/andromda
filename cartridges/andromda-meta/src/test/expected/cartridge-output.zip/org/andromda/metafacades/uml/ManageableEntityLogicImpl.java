package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntity.
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public class ManageableEntityLogicImpl
    extends ManageableEntityLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackageName()
     */
    protected java.lang.String handleGetCrudPackageName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getServiceAccessorCall()
     */
    protected java.lang.String handleGetServiceAccessorCall()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
     */
    protected boolean handleIsRead()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
     */
    protected boolean handleIsCreate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
     */
    protected boolean handleIsUpdate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
     */
    protected boolean handleIsDelete()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackagePath()
     */
    protected java.lang.String handleGetCrudPackagePath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getServiceName()
     */
    protected java.lang.String handleGetServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getFullyQualifiedServiceName()
     */
    protected java.lang.String handleGetFullyQualifiedServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getServiceFullPath()
     */
    protected java.lang.String handleGetServiceFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudMembers()
     */
    protected java.util.List handleGetCrudMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#listCrudMembers(boolean, boolean)
     */
    protected java.lang.String handleListCrudMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableAssociationEnds()
     */
    protected java.util.List handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

}