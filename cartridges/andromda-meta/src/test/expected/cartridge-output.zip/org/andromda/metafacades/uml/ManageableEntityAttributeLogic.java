//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAttribute
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public abstract class ManageableEntityAttributeLogic
    extends org.andromda.metafacades.uml.EntityAttributeLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAttribute
{

    protected Object metaObject;

    public ManageableEntityAttributeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAttribute";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableGetterName()
    */
    protected abstract java.lang.String handleGetManageableGetterName();

    private void handleGetManageableGetterName1aPreCondition()
    {
    }

    private void handleGetManageableGetterName1aPostCondition()
    {
    }

    private java.lang.String __manageableGetterName1a;
    private boolean __manageableGetterName1aSet = false;

    public final java.lang.String getManageableGetterName()
    {
        java.lang.String manageableGetterName1a = this.__manageableGetterName1a;
        if (!this.__manageableGetterName1aSet)
        {
            handleGetManageableGetterName1aPreCondition();
            manageableGetterName1a = handleGetManageableGetterName();
            handleGetManageableGetterName1aPostCondition();
            this.__manageableGetterName1a = manageableGetterName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableGetterName1aSet = true;
            }
        }
        return manageableGetterName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableName()
    */
    protected abstract java.lang.String handleGetManageableName();

    private void handleGetManageableName2aPreCondition()
    {
    }

    private void handleGetManageableName2aPostCondition()
    {
    }

    private java.lang.String __manageableName2a;
    private boolean __manageableName2aSet = false;

    public final java.lang.String getManageableName()
    {
        java.lang.String manageableName2a = this.__manageableName2a;
        if (!this.__manageableName2aSet)
        {
            handleGetManageableName2aPreCondition();
            manageableName2a = handleGetManageableName();
            handleGetManageableName2aPostCondition();
            this.__manageableName2a = manageableName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableName2aSet = true;
            }
        }
        return manageableName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getManageableSetterName()
    */
    protected abstract java.lang.String handleGetManageableSetterName();

    private void handleGetManageableSetterName3aPreCondition()
    {
    }

    private void handleGetManageableSetterName3aPostCondition()
    {
    }

    private java.lang.String __manageableSetterName3a;
    private boolean __manageableSetterName3aSet = false;

    public final java.lang.String getManageableSetterName()
    {
        java.lang.String manageableSetterName3a = this.__manageableSetterName3a;
        if (!this.__manageableSetterName3aSet)
        {
            handleGetManageableSetterName3aPreCondition();
            manageableSetterName3a = handleGetManageableSetterName();
            handleGetManageableSetterName3aPostCondition();
            this.__manageableSetterName3a = manageableSetterName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableSetterName3aSet = true;
            }
        }
        return manageableSetterName3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#isDisplay()
    */
    protected abstract boolean handleIsDisplay();

    private void handleIsDisplay4aPreCondition()
    {
    }

    private void handleIsDisplay4aPostCondition()
    {
    }

    private boolean __display4a;
    private boolean __display4aSet = false;

    public final boolean isDisplay()
    {
        boolean display4a = this.__display4a;
        if (!this.__display4aSet)
        {
            handleIsDisplay4aPreCondition();
            display4a = handleIsDisplay();
            handleIsDisplay4aPostCondition();
            this.__display4a = display4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__display4aSet = true;
            }
        }
        return display4a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}