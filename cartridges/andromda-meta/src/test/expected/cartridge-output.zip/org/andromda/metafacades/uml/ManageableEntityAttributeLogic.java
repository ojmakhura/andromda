//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAttribute
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public abstract class ManageableEntityAttributeLogic
    extends org.andromda.metafacades.uml.EntityAttributeLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAttribute
{

    protected Object metaObject;

    public ManageableEntityAttributeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAttribute";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#isDisplay()
    */
    protected abstract boolean handleIsDisplay();

    private void handleIsDisplay1aPreCondition()
    {
    }

    private void handleIsDisplay1aPostCondition()
    {
    }

    private boolean __display1a;
    private boolean __display1aSet = false;

    public final boolean isDisplay()
    {
        boolean display1a = this.__display1a;
        if (!this.__display1aSet)
        {
            handleIsDisplay1aPreCondition();
            display1a = handleIsDisplay();
            handleIsDisplay1aPostCondition();
            this.__display1a = display1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__display1aSet = true;
            }
        }
        return display1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#isManageableGetterAvailable()
    */
    protected abstract boolean handleIsManageableGetterAvailable();

    private void handleIsManageableGetterAvailable2aPreCondition()
    {
    }

    private void handleIsManageableGetterAvailable2aPostCondition()
    {
    }

    private boolean __manageableGetterAvailable2a;
    private boolean __manageableGetterAvailable2aSet = false;

    public final boolean isManageableGetterAvailable()
    {
        boolean manageableGetterAvailable2a = this.__manageableGetterAvailable2a;
        if (!this.__manageableGetterAvailable2aSet)
        {
            handleIsManageableGetterAvailable2aPreCondition();
            manageableGetterAvailable2a = handleIsManageableGetterAvailable();
            handleIsManageableGetterAvailable2aPostCondition();
            this.__manageableGetterAvailable2a = manageableGetterAvailable2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableGetterAvailable2aSet = true;
            }
        }
        return manageableGetterAvailable2a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}