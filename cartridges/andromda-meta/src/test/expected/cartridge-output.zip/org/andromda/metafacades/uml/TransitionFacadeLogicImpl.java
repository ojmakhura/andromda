package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.TransitionFacade.
 *
 * @see org.andromda.metafacades.uml.TransitionFacade
 */
public class TransitionFacadeLogicImpl
       extends TransitionFacadeLogic
       implements org.andromda.metafacades.uml.TransitionFacade
{
    // ---------------- constructor -------------------------------

    public TransitionFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.Transition metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isTriggerPresent()
     */
    public boolean handleIsTriggerPresent() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isExitingDecisionPoint()
     */
    public boolean handleIsExitingDecisionPoint() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringDecisionPoint()
     */
    public boolean handleIsEnteringDecisionPoint() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isExitingActionState()
     */
    public boolean handleIsExitingActionState() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringActionState()
     */
    public boolean handleIsEnteringActionState() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isExitingInitialState()
     */
    public boolean handleIsExitingInitialState() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringFinalState()
     */
    public boolean handleIsEnteringFinalState() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#getEffect()
     */
    public java.lang.Object handleGetEffect()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#getTrigger()
     */
    public java.lang.Object handleGetTrigger()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#getTarget()
     */
    public java.lang.Object handleGetTarget()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#getSource()
     */
    public java.lang.Object handleGetSource()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.TransitionFacade#getGuard()
     */
    public java.lang.Object handleGetGuard()
    {
        // TODO: add your implementation here!
        return null;
    }

}
