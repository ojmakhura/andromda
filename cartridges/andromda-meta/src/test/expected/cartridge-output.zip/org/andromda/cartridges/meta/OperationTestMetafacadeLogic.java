//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * MetafacadeLogic for org.andromda.cartridges.meta.OperationTestMetafacade
 *
 * @see org.andromda.cartridges.meta.OperationTestMetafacade
 */
public abstract class OperationTestMetafacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.cartridges.meta.OperationTestMetafacade
{

    protected Object metaObject;

    public OperationTestMetafacadeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.superOperationFacade =
           (org.andromda.metafacades.uml.OperationFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.OperationFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.OperationTestMetafacade";
        }
        return context;
    }

    private org.andromda.metafacades.uml.OperationFacade superOperationFacade;
    private boolean superOperationFacadeInitialized = false;

    /**
     * Gets the org.andromda.metafacades.uml.OperationFacade parent instance.
     */
    private org.andromda.metafacades.uml.OperationFacade getSuperSuperOperationFacade()
    {
        if (!this.superOperationFacadeInitialized)
        {
            ((org.andromda.core.metafacade.MetafacadeBase)superOperationFacade).setMetafacadeContext(this.getMetafacadeContext());
            this.superOperationFacadeInitialized = true;
        }
        return superOperationFacade;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
    */
    protected abstract boolean handleIsTestAttribute();

    private void handleIsTestAttribute1aPreCondition()
    {
    }

    private void handleIsTestAttribute1aPostCondition()
    {
    }

    private boolean __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    public final boolean isTestAttribute()
    {
        boolean testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            handleIsTestAttribute1aPreCondition();
            testAttribute1a = handleIsTestAttribute();
            handleIsTestAttribute1aPostCondition();
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ------------- associations ------------------

    private void handleGetTestClassifier1rPreCondition()
    {
    }

    private void handleGetTestClassifier1rPostCondition()
    {
    }

    public final org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier()
    {
        org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier1r = null;
        handleGetTestClassifier1rPreCondition();
        Object result = this.shieldedElement(handleGetTestClassifier());
        try
        {
            getTestClassifier1r = (org.andromda.cartridges.meta.ClassifierTestMetafacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTestClassifier1rPostCondition();
        return getTestClassifier1r;
    }

    protected abstract java.lang.Object handleGetTestClassifier();

    // ----------- delegates to org.andromda.metafacades.uml.OperationFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        return this.getSuperSuperOperationFacade().findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        return this.getSuperSuperOperationFacade().findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        return this.getSuperSuperOperationFacade().getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        return this.getSuperSuperOperationFacade().getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        return this.getSuperSuperOperationFacade().getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        return this.getSuperSuperOperationFacade().getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        return this.getSuperSuperOperationFacade().getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        return this.getSuperSuperOperationFacade().getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        return this.getSuperSuperOperationFacade().getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        return this.getSuperSuperOperationFacade().getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        return this.getSuperSuperOperationFacade().getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        return this.getSuperSuperOperationFacade().getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        return this.getSuperSuperOperationFacade().getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        return this.getSuperSuperOperationFacade().getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        return this.getSuperSuperOperationFacade().getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        return this.getSuperSuperOperationFacade().getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        return this.getSuperSuperOperationFacade().getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName(boolean modelName)
    {
        return this.getSuperSuperOperationFacade().getPackageName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        return this.getSuperSuperOperationFacade().getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        return this.getSuperSuperOperationFacade().getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        return this.getSuperSuperOperationFacade().getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        return this.getSuperSuperOperationFacade().getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        return this.getSuperSuperOperationFacade().getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        return this.getSuperSuperOperationFacade().getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        return this.getSuperSuperOperationFacade().getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        return this.getSuperSuperOperationFacade().getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        return this.getSuperSuperOperationFacade().getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperSuperOperationFacade().hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperSuperOperationFacade().hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean isConstraintsPresent()
    {
        return this.getSuperSuperOperationFacade().isConstraintsPresent();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        return this.getSuperSuperOperationFacade().translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        return this.getSuperSuperOperationFacade().translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        return this.getSuperSuperOperationFacade().translateConstraints(kind, translation);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        return this.getSuperSuperOperationFacade().findTaggedValue(name, follow);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentNames()
    {
        return this.getSuperSuperOperationFacade().getArgumentNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentTypeNames()
    {
        return this.getSuperSuperOperationFacade().getArgumentTypeNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getArguments()
    {
        return this.getSuperSuperOperationFacade().getArguments();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getCall()
    {
        return this.getSuperSuperOperationFacade().getCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getConcurrency()
    {
        return this.getSuperSuperOperationFacade().getConcurrency();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList(java.lang.String initialExceptions)
    {
        return this.getSuperSuperOperationFacade().getExceptionList(initialExceptions);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList()
    {
        return this.getSuperSuperOperationFacade().getExceptionList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getExceptions()
    {
        return this.getSuperSuperOperationFacade().getExceptions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        return this.getSuperSuperOperationFacade().getOwner();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getParameters()
    {
        return this.getSuperSuperOperationFacade().getParameters();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPostconditionName()
    {
        return this.getSuperSuperOperationFacade().getPostconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPostconditions()
    {
        return this.getSuperSuperOperationFacade().getPostconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionCall()
    {
        return this.getSuperSuperOperationFacade().getPreconditionCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionName()
    {
        return this.getSuperSuperOperationFacade().getPreconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionSignature()
    {
        return this.getSuperSuperOperationFacade().getPreconditionSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPreconditions()
    {
        return this.getSuperSuperOperationFacade().getPreconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getReturnType()
    {
        return this.getSuperSuperOperationFacade().getReturnType();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(boolean withArgumentNames)
    {
        return this.getSuperSuperOperationFacade().getSignature(withArgumentNames);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature()
    {
        return this.getSuperSuperOperationFacade().getSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(java.lang.String argumentModifier)
    {
        return this.getSuperSuperOperationFacade().getSignature(argumentModifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList(java.lang.String modifier)
    {
        return this.getSuperSuperOperationFacade().getTypedArgumentList(modifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList()
    {
        return this.getSuperSuperOperationFacade().getTypedArgumentList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isAbstract()
    {
        return this.getSuperSuperOperationFacade().isAbstract();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isExceptionsPresent()
    {
        return this.getSuperSuperOperationFacade().isExceptionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPostconditionsPresent()
    {
        return this.getSuperSuperOperationFacade().isPostconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPreconditionsPresent()
    {
        return this.getSuperSuperOperationFacade().isPreconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isQuery()
    {
        return this.getSuperSuperOperationFacade().isQuery();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isReturnTypePresent()
    {
        return this.getSuperSuperOperationFacade().isReturnTypePresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isStatic()
    {
        return this.getSuperSuperOperationFacade().isStatic();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        this.getSuperSuperOperationFacade().initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        Object owner = this.getSuperSuperOperationFacade().getValidationOwner();
        return owner;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        String name = this.getSuperSuperOperationFacade().getValidationName();
        return name;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        this.getSuperSuperOperationFacade().validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.nonEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"testAttribute")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Test attribute is required."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}