//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * MetafacadeLogic for org.andromda.cartridges.meta.OperationTestMetafacade
 *
 * @see org.andromda.cartridges.meta.OperationTestMetafacade
 */
public abstract class OperationTestMetafacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.cartridges.meta.OperationTestMetafacade
{

    protected Object metaObject;

    public OperationTestMetafacadeLogic(Object metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.super_1 =
           (org.andromda.metafacades.uml.OperationFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.OperationFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.OperationTestMetafacade";
        }
        return context;
    }
    
    private org.andromda.metafacades.uml.OperationFacade super_1;
    
    /**
     * Gets the org.andromda.metafacades.uml.OperationFacade parent instance.
     */ 
    private org.andromda.metafacades.uml.OperationFacade getSuperOperationFacade()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_1).setMetafacadeContext(this.getMetafacadeContext());
        return super_1;
    }
    
    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
    */
    protected abstract boolean handleIsTestAttribute();

    private void handleIsTestAttribute1aPreCondition()
    {
    }

    private void handleIsTestAttribute1aPostCondition()
    {
    }

    private boolean __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    public final boolean isTestAttribute()
    {
        boolean testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            handleIsTestAttribute1aPreCondition();
            testAttribute1a = handleIsTestAttribute();
            handleIsTestAttribute1aPostCondition();
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ------------- associations ------------------

    private void handleGetTestClassifier1rPreCondition()
    {
    }

    private void handleGetTestClassifier1rPostCondition()
    {
    }

    public final org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier()
    {
        org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier1r = null;
        handleGetTestClassifier1rPreCondition();
        Object result = this.shieldedElement(handleGetTestClassifier());
        try
        {
            getTestClassifier1r = (org.andromda.cartridges.meta.ClassifierTestMetafacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTestClassifier1rPostCondition();
        return getTestClassifier1r;
    }

    protected abstract java.lang.Object handleGetTestClassifier();

    // ----------- delegates to $generalization.fullyQualifiedName ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        return this.getSuperOperationFacade().findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        return this.getSuperOperationFacade().findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        return this.getSuperOperationFacade().getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        return this.getSuperOperationFacade().getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        return this.getSuperOperationFacade().getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        return this.getSuperOperationFacade().getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        return this.getSuperOperationFacade().getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        return this.getSuperOperationFacade().getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        return this.getSuperOperationFacade().getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        return this.getSuperOperationFacade().getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        return this.getSuperOperationFacade().getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        return this.getSuperOperationFacade().getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        return this.getSuperOperationFacade().getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        return this.getSuperOperationFacade().getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        return this.getSuperOperationFacade().getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        return this.getSuperOperationFacade().getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        return this.getSuperOperationFacade().getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName(boolean modelName)
    {
        return this.getSuperOperationFacade().getPackageName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        return this.getSuperOperationFacade().getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        return this.getSuperOperationFacade().getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        return this.getSuperOperationFacade().getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        return this.getSuperOperationFacade().getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        return this.getSuperOperationFacade().getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        return this.getSuperOperationFacade().getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        return this.getSuperOperationFacade().getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        return this.getSuperOperationFacade().getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        return this.getSuperOperationFacade().getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperOperationFacade().hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        return this.getSuperOperationFacade().hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean isConstraintsPresent()
    {
        return this.getSuperOperationFacade().isConstraintsPresent();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        return this.getSuperOperationFacade().translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        return this.getSuperOperationFacade().translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        return this.getSuperOperationFacade().translateConstraints(kind, translation);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        return this.getSuperOperationFacade().findTaggedValue(name, follow);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentNames()
    {
        return this.getSuperOperationFacade().getArgumentNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentTypeNames()
    {
        return this.getSuperOperationFacade().getArgumentTypeNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getArguments()
    {
        return this.getSuperOperationFacade().getArguments();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getCall()
    {
        return this.getSuperOperationFacade().getCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getConcurrency()
    {
        return this.getSuperOperationFacade().getConcurrency();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList(java.lang.String initialExceptions)
    {
        return this.getSuperOperationFacade().getExceptionList(initialExceptions);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList()
    {
        return this.getSuperOperationFacade().getExceptionList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getExceptions()
    {
        return this.getSuperOperationFacade().getExceptions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        return this.getSuperOperationFacade().getOwner();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getParameters()
    {
        return this.getSuperOperationFacade().getParameters();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPostconditionName()
    {
        return this.getSuperOperationFacade().getPostconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPostconditions()
    {
        return this.getSuperOperationFacade().getPostconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionCall()
    {
        return this.getSuperOperationFacade().getPreconditionCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionName()
    {
        return this.getSuperOperationFacade().getPreconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionSignature()
    {
        return this.getSuperOperationFacade().getPreconditionSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPreconditions()
    {
        return this.getSuperOperationFacade().getPreconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getReturnType()
    {
        return this.getSuperOperationFacade().getReturnType();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(boolean withArgumentNames)
    {
        return this.getSuperOperationFacade().getSignature(withArgumentNames);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature()
    {
        return this.getSuperOperationFacade().getSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(java.lang.String argumentModifier)
    {
        return this.getSuperOperationFacade().getSignature(argumentModifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList(java.lang.String modifier)
    {
        return this.getSuperOperationFacade().getTypedArgumentList(modifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList()
    {
        return this.getSuperOperationFacade().getTypedArgumentList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isAbstract()
    {
        return this.getSuperOperationFacade().isAbstract();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isExceptionsPresent()
    {
        return this.getSuperOperationFacade().isExceptionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPostconditionsPresent()
    {
        return this.getSuperOperationFacade().isPostconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPreconditionsPresent()
    {
        return this.getSuperOperationFacade().isPreconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isQuery()
    {
        return this.getSuperOperationFacade().isQuery();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isReturnTypePresent()
    {
        return this.getSuperOperationFacade().isReturnTypePresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isStatic()
    {
        return this.getSuperOperationFacade().isStatic();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        this.getSuperOperationFacade().initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        Object owner = this.getSuperOperationFacade().getValidationOwner();
        return owner;
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        String name = this.getSuperOperationFacade().getValidationName();
        return name;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        this.getSuperOperationFacade().validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.nonEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"testAttribute")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Test attribute is required."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}