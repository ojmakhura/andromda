// license-header java merge-point
//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

import java.util.Collection;
import org.andromda.core.common.Introspector;
import org.andromda.core.metafacade.MetafacadeBase;
import org.andromda.core.metafacade.MetafacadeFactory;
import org.andromda.core.metafacade.ModelValidationMessage;
import org.andromda.metafacades.uml.ClassifierFacade;
import org.andromda.metafacades.uml.ConstraintFacade;
import org.andromda.metafacades.uml.DependencyFacade;
import org.andromda.metafacades.uml.ModelElementFacade;
import org.andromda.metafacades.uml.ModelFacade;
import org.andromda.metafacades.uml.OperationFacade;
import org.andromda.metafacades.uml.PackageFacade;
import org.andromda.metafacades.uml.ParameterFacade;
import org.andromda.metafacades.uml.StateMachineFacade;
import org.andromda.metafacades.uml.StereotypeFacade;
import org.andromda.metafacades.uml.TaggedValueFacade;
import org.andromda.metafacades.uml.TemplateParameterFacade;
import org.andromda.metafacades.uml.TypeMappings;
import org.andromda.translation.ocl.validation.OCLCollections;
import org.andromda.translation.ocl.validation.OCLIntrospector;
import org.andromda.translation.ocl.validation.OCLResultEnsurer;
import org.apache.log4j.Logger;

/**
 * 
 * MetafacadeLogic for OperationTestMetafacade
 *
 * @see OperationTestMetafacade
 */
public abstract class OperationTestMetafacadeLogic
    extends MetafacadeBase
    implements OperationTestMetafacade
{
    /**
     * The underlying UML object
     * @see Object
     */
    protected Object metaObject;

    /** Create Metafacade implementation instance using the MetafacadeFactory from the context
     * @param metaObjectIn
     * @param context
     */
    protected OperationTestMetafacadeLogic(Object metaObjectIn, String context)
    {
        super(metaObjectIn, getContext(context));
        this.superOperationFacade =
           (OperationFacade)
            MetafacadeFactory.getInstance().createFacadeImpl(
                    "org.andromda.metafacades.uml.OperationFacade",
                    metaObjectIn,
                    getContext(context));
        this.metaObject = metaObjectIn;
    }

    /**
     * The logger instance.
     */
    private static final Logger logger = Logger.getLogger(OperationTestMetafacadeLogic.class);

    /**
     * Gets the context for this metafacade logic instance.
     * @param context String. Set to OperationTestMetafacade if null
     * @return context String
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.OperationTestMetafacade";
        }
        return context;
    }

    private OperationFacade superOperationFacade;
    private boolean superOperationFacadeInitialized = false;

    /**
     * Gets the OperationFacade parent instance.
     * @return this.superOperationFacade OperationFacade
     */
    private OperationFacade getSuperOperationFacade()
    {
        if (!this.superOperationFacadeInitialized)
        {
            ((MetafacadeBase)this.superOperationFacade).setMetafacadeContext(this.getMetafacadeContext());
            this.superOperationFacadeInitialized = true;
        }
        return this.superOperationFacade;
    }

    /** Reset context only for non-root metafacades
     * @param context
     * @see org.andromda.core.metafacade.MetafacadeBase#resetMetafacadeContext(String context)
     */
    @Override
    public void resetMetafacadeContext(String context)
    {
        if (!this.contextRoot) // reset context only for non-root metafacades
        {
            context = getContext(context);  // to have same value as in original constructor call
            setMetafacadeContext (context);
            if (this.superOperationFacadeInitialized)
            {
                ((MetafacadeBase)this.superOperationFacade).resetMetafacadeContext(context);
            }
        }
    }

    /**
     * @return boolean true always
     * @see OperationTestMetafacade
     */
    public boolean isOperationTestMetafacadeMetaType()
    {
        return true;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
    * @return boolean
    */
    protected abstract boolean handleIsTestAttribute();

    private boolean __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    /**
     * 
     * @return (boolean)handleIsTestAttribute()
     */
    public final boolean isTestAttribute()
    {
        boolean testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            // testAttribute has no pre constraints
            testAttribute1a = handleIsTestAttribute();
            // testAttribute has no post constraints
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ------------- associations ------------------


    /**
     * 
     * @return (ClassifierTestMetafacade)handleGetTestClassifier()
     */
    public final ClassifierTestMetafacade getTestClassifier()
    {
        ClassifierTestMetafacade getTestClassifier1r = null;
        // testOperations has no pre constraints
        Object result = this.shieldedElement(handleGetTestClassifier());
        try
        {
            getTestClassifier1r = (ClassifierTestMetafacade)result;
        }
        catch (ClassCastException ex)
        {
            // Bad things happen if the metafacade type mapping in metafacades.xml is wrong - Warn
            OperationTestMetafacadeLogic.logger.warn("incorrect metafacade cast for OperationTestMetafacadeLogic.getTestClassifier ClassifierTestMetafacade " + handleGetTestClassifier() + ": " + result);
        }
        // testOperations has no post constraints
        return getTestClassifier1r;
    }

    /**
     * UML Specific type is transformed by shieldedElements to AndroMDA Metafacade type
     * @return Object
     */
    protected abstract Object handleGetTestClassifier();

    /**
     * @return true
     * @see OperationFacade
     */
    public boolean isOperationFacadeMetaType()
    {
        return true;
    }

    /**
     * @return true
     * @see ModelElementFacade
     */
    public boolean isModelElementFacadeMetaType()
    {
        return true;
    }

    // ----------- delegates to OperationFacade ------------
    /**
     * <p>
    * Copies all tagged values from the given ModelElementFacade to
    * this model element facade.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#copyTaggedValues(ModelElementFacade element)
     */
    public void copyTaggedValues(ModelElementFacade element)
    {
        this.getSuperOperationFacade().copyTaggedValues(element);
    }

    /**
     * <p>
    * Finds the tagged value with the specified 'tagName'. In case
    * there are more values the first one found will be returned.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValue(String tagName)
     */
    public Object findTaggedValue(String tagName)
    {
        return this.getSuperOperationFacade().findTaggedValue(tagName);
    }

    /**
     * <p>
    * Returns all the values for the tagged value with the specified
    * name. The returned collection will contains only String
    * instances, or will be empty. Never null.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValues(String tagName)
     */
    public Collection findTaggedValues(String tagName)
    {
        return this.getSuperOperationFacade().findTaggedValues(tagName);
    }

    /**
     * <p>
    * Gets all constraints belonging to the model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints()
     */
    public Collection<ConstraintFacade> getConstraints()
    {
        return this.getSuperOperationFacade().getConstraints();
    }

    /**
     * <p>
    * Returns the constraints of the argument kind that have been
    * placed onto this model. Typical kinds are "inv", "pre" and
    * "post". Other kinds are possible.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints(String kind)
     */
    public Collection getConstraints(String kind)
    {
        return this.getSuperOperationFacade().getConstraints(kind);
    }

    /**
     * <p>
    * Gets the documentation for the model element, The indent
    * argument is prefixed to each line. By default this method wraps
    * lines after 64 characters.
    * </p>
    * <p>
    * This method is equivalent to <code>getDocumentation(indent,
    * 64)</code>.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(String indent)
     */
    public String getDocumentation(String indent)
    {
        return this.getSuperOperationFacade().getDocumentation(indent);
    }

    /**
     * <p>
    * This method returns the documentation for this model element,
    * with the lines wrapped after the specified number of characters,
    * values of less than 1 will indicate no line wrapping is
    * required. By default paragraphs are returned as HTML.
    * </p>
    * <p>
    * This method is equivalent to <code>getDocumentation(indent,
    * lineLength, true)</code>.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(String indent, int lineLength)
     */
    public String getDocumentation(String indent, int lineLength)
    {
        return this.getSuperOperationFacade().getDocumentation(indent, lineLength);
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(String indent, int lineLength, boolean htmlStyle)
     */
    public String getDocumentation(String indent, int lineLength, boolean htmlStyle)
    {
        return this.getSuperOperationFacade().getDocumentation(indent, lineLength, htmlStyle);
    }

    /**
     * <p>
    * The fully qualified name of this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName()
     */
    public String getFullyQualifiedName()
    {
        return this.getSuperOperationFacade().getFullyQualifiedName();
    }

    /**
     * <p>
    * Returns the fully qualified name of the model element. The fully
    * qualified name includes complete package qualified name of the
    * underlying model element.  If modelName is true, then the
    * original name of the model element (the name contained within
    * the model) will be the name returned, otherwise a name from a
    * language mapping will be returned.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName(boolean modelName)
     */
    public String getFullyQualifiedName(boolean modelName)
    {
        return this.getSuperOperationFacade().getFullyQualifiedName(modelName);
    }

    /**
     * <p>
    * Returns the fully qualified name as a path, the returned value
    * always starts with out a slash '/'.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedNamePath()
     */
    public String getFullyQualifiedNamePath()
    {
        return this.getSuperOperationFacade().getFullyQualifiedNamePath();
    }

    /**
     * <p>
    * Gets the unique identifier of the underlying model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getId()
     */
    public String getId()
    {
        return this.getSuperOperationFacade().getId();
    }

    /**
     * <p>
    * UML2: Retrieves the keywords for this element. Used to modify
    * implementation properties which are not represented by other
    * properties, i.e. native, transient, volatile, synchronized,
    * (added annotations) override, deprecated. Can also be used to
    * suppress compiler warnings: (added annotations) unchecked,
    * fallthrough, path, serial, finally, all. Annotations require
    * JDK5 compiler level.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getKeywords()
     */
    public Collection<String> getKeywords()
    {
        return this.getSuperOperationFacade().getKeywords();
    }

    /**
     * <p>
    * UML2: Retrieves a localized label for this named element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getLabel()
     */
    public String getLabel()
    {
        return this.getSuperOperationFacade().getLabel();
    }

    /**
     * <p>
    * The language mappings that have been set for this model elemnt.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getLanguageMappings()
     */
    public TypeMappings getLanguageMappings()
    {
        return this.getSuperOperationFacade().getLanguageMappings();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#getModel()
     */
    public ModelFacade getModel()
    {
        return this.getSuperOperationFacade().getModel();
    }

    /**
     * <p>
    * The name of the model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getName()
     */
    public String getName()
    {
        return this.getSuperOperationFacade().getName();
    }

    /**
     * <p>
    * Gets the package to which this model element belongs.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackage()
     */
    public ModelElementFacade getPackage()
    {
        return this.getSuperOperationFacade().getPackage();
    }

    /**
     * <p>
    * The name of this model element's package.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName()
     */
    public String getPackageName()
    {
        return this.getSuperOperationFacade().getPackageName();
    }

    /**
     * <p>
    * Gets the package name (optionally providing the ability to
    * retrieve the model name and not the mapped name).
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName(boolean modelName)
     */
    public String getPackageName(boolean modelName)
    {
        return this.getSuperOperationFacade().getPackageName(modelName);
    }

    /**
     * <p>
    * Returns the package as a path, the returned value always starts
    * with out a slash '/'.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackagePath()
     */
    public String getPackagePath()
    {
        return this.getSuperOperationFacade().getPackagePath();
    }

    /**
     * <p>
    * UML2: Returns the value of the 'Qualified Name' attribute. A
    * name which allows the NamedElement to be identified within a
    * hierarchy of nested Namespaces. It is constructed from the names
    * of the containing namespaces starting at the root of the
    * hierarchy and ending with the name of the NamedElement itself.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getQualifiedName()
     */
    public String getQualifiedName()
    {
        return this.getSuperOperationFacade().getQualifiedName();
    }

    /**
     * <p>
    * Gets the root package for the model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getRootPackage()
     */
    public PackageFacade getRootPackage()
    {
        return this.getSuperOperationFacade().getRootPackage();
    }

    /**
     * <p>
    * Gets the dependencies for which this model element is the
    * source.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getSourceDependencies()
     */
    public Collection<DependencyFacade> getSourceDependencies()
    {
        return this.getSuperOperationFacade().getSourceDependencies();
    }

    /**
     * <p>
    * If this model element is the context of an activity graph, this
    * represents that activity graph.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStateMachineContext()
     */
    public StateMachineFacade getStateMachineContext()
    {
        return this.getSuperOperationFacade().getStateMachineContext();
    }

    /**
     * <p>
    * The collection of ALL stereotype names for this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypeNames()
     */
    public Collection<String> getStereotypeNames()
    {
        return this.getSuperOperationFacade().getStereotypeNames();
    }

    /**
     * <p>
    * Gets all stereotypes for this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypes()
     */
    public Collection<StereotypeFacade> getStereotypes()
    {
        return this.getSuperOperationFacade().getStereotypes();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTaggedValues()
     */
    public Collection<TaggedValueFacade> getTaggedValues()
    {
        return this.getSuperOperationFacade().getTaggedValues();
    }

    /**
     * <p>
    * Gets the dependencies for which this model element is the
    * target.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTargetDependencies()
     */
    public Collection<DependencyFacade> getTargetDependencies()
    {
        return this.getSuperOperationFacade().getTargetDependencies();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTemplateParameter(String parameterName)
     */
    public Object getTemplateParameter(String parameterName)
    {
        return this.getSuperOperationFacade().getTemplateParameter(parameterName);
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTemplateParameters()
     */
    public Collection<TemplateParameterFacade> getTemplateParameters()
    {
        return this.getSuperOperationFacade().getTemplateParameters();
    }

    /**
     * <p>
    * The visibility (i.e. public, private, protected or package) of
    * the model element, will attempt a lookup for these values in the
    * language mappings (if any).
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#getVisibility()
     */
    public String getVisibility()
    {
        return this.getSuperOperationFacade().getVisibility();
    }

    /**
     * <p>
    * Returns true if the model element has the exact stereotype
    * (meaning no stereotype inheritance is taken into account when
    * searching for the stereotype), false otherwise.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasExactStereotype(String stereotypeName)
     */
    public boolean hasExactStereotype(String stereotypeName)
    {
        return this.getSuperOperationFacade().hasExactStereotype(stereotypeName);
    }

    /**
     * <p>
    * Does the UML Element contain the named Keyword? Keywords can be
    * separated by space, comma, pipe, semicolon, or << >>
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasKeyword(String keywordName)
     */
    public boolean hasKeyword(String keywordName)
    {
        return this.getSuperOperationFacade().hasKeyword(keywordName);
    }

    /**
     * <p>
    * Returns true if the model element has the specified stereotype. 
    * If the stereotype itself does not match, then a search will be
    * made up the stereotype inheritance hierarchy, and if one of the
    * stereotype's ancestors has a matching name this method will
    * return true, false otherwise.
    * </p>
    * <p>
    * For example, if we have a certain stereotype called
    * <<exception>> and a model element has a stereotype called
    * <<applicationException>> which extends <<exception>>, when
    * calling this method with 'stereotypeName' defined as 'exception'
    * the method would return true since <<applicationException>>
    * inherits from <<exception>>.  If you want to check if the model
    * element has the exact stereotype, then use the method
    * 'hasExactStereotype' instead.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasStereotype(String stereotypeName)
     */
    public boolean hasStereotype(String stereotypeName)
    {
        return this.getSuperOperationFacade().hasStereotype(stereotypeName);
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#isBindingDependenciesPresent()
     */
    public boolean isBindingDependenciesPresent()
    {
        return this.getSuperOperationFacade().isBindingDependenciesPresent();
    }

    /**
     * <p>
    * Indicates if any constraints are present on this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#isConstraintsPresent()
     */
    public boolean isConstraintsPresent()
    {
        return this.getSuperOperationFacade().isConstraintsPresent();
    }

    /**
     * <p>
    * Indicates if any documentation is present on this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#isDocumentationPresent()
     */
    public boolean isDocumentationPresent()
    {
        return this.getSuperOperationFacade().isDocumentationPresent();
    }

    /**
     * <p>
    * True if this element name is a reserved word in Java, C#, ANSI
    * or ISO C, C++, JavaScript.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#isReservedWord()
     */
    public boolean isReservedWord()
    {
        return this.getSuperOperationFacade().isReservedWord();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.ModelElementFacade#isTemplateParametersPresent()
     */
    public boolean isTemplateParametersPresent()
    {
        return this.getSuperOperationFacade().isTemplateParametersPresent();
    }

    /**
     * <p>
    * Searches for the constraint with the specified 'name' on this
    * model element, and if found translates it using the specified
    * 'translation' from a translation library discovered by the
    * framework.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraint(String name, String translation)
     */
    public String translateConstraint(String name, String translation)
    {
        return this.getSuperOperationFacade().translateConstraint(name, translation);
    }

    /**
     * <p>
    * Translates all constraints belonging to this model element with
    * the given 'translation'.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(String translation)
     */
    public String[] translateConstraints(String translation)
    {
        return this.getSuperOperationFacade().translateConstraints(translation);
    }

    /**
     * <p>
    * Translates the constraints of the specified 'kind' belonging to
    * this model element.
    * </p>
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(String kind, String translation)
     */
    public String[] translateConstraints(String kind, String translation)
    {
        return this.getSuperOperationFacade().translateConstraints(kind, translation);
    }

    /**
     * <p>
    * Finds the parameter on this operation having the given name, if
    * no parameter is found, null is returned instead.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#findParameter(String name)
     */
    public ParameterFacade findParameter(String name)
    {
        return this.getSuperOperationFacade().findParameter(name);
    }

    /**
     * <p>
    * Searches the given feature for the specified tag.
    * </p>
    * <p>
    * If the follow boolean is set to true then the search will
    * continue from the class operation to the class itself and then
    * up the class hierarchy.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#findTaggedValue(String name, boolean follow)
     */
    public Object findTaggedValue(String name, boolean follow)
    {
        return this.getSuperOperationFacade().findTaggedValue(name, follow);
    }

    /**
     * <p>
    * A comma separated list of all argument names.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getArgumentNames()
     */
    public String getArgumentNames()
    {
        return this.getSuperOperationFacade().getArgumentNames();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getArgumentTypeNames()
     */
    public String getArgumentTypeNames()
    {
        return this.getSuperOperationFacade().getArgumentTypeNames();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getArguments()
     */
    public Collection<ParameterFacade> getArguments()
    {
        return this.getSuperOperationFacade().getArguments();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getCall()
     */
    public String getCall()
    {
        return this.getSuperOperationFacade().getCall();
    }

    /**
     * <p>
    * Returns the concurrency modifier for this operation (i.e.
    * concurrent, guarded or sequential) of the model element, will
    * attempt a lookup for these values in the language mappings (if
    * any).
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getConcurrency()
     */
    public String getConcurrency()
    {
        return this.getSuperOperationFacade().getConcurrency();
    }

    /**
     * <p>
    * A comma separated list containing all exceptions that this
    * operation throws.  Exceptions are determined through
    * dependencies that have the target element stereotyped as
    * <<Exception>>.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptionList()
     */
    public String getExceptionList()
    {
        return this.getSuperOperationFacade().getExceptionList();
    }

    /**
     * <p>
    * Returns a comma separated list of exceptions appended to the
    * comma separated list of fully qualified 'initialException'
    * classes passed in to this method.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptionList(String initialExceptions)
     */
    public String getExceptionList(String initialExceptions)
    {
        return this.getSuperOperationFacade().getExceptionList(initialExceptions);
    }

    /**
     * <p>
    * A collection of all exceptions thrown by this operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptions()
     */
    public Collection getExceptions()
    {
        return this.getSuperOperationFacade().getExceptions();
    }

    /**
     * <p>
    * Return Type with multiplicity taken into account. UML14 does not
    * allow multiplicity *.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getGetterSetterReturnTypeName()
     */
    public String getGetterSetterReturnTypeName()
    {
        return this.getSuperOperationFacade().getGetterSetterReturnTypeName();
    }

    /**
     * <p>
    * the lower value for the multiplicity
    * </p>
    * <p>
    * -only applicable for UML2
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getLower()
     */
    public int getLower()
    {
        return this.getSuperOperationFacade().getLower();
    }

    /**
     * <p>
    * Returns the operation method body determined from UML sequence
    * diagrams or other UML sources.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getMethodBody()
     */
    public String getMethodBody()
    {
        return this.getSuperOperationFacade().getMethodBody();
    }

    /**
     * <p>
    * The operation this operation overrides, null if this operation
    * is not overriding.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getOverriddenOperation()
     */
    public OperationFacade getOverriddenOperation()
    {
        return this.getSuperOperationFacade().getOverriddenOperation();
    }

    /**
     * <p>
    * Gets the owner of this operation
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getOwner()
     */
    public ClassifierFacade getOwner()
    {
        return this.getSuperOperationFacade().getOwner();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getParameters()
     */
    public Collection<ParameterFacade> getParameters()
    {
        return this.getSuperOperationFacade().getParameters();
    }

    /**
     * <p>
    * The name of the operation that handles postcondition
    * constraints.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPostconditionName()
     */
    public String getPostconditionName()
    {
        return this.getSuperOperationFacade().getPostconditionName();
    }

    /**
     * <p>
    * The postcondition constraints belonging to this operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPostconditions()
     */
    public Collection<ConstraintFacade> getPostconditions()
    {
        return this.getSuperOperationFacade().getPostconditions();
    }

    /**
     * <p>
    * The call to the precondition operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPreconditionCall()
     */
    public String getPreconditionCall()
    {
        return this.getSuperOperationFacade().getPreconditionCall();
    }

    /**
     * <p>
    * The name of the operation that handles precondition constraints.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPreconditionName()
     */
    public String getPreconditionName()
    {
        return this.getSuperOperationFacade().getPreconditionName();
    }

    /**
     * <p>
    * The signature of the precondition operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPreconditionSignature()
     */
    public String getPreconditionSignature()
    {
        return this.getSuperOperationFacade().getPreconditionSignature();
    }

    /**
     * <p>
    * The precondition constraints belonging to this operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getPreconditions()
     */
    public Collection<ConstraintFacade> getPreconditions()
    {
        return this.getSuperOperationFacade().getPreconditions();
    }

    /**
     * <p>
    * (UML2 Only). Get the actual return parameter (which may have
    * stereotypes etc).
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getReturnParameter()
     */
    public ParameterFacade getReturnParameter()
    {
        return this.getSuperOperationFacade().getReturnParameter();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getReturnType()
     */
    public ClassifierFacade getReturnType()
    {
        return this.getSuperOperationFacade().getReturnType();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#getSignature()
     */
    public String getSignature()
    {
        return this.getSuperOperationFacade().getSignature();
    }

    /**
     * <p>
    * Returns the signature of the operation and optionally appends
    * the argument names (if withArgumentNames is true), otherwise
    * returns the signature with just the types alone in the
    * signature.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getSignature(boolean withArgumentNames)
     */
    public String getSignature(boolean withArgumentNames)
    {
        return this.getSuperOperationFacade().getSignature(withArgumentNames);
    }

    /**
     * <p>
    * Returns the signature of the operation and optionally appends
    * the given 'argumentModifier' to each argument.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getSignature(String argumentModifier)
     */
    public String getSignature(String argumentModifier)
    {
        return this.getSuperOperationFacade().getSignature(argumentModifier);
    }

    /**
     * <p>
    * A comma-separated parameter list  (type and name of each
    * parameter) of an operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getTypedArgumentList()
     */
    public String getTypedArgumentList()
    {
        return this.getSuperOperationFacade().getTypedArgumentList();
    }

    /**
     * <p>
    * A comma-separated parameter list  (type and name of each
    * parameter) of an operation with an optional modifier (i.e final)
    * before each parameter.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getTypedArgumentList(String modifier)
     */
    public String getTypedArgumentList(String modifier)
    {
        return this.getSuperOperationFacade().getTypedArgumentList(modifier);
    }

    /**
     * <p>
    * the upper value for the multiplicity (will be -1 for *)
    * </p>
    * <p>
    * - only applicable for UML2
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#getUpper()
     */
    public int getUpper()
    {
        return this.getSuperOperationFacade().getUpper();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#isAbstract()
     */
    public boolean isAbstract()
    {
        return this.getSuperOperationFacade().isAbstract();
    }

    /**
     * <p>
    * True if the operation has (i.e. throws any exceptions) false
    * otherwise.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isExceptionsPresent()
     */
    public boolean isExceptionsPresent()
    {
        return this.getSuperOperationFacade().isExceptionsPresent();
    }

    /**
     * <p>
    * IsLeaf property in the operation. If true, operation is final,
    * cannot be extended or implemented by a descendant.
    * Default=false.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isLeaf()
     */
    public boolean isLeaf()
    {
        return this.getSuperOperationFacade().isLeaf();
    }

    /**
     * <p>
    * UML2 only. If the return type parameter multiplicity>1 OR the
    * operation multiplicity>1. Default=false.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isMany()
     */
    public boolean isMany()
    {
        return this.getSuperOperationFacade().isMany();
    }

    /**
     * <p>
    * UML2 only: If isMany (Collection type returned), is the type
    * unique within the collection.  Unique+Ordered determines
    * CollectionType implementation of return result. Default=false.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isOrdered()
     */
    public boolean isOrdered()
    {
        return this.getSuperOperationFacade().isOrdered();
    }

    /**
     * <p>
    * True if this operation overrides an operation defined in an
    * ancestor class. An operation overrides when the names of the
    * operations as well as the types of the arguments are equal. The
    * return type may be different and is, as well as any exceptions,
    * ignored.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isOverriding()
     */
    public boolean isOverriding()
    {
        return this.getSuperOperationFacade().isOverriding();
    }

    /**
     * <p>
    * Whether any postcondition constraints are present on this
    * operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isPostconditionsPresent()
     */
    public boolean isPostconditionsPresent()
    {
        return this.getSuperOperationFacade().isPostconditionsPresent();
    }

    /**
     * <p>
    * Whether any precondition constraints are present on this
    * operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isPreconditionsPresent()
     */
    public boolean isPreconditionsPresent()
    {
        return this.getSuperOperationFacade().isPreconditionsPresent();
    }

    /**
     * <p>
    * Indicates whether or not this operation is a query operation.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isQuery()
     */
    public boolean isQuery()
    {
        return this.getSuperOperationFacade().isQuery();
    }

    /**
     * <p>
    * True/false depending on whether or not the operation has a
    * return type or not (i.e. a return type of something other than
    * void).
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isReturnTypePresent()
     */
    public boolean isReturnTypePresent()
    {
        return this.getSuperOperationFacade().isReturnTypePresent();
    }

    /**
     * 
     * @see org.andromda.metafacades.uml.OperationFacade#isStatic()
     */
    public boolean isStatic()
    {
        return this.getSuperOperationFacade().isStatic();
    }

    /**
     * <p>
    * UML2 only: for Collection return type, is the type unique within
    * the collection. Unique+Ordered determines the returned
    * CollectionType. Default=false.
    * </p>
     * @see org.andromda.metafacades.uml.OperationFacade#isUnique()
     */
    public boolean isUnique()
    {
        return this.getSuperOperationFacade().isUnique();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    @Override
    public void initialize()
    {
        this.getSuperOperationFacade().initialize();
    }

    /**
     * @return Object getSuperOperationFacade().getValidationOwner()
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    @Override
    public Object getValidationOwner()
    {
        Object owner = this.getSuperOperationFacade().getValidationOwner();
        return owner;
    }

    /**
     * @return String getSuperOperationFacade().getValidationName()
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    @Override
    public String getValidationName()
    {
        String name = this.getSuperOperationFacade().getValidationName();
        return name;
    }

    /**
     * @param validationMessages Collection
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(Collection validationMessages)
     */
    @Override
    public void validateInvariants(Collection<ModelValidationMessage> validationMessages)
    {
        this.getSuperOperationFacade().validateInvariants(validationMessages);
        try
        {
            final Object contextElement = this; boolean constraintValid = OCLResultEnsurer.ensure(OCLCollections.nonEmpty(OCLIntrospector.invoke(contextElement,"testAttribute")));
            if (!constraintValid)
                validationMessages.add(
                    new ModelValidationMessage(
                        (MetafacadeBase)contextElement ,
                        "org::andromda::cartridges::meta::OperationTestMetafacade::metafacade test constraint",
                        "Test attribute is required."));
        }
        catch (Throwable th)
        {
            Throwable cause = th.getCause();
            int depth = 0; // Some throwables have infinite recursion
            while (cause != null && depth < 7)
            {
                th = cause;
                depth++;
            }
            logger.error("Error validating constraint 'org::andromda::cartridges::meta::OperationTestMetafacade::metafacade test constraint' ON "
                + this.THIS().toString() + ": " + th.getMessage(), th);
        }
    }

    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";

    /**
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        final StringBuilder toString = new StringBuilder(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable ignore)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}