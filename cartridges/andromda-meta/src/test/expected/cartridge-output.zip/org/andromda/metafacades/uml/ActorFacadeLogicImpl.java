package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActorFacade.
 *
 * @see org.andromda.metafacades.uml.ActorFacade
 */
public class ActorFacadeLogicImpl
       extends ActorFacadeLogic
       implements org.andromda.metafacades.uml.ActorFacade
{
    // ---------------- constructor -------------------------------

    public ActorFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.Actor metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActorFacade#getGeneralizedByActors()
     */
    public java.util.Collection handleGetGeneralizedByActors()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActorFacade#getGeneralizedActors()
     */
    public java.util.Collection handleGetGeneralizedActors()
    {
        // TODO: add your implementation here!
        return null;
    }

}
