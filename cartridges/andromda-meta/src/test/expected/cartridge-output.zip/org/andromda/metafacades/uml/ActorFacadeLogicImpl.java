package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActorFacade.
 *
 * @see org.andromda.metafacades.uml.ActorFacade
 */
public class ActorFacadeLogicImpl
    extends ActorFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ActorFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.Actor metaObject, String context)
    {
        super (metaObject, context);
    }
}