//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface NamespaceFacade
       extends org.andromda.metafacades.uml.ClassifierFacade
{

   /**
    * <p>
    *  Gets the model element which this namespace owns.
    * </p>
    */
    public java.util.Collection getOwnedElements();

}
