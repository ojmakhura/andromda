package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.CallEventFacade.
 *
 * @see org.andromda.metafacades.uml.CallEventFacade
 */
public class CallEventFacadeLogicImpl
       extends CallEventFacadeLogic
       implements org.andromda.metafacades.uml.CallEventFacade
{
    // ---------------- constructor -------------------------------

    public CallEventFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.CallEvent metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.CallEventFacade#getOperation()
     */
    protected java.lang.Object handleGetOperation()
    {
        // TODO: add your implementation here!
        return null;
    }

}
