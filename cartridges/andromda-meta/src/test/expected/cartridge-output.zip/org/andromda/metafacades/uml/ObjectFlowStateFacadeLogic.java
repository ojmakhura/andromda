//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ObjectFlowStateFacade
 *
 * @see org.andromda.metafacades.uml.ObjectFlowStateFacade
 */
public abstract class ObjectFlowStateFacadeLogic
    extends org.andromda.metafacades.uml.StateFacadeLogicImpl
    implements org.andromda.metafacades.uml.ObjectFlowStateFacade
{

    protected org.omg.uml.behavioralelements.activitygraphs.ObjectFlowState metaObject;

    public ObjectFlowStateFacadeLogic(org.omg.uml.behavioralelements.activitygraphs.ObjectFlowState metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ObjectFlowStateFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetType2rPreCondition()
    {
    }

    private void handleGetType2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType2r = null;
        handleGetType2rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType2r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType2rPostCondition();
        return getType2r;
    }

    protected abstract java.lang.Object handleGetType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}