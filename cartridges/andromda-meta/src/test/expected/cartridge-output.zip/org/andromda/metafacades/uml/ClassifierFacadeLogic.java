//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ClassifierFacade
 *
 * @see org.andromda.metafacades.uml.ClassifierFacade
 */
public abstract class ClassifierFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.ClassifierFacade
{
    protected org.omg.uml.foundation.core.Classifier metaObject;
    private org.andromda.metafacades.uml.GeneralizableElementFacade super_;

    public ClassifierFacadeLogic (org.omg.uml.foundation.core.Classifier metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.GeneralizableElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.GeneralizableElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ClassifierFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isPrimitive()
    */
    protected abstract boolean handleIsPrimitive();

    private void handleIsPrimitive1aPreCondition()
    {
    }

    private void handleIsPrimitive1aPostCondition()
    {
    }

    public final boolean isPrimitive()
    {
        handleIsPrimitive1aPreCondition();
        boolean primitive1a = handleIsPrimitive();
        handleIsPrimitive1aPostCondition();
        return primitive1a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#getOperationCallFromAttributes()
    */
    protected abstract java.lang.String handleGetOperationCallFromAttributes();

    private void handleGetOperationCallFromAttributes2aPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes2aPostCondition()
    {
    }

    public final java.lang.String getOperationCallFromAttributes()
    {
        handleGetOperationCallFromAttributes2aPreCondition();
        java.lang.String operationCallFromAttributes2a = handleGetOperationCallFromAttributes();
        handleGetOperationCallFromAttributes2aPostCondition();
        return operationCallFromAttributes2a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#getAbstractions()
    */
    protected abstract java.util.Collection handleGetAbstractions();

    private void handleGetAbstractions3aPreCondition()
    {
    }

    private void handleGetAbstractions3aPostCondition()
    {
    }

    public final java.util.Collection getAbstractions()
    {
        handleGetAbstractions3aPreCondition();
        java.util.Collection abstractions3a = handleGetAbstractions();
        handleGetAbstractions3aPostCondition();
        return abstractions3a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isAbstract()
    */
    protected abstract boolean handleIsAbstract();

    private void handleIsAbstract4aPreCondition()
    {
    }

    private void handleIsAbstract4aPostCondition()
    {
    }

    public final boolean isAbstract()
    {
        handleIsAbstract4aPreCondition();
        boolean abstract4a = handleIsAbstract();
        handleIsAbstract4aPostCondition();
        return abstract4a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#getProperties()
    */
    protected abstract java.util.Collection handleGetProperties();

    private void handleGetProperties5aPreCondition()
    {
    }

    private void handleGetProperties5aPostCondition()
    {
    }

    public final java.util.Collection getProperties()
    {
        handleGetProperties5aPreCondition();
        java.util.Collection properties5a = handleGetProperties();
        handleGetProperties5aPostCondition();
        return properties5a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isDataType()
    */
    protected abstract boolean handleIsDataType();

    private void handleIsDataType6aPreCondition()
    {
    }

    private void handleIsDataType6aPostCondition()
    {
    }

    public final boolean isDataType()
    {
        handleIsDataType6aPreCondition();
        boolean dataType6a = handleIsDataType();
        handleIsDataType6aPostCondition();
        return dataType6a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isArrayType()
    */
    protected abstract boolean handleIsArrayType();

    private void handleIsArrayType7aPreCondition()
    {
    }

    private void handleIsArrayType7aPostCondition()
    {
    }

    public final boolean isArrayType()
    {
        handleIsArrayType7aPreCondition();
        boolean arrayType7a = handleIsArrayType();
        handleIsArrayType7aPostCondition();
        return arrayType7a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isCollectionType()
    */
    protected abstract boolean handleIsCollectionType();

    private void handleIsCollectionType8aPreCondition()
    {
    }

    private void handleIsCollectionType8aPostCondition()
    {
    }

    public final boolean isCollectionType()
    {
        handleIsCollectionType8aPreCondition();
        boolean collectionType8a = handleIsCollectionType();
        handleIsCollectionType8aPostCondition();
        return collectionType8a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#getWrapperName()
    */
    protected abstract java.lang.String handleGetWrapperName();

    private void handleGetWrapperName9aPreCondition()
    {
    }

    private void handleGetWrapperName9aPostCondition()
    {
    }

    public final java.lang.String getWrapperName()
    {
        handleGetWrapperName9aPreCondition();
        java.lang.String wrapperName9a = handleGetWrapperName();
        handleGetWrapperName9aPostCondition();
        return wrapperName9a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isDateType()
    */
    protected abstract boolean handleIsDateType();

    private void handleIsDateType10aPreCondition()
    {
    }

    private void handleIsDateType10aPostCondition()
    {
    }

    public final boolean isDateType()
    {
        handleIsDateType10aPreCondition();
        boolean dateType10a = handleIsDateType();
        handleIsDateType10aPostCondition();
        return dateType10a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isInterface()
    */
    protected abstract boolean handleIsInterface();

    private void handleIsInterface11aPreCondition()
    {
    }

    private void handleIsInterface11aPostCondition()
    {
    }

    public final boolean isInterface()
    {
        handleIsInterface11aPreCondition();
        boolean interface11a = handleIsInterface();
        handleIsInterface11aPostCondition();
        return interface11a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#getJavaNullString()
    */
    protected abstract java.lang.String handleGetJavaNullString();

    private void handleGetJavaNullString12aPreCondition()
    {
    }

    private void handleGetJavaNullString12aPostCondition()
    {
    }

    public final java.lang.String getJavaNullString()
    {
        handleGetJavaNullString12aPreCondition();
        java.lang.String javaNullString12a = handleGetJavaNullString();
        handleGetJavaNullString12aPostCondition();
        return javaNullString12a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isListType()
    */
    protected abstract boolean handleIsListType();

    private void handleIsListType13aPreCondition()
    {
    }

    private void handleIsListType13aPostCondition()
    {
    }

    public final boolean isListType()
    {
        handleIsListType13aPreCondition();
        boolean listType13a = handleIsListType();
        handleIsListType13aPostCondition();
        return listType13a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isSetType()
    */
    protected abstract boolean handleIsSetType();

    private void handleIsSetType14aPreCondition()
    {
    }

    private void handleIsSetType14aPostCondition()
    {
    }

    public final boolean isSetType()
    {
        handleIsSetType14aPreCondition();
        boolean setType14a = handleIsSetType();
        handleIsSetType14aPostCondition();
        return setType14a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isFileType()
    */
    protected abstract boolean handleIsFileType();

    private void handleIsFileType15aPreCondition()
    {
    }

    private void handleIsFileType15aPostCondition()
    {
    }

    public final boolean isFileType()
    {
        handleIsFileType15aPreCondition();
        boolean fileType15a = handleIsFileType();
        handleIsFileType15aPostCondition();
        return fileType15a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isMapType()
    */
    protected abstract boolean handleIsMapType();

    private void handleIsMapType16aPreCondition()
    {
    }

    private void handleIsMapType16aPostCondition()
    {
    }

    public final boolean isMapType()
    {
        handleIsMapType16aPreCondition();
        boolean mapType16a = handleIsMapType();
        handleIsMapType16aPostCondition();
        return mapType16a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isStringType()
    */
    protected abstract boolean handleIsStringType();

    private void handleIsStringType17aPreCondition()
    {
    }

    private void handleIsStringType17aPostCondition()
    {
    }

    public final boolean isStringType()
    {
        handleIsStringType17aPreCondition();
        boolean stringType17a = handleIsStringType();
        handleIsStringType17aPostCondition();
        return stringType17a;
    }

   /**
	* @see org.andromda.metafacades.uml.ClassifierFacade#isEnumeration()
    */
    protected abstract boolean handleIsEnumeration();

    private void handleIsEnumeration18aPreCondition()
    {
    }

    private void handleIsEnumeration18aPostCondition()
    {
    }

    public final boolean isEnumeration()
    {
        handleIsEnumeration18aPreCondition();
        boolean enumeration18a = handleIsEnumeration();
        handleIsEnumeration18aPostCondition();
        return enumeration18a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.util.Collection handleGetAttributes(boolean follow);

    private void handleGetAttributes1oPreCondition()
    {
    }

    private void handleGetAttributes1oPostCondition()
    {
    }

    public java.util.Collection getAttributes(boolean follow)
    {
        handleGetAttributes1oPreCondition();
        java.util.Collection returnValue = handleGetAttributes(follow);
        handleGetAttributes1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOperations1rPreCondition()
    {
    }

    private void handleGetOperations1rPostCondition()
    {
    }

    public final java.util.Collection getOperations()
    {
        handleGetOperations1rPreCondition();
        java.util.Collection getOperations1r = shieldedElements(handleGetOperations());
        handleGetOperations1rPostCondition();
        return getOperations1r;
    }

    protected abstract java.util.Collection handleGetOperations();

    private void handleGetAttributes2rPreCondition()
    {
    }

    private void handleGetAttributes2rPostCondition()
    {
    }

    public final java.util.Collection getAttributes()
    {
        handleGetAttributes2rPreCondition();
        java.util.Collection getAttributes2r = shieldedElements(handleGetAttributes());
        handleGetAttributes2rPostCondition();
        return getAttributes2r;
    }

    protected abstract java.util.Collection handleGetAttributes();

    private void handleGetAssociationEnds3rPreCondition()
    {
    }

    private void handleGetAssociationEnds3rPostCondition()
    {
    }

    public final java.util.Collection getAssociationEnds()
    {
        handleGetAssociationEnds3rPreCondition();
        java.util.Collection getAssociationEnds3r = shieldedElements(handleGetAssociationEnds());
        handleGetAssociationEnds3rPostCondition();
        return getAssociationEnds3r;
    }

    protected abstract java.util.Collection handleGetAssociationEnds();

    private void handleGetNonArray5rPreCondition()
    {
    }

    private void handleGetNonArray5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        handleGetNonArray5rPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade getNonArray5r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetNonArray());
        handleGetNonArray5rPostCondition();
        return getNonArray5r;
    }

    protected abstract java.lang.Object handleGetNonArray();

    private void handleGetArray6rPreCondition()
    {
    }

    private void handleGetArray6rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        handleGetArray6rPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade getArray6r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetArray());
        handleGetArray6rPostCondition();
        return getArray6r;
    }

    protected abstract java.lang.Object handleGetArray();

    private void handleGetStaticAttributes11rPreCondition()
    {
    }

    private void handleGetStaticAttributes11rPostCondition()
    {
    }

    public final java.util.Collection getStaticAttributes()
    {
        handleGetStaticAttributes11rPreCondition();
        java.util.Collection getStaticAttributes11r = shieldedElements(handleGetStaticAttributes());
        handleGetStaticAttributes11rPostCondition();
        return getStaticAttributes11r;
    }

    protected abstract java.util.Collection handleGetStaticAttributes();

    private void handleGetInstanceAttributes12rPreCondition()
    {
    }

    private void handleGetInstanceAttributes12rPostCondition()
    {
    }

    public final java.util.Collection getInstanceAttributes()
    {
        handleGetInstanceAttributes12rPreCondition();
        java.util.Collection getInstanceAttributes12r = shieldedElements(handleGetInstanceAttributes());
        handleGetInstanceAttributes12rPostCondition();
        return getInstanceAttributes12r;
    }

    protected abstract java.util.Collection handleGetInstanceAttributes();

    private void handleGetStaticOperations13rPreCondition()
    {
    }

    private void handleGetStaticOperations13rPostCondition()
    {
    }

    public final java.util.Collection getStaticOperations()
    {
        handleGetStaticOperations13rPreCondition();
        java.util.Collection getStaticOperations13r = shieldedElements(handleGetStaticOperations());
        handleGetStaticOperations13rPostCondition();
        return getStaticOperations13r;
    }

    protected abstract java.util.Collection handleGetStaticOperations();

    private void handleGetInstanceOperations14rPreCondition()
    {
    }

    private void handleGetInstanceOperations14rPostCondition()
    {
    }

    public final java.util.Collection getInstanceOperations()
    {
        handleGetInstanceOperations14rPreCondition();
        java.util.Collection getInstanceOperations14r = shieldedElements(handleGetInstanceOperations());
        handleGetInstanceOperations14rPostCondition();
        return getInstanceOperations14r;
    }

    protected abstract java.util.Collection handleGetInstanceOperations();

    // ----------- delegates to org.andromda.metafacades.uml.GeneralizableElementFacade ------------
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getAllGeneralizations()
	{
        return super_.getAllGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
	{
        return super_.getGeneralization();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getGeneralizations()
	{
        return super_.getGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getSpecializations()
	{
        return super_.getSpecializations();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
	{
        return super_.getActivityGraphContext();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getSourceDependencies()
	{
        return super_.getSourceDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTargetDependencies()
	{
        return super_.getTargetDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        return super_.getValidationOwner();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        return super_.getValidationName();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each classifier must have a non-empty name."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.isUnique(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"attributes"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.validation.OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "The name of each attribute on a class MUST BE unique."));
        }
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");  
        } 
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }      
        return toString.toString();
    }      
}
