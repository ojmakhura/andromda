//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ClassifierFacade
 *
 * @see org.andromda.metafacades.uml.ClassifierFacade
 */
public abstract class ClassifierFacadeLogic
    extends org.andromda.metafacades.uml.GeneralizableElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ClassifierFacade
{

    protected org.omg.uml.foundation.core.Classifier metaObject;

    public ClassifierFacadeLogic(org.omg.uml.foundation.core.Classifier metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ClassifierFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isPrimitive()
    */
    protected abstract boolean handleIsPrimitive();

    private void handleIsPrimitive1aPreCondition()
    {
    }

    private void handleIsPrimitive1aPostCondition()
    {
    }

    private boolean __primitive1a;
    private boolean __primitive1aSet = false;

    public final boolean isPrimitive()
    {
        boolean primitive1a = this.__primitive1a;
        if (!this.__primitive1aSet)
        {
            handleIsPrimitive1aPreCondition();
            primitive1a = handleIsPrimitive();
            handleIsPrimitive1aPostCondition();
            this.__primitive1a = primitive1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__primitive1aSet = true;
            }
        }
        return primitive1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getOperationCallFromAttributes()
    */
    protected abstract java.lang.String handleGetOperationCallFromAttributes();

    private void handleGetOperationCallFromAttributes2aPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes2aPostCondition()
    {
    }

    private java.lang.String __operationCallFromAttributes2a;
    private boolean __operationCallFromAttributes2aSet = false;

    public final java.lang.String getOperationCallFromAttributes()
    {
        java.lang.String operationCallFromAttributes2a = this.__operationCallFromAttributes2a;
        if (!this.__operationCallFromAttributes2aSet)
        {
            handleGetOperationCallFromAttributes2aPreCondition();
            operationCallFromAttributes2a = handleGetOperationCallFromAttributes();
            handleGetOperationCallFromAttributes2aPostCondition();
            this.__operationCallFromAttributes2a = operationCallFromAttributes2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__operationCallFromAttributes2aSet = true;
            }
        }
        return operationCallFromAttributes2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isAbstract()
    */
    protected abstract boolean handleIsAbstract();

    private void handleIsAbstract3aPreCondition()
    {
    }

    private void handleIsAbstract3aPostCondition()
    {
    }

    private boolean __abstract3a;
    private boolean __abstract3aSet = false;

    public final boolean isAbstract()
    {
        boolean abstract3a = this.__abstract3a;
        if (!this.__abstract3aSet)
        {
            handleIsAbstract3aPreCondition();
            abstract3a = handleIsAbstract();
            handleIsAbstract3aPostCondition();
            this.__abstract3a = abstract3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__abstract3aSet = true;
            }
        }
        return abstract3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getProperties()
    */
    protected abstract java.util.Collection handleGetProperties();

    private void handleGetProperties4aPreCondition()
    {
    }

    private void handleGetProperties4aPostCondition()
    {
    }

    private java.util.Collection __properties4a;
    private boolean __properties4aSet = false;

    public final java.util.Collection getProperties()
    {
        java.util.Collection properties4a = this.__properties4a;
        if (!this.__properties4aSet)
        {
            handleGetProperties4aPreCondition();
            properties4a = handleGetProperties();
            handleGetProperties4aPostCondition();
            this.__properties4a = properties4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__properties4aSet = true;
            }
        }
        return properties4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isDataType()
    */
    protected abstract boolean handleIsDataType();

    private void handleIsDataType5aPreCondition()
    {
    }

    private void handleIsDataType5aPostCondition()
    {
    }

    private boolean __dataType5a;
    private boolean __dataType5aSet = false;

    public final boolean isDataType()
    {
        boolean dataType5a = this.__dataType5a;
        if (!this.__dataType5aSet)
        {
            handleIsDataType5aPreCondition();
            dataType5a = handleIsDataType();
            handleIsDataType5aPostCondition();
            this.__dataType5a = dataType5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__dataType5aSet = true;
            }
        }
        return dataType5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isArrayType()
    */
    protected abstract boolean handleIsArrayType();

    private void handleIsArrayType6aPreCondition()
    {
    }

    private void handleIsArrayType6aPostCondition()
    {
    }

    private boolean __arrayType6a;
    private boolean __arrayType6aSet = false;

    public final boolean isArrayType()
    {
        boolean arrayType6a = this.__arrayType6a;
        if (!this.__arrayType6aSet)
        {
            handleIsArrayType6aPreCondition();
            arrayType6a = handleIsArrayType();
            handleIsArrayType6aPostCondition();
            this.__arrayType6a = arrayType6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__arrayType6aSet = true;
            }
        }
        return arrayType6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isCollectionType()
    */
    protected abstract boolean handleIsCollectionType();

    private void handleIsCollectionType7aPreCondition()
    {
    }

    private void handleIsCollectionType7aPostCondition()
    {
    }

    private boolean __collectionType7a;
    private boolean __collectionType7aSet = false;

    public final boolean isCollectionType()
    {
        boolean collectionType7a = this.__collectionType7a;
        if (!this.__collectionType7aSet)
        {
            handleIsCollectionType7aPreCondition();
            collectionType7a = handleIsCollectionType();
            handleIsCollectionType7aPostCondition();
            this.__collectionType7a = collectionType7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__collectionType7aSet = true;
            }
        }
        return collectionType7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getWrapperName()
    */
    protected abstract java.lang.String handleGetWrapperName();

    private void handleGetWrapperName8aPreCondition()
    {
    }

    private void handleGetWrapperName8aPostCondition()
    {
    }

    private java.lang.String __wrapperName8a;
    private boolean __wrapperName8aSet = false;

    public final java.lang.String getWrapperName()
    {
        java.lang.String wrapperName8a = this.__wrapperName8a;
        if (!this.__wrapperName8aSet)
        {
            handleGetWrapperName8aPreCondition();
            wrapperName8a = handleGetWrapperName();
            handleGetWrapperName8aPostCondition();
            this.__wrapperName8a = wrapperName8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__wrapperName8aSet = true;
            }
        }
        return wrapperName8a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isDateType()
    */
    protected abstract boolean handleIsDateType();

    private void handleIsDateType9aPreCondition()
    {
    }

    private void handleIsDateType9aPostCondition()
    {
    }

    private boolean __dateType9a;
    private boolean __dateType9aSet = false;

    public final boolean isDateType()
    {
        boolean dateType9a = this.__dateType9a;
        if (!this.__dateType9aSet)
        {
            handleIsDateType9aPreCondition();
            dateType9a = handleIsDateType();
            handleIsDateType9aPostCondition();
            this.__dateType9a = dateType9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__dateType9aSet = true;
            }
        }
        return dateType9a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isInterface()
    */
    protected abstract boolean handleIsInterface();

    private void handleIsInterface10aPreCondition()
    {
    }

    private void handleIsInterface10aPostCondition()
    {
    }

    private boolean __interface10a;
    private boolean __interface10aSet = false;

    public final boolean isInterface()
    {
        boolean interface10a = this.__interface10a;
        if (!this.__interface10aSet)
        {
            handleIsInterface10aPreCondition();
            interface10a = handleIsInterface();
            handleIsInterface10aPostCondition();
            this.__interface10a = interface10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__interface10aSet = true;
            }
        }
        return interface10a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getJavaNullString()
    */
    protected abstract java.lang.String handleGetJavaNullString();

    private void handleGetJavaNullString11aPreCondition()
    {
    }

    private void handleGetJavaNullString11aPostCondition()
    {
    }

    private java.lang.String __javaNullString11a;
    private boolean __javaNullString11aSet = false;

    public final java.lang.String getJavaNullString()
    {
        java.lang.String javaNullString11a = this.__javaNullString11a;
        if (!this.__javaNullString11aSet)
        {
            handleGetJavaNullString11aPreCondition();
            javaNullString11a = handleGetJavaNullString();
            handleGetJavaNullString11aPostCondition();
            this.__javaNullString11a = javaNullString11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__javaNullString11aSet = true;
            }
        }
        return javaNullString11a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isListType()
    */
    protected abstract boolean handleIsListType();

    private void handleIsListType12aPreCondition()
    {
    }

    private void handleIsListType12aPostCondition()
    {
    }

    private boolean __listType12a;
    private boolean __listType12aSet = false;

    public final boolean isListType()
    {
        boolean listType12a = this.__listType12a;
        if (!this.__listType12aSet)
        {
            handleIsListType12aPreCondition();
            listType12a = handleIsListType();
            handleIsListType12aPostCondition();
            this.__listType12a = listType12a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__listType12aSet = true;
            }
        }
        return listType12a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isSetType()
    */
    protected abstract boolean handleIsSetType();

    private void handleIsSetType13aPreCondition()
    {
    }

    private void handleIsSetType13aPostCondition()
    {
    }

    private boolean __setType13a;
    private boolean __setType13aSet = false;

    public final boolean isSetType()
    {
        boolean setType13a = this.__setType13a;
        if (!this.__setType13aSet)
        {
            handleIsSetType13aPreCondition();
            setType13a = handleIsSetType();
            handleIsSetType13aPostCondition();
            this.__setType13a = setType13a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__setType13aSet = true;
            }
        }
        return setType13a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isFileType()
    */
    protected abstract boolean handleIsFileType();

    private void handleIsFileType14aPreCondition()
    {
    }

    private void handleIsFileType14aPostCondition()
    {
    }

    private boolean __fileType14a;
    private boolean __fileType14aSet = false;

    public final boolean isFileType()
    {
        boolean fileType14a = this.__fileType14a;
        if (!this.__fileType14aSet)
        {
            handleIsFileType14aPreCondition();
            fileType14a = handleIsFileType();
            handleIsFileType14aPostCondition();
            this.__fileType14a = fileType14a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fileType14aSet = true;
            }
        }
        return fileType14a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isMapType()
    */
    protected abstract boolean handleIsMapType();

    private void handleIsMapType15aPreCondition()
    {
    }

    private void handleIsMapType15aPostCondition()
    {
    }

    private boolean __mapType15a;
    private boolean __mapType15aSet = false;

    public final boolean isMapType()
    {
        boolean mapType15a = this.__mapType15a;
        if (!this.__mapType15aSet)
        {
            handleIsMapType15aPreCondition();
            mapType15a = handleIsMapType();
            handleIsMapType15aPostCondition();
            this.__mapType15a = mapType15a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__mapType15aSet = true;
            }
        }
        return mapType15a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isStringType()
    */
    protected abstract boolean handleIsStringType();

    private void handleIsStringType16aPreCondition()
    {
    }

    private void handleIsStringType16aPostCondition()
    {
    }

    private boolean __stringType16a;
    private boolean __stringType16aSet = false;

    public final boolean isStringType()
    {
        boolean stringType16a = this.__stringType16a;
        if (!this.__stringType16aSet)
        {
            handleIsStringType16aPreCondition();
            stringType16a = handleIsStringType();
            handleIsStringType16aPostCondition();
            this.__stringType16a = stringType16a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__stringType16aSet = true;
            }
        }
        return stringType16a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isEnumeration()
    */
    protected abstract boolean handleIsEnumeration();

    private void handleIsEnumeration17aPreCondition()
    {
    }

    private void handleIsEnumeration17aPostCondition()
    {
    }

    private boolean __enumeration17a;
    private boolean __enumeration17aSet = false;

    public final boolean isEnumeration()
    {
        boolean enumeration17a = this.__enumeration17a;
        if (!this.__enumeration17aSet)
        {
            handleIsEnumeration17aPreCondition();
            enumeration17a = handleIsEnumeration();
            handleIsEnumeration17aPostCondition();
            this.__enumeration17a = enumeration17a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enumeration17aSet = true;
            }
        }
        return enumeration17a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getArrayName()
    */
    protected abstract java.lang.String handleGetArrayName();

    private void handleGetArrayName18aPreCondition()
    {
    }

    private void handleGetArrayName18aPostCondition()
    {
    }

    private java.lang.String __arrayName18a;
    private boolean __arrayName18aSet = false;

    public final java.lang.String getArrayName()
    {
        java.lang.String arrayName18a = this.__arrayName18a;
        if (!this.__arrayName18aSet)
        {
            handleGetArrayName18aPreCondition();
            arrayName18a = handleGetArrayName();
            handleGetArrayName18aPostCondition();
            this.__arrayName18a = arrayName18a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__arrayName18aSet = true;
            }
        }
        return arrayName18a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getFullyQualifiedArrayName()
    */
    protected abstract java.lang.String handleGetFullyQualifiedArrayName();

    private void handleGetFullyQualifiedArrayName19aPreCondition()
    {
    }

    private void handleGetFullyQualifiedArrayName19aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedArrayName19a;
    private boolean __fullyQualifiedArrayName19aSet = false;

    public final java.lang.String getFullyQualifiedArrayName()
    {
        java.lang.String fullyQualifiedArrayName19a = this.__fullyQualifiedArrayName19a;
        if (!this.__fullyQualifiedArrayName19aSet)
        {
            handleGetFullyQualifiedArrayName19aPreCondition();
            fullyQualifiedArrayName19a = handleGetFullyQualifiedArrayName();
            handleGetFullyQualifiedArrayName19aPostCondition();
            this.__fullyQualifiedArrayName19a = fullyQualifiedArrayName19a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullyQualifiedArrayName19aSet = true;
            }
        }
        return fullyQualifiedArrayName19a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getSerialVersionUID()
    */
    protected abstract java.lang.Long handleGetSerialVersionUID();

    private void handleGetSerialVersionUID20aPreCondition()
    {
    }

    private void handleGetSerialVersionUID20aPostCondition()
    {
    }

    private java.lang.Long __serialVersionUID20a;
    private boolean __serialVersionUID20aSet = false;

    public final java.lang.Long getSerialVersionUID()
    {
        java.lang.Long serialVersionUID20a = this.__serialVersionUID20a;
        if (!this.__serialVersionUID20aSet)
        {
            handleGetSerialVersionUID20aPreCondition();
            serialVersionUID20a = handleGetSerialVersionUID();
            handleGetSerialVersionUID20aPostCondition();
            this.__serialVersionUID20a = serialVersionUID20a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__serialVersionUID20aSet = true;
            }
        }
        return serialVersionUID20a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isBlobType()
    */
    protected abstract boolean handleIsBlobType();

    private void handleIsBlobType21aPreCondition()
    {
    }

    private void handleIsBlobType21aPostCondition()
    {
    }

    private boolean __blobType21a;
    private boolean __blobType21aSet = false;

    public final boolean isBlobType()
    {
        boolean blobType21a = this.__blobType21a;
        if (!this.__blobType21aSet)
        {
            handleIsBlobType21aPreCondition();
            blobType21a = handleIsBlobType();
            handleIsBlobType21aPostCondition();
            this.__blobType21a = blobType21a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__blobType21aSet = true;
            }
        }
        return blobType21a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isBooleanType()
    */
    protected abstract boolean handleIsBooleanType();

    private void handleIsBooleanType22aPreCondition()
    {
    }

    private void handleIsBooleanType22aPostCondition()
    {
    }

    private boolean __booleanType22a;
    private boolean __booleanType22aSet = false;

    public final boolean isBooleanType()
    {
        boolean booleanType22a = this.__booleanType22a;
        if (!this.__booleanType22aSet)
        {
            handleIsBooleanType22aPreCondition();
            booleanType22a = handleIsBooleanType();
            handleIsBooleanType22aPostCondition();
            this.__booleanType22a = booleanType22a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__booleanType22aSet = true;
            }
        }
        return booleanType22a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isTimeType()
    */
    protected abstract boolean handleIsTimeType();

    private void handleIsTimeType23aPreCondition()
    {
    }

    private void handleIsTimeType23aPostCondition()
    {
    }

    private boolean __timeType23a;
    private boolean __timeType23aSet = false;

    public final boolean isTimeType()
    {
        boolean timeType23a = this.__timeType23a;
        if (!this.__timeType23aSet)
        {
            handleIsTimeType23aPreCondition();
            timeType23a = handleIsTimeType();
            handleIsTimeType23aPostCondition();
            this.__timeType23a = timeType23a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__timeType23aSet = true;
            }
        }
        return timeType23a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#isLeaf()
    */
    protected abstract boolean handleIsLeaf();

    private void handleIsLeaf24aPreCondition()
    {
    }

    private void handleIsLeaf24aPostCondition()
    {
    }

    private boolean __leaf24a;
    private boolean __leaf24aSet = false;

    public final boolean isLeaf()
    {
        boolean leaf24a = this.__leaf24a;
        if (!this.__leaf24aSet)
        {
            handleIsLeaf24aPreCondition();
            leaf24a = handleIsLeaf();
            handleIsLeaf24aPostCondition();
            this.__leaf24a = leaf24a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__leaf24aSet = true;
            }
        }
        return leaf24a;
    }

   /**
    * @see org.andromda.metafacades.uml.ClassifierFacade#getImplementedInterfaceList()
    */
    protected abstract java.lang.String handleGetImplementedInterfaceList();

    private void handleGetImplementedInterfaceList25aPreCondition()
    {
    }

    private void handleGetImplementedInterfaceList25aPostCondition()
    {
    }

    private java.lang.String __implementedInterfaceList25a;
    private boolean __implementedInterfaceList25aSet = false;

    public final java.lang.String getImplementedInterfaceList()
    {
        java.lang.String implementedInterfaceList25a = this.__implementedInterfaceList25a;
        if (!this.__implementedInterfaceList25aSet)
        {
            handleGetImplementedInterfaceList25aPreCondition();
            implementedInterfaceList25a = handleGetImplementedInterfaceList();
            handleGetImplementedInterfaceList25aPostCondition();
            this.__implementedInterfaceList25a = implementedInterfaceList25a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__implementedInterfaceList25aSet = true;
            }
        }
        return implementedInterfaceList25a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.util.Collection handleGetAttributes(boolean follow);

    private void handleGetAttributes1oPreCondition()
    {
    }

    private void handleGetAttributes1oPostCondition()
    {
    }

    public java.util.Collection getAttributes(boolean follow)
    {
        handleGetAttributes1oPreCondition();
        java.util.Collection returnValue = handleGetAttributes(follow);
        handleGetAttributes1oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.AttributeFacade handleFindAttribute(java.lang.String name);

    private void handleFindAttribute2oPreCondition()
    {
    }

    private void handleFindAttribute2oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.AttributeFacade findAttribute(java.lang.String name)
    {
        handleFindAttribute2oPreCondition();
        org.andromda.metafacades.uml.AttributeFacade returnValue = handleFindAttribute(name);
        handleFindAttribute2oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetProperties(boolean follow);

    private void handleGetProperties3oPreCondition()
    {
    }

    private void handleGetProperties3oPostCondition()
    {
    }

    public java.util.Collection getProperties(boolean follow)
    {
        handleGetProperties3oPreCondition();
        java.util.Collection returnValue = handleGetProperties(follow);
        handleGetProperties3oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOperations1rPreCondition()
    {
    }

    private void handleGetOperations1rPostCondition()
    {
    }

    public final java.util.Collection getOperations()
    {
        java.util.Collection getOperations1r = null;
        handleGetOperations1rPreCondition();
        Object result = this.shieldedElements(handleGetOperations());
        try
        {
            getOperations1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOperations1rPostCondition();
        return getOperations1r;
    }

    protected abstract java.util.Collection handleGetOperations();

    private void handleGetAttributes2rPreCondition()
    {
    }

    private void handleGetAttributes2rPostCondition()
    {
    }

    public final java.util.Collection getAttributes()
    {
        java.util.Collection getAttributes2r = null;
        handleGetAttributes2rPreCondition();
        Object result = this.shieldedElements(handleGetAttributes());
        try
        {
            getAttributes2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAttributes2rPostCondition();
        return getAttributes2r;
    }

    protected abstract java.util.Collection handleGetAttributes();

    private void handleGetAssociationEnds3rPreCondition()
    {
    }

    private void handleGetAssociationEnds3rPostCondition()
    {
    }

    public final java.util.Collection getAssociationEnds()
    {
        java.util.Collection getAssociationEnds3r = null;
        handleGetAssociationEnds3rPreCondition();
        Object result = this.shieldedElements(handleGetAssociationEnds());
        try
        {
            getAssociationEnds3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAssociationEnds3rPostCondition();
        return getAssociationEnds3r;
    }

    protected abstract java.util.Collection handleGetAssociationEnds();

    private void handleGetNonArray5rPreCondition()
    {
    }

    private void handleGetNonArray5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        org.andromda.metafacades.uml.ClassifierFacade getNonArray5r = null;
        handleGetNonArray5rPreCondition();
        Object result = this.shieldedElement(handleGetNonArray());
        try
        {
            getNonArray5r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetNonArray5rPostCondition();
        return getNonArray5r;
    }

    protected abstract java.lang.Object handleGetNonArray();

    private void handleGetArray6rPreCondition()
    {
    }

    private void handleGetArray6rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        org.andromda.metafacades.uml.ClassifierFacade getArray6r = null;
        handleGetArray6rPreCondition();
        Object result = this.shieldedElement(handleGetArray());
        try
        {
            getArray6r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetArray6rPostCondition();
        return getArray6r;
    }

    protected abstract java.lang.Object handleGetArray();

    private void handleGetStaticAttributes11rPreCondition()
    {
    }

    private void handleGetStaticAttributes11rPostCondition()
    {
    }

    public final java.util.Collection getStaticAttributes()
    {
        java.util.Collection getStaticAttributes11r = null;
        handleGetStaticAttributes11rPreCondition();
        Object result = this.shieldedElements(handleGetStaticAttributes());
        try
        {
            getStaticAttributes11r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetStaticAttributes11rPostCondition();
        return getStaticAttributes11r;
    }

    protected abstract java.util.Collection handleGetStaticAttributes();

    private void handleGetInstanceAttributes12rPreCondition()
    {
    }

    private void handleGetInstanceAttributes12rPostCondition()
    {
    }

    public final java.util.Collection getInstanceAttributes()
    {
        java.util.Collection getInstanceAttributes12r = null;
        handleGetInstanceAttributes12rPreCondition();
        Object result = this.shieldedElements(handleGetInstanceAttributes());
        try
        {
            getInstanceAttributes12r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetInstanceAttributes12rPostCondition();
        return getInstanceAttributes12r;
    }

    protected abstract java.util.Collection handleGetInstanceAttributes();

    private void handleGetStaticOperations13rPreCondition()
    {
    }

    private void handleGetStaticOperations13rPostCondition()
    {
    }

    public final java.util.Collection getStaticOperations()
    {
        java.util.Collection getStaticOperations13r = null;
        handleGetStaticOperations13rPreCondition();
        Object result = this.shieldedElements(handleGetStaticOperations());
        try
        {
            getStaticOperations13r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetStaticOperations13rPostCondition();
        return getStaticOperations13r;
    }

    protected abstract java.util.Collection handleGetStaticOperations();

    private void handleGetInstanceOperations14rPreCondition()
    {
    }

    private void handleGetInstanceOperations14rPostCondition()
    {
    }

    public final java.util.Collection getInstanceOperations()
    {
        java.util.Collection getInstanceOperations14r = null;
        handleGetInstanceOperations14rPreCondition();
        Object result = this.shieldedElements(handleGetInstanceOperations());
        try
        {
            getInstanceOperations14r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetInstanceOperations14rPostCondition();
        return getInstanceOperations14r;
    }

    protected abstract java.util.Collection handleGetInstanceOperations();

    private void handleGetAbstractions16rPreCondition()
    {
    }

    private void handleGetAbstractions16rPostCondition()
    {
    }

    public final java.util.Collection getAbstractions()
    {
        java.util.Collection getAbstractions16r = null;
        handleGetAbstractions16rPreCondition();
        Object result = this.shieldedElements(handleGetAbstractions());
        try
        {
            getAbstractions16r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAbstractions16rPostCondition();
        return getAbstractions16r;
    }

    protected abstract java.util.Collection handleGetAbstractions();

    private void handleGetNavigableConnectingEnds21rPreCondition()
    {
    }

    private void handleGetNavigableConnectingEnds21rPostCondition()
    {
    }

    public final java.util.Collection getNavigableConnectingEnds()
    {
        java.util.Collection getNavigableConnectingEnds21r = null;
        handleGetNavigableConnectingEnds21rPreCondition();
        Object result = this.shieldedElements(handleGetNavigableConnectingEnds());
        try
        {
            getNavigableConnectingEnds21r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetNavigableConnectingEnds21rPostCondition();
        return getNavigableConnectingEnds21r;
    }

    protected abstract java.util.Collection handleGetNavigableConnectingEnds();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::classifier must have a name",
                        "Each classifier must have a non-empty name."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"attributes"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}})); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::attribute names must be unique",
                        "The name of each attribute on a class must be unique."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"navigableConnectingEnds"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}})); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::ClassifierFacade::association end names must be unique",
                        "The name of each navigable connecting association end must be unique."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}