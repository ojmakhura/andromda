//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndExceptionHandler
 *
 * @see org.andromda.metafacades.uml.FrontEndExceptionHandler
 */
public abstract class FrontEndExceptionHandlerLogic
    extends org.andromda.metafacades.uml.FrontEndForwardLogicImpl
    implements org.andromda.metafacades.uml.FrontEndExceptionHandler
{

    protected Object metaObject;

    public FrontEndExceptionHandlerLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndExceptionHandler";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndExceptionHandler#isFrontEndException()
    */
    protected abstract boolean handleIsFrontEndException();

    private void handleIsFrontEndException1aPreCondition()
    {
    }

    private void handleIsFrontEndException1aPostCondition()
    {
    }

    private boolean __frontEndException1a;
    private boolean __frontEndException1aSet = false;

    public final boolean isFrontEndException()
    {
        boolean frontEndException1a = this.__frontEndException1a;
        if (!this.__frontEndException1aSet)
        {
            handleIsFrontEndException1aPreCondition();
            frontEndException1a = handleIsFrontEndException();
            handleIsFrontEndException1aPostCondition();
            this.__frontEndException1a = frontEndException1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__frontEndException1aSet = true;
            }
        }
        return frontEndException1a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}