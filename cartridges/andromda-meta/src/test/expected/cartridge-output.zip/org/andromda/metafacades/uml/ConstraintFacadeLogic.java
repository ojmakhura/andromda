//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ConstraintFacade
 *
 * @see org.andromda.metafacades.uml.ConstraintFacade
 */
public abstract class ConstraintFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ConstraintFacade
{
    protected org.omg.uml.foundation.core.Constraint metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public ConstraintFacadeLogic (org.omg.uml.foundation.core.Constraint metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ConstraintFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see java.lang.String#getBody()
    */
    public abstract java.lang.String handleGetBody();

    private java.lang.String body1a;

    private void handleGetBody1aPreCondition()
    {
    }

    private void handleGetBody1aPostCondition()
    {
    }

    public final java.lang.String getBody()
    {
        handleGetBody1aPreCondition();
        body1a = handleGetBody();
        handleGetBody1aPostCondition();
        return body1a;
    }

    // ---------------- business methods ----------------------

    public abstract boolean handleIsInvariant();

    private void handleIsInvariant1oPreCondition()
    {
    }

    private void handleIsInvariant1oPostCondition()
    {
    }

    public final boolean isInvariant()
    {
        handleIsInvariant1oPreCondition();
        boolean returnValue = handleIsInvariant();
        handleIsInvariant1oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsPreCondition();

    private void handleIsPreCondition2oPreCondition()
    {
    }

    private void handleIsPreCondition2oPostCondition()
    {
    }

    public final boolean isPreCondition()
    {
        handleIsPreCondition2oPreCondition();
        boolean returnValue = handleIsPreCondition();
        handleIsPreCondition2oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsPostCondition();

    private void handleIsPostCondition3oPreCondition()
    {
    }

    private void handleIsPostCondition3oPostCondition()
    {
    }

    public final boolean isPostCondition()
    {
        handleIsPostCondition3oPreCondition();
        boolean returnValue = handleIsPostCondition();
        handleIsPostCondition3oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsDefinition();

    private void handleIsDefinition4oPreCondition()
    {
    }

    private void handleIsDefinition4oPostCondition()
    {
    }

    public final boolean isDefinition()
    {
        handleIsDefinition4oPreCondition();
        boolean returnValue = handleIsDefinition();
        handleIsDefinition4oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsBodyExpression();

    private void handleIsBodyExpression5oPreCondition()
    {
    }

    private void handleIsBodyExpression5oPostCondition()
    {
    }

    public final boolean isBodyExpression()
    {
        handleIsBodyExpression5oPreCondition();
        boolean returnValue = handleIsBodyExpression();
        handleIsBodyExpression5oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetTranslation(java.lang.String language);

    private void handleGetTranslation6oPreCondition()
    {
    }

    private void handleGetTranslation6oPostCondition()
    {
    }

    public final java.lang.String getTranslation(java.lang.String language)
    {
        handleGetTranslation6oPreCondition();
        java.lang.String returnValue = handleGetTranslation(language);
        handleGetTranslation6oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private org.andromda.metafacades.uml.ModelElementFacade getContextElement1r;

    private void handleGetContextElement1rPreCondition()
    {
    }

    private void handleGetContextElement1rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetContextElement();

    public final org.andromda.metafacades.uml.ModelElementFacade getContextElement()
    {
        handleGetContextElement1rPreCondition();
        getContextElement1r = (org.andromda.metafacades.uml.ModelElementFacade)shieldedElement(handleGetContextElement());
        handleGetContextElement1rPostCondition();
        return getContextElement1r;
    }

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
