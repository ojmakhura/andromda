//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.GeneralizableElementFacade
 *
 * @see org.andromda.metafacades.uml.GeneralizableElementFacade
 */
public abstract class GeneralizableElementFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.GeneralizableElementFacade
{

    protected org.omg.uml.foundation.core.GeneralizableElement metaObject;

    public GeneralizableElementFacadeLogic(org.omg.uml.foundation.core.GeneralizableElement metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizableElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getAllGeneralizations()
    */
    protected abstract java.util.Collection handleGetAllGeneralizations();

    private void handleGetAllGeneralizations1aPreCondition()
    {
    }

    private void handleGetAllGeneralizations1aPostCondition()
    {
    }

    private java.util.Collection __allGeneralizations1a;
    private boolean __allGeneralizations1aSet = false;

    public final java.util.Collection getAllGeneralizations()
    {
        java.util.Collection allGeneralizations1a = this.__allGeneralizations1a;
        if (!this.__allGeneralizations1aSet)
        {
            handleGetAllGeneralizations1aPreCondition();
            allGeneralizations1a = handleGetAllGeneralizations();
            handleGetAllGeneralizations1aPostCondition();
            this.__allGeneralizations1a = allGeneralizations1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__allGeneralizations1aSet = true;
            }
        }
        return allGeneralizations1a;
    }

   /**
    * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizationList()
    */
    protected abstract java.lang.String handleGetGeneralizationList();

    private void handleGetGeneralizationList2aPreCondition()
    {
    }

    private void handleGetGeneralizationList2aPostCondition()
    {
    }

    private java.lang.String __generalizationList2a;
    private boolean __generalizationList2aSet = false;

    public final java.lang.String getGeneralizationList()
    {
        java.lang.String generalizationList2a = this.__generalizationList2a;
        if (!this.__generalizationList2aSet)
        {
            handleGetGeneralizationList2aPreCondition();
            generalizationList2a = handleGetGeneralizationList();
            handleGetGeneralizationList2aPostCondition();
            this.__generalizationList2a = generalizationList2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__generalizationList2aSet = true;
            }
        }
        return generalizationList2a;
    }

    // ------------- associations ------------------

    private void handleGetGeneralization1rPreCondition()
    {
    }

    private void handleGetGeneralization1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization1r = null;
        handleGetGeneralization1rPreCondition();
        Object result = this.shieldedElement(handleGetGeneralization());
        try
        {
            getGeneralization1r = (org.andromda.metafacades.uml.GeneralizableElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralization1rPostCondition();
        return getGeneralization1r;
    }

    protected abstract java.lang.Object handleGetGeneralization();

    private void handleGetSpecializations6rPreCondition()
    {
    }

    private void handleGetSpecializations6rPostCondition()
    {
    }

    public final java.util.Collection getSpecializations()
    {
        java.util.Collection getSpecializations6r = null;
        handleGetSpecializations6rPreCondition();
        Object result = this.shieldedElements(handleGetSpecializations());
        try
        {
            getSpecializations6r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSpecializations6rPostCondition();
        return getSpecializations6r;
    }

    protected abstract java.util.Collection handleGetSpecializations();

    private void handleGetGeneralizations7rPreCondition()
    {
    }

    private void handleGetGeneralizations7rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizations()
    {
        java.util.Collection getGeneralizations7r = null;
        handleGetGeneralizations7rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizations());
        try
        {
            getGeneralizations7r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizations7rPostCondition();
        return getGeneralizations7r;
    }

    protected abstract java.util.Collection handleGetGeneralizations();

    private void handleGetLinks9rPreCondition()
    {
    }

    private void handleGetLinks9rPostCondition()
    {
    }

    public final java.util.Collection getLinks()
    {
        java.util.Collection getLinks9r = null;
        handleGetLinks9rPreCondition();
        Object result = this.shieldedElements(handleGetLinks());
        try
        {
            getLinks9r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetLinks9rPostCondition();
        return getLinks9r;
    }

    protected abstract java.util.Collection handleGetLinks();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}