//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.GeneralizableElementFacade
 *
 * @see org.andromda.metafacades.uml.GeneralizableElementFacade
 */
public abstract class GeneralizableElementFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.GeneralizableElementFacade
{

    protected org.omg.uml.foundation.core.GeneralizableElement metaObject;

    public GeneralizableElementFacadeLogic(org.omg.uml.foundation.core.GeneralizableElement metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizableElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getAllGeneralizations()
    */
    protected abstract java.util.Collection handleGetAllGeneralizations();

    private void handleGetAllGeneralizations1aPreCondition()
    {
    }

    private void handleGetAllGeneralizations1aPostCondition()
    {
    }

    private java.util.Collection __allGeneralizations1a;
    private boolean __allGeneralizations1aSet = false;

    public final java.util.Collection getAllGeneralizations()
    {
        java.util.Collection allGeneralizations1a = this.__allGeneralizations1a;
        if (!this.__allGeneralizations1aSet)
        {
            handleGetAllGeneralizations1aPreCondition();
            allGeneralizations1a = handleGetAllGeneralizations();
            handleGetAllGeneralizations1aPostCondition();
            this.__allGeneralizations1a = allGeneralizations1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__allGeneralizations1aSet = true;
            }
        }
        return allGeneralizations1a;
    }

    // ------------- associations ------------------

    private void handleGetGeneralization1rPreCondition()
    {
    }

    private void handleGetGeneralization1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization1r = null;
        handleGetGeneralization1rPreCondition();
        Object result = this.shieldedElement(handleGetGeneralization());
        try
        {
            getGeneralization1r = (org.andromda.metafacades.uml.GeneralizableElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralization1rPostCondition();
        return getGeneralization1r;
    }

    protected abstract java.lang.Object handleGetGeneralization();

    private void handleGetGeneralizations5rPreCondition()
    {
    }

    private void handleGetGeneralizations5rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizations()
    {
        java.util.Collection getGeneralizations5r = null;
        handleGetGeneralizations5rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizations());
        try
        {
            getGeneralizations5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizations5rPostCondition();
        return getGeneralizations5r;
    }

    protected abstract java.util.Collection handleGetGeneralizations();

    private void handleGetSpecializations7rPreCondition()
    {
    }

    private void handleGetSpecializations7rPostCondition()
    {
    }

    public final java.util.Collection getSpecializations()
    {
        java.util.Collection getSpecializations7r = null;
        handleGetSpecializations7rPreCondition();
        Object result = this.shieldedElements(handleGetSpecializations());
        try
        {
            getSpecializations7r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSpecializations7rPostCondition();
        return getSpecializations7r;
    }

    protected abstract java.util.Collection handleGetSpecializations();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
