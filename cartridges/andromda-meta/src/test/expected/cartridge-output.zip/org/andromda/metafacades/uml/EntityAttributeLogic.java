//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAttribute
 *
 * @see org.andromda.metafacades.uml.EntityAttribute
 */
public abstract class EntityAttributeLogic
    extends org.andromda.metafacades.uml.AttributeFacadeLogicImpl
    implements org.andromda.metafacades.uml.EntityAttribute
{

    protected Object metaObject;

    public EntityAttributeLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Attribute)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAttribute";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getColumnLength()
    */
    protected abstract java.lang.String handleGetColumnLength();

    private void handleGetColumnLength1aPreCondition()
    {
    }

    private void handleGetColumnLength1aPostCondition()
    {
    }

    private java.lang.String __columnLength1a;
    private boolean __columnLength1aSet = false;

    public final java.lang.String getColumnLength()
    {
        java.lang.String columnLength1a = this.__columnLength1a;
        if (!this.__columnLength1aSet)
        {
            handleGetColumnLength1aPreCondition();
            columnLength1a = handleGetColumnLength();
            handleGetColumnLength1aPostCondition();
            this.__columnLength1a = columnLength1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__columnLength1aSet = true;
            }
        }
        return columnLength1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName2aPreCondition()
    {
    }

    private void handleGetColumnName2aPostCondition()
    {
    }

    private java.lang.String __columnName2a;
    private boolean __columnName2aSet = false;

    public final java.lang.String getColumnName()
    {
        java.lang.String columnName2a = this.__columnName2a;
        if (!this.__columnName2aSet)
        {
            handleGetColumnName2aPreCondition();
            columnName2a = handleGetColumnName();
            handleGetColumnName2aPostCondition();
            this.__columnName2a = columnName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__columnName2aSet = true;
            }
        }
        return columnName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getJdbcMappings()
    */
    protected abstract org.andromda.metafacades.uml.TypeMappings handleGetJdbcMappings();

    private void handleGetJdbcMappings3aPreCondition()
    {
    }

    private void handleGetJdbcMappings3aPostCondition()
    {
    }

    private org.andromda.metafacades.uml.TypeMappings __jdbcMappings3a;
    private boolean __jdbcMappings3aSet = false;

    public final org.andromda.metafacades.uml.TypeMappings getJdbcMappings()
    {
        org.andromda.metafacades.uml.TypeMappings jdbcMappings3a = this.__jdbcMappings3a;
        if (!this.__jdbcMappings3aSet)
        {
            handleGetJdbcMappings3aPreCondition();
            jdbcMappings3a = handleGetJdbcMappings();
            handleGetJdbcMappings3aPostCondition();
            this.__jdbcMappings3a = jdbcMappings3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__jdbcMappings3aSet = true;
            }
        }
        return jdbcMappings3a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getJdbcType()
    */
    protected abstract java.lang.String handleGetJdbcType();

    private void handleGetJdbcType4aPreCondition()
    {
    }

    private void handleGetJdbcType4aPostCondition()
    {
    }

    private java.lang.String __jdbcType4a;
    private boolean __jdbcType4aSet = false;

    public final java.lang.String getJdbcType()
    {
        java.lang.String jdbcType4a = this.__jdbcType4a;
        if (!this.__jdbcType4aSet)
        {
            handleGetJdbcType4aPreCondition();
            jdbcType4a = handleGetJdbcType();
            handleGetJdbcType4aPostCondition();
            this.__jdbcType4a = jdbcType4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__jdbcType4aSet = true;
            }
        }
        return jdbcType4a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getSqlMappings()
    */
    protected abstract org.andromda.metafacades.uml.TypeMappings handleGetSqlMappings();

    private void handleGetSqlMappings5aPreCondition()
    {
    }

    private void handleGetSqlMappings5aPostCondition()
    {
    }

    private org.andromda.metafacades.uml.TypeMappings __sqlMappings5a;
    private boolean __sqlMappings5aSet = false;

    public final org.andromda.metafacades.uml.TypeMappings getSqlMappings()
    {
        org.andromda.metafacades.uml.TypeMappings sqlMappings5a = this.__sqlMappings5a;
        if (!this.__sqlMappings5aSet)
        {
            handleGetSqlMappings5aPreCondition();
            sqlMappings5a = handleGetSqlMappings();
            handleGetSqlMappings5aPostCondition();
            this.__sqlMappings5a = sqlMappings5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__sqlMappings5aSet = true;
            }
        }
        return sqlMappings5a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getSqlType()
    */
    protected abstract java.lang.String handleGetSqlType();

    private void handleGetSqlType6aPreCondition()
    {
    }

    private void handleGetSqlType6aPostCondition()
    {
    }

    private java.lang.String __sqlType6a;
    private boolean __sqlType6aSet = false;

    public final java.lang.String getSqlType()
    {
        java.lang.String sqlType6a = this.__sqlType6a;
        if (!this.__sqlType6aSet)
        {
            handleGetSqlType6aPreCondition();
            sqlType6a = handleGetSqlType();
            handleGetSqlType6aPostCondition();
            this.__sqlType6a = sqlType6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__sqlType6aSet = true;
            }
        }
        return sqlType6a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#isIdentifier()
    */
    protected abstract boolean handleIsIdentifier();

    private void handleIsIdentifier7aPreCondition()
    {
    }

    private void handleIsIdentifier7aPostCondition()
    {
    }

    private boolean __identifier7a;
    private boolean __identifier7aSet = false;

    public final boolean isIdentifier()
    {
        boolean identifier7a = this.__identifier7a;
        if (!this.__identifier7aSet)
        {
            handleIsIdentifier7aPreCondition();
            identifier7a = handleIsIdentifier();
            handleIsIdentifier7aPostCondition();
            this.__identifier7a = identifier7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__identifier7aSet = true;
            }
        }
        return identifier7a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#isUnique()
    */
    protected abstract boolean handleIsUnique();

    private void handleIsUnique8aPreCondition()
    {
    }

    private void handleIsUnique8aPostCondition()
    {
    }

    private boolean __unique8a;
    private boolean __unique8aSet = false;

    public final boolean isUnique()
    {
        boolean unique8a = this.__unique8a;
        if (!this.__unique8aSet)
        {
            handleIsUnique8aPreCondition();
            unique8a = handleIsUnique();
            handleIsUnique8aPostCondition();
            this.__unique8a = unique8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__unique8aSet = true;
            }
        }
        return unique8a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttribute#getColumnIndex()
    */
    protected abstract java.lang.String handleGetColumnIndex();

    private void handleGetColumnIndex9aPreCondition()
    {
    }

    private void handleGetColumnIndex9aPostCondition()
    {
    }

    private java.lang.String __columnIndex9a;
    private boolean __columnIndex9aSet = false;

    public final java.lang.String getColumnIndex()
    {
        java.lang.String columnIndex9a = this.__columnIndex9a;
        if (!this.__columnIndex9aSet)
        {
            handleGetColumnIndex9aPreCondition();
            columnIndex9a = handleGetColumnIndex();
            handleGetColumnIndex9aPostCondition();
            this.__columnIndex9a = columnIndex9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__columnIndex9aSet = true;
            }
        }
        return columnIndex9a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}