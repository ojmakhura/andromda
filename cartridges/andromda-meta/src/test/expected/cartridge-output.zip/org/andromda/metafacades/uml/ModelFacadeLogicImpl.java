package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ModelFacade.
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public class ModelFacadeLogicImpl
       extends ModelFacadeLogic
       implements org.andromda.metafacades.uml.ModelFacade
{
    // ---------------- constructor -------------------------------

    public ModelFacadeLogicImpl (org.omg.uml.UmlPackage metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getRootPackage()
     */
    public java.lang.Object handleGetRootPackage()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllUseCases()
     */
    public java.util.Collection handleGetAllUseCases()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActionStates()
     */
    public java.util.Collection handleGetAllActionStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActors()
     */
    public java.util.Collection handleGetAllActors()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllFinalStates()
     */
    public java.util.Collection handleGetAllFinalStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActivityGraphs()
     */
    public java.util.Collection handleGetAllActivityGraphs()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllTransitions()
     */
    public java.util.Collection handleGetAllTransitions()
    {
        // TODO: add your implementation here!
        return null;
    }

}
