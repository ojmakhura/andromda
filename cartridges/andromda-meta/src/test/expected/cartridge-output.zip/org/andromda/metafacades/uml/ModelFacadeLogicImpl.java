package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ModelFacade.
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public class ModelFacadeLogicImpl
    extends ModelFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ModelFacadeLogicImpl (org.omg.uml.UmlPackage metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseWithTaggedValueOrHyperlink(java.lang.String, java.lang.String)
     */
    protected org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithTaggedValueOrHyperlink()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findClassWithTaggedValueOrHyperlink(java.lang.String, java.lang.String)
     */
    protected org.andromda.metafacades.uml.ClassifierFacade handleFindClassWithTaggedValueOrHyperlink()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findActivityGraphByName(java.lang.String)
     */
    protected org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findActivityGraphByNameAndStereotype(java.lang.String, java.lang.String)
     */
    protected org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByNameAndStereotype()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseByName(java.lang.String)
     */
    protected org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseByName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseWithNameAndStereotype(java.lang.String, java.lang.String)
     */
    protected org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithNameAndStereotype()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade)
     */
    protected java.util.Collection handleFindFinalStatesWithNameOrHyperlink()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade, java.lang.String)
     */
    protected java.util.Collection handleGetAllActionStatesWithStereotype()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getRootPackage()
     */
    protected java.lang.Object handleGetModelFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActors()
     */
    protected java.util.Collection handleGetModelFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllUseCases()
     */
    protected java.util.Collection handleGetModelFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActionStates()
     */
    protected java.util.Collection handleGetModelFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

}