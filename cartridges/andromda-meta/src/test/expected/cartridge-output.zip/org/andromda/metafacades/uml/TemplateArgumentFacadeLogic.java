//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TemplateArgumentFacade
 *
 * @see org.andromda.metafacades.uml.TemplateArgumentFacade
 */
public abstract class TemplateArgumentFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.TemplateArgumentFacade
{

    protected org.omg.uml.foundation.core.TemplateArgument metaObject;

    public TemplateArgumentFacadeLogic(org.omg.uml.foundation.core.TemplateArgument metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TemplateArgumentFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetElement2rPreCondition()
    {
    }

    private void handleGetElement2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getElement2r = null;
        handleGetElement2rPreCondition();
        Object result = this.shieldedElement(handleGetElement());
        try
        {
            getElement2r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetElement2rPostCondition();
        return getElement2r;
    }

    protected abstract java.lang.Object handleGetElement();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}