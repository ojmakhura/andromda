//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AttributeFacade
 *
 * @see org.andromda.metafacades.uml.AttributeFacade
 */
public abstract class AttributeFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.AttributeFacade
{
    protected org.omg.uml.foundation.core.Attribute metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public AttributeFacadeLogic (org.omg.uml.foundation.core.Attribute metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.AttributeFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    public abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName1oPreCondition()
    {
    }

    private void handleGetGetterName1oPostCondition()
    {
    }

    public final java.lang.String getGetterName()
    {
        handleGetGetterName1oPreCondition();
        java.lang.String returnValue = handleGetGetterName();
        handleGetGetterName1oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName2oPreCondition()
    {
    }

    private void handleGetSetterName2oPostCondition()
    {
    }

    public final java.lang.String getSetterName()
    {
        handleGetSetterName2oPreCondition();
        java.lang.String returnValue = handleGetSetterName();
        handleGetSetterName2oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsReadOnly();

    private void handleIsReadOnly3oPreCondition()
    {
    }

    private void handleIsReadOnly3oPostCondition()
    {
    }

    public final boolean isReadOnly()
    {
        handleIsReadOnly3oPreCondition();
        boolean returnValue = handleIsReadOnly();
        handleIsReadOnly3oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetDefaultValue();

    private void handleGetDefaultValue4oPreCondition()
    {
    }

    private void handleGetDefaultValue4oPostCondition()
    {
    }

    public final java.lang.String getDefaultValue()
    {
        handleGetDefaultValue4oPreCondition();
        java.lang.String returnValue = handleGetDefaultValue();
        handleGetDefaultValue4oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsStatic();

    private void handleIsStatic5oPreCondition()
    {
    }

    private void handleIsStatic5oPostCondition()
    {
    }

    public final boolean isStatic()
    {
        handleIsStatic5oPreCondition();
        boolean returnValue = handleIsStatic();
        handleIsStatic5oPostCondition();
        return returnValue;
    }

    public abstract java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow);

    private void handleFindTaggedValue6oPreCondition()
    {
    }

    private void handleFindTaggedValue6oPostCondition()
    {
    }

    public final java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        handleFindTaggedValue6oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(name, follow);
        handleFindTaggedValue6oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsRequired();

    private void handleIsRequired7oPreCondition()
    {
    }

    private void handleIsRequired7oPostCondition()
    {
    }

    public final boolean isRequired()
    {
        handleIsRequired7oPreCondition();
        boolean returnValue = handleIsRequired();
        handleIsRequired7oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsMany();

    private void handleIsMany8oPreCondition()
    {
    }

    private void handleIsMany8oPostCondition()
    {
    }

    public final boolean isMany()
    {
        handleIsMany8oPreCondition();
        boolean returnValue = handleIsMany();
        handleIsMany8oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private org.andromda.metafacades.uml.ClassifierFacade getOwner1r;

    private void handleGetOwner1rPreCondition()
    {
    }

    private void handleGetOwner1rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetOwner();

    public final org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        handleGetOwner1rPreCondition();
        getOwner1r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetOwner());
        handleGetOwner1rPostCondition();
        return getOwner1r;
    }

    private org.andromda.metafacades.uml.ClassifierFacade getType2r;

    private void handleGetType2rPreCondition()
    {
    }

    private void handleGetType2rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetType();

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        handleGetType2rPreCondition();
        getType2r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetType());
        handleGetType2rPostCondition();
        return getType2r;
    }

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"type")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.getClass(),
                        this.getName(),
                        "Each attribute needs a type, you cannot leave the type unspecified."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.getClass(),
                        this.getName(),
                        "Each attribute must have a non-empty name."));
        }
    }
}
