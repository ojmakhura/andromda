//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AttributeFacade
 *
 * @see org.andromda.metafacades.uml.AttributeFacade
 */
public abstract class AttributeFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.AttributeFacade
{

    protected org.omg.uml.foundation.core.Attribute metaObject;

    public AttributeFacadeLogic(org.omg.uml.foundation.core.Attribute metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AttributeFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName1aPreCondition()
    {
    }

    private void handleGetGetterName1aPostCondition()
    {
    }

    private java.lang.String __getterName1a;
    private boolean __getterName1aSet = false;

    public final java.lang.String getGetterName()
    {
        java.lang.String getterName1a = this.__getterName1a;
        if (!this.__getterName1aSet)
        {
            handleGetGetterName1aPreCondition();
            getterName1a = handleGetGetterName();
            handleGetGetterName1aPostCondition();
            this.__getterName1a = getterName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterName1aSet = true;
            }
        }
        return getterName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName2aPreCondition()
    {
    }

    private void handleGetSetterName2aPostCondition()
    {
    }

    private java.lang.String __setterName2a;
    private boolean __setterName2aSet = false;

    public final java.lang.String getSetterName()
    {
        java.lang.String setterName2a = this.__setterName2a;
        if (!this.__setterName2aSet)
        {
            handleGetSetterName2aPreCondition();
            setterName2a = handleGetSetterName();
            handleGetSetterName2aPostCondition();
            this.__setterName2a = setterName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__setterName2aSet = true;
            }
        }
        return setterName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isReadOnly()
    */
    protected abstract boolean handleIsReadOnly();

    private void handleIsReadOnly3aPreCondition()
    {
    }

    private void handleIsReadOnly3aPostCondition()
    {
    }

    private boolean __readOnly3a;
    private boolean __readOnly3aSet = false;

    public final boolean isReadOnly()
    {
        boolean readOnly3a = this.__readOnly3a;
        if (!this.__readOnly3aSet)
        {
            handleIsReadOnly3aPreCondition();
            readOnly3a = handleIsReadOnly();
            handleIsReadOnly3aPostCondition();
            this.__readOnly3a = readOnly3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__readOnly3aSet = true;
            }
        }
        return readOnly3a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getDefaultValue()
    */
    protected abstract java.lang.String handleGetDefaultValue();

    private void handleGetDefaultValue4aPreCondition()
    {
    }

    private void handleGetDefaultValue4aPostCondition()
    {
    }

    private java.lang.String __defaultValue4a;
    private boolean __defaultValue4aSet = false;

    public final java.lang.String getDefaultValue()
    {
        java.lang.String defaultValue4a = this.__defaultValue4a;
        if (!this.__defaultValue4aSet)
        {
            handleGetDefaultValue4aPreCondition();
            defaultValue4a = handleGetDefaultValue();
            handleGetDefaultValue4aPostCondition();
            this.__defaultValue4a = defaultValue4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__defaultValue4aSet = true;
            }
        }
        return defaultValue4a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isStatic()
    */
    protected abstract boolean handleIsStatic();

    private void handleIsStatic5aPreCondition()
    {
    }

    private void handleIsStatic5aPostCondition()
    {
    }

    private boolean __static5a;
    private boolean __static5aSet = false;

    public final boolean isStatic()
    {
        boolean static5a = this.__static5a;
        if (!this.__static5aSet)
        {
            handleIsStatic5aPreCondition();
            static5a = handleIsStatic();
            handleIsStatic5aPostCondition();
            this.__static5a = static5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__static5aSet = true;
            }
        }
        return static5a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired6aPreCondition()
    {
    }

    private void handleIsRequired6aPostCondition()
    {
    }

    private boolean __required6a;
    private boolean __required6aSet = false;

    public final boolean isRequired()
    {
        boolean required6a = this.__required6a;
        if (!this.__required6aSet)
        {
            handleIsRequired6aPreCondition();
            required6a = handleIsRequired();
            handleIsRequired6aPostCondition();
            this.__required6a = required6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__required6aSet = true;
            }
        }
        return required6a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isMany()
    */
    protected abstract boolean handleIsMany();

    private void handleIsMany7aPreCondition()
    {
    }

    private void handleIsMany7aPostCondition()
    {
    }

    private boolean __many7a;
    private boolean __many7aSet = false;

    public final boolean isMany()
    {
        boolean many7a = this.__many7a;
        if (!this.__many7aSet)
        {
            handleIsMany7aPreCondition();
            many7a = handleIsMany();
            handleIsMany7aPostCondition();
            this.__many7a = many7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__many7aSet = true;
            }
        }
        return many7a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isChangeable()
    */
    protected abstract boolean handleIsChangeable();

    private void handleIsChangeable8aPreCondition()
    {
    }

    private void handleIsChangeable8aPostCondition()
    {
    }

    private boolean __changeable8a;
    private boolean __changeable8aSet = false;

    public final boolean isChangeable()
    {
        boolean changeable8a = this.__changeable8a;
        if (!this.__changeable8aSet)
        {
            handleIsChangeable8aPreCondition();
            changeable8a = handleIsChangeable();
            handleIsChangeable8aPostCondition();
            this.__changeable8a = changeable8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__changeable8aSet = true;
            }
        }
        return changeable8a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isAddOnly()
    */
    protected abstract boolean handleIsAddOnly();

    private void handleIsAddOnly9aPreCondition()
    {
    }

    private void handleIsAddOnly9aPostCondition()
    {
    }

    private boolean __addOnly9a;
    private boolean __addOnly9aSet = false;

    public final boolean isAddOnly()
    {
        boolean addOnly9a = this.__addOnly9a;
        if (!this.__addOnly9aSet)
        {
            handleIsAddOnly9aPreCondition();
            addOnly9a = handleIsAddOnly();
            handleIsAddOnly9aPostCondition();
            this.__addOnly9a = addOnly9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__addOnly9aSet = true;
            }
        }
        return addOnly9a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isEnumerationLiteral()
    */
    protected abstract boolean handleIsEnumerationLiteral();

    private void handleIsEnumerationLiteral10aPreCondition()
    {
    }

    private void handleIsEnumerationLiteral10aPostCondition()
    {
    }

    private boolean __enumerationLiteral10a;
    private boolean __enumerationLiteral10aSet = false;

    public final boolean isEnumerationLiteral()
    {
        boolean enumerationLiteral10a = this.__enumerationLiteral10a;
        if (!this.__enumerationLiteral10aSet)
        {
            handleIsEnumerationLiteral10aPreCondition();
            enumerationLiteral10a = handleIsEnumerationLiteral();
            handleIsEnumerationLiteral10aPostCondition();
            this.__enumerationLiteral10a = enumerationLiteral10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enumerationLiteral10aSet = true;
            }
        }
        return enumerationLiteral10a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getEnumerationValue()
    */
    protected abstract java.lang.String handleGetEnumerationValue();

    private void handleGetEnumerationValue11aPreCondition()
    {
    }

    private void handleGetEnumerationValue11aPostCondition()
    {
    }

    private java.lang.String __enumerationValue11a;
    private boolean __enumerationValue11aSet = false;

    public final java.lang.String getEnumerationValue()
    {
        java.lang.String enumerationValue11a = this.__enumerationValue11a;
        if (!this.__enumerationValue11aSet)
        {
            handleGetEnumerationValue11aPreCondition();
            enumerationValue11a = handleGetEnumerationValue();
            handleGetEnumerationValue11aPostCondition();
            this.__enumerationValue11a = enumerationValue11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enumerationValue11aSet = true;
            }
        }
        return enumerationValue11a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getGetterSetterTypeName()
    */
    protected abstract java.lang.String handleGetGetterSetterTypeName();

    private void handleGetGetterSetterTypeName12aPreCondition()
    {
    }

    private void handleGetGetterSetterTypeName12aPostCondition()
    {
    }

    private java.lang.String __getterSetterTypeName12a;
    private boolean __getterSetterTypeName12aSet = false;

    public final java.lang.String getGetterSetterTypeName()
    {
        java.lang.String getterSetterTypeName12a = this.__getterSetterTypeName12a;
        if (!this.__getterSetterTypeName12aSet)
        {
            handleGetGetterSetterTypeName12aPreCondition();
            getterSetterTypeName12a = handleGetGetterSetterTypeName();
            handleGetGetterSetterTypeName12aPostCondition();
            this.__getterSetterTypeName12a = getterSetterTypeName12a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterSetterTypeName12aSet = true;
            }
        }
        return getterSetterTypeName12a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isOrdered()
    */
    protected abstract boolean handleIsOrdered();

    private void handleIsOrdered13aPreCondition()
    {
    }

    private void handleIsOrdered13aPostCondition()
    {
    }

    private boolean __ordered13a;
    private boolean __ordered13aSet = false;

    public final boolean isOrdered()
    {
        boolean ordered13a = this.__ordered13a;
        if (!this.__ordered13aSet)
        {
            handleIsOrdered13aPreCondition();
            ordered13a = handleIsOrdered();
            handleIsOrdered13aPostCondition();
            this.__ordered13a = ordered13a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__ordered13aSet = true;
            }
        }
        return ordered13a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(name, follow);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOwner1rPreCondition()
    {
    }

    private void handleGetOwner1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        org.andromda.metafacades.uml.ClassifierFacade getOwner1r = null;
        handleGetOwner1rPreCondition();
        Object result = this.shieldedElement(handleGetOwner());
        try
        {
            getOwner1r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOwner1rPostCondition();
        return getOwner1r;
    }

    protected abstract java.lang.Object handleGetOwner();

    private void handleGetType2rPreCondition()
    {
    }

    private void handleGetType2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType2r = null;
        handleGetType2rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType2r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType2rPostCondition();
        return getType2r;
    }

    protected abstract java.lang.Object handleGetType();

    private void handleGetEnumeration5rPreCondition()
    {
    }

    private void handleGetEnumeration5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EnumerationFacade getEnumeration()
    {
        org.andromda.metafacades.uml.EnumerationFacade getEnumeration5r = null;
        handleGetEnumeration5rPreCondition();
        Object result = this.shieldedElement(handleGetEnumeration());
        try
        {
            getEnumeration5r = (org.andromda.metafacades.uml.EnumerationFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEnumeration5rPostCondition();
        return getEnumeration5r;
    }

    protected abstract java.lang.Object handleGetEnumeration();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"type"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each attribute needs a type, you cannot leave the type unspecified."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each attribute must have a non-empty name."));
        }
    }
}