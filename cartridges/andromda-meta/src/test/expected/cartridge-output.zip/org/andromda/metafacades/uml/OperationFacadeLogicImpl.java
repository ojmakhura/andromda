package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.OperationFacade.
 *
 * @see org.andromda.metafacades.uml.OperationFacade
 */
public class OperationFacadeLogicImpl
       extends OperationFacadeLogic
       implements org.andromda.metafacades.uml.OperationFacade
{
    // ---------------- constructor -------------------------------

    public OperationFacadeLogicImpl (org.omg.uml.foundation.core.Operation metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getSignature()
     */
    public java.lang.String handleGetSignature() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getCall()
     */
    public java.lang.String handleGetCall() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getTypedArgumentList()
     */
    public java.lang.String handleGetTypedArgumentList() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#isStatic()
     */
    public boolean handleIsStatic() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#isAbstract()
     */
    public boolean handleIsAbstract() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptionList()
     */
    public java.lang.String handleGetExceptionList() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptions()
     */
    public java.util.Collection handleGetExceptions() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#isReturnTypePresent()
     */
    public boolean handleIsReturnTypePresent() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getArguments()
     */
    public java.util.Collection handleGetArguments() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#isExceptionsPresent()
     */
    public boolean handleIsExceptionsPresent() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getArgumentNames()
     */
    public java.lang.String handleGetArgumentNames() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getArgumentTypeNames()
     */
    public java.lang.String handleGetArgumentTypeNames() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#findTaggedValue(java.lang.String, boolean)
     */
    public java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getExceptionList(java.lang.String)
     */
    public java.lang.String handleGetExceptionList(java.lang.String initialExceptions) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getSignature(boolean)
     */
    public java.lang.String handleGetSignature(boolean withArgumentNames) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getOwner()
     */
    public java.lang.Object handleGetOwner()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getParameters()
     */
    public java.util.Collection handleGetParameters()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.OperationFacade#getReturnType()
     */
    public java.lang.Object handleGetReturnType()
    {
        // TODO: add your implementation here!
        return null;
    }

}
