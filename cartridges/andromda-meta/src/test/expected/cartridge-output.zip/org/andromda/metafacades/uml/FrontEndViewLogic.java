//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndView
 *
 * @see org.andromda.metafacades.uml.FrontEndView
 */
public abstract class FrontEndViewLogic
    extends org.andromda.metafacades.uml.FrontEndActionStateLogicImpl
    implements org.andromda.metafacades.uml.FrontEndView
{

    protected Object metaObject;

    public FrontEndViewLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndView";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndView#isFrontEndView()
    */
    protected abstract boolean handleIsFrontEndView();

    private void handleIsFrontEndView1aPreCondition()
    {
    }

    private void handleIsFrontEndView1aPostCondition()
    {
    }

    private boolean __frontEndView1a;
    private boolean __frontEndView1aSet = false;

    public final boolean isFrontEndView()
    {
        boolean frontEndView1a = this.__frontEndView1a;
        if (!this.__frontEndView1aSet)
        {
            handleIsFrontEndView1aPreCondition();
            frontEndView1a = handleIsFrontEndView();
            handleIsFrontEndView1aPostCondition();
            this.__frontEndView1a = frontEndView1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__frontEndView1aSet = true;
            }
        }
        return frontEndView1a;
    }

    // ------------- associations ------------------

    private void handleGetUseCase1rPreCondition()
    {
    }

    private void handleGetUseCase1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndUseCase __getUseCase1r;
    private boolean __getUseCase1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndUseCase getUseCase()
    {
        org.andromda.metafacades.uml.FrontEndUseCase getUseCase1r = this.__getUseCase1r;
        if (!this.__getUseCase1rSet)
        {
            handleGetUseCase1rPreCondition();
            Object result = this.shieldedElement(handleGetUseCase());
            try
            {
                getUseCase1r = (org.andromda.metafacades.uml.FrontEndUseCase)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetUseCase1rPostCondition();
            this.__getUseCase1r = getUseCase1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase1rSet = true;
            }
        }
        return getUseCase1r;
    }

    protected abstract java.lang.Object handleGetUseCase();

    private void handleGetVariables2rPreCondition()
    {
    }

    private void handleGetVariables2rPostCondition()
    {
    }

    private java.util.List __getVariables2r;
    private boolean __getVariables2rSet = false;

    public final java.util.List getVariables()
    {
        java.util.List getVariables2r = this.__getVariables2r;
        if (!this.__getVariables2rSet)
        {
            handleGetVariables2rPreCondition();
            Object result = this.shieldedElements(handleGetVariables());
            try
            {
                getVariables2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetVariables2rPostCondition();
            this.__getVariables2r = getVariables2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getVariables2rSet = true;
            }
        }
        return getVariables2r;
    }

    protected abstract java.util.List handleGetVariables();

    private void handleGetActions3rPreCondition()
    {
    }

    private void handleGetActions3rPostCondition()
    {
    }

    private java.util.List __getActions3r;
    private boolean __getActions3rSet = false;

    public final java.util.List getActions()
    {
        java.util.List getActions3r = this.__getActions3r;
        if (!this.__getActions3rSet)
        {
            handleGetActions3rPreCondition();
            Object result = this.shieldedElements(handleGetActions());
            try
            {
                getActions3r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActions3rPostCondition();
            this.__getActions3r = getActions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions3rSet = true;
            }
        }
        return getActions3r;
    }

    protected abstract java.util.List handleGetActions();

    private void handleGetAllFormFields4rPreCondition()
    {
    }

    private void handleGetAllFormFields4rPostCondition()
    {
    }

    private java.util.List __getAllFormFields4r;
    private boolean __getAllFormFields4rSet = false;

    public final java.util.List getAllFormFields()
    {
        java.util.List getAllFormFields4r = this.__getAllFormFields4r;
        if (!this.__getAllFormFields4rSet)
        {
            handleGetAllFormFields4rPreCondition();
            Object result = this.shieldedElements(handleGetAllFormFields());
            try
            {
                getAllFormFields4r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAllFormFields4rPostCondition();
            this.__getAllFormFields4r = getAllFormFields4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllFormFields4rSet = true;
            }
        }
        return getAllFormFields4r;
    }

    protected abstract java.util.List handleGetAllFormFields();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"useCase.views"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each name of a view action state must be unique in the namespace of a front-end use-case."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"variables"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each view-variable should have a unique name within the context of a view."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLCollections.size(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"controllerCalls")),0));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Views cannot defer to operations. All deferrable events modeled on a front-end view will be ignored."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}