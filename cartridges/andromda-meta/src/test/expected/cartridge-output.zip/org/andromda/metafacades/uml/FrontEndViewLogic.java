//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndView
 *
 * @see org.andromda.metafacades.uml.FrontEndView
 */
public abstract class FrontEndViewLogic
    extends org.andromda.metafacades.uml.FrontEndActionStateLogicImpl
    implements org.andromda.metafacades.uml.FrontEndView
{

    protected Object metaObject;

    public FrontEndViewLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndView";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndView#isFrontEndView()
    */
    protected abstract boolean handleIsFrontEndView();

    private void handleIsFrontEndView1aPreCondition()
    {
    }

    private void handleIsFrontEndView1aPostCondition()
    {
    }

    private boolean __frontEndView1a;
    private boolean __frontEndView1aSet = false;

    public final boolean isFrontEndView()
    {
        boolean frontEndView1a = this.__frontEndView1a;
        if (!this.__frontEndView1aSet)
        {
            handleIsFrontEndView1aPreCondition();
            frontEndView1a = handleIsFrontEndView();
            handleIsFrontEndView1aPostCondition();
            this.__frontEndView1a = frontEndView1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__frontEndView1aSet = true;
            }
        }
        return frontEndView1a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}