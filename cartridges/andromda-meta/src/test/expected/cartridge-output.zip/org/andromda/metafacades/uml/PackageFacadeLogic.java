//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PackageFacade
 *
 * @see org.andromda.metafacades.uml.PackageFacade
 */
public abstract class PackageFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.PackageFacade
{

    protected org.omg.uml.modelmanagement.UmlPackage metaObject;

    public PackageFacadeLogic (org.omg.uml.modelmanagement.UmlPackage metaObject, String context)
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PackageFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    protected abstract org.andromda.metafacades.uml.ModelElementFacade handleFindModelElement(java.lang.String fullyQualifiedName);

    private void handleFindModelElement1oPreCondition()
    {
    }

    private void handleFindModelElement1oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ModelElementFacade findModelElement(java.lang.String fullyQualifiedName)
    {
        handleFindModelElement1oPreCondition();
        org.andromda.metafacades.uml.ModelElementFacade returnValue = handleFindModelElement(fullyQualifiedName);
        handleFindModelElement1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetClasses2rPreCondition()
    {
    }

    private void handleGetClasses2rPostCondition()
    {
    }

    public final java.util.Collection getClasses()
    {
        java.util.Collection getClasses2r = null;
        handleGetClasses2rPreCondition();
        Object result = this.shieldedElements(handleGetClasses());
        try
        {
            getClasses2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetClasses2rPostCondition();
        return getClasses2r;
    }

    protected abstract java.util.Collection handleGetClasses();

    private void handleGetSubPackages3rPreCondition()
    {
    }

    private void handleGetSubPackages3rPostCondition()
    {
    }

    public final java.util.Collection getSubPackages()
    {
        java.util.Collection getSubPackages3r = null;
        handleGetSubPackages3rPreCondition();
        Object result = this.shieldedElements(handleGetSubPackages());
        try
        {
            getSubPackages3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSubPackages3rPostCondition();
        return getSubPackages3r;
    }

    protected abstract java.util.Collection handleGetSubPackages();

    private void handleGetModelElements5rPreCondition()
    {
    }

    private void handleGetModelElements5rPostCondition()
    {
    }

    public final java.util.Collection getModelElements()
    {
        java.util.Collection getModelElements5r = null;
        handleGetModelElements5rPreCondition();
        Object result = this.shieldedElements(handleGetModelElements());
        try
        {
            getModelElements5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetModelElements5rPostCondition();
        return getModelElements5r;
    }

    protected abstract java.util.Collection handleGetModelElements();

    private void handleGetOwnedElements6rPreCondition()
    {
    }

    private void handleGetOwnedElements6rPostCondition()
    {
    }

    public final java.util.Collection getOwnedElements()
    {
        java.util.Collection getOwnedElements6r = null;
        handleGetOwnedElements6rPreCondition();
        Object result = this.shieldedElements(handleGetOwnedElements());
        try
        {
            getOwnedElements6r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOwnedElements6rPostCondition();
        return getOwnedElements6r;
    }

    protected abstract java.util.Collection handleGetOwnedElements();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
