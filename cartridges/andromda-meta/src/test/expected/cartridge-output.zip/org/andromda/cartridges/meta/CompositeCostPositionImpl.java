// license-header java merge-point
/**
 * This is only generated once by PSMmetaclassImpl.vsl! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

import java.util.Collection;

/**
 * @see CompositeCostPosition
 */
public class CompositeCostPositionImpl
    extends CompositeCostPosition
{
    /**
     * Public default constructor for CompositeCostPositionImpl
     */
    public CompositeCostPositionImpl()
    {
        super();
    }

    /**
     * Public constructor for CompositeCostPositionImpl with 2 required properties.
     * @param nameIn String 
     * @param priceIn double 
     */
    public CompositeCostPositionImpl(String name, double price)
    {
       super(name, price);
    }

    /**
     * Public constructor for CompositeCostPositionImpl with all properties.
     * @param nameIn String 
     * @param priceIn double 
     * @param subPositionsIn Collection<SimpleCostPosition> 
     */
    public CompositeCostPositionImpl(String name, double price, Collection<SimpleCostPosition> subPositions)
    {
        super(name, price, subPositions);
    }

    /**
     * Copy-constructor from other CompositeCostPosition
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public CompositeCostPositionImpl(CompositeCostPosition otherBean)
    {
        this(otherBean.getName(), otherBean.getPrice(), otherBean.getSubPositions());
    }

    /**
     * @see org.andromda.cartridges.meta.CompositeCostPosition#calcTotal()
     */
    public double calcTotal()
    {
        // TODO implement public double calcTotal()
        throw new UnsupportedOperationException("org.andromda.cartridges.meta.CompositeCostPosition.calcTotal() Not implemented!");
    }

}