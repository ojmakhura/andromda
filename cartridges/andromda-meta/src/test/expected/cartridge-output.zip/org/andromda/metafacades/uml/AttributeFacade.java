//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AttributeFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * <p>
    *  Searches the given feature for the specified tag. If the follow
    *  boolean is set to true then the search will continue from the
    *  class attribute to the class itself and then up the class
    *  hiearchy.
    * </p>
    */
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow);

   /**
    * 
    */
    public java.lang.String getDefaultValue();

   /**
    * 
    */
    public java.lang.String getGetterName();

   /**
    * <p>
    *  Gets the classifer who is the owner of the attributes.
    * </p>
    */
    public org.andromda.metafacades.uml.ClassifierFacade getOwner();

   /**
    * 
    */
    public java.lang.String getSetterName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * <p>
    *  Returns true or false if the multiplicity for this attribute is
    *  many.
    * </p>
    */
    public boolean isMany();

   /**
    * 
    */
    public boolean isReadOnly();

   /**
    * <p>
    *  Returns true if this association end is required, false
    *  otherwise.
    * </p>
    */
    public boolean isRequired();

   /**
    * <p>
    *  <p>Returns true/false if the attribute is declared static.</p>
    * </p>
    */
    public boolean isStatic();

}
