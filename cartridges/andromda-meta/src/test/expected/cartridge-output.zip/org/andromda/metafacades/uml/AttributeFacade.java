//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AttributeFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * <p>
    *  Searches the given feature for the specified tag. If the follow
    *  boolean is set to true then the search will continue from the
    *  class attribute to the class itself and then up the class
    *  hiearchy.
    * </p>
    */
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow);

   /**
    * 
    */
    public java.lang.String getDefaultValue();

   /**
    * <p>
    *  If the attribute is an enumeration literal this represents the
    *  owning enumeration. Can be empty.
    * </p>
    */
    public org.andromda.metafacades.uml.EnumerationFacade getEnumeration();

   /**
    * <p>
    *  The value for this attribute if it is an enumeration literal,
    *  null otherwise. The default value is returned as a String if it
    *  has been specified, if it's not specified this attribute's name
    *  is assumed.
    * </p>
    */
    public java.lang.String getEnumerationValue();

   /**
    * 
    */
    public java.lang.String getGetterName();

   /**
    * <p>
    *  Gets the classifer who is the owner of the attributes.
    * </p>
    */
    public org.andromda.metafacades.uml.ClassifierFacade getOwner();

   /**
    * 
    */
    public java.lang.String getSetterName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * <p>
    *  True if this attribute can only be set.
    * </p>
    */
    public boolean isAddOnly();

   /**
    * <p>
    *  True if this attribute is a variable.
    * </p>
    */
    public boolean isChangeable();

   /**
    * <p>
    *  True if this attribute is owned by an enumeration.
    * </p>
    */
    public boolean isEnumerationLiteral();

   /**
    * 
    */
    public boolean isMany();

   /**
    * 
    */
    public boolean isReadOnly();

   /**
    * 
    */
    public boolean isRequired();

   /**
    * 
    */
    public boolean isStatic();

}
