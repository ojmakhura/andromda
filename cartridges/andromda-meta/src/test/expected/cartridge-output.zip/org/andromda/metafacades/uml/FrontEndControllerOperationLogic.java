//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndControllerOperation
 *
 * @see org.andromda.metafacades.uml.FrontEndControllerOperation
 */
public abstract class FrontEndControllerOperationLogic
    extends org.andromda.metafacades.uml.OperationFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndControllerOperation
{

    protected Object metaObject;

    public FrontEndControllerOperationLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Operation)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndControllerOperation";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndControllerOperation#isOwnerIsController()
    */
    protected abstract boolean handleIsOwnerIsController();

    private void handleIsOwnerIsController1aPreCondition()
    {
    }

    private void handleIsOwnerIsController1aPostCondition()
    {
    }

    private boolean __ownerIsController1a;
    private boolean __ownerIsController1aSet = false;

    public final boolean isOwnerIsController()
    {
        boolean ownerIsController1a = this.__ownerIsController1a;
        if (!this.__ownerIsController1aSet)
        {
            handleIsOwnerIsController1aPreCondition();
            ownerIsController1a = handleIsOwnerIsController();
            handleIsOwnerIsController1aPostCondition();
            this.__ownerIsController1a = ownerIsController1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__ownerIsController1aSet = true;
            }
        }
        return ownerIsController1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndControllerOperation#isAllArgumentsHaveFormFields()
    */
    protected abstract boolean handleIsAllArgumentsHaveFormFields();

    private void handleIsAllArgumentsHaveFormFields2aPreCondition()
    {
    }

    private void handleIsAllArgumentsHaveFormFields2aPostCondition()
    {
    }

    private boolean __allArgumentsHaveFormFields2a;
    private boolean __allArgumentsHaveFormFields2aSet = false;

    public final boolean isAllArgumentsHaveFormFields()
    {
        boolean allArgumentsHaveFormFields2a = this.__allArgumentsHaveFormFields2a;
        if (!this.__allArgumentsHaveFormFields2aSet)
        {
            handleIsAllArgumentsHaveFormFields2aPreCondition();
            allArgumentsHaveFormFields2a = handleIsAllArgumentsHaveFormFields();
            handleIsAllArgumentsHaveFormFields2aPostCondition();
            this.__allArgumentsHaveFormFields2a = allArgumentsHaveFormFields2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__allArgumentsHaveFormFields2aSet = true;
            }
        }
        return allArgumentsHaveFormFields2a;
    }

    // ------------- associations ------------------

    private void handleGetFormFields2rPreCondition()
    {
    }

    private void handleGetFormFields2rPostCondition()
    {
    }

    private java.util.List __getFormFields2r;
    private boolean __getFormFields2rSet = false;

    public final java.util.List getFormFields()
    {
        java.util.List getFormFields2r = this.__getFormFields2r;
        if (!this.__getFormFields2rSet)
        {
            handleGetFormFields2rPreCondition();
            Object result = this.shieldedElements(handleGetFormFields());
            try
            {
                getFormFields2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFormFields2rPostCondition();
            this.__getFormFields2r = getFormFields2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFormFields2rSet = true;
            }
        }
        return getFormFields2r;
    }

    protected abstract java.util.List handleGetFormFields();

    private void handleGetDeferringActions3rPreCondition()
    {
    }

    private void handleGetDeferringActions3rPostCondition()
    {
    }

    private java.util.List __getDeferringActions3r;
    private boolean __getDeferringActions3rSet = false;

    public final java.util.List getDeferringActions()
    {
        java.util.List getDeferringActions3r = this.__getDeferringActions3r;
        if (!this.__getDeferringActions3rSet)
        {
            handleGetDeferringActions3rPreCondition();
            Object result = this.shieldedElements(handleGetDeferringActions());
            try
            {
                getDeferringActions3r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDeferringActions3rPostCondition();
            this.__getDeferringActions3r = getDeferringActions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferringActions3rSet = true;
            }
        }
        return getDeferringActions3r;
    }

    protected abstract java.util.List handleGetDeferringActions();

    private void handleGetActivityGraph4rPreCondition()
    {
    }

    private void handleGetActivityGraph4rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndActivityGraph __getActivityGraph4r;
    private boolean __getActivityGraph4rSet = false;

    public final org.andromda.metafacades.uml.FrontEndActivityGraph getActivityGraph()
    {
        org.andromda.metafacades.uml.FrontEndActivityGraph getActivityGraph4r = this.__getActivityGraph4r;
        if (!this.__getActivityGraph4rSet)
        {
            handleGetActivityGraph4rPreCondition();
            Object result = this.shieldedElement(handleGetActivityGraph());
            try
            {
                getActivityGraph4r = (org.andromda.metafacades.uml.FrontEndActivityGraph)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActivityGraph4rPostCondition();
            this.__getActivityGraph4r = getActivityGraph4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActivityGraph4rSet = true;
            }
        }
        return getActivityGraph4r;
    }

    protected abstract java.lang.Object handleGetActivityGraph();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"allArgumentsHaveFormFields")); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "all arguments need an event parameter",
                        "For each controller operation argument there must exist a parameter for each action deferring to that operation. This parameter must carry the same name and must be of the same type."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.notEqual(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name"),org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"owner.useCase.name"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "the operation name may not be the same as the use-case name",
                        "It is not allowed to give a controller operation the same name as the use-case for which it is defined, please either rename your operation or your use-case."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}