//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.Entity
 *
 * @see org.andromda.metafacades.uml.Entity
 */
public abstract class EntityLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.Entity
{

    protected Object metaObject;

    public EntityLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.Entity";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.Entity#getTableName()
    */
    protected abstract java.lang.String handleGetTableName();

    private void handleGetTableName1aPreCondition()
    {
    }

    private void handleGetTableName1aPostCondition()
    {
    }

    private java.lang.String __tableName1a;
    private boolean __tableName1aSet = false;

    public final java.lang.String getTableName()
    {
        java.lang.String tableName1a = this.__tableName1a;
        if (!this.__tableName1aSet)
        {
            handleGetTableName1aPreCondition();
            tableName1a = handleGetTableName();
            handleGetTableName1aPostCondition();
            this.__tableName1a = tableName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__tableName1aSet = true;
            }
        }
        return tableName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#isIdentifiersPresent()
    */
    protected abstract boolean handleIsIdentifiersPresent();

    private void handleIsIdentifiersPresent2aPreCondition()
    {
    }

    private void handleIsIdentifiersPresent2aPostCondition()
    {
    }

    public final boolean isIdentifiersPresent()
    {
        boolean identifiersPresent2a = false;
        handleIsIdentifiersPresent2aPreCondition();
        identifiersPresent2a = handleIsIdentifiersPresent();
        handleIsIdentifiersPresent2aPostCondition();
        return identifiersPresent2a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#getMaxSqlNameLength()
    */
    protected abstract java.lang.Short handleGetMaxSqlNameLength();

    private void handleGetMaxSqlNameLength3aPreCondition()
    {
    }

    private void handleGetMaxSqlNameLength3aPostCondition()
    {
    }

    private java.lang.Short __maxSqlNameLength3a;
    private boolean __maxSqlNameLength3aSet = false;

    public final java.lang.Short getMaxSqlNameLength()
    {
        java.lang.Short maxSqlNameLength3a = this.__maxSqlNameLength3a;
        if (!this.__maxSqlNameLength3aSet)
        {
            handleGetMaxSqlNameLength3aPreCondition();
            maxSqlNameLength3a = handleGetMaxSqlNameLength();
            handleGetMaxSqlNameLength3aPostCondition();
            this.__maxSqlNameLength3a = maxSqlNameLength3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__maxSqlNameLength3aSet = true;
            }
        }
        return maxSqlNameLength3a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#isChild()
    */
    protected abstract boolean handleIsChild();

    private void handleIsChild4aPreCondition()
    {
    }

    private void handleIsChild4aPostCondition()
    {
    }

    private boolean __child4a;
    private boolean __child4aSet = false;

    public final boolean isChild()
    {
        boolean child4a = this.__child4a;
        if (!this.__child4aSet)
        {
            handleIsChild4aPreCondition();
            child4a = handleIsChild();
            handleIsChild4aPostCondition();
            this.__child4a = child4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__child4aSet = true;
            }
        }
        return child4a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#isUsingForeignIdentifier()
    */
    protected abstract boolean handleIsUsingForeignIdentifier();

    private void handleIsUsingForeignIdentifier5aPreCondition()
    {
    }

    private void handleIsUsingForeignIdentifier5aPostCondition()
    {
    }

    public final boolean isUsingForeignIdentifier()
    {
        boolean usingForeignIdentifier5a = false;
        handleIsUsingForeignIdentifier5aPreCondition();
        usingForeignIdentifier5a = handleIsUsingForeignIdentifier();
        handleIsUsingForeignIdentifier5aPostCondition();
        return usingForeignIdentifier5a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#isDynamicIdentifiersPresent()
    */
    protected abstract boolean handleIsDynamicIdentifiersPresent();

    private void handleIsDynamicIdentifiersPresent6aPreCondition()
    {
    }

    private void handleIsDynamicIdentifiersPresent6aPostCondition()
    {
    }

    public final boolean isDynamicIdentifiersPresent()
    {
        boolean dynamicIdentifiersPresent6a = false;
        handleIsDynamicIdentifiersPresent6aPreCondition();
        dynamicIdentifiersPresent6a = handleIsDynamicIdentifiersPresent();
        handleIsDynamicIdentifiersPresent6aPostCondition();
        return dynamicIdentifiersPresent6a;
    }

   /**
    * @see org.andromda.metafacades.uml.Entity#isUsingAssignedIdentifier()
    */
    protected abstract boolean handleIsUsingAssignedIdentifier();

    private void handleIsUsingAssignedIdentifier7aPreCondition()
    {
    }

    private void handleIsUsingAssignedIdentifier7aPostCondition()
    {
    }

    public final boolean isUsingAssignedIdentifier()
    {
        boolean usingAssignedIdentifier7a = false;
        handleIsUsingAssignedIdentifier7aPreCondition();
        usingAssignedIdentifier7a = handleIsUsingAssignedIdentifier();
        handleIsUsingAssignedIdentifier7aPostCondition();
        return usingAssignedIdentifier7a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers);

    private void handleGetOperationCallFromAttributes1oPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes1oPostCondition()
    {
    }

    public java.lang.String getOperationCallFromAttributes(boolean withIdentifiers)
    {
        handleGetOperationCallFromAttributes1oPreCondition();
        java.lang.String returnValue = handleGetOperationCallFromAttributes(withIdentifiers);
        handleGetOperationCallFromAttributes1oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetIdentifiers(boolean follow);

    private void handleGetIdentifiers2oPreCondition()
    {
    }

    private void handleGetIdentifiers2oPostCondition()
    {
    }

    public java.util.Collection getIdentifiers(boolean follow)
    {
        handleGetIdentifiers2oPreCondition();
        java.util.Collection returnValue = handleGetIdentifiers(follow);
        handleGetIdentifiers2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers, boolean follow);

    private void handleGetOperationCallFromAttributes3oPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes3oPostCondition()
    {
    }

    public java.lang.String getOperationCallFromAttributes(boolean withIdentifiers, boolean follow)
    {
        handleGetOperationCallFromAttributes3oPreCondition();
        java.lang.String returnValue = handleGetOperationCallFromAttributes(withIdentifiers, follow);
        handleGetOperationCallFromAttributes3oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetRequiredAttributes(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributes4oPreCondition()
    {
    }

    private void handleGetRequiredAttributes4oPostCondition()
    {
    }

    public java.util.Collection getRequiredAttributes(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributes4oPreCondition();
        java.util.Collection returnValue = handleGetRequiredAttributes(follow, withIdentifiers);
        handleGetRequiredAttributes4oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetRequiredProperties(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredProperties5oPreCondition()
    {
    }

    private void handleGetRequiredProperties5oPostCondition()
    {
    }

    public java.util.Collection getRequiredProperties(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredProperties5oPreCondition();
        java.util.Collection returnValue = handleGetRequiredProperties(follow, withIdentifiers);
        handleGetRequiredProperties5oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetAttributes(boolean follow, boolean withIdentifiers);

    private void handleGetAttributes6oPreCondition()
    {
    }

    private void handleGetAttributes6oPostCondition()
    {
    }

    public java.util.Collection getAttributes(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributes6oPreCondition();
        java.util.Collection returnValue = handleGetAttributes(follow, withIdentifiers);
        handleGetAttributes6oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetAttributeTypeList(boolean follow, boolean withIdentifiers);

    private void handleGetAttributeTypeList7oPreCondition()
    {
    }

    private void handleGetAttributeTypeList7oPostCondition()
    {
    }

    public java.lang.String getAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributeTypeList7oPreCondition();
        java.lang.String returnValue = handleGetAttributeTypeList(follow, withIdentifiers);
        handleGetAttributeTypeList7oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetAttributeNameList(boolean follow, boolean withIdentifiers);

    private void handleGetAttributeNameList8oPreCondition()
    {
    }

    private void handleGetAttributeNameList8oPostCondition()
    {
    }

    public java.lang.String getAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributeNameList8oPreCondition();
        java.lang.String returnValue = handleGetAttributeNameList(follow, withIdentifiers);
        handleGetAttributeNameList8oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredAttributeTypeList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributeTypeList9oPreCondition()
    {
    }

    private void handleGetRequiredAttributeTypeList9oPostCondition()
    {
    }

    public java.lang.String getRequiredAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributeTypeList9oPreCondition();
        java.lang.String returnValue = handleGetRequiredAttributeTypeList(follow, withIdentifiers);
        handleGetRequiredAttributeTypeList9oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredAttributeNameList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributeNameList10oPreCondition()
    {
    }

    private void handleGetRequiredAttributeNameList10oPostCondition()
    {
    }

    public java.lang.String getRequiredAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributeNameList10oPreCondition();
        java.lang.String returnValue = handleGetRequiredAttributeNameList(follow, withIdentifiers);
        handleGetRequiredAttributeNameList10oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetQueryOperations(boolean follow);

    private void handleGetQueryOperations11oPreCondition()
    {
    }

    private void handleGetQueryOperations11oPostCondition()
    {
    }

    public java.util.Collection getQueryOperations(boolean follow)
    {
        handleGetQueryOperations11oPreCondition();
        java.util.Collection returnValue = handleGetQueryOperations(follow);
        handleGetQueryOperations11oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredPropertyNameList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredPropertyNameList12oPreCondition()
    {
    }

    private void handleGetRequiredPropertyNameList12oPostCondition()
    {
    }

    public java.lang.String getRequiredPropertyNameList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredPropertyNameList12oPreCondition();
        java.lang.String returnValue = handleGetRequiredPropertyNameList(follow, withIdentifiers);
        handleGetRequiredPropertyNameList12oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredPropertyTypeList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredPropertyTypeList13oPreCondition()
    {
    }

    private void handleGetRequiredPropertyTypeList13oPostCondition()
    {
    }

    public java.lang.String getRequiredPropertyTypeList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredPropertyTypeList13oPreCondition();
        java.lang.String returnValue = handleGetRequiredPropertyTypeList(follow, withIdentifiers);
        handleGetRequiredPropertyTypeList13oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetEntityReferences1rPreCondition()
    {
    }

    private void handleGetEntityReferences1rPostCondition()
    {
    }

    public final java.util.Collection getEntityReferences()
    {
        java.util.Collection getEntityReferences1r = null;
        handleGetEntityReferences1rPreCondition();
        Object result = this.shieldedElements(handleGetEntityReferences());
        try
        {
            getEntityReferences1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEntityReferences1rPostCondition();
        return getEntityReferences1r;
    }

    protected abstract java.util.Collection handleGetEntityReferences();

    private void handleGetParentEnd2rPreCondition()
    {
    }

    private void handleGetParentEnd2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EntityAssociationEnd getParentEnd()
    {
        org.andromda.metafacades.uml.EntityAssociationEnd getParentEnd2r = null;
        handleGetParentEnd2rPreCondition();
        Object result = this.shieldedElement(handleGetParentEnd());
        try
        {
            getParentEnd2r = (org.andromda.metafacades.uml.EntityAssociationEnd)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetParentEnd2rPostCondition();
        return getParentEnd2r;
    }

    protected abstract java.lang.Object handleGetParentEnd();

    private void handleGetChildEnds3rPreCondition()
    {
    }

    private void handleGetChildEnds3rPostCondition()
    {
    }

    public final java.util.Collection getChildEnds()
    {
        java.util.Collection getChildEnds3r = null;
        handleGetChildEnds3rPreCondition();
        Object result = this.shieldedElements(handleGetChildEnds());
        try
        {
            getChildEnds3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetChildEnds3rPostCondition();
        return getChildEnds3r;
    }

    protected abstract java.util.Collection handleGetChildEnds();

    private void handleGetQueryOperations4rPreCondition()
    {
    }

    private void handleGetQueryOperations4rPostCondition()
    {
    }

    public final java.util.Collection getQueryOperations()
    {
        java.util.Collection getQueryOperations4r = null;
        handleGetQueryOperations4rPreCondition();
        Object result = this.shieldedElements(handleGetQueryOperations());
        try
        {
            getQueryOperations4r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetQueryOperations4rPostCondition();
        return getQueryOperations4r;
    }

    protected abstract java.util.Collection handleGetQueryOperations();

    private void handleGetBusinessOperations5rPreCondition()
    {
    }

    private void handleGetBusinessOperations5rPostCondition()
    {
    }

    public final java.util.Collection getBusinessOperations()
    {
        java.util.Collection getBusinessOperations5r = null;
        handleGetBusinessOperations5rPreCondition();
        Object result = this.shieldedElements(handleGetBusinessOperations());
        try
        {
            getBusinessOperations5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetBusinessOperations5rPostCondition();
        return getBusinessOperations5r;
    }

    protected abstract java.util.Collection handleGetBusinessOperations();

    private void handleGetIdentifiers6rPreCondition()
    {
    }

    private void handleGetIdentifiers6rPostCondition()
    {
    }

    public final java.util.Collection getIdentifiers()
    {
        java.util.Collection getIdentifiers6r = null;
        handleGetIdentifiers6rPreCondition();
        Object result = this.shieldedElements(handleGetIdentifiers());
        try
        {
            getIdentifiers6r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetIdentifiers6rPostCondition();
        return getIdentifiers6r;
    }

    protected abstract java.util.Collection handleGetIdentifiers();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"identifiersPresent"));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each entity must have at least one identifier defined."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"attributes"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"visibility"),"public"))).booleanValue();}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "All attributes on an entity must have a public visibility."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"associationEnds"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"otherEnd.navigable"))).booleanValue()?org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"otherEnd.visibility"),"public"):true))).booleanValue();}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "All navigable connecting association ends must have a public visibility."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization")))).booleanValue()?org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"generalization") instanceof org.andromda.metafacades.uml.Entity:true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "An entity can only generalize another entity."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations")))).booleanValue()?org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"specializations"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(object instanceof org.andromda.metafacades.uml.Entity)).booleanValue();}}):true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "An entity can only specialize another entity."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}