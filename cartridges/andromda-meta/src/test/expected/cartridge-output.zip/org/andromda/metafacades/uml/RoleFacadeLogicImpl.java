package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.RoleFacade.
 *
 * @see org.andromda.metafacades.uml.RoleFacade
 */
public class RoleFacadeLogicImpl
    extends RoleFacadeLogic
{
    // ---------------- constructor -------------------------------

    public RoleFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.RoleFacade#isServiceReferencesPresent()
     */
    protected boolean handleIsServiceReferencesPresent()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.RoleFacade#isServiceOperationReferencesPresent()
     */
    protected boolean handleIsServiceOperationReferencesPresent()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

}
