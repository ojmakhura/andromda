package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.RoleFacade.
 *
 * @see org.andromda.metafacades.uml.RoleFacade
 */
public class RoleFacadeLogicImpl
       extends RoleFacadeLogic
       implements org.andromda.metafacades.uml.RoleFacade
{
    // ---------------- constructor -------------------------------

    public RoleFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
}
