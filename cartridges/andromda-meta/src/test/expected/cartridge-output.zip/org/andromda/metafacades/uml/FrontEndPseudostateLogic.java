//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndPseudostate
 *
 * @see org.andromda.metafacades.uml.FrontEndPseudostate
 */
public abstract class FrontEndPseudostateLogic
    extends org.andromda.metafacades.uml.PseudostateFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndPseudostate
{

    protected Object metaObject;

    public FrontEndPseudostateLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.statemachines.Pseudostate)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndPseudostate";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndPseudostate#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase1aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase1aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase1a;
    private boolean __containedInFrontEndUseCase1aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = this.__containedInFrontEndUseCase1a;
        if (!this.__containedInFrontEndUseCase1aSet)
        {
            handleIsContainedInFrontEndUseCase1aPreCondition();
            containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase1aPostCondition();
            this.__containedInFrontEndUseCase1a = containedInFrontEndUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase1aSet = true;
            }
        }
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private void handleGetContainerActions1rPreCondition()
    {
    }

    private void handleGetContainerActions1rPostCondition()
    {
    }

    private java.util.List __getContainerActions1r;
    private boolean __getContainerActions1rSet = false;

    public final java.util.List getContainerActions()
    {
        java.util.List getContainerActions1r = this.__getContainerActions1r;
        if (!this.__getContainerActions1rSet)
        {
            handleGetContainerActions1rPreCondition();
            Object result = this.shieldedElements(handleGetContainerActions());
            try
            {
                getContainerActions1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetContainerActions1rPostCondition();
            this.__getContainerActions1r = getContainerActions1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getContainerActions1rSet = true;
            }
        }
        return getContainerActions1r;
    }

    protected abstract java.util.List handleGetContainerActions();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}