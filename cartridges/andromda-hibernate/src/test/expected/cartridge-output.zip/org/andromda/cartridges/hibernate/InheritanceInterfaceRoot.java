/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 *
 * No hibernate persistance, inheritance = interface
 *
   *
 * @andromda.hibernate.inheritance    interface
 */
  public interface InheritanceInterfaceRoot {

    // --------------- attributes ---------------------

    /**
     * 
     *
     */
    public float getBaseAttributeI1a();

    public void setBaseAttributeI1a(float baseAttributeI1a);


    /**
     * 
     *
     * identifier attribute skipped.
     */


    /**
     * 
     *
     * identifier attribute skipped.
     */


    /**
     * 
     *
     * identifier attribute skipped.
     */

    // ------------- relations ------------------

      // ---------------- business methods  ----------------------

 
}
