/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type CompositeEntityD.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.CompositeEntityD
 */
public abstract class CompositeEntityDFactory
{
   /**
    * Creates a(n) CompositeEntityD object.
    *
    * @param attributeD1
    * @return CompositeEntityD the created object
    */
    public static CompositeEntityD create (java.lang.String attributeD1)
    {
        CompositeEntityD object = new CompositeEntityDImpl();

        object.setAttributeD1 (attributeD1);

        return object;
    }

    /**
     *
     * Finds CompositeEntityD object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static CompositeEntityD findByPrimaryKey (org.hibernate.Session session, int id)
        throws org.hibernate.HibernateException
    {
        CompositeEntityD object = (CompositeEntityD) session.load(CompositeEntityDImpl.class, new java.lang.Integer(id));
        return object;
    }

}