/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="ENTITY_FOUR"
 * @hibernate.discriminator
 *     column="class"
 *
 */
public abstract class EntityFour
{
    // --------------- attributes ---------------------
    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

    /**
     * 
     *
     * @hibernate.set
     *     lazy="true"
     *     table="ENTITY_FIVES2ENTITY_FOURS"
     *     inverse="true"
     * @hibernate.collection-key
     *     column="ENTITY_FOURS_FK"
     * @hibernate.collection-many-to-many
     *     column="ENTITY_FIVES_FK"
     *     class="org.andromda.cartridges.hibernate.EntityFive"
     */
    public java.util.Collection getEntityFives()
    {
        return this.entityFives;
    }

    public void setEntityFives(java.util.Collection entityFives)
    {
        this.entityFives = entityFives;
    }

    private java.util.Collection entityFives;


    // ---------------- business methods  ----------------------


}
