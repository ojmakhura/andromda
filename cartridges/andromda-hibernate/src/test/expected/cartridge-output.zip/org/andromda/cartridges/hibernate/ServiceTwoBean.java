package org.andromda.cartridges.hibernate;

import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

import org.andromda.persistence.hibernate.HibernateUtils;


/**
 * <p>
 *  Just another service for testing the hibernate cartridge.
 * </p>
 *
 * @ejb.bean
 *        name="ServiceTwo"
 *        type="Stateful"
 *        jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceTwo"
 *        local-jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceTwo/Local"
 *        view-type="both"
 * @ejb.interface
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceTwo"
 *        local-class="org.andromda.cartridges.hibernate.ServiceTwoLocal"
 * @ejb.home
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceTwoHome"
 *        local-class="org.andromda.cartridges.hibernate.ServiceTwoLocalHome"
 * @ejb.util generate="physical"
 */
public abstract class ServiceTwoBean
    implements javax.ejb.SessionBean
{

    // --------------- attributes ---------------------

   protected java.lang.String attributeOne;

   /**
     * 
    */
    public java.lang.String getAttributeOne()
    {
        return attributeOne;
    }

    public void setAttributeOne(java.lang.String newValue)
    {
        attributeOne = newValue;
    }

    // ---------------- business methods  ----------------------
    protected abstract org.andromda.cartridges.hibernate.TestValueObject handleOperationOne (net.sf.hibernate.Session session);

    /**
     * <p>
     *  An operation that IS exposed as a webservice.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public org.andromda.cartridges.hibernate.TestValueObject operationOne()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handleOperationOne(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceTwoBean.operationOne: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceTwoBean.operationOne: " + he.getMessage());
                }
            }
        }
    }

    protected abstract java.lang.String handleOperationTwo (net.sf.hibernate.Session session);

    /**
     * <p>
     *  An operation on the service which is NOT exposed as a
     *  webservice.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public java.lang.String operationTwo()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handleOperationTwo(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceTwoBean.operationTwo: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceTwoBean.operationTwo: " + he.getMessage());
                }
            }
        }
    }

   // ---------------- create methods -------------------------

    public void ejbCreate ()
           throws javax.ejb.CreateException
    {
    }

    public void ejbPostCreate ()
           throws javax.ejb.CreateException
    {
    }

   // ---------------- create methods with separate attributes --------------------

    public void ejbCreate (java.lang.String attributeOne)
           throws javax.ejb.CreateException
    {
        setAttributeOne (attributeOne);
    }

    public void ejbPostCreate (java.lang.String attributeOne)
           throws javax.ejb.CreateException
    {
    }

   // ---------------- Hibernate helpers -------------------------

    protected javax.ejb.SessionContext ctx = null;

    private static SessionFactory sessionFactory = null;

    public void setSessionContext( javax.ejb.SessionContext ctx )
    {
        this.ctx = ctx;
    }

    private SessionFactory getSessionFactory() throws HibernateException, NamingException
    {
        if(this.sessionFactory == null)
        {
            this.sessionFactory = HibernateUtils.getSessionFactory();
        }
        return this.sessionFactory;
    }

    private Session getSession() throws HibernateException, NamingException
    {
        return this.getSessionFactory().openSession();
    }

    // ---------------- accessor methods for (session!) bean references ---------------
}