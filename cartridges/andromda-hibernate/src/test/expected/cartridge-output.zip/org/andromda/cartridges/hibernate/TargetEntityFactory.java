/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type TargetEntity.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.TargetEntity
 */
public abstract class TargetEntityFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) TargetEntity object.
    *
    * @param orderedColumn
    * @return TargetEntity the created object
    */
    public static TargetEntity create (java.lang.String orderedColumn)
    {
        TargetEntity object = new TargetEntityImpl();

        object.setOrderedColumn (orderedColumn);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds TargetEntity object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static TargetEntity findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        TargetEntity object = (TargetEntity) session.load(TargetEntityImpl.class, id);
        return object;
    }

}