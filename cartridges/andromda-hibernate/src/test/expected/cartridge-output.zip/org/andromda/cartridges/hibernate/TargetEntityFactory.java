/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type TargetEntity.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.TargetEntity
 */
public abstract class TargetEntityFactory
{
   /**
    * Creates a(n) TargetEntity object.
    *
    * @param orderedColumn
    * @param idLista
    * @return TargetEntity the created object
    */
    public static TargetEntity create (java.lang.String orderedColumn, int idLista)
    {
        TargetEntity object = new TargetEntityImpl();

        object.setOrderedColumn (orderedColumn);
        object.setIdLista (idLista);

        return object;
    }

    /**
     *
     * Finds TargetEntity object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static TargetEntity findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        TargetEntity object = (TargetEntity) session.load(TargetEntityImpl.class, id);
        return object;
    }

}