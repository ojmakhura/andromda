/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_BUSINESS_METHOD_TE"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="InheritanceBusinessMethodTest"
   *
 */
public abstract class InheritanceBusinessMethodTest
 {

 
    // --------------- attributes ---------------------
    private boolean test;

    /**
     * 
     *
     * @hibernate.property
     *     column="TEST"
     *     type="boolean"
     *
     * @hibernate.column
     *     name="TEST"
     *     sql-type="NUMBER(1)"
     *     not-null="true"
     */
    public boolean isTest()
    {
        return this.test;
    }

    public void setTest(boolean test)
    {
        this.test = test;
    }
     private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }
      // ------------- relations ------------------

     // ---------------- business methods  ----------------------

    /**
     * 
     */
    public abstract boolean realMethod();
    /**
     * 
     */
    public abstract byte abstractMethod();
 
}
