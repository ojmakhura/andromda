/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceInterfaceRoot.
 * Hibernate inheritance interface
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceInterfaceRoot
 */
public abstract class InheritanceInterfaceRootFactory {
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceInterfaceRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceInterfaceRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceInterfaceRoot object = (InheritanceInterfaceRoot) session.load(InheritanceInterfaceRootImpl.class, id);
        return object;
    }

}
