/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.subclass
 *    discriminator-value="InheritanceIfSubclass2Impl"
 */
public class InheritanceIfSubclass2Impl
    extends InheritanceIfSubclass2
{
    // concrete business methods that were declared
    // abstract in class InheritanceIfSubclass2 ...
 }
