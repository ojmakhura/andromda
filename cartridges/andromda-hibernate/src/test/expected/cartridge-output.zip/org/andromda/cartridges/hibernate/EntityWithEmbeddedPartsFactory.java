/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithEmbeddedParts.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithEmbeddedParts
 */
public abstract class EntityWithEmbeddedPartsFactory
{
   /**
    * Creates a(n) EntityWithEmbeddedParts object.
    *
    * @param firstEmbedded
    * @param secondEmbedded
    * @param normalAttr
    * @param thirdEmbedded
    * @return EntityWithEmbeddedParts the created object
    */
    public static EntityWithEmbeddedParts create (TheEmbeddedDataType firstEmbedded, TheEmbeddedDataType secondEmbedded, String normalAttr, TheEmbeddedImmutableType thirdEmbedded)
    {
        EntityWithEmbeddedParts object = new EntityWithEmbeddedPartsImpl();

        object.setFirstEmbedded (firstEmbedded);
        object.setSecondEmbedded (secondEmbedded);
        object.setNormalAttr (normalAttr);
        object.setThirdEmbedded (thirdEmbedded);

        return object;
    }

    /**
     *
     * Finds EntityWithEmbeddedParts object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithEmbeddedParts findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        EntityWithEmbeddedParts object = (EntityWithEmbeddedParts) session.load(EntityWithEmbeddedPartsImpl.class, id);
        return object;
    }

}