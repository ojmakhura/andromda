/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityNine.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityNine
 */
public abstract class EntityNineFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityNine object.
    *
    * @return EntityNine the created object
    */
    public static EntityNine create ()
    {
        EntityNine object = new EntityNineImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityNine object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityNine findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        EntityNine object = (EntityNine) session.load(EntityNineImpl.class, id);
        return object;
    }

}