/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.joined-subclass
 *     table="INHERITANCE_SUBCLASS_SUBCLASS1"
 * @hibernate.joined-subclass-key
 *     column="ID"
 *
  *
 */
public abstract class InheritanceSubclassSubclass1
     extends org.andromda.cartridges.hibernate.InheritanceSubclassRootImpl
   {

  
    // --------------- attributes ---------------------
    private long attributeSSC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_S_S_C1A"
     *     type="long"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_S_S_C1A"
     *     sql-type="NUMBER(19)"
     */
    public long getAttributeSSC1a()
    {
        return this.attributeSSC1a;
    }

    public void setAttributeSSC1a(long attributeSSC1a)
    {
        this.attributeSSC1a = attributeSSC1a;
    }
      // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
