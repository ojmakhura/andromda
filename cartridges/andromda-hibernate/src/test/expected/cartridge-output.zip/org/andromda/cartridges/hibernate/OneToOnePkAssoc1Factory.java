/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type OneToOnePkAssoc1.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.OneToOnePkAssoc1
 */
public abstract class OneToOnePkAssoc1Factory
{
   /**
    * Creates a(n) OneToOnePkAssoc1 object.
    *
    * @return OneToOnePkAssoc1 the created object
    */
    public static OneToOnePkAssoc1 create ()
    {
        OneToOnePkAssoc1 object = new OneToOnePkAssoc1Impl();


        return object;
    }

    /**
     *
     * Finds OneToOnePkAssoc1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static OneToOnePkAssoc1 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        OneToOnePkAssoc1 object = (OneToOnePkAssoc1) session.load(OneToOnePkAssoc1Impl.class, id);
        return object;
    }

}