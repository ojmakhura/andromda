/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AbstractConcreteRoot.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AbstractConcreteRoot
 */
public abstract class AbstractConcreteRootFactory {
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds AbstractConcreteRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AbstractConcreteRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        AbstractConcreteRoot object = (AbstractConcreteRoot) session.load(AbstractConcreteRootImpl.class, id);
        return object;
    }

}