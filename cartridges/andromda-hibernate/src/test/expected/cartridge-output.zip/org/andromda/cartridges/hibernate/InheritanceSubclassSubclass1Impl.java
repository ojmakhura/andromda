/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.joined-subclass
 *     table="INHERITANCE_SUBCLASS_SUBCLASS1"
 * @hibernate.joined-subclass-key
 *     column="ID"
 */
public class InheritanceSubclassSubclass1Impl
    extends InheritanceSubclassSubclass1
{
    // concrete business methods that were declared
    // abstract in class InheritanceSubclassSubclass1 ...
 }
