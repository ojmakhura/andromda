/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.joined-subclass
 *     table="INHERITANCE_IF_SUBCLASS1"
 * @hibernate.joined-subclass-key
 *     column="ID"
 *    
  *
 */
public abstract class InheritanceIfSubclass1
 	extends org.andromda.cartridges.hibernate.InheritanceIfSubclassImpl
   {

  
    // --------------- attributes ---------------------
    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
