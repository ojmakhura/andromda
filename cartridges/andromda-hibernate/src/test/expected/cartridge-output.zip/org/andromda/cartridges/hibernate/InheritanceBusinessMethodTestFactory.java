/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceBusinessMethodTest.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest
 */
public abstract class InheritanceBusinessMethodTestFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceBusinessMethodTest object.
    *
    * @param test
    * @return InheritanceBusinessMethodTest the created object
    */
    public static InheritanceBusinessMethodTest create (boolean test)
    {
        InheritanceBusinessMethodTest object = new InheritanceBusinessMethodTestImpl();

        object.setTest (test);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceBusinessMethodTest object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceBusinessMethodTest findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceBusinessMethodTest object = (InheritanceBusinessMethodTest) session.load(InheritanceBusinessMethodTestImpl.class, id);
        return object;
    }

}
