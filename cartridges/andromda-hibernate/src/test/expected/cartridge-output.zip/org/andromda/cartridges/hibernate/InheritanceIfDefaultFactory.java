/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceIfDefault.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceIfDefault
 */
public abstract class InheritanceIfDefaultFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceIfDefault object.
    *
    * @param attributeISC1a
    * @param baseAttributeI1a
    * @return InheritanceIfDefault the created object
    */
    public static InheritanceIfDefault create (float attributeISC1a, float baseAttributeI1a)
    {
        InheritanceIfDefault object = new InheritanceIfDefaultImpl();

        object.setAttributeISC1a (attributeISC1a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceIfDefault object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceIfDefault findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceIfDefault object = (InheritanceIfDefault) session.load(InheritanceIfDefaultImpl.class, id);
        return object;
    }

}