/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AggregationChild.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AggregationChild
 */
public abstract class AggregationChildFactory
{
   /**
    * Creates a(n) AggregationChild object.
    *
    * @return AggregationChild the created object
    */
    public static AggregationChild create ()
    {
        AggregationChild object = new AggregationChildImpl();


        return object;
    }

    /**
     *
     * Finds AggregationChild object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AggregationChild findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        AggregationChild object = (AggregationChild) session.load(AggregationChildImpl.class, id);
        return object;
    }

}