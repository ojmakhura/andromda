/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_CONCRETE_SUBCLASS1"
 *
  *
 */
public abstract class InheritanceConcreteSubclass1
 	extends org.andromda.cartridges.hibernate.InheritanceConcreteRootImpl
   {

  
    // --------------- attributes ---------------------
    private boolean attributeCCSC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_C_C_S_C1A"
     *     type="boolean"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_C_C_S_C1A"
     *     sql-type="NUMBER(1)"
     */
    public boolean isAttributeCCSC1a()
    {
        return this.attributeCCSC1a;
    }

    public void setAttributeCCSC1a(boolean attributeCCSC1a)
    {
        this.attributeCCSC1a = attributeCCSC1a;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
