/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AssignedIdentifierEntity.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AssignedIdentifierEntity
 */
public abstract class AssignedIdentifierEntityFactory
{
   /**
    * Creates a(n) AssignedIdentifierEntity object.
    *
    * @return AssignedIdentifierEntity the created object
    */
    public static AssignedIdentifierEntity create ()
    {
        AssignedIdentifierEntity object = new AssignedIdentifierEntityImpl();


        return object;
    }

    /**
     *
     * Finds AssignedIdentifierEntity object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AssignedIdentifierEntity findByPrimaryKey (org.hibernate.Session session, java.lang.Long assignedId)
        throws org.hibernate.HibernateException
    {
        AssignedIdentifierEntity object = (AssignedIdentifierEntity) session.load(AssignedIdentifierEntityImpl.class, assignedId);
        return object;
    }

}