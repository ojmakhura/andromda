/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see EntityTwo
 */
public class EntityTwoImpl
    extends EntityTwo
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2047029433980992227L;

    /**
     * @see org.andromda.cartridges.hibernate.EntityTwo#operationOne(String)
     */
    public long operationOne(String paramOne)
        throws TestException
    {
        // @todo implement public long operationOne(String paramOne)
        return 0;
    }

    /**
     * @see org.andromda.cartridges.hibernate.EntityTwo#operationTwo(Long)
     */
    public void operationTwo(Long paramOne)
        throws TestException
    {
        // @todo implement public void operationTwo(Long paramOne)
        throw new UnsupportedOperationException("org.andromda.cartridges.hibernate.EntityTwo.operationTwo(Long paramOne) Not implemented!");
    }

}