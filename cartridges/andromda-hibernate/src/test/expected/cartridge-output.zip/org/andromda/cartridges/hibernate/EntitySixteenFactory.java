/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntitySixteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntitySixteen
 */
public abstract class EntitySixteenFactory
{
   /**
    * Creates a(n) EntitySixteen object.
    *
    * @return EntitySixteen the created object
    */
    public static EntitySixteen create ()
    {
        EntitySixteen object = new EntitySixteenImpl();


        return object;
    }

    /**
     *
     * Finds EntitySixteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static EntitySixteen findByPrimaryKey (Session session, EntitySixteenPK entitySixteenPk)
        throws HibernateException
    {
        EntitySixteen object = (EntitySixteen) session.load(EntitySixteenImpl.class, entitySixteenPk);
        return object;
    }

}