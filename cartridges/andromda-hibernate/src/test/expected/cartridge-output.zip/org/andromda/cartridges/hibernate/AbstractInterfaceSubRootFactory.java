/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AbstractInterfaceSubRoot.
 * The Hibernate <em>interface</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AbstractInterfaceSubRoot
 */
public abstract class AbstractInterfaceSubRootFactory
{
    /**
     *
     * Finds AbstractInterfaceSubRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AbstractInterfaceSubRoot findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        AbstractInterfaceSubRoot object = (AbstractInterfaceSubRoot) session.load(AbstractInterfaceSubRootImpl.class, id);
        return object;
    }

}