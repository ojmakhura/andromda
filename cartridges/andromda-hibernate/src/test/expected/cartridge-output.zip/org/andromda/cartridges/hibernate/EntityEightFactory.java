/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityEight.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityEight
 */
public abstract class EntityEightFactory
{
   /**
    * Creates a(n) EntityEight object.
    *
    * @return EntityEight the created object
    */
    public static EntityEight create ()
    {
        EntityEight object = new EntityEightImpl();


        return object;
    }

    /**
     *
     * Finds EntityEight object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityEight findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityEight object = (EntityEight) session.load(EntityEightImpl.class, id);
        return object;
    }

}