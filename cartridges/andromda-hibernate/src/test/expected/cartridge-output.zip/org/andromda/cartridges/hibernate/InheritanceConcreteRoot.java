/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_CONCRETE_ROOT"
   *
 * @andromda.hibernate.inheritance    concrete
 */
public abstract class InheritanceConcreteRoot
 {

 
    // --------------- attributes ---------------------
    private int baseAttributeCC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="BASE_ATTRIBUTE_C_C1A"
     *     type="int"
     *
     * @hibernate.column
     *     name="BASE_ATTRIBUTE_C_C1A"
     *     sql-type="NUMBER(10)"
     *     not-null="true"
     */
    public int getBaseAttributeCC1a()
    {
        return this.baseAttributeCC1a;
    }

    public void setBaseAttributeCC1a(int baseAttributeCC1a)
    {
        this.baseAttributeCC1a = baseAttributeCC1a;
    }
     private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }
      // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
