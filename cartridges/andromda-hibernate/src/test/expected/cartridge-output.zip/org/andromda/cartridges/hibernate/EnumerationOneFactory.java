/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EnumerationOne.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EnumerationOne
 */
public abstract class EnumerationOneFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EnumerationOne object.
    *
    * @param literal1
    * @param literal2
    * @param literal3
    * @param literal4
    * @param literal5
    * @return EnumerationOne the created object
    */
    public static EnumerationOne create (boolean literal1, java.lang.String literal2, double literal3, int literal4, java.lang.String literal5)
    {
        EnumerationOne object = new EnumerationOneImpl();

        object.setLiteral1 (literal1);
        object.setLiteral2 (literal2);
        object.setLiteral3 (literal3);
        object.setLiteral4 (literal4);
        object.setLiteral5 (literal5);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EnumerationOne object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EnumerationOne findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        EnumerationOne object = (EnumerationOne) session.load(EnumerationOneImpl.class, id);
        return object;
    }

}
