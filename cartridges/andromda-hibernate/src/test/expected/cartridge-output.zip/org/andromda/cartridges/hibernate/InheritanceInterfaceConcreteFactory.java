/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceInterfaceConcrete.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceInterfaceConcrete
 */
public abstract class InheritanceInterfaceConcreteFactory
{
   /**
    * Creates a(n) InheritanceInterfaceConcrete object.
    *
    * @param baseAttributeI1a
    * @return InheritanceInterfaceConcrete the created object
    */
    public static InheritanceInterfaceConcrete create (float baseAttributeI1a)
    {
        InheritanceInterfaceConcrete object = new InheritanceInterfaceConcreteImpl();

        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    /**
     *
     * Finds InheritanceInterfaceConcrete object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceInterfaceConcrete findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        InheritanceInterfaceConcrete object = (InheritanceInterfaceConcrete) session.load(InheritanceInterfaceConcreteImpl.class, id);
        return object;
    }

}