/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityOne.
 * Hibernate inheritance subclass
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityOne
 */
public abstract class EntityOneFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityOne object.
    *
    * @param attributeOne
    * @param attributeTwo
    * @return EntityOne the created object
    */
    public static EntityOne create (java.lang.String attributeOne, int attributeTwo)
    {
        EntityOne object = new EntityOneImpl();

        object.setAttributeOne (attributeOne);
        object.setAttributeTwo (attributeTwo);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityOne object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityOne findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityOne object = (EntityOne) session.load(EntityOneImpl.class, id);
        return object;
    }

    /**
     * <p>
     *  Tests automatic finder generation.
     * </p>
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static java.util.Collection findByAttributeOne(net.sf.hibernate.Session session, java.lang.String attributeOne)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeOne = ?");
        query.setParameter(0, attributeOne);
        return query.list();
    }

    /**
     * 
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static java.util.Collection findByAttributeTwo(net.sf.hibernate.Session session, int attributeTwo)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeTwo = ? ");
        query.setParameter(0, attributeTwo);
        return query.list();
    }

    /**
     * 
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static java.util.Collection findByCollectionOfAttributeTwo(net.sf.hibernate.Session session, java.util.Collection attributeTwos)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeTwos = ?");
        query.setParameterList(0, attributeTwos);
        return query.list();
    }

}