/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import java.util.Collection;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityOne.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityOne
 */
public abstract class EntityOneFactory
{
   /**
    * Creates a(n) EntityOne object.
    *
    * @param attributeOne
    * @param attributeTwo
    * @return EntityOne the created object
    */
    public static EntityOne create (String attributeOne, int attributeTwo)
    {
        EntityOne object = new EntityOneImpl();

        object.setAttributeOne (attributeOne);
        object.setAttributeTwo (attributeTwo);

        return object;
    }

    /**
     *
     * Finds EntityOne object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityOne findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        EntityOne object = (EntityOne) session.load(EntityOneImpl.class, id);
        return object;
    }

    /**
     * <p>
     * Tests automatic finder generation.
     * </p>
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static Collection findByAttributeOne(Session session, String attributeOne)
        throws HibernateException
    {
        Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeOne = ?");
        query.setParameter(0, attributeOne);
        return query.list();
    }

    /**
     * 
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static Collection findByAttributeTwo(Session session, int attributeTwo)
        throws HibernateException
    {
        Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeTwo = ? ");
        query.setParameter(0, attributeTwo);
        return query.list();
    }

    /**
     * 
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static Collection findByCollectionOfAttributeTwo(Session session, Collection attributeTwos)
        throws HibernateException
    {
        Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeTwos = ?");
        query.setParameterList(0, attributeTwos);
        return query.list();
    }

}