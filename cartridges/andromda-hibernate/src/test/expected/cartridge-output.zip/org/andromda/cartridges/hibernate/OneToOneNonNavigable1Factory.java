/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type OneToOneNonNavigable1.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.OneToOneNonNavigable1
 */
public abstract class OneToOneNonNavigable1Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) OneToOneNonNavigable1 object.
    *
    * @return OneToOneNonNavigable1 the created object
    */
    public static OneToOneNonNavigable1 create ()
    {
        OneToOneNonNavigable1 object = new OneToOneNonNavigable1Impl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds OneToOneNonNavigable1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static OneToOneNonNavigable1 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        OneToOneNonNavigable1 object = (OneToOneNonNavigable1) session.load(OneToOneNonNavigable1Impl.class, id);
        return object;
    }

}