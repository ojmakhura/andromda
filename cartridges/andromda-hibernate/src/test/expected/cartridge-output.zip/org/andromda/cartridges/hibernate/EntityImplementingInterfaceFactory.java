/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityImplementingInterface.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityImplementingInterface
 */
public abstract class EntityImplementingInterfaceFactory
{
   /**
    * Creates a(n) EntityImplementingInterface object.
    *
    * @return EntityImplementingInterface the created object
    */
    public static EntityImplementingInterface create ()
    {
        EntityImplementingInterface object = new EntityImplementingInterfaceImpl();


        return object;
    }

    /**
     *
     * Finds EntityImplementingInterface object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityImplementingInterface findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityImplementingInterface object = (EntityImplementingInterface) session.load(EntityImplementingInterfaceImpl.class, id);
        return object;
    }

}