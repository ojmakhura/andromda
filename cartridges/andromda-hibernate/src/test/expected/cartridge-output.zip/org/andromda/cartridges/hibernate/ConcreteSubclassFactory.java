/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type ConcreteSubclass.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.ConcreteSubclass
 */
public abstract class ConcreteSubclassFactory
{
   /**
    * Creates a(n) ConcreteSubclass object.
    *
    * @param concreteSubclassAttributeOne
    * @param abstractConcreteSubrootAttributeOne
    * @param abstractConcreteRootAttributeOne
    * @return ConcreteSubclass the created object
    */
    public static ConcreteSubclass create (boolean concreteSubclassAttributeOne, Long abstractConcreteSubrootAttributeOne, String abstractConcreteRootAttributeOne)
    {
        ConcreteSubclass object = new ConcreteSubclassImpl();

        object.setConcreteSubclassAttributeOne (concreteSubclassAttributeOne);
        object.setAbstractConcreteSubrootAttributeOne (abstractConcreteSubrootAttributeOne);
        object.setAbstractConcreteRootAttributeOne (abstractConcreteRootAttributeOne);

        return object;
    }

    /**
     *
     * Finds ConcreteSubclass object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static ConcreteSubclass findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        ConcreteSubclass object = (ConcreteSubclass) session.load(ConcreteSubclassImpl.class, id);
        return object;
    }

}