/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type BagEntityTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.BagEntityTarget
 */
public abstract class BagEntityTargetFactory
{
   /**
    * Creates a(n) BagEntityTarget object.
    *
    * @return BagEntityTarget the created object
    */
    public static BagEntityTarget create ()
    {
        BagEntityTarget object = new BagEntityTargetImpl();


        return object;
    }

    /**
     *
     * Finds BagEntityTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static BagEntityTarget findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        BagEntityTarget object = (BagEntityTarget) session.load(BagEntityTargetImpl.class, id);
        return object;
    }

}