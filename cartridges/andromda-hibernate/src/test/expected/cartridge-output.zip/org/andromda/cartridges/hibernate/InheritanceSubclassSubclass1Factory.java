/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceSubclassSubclass1.
 * Hibernate inheritance subclass
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceSubclassSubclass1
 */
public abstract class InheritanceSubclassSubclass1Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceSubclassSubclass1 object.
    *
    * @param attributeSSC1a
    * @param baseAttributeSSC1a
    * @return InheritanceSubclassSubclass1 the created object
    */
    public static InheritanceSubclassSubclass1 create (long attributeSSC1a, java.lang.String baseAttributeSSC1a)
    {
        InheritanceSubclassSubclass1 object = new InheritanceSubclassSubclass1Impl();

        object.setAttributeSSC1a (attributeSSC1a);
        object.setBaseAttributeSSC1a (baseAttributeSSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceSubclassSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceSubclassSubclass1 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceSubclassSubclass1 object = (InheritanceSubclassSubclass1) session.load(InheritanceSubclassSubclass1Impl.class, id);
        return object;
    }

}