/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type CompositeEntityB.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.CompositeEntityB
 */
public abstract class CompositeEntityBFactory
{
   /**
    * Creates a(n) CompositeEntityB object.
    *
    * @return CompositeEntityB the created object
    */
    public static CompositeEntityB create ()
    {
        CompositeEntityB object = new CompositeEntityBImpl();


        return object;
    }

    /**
     *
     * Finds CompositeEntityB object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static CompositeEntityB findByPrimaryKey (Session session, CompositeEntityBPK compositeEntityBPk)
        throws HibernateException
    {
        CompositeEntityB object = (CompositeEntityB) session.load(CompositeEntityBImpl.class, compositeEntityBPk);
        return object;
    }

}