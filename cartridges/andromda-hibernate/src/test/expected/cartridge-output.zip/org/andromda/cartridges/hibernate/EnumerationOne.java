/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *      table="ENUMERATION_ONE"
 *      mutable="false"
 */
public class EnumerationOne implements java.io.Serializable
{
    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private org.andromda.cartridges.hibernate.EnumerationOneEnum value;

    /**
     * This value holds the enumeration value for this entity.
     *
     * @hibernate.property
     *     name="value"
     *     column="VALUE"
     *     type="org.andromda.cartridges.hibernate.EnumerationOneEnum"
     *     insert="false"
     *     update="false"
     *     unique="true"
     *
     * @hibernate.column
     *     name="VALUE"
     *     non-null="true"
     */
    public org.andromda.cartridges.hibernate.EnumerationOneEnum getValue()
    {
        return this.value;
    }

    public void setValue(org.andromda.cartridges.hibernate.EnumerationOneEnum value)
    {
        this.value = value;
    }
}
