/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_SUBCLASS_ROOT"
   *
 * @andromda.hibernate.inheritance    subclass
 */
public abstract class InheritanceSubclassRoot
 {

 
    // --------------- attributes ---------------------
    private java.lang.String baseAttributeSSC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="BASE_ATTRIBUTE_S_S_C1A"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="BASE_ATTRIBUTE_S_S_C1A"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getBaseAttributeSSC1a()
    {
        return this.baseAttributeSSC1a;
    }

    public void setBaseAttributeSSC1a(java.lang.String baseAttributeSSC1a)
    {
        this.baseAttributeSSC1a = baseAttributeSSC1a;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
