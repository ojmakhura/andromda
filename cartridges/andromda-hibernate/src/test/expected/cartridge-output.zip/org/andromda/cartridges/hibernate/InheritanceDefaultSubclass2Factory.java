/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceDefaultSubclass2.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceDefaultSubclass2
 */
public abstract class InheritanceDefaultSubclass2Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceDefaultSubclass2 object.
    *
    * @param attributeDSC2a
    * @param baseAttributeDSC1a
    * @return InheritanceDefaultSubclass2 the created object
    */
    public static InheritanceDefaultSubclass2 create (java.lang.Double attributeDSC2a, java.util.Date baseAttributeDSC1a)
    {
        InheritanceDefaultSubclass2 object = new InheritanceDefaultSubclass2Impl();

        object.setAttributeDSC2a (attributeDSC2a);
        object.setBaseAttributeDSC1a (baseAttributeDSC1a);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceDefaultSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceDefaultSubclass2 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceDefaultSubclass2 object = (InheritanceDefaultSubclass2) session.load(InheritanceDefaultSubclass2Impl.class, id);
        return object;
    }

}