/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.subclass
 *    discriminator-value="InheritanceInterfaceSubclass1Impl"
 */
public class InheritanceInterfaceSubclass1Impl
    extends InheritanceInterfaceSubclass1
{
    // concrete business methods that were declared
    // abstract in class InheritanceInterfaceSubclass1 ...
 }
