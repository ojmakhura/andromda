/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 *  Tests the generation with the default identifer (since no
 *  identifier is defined)
 * </p>
 *
 * @hibernate.class
 *     table="ENTITY_ONE"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="EntityOne"
   *
 */
public abstract class EntityOne
 {

 
    // --------------- attributes ---------------------
    private java.lang.String attributeOne;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_ONE"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_ONE"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getAttributeOne()
    {
        return this.attributeOne;
    }

    public void setAttributeOne(java.lang.String attributeOne)
    {
        this.attributeOne = attributeOne;
    }

    private int attributeTwo;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_TWO"
     *     type="int"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_TWO"
     *     sql-type="NUMBER(10)"
     *     not-null="true"
     */
    public int getAttributeTwo()
    {
        return this.attributeTwo;
    }

    public void setAttributeTwo(int attributeTwo)
    {
        this.attributeTwo = attributeTwo;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

    /**
     * 
     *
     * @hibernate.set
     *     role="entityTwos"
     *     lazy="true"
     * @hibernate.collection-key
     *     column="ENTITY_ONE_FK"
     * @hibernate.collection-one-to-many
     *     class="org.andromda.cartridges.hibernate.EntityTwo"
     */
    public java.util.Collection getEntityTwos()
    {
        return this.entityTwos;
    }

    public void setEntityTwos(java.util.Collection entityTwos)
    {
        this.entityTwos = entityTwos;
    }

    private java.util.Collection entityTwos;

     // ---------------- business methods  ----------------------

 
}
