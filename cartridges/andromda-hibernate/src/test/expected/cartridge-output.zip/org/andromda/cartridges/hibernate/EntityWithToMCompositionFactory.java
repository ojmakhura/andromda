/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithToMComposition.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithToMComposition
 */
public abstract class EntityWithToMCompositionFactory
{
   /**
    * Creates a(n) EntityWithToMComposition object.
    *
    * @return EntityWithToMComposition the created object
    */
    public static EntityWithToMComposition create ()
    {
        EntityWithToMComposition object = new EntityWithToMCompositionImpl();


        return object;
    }

    /**
     *
     * Finds EntityWithToMComposition object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithToMComposition findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        EntityWithToMComposition object = (EntityWithToMComposition) session.load(EntityWithToMCompositionImpl.class, id);
        return object;
    }

}