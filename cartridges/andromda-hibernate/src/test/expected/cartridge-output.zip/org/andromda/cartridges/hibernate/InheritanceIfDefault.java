/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *    table="INHERITANCE_IF_DEFAULT"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="InheritanceIfDefault"
 *
  *
 */
public abstract class InheritanceIfDefault
 	implements org.andromda.cartridges.hibernate.InheritanceInterfaceRoot
  {

    // --------------- super attributes ---------------------
    private float baseAttributeI1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="BASE_ATTRIBUTE_I1A"
     *     type="float"
     *
     * @hibernate.column
     *     name="BASE_ATTRIBUTE_I1A"
     *     sql-type="NUMBER(38,7)"
     */
    public float getBaseAttributeI1a()
    {
        return this.baseAttributeI1a;
    }

    public void setBaseAttributeI1a(float baseAttributeI1a)
    {
        this.baseAttributeI1a = baseAttributeI1a;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

  
    // ------------- super relations ------------------

   
    // --------------- attributes ---------------------
    private float attributeISC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_I_S_C1A"
     *     type="float"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_I_S_C1A"
     *     sql-type="NUMBER(38,7)"
     */
    public float getAttributeISC1a()
    {
        return this.attributeISC1a;
    }

    public void setAttributeISC1a(float attributeISC1a)
    {
        this.attributeISC1a = attributeISC1a;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
