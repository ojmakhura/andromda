/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceIfSubclass2.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceIfSubclass2
 */
public abstract class InheritanceIfSubclass2Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceIfSubclass2 object.
    *
    * @param attributeISC2a
    * @param baseAttributeI1a
    * @return InheritanceIfSubclass2 the created object
    */
    public static InheritanceIfSubclass2 create (float attributeISC2a, float baseAttributeI1a)
    {
        InheritanceIfSubclass2 object = new InheritanceIfSubclass2Impl();

        object.setAttributeISC2a (attributeISC2a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceIfSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceIfSubclass2 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceIfSubclass2 object = (InheritanceIfSubclass2) session.load(InheritanceIfSubclass2Impl.class, id);
        return object;
    }

}
