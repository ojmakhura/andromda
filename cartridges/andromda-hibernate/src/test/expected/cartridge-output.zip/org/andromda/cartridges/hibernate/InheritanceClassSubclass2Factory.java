/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import java.util.Date;
import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceClassSubclass2.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceClassSubclass2
 */
public abstract class InheritanceClassSubclass2Factory
{
   /**
    * Creates a(n) InheritanceClassSubclass2 object.
    *
    * @param attributeCSC2a
    * @param baseAttributeCSC1a
    * @return InheritanceClassSubclass2 the created object
    */
    public static InheritanceClassSubclass2 create (Double attributeCSC2a, Date baseAttributeCSC1a)
    {
        InheritanceClassSubclass2 object = new InheritanceClassSubclass2Impl();

        object.setAttributeCSC2a (attributeCSC2a);
        object.setBaseAttributeCSC1a (baseAttributeCSC1a);

        return object;
    }

    /**
     *
     * Finds InheritanceClassSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceClassSubclass2 findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        InheritanceClassSubclass2 object = (InheritanceClassSubclass2) session.load(InheritanceClassSubclass2Impl.class, id);
        return object;
    }

}