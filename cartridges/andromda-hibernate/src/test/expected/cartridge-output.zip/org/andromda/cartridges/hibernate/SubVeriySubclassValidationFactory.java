/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type SubVeriySubclassValidation.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.SubVeriySubclassValidation
 */
public abstract class SubVeriySubclassValidationFactory
{
   /**
    * Creates a(n) SubVeriySubclassValidation object.
    *
    * @return SubVeriySubclassValidation the created object
    */
    public static SubVeriySubclassValidation create ()
    {
        SubVeriySubclassValidation object = new SubVeriySubclassValidationImpl();


        return object;
    }

    /**
     *
     * Finds SubVeriySubclassValidation object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static SubVeriySubclassValidation findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        SubVeriySubclassValidation object = (SubVeriySubclassValidation) session.load(SubVeriySubclassValidationImpl.class, id);
        return object;
    }

}