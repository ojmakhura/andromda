/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntitySix.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntitySix
 */
public abstract class EntitySixFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntitySix object.
    *
    * @return EntitySix the created object
    */
    public static EntitySix create ()
    {
        EntitySix object = new EntitySixImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntitySix object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntitySix findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        EntitySix object = (EntitySix) session.load(EntitySixImpl.class, id);
        return object;
    }

}