/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.class
 *     table="INHERITANCE_CONCRETE_SUBCLASS1"
 */
public class InheritanceConcreteSubclass1Impl
    extends InheritanceConcreteSubclass1
{
    // concrete business methods that were declared
    // abstract in class InheritanceConcreteSubclass1 ...
 }
