/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type VerifyClassValidation.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.VerifyClassValidation
 */
public abstract class VerifyClassValidationFactory
{
   /**
    * Creates a(n) VerifyClassValidation object.
    *
    * @return VerifyClassValidation the created object
    */
    public static VerifyClassValidation create ()
    {
        VerifyClassValidation object = new VerifyClassValidationImpl();


        return object;
    }

    /**
     *
     * Finds VerifyClassValidation object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static VerifyClassValidation findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        VerifyClassValidation object = (VerifyClassValidation) session.load(VerifyClassValidationImpl.class, id);
        return object;
    }

}