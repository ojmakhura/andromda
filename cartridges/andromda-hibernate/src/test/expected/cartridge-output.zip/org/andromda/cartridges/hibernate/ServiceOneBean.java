package org.andromda.cartridges.hibernate;

import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

import org.andromda.persistence.hibernate.HibernateUtils;

import org.andromda.cartridges.hibernate.ServiceTwoHome;

/**
 * <p>
 *  Test generation of a normal EJB service facade for the
 *  hibernate cartridge.
 * </p>
 *
 * @ejb.bean
 *        name="ServiceOne"
 *        type="Stateless"
 *        jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceOne"
 *        local-jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceOne/Local"
 *        view-type="both"
 * @ejb.interface
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceOne"
 *        local-class="org.andromda.cartridges.hibernate.ServiceOneLocal"
 * @ejb.home
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceOneHome"
 *        local-class="org.andromda.cartridges.hibernate.ServiceOneLocalHome"
 * @ejb.util generate="physical"
 * @ejb.ejb-ref
 *        ejb-name="ServiceTwo"
 *        view-type="remote"
 *        ref-name="ejb/ServiceTwoBeanRef"
 */
public abstract class ServiceOneBean
    implements javax.ejb.SessionBean
{

    // ---------------- business methods  ----------------------
    protected abstract void handleOperationWithVoidReturnType (net.sf.hibernate.Session session);

    /**
     * <p>
     *  Tests a void operation
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public void operationWithVoidReturnType()
    {
        Session session = null;
        try
        {
            session = getSession();
            handleOperationWithVoidReturnType(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceOneBean.operationWithVoidReturnType: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceOneBean.operationWithVoidReturnType: " + he.getMessage());
                }
            }
        }
    }

    protected abstract java.lang.String handleOperationWithSimpleReturnType (net.sf.hibernate.Session session);

    /**
     * <p>
     *  Tests an operation with a single return type.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public java.lang.String operationWithSimpleReturnType()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handleOperationWithSimpleReturnType(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceOneBean.operationWithSimpleReturnType: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceOneBean.operationWithSimpleReturnType: " + he.getMessage());
                }
            }
        }
    }

    protected abstract java.util.Collection handleOperationWithComplexReturnType (net.sf.hibernate.Session session);

    /**
     * <p>
     *  Tests generation of a return type for a complex type.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public java.util.Collection operationWithComplexReturnType()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handleOperationWithComplexReturnType(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceOneBean.operationWithComplexReturnType: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceOneBean.operationWithComplexReturnType: " + he.getMessage());
                }
            }
        }
    }

    protected abstract java.lang.String handleSoperationWithSingleArgument (net.sf.hibernate.Session session, java.util.Date argumentOne);

    /**
     * 
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public java.lang.String SoperationWithSingleArgument(java.util.Date argumentOne)
    {
        Session session = null;
        try
        {
            session = getSession();
            return handleSoperationWithSingleArgument(session, argumentOne);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceOneBean.SoperationWithSingleArgument: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceOneBean.SoperationWithSingleArgument: " + he.getMessage());
                }
            }
        }
    }

    protected abstract void handleOperationWithMultipleArguments (net.sf.hibernate.Session session, java.lang.Long firstArgument, java.lang.Boolean secondArgument);

    /**
     * 
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
    {
        Session session = null;
        try
        {
            session = getSession();
            handleOperationWithMultipleArguments(session, firstArgument, secondArgument);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceOneBean.operationWithMultipleArguments: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceOneBean.operationWithMultipleArguments: " + he.getMessage());
                }
            }
        }
    }

   // ---------------- create methods -------------------------

   /**
    * @ejb.create-method
    * @ejb.transaction type="Required"
    */
    public void ejbCreate ()
           throws javax.ejb.CreateException
    {
    }

    public void ejbPostCreate ()
           throws javax.ejb.CreateException
    {
    }

   // ---------------- Hibernate helpers -------------------------

    protected javax.ejb.SessionContext _ctx = null;

    private static SessionFactory _sessionFactory = null;

    public void setSessionContext( javax.ejb.SessionContext ctx )
    {
        _ctx = ctx;
    }

    private SessionFactory getSessionFactory() throws HibernateException, NamingException
    {
        if( _sessionFactory == null )
        {
            _sessionFactory = HibernateUtils.getSessionFactory();
        }
        return _sessionFactory;
    }

    private Session getSession() throws HibernateException, NamingException
    {
        return getSessionFactory().openSession();
    }

    // ---------------- accessor methods for (session!) bean references ---------------
   /**
    * This is to get the reference to the ServiceTwo bean.
    * Obtains local home interface from default initial context
    * @return Local home interface for ServiceTwo. Lookup using bean ref name.
    */
    protected static ServiceTwoHome getServiceTwoHome() throws NamingException
    {
        InitialContext initialContext = new InitialContext();
        try {
            // Local homes shouldn't be narrowed, as there is no RMI involved.
            ServiceTwoHome home = (ServiceTwoHome) initialContext.lookup("java:comp/env/ejb/ServiceTwoBeanRef");
            return home;
        } finally {
            initialContext.close();
        }
    }

}
