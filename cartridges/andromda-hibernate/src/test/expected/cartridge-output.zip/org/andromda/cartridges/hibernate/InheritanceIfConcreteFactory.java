/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceIfConcrete.
 * Hibernate inheritance concrete
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceIfConcrete
 */
public abstract class InheritanceIfConcreteFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceIfConcrete object.
    *
    * @param baseAttributeI1a
    * @return InheritanceIfConcrete the created object
    */
    public static InheritanceIfConcrete create (float baseAttributeI1a)
    {
        InheritanceIfConcrete object = new InheritanceIfConcreteImpl();

        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceIfConcrete object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceIfConcrete findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceIfConcrete object = (InheritanceIfConcrete) session.load(InheritanceIfConcreteImpl.class, id);
        return object;
    }

}
