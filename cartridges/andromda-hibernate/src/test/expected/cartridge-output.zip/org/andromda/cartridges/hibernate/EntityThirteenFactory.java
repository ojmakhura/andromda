/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityThirteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityThirteen
 */
public abstract class EntityThirteenFactory
{
   /**
    * Creates a(n) EntityThirteen object.
    *
    * @return EntityThirteen the created object
    */
    public static EntityThirteen create ()
    {
        EntityThirteen object = new EntityThirteenImpl();


        return object;
    }

    /**
     *
     * Finds EntityThirteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityThirteen findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityThirteen object = (EntityThirteen) session.load(EntityThirteenImpl.class, id);
        return object;
    }

}