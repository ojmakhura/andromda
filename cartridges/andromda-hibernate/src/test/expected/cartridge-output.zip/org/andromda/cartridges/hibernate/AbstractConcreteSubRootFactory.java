/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AbstractConcreteSubRoot.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AbstractConcreteSubRoot
 */
public abstract class AbstractConcreteSubRootFactory
{
    /**
     *
     * Finds AbstractConcreteSubRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AbstractConcreteSubRoot findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        AbstractConcreteSubRoot object = (AbstractConcreteSubRoot) session.load(AbstractConcreteSubRootImpl.class, id);
        return object;
    }

}