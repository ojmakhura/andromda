/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="ENTITY_FIVE"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="EntityFive"
   *
 */
public abstract class EntityFive
 {

 
    // --------------- attributes ---------------------
    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

    /**
     * 
     *
     * @hibernate.set
     *     lazy="true"
     *     table="$associationEnd.association.tableName"
     * @hibernate.collection-key
     *     column="ENTITY_FIVES_FK"
     * @hibernate.collection-many-to-many
     *     column="ENTITY_FOURS_FK"
     *     class="org.andromda.cartridges.hibernate.EntityFour"
     */
    public java.util.Collection getEntityFours()
    {
        return this.entityFours;
    }

    public void setEntityFours(java.util.Collection entityFours)
    {
        this.entityFours = entityFours;
    }

    private java.util.Collection entityFours;

     // ---------------- business methods  ----------------------

 
}
