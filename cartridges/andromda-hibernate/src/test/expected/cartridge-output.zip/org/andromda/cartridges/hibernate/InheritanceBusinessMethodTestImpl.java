/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.subclass
 *    discriminator-value="InheritanceBusinessMethodTestImpl"
 */
public class InheritanceBusinessMethodTestImpl
    extends InheritanceBusinessMethodTest
{
    // concrete business methods that were declared
    // abstract in class InheritanceBusinessMethodTest ...
  /**
   * 
   * @return boolean
   */
    public boolean realMethod()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

   /**
   * 
   * @return byte
   */
    public abstract byte abstractMethod();

  }
