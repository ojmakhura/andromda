/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.subclass
 *    discriminator-value="EntityThreeImpl"
 */
public class EntityThreeImpl
    extends EntityThree
{
    // concrete business methods that were declared
    // abstract in class EntityThree ...
 }
