/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceInterfaceSubclass1.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceInterfaceSubclass1
 */
public abstract class InheritanceInterfaceSubclass1Factory
{
   /**
    * Creates a(n) InheritanceInterfaceSubclass1 object.
    *
    * @param attributeISC2a
    * @param baseAttributeI1a
    * @return InheritanceInterfaceSubclass1 the created object
    */
    public static InheritanceInterfaceSubclass1 create (float attributeISC2a, float baseAttributeI1a)
    {
        InheritanceInterfaceSubclass1 object = new InheritanceInterfaceSubclass1Impl();

        object.setAttributeISC2a (attributeISC2a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    /**
     *
     * Finds InheritanceInterfaceSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceInterfaceSubclass1 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        InheritanceInterfaceSubclass1 object = (InheritanceInterfaceSubclass1) session.load(InheritanceInterfaceSubclass1Impl.class, id);
        return object;
    }

}