/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceClassSubclass1.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceClassSubclass1
 */
public abstract class InheritanceClassSubclass1Factory
{
   /**
    * Creates a(n) InheritanceClassSubclass1 object.
    *
    * @param attributeCSC1a
    * @param baseAttributeCSC1a
    * @return InheritanceClassSubclass1 the created object
    */
    public static InheritanceClassSubclass1 create (java.lang.Double attributeCSC1a, java.util.Date baseAttributeCSC1a)
    {
        InheritanceClassSubclass1 object = new InheritanceClassSubclass1Impl();

        object.setAttributeCSC1a (attributeCSC1a);
        object.setBaseAttributeCSC1a (baseAttributeCSC1a);

        return object;
    }

    /**
     *
     * Finds InheritanceClassSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceClassSubclass1 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        InheritanceClassSubclass1 object = (InheritanceClassSubclass1) session.load(InheritanceClassSubclass1Impl.class, id);
        return object;
    }

}