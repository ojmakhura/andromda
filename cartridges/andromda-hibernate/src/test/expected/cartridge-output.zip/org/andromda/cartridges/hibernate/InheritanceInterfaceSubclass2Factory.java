/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceInterfaceSubclass2.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceInterfaceSubclass2
 */
public abstract class InheritanceInterfaceSubclass2Factory
{
   /**
    * Creates a(n) InheritanceInterfaceSubclass2 object.
    *
    * @param attributeISC2a
    * @param baseAttributeI1a
    * @return InheritanceInterfaceSubclass2 the created object
    */
    public static InheritanceInterfaceSubclass2 create (float attributeISC2a, float baseAttributeI1a)
    {
        InheritanceInterfaceSubclass2 object = new InheritanceInterfaceSubclass2Impl();

        object.setAttributeISC2a (attributeISC2a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    /**
     *
     * Finds InheritanceInterfaceSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceInterfaceSubclass2 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        InheritanceInterfaceSubclass2 object = (InheritanceInterfaceSubclass2) session.load(InheritanceInterfaceSubclass2Impl.class, id);
        return object;
    }

}