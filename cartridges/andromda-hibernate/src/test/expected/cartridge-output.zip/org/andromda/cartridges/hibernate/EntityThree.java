/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="ENTITY_THREE"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="EntityThree"
   *
 */
public abstract class EntityThree
 {

 
    // --------------- attributes ---------------------
    private java.lang.Boolean testAttribute;

    /**
     * 
     *
     * @hibernate.property
     *     column="TEST_ATTRIBUTE"
     *     type="java.lang.Boolean"
     *
     * @hibernate.column
     *     name="TEST_ATTRIBUTE"
     *     sql-type="NUMBER(1)"
     *     not-null="true"
     */
    public java.lang.Boolean isTestAttribute()
    {
        return this.testAttribute;
    }

    public void setTestAttribute(java.lang.Boolean testAttribute)
    {
        this.testAttribute = testAttribute;
    }

    private java.lang.Long testAttributeTwo;

    /**
     * 
     *
     * @hibernate.property
     *     column="TEST_ATTRIBUTE_TWO"
     *     type="java.lang.Long"
     *
     * @hibernate.column
     *     name="TEST_ATTRIBUTE_TWO"
     *     sql-type="NUMBER(19)"
     *     not-null="true"
     */
    public java.lang.Long getTestAttributeTwo()
    {
        return this.testAttributeTwo;
    }

    public void setTestAttributeTwo(java.lang.Long testAttributeTwo)
    {
        this.testAttributeTwo = testAttributeTwo;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

    /**
     * 
     *
     * @hibernate.set
     *     role="entityTwos"
     *     lazy="true"
     *     inverse="true"
     * @hibernate.collection-key
     *     column="ENTITY_THREE_FK"
     * @hibernate.collection-one-to-many
     *     class="org.andromda.cartridges.hibernate.EntityTwo"
     */
    public java.util.Collection getEntityTwos()
    {
        return this.entityTwos;
    }

    public void setEntityTwos(java.util.Collection entityTwos)
    {
        this.entityTwos = entityTwos;
    }

    private java.util.Collection entityTwos;

     // ---------------- business methods  ----------------------

 
}
