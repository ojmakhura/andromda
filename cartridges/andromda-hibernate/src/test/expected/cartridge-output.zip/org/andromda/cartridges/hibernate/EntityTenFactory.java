/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityTen.
 * Hibernate inheritance subclass
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityTen
 */
public abstract class EntityTenFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityTen object.
    *
    * @return EntityTen the created object
    */
    public static EntityTen create ()
    {
        EntityTen object = new EntityTenImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityTen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityTen findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityTen object = (EntityTen) session.load(EntityTenImpl.class, id);
        return object;
    }

}