/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFourteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityFourteen
 */
public abstract class EntityFourteenFactory
{
   /**
    * Creates a(n) EntityFourteen object.
    *
    * @return EntityFourteen the created object
    */
    public static EntityFourteen create ()
    {
        EntityFourteen object = new EntityFourteenImpl();


        return object;
    }

    /**
     *
     * Finds EntityFourteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static EntityFourteen findByPrimaryKey (org.hibernate.Session session, org.andromda.cartridges.hibernate.EntityFourteenPK entityFourteenPk)
        throws org.hibernate.HibernateException
    {
        EntityFourteen object = (EntityFourteen) session.load(EntityFourteenImpl.class, entityFourteenPk);
        return object;
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static int findAttributeOneSum(org.hibernate.Session session)
        throws org.hibernate.HibernateException
    {
        org.hibernate.Query query = session.createQuery("select sum(entityFourteen.one) from EntityFourteen entityFourteen");
        return ((java.lang.Integer)query.uniqueResult()).intValue();
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static org.andromda.cartridges.hibernate.EntityFourteen findEntityFourteenByFive(org.hibernate.Session session)
        throws org.hibernate.HibernateException
    {
        org.hibernate.Query query = session.createQuery("select distinct(entityFourteen.one) from EntityFourteenImp entityFourteen");
        return (org.andromda.cartridges.hibernate.EntityFourteen)query.uniqueResult();
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static java.util.Collection findByPositionalParameter(org.hibernate.Session session, java.lang.String six)
        throws org.hibernate.HibernateException
    {
        org.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityFourteen as entityFourteen where entityFourteen.six = ?");
        query.setParameter(0, six);
        return query.list();
    }

}