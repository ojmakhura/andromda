/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import java.util.Collection;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFourteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see EntityFourteen
 */
public abstract class EntityFourteenFactory
{
   /**
    * Creates a(n) EntityFourteen object.
    *
    * @return EntityFourteen the created object
    */
    public static EntityFourteen create ()
    {
        EntityFourteen object = new EntityFourteenImpl();


        return object;
    }

    /**
     *
     * Finds EntityFourteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static EntityFourteen findByPrimaryKey (Session session, EntityFourteenPK entityFourteenPk)
        throws HibernateException
    {
        EntityFourteen object = (EntityFourteen) session.load(EntityFourteenImpl.class, entityFourteenPk);
        return object;
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static int findAttributeOneSum(Session session)
        throws HibernateException
    {
        Query query = session.createQuery("select sum(entityFourteen.one) from EntityFourteen entityFourteen");
        return ((Integer)query.uniqueResult()).intValue();
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static EntityFourteen findEntityFourteenByFive(Session session)
        throws HibernateException
    {
        Query query = session.createQuery("select distinct(entityFourteen.one) from EntityFourteenImp entityFourteen");
        return (EntityFourteen)query.uniqueResult();
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static Collection findByPositionalParameter(Session session, String six)
        throws HibernateException
    {
        Query query = session.createQuery("from EntityFourteen as entityFourteen where entityFourteen.six = ?");
        query.setParameter(0, six);
        return query.list();
    }

}