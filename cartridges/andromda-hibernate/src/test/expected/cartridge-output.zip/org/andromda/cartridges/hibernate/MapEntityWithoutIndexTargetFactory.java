/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type MapEntityWithoutIndexTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.MapEntityWithoutIndexTarget
 */
public abstract class MapEntityWithoutIndexTargetFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) MapEntityWithoutIndexTarget object.
    *
    * @return MapEntityWithoutIndexTarget the created object
    */
    public static MapEntityWithoutIndexTarget create ()
    {
        MapEntityWithoutIndexTarget object = new MapEntityWithoutIndexTargetImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds MapEntityWithoutIndexTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static MapEntityWithoutIndexTarget findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        MapEntityWithoutIndexTarget object = (MapEntityWithoutIndexTarget) session.load(MapEntityWithoutIndexTargetImpl.class, id);
        return object;
    }

}