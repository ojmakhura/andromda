/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceDefaultSubclass1.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceDefaultSubclass1
 */
public abstract class InheritanceDefaultSubclass1Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceDefaultSubclass1 object.
    *
    * @param attributeDSC1a
    * @param baseAttributeDSC1a
    * @return InheritanceDefaultSubclass1 the created object
    */
    public static InheritanceDefaultSubclass1 create (java.lang.Double attributeDSC1a, java.util.Date baseAttributeDSC1a)
    {
        InheritanceDefaultSubclass1 object = new InheritanceDefaultSubclass1Impl();

        object.setAttributeDSC1a (attributeDSC1a);
        object.setBaseAttributeDSC1a (baseAttributeDSC1a);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceDefaultSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceDefaultSubclass1 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceDefaultSubclass1 object = (InheritanceDefaultSubclass1) session.load(InheritanceDefaultSubclass1Impl.class, id);
        return object;
    }

}