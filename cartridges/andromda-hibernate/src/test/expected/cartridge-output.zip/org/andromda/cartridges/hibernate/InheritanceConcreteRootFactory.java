/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceConcreteRoot.
 * Hibernate inheritance concrete
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceConcreteRoot
 */
public abstract class InheritanceConcreteRootFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceConcreteRoot object.
    *
    * @param baseAttributeCC1a
    * @return InheritanceConcreteRoot the created object
    */
    public static InheritanceConcreteRoot create (int baseAttributeCC1a)
    {
        InheritanceConcreteRoot object = new InheritanceConcreteRootImpl();

        object.setBaseAttributeCC1a (baseAttributeCC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceConcreteRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceConcreteRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceConcreteRoot object = (InheritanceConcreteRoot) session.load(InheritanceConcreteRootImpl.class, id);
        return object;
    }

}
