/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceDefaultRoot.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceDefaultRoot
 */
public abstract class InheritanceDefaultRootFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceDefaultRoot object.
    *
    * @param baseAttributeDSC1a
    * @return InheritanceDefaultRoot the created object
    */
    public static InheritanceDefaultRoot create (java.util.Date baseAttributeDSC1a)
    {
        InheritanceDefaultRoot object = new InheritanceDefaultRootImpl();

        object.setBaseAttributeDSC1a (baseAttributeDSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceDefaultRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceDefaultRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceDefaultRoot object = (InheritanceDefaultRoot) session.load(InheritanceDefaultRootImpl.class, id);
        return object;
    }

}