/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceSubclassRoot.
 * Hibernate inheritance subclass
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceSubclassRoot
 */
public abstract class InheritanceSubclassRootFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceSubclassRoot object.
    *
    * @param baseAttributeSSC1a
    * @return InheritanceSubclassRoot the created object
    */
    public static InheritanceSubclassRoot create (java.lang.String baseAttributeSSC1a)
    {
        InheritanceSubclassRoot object = new InheritanceSubclassRootImpl();

        object.setBaseAttributeSSC1a (baseAttributeSSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceSubclassRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceSubclassRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceSubclassRoot object = (InheritanceSubclassRoot) session.load(InheritanceSubclassRootImpl.class, id);
        return object;
    }

}