/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceSubclassRoot.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceSubclassRoot
 */
public abstract class InheritanceSubclassRootFactory
{
   /**
    * Creates a(n) InheritanceSubclassRoot object.
    *
    * @param baseAttributeSSC1a
    * @return InheritanceSubclassRoot the created object
    */
    public static InheritanceSubclassRoot create (String baseAttributeSSC1a)
    {
        InheritanceSubclassRoot object = new InheritanceSubclassRootImpl();

        object.setBaseAttributeSSC1a (baseAttributeSSC1a);

        return object;
    }

    /**
     *
     * Finds InheritanceSubclassRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceSubclassRoot findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        InheritanceSubclassRoot object = (InheritanceSubclassRoot) session.load(InheritanceSubclassRootImpl.class, id);
        return object;
    }

}