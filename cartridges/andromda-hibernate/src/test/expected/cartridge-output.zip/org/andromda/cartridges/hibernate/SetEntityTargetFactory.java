/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type SetEntityTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.SetEntityTarget
 */
public abstract class SetEntityTargetFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) SetEntityTarget object.
    *
    * @return SetEntityTarget the created object
    */
    public static SetEntityTarget create ()
    {
        SetEntityTarget object = new SetEntityTargetImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds SetEntityTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static SetEntityTarget findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        SetEntityTarget object = (SetEntityTarget) session.load(SetEntityTargetImpl.class, id);
        return object;
    }

}