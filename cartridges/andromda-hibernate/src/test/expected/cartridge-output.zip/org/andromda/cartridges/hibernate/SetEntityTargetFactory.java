/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type SetEntityTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.SetEntityTarget
 */
public abstract class SetEntityTargetFactory
{
   /**
    * Creates a(n) SetEntityTarget object.
    *
    * @return SetEntityTarget the created object
    */
    public static SetEntityTarget create ()
    {
        SetEntityTarget object = new SetEntityTargetImpl();


        return object;
    }

    /**
     *
     * Finds SetEntityTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static SetEntityTarget findByPrimaryKey (Session session, Long id)
        throws HibernateException
    {
        SetEntityTarget object = (SetEntityTarget) session.load(SetEntityTargetImpl.class, id);
        return object;
    }

}