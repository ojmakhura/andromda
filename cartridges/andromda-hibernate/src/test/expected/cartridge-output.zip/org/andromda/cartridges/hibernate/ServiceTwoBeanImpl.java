package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceTwo
 */
public class ServiceTwoBeanImpl
    extends ServiceTwoBean
    implements javax.ejb.SessionBean
{
    protected org.andromda.cartridges.hibernate.TestValueObject handleOperationOne (net.sf.hibernate.Session session)
    {
        //@todo implement public org.andromda.cartridges.hibernate.TestValueObject operationOne()
        return null;
    }

    protected java.lang.String handleOperationTwo (net.sf.hibernate.Session session)
    {
        //@todo implement public java.lang.String operationTwo()
        return null;
    }

}
