/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.hibernate;

import javax.ejb.SessionBean;
import org.hibernate.Session;
/**
 * @see org.andromda.cartridges.hibernate.ServiceTwo
 */
public class ServiceTwoBeanImpl
    extends ServiceTwoBean
    implements SessionBean
{
    protected TestValueObject handleOperationOne (Session session)
    {
        // @todo implement public TestValueObject operationOne()
        return null;
    }

    protected String handleOperationTwo (Session session)
    {
        // @todo implement public String operationTwo()
        return null;
    }

}