package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceTwo
 */
public class ServiceTwoBeanImpl
    extends ServiceTwoBean
    implements javax.ejb.SessionBean
{
    // concrete business methods that were declared
    // abstract in class ServiceTwoBean ...

    protected org.andromda.cartridges.hibernate.TestValueObject handleOperationOne (net.sf.hibernate.Session session)
    {
        // TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    protected java.lang.String handleOperationTwo (net.sf.hibernate.Session session)
    {
        // TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    // ---------- the usual session bean stuff... ------------

    public void setSessionContext(javax.ejb.SessionContext ctx)
    {
        super.setSessionContext (ctx);
    }

    public void ejbRemove()
    {
    }

    public void ejbPassivate()
    {
    }

    public void ejbActivate()
    {
    }
}
