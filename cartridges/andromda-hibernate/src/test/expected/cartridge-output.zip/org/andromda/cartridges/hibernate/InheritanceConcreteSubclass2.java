/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_CONCRETE_SUBCLASS2"
 *
  *
 */
public abstract class InheritanceConcreteSubclass2
     extends org.andromda.cartridges.hibernate.InheritanceConcreteRootImpl
   {

  
    // --------------- attributes ---------------------
    private double attributeCCSC2a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_C_C_S_C2A"
     *     type="double"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_C_C_S_C2A"
     *     sql-type="NUMBER(38,15)"
     */
    public double getAttributeCCSC2a()
    {
        return this.attributeCCSC2a;
    }

    public void setAttributeCCSC2a(double attributeCCSC2a)
    {
        this.attributeCCSC2a = attributeCCSC2a;
    }
      // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
