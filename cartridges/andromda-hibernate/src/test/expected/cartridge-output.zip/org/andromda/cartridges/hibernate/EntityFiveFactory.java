/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFive.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityFive
 */
public abstract class EntityFiveFactory
{
   /**
    * Creates a(n) EntityFive object.
    *
    * @return EntityFive the created object
    */
    public static EntityFive create ()
    {
        EntityFive object = new EntityFiveImpl();


        return object;
    }

    /**
     *
     * Finds EntityFive object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityFive findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityFive object = (EntityFive) session.load(EntityFiveImpl.class, id);
        return object;
    }

}