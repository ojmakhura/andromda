package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceOne
 */
public class ServiceOneBeanImpl
    extends ServiceOneBean
    implements javax.ejb.SessionBean
{
    // concrete business methods that were declared
    // abstract in class ServiceOneBean ...

    protected void handleOperationWithVoidReturnType (net.sf.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException 
    {
        // TODO: put your implementation here.
    }
    
    protected java.lang.String handleOperationWithSimpleReturnType (net.sf.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected java.util.Collection handleOperationWithComplexReturnType (net.sf.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected java.lang.String handleSoperationWithSingleArgument (net.sf.hibernate.Session session, java.util.Date argumentOne)
        throws org.andromda.cartridges.hibernate.TestException 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected void handleOperationWithMultipleArguments (net.sf.hibernate.Session session, java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws org.andromda.cartridges.hibernate.TestException 
    {
        // TODO: put your implementation here.
    }
    
    // ---------- the usual session bean stuff... ------------

    public void setSessionContext(javax.ejb.SessionContext ctx)
    {
        super.setSessionContext (ctx);
    }

    public void ejbRemove()
    {
    }

    public void ejbPassivate()
    {
    }

    public void ejbActivate()
    {
    }
}
