/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.hibernate;

import java.util.Collection;
import java.util.Date;
import javax.ejb.SessionBean;
import org.hibernate.Session;
/**
 * @see org.andromda.cartridges.hibernate.ServiceOne
 */
public class ServiceOneBeanImpl
    extends ServiceOneBean
    implements SessionBean
{
    protected void handleOperationWithVoidReturnType (Session session)
        throws TestException
    {
        // @todo implement public void operationWithVoidReturnType()
        throw new UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithVoidReturnType() Not implemented!");
    }

    protected String handleOperationWithSimpleReturnType (Session session)
        throws TestException
    {
        // @todo implement public String operationWithSimpleReturnType()
        return null;
    }

    protected Collection handleOperationWithComplexReturnType (Session session)
        throws TestException
    {
        // @todo implement public Collection operationWithComplexReturnType()
        return null;
    }

    protected String handleSoperationWithSingleArgument (Session session, Date argumentOne)
        throws TestException
    {
        // @todo implement public String SoperationWithSingleArgument(Date argumentOne)
        return null;
    }

    protected void handleOperationWithMultipleArguments (Session session, Long firstArgument, Boolean secondArgument)
        throws TestException
    {
        // @todo implement public void operationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throw new UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithMultipleArguments(Long firstArgument, Boolean secondArgument) Not implemented!");
    }

}