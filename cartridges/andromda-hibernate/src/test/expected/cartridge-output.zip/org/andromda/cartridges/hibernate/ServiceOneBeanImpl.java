package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceOne
 */
public class ServiceOneBeanImpl
    extends ServiceOneBean
    implements javax.ejb.SessionBean
{
    protected void handleOperationWithVoidReturnType (net.sf.hibernate.Session session)
    {
        //@todo implement public void operationWithVoidReturnType()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithVoidReturnType() Not implemented!");
    }

    protected java.lang.String handleOperationWithSimpleReturnType (net.sf.hibernate.Session session)
    {
        //@todo implement public java.lang.String operationWithSimpleReturnType()
        return null;
    }

    protected java.util.Collection handleOperationWithComplexReturnType (net.sf.hibernate.Session session)
    {
        //@todo implement public java.util.Collection operationWithComplexReturnType()
        return null;
    }

    protected java.lang.String handleSoperationWithSingleArgument (net.sf.hibernate.Session session, java.util.Date argumentOne)
    {
        //@todo implement public java.lang.String SoperationWithSingleArgument(java.util.Date argumentOne)
        return null;
    }

    protected void handleOperationWithMultipleArguments (net.sf.hibernate.Session session, java.lang.Long firstArgument, java.lang.Boolean secondArgument)
    {
        //@todo implement public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument) Not implemented!");
    }

}