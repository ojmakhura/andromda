/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
//
/**
 * @author GENERATED CODE! Do not modify by hand!
 *
 * TEMPLATE:     ValueObject.vsl in andromda-java-cartridge.
 * MODEL CLASS:  JavaCartridgeTestModel::org.andromda.cartridges.java::RelatedValueObject
 * METAFACADE:   org.andromda.metafacades.uml.ValueObject
 * STEREOTYPE:   ValueObject
 */
package org.andromda.cartridges.java;

import java.io.Serializable;
import java.util.Arrays;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * <p>
 * Related to ValueObject
 * </p>
 */
@XmlRootElement(name = "RelatedValueObject")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelatedValueObject", // namespace="http://java.cartridges.andromda.org/",
  propOrder = {
    "oneAttribute",
    "valueObject",
    "typeSafeEnumeration"
})
public class RelatedValueObject
    implements Serializable, Comparable<RelatedValueObject>
    {
    /** The serial version UID of this class. Needed for serialization. */
    private static final long serialVersionUID = -8329288830171269195L;

    // Class attributes
    /** TODO: Model Documentation for attribute oneAttribute */
    @XmlElement(name = "oneAttribute")
    protected SuperInterface1 oneAttribute;

    // Class associationEnds
    @XmlElement(name="valueObject", required=true)
    protected ValueObject valueObject;
    @XmlElement(name="typeSafeEnumeration")
    protected TypeSafeEnumeration typeSafeEnumeration;

    /** Default Constructor with no properties */
    public RelatedValueObject()
    {
        // Documented empty block - avoid compiler warning - no super constructor
    }

    /**
     * Constructor taking only required properties
     * @param oneAttributeIn SuperInterface1
     * @param valueObjectIn ValueObject
     */
    public RelatedValueObject(final SuperInterface1 oneAttributeIn, final ValueObject valueObjectIn)
    {
        this.oneAttribute = oneAttributeIn;
        this.valueObject = valueObjectIn;
    }

    /**
     * Constructor with all properties
     * @param oneAttributeIn SuperInterface1
     * @param valueObjectIn ValueObject
     * @param typeSafeEnumerationIn TypeSafeEnumeration
     */
    public RelatedValueObject(final SuperInterface1 oneAttributeIn, final ValueObject valueObjectIn, final TypeSafeEnumeration typeSafeEnumerationIn)
    {
        this.oneAttribute = oneAttributeIn;
        this.valueObject = valueObjectIn;
        this.typeSafeEnumeration = typeSafeEnumerationIn;
    }

    /**
     * Copies constructor from other RelatedValueObject
     *
     * @param otherBean Cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public RelatedValueObject(final RelatedValueObject otherBean)
    {
        this.oneAttribute = otherBean.getOneAttribute();
        this.valueObject = otherBean.getValueObject();
        this.typeSafeEnumeration = otherBean.getTypeSafeEnumeration();
    }

    /**
     * Copies all properties from the argument value object into this value object.
     * @param otherBean Cannot be <code>null</code>
     * @return this
     */
    public void copy(final RelatedValueObject otherBean)
    {
        if (null != otherBean)
        {
            this.setOneAttribute(otherBean.getOneAttribute());
            this.setValueObject(otherBean.getValueObject());
            this.setTypeSafeEnumeration(otherBean.getTypeSafeEnumeration());
        }
    }

    /**
     * TODO: Model Documentation for attribute oneAttribute
     * Get the oneAttribute Attribute
     * @return oneAttribute SuperInterface1
     */
    public SuperInterface1 getOneAttribute()
    {
        return this.oneAttribute;
    }

    /**
     * 
     * @param value SuperInterface1
     */
    public void setOneAttribute(final SuperInterface1 value)
    {
        this.oneAttribute = value;
    }

    /**
     * TODO: Model Documentation for association valueObject
     * Get the valueObject Association
     * @return this.valueObject ValueObject
     */
    public ValueObject getValueObject()
    {
        return this.valueObject;
    }

    /**
     * Sets the valueObject
     * @param value ValueObject
     */
    public void setValueObject(ValueObject value)
    {
        this.valueObject = value;
    }

    /**
     * TODO: Model Documentation for association typeSafeEnumeration
     * Get the typeSafeEnumeration Association
     * @return this.typeSafeEnumeration TypeSafeEnumeration
     */
    public TypeSafeEnumeration getTypeSafeEnumeration()
    {
        return this.typeSafeEnumeration;
    }

    /**
     * Sets the typeSafeEnumeration
     * @param value TypeSafeEnumeration
     */
    public void setTypeSafeEnumeration(TypeSafeEnumeration value)
    {
        this.typeSafeEnumeration = value;
    }

    /**
     * @param object to compare this object against
     * @return boolean if equal
     * @see Object#equals(Object)
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object object)
    {
        if (object==null || !(object instanceof RelatedValueObject))
        {
             return false;
        }
        RelatedValueObject rhs = (RelatedValueObject) object;
        return new EqualsBuilder()
            .append(this.getOneAttribute(), rhs.getOneAttribute())
            .append(this.getValueObject(), rhs.getValueObject())
            .append(this.getTypeSafeEnumeration(), rhs.getTypeSafeEnumeration())
            .isEquals();
    }

    /**
     * @param object to compare this object against
     * @return int if equal
     * @see Comparable#compareTo(Object)
     */
    @SuppressWarnings("unchecked")
    public int compareTo(final RelatedValueObject object)
    {
        if (object==null)
        {
            return -1;
        }
        return new CompareToBuilder()
            .append(this.getOneAttribute(), object.getOneAttribute())
            .append(this.getValueObject(), object.getValueObject())
            .append(this.getTypeSafeEnumeration(), object.getTypeSafeEnumeration())
            .toComparison();
    }

    /**
     * @return int hashCode value
     * @see Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1249046965, -82296885)
            .append(this.getOneAttribute())
            .append(this.getValueObject())
            .append(this.getTypeSafeEnumeration())
            .append(this.getValueObject())
            //Commented out to avoid commons-lang-2.4 recursion StackOverflowError: https://issues.apache.org/jira/browse/LANG-456
            //.append(this.getTypeSafeEnumeration())
            .toHashCode();
    }

    /**
     * @return String representation of object
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        return new ToStringBuilder(this)
            .append("oneAttribute", this.getOneAttribute())
            .append("valueObject", this.getValueObject())
            .append("typeSafeEnumeration", this.getTypeSafeEnumeration())
            .toString();
    }

    /**
     * Compares the properties of this instance to the properties of the argument. This method will return
     * {@code false} as soon as it detects that the argument is {@code null} or not of the same type as
     * (or a sub-type of) this instance's type.
     *
     * <p/>For array, collection or map properties the comparison will be done one level deep, in other words:
     * the elements will be compared using the {@code equals()} operation.
     *
     * <p/>Note that two properties will be considered equal when both values are {@code null}.
     *
     * @param thatObject the object containing the properties to compare against this instance
     * @return this method will return {@code true} in case the argument has the same type as this class, or is a
     *      sub-type of this class and all properties as found on this class have equal values when queried on that
     *      argument instance; in all other cases this method will return {@code false}
     */
    @SuppressWarnings("unchecked")
    public boolean equalProperties(final Object thatObject)
    {
        if (thatObject == null || !this.getClass().isAssignableFrom(thatObject.getClass()))
        {
            return false;
        }

        final RelatedValueObject that = (RelatedValueObject)thatObject;

        return
            equal(this.getOneAttribute(), that.getOneAttribute())
            && equal(this.getValueObject(), that.getValueObject())
            && equal(this.getTypeSafeEnumeration(), that.getTypeSafeEnumeration())
        ;
    }

    /**
     * This is a convenient helper method which is able to detect whether or not two values are equal. Two values
     * are equal when they are both {@code null}, are arrays of the same length with equal elements or are
     * equal objects (this includes {@link java.util.Collection} and {@link java.util.Map} instances).
     *
     * <p/>Note that for array, collection or map instances the comparison runs one level deep.
     *
     * @param first the first object to compare, may be {@code null}
     * @param second the second object to compare, may be {@code null}
     * @return this method will return {@code true} in case both objects are equal as explained above;
     *      in all other cases this method will return {@code false}
     */
    protected static boolean equal(final Object first, final Object second)
    {
        final boolean equal;

        if (first == null)
        {
            equal = second == null;
        }
        else if (first.getClass().isArray() && (second != null) && second.getClass().isArray())
        {
            equal = Arrays.equals((Object[])first, (Object[])second);
        }
        else // note that the following also covers java.util.Collection and java.util.Map
        {
            equal = first.equals(second);
        }

        return equal;
    }

    // RelatedValueObject value-object java merge-point
}