/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
//
/**
 * @author Generated on 09/23/2012 21:38:04-0400 Do not modify by hand!
 *
 * TEMPLATE:     ValueObject.vsl in andromda-java-cartridge.
 * MODEL CLASS:  JavaCartridgeTestModel::org.andromda.cartridges.java::TemplateVO
 * STEREOTYPE:   ValueObject
 */
package org.andromda.cartridges.java;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Two template parameters type + name: String string, Integer integer
 * Class template parameters<parameter1, parameter2, etc>
 * @param string String $param.parameter.getterSetterTypeName
 * @param integer Integer $param.parameter.getterSetterTypeName
 */
@XmlRootElement(name = "TemplateVO")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TemplateVO", // namespace="http://java.cartridges.andromda.org/",
  propOrder = {
    "someAttribute",
    "references"
})
public class TemplateVO<string, integer>
    implements Serializable, Comparable<TemplateVO>
{
    /** The serial version UID of this class. Needed for serialization. */
    private static final long serialVersionUID = -8319633474975176002L;

    // Class template parameters

    protected String string;

    /**
     * Get the string Template Parameter
     * @return string String
     */
    public String getString()
    {
        return this.string;
    }

    /**
     * Set the string Template Parameter
     * @param value String
     */
    public void setString(String value)
    {
        this.string = value;
    }

    protected Integer integer;

    /**
     * Get the integer Template Parameter
     * @return integer Integer
     */
    public Integer getInteger()
    {
        return this.integer;
    }

    /**
     * Set the integer Template Parameter
     * @param value Integer
     */
    public void setInteger(Integer value)
    {
        this.integer = value;
    }

    // Class attributes
    /**
     * TODO: Model Documentation for TemplateVO.someAttribute
     */
    @XmlElement(name = "someAttribute")
    protected int someAttribute;
    /**
     * boolean setter for primitive attribute, so we can tell if it's initialized
     */
    @XmlTransient
    protected boolean setSomeAttribute = false;

    // Class associationEnds
    /**
     * Two template parameters type + name: String string, Integer integer
     */
    @XmlElement(name="references")
    protected Collection<TemplateVO<String, Integer>> references;

    /** Default Constructor with no properties */
    public TemplateVO()
    {
        // Documented empty block - avoid compiler warning - no super constructor
    }

    /**
     * Constructor taking only required properties
     * @param someAttributeIn int TODO: Model Documentation for TemplateVO.someAttribute
     */
    public TemplateVO(final int someAttributeIn)
    {
        this.someAttribute = someAttributeIn;
        this.setSomeAttribute = true;
    }

    /**
     * Constructor with all properties
     * @param someAttributeIn int
     * @param referencesIn Collection<TemplateVO<String, Integer>>
     */
    public TemplateVO(final int someAttributeIn, final Collection<TemplateVO<String, Integer>> referencesIn)
    {
        this.someAttribute = someAttributeIn;
        this.setSomeAttribute = true;
        this.references = referencesIn;
    }

    /**
     * Copies constructor from other TemplateVO
     *
     * @param otherBean Cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public TemplateVO(final TemplateVO<?, ?> otherBean)
    {
        this.someAttribute = otherBean.getSomeAttribute();
        this.setSomeAttribute = true;
        this.references = otherBean.getReferences();
    }

    /**
     * Copies all properties from the argument value object into this value object.
     * @param otherBean Cannot be <code>null</code>
     */
    public void copy(final TemplateVO<?, ?> otherBean)
    {
        if (null != otherBean)
        {
            this.setSomeAttribute(otherBean.getSomeAttribute());
            this.setSomeAttribute = true;
            this.setReferences(otherBean.getReferences());
        }
    }

    /**
     * TODO: Model Documentation for TemplateVO.someAttribute
     * Get the someAttribute Attribute
     * @return someAttribute int
     */
    public int getSomeAttribute()
    {
        return this.someAttribute;
    }

    /**
     * TODO: Model Documentation for TemplateVO.someAttribute
     * @param value int
     */
    public void setSomeAttribute(final int value)
    {
        this.someAttribute = value;
        this.setSomeAttribute = true;
    }

    /**
     * Return true if the primitive attribute someAttribute is set, through the setter or constructor
     * @return true if the attribute value has been set
     */
    public boolean isSetSomeAttribute()
    {
        return this.setSomeAttribute;
    }

    /**
     * Two template parameters type + name: String string, Integer integer
     * Get the references Association
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the object.
     * @return this.references Collection<TemplateVO<String, Integer>>
     */
    public Collection<TemplateVO<String, Integer>> getReferences()
    {
        if (this.references == null)
        {
            this.references = new ArrayList<TemplateVO<String, Integer>>();
        }
        return this.references;
    }

    /**
     * Sets the references
     * @param value Collection<TemplateVO<String, Integer>>
     */
    public void setReferences(Collection<TemplateVO<String, Integer>> value)
    {
        this.references = value;
    }

    /**
     * @param object to compare this object against
     * @return boolean if equal
     * @see Object#equals(Object)
     */
    @Override
    public boolean equals(final Object object)
    {
        if (object==null || object.getClass() != this.getClass())
        {
             return false;
        }
        // Check if the same object instance
        if (object==this)
        {
            return true;
        }
        TemplateVO<String, Integer> rhs = (TemplateVO<String, Integer>) object;
        return new EqualsBuilder()
            .append(this.getSomeAttribute(), rhs.getSomeAttribute())
            .append(this.getReferences(), rhs.getReferences())
            .isEquals();
    }

    /**
     * @param object to compare this object against
     * @return int if equal
     * @see Comparable#compareTo(Object)
     */
    public int compareTo(final TemplateVO object)
    {
        if (object==null)
        {
            return -1;
        }
        // Check if the same object instance
        if (object==this)
        {
            return 0;
        }
        return new CompareToBuilder()
            .append(this.getSomeAttribute(), object.getSomeAttribute())
            .append(this.getReferences(), object.getReferences())
            .toComparison();
    }

    /**
     * @return int hashCode value
     * @see Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1249046965, -82296885)
            .append(this.getSomeAttribute())
            //Commented out to avoid commons-lang-2.4 recursion StackOverflowError: https://issues.apache.org/jira/browse/LANG-456
            //.append(this.getReferences())
            .toHashCode();
    }

    /**
     * @return String representation of object
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        return new ToStringBuilder(this)
            .append("someAttribute", this.getSomeAttribute())
            .append("references", this.getReferences())
            .toString();
    }

    /**
     * Compares the properties of this instance to the properties of the argument. This method will return
     * {@code false} as soon as it detects that the argument is {@code null} or not of the same type as
     * (or a sub-type of) this instance's type.
     *
     * <p/>For array, collection or map properties the comparison will be done one level deep, in other words:
     * the elements will be compared using the {@code equals()} operation.
     *
     * <p/>Note that two properties will be considered equal when both values are {@code null}.
     *
     * @param thatObject the object containing the properties to compare against this instance
     * @return this method will return {@code true} in case the argument has the same type as this class, or is a
     *      sub-type of this class and all properties as found on this class have equal values when queried on that
     *      argument instance; in all other cases this method will return {@code false}
     */
    public boolean equalProperties(final Object thatObject)
    {
        if (thatObject == null || !this.getClass().isAssignableFrom(thatObject.getClass()))
        {
            return false;
        }

        final TemplateVO<String, Integer> that = (TemplateVO<String, Integer>)thatObject;

        return
            equal(this.getSomeAttribute(), that.getSomeAttribute())
            && equal(this.getReferences(), that.getReferences())
        ;
    }

    /**
     * This is a convenient helper method which is able to detect whether or not two values are equal. Two values
     * are equal when they are both {@code null}, are arrays of the same length with equal elements or are
     * equal objects (this includes {@link Collection} and {@link java.util.Map} instances).
     *
     * <p/>Note that for array, collection or map instances the comparison runs one level deep.
     *
     * @param first the first object to compare, may be {@code null}
     * @param second the second object to compare, may be {@code null}
     * @return this method will return {@code true} in case both objects are equal as explained above;
     *      in all other cases this method will return {@code false}
     */
    protected static boolean equal(final Object first, final Object second)
    {
        final boolean equal;

        if (first == null)
        {
            equal = (second == null);
        }
        else if (first.getClass().isArray() && (second != null) && second.getClass().isArray())
        {
            equal = Arrays.equals((Object[])first, (Object[])second);
        }
        else // note that the following also covers Collection and java.util.Map
        {
            equal = first.equals(second);
        }

        return equal;
    }

    // TemplateVO<String, Integer> value-object java merge-point
}