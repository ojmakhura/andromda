// license-header java merge-point
package org.andromda.cartridges.jsf.tests.sessionobjects;

/**
 * @see org.andromda.cartridges.jsf.tests.sessionobjects.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2503432956863646565L;
    
    /**
     * @see org.andromda.cartridges.jsf.tests.sessionobjects.Controller#someOperation()
     */
    @Override
    public void someOperation()
    {
    }
    
}