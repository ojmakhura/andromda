package org.andromda.cartridges.jsf.tests.interactionstate;

/**
 * Stores all forward paths available in the use case InterActionState keyed by forward name.
 */
final class InterActionStateForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("page1", "/org/andromda/cartridges/jsf/tests/interactionstate/page1.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}