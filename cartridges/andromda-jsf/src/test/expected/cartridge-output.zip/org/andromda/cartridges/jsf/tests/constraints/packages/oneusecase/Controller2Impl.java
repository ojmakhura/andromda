// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.Controller2
 */
public class Controller2Impl
    extends Controller2
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 7747122272866222526L;
    
}