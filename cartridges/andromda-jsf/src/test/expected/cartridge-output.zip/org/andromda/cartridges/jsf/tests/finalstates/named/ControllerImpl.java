// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.named;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.named.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 7854140775327978481L;

}