package org.andromda.cartridges.jsf.tests.formfields;

/**
 * Provides the ability to populate any view in the FormFields
 */
public final class FormFieldsViewPopulator
{
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateFormAndViewVariables(final javax.faces.context.FacesContext facesContext, Object form)
    {
        try
        {
	        String viewId = getViewId(facesContext);
	        final Class<?> populator = populators.get(viewId);
	        if (populator != null)
	        {
	            final java.lang.reflect.Method method = populator.getMethod(
	                "populateFormAndViewVariables", 
	                new Class[]{javax.faces.context.FacesContext.class, Object.class});
	            method.invoke(populator, new Object[]{facesContext, form});
	       }    
	    }
	    catch (final Throwable throwable)
	    {
	    	throw new RuntimeException(throwable);
	    }
    }
    
    protected static String getViewId(final javax.faces.context.FacesContext facesContext)
    {
        javax.faces.component.UIViewRoot view  = facesContext.getViewRoot();
        return view != null ? view.getViewId() : null;
    }

    /**
     * Stores the view populators by path.
     */
    private static final java.util.Map<String, Class<?>> populators = new java.util.HashMap<String, Class<?>>();
    
    static
    {
        populators.put("/org/andromda/cartridges/jsf/tests/formfields/one.xhtml", org.andromda.cartridges.jsf.tests.formfields.OnePopulator.class);
        populators.put("/org/andromda/cartridges/jsf/tests/formfields/three.xhtml", org.andromda.cartridges.jsf.tests.formfields.ThreePopulator.class);
    }
}