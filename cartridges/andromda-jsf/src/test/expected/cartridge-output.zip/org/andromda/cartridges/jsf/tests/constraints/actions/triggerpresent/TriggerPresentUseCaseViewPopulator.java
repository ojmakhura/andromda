package org.andromda.cartridges.jsf.tests.constraints.actions.triggerpresent;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;

/**
 * Provides the ability to populate any view in the TriggerPresent UseCase
 */
public final class TriggerPresentUseCaseViewPopulator
{
    /**
     * Populates the view using the appropriate view populator.
     */
    public static void populateFormAndViewVariables(final FacesContext facesContext, Object form)
    {
        try
        {
            String viewId = getViewId(facesContext);
            final Class<?> populator = populators.get(viewId);
            if (populator != null)
            {
                final Method method = populator.getMethod(
                    "populateFormAndViewVariables",
                    new Class[]{FacesContext.class, Object.class});
                method.invoke(populator, new Object[]{facesContext, form});
           }
        }
        catch (final Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }

    protected static String getViewId(final FacesContext facesContext)
    {
        UIViewRoot view  = facesContext.getViewRoot();
        return view != null ? view.getViewId() : null;
    }

    /**
     * Stores the view populators by path.
     */
    private static final Map<String, Class<?>> populators = new HashMap<String, Class<?>>();

    static
    {
    }
}