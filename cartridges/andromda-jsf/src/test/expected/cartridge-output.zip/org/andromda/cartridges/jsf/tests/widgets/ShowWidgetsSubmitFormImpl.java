// license-header java merge-point
package org.andromda.cartridges.jsf.tests.widgets;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class ShowWidgetsSubmitFormImpl
    implements Serializable
{
    public ShowWidgetsSubmitFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private String textFieldTest;

    /**
     * 
     */
    public String getTextFieldTest()
    {
        return this.textFieldTest;
    }

    /**
     * Keeps track of whether or not the value of textFieldTest has
     * be populated at least once.
     */
    private boolean textFieldTestSet = false;

    /**
     * Resets the value of the textFieldTestSet to false
     */
    public void resetTextFieldTestSet()
    {
        this.textFieldTestSet = false;
    }

    /**
     * Indicates whether or not the value for textFieldTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextFieldTestSet()
    {
        return this.textFieldTestSet;
    }

    /**
     * 
     */
    public void setTextFieldTest(String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
        this.textFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] textFieldTestValueList;

    /**
     * Stores the labels
     */
    private Object[] textFieldTestLabelList;
    public Object[] getTextFieldTestBackingList()
    {
        Object[] values = this.textFieldTestValueList;
        Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextFieldTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;
        if (items != null)
        {
            this.textFieldTestValueList = new Object[items.size()];
            this.textFieldTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.textFieldTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.textFieldTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.textFieldTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String passwordFieldTest;

    /**
     * 
     */
    public String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }

    /**
     * Keeps track of whether or not the value of passwordFieldTest has
     * be populated at least once.
     */
    private boolean passwordFieldTestSet = false;

    /**
     * Resets the value of the passwordFieldTestSet to false
     */
    public void resetPasswordFieldTestSet()
    {
        this.passwordFieldTestSet = false;
    }

    /**
     * Indicates whether or not the value for passwordFieldTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPasswordFieldTestSet()
    {
        return this.passwordFieldTestSet;
    }

    /**
     * 
     */
    public void setPasswordFieldTest(String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
        this.passwordFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] passwordFieldTestValueList;

    /**
     * Stores the labels
     */
    private Object[] passwordFieldTestLabelList;
    public Object[] getPasswordFieldTestBackingList()
    {
        Object[] values = this.passwordFieldTestValueList;
        Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setPasswordFieldTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;
        if (items != null)
        {
            this.passwordFieldTestValueList = new Object[items.size()];
            this.passwordFieldTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.passwordFieldTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.passwordFieldTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.passwordFieldTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String textAreaTest;

    /**
     * 
     */
    public String getTextAreaTest()
    {
        return this.textAreaTest;
    }

    /**
     * Keeps track of whether or not the value of textAreaTest has
     * be populated at least once.
     */
    private boolean textAreaTestSet = false;

    /**
     * Resets the value of the textAreaTestSet to false
     */
    public void resetTextAreaTestSet()
    {
        this.textAreaTestSet = false;
    }

    /**
     * Indicates whether or not the value for textAreaTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextAreaTestSet()
    {
        return this.textAreaTestSet;
    }

    /**
     * 
     */
    public void setTextAreaTest(String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
        this.textAreaTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] textAreaTestValueList;

    /**
     * Stores the labels
     */
    private Object[] textAreaTestLabelList;
    public Object[] getTextAreaTestBackingList()
    {
        Object[] values = this.textAreaTestValueList;
        Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextAreaTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;
        if (items != null)
        {
            this.textAreaTestValueList = new Object[items.size()];
            this.textAreaTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.textAreaTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.textAreaTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.textAreaTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private boolean checkboxTest;

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }

    /**
     * Keeps track of whether or not the value of checkboxTest has
     * be populated at least once.
     */
    private boolean checkboxTestSet = false;

    /**
     * Resets the value of the checkboxTestSet to false
     */
    public void resetCheckboxTestSet()
    {
        this.checkboxTestSet = false;
    }

    /**
     * Indicates whether or not the value for checkboxTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCheckboxTestSet()
    {
        return this.checkboxTestSet;
    }

    /**
     * 
     */
    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
        this.checkboxTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] checkboxTestValueList;

    /**
     * Stores the labels
     */
    private Object[] checkboxTestLabelList;
    public Object[] getCheckboxTestBackingList()
    {
        Object[] values = this.checkboxTestValueList;
        Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCheckboxTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;
        if (items != null)
        {
            this.checkboxTestValueList = new Object[items.size()];
            this.checkboxTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.checkboxTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.checkboxTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.checkboxTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String radioButtonsTest;

    /**
     * 
     */
    public String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest has
     * be populated at least once.
     */
    private boolean radioButtonsTestSet = false;

    /**
     * Resets the value of the radioButtonsTestSet to false
     */
    public void resetRadioButtonsTestSet()
    {
        this.radioButtonsTestSet = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTestSet()
    {
        return this.radioButtonsTestSet;
    }

    /**
     * 
     */
    public void setRadioButtonsTest(String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
        this.radioButtonsTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] radioButtonsTestValueList;

    /**
     * Stores the labels
     */
    private Object[] radioButtonsTestLabelList;
    public Object[] getRadioButtonsTestBackingList()
    {
        Object[] values = this.radioButtonsTestValueList;
        Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;
        if (items != null)
        {
            this.radioButtonsTestValueList = new Object[items.size()];
            this.radioButtonsTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.radioButtonsTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.radioButtonsTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.radioButtonsTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String radioButtonsTest2;

    /**
     * 
     */
    public String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest2 has
     * be populated at least once.
     */
    private boolean radioButtonsTest2Set = false;

    /**
     * Resets the value of the radioButtonsTest2Set to false
     */
    public void resetRadioButtonsTest2Set()
    {
        this.radioButtonsTest2Set = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTest2Set()
    {
        return this.radioButtonsTest2Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest2(String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
        this.radioButtonsTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] radioButtonsTest2ValueList;

    /**
     * Stores the labels
     */
    private Object[] radioButtonsTest2LabelList;
    public Object[] getRadioButtonsTest2BackingList()
    {
        Object[] values = this.radioButtonsTest2ValueList;
        Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTest2BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest2ValueList = new Object[items.size()];
            this.radioButtonsTest2LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.radioButtonsTest2ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.radioButtonsTest2LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.radioButtonsTest2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String radioButtonsTest3;

    /**
     * 
     */
    public String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }

    /**
     * Keeps track of whether or not the value of radioButtonsTest3 has
     * be populated at least once.
     */
    private boolean radioButtonsTest3Set = false;

    /**
     * Resets the value of the radioButtonsTest3Set to false
     */
    public void resetRadioButtonsTest3Set()
    {
        this.radioButtonsTest3Set = false;
    }

    /**
     * Indicates whether or not the value for radioButtonsTest3 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRadioButtonsTest3Set()
    {
        return this.radioButtonsTest3Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest3(String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
        this.radioButtonsTest3Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] radioButtonsTest3ValueList;

    /**
     * Stores the labels
     */
    private Object[] radioButtonsTest3LabelList;
    public Object[] getRadioButtonsTest3BackingList()
    {
        Object[] values = this.radioButtonsTest3ValueList;
        Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRadioButtonsTest3BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest3ValueList = new Object[items.size()];
            this.radioButtonsTest3LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.radioButtonsTest3ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.radioButtonsTest3LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.radioButtonsTest3LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String selectTest;

    /**
     * 
     */
    public String getSelectTest()
    {
        return this.selectTest;
    }

    /**
     * Keeps track of whether or not the value of selectTest has
     * be populated at least once.
     */
    private boolean selectTestSet = false;

    /**
     * Resets the value of the selectTestSet to false
     */
    public void resetSelectTestSet()
    {
        this.selectTestSet = false;
    }

    /**
     * Indicates whether or not the value for selectTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSelectTestSet()
    {
        return this.selectTestSet;
    }

    /**
     * 
     */
    public void setSelectTest(String selectTest)
    {
        this.selectTest = selectTest;
        this.selectTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] selectTestValueList;

    /**
     * Stores the labels
     */
    private Object[] selectTestLabelList;
    public Object[] getSelectTestBackingList()
    {
        Object[] values = this.selectTestValueList;
        Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSelectTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        if (items != null)
        {
            this.selectTestValueList = new Object[items.size()];
            this.selectTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.selectTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.selectTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.selectTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String hiddenTest;

    /**
     * 
     */
    public String getHiddenTest()
    {
        return this.hiddenTest;
    }

    /**
     * Keeps track of whether or not the value of hiddenTest has
     * be populated at least once.
     */
    private boolean hiddenTestSet = false;

    /**
     * Resets the value of the hiddenTestSet to false
     */
    public void resetHiddenTestSet()
    {
        this.hiddenTestSet = false;
    }

    /**
     * Indicates whether or not the value for hiddenTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenTestSet()
    {
        return this.hiddenTestSet;
    }

    /**
     * 
     */
    public void setHiddenTest(String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
        this.hiddenTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] hiddenTestValueList;

    /**
     * Stores the labels
     */
    private Object[] hiddenTestLabelList;
    public Object[] getHiddenTestBackingList()
    {
        Object[] values = this.hiddenTestValueList;
        Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setHiddenTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;
        if (items != null)
        {
            this.hiddenTestValueList = new Object[items.size()];
            this.hiddenTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.hiddenTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.hiddenTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.hiddenTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String textFieldTest2;

    /**
     * 
     */
    public String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }

    /**
     * Keeps track of whether or not the value of textFieldTest2 has
     * be populated at least once.
     */
    private boolean textFieldTest2Set = false;

    /**
     * Resets the value of the textFieldTest2Set to false
     */
    public void resetTextFieldTest2Set()
    {
        this.textFieldTest2Set = false;
    }

    /**
     * Indicates whether or not the value for textFieldTest2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextFieldTest2Set()
    {
        return this.textFieldTest2Set;
    }

    /**
     * 
     */
    public void setTextFieldTest2(String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
        this.textFieldTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] textFieldTest2ValueList;

    /**
     * Stores the labels
     */
    private Object[] textFieldTest2LabelList;
    public Object[] getTextFieldTest2BackingList()
    {
        Object[] values = this.textFieldTest2ValueList;
        Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextFieldTest2BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;
        if (items != null)
        {
            this.textFieldTest2ValueList = new Object[items.size()];
            this.textFieldTest2LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.textFieldTest2ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.textFieldTest2LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.textFieldTest2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTextFieldTestSet();
         this.resetPasswordFieldTestSet();
         this.resetTextAreaTestSet();
         this.resetCheckboxTestSet();
         this.resetRadioButtonsTestSet();
         this.resetRadioButtonsTest2Set();
         this.resetRadioButtonsTest3Set();
         this.resetSelectTestSet();
         this.resetHiddenTestSet();
         this.resetTextFieldTest2Set();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -429804311279173999L;
}