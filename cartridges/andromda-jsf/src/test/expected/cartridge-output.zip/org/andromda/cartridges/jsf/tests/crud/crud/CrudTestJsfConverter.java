// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

/**
 * Handles conversion of the entity id to a String.
 */
public class CrudTestJsfConverter
    implements javax.faces.convert.Converter
{
    /**
     * @see javax.faces.convert.Converter#getAsString(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.Object)
     */
    public String getAsString(
        javax.faces.context.FacesContext context,
        javax.faces.component.UIComponent component,
        java.lang.Object value)
        throws javax.faces.convert.ConverterException
    {
        if(value == null)
            return "";

        final CrudTestValueObject vo;
        try {
            final Long id;
            if(value instanceof String)
                id = Long.valueOf((String)value);
            else
                id = (Long)value;

            vo = ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().readById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return ("Failed to locate object.");
        }
        return String.valueOf(vo.getId());
    }

    /**
     * @see javax.faces.convert.Converter#getAsObject(javax.faces.context.FacesContext, javax.faces.component.UIComponent, java.lang.String)
     */
    public Object getAsObject(
        javax.faces.context.FacesContext context,
        javax.faces.component.UIComponent component,
        java.lang.String value)
        throws javax.faces.convert.ConverterException
    {
        throw new UnsupportedOperationException();
    }
}
