// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller#thisOperationReturnsSomething()
     */
    public java.lang.Object thisOperationReturnsSomething()
    {
        return null;
    }
    
}