// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>operation2</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.deferringoperations.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#operation2(java.lang.String testParam2)
 */
public interface Operation2Form
{
    /**
     * 
     */
    public int getTestParam2();

    /**
     * 
     */
    public void setTestParam2(int testParam2);
    
}