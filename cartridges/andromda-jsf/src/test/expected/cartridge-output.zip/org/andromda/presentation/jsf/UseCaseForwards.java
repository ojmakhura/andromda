package org.andromda.presentation.jsf;

/**
 * Stores all forward paths available in all use cases keyed by forward name.
 */
public final class UseCaseForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    public static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("no-table-link-activity-usecase", "/org/andromda/cartridges/jsf/tests/tables/notablelink/no-table-link-activity.jsf");
            forwards.put("no-table-link-activity-show-table-data", "/org/andromda/cartridges/jsf/tests/tables/notablelink/show-table-data.jsf");
            forwards.put("table-link-activity-usecase", "/org/andromda/cartridges/jsf/tests/tables/tablelink/table-link-activity.jsf");
            forwards.put("table-link-activity-show-table-data", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data.jsf");
            forwards.put("table-link-activity-again", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-again.jsf");
            forwards.put("table-link-activity-hyperlink-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-hyperlink-action.jsf");
            forwards.put("table-link-activity-bad-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-bad-action.jsf");
            forwards.put("table-link-activity-hyperlink-action-duplicating-parameter", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-hyperlink-action-duplicating-parameter.jsf");
            forwards.put("table-link-activity-hyperlink-not-specifying-column", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-hyperlink-not-specifying-column.jsf");
            forwards.put("table-link-activity-action-with-bad-table-link", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-action-with-bad-table-link.jsf");
            forwards.put("table-link-activity-realistic-form-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-realistic-form-action.jsf");
            forwards.put("table-link-activity-image-link-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-image-link-action.jsf");
            forwards.put("table-link-activity-global-table-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-global-table-action.jsf");
            forwards.put("table-link-activity-duplicate-global-table-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-duplicate-global-table-action.jsf");
            forwards.put("table-link-activity-another-duplicate-global-table-action", "/org/andromda/cartridges/jsf/tests/tables/tablelink/show-table-data-another-duplicate-global-table-action.jsf");
            forwards.put("validation-activity-usecase", "/org/andromda/cartridges/jsf/tests/validation/validation-activity.jsf");
            forwards.put("validation-activity-enter-data", "/org/andromda/cartridges/jsf/tests/validation/enter-data.jsf");
            forwards.put("validation-activity-usecase", "/org/andromda/cartridges/jsf/tests/validation/validation-activity.jsf");
            forwards.put("trigger-present-use-case-usecase", "/org/andromda/cartridges/jsf/tests/constraints/actions/triggerpresent/trigger-present-use-case.jsf");
            forwards.put("trigger-present-use-case-some-page", "/org/andromda/cartridges/jsf/tests/constraints/actions/triggerpresent/some-page.jsf");
            forwards.put("jsps-cannot-defer-can-stop-usecase", "/org/andromda/cartridges/jsf/tests/constraints/jsps/cannotdefercanstop/jsps-cannot-defer-can-stop.jsf");
            forwards.put("jsps-cannot-defer-can-stop-page", "/org/andromda/cartridges/jsf/tests/constraints/jsps/cannotdefercanstop/page.jsf");
            forwards.put("one-use-case-use-case1-usecase", "/org/andromda/cartridges/jsf/tests/constraints/packages/oneusecase/one-use-case-use-case1.jsf");
            forwards.put("one-use-case-use-case2-usecase", "/org/andromda/cartridges/jsf/tests/constraints/packages/oneusecase/one-use-case-use-case2.jsf");
            forwards.put("duplicate-operation-names-usecase", "/org/andromda/cartridges/jsf/tests/constraints/controllers/duplicateoperationnames/duplicate-operation-names.jsf");
            forwards.put("duplicate-operation-names-show-something", "/org/andromda/cartridges/jsf/tests/constraints/controllers/duplicateoperationnames/show-something.jsf");
            forwards.put("operation-name-as-use-case-usecase", "/org/andromda/cartridges/jsf/tests/constraints/controllers/operationnameasusecase/operation-name-as-use-case.jsf");
            forwards.put("operation-name-as-use-case-page", "/org/andromda/cartridges/jsf/tests/constraints/controllers/operationnameasusecase/page.jsf");
            forwards.put("valid-exception-target-usecase", "/org/andromda/cartridges/jsf/tests/constraints/exceptions/validtarget/valid-exception-target.jsf");
            forwards.put("valid-exception-target-a", "/org/andromda/cartridges/jsf/tests/constraints/exceptions/validtarget/a.jsf");
            forwards.put("valid-exception-target-usecase", "/org/andromda/cartridges/jsf/tests/constraints/exceptions/validtarget/valid-exception-target.jsf");
            forwards.put("decisions-return-type-void-usecase", "/org/andromda/cartridges/jsf/tests/constraints/decisions/returntypevoid/decisions-return-type-void.jsf");
            forwards.put("decisions-missing-call-usecase", "/org/andromda/cartridges/jsf/tests/constraints/decisions/missingcall/decisions-missing-call.jsf");
            forwards.put("decisions-missing-guard-usecase", "/org/andromda/cartridges/jsf/tests/constraints/decisions/missingguard/decisions-missing-guard.jsf");
            forwards.put("decisions-bad-target-usecase", "/org/andromda/cartridges/jsf/tests/constraints/decisions/badtarget/decisions-bad-target.jsf");
            forwards.put("decisions-bad-target-show-something", "/org/andromda/cartridges/jsf/tests/constraints/decisions/badtarget/show-something.jsf");
            forwards.put("action-states-no-forward-usecase", "/org/andromda/cartridges/jsf/tests/constraints/actionstates/noforward/action-states-no-forward.jsf");
            forwards.put("exceptions-activity-usecase", "/org/andromda/cartridges/jsf/tests/exceptions/exceptions-activity.jsf");
            forwards.put("exceptions-activity-enter-info", "/org/andromda/cartridges/jsf/tests/exceptions/enter-info.jsf");
            forwards.put("exceptions-activity-show-something", "/org/andromda/cartridges/jsf/tests/exceptions/show-something.jsf");
            forwards.put("exceptions-activity-usecase", "/org/andromda/cartridges/jsf/tests/exceptions/exceptions-activity.jsf");
            forwards.put("nohrefnoname-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/nohrefnoname/nohrefnoname.jsf");
            forwards.put("hyperlinked-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/hyperlinked/hyperlinked.jsf");
            forwards.put("named-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/named/named.jsf");
            forwards.put("hyperlinkednotusecase-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/hyperlinkednotusecase/hyperlinkednotusecase.jsf");
            forwards.put("namednotusecase-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/namednotusecase/namednotusecase.jsf");
            forwards.put("final-states-web-page-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/final-states-web-page.jsf");
            forwards.put("final-states-web-page-something", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/something.jsf");
            forwards.put("final-states-web-page-a", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/something-a.jsf");
            forwards.put("final-states-web-page-b", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/something-b.jsf");
            forwards.put("final-states-web-page-c", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/something-c.jsf");
            forwards.put("final-states-web-page-d", "/org/andromda/cartridges/jsf/tests/finalstates/webpage/something-d.jsf");
            forwards.put("session-object-activity-usecase", "/org/andromda/cartridges/jsf/tests/sessionobjects/session-object-activity.jsf");
            forwards.put("widgets-activity-usecase", "/org/andromda/cartridges/jsf/tests/widgets/widgets-activity.jsf");
            forwards.put("widgets-activity-show-widgets", "/org/andromda/cartridges/jsf/tests/widgets/show-widgets.jsf");
            forwards.put("widgets-activity-usecase", "/org/andromda/cartridges/jsf/tests/widgets/widgets-activity.jsf");
            forwards.put("hyperlinkactions-usecase", "/org/andromda/cartridges/jsf/tests/hyperlinkactions/hyperlinkactions.jsf");
            forwards.put("hyperlinkactions-show-something", "/org/andromda/cartridges/jsf/tests/hyperlinkactions/show-something.jsf");
            forwards.put("deferring-operations-usecase", "/org/andromda/cartridges/jsf/tests/deferringoperations/deferring-operations.jsf");
            forwards.put("deferring-operations-state2", "/org/andromda/cartridges/jsf/tests/deferringoperations/state2.jsf");
            forwards.put("deferring-operations-state4", "/org/andromda/cartridges/jsf/tests/deferringoperations/state4.jsf");
            forwards.put("deferring-operations-state6", "/org/andromda/cartridges/jsf/tests/deferringoperations/state6.jsf");
            forwards.put("duplicate-actions-usecase-usecase", "/org/andromda/cartridges/jsf/tests/duplicateactions/duplicate-actions-usecase.jsf");
            forwards.put("duplicate-actions-usecase-show-something", "/org/andromda/cartridges/jsf/tests/duplicateactions/show-something.jsf");
            forwards.put("messages-activity-usecase", "/org/andromda/cartridges/jsf/tests/messages/messages-activity.jsf");
            forwards.put("messages-activity-three", "/org/andromda/cartridges/jsf/tests/messages/three.jsf");
            forwards.put("form-fields-usecase", "/org/andromda/cartridges/jsf/tests/formfields/form-fields.jsf");
            forwards.put("form-fields-one", "/org/andromda/cartridges/jsf/tests/formfields/one.jsf");
            forwards.put("form-fields-three", "/org/andromda/cartridges/jsf/tests/formfields/three.jsf");
            forwards.put("form-fields-go", "/org/andromda/cartridges/jsf/tests/formfields/three-go.jsf");
            forwards.put("empty-graph-usecase", "${useCase.path}.jsf");
            forwards.put("empty-use-case-usecase", "${useCase.path}.jsf");
            forwards.put("page-variables-usecase", "/org/andromda/cartridges/jsf/tests/pagevariables/page-variables.jsf");
            forwards.put("page-variables-show-something", "/org/andromda/cartridges/jsf/tests/pagevariables/show-something.jsf");
            forwards.put("inter-use-case-source-usecase", "/org/andromda/cartridges/jsf/tests/interusecase/source/inter-use-case-source.jsf");
            forwards.put("inter-use-case-source-source", "/org/andromda/cartridges/jsf/tests/interusecase/source/source.jsf");
            forwards.put("inter-use-case-source-submit", "/org/andromda/cartridges/jsf/tests/interusecase/source/source-submit.jsf");
            forwards.put("inter-use-case-target-usecase", "/org/andromda/cartridges/jsf/tests/interusecase/target/inter-use-case-target.jsf");
            forwards.put("redirect-usecase", "/org/andromda/cartridges/jsf/tests/redirect/redirect.jsf");
            forwards.put("services-usecase", "/org/andromda/cartridges/jsf/tests/services/services.jsf");
            forwards.put("services-a", "/org/andromda/cartridges/jsf/tests/services/a.jsf");
            forwards.put("reset-usecase", "/org/andromda/cartridges/jsf/tests/reset/reset.jsf");
            forwards.put("reset-reset-page", "/org/andromda/cartridges/jsf/tests/reset/reset-page.jsf");
            forwards.put("reset-usecase", "/org/andromda/cartridges/jsf/tests/reset/reset.jsf");
            forwards.put("inter-action-state-usecase", "/org/andromda/cartridges/jsf/tests/interactionstate/inter-action-state.jsf");
            forwards.put("inter-action-state-page1", "/org/andromda/cartridges/jsf/tests/interactionstate/page1.jsf");
            forwards.put("graph-out-use-case-usecase", "/org/andromda/cartridges/jsf/tests/graphoutusecase/usecase/graph-out-use-case.jsf");
            forwards.put("graph-out-use-case-stop-here", "/org/andromda/cartridges/jsf/tests/graphoutusecase/usecase/stop-here.jsf");
            forwards.put("controller-tv-usecase", "/org/andromda/cartridges/jsf/tests/controllertv/controller-tv.jsf");
            forwards.put("controller-tv-woohoow", "/org/andromda/cartridges/jsf/tests/controllertv/woohoow.jsf");
            forwards.put("form-scope-usecase", "/org/andromda/cartridges/jsf/tests/formscope/form-scope.jsf");
            forwards.put("form-scope-a-page", "/org/andromda/cartridges/jsf/tests/formscope/a-page.jsf");
            forwards.put("form-scope-submit", "/org/andromda/cartridges/jsf/tests/formscope/a-page-submit.jsf");
        }
        return (String)forwards.get(name);
    }

    /**
     * Stores the keyed forward paths.
     */
    private static final java.util.Map<String, String> forwards = new java.util.HashMap<String, String>();
}