// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

import java.io.Serializable;

/**
 * This form holds the fields that are used in the search operation of CrudTest
 *
 */
public final class CrudTestSearchForm
    implements Serializable
{

    private String stringAttribute;

    /**
     * 
     */
    public String getStringAttribute()
    {
        return this.stringAttribute;
    }

    /**
     * 
     */
    public void setStringAttribute(String stringAttribute)
    {
        this.stringAttribute = stringAttribute;
    }

    private Integer intRequiredAttribute;

    /**
     * 
     */
    public Integer getIntRequiredAttribute()
    {
        return this.intRequiredAttribute;
    }

    /**
     * 
     */
    public void setIntRequiredAttribute(Integer intRequiredAttribute)
    {
        this.intRequiredAttribute = intRequiredAttribute;
    }

    private Long id;

    /**
     * 
     */
    public Long getId()
    {
        return this.id;
    }

    /**
     * 
     */
    public void setId(Long id)
    {
        this.id = id;
    }


    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 5464408209025651331L;
}