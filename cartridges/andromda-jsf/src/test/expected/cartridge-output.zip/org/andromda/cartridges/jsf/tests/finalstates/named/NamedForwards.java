package org.andromda.cartridges.jsf.tests.finalstates.named;

/**
 * Stores all forward paths available in the use case Named keyed by forward name.
 */
final class NamedForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("named-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/named/named.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}