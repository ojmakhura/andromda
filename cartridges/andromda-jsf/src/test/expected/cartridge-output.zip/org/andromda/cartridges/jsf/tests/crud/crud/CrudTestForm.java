// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;

/**
 * This form encapsulates the fields that are used in the execution of the CRUD operations in CrudTest
 *
 */
public class CrudTestForm
    implements Serializable
{

    /**
     * Default constructor. Initializes the attributes formatters.
     *
     */
    public CrudTestForm(){
        // - setup the default java.util.Date.toString() formatter
        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);

        searchForm = new CrudTestSearchForm();

        editState=false;
    }

    /**
     * Holds the edit/search state of the form
     */
    private boolean editState;

    public boolean getEditState(){
        return editState;
    }

    public void setEditState(boolean editState){
        this.editState = editState;
    }

    private CrudTestSearchForm searchForm;

    public CrudTestSearchForm getSearchForm(){
        return searchForm;
    }

    public void setSearchForm(CrudTestSearchForm searchForm){
        this.searchForm = searchForm;
    }

    private List manageableList = null;

    public List getManageableList()
    {
        return this.manageableList;
    }

    public void setManageableList(List manageableList)
    {
        this.manageableList = manageableList;
    }

    /**
     * 
    */
    private Long[] selectedRows = null;

    public Long[] getSelectedRows()
    {
        return this.selectedRows;
    }

    public void setSelectedRows(Long[] selectedRows)
    {
        this.selectedRows = selectedRows;
    }

    private String stringAttribute;

    /**
     * 
     */
    public String getStringAttribute()
    {
        return this.stringAttribute;
    }

    /**
     * 
     */
    public void setStringAttribute(String stringAttribute)
    {
        this.stringAttribute = stringAttribute;
    }

    private Collection stringAttributeBackingList;

    public Collection getStringAttributeBackingList(){
        return stringAttributeBackingList;
    }

    public void setStringAttributeBackingList(Collection stringAttributeBackingList){
        this.stringAttributeBackingList = stringAttributeBackingList;
    }

    private int intRequiredAttribute;

    /**
     * 
     */
    public int getIntRequiredAttribute()
    {
        return this.intRequiredAttribute;
    }

    /**
     * 
     */
    public void setIntRequiredAttribute(int intRequiredAttribute)
    {
        this.intRequiredAttribute = intRequiredAttribute;
    }

    private Collection intRequiredAttributeBackingList;

    public Collection getIntRequiredAttributeBackingList(){
        return intRequiredAttributeBackingList;
    }

    public void setIntRequiredAttributeBackingList(Collection intRequiredAttributeBackingList){
        this.intRequiredAttributeBackingList = intRequiredAttributeBackingList;
    }

    private Long id;

    /**
     * 
     */
    public Long getId()
    {
        return this.id;
    }

    /**
     * 
     */
    public void setId(Long id)
    {
        this.id = id;
    }

    private Collection idBackingList;

    public Collection getIdBackingList(){
        return idBackingList;
    }

    public void setIdBackingList(Collection idBackingList){
        this.idBackingList = idBackingList;
    }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map dateTimeFormatters = new HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }


    /**
     * The current collection of messages stored within this form.
     */
    private Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * Copy all the properties from the other form to the current form.
     *
     * @param otherForm the form with the source properties to be copied.
     */
    public void copyFrom(CrudTestForm otherForm){
        this.setStringAttribute(otherForm.getStringAttribute());
        this.setStringAttributeBackingList(otherForm.getStringAttributeBackingList());
        this.setIntRequiredAttribute(otherForm.getIntRequiredAttribute());
        this.setIntRequiredAttributeBackingList(otherForm.getIntRequiredAttributeBackingList());
        this.setId(otherForm.getId());
        this.setIdBackingList(otherForm.getIdBackingList());

        this.setJsfMessages(otherForm.getJsfMessages());
        this.setJsfMessagesTitle(otherForm.getJsfMessagesTitle());

        this.setEditState(otherForm.getEditState());
        this.setSearchForm(otherForm.getSearchForm());
        this.setManageableList(otherForm.getManageableList());
        this.setSelectedRows(otherForm.getSelectedRows());
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 5464408209025651331L;
}