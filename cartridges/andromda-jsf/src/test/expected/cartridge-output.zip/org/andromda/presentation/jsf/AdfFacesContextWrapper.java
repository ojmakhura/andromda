package org.andromda.presentation.jsf;

import java.io.Serializable;
import org.apache.myfaces.trinidad.context.RequestContext;

/**
 * This wrapper just allows us to store the current RequestContext instance
 * in the session since the RequestContext is not serializable.
 *
 * @author Chad Brandon
 */
public class AdfFacesContextWrapper
    implements Serializable
{
    private transient RequestContext currentInstance = null;

    public RequestContext getCurrentInstance()
    {
        if (this.currentInstance == null)
        {
            this.currentInstance = RequestContext.getCurrentInstance();
        }
        return this.currentInstance;
    }

    private static final long serialVersionUID = 1L;
}