// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.notablelink;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class NoTableLinkActivityFormImpl
    implements Serializable
{
    public NoTableLinkActivityFormImpl()
    {
        final DateFormat customTableThreeDateFormatter = new SimpleDateFormat("dd/MMM/yy");
        customTableThreeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("customTable.three", customTableThreeDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private Collection tableData;

    /**
     * 
     */
    public Collection getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Resets the value of the tableDataSet to false
     */
    public void resetTableDataSet()
    {
        this.tableDataSet = false;
    }

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(Collection tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataValueList;

    /**
     * Stores the labels
     */
    private Object[] tableDataLabelList;
    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new Object[items.size()];
            this.tableDataLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection tableDataBackingValue;

    public void setTableDataBackingValue(Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }

    public Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private CustomTableRow[] customTable;

    /**
     * 
     */
    public CustomTableRow[] getCustomTable()
    {
        return this.customTable;
    }

    /**
     * Keeps track of whether or not the value of customTable has
     * be populated at least once.
     */
    private boolean customTableSet = false;

    /**
     * Resets the value of the customTableSet to false
     */
    public void resetCustomTableSet()
    {
        this.customTableSet = false;
    }

    /**
     * Indicates whether or not the value for customTable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCustomTableSet()
    {
        return this.customTableSet;
    }

    /**
     * 
     */
    public void setCustomTable(CustomTableRow[] customTable)
    {
        this.customTable = customTable;
        this.customTableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] customTableValueList;

    /**
     * Stores the labels
     */
    private Object[] customTableLabelList;
    public Object[] getCustomTableBackingList()
    {
        Object[] values = this.customTableValueList;
        Object[] labels = this.customTableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCustomTableValueList()
    {
        return this.customTableValueList;
    }

    public void setCustomTableValueList(Object[] customTableValueList)
    {
        this.customTableValueList = customTableValueList;
    }

    public Object[] getCustomTableLabelList()
    {
        return this.customTableLabelList;
    }

    public void setCustomTableLabelList(Object[] customTableLabelList)
    {
        this.customTableLabelList = customTableLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.customTableValueList = null;
        this.customTableLabelList = null;
        if (items != null)
        {
            this.customTableValueList = new Object[items.size()];
            this.customTableLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.customTableValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private CustomTableRow[] customTableBackingValue;

    public void setCustomTableBackingValue(CustomTableRow[] customTableBackingValue)
    {
        this.customTableBackingValue = customTableBackingValue;
    }

    public CustomTableRow[] getCustomTableBackingValue()
    {
        return this.customTableBackingValue;
    }

    /**
     * Stores the values.
     */
    private Object[] customTableOneValueList;

    /**
     * Stores the labels
     */
    private Object[] customTableOneLabelList;
    public Object[] getCustomTableOneBackingList()
    {
        Object[] values = this.customTableOneValueList;
        Object[] labels = this.customTableOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCustomTableOneValueList()
    {
        return this.customTableOneValueList;
    }

    public void setCustomTableOneValueList(Object[] customTableOneValueList)
    {
        this.customTableOneValueList = customTableOneValueList;
    }

    public Object[] getCustomTableOneLabelList()
    {
        return this.customTableOneLabelList;
    }

    public void setCustomTableOneLabelList(Object[] customTableOneLabelList)
    {
        this.customTableOneLabelList = customTableOneLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableOneBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.customTableOneValueList = null;
        this.customTableOneLabelList = null;
        if (items != null)
        {
            this.customTableOneValueList = new Object[items.size()];
            this.customTableOneLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.customTableOneValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableOneLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableOneLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private Object[] customTableTwoValueList;

    /**
     * Stores the labels
     */
    private Object[] customTableTwoLabelList;
    public Object[] getCustomTableTwoBackingList()
    {
        Object[] values = this.customTableTwoValueList;
        Object[] labels = this.customTableTwoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCustomTableTwoValueList()
    {
        return this.customTableTwoValueList;
    }

    public void setCustomTableTwoValueList(Object[] customTableTwoValueList)
    {
        this.customTableTwoValueList = customTableTwoValueList;
    }

    public Object[] getCustomTableTwoLabelList()
    {
        return this.customTableTwoLabelList;
    }

    public void setCustomTableTwoLabelList(Object[] customTableTwoLabelList)
    {
        this.customTableTwoLabelList = customTableTwoLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableTwoBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.customTableTwoValueList = null;
        this.customTableTwoLabelList = null;
        if (items != null)
        {
            this.customTableTwoValueList = new Object[items.size()];
            this.customTableTwoLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.customTableTwoValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableTwoLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableTwoLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private Object[] customTableThreeValueList;

    /**
     * Stores the labels
     */
    private Object[] customTableThreeLabelList;
    public Object[] getCustomTableThreeBackingList()
    {
        Object[] values = this.customTableThreeValueList;
        Object[] labels = this.customTableThreeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCustomTableThreeValueList()
    {
        return this.customTableThreeValueList;
    }

    public void setCustomTableThreeValueList(Object[] customTableThreeValueList)
    {
        this.customTableThreeValueList = customTableThreeValueList;
    }

    public Object[] getCustomTableThreeLabelList()
    {
        return this.customTableThreeLabelList;
    }

    public void setCustomTableThreeLabelList(Object[] customTableThreeLabelList)
    {
        this.customTableThreeLabelList = customTableThreeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableThreeBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.customTableThreeValueList = null;
        this.customTableThreeLabelList = null;
        if (items != null)
        {
            this.customTableThreeValueList = new Object[items.size()];
            this.customTableThreeLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.customTableThreeValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableThreeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableThreeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private Object[] customTableNoColumnForThisAttributeValueList;

    /**
     * Stores the labels
     */
    private Object[] customTableNoColumnForThisAttributeLabelList;
    public Object[] getCustomTableNoColumnForThisAttributeBackingList()
    {
        Object[] values = this.customTableNoColumnForThisAttributeValueList;
        Object[] labels = this.customTableNoColumnForThisAttributeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCustomTableNoColumnForThisAttributeValueList()
    {
        return this.customTableNoColumnForThisAttributeValueList;
    }

    public void setCustomTableNoColumnForThisAttributeValueList(Object[] customTableNoColumnForThisAttributeValueList)
    {
        this.customTableNoColumnForThisAttributeValueList = customTableNoColumnForThisAttributeValueList;
    }

    public Object[] getCustomTableNoColumnForThisAttributeLabelList()
    {
        return this.customTableNoColumnForThisAttributeLabelList;
    }

    public void setCustomTableNoColumnForThisAttributeLabelList(Object[] customTableNoColumnForThisAttributeLabelList)
    {
        this.customTableNoColumnForThisAttributeLabelList = customTableNoColumnForThisAttributeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableNoColumnForThisAttributeBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.customTableNoColumnForThisAttributeValueList = null;
        this.customTableNoColumnForThisAttributeLabelList = null;
        if (items != null)
        {
            this.customTableNoColumnForThisAttributeValueList = new Object[items.size()];
            this.customTableNoColumnForThisAttributeLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.customTableNoColumnForThisAttributeValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableNoColumnForThisAttributeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableNoColumnForThisAttributeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTableDataSet();
         this.resetCustomTableSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 8406701110595000677L;
}