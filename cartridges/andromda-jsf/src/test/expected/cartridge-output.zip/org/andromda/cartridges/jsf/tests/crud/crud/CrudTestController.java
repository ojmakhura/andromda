// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

/**
 * Javaserver Faces Controller of the CrudTest CRUD management.
 */
public abstract class CrudTestController
{
    private static final org.apache.commons.logging.Log logger = org.apache.commons.logging.LogFactory.getLog(CrudTestController.class);

    /**
    * Initializes the controller, calling the doInit method
    *
    * @return the controller view path.
    */
    public String init()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doInit(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }
        return "/org/andromda/cartridges/jsf/tests/crud/crud/crudtest-crud";
    }

    /**
    * Initializes the controller. This method can be overriden.
    */
    public void doInit(org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {

        form.getSearchForm().setStringAttribute(null);
        form.getSearchForm().setIntRequiredAttribute(null);

        form.setManageableList(null);


        form.setEditState(false);
    }

    /**
    * The instance load action.
    */
    public void load(javax.faces.event.ActionEvent event)
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doLoad(Long.valueOf(((javax.faces.component.UIParameter)event.getComponent().findComponent("id")).getValue().toString()),form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
            resetAllEditableComponentsValues();
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }
    }

    /**
    * Loads the selected instance.
    */
    public void doLoad(Long id, org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {
        final CrudTestValueObject vo=
            ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().readById(id);

        form.setStringAttribute(vo.getStringAttribute());
        form.setIntRequiredAttribute(vo.getIntRequiredAttribute());
        form.setId(vo.getId());

        form.setEditState(true);
    }

    /**
    * The cancel edit action
    *
    * @return the controller view path.
    */
    public String cancel()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doCancel(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }

        resetAllEditableComponentsValues();
        return null;
    }

    /**
    * Executes the edit cancel.
    */
    public void doCancel(org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {
        form.setEditState(false);
    }

    /**
    * The new instance action.
    *
    * @return the controller view path.
    */
    public String startNew()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doStartNew(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }

        resetAllEditableComponentsValues();
        return null;
    }

    /**
    * Executes the new instance action.
    */
    public void doStartNew(org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {

        form.setStringAttribute(null);
        form.setIntRequiredAttribute(0);
        form.setId(null);


        form.setEditState(true);
    }
    /**
    * The save instance action.
    *
    * @return the controller view path.
    */
    public String save()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doSave(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }

        resetAllEditableComponentsValues();
        return null;
    }

    /**
    * Saves instance action.
    */
    public void doSave(org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {

        if(form.getId() == null){
            form.setId(
                ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().create(
                    form.getStringAttribute()
                    , form.getIntRequiredAttribute()
                    , null
                ).getId()
            );
            this.addInfoMessage(org.andromda.presentation.jsf.Messages.get("manageable.entity.created", new Object[]{org.andromda.presentation.jsf.Messages.get("crud.test")}));
        }
        else{
            ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().update(
                form.getStringAttribute()
                , form.getIntRequiredAttribute()
                , form.getId()
            );
            this.addInfoMessage(org.andromda.presentation.jsf.Messages.get("manageable.entity.changed", new Object[]{org.andromda.presentation.jsf.Messages.get("crud.test")}));
        }
        if(form.getManageableList() != null) //only searches again if there was an old search
            doSearch(form); //search again to show the updated item (if it fits the search criteria)

        form.setEditState(false);
    }

    /**
    * The save and new instance action.
    *
    * @return the controller view path.
    */
    public String saveAndNew()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doSave(form);
                this.doStartNew(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }

        resetAllEditableComponentsValues();
        return null;
    }

    /**
    * The search action.
    *
    * @return the controller view path.
    */
    public String search()
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doSearch(form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }

        resetAllEditableComponentsValues();
        return null;
    }

    /**
    * Executes the search action.
    */
    public void doSearch(org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {

        final java.util.List list;
        //if all search fields are null, call readAll()
        if(
             org.apache.commons.lang.StringUtils.isEmpty(form.getSearchForm().getStringAttribute())
            && form.getSearchForm().getIntRequiredAttribute() == null
            )
        list=${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().readAll();
    else
        list = ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().read(
            form.getSearchForm().getStringAttribute()
            , form.getSearchForm().getIntRequiredAttribute()
            , null
        );

        form.setManageableList(list);
        if (list.size() >= 250)
            saveMaxResultsWarning();


        form.setEditState(false);
    }

    /**
    * The delete event.
    */
    public void delete(javax.faces.event.ActionEvent event)
    {
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        try
        {
            final org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form = this.getForm();

            try
            {
                contextWrapper.getCurrentInstance().getPageFlowScope().put("form", form);

                this.doDelete(Long.valueOf(((javax.faces.component.UIParameter)event.getComponent().findComponent("id")).getValue().toString()),form);
            }
            catch (final Throwable throwable)
            {
                final String messageKey = org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable);
                // - the exception is re-thrown by the exception handler and handled by the catch below if it can't get a messageKey
                //   (no reason to check for presence of messageKey)
                this.addErrorMessage(org.andromda.presentation.jsf.Messages.get(messageKey, null));
            }
            resetAllEditableComponentsValues();
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }
    }

    /**
    * Deletes the selected instance.
    */
    public void doDelete(Long id, org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm form)
        throws Exception
    {
        ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().delete(new Long[]{id});
        this.addInfoMessage(org.andromda.presentation.jsf.Messages.get("manageable.entity.deleted", new Object[]{org.andromda.presentation.jsf.Messages.get("crud.test")}));

        doSearch(form);
    }

    /**
    * Shows a message warning the user can exists more records available.
    */
    private void saveMaxResultsWarning()
    {
        addWarningMessage(org.andromda.presentation.jsf.Messages.get("maximum.results.fetched.warning", new Object[]{String.valueOf("250")}));
    }

    /**
    * Helper method to fill the autocomplete component list.
    */
    public void fillAutocomplete(javax.faces.event.ActionEvent event)
    {
        final javax.faces.context.FacesContext facesContext = this.getContext();
        final java.util.Map parameters = facesContext.getExternalContext().getRequestParameterMap();
        final Object fieldValue = parameters.get(this.getParameterValue("searchFieldRequestParamName",event));
        try{
            final java.util.List list = ${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().read(
                null
                , null
                , (fieldValue==null || fieldValue.toString().length() == 0) ? null : java.lang.Long.valueOf(fieldValue.toString())
            );
            final javax.faces.el.ValueBinding vb = facesContext.getApplication().createValueBinding("#{autocompleteResult}");
            vb.setValue(facesContext, list);
        }
        catch (final Throwable throwable)
        {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
        }
    }

    /**
    * Helper method to fill the select component list.
    *
    * @return a collection with the filtered list.
    */
    public java.util.Collection<javax.faces.model.SelectItem> getAsSelectItems()
    {
        final java.util.Collection<CrudTestValueObject> vos;
        try {
            vos = (java.util.Collection<CrudTestValueObject>)${application.package}.ManageableServiceLocator.instance().getCrudTestManageableService().readAll();
        } catch (final Throwable throwable) {
            logger.error(throwable);
            this.addExceptionMessage(throwable);
            return null;
        }
        final java.util.Collection<javax.faces.model.SelectItem> result=new java.util.ArrayList<javax.faces.model.SelectItem>(vos.size());
        for(CrudTestValueObject vo: vos){
            result.add(new javax.faces.model.SelectItem(vo.getId(),org.apache.commons.lang.ObjectUtils.toString(vo.getId())));
        }
        return result;
    }

    /**
     * Resolves "manageCrudTestForm" variable in all contexts.
     *
     * @return the manageable form.
     */
    protected org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm getForm()
    {
        return (org.andromda.cartridges.jsf.tests.crud.crud.ManageCrudTestForm)this.resolveVariable("manageCrudTestForm");
    }

    /**
     * Force the component to get its value from the backing bean before rendering
     *
     * @param uic the parent UIComponent.
     */
    private void resetEditableComponentsValues(javax.faces.component.UIComponent uic)
    {
        if(uic instanceof javax.faces.component.EditableValueHolder)
        {
            final javax.faces.component.EditableValueHolder evh=(javax.faces.component.EditableValueHolder)uic;
            evh.setValue(null);
            evh.setSubmittedValue(null);
            evh.setLocalValueSet(false);
            evh.setValid(true);
        }
        for(Object component: uic.getChildren())
        {
            resetEditableComponentsValues((javax.faces.component.UIComponent)component);
        }
    }

    /**
     * Force all the editable components to get its values from the backing bean before rendering
     */
    private void resetAllEditableComponentsValues()
    {
        resetEditableComponentsValues(this.getContext().getViewRoot());
    }

    /**
     * Returns an javax.faces.event.FacesEvent parameter value, from its name
     *
     * @param parameterName the name of the parameter.
     * @param event the FacesEvent holding the parameter.
     */
    protected Object getParameterValue(String parameterName, javax.faces.event.FacesEvent event)
    {
        for(Object uiObject : event.getComponent().getChildren()){
            if(uiObject instanceof javax.faces.component.UIParameter){
                final javax.faces.component.UIParameter param = (javax.faces.component.UIParameter)uiObject;
                if(param.getName().equals(parameterName)) {
                    return param.getValue();
                }
            }
        }
        return null;
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }

    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     *
     * @param name the variable name
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        org.apache.myfaces.trinidad.context.RequestContext adfContext = org.apache.myfaces.trinidad.context.RequestContext.getCurrentInstance();
        Object variable = adfContext.getPageFlowScope().get(name);
        // - if we couldn't get the variable from the regular ADF context, see if
        //   the session contains an ADF context with the variable
        if (variable == null)
        {
            final javax.servlet.http.HttpSession session = this.getSession(false);
            if (session != null)
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper =
                    (org.andromda.presentation.jsf.AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;
            }
            variable = adfContext != null ? adfContext.getPageFlowScope().get(name) : null;
        }
        // - finally try resolving it in the standard JSF manner
        if (variable == null)
        {
            final javax.faces.context.FacesContext context = this.getContext();
            variable = context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;
        }
        return variable;
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    protected final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        final org.apache.myfaces.trinidad.context.RequestContext adfContext = org.apache.myfaces.trinidad.context.RequestContext.getCurrentInstance();
        final Object form = adfContext.getPageFlowScope().get("form");
        if (form != null)
        {
            try
            {
                final java.lang.reflect.Method method = form.getClass().getMethod(
                    "addJsfMessages",
                    new Class[]{javax.faces.application.FacesMessage.class});
                method.invoke(form, new Object[]{facesMessage});
            }
            catch (final Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
    }

    /**
     * Creates a new request attribute.
     *
     * @param name the attribute name.
     * @param object the attribute value.
     */
    protected void setRequestAttribute(final String name, final Object object)
    {
        org.andromda.presentation.jsf.JsfUtils.setAttribute(this.getContext().getExternalContext().getRequest(), name, object);
    }

    // crud-controller merge-point

}