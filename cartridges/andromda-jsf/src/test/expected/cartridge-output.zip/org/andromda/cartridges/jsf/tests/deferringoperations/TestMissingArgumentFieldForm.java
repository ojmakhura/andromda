// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>testMissingArgumentField</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 * The action deferring to this operation has no form field with
 * the same name and type.
 * </p>
 *
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#testMissingArgumentField(java.lang.String thisArgumentIsMissingFromTheActionForm)
 */
public interface TestMissingArgumentFieldForm
{
    /**
     * 
     */
    public java.lang.String getThisArgumentIsMissingFromTheActionForm();

    /**
     * 
     */
    public void setThisArgumentIsMissingFromTheActionForm(java.lang.String thisArgumentIsMissingFromTheActionForm);
    
}