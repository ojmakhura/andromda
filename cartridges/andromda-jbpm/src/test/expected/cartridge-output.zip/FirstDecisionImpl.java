public class FirstDecisionImpl extends FirstDecision
{
    protected final void handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }
}
