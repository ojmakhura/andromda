package org.andromda.cartridges.jbpm.tests.onlinestore;

import org.jbpm.db.GraphSession;
import org.jbpm.db.JbpmSession;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
/**
 * This helper class provides static utility methods to more easily handle
 * the jBPM process API for the 'Online Store' process.
 */
public class OnlineStore
{
    /**
     * The name for this process, this is the name used in the corresponding jPDL descriptor file.
     */
    public static final String PROCESS_NAME = "Online Store";

    /**
     * This constant holds a reference to the name of the
     * <em>customer ready for purchase</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CUSTOMER_READY_FOR_PURCHASE = "customer ready for purchase";

    /**
     * This constant holds a reference to the name of the
     * <em>article selected</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_ARTICLE_SELECTED = "article selected";

    /**
     * This constant holds a reference to the name of the
     * <em>checking out</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CHECKING_OUT = "checking out";

    /**
     * This constant holds a reference to the name of the
     * <em>check out confirmed</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CHECK_OUT_CONFIRMED = "check out confirmed";

    /**
     * This constant holds a reference to the name of the
     * <em>dispatching articles</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_DISPATCHING_ARTICLES = "dispatching articles";

    /**
     * This constant holds a reference to the name of the
     * <em>items dispatched</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_ITEMS_DISPATCHED = "items dispatched";

    /**
     * This constant holds a reference to the name of the
     * <em>update credentials</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_UPDATE_CREDENTIALS = "update credentials";

    /**
     * This constant holds a reference to the name of the
     * <em>notifying customer</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_NOTIFYING_CUSTOMER = "notifying customer";

    /**
     * This constant holds a reference to the name of the
     * <em>start</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_START = "start";

    /**
     * This constant holds a reference to the name of the
     * <em>customer check out credentials okay</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CUSTOMER_CHECK_OUT_CREDENTIALS_OKAY = "customer check out credentials okay";

    /**
     * This constant holds a reference to the name of the
     * <em>notify customer while dispatching articles</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_NOTIFY_CUSTOMER_WHILE_DISPATCHING_ARTICLES = "notify customer while dispatching articles";

    /**
     * This constant holds a reference to the name of the
     * <em>customer notified during dispatching</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CUSTOMER_NOTIFIED_DURING_DISPATCHING = "customer notified during dispatching";

    /**
     * This constant holds a reference to the name of the
     * <em>addArticleToBasket</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_ADD_ARTICLE_TO_BASKET = "addArticleToBasket";

    /**
     * This constant holds a reference to the name of the
     * <em>confirmCheckoutCredentials</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_CONFIRM_CHECKOUT_CREDENTIALS = "confirmCheckoutCredentials";

    /**
     * This constant holds a reference to the name of the
     * <em>dispatchArticles</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_DISPATCH_ARTICLES = "dispatchArticles";

    /**
     * This constant holds a reference to the name of the
     * <em>updateCredentials</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_UPDATE_CREDENTIALS = "updateCredentials";

    /**
     * Creates a new process instance and returns the node representing the start state
     * in which the root token will be present.
     *
     * @param session the session into which to perform this operation
     * @return the node in which the process is started
     */
    public static nullNode startProcess(final JbpmSession session)
    {
        // the graph session allows us to work with the process definition
        final GraphSession graphSession = session.getGraphSession();

        // find the latest process definition we can use
        final ProcessDefinition processDefinition =
                graphSession.findLatestProcessDefinition(PROCESS_NAME);

        // create a new process
        final ProcessInstance processInstance = processDefinition.createProcessInstance();

        // return the first node in the process
        return new nullNode(processInstance.getRootToken());
    }

    /**
     * This method takes an internal jBpm node name and construct a wrapper node class around it
     * so it is easier to work with.
     *
     * @param token the token which will be encapsulated by the returned OnlineStoreProcessNode instance,
     *      must <em>not</em> be <code>null</code>
     * @return an OnlineStoreProcessNode wrapping the node with the argument name
     * @throws IllegalArgumentException when no matching node could be found for the argument name
     */
    static OnlineStoreProcessNode createNode(Token token)
    {
        OnlineStoreProcessNode node = null;
        final String nodeName = token.getNode().getName();

        if (NODE_START.equals(nodeName)) node = new nullNode(token); else
        if (NODE_ARTICLE_SELECTED.equals(nodeName)) node = new ArticleSelectedNode(token); else
        if (NODE_CHECK_OUT_CONFIRMED.equals(nodeName)) node = new CheckOutConfirmedNode(token); else
        if (NODE_DISPATCHING_ARTICLES.equals(nodeName)) node = new DispatchingArticlesNode(token); else
        if (NODE_UPDATE_CREDENTIALS.equals(nodeName)) node = new UpdateCredentialsNode(token); else
        if (NODE_CUSTOMER_READY_FOR_PURCHASE.equals(nodeName)) node = new CustomerReadyForPurchaseNode(token); else
        if (NODE_CHECKING_OUT.equals(nodeName)) node = new CheckingOutNode(token); else
        if (NODE_NOTIFYING_CUSTOMER.equals(nodeName)) node = new NotifyingCustomerNode(token); else
        if (NODE_ITEMS_DISPATCHED.equals(nodeName)) node = new ItemsDispatchedNode(token); else
            // hmm, apparently we have arrived in an unknown node, this could be a jbpm-cartridge bug
            throw new IllegalArgumentException("No matching node could be found for the process instance: " + nodeName);

        return node;
    }

    /**
     * Finds the process instance with the given id and returns the node representing the state in which
     * the process is in.
     *
     * @param session the session into which to perform this operation
     * @param processInstanceId the identifier for the process instance to load
     * @return the node in which the process instance with the argument id is currently present
     */
    public static OnlineStoreProcessNode getProcess(final JbpmSession session, final Long processInstanceId)
    {
        // the graph session allows us to work with the process definition
        final GraphSession graphSession = session.getGraphSession();

        // load the process using the unique identifier argument
        final ProcessInstance processInstance = graphSession.loadProcessInstance(processInstanceId.longValue());

        // the token for this process instance
        final Token token = processInstance.getRootToken();

        // construct the node we're in
        return createNode(token);
    }

    /**
     * Checks whether or not the argument node represents the <em>start</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.nullNode}
     */
    public static boolean isNullNode(final OnlineStoreProcessNode node)
    {
        return node instanceof nullNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>article selected</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.ArticleSelectedNode}
     */
    public static boolean isArticleSelectedNode(final OnlineStoreProcessNode node)
    {
        return node instanceof ArticleSelectedNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>check out confirmed</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CheckOutConfirmedNode}
     */
    public static boolean isCheckOutConfirmedNode(final OnlineStoreProcessNode node)
    {
        return node instanceof CheckOutConfirmedNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>dispatching articles</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.DispatchingArticlesNode}
     */
    public static boolean isDispatchingArticlesNode(final OnlineStoreProcessNode node)
    {
        return node instanceof DispatchingArticlesNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>update credentials</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.UpdateCredentialsNode}
     */
    public static boolean isUpdateCredentialsNode(final OnlineStoreProcessNode node)
    {
        return node instanceof UpdateCredentialsNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>customer ready for purchase</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CustomerReadyForPurchaseNode}
     */
    public static boolean isCustomerReadyForPurchaseNode(final OnlineStoreProcessNode node)
    {
        return node instanceof CustomerReadyForPurchaseNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>checking out</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CheckingOutNode}
     */
    public static boolean isCheckingOutNode(final OnlineStoreProcessNode node)
    {
        return node instanceof CheckingOutNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>notifying customer</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.NotifyingCustomerNode}
     */
    public static boolean isNotifyingCustomerNode(final OnlineStoreProcessNode node)
    {
        return node instanceof NotifyingCustomerNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>items dispatched</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.ItemsDispatchedNode}
     */
    public static boolean isItemsDispatchedNode(final OnlineStoreProcessNode node)
    {
        return node instanceof ItemsDispatchedNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>notify customer while dispatching articles</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.NotifyCustomerWhileDispatchingArticlesNode}
     */
    public static boolean isNotifyCustomerWhileDispatchingArticlesNode(final OnlineStoreProcessNode node)
    {
        return node instanceof NotifyCustomerWhileDispatchingArticlesNode;
    }


    /**
     * Saves the process instance to which this node is associated.
     *
     * @param session the session into which to perform this operation
     * @param node the process instance to persist will be retrieved from this node
     */
    public static void save(final JbpmSession session, final OnlineStoreProcessNode node)
    {
        session.getGraphSession().saveProcessInstance(node.getToken().getProcessInstance());
    }
}

