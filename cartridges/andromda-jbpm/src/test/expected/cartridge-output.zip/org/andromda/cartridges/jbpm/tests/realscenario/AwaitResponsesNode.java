package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * The node representing the await responses state in the <em>Real Scenario</em> process.
 */
public final class AwaitResponsesNode implements RealScenarioNode
{
    /**
     * This is the token encapsulated by this node class. It represents the internal jBpm state of the corresponding
     * process instance.
     */
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    AwaitResponsesNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Signals the process to leave this node
     * via the <em>flow received or attestation encoded</em> transition
     * and proceed to the next one.
     *
     * @return the next node in the process
     *      after following the <em>flow received or attestation encoded</em> transition
     */
    public CheckFileCompletenessNode signalFlowReceivedOrAttestationEncoded()
    {
        // signal this token to leave its node
        this.token.signal("flow received or attestation encoded");

        // simply return the next node instance
        return new CheckFileCompletenessNode(this.token);
    }

    /**
     * Signals the process to leave this node
     * via the <em>take decision</em> transition
     * and proceed to the next one.
     *
     * @return the next node in the process
     *      after following the <em>take decision</em> transition
     */
    public DecisionTakenNode signalTakeDecision()
    {
        // signal this token to leave its node
        this.token.signal("take decision");

        // simply return the next node instance
        return new DecisionTakenNode(this.token);
    }


    public String toString()
    {
        return AwaitResponsesNode.class + "[" + this.token.getName() + "]";
    }
}