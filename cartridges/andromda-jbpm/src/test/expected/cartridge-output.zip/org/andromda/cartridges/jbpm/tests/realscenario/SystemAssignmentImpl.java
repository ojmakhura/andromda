package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.taskmgmt.exe.Assignable;
/**
 * @see {@link SystemAssignment}
 */
public class SystemAssignmentImpl extends SystemAssignment
{
    protected void handleAssign(Assignable assignable, ExecutionContext executionContext)
        throws java.lang.Exception
    {
       // @todo implement code for handleAssign
    }
}
