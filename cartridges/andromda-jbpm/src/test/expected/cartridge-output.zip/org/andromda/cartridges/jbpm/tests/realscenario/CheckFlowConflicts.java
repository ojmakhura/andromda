package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * 
 */
public abstract class CheckFlowConflicts implements org.jbpm.graph.node.DecisionHandler
{
    public final java.lang.String decide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        return handleDecide(executionContext);
    }

    protected abstract java.lang.String handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;
}
