package org.andromda.cartridges.jbpm.tests;

public class FirstDecisionImpl implements FirstDecision
{
    public void decide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }
}
