package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * The node representing the article selected state in the <em>Online Store</em> process.
 */
public final class ArticleSelectedNode implements OnlineStoreNode
{
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    ArticleSelectedNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Returns true if all tasks for this node are ended.
     *
     * @return true if this node does not have any tasks that have not yet been finished, false otherwise
     */
    public boolean isTasksFinished()
    {
        return !this.token.getProcessInstance().getTaskMgmtInstance().hasUnfinishedTasks(this.token);
    }

    /**
     * Starts this node's <em>addArticleToBasket</em> task.
     */
    public void startAddArticleToBasket()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getAddArticleToBasketTask();
        if (task != null)
        {
            task.start();
        }
    }

    /**
     * Finishes this node's <em>addArticleToBasket</em> task.
     */
    public void finishAddArticleToBasket()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getAddArticleToBasketTask();
        if (task != null)
        {
            task.end();
        }
    }

    /**
     * Checks whether or not this node's <em>addArticleToBasket</em> task has been finished.
     *
     * @return true if this node's addArticleToBasket has been finished, false otherwise
     */
    public boolean isAddArticleToBasketFinished()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getAddArticleToBasketTask();
        return task == null ? true : task.hasEnded();
    }

    private org.jbpm.taskmgmt.exe.TaskInstance taskAddArticleToBasket = null;

    org.jbpm.taskmgmt.exe.TaskInstance getAddArticleToBasketTask()
    {
        if (this.taskAddArticleToBasket == null)
        {
            final java.util.Collection tasks = this.token.getProcessInstance().getTaskMgmtInstance().getTaskInstances();
            for (final java.util.Iterator taskIterator = tasks.iterator(); taskIterator.hasNext() && this.taskAddArticleToBasket == null;)
            {
                final org.jbpm.taskmgmt.exe.TaskInstance taskInstance = (org.jbpm.taskmgmt.exe.TaskInstance)taskIterator.next();
                if ("addArticleToBasket".equals(taskInstance.getName()))
                {
                    this.taskAddArticleToBasket = taskInstance;
                }
            }
        }
        return this.taskAddArticleToBasket;
    }

    /**
     * Signals the process to leave this node and proceed to the next one.
     * Since this transition leads into a node that will split it up into different transitions
     * this method returns the {@link OnlineStoreNode} instead of a concrete implementing class type.
     *
     * @return the next node in the process
     */
    public OnlineStoreNode signal()
    {
        this.token.signal();
        OnlineStoreNode targetNode = null;
        final java.lang.String nodeName = this.token.getNode().getName();

        if ("customer ready for purchase".equals(nodeName)) targetNode = new CustomerReadyForPurchaseNode(this.token); else
        throw new IllegalArgumentException("No matching node could be found for target token: " + nodeName);

        return targetNode;
    }

}