package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.db.GraphSession;
import org.jbpm.db.JbpmSession;
import org.jbpm.graph.def.ProcessDefinition;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
/**
 * This helper class provides static utility methods to more easily handle
 * the jBPM process API for the 'Real Scenario' process.
 */
public class RealScenario
{
    /**
     * The name for this process, this is the name used in the corresponding jPDL descriptor file.
     */
    public static final String PROCESS_NAME = "Real Scenario";

    /**
     * This constant holds a reference to the name of the
     * <em>perform initial tasks</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_PERFORM_INITIAL_TASKS = "perform initial tasks";

    /**
     * This constant holds a reference to the name of the
     * <em>await responses</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_AWAIT_RESPONSES = "await responses";

    /**
     * This constant holds a reference to the name of the
     * <em>take decision</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_TAKE_DECISION = "take decision";

    /**
     * This constant holds a reference to the name of the
     * <em>decision taken</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_DECISION_TAKEN = "decision taken";

    /**
     * This constant holds a reference to the name of the
     * <em>conflicts in file</em> state, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CONFLICTS_IN_FILE = "conflicts in file";

    /**
     * This constant holds a reference to the name of the
     * <em>start</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_START = "start";

    /**
     * This constant holds a reference to the name of the
     * <em>check file completeness</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CHECK_FILE_COMPLETENESS = "check file completeness";

    /**
     * This constant holds a reference to the name of the
     * <em>check flow conflicts</em> pseudostate, the value corresponds to the one used by jBPM internally.
     */
    public static final String NODE_CHECK_FLOW_CONFLICTS = "check flow conflicts";

    /**
     * This constant holds a reference to the name of the
     * <em>createFile</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_CREATE_FILE = "createFile";

    /**
     * This constant holds a reference to the name of the
     * <em>integrateMember</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_INTEGRATE_MEMBER = "integrateMember";

    /**
     * This constant holds a reference to the name of the
     * <em>sendFlows</em> task, the value corresponds to the one used by jBPM internally.
     */
    public static final String TASK_SEND_FLOWS = "sendFlows";

    /**
     * Creates a new process instance and returns the node representing the start state
     * in which the root token will be present.
     *
     * @param session the session into which to perform this operation
     * @return the node in which the process is started
     */
    public static nullNode startProcess(final JbpmSession session)
    {
        // the graph session allows us to work with the process definition
        final GraphSession graphSession = session.getGraphSession();

        // find the latest process definition we can use
        final ProcessDefinition processDefinition =
                graphSession.findLatestProcessDefinition(PROCESS_NAME);

        // create a new process
        final ProcessInstance processInstance = processDefinition.createProcessInstance();

        // return the first node in the process
        return new nullNode(processInstance.getRootToken());
    }

    /**
     * This method takes an internal jBpm node name and construct a wrapper node class around it
     * so it is easier to work with.
     *
     * @param token the token which will be encapsulated by the returned RealScenarioProcessNode instance,
     *      must <em>not</em> be <code>null</code>
     * @return an RealScenarioProcessNode wrapping the node with the argument name
     * @throws IllegalArgumentException when no matching node could be found for the argument name
     */
    static RealScenarioProcessNode createNode(Token token)
    {
        RealScenarioProcessNode node = null;
        final String nodeName = token.getNode().getName();

        if (NODE_START.equals(nodeName)) node = new nullNode(token); else
        if (NODE_AWAIT_RESPONSES.equals(nodeName)) node = new AwaitResponsesNode(token); else
        if (NODE_PERFORM_INITIAL_TASKS.equals(nodeName)) node = new PerformInitialTasksNode(token); else
        if (NODE_TAKE_DECISION.equals(nodeName)) node = new TakeDecisionNode(token); else
        if (NODE_DECISION_TAKEN.equals(nodeName)) node = new DecisionTakenNode(token); else
        if (NODE_CONFLICTS_IN_FILE.equals(nodeName)) node = new ConflictsInFileNode(token); else
            // hmm, apparently we have arrived in an unknown node, this could be a jbpm-cartridge bug
            throw new IllegalArgumentException("No matching node could be found for the process instance: " + nodeName);

        return node;
    }

    /**
     * Finds the process instance with the given id and returns the node representing the state in which
     * the process is in.
     *
     * @param session the session into which to perform this operation
     * @param processInstanceId the identifier for the process instance to load
     * @return the node in which the process instance with the argument id is currently present
     */
    public static RealScenarioProcessNode getProcess(final JbpmSession session, final Long processInstanceId)
    {
        // the graph session allows us to work with the process definition
        final GraphSession graphSession = session.getGraphSession();

        // load the process using the unique identifier argument
        final ProcessInstance processInstance = graphSession.loadProcessInstance(processInstanceId.longValue());

        // the token for this process instance
        final Token token = processInstance.getRootToken();

        // construct the node we're in
        return createNode(token);
    }

    /**
     * Checks whether or not the argument node represents the <em>start</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.nullNode}
     */
    public static boolean isNullNode(final RealScenarioProcessNode node)
    {
        return node instanceof nullNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>await responses</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.AwaitResponsesNode}
     */
    public static boolean isAwaitResponsesNode(final RealScenarioProcessNode node)
    {
        return node instanceof AwaitResponsesNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>perform initial tasks</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.PerformInitialTasksNode}
     */
    public static boolean isPerformInitialTasksNode(final RealScenarioProcessNode node)
    {
        return node instanceof PerformInitialTasksNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>take decision</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.TakeDecisionNode}
     */
    public static boolean isTakeDecisionNode(final RealScenarioProcessNode node)
    {
        return node instanceof TakeDecisionNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>decision taken</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.DecisionTakenNode}
     */
    public static boolean isDecisionTakenNode(final RealScenarioProcessNode node)
    {
        return node instanceof DecisionTakenNode;
    }

    /**
     * Checks whether or not the argument node represents the <em>conflicts in file</em> state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.ConflictsInFileNode}
     */
    public static boolean isConflictsInFileNode(final RealScenarioProcessNode node)
    {
        return node instanceof ConflictsInFileNode;
    }


    /**
     * Saves the process instance to which this node is associated.
     *
     * @param session the session into which to perform this operation
     * @param node the process instance to persist will be retrieved from this node
     */
    public static void save(final JbpmSession session, final RealScenarioProcessNode node)
    {
        session.getGraphSession().saveProcessInstance(node.getToken().getProcessInstance());
    }
}

