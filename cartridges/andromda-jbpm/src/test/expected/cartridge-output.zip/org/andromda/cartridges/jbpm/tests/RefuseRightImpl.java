package org.andromda.cartridges.jbpm.tests;

public class RefuseRightImpl implements RefuseRight
{
    public void execute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
