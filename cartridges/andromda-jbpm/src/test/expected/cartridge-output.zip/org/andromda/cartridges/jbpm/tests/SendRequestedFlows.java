package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public abstract class SendRequestedFlows implements
    org.jbpm.graph.def.ActionHandler
{
    public final void execute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        handleExecute(executionContext);
    }

    protected abstract void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;

}
