package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface SendRequestedFlows extends
    org.jbpm.graph.def.ActionHandler
{
}
