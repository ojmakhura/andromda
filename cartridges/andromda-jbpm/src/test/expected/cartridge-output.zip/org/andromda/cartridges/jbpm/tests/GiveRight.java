package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface GiveRight extends
    org.jbpm.graph.def.ActionHandler
{
}
