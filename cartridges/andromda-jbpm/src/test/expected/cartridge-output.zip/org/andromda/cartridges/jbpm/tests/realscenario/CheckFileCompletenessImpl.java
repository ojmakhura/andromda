package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.ExecutionContext;
/**
 * @see {@link CheckFileCompleteness}
 */
public class CheckFileCompletenessImpl extends CheckFileCompleteness
{
    protected final String handleDecide(ExecutionContext executionContext)
        throws Exception
    {
        // @todo implement code for handleDecide
        return null;
    }
}
