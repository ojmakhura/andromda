package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.ExecutionContext;
/**
 * @see {@link TakeDecision}
 */
public class TakeDecisionImpl extends TakeDecision
{
    protected final void handleExecute(ExecutionContext executionContext)
        throws java.lang.Exception
    {
        // @todo implement code for handleExecute
    }

}
