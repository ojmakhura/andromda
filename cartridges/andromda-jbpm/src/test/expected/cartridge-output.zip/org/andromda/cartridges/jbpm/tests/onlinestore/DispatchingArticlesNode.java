package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * The node representing the dispatching articles state in the <em>Online Store</em> process.
 */
public final class DispatchingArticlesNode implements OnlineStoreProcessNode
{
    /**
     * This is the token encapsulated by this node class. It represents the internal jBpm state of the corresponding
     * process instance.
     */
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    DispatchingArticlesNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Returns true if all tasks for this node are ended.
     *
     * @return true if this node does not have any tasks that have not yet been finished, false otherwise
     */
    public boolean isTasksFinished()
    {
        return !this.token.getProcessInstance().getTaskMgmtInstance().hasUnfinishedTasks(this.token);
    }

    /**
     * Starts this node's <em>dispatchArticles</em> task.
     */
    public void startDispatchArticles()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getDispatchArticlesTask();
        if (task != null)
        {
            task.start();
        }
    }

    /**
     * Finishes this node's <em>dispatchArticles</em> task.
     */
    public void finishDispatchArticles()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getDispatchArticlesTask();
        if (task != null)
        {
            task.end();
        }
    }

    /**
     * Checks whether or not this node's <em>dispatchArticles</em> task has been finished.
     *
     * @return true if this node's dispatchArticles has been finished, false otherwise
     */
    public boolean isDispatchArticlesFinished()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getDispatchArticlesTask();
        return task == null || task.hasEnded();
    }

    private org.jbpm.taskmgmt.exe.TaskInstance taskDispatchArticles = null;

    /**
     * Returns the first unfinished <em>DispatchArticles</em> task that can be found.
     */
    org.jbpm.taskmgmt.exe.TaskInstance getDispatchArticlesTask()
    {
        if (this.taskDispatchArticles == null)
        {
            final java.util.Collection tasks = this.token.getProcessInstance().getTaskMgmtInstance().getTaskInstances();
            for (final java.util.Iterator taskIterator = tasks.iterator(); taskIterator.hasNext() && this.taskDispatchArticles == null;)
            {
                final org.jbpm.taskmgmt.exe.TaskInstance taskInstance = (org.jbpm.taskmgmt.exe.TaskInstance)taskIterator.next();
                if ("dispatchArticles".equals(taskInstance.getName()) && taskInstance.getEnd() == null)
                {
                    this.taskDispatchArticles = taskInstance;
                }
            }
        }
        return this.taskDispatchArticles;
    }

    /**
     * Signals the process to leave this node
     * and proceed to the next one.
     *
     * @return the next node in the process
     */
    public CustomerNotifiedDuringDispatchingNode signal()
    {
        // signal this token to leave its node
        this.token.signal();

        // simply return the next node instance
        return new CustomerNotifiedDuringDispatchingNode(this.token);
    }

    /**
     * Overrides the default behavior of the <code>toString()</code> method in order
     * to be able to display this node's name as well as the name of the encapsulated token.
     */
    public String toString()
    {
        return "org.andromda.cartridges.jbpm.tests.onlinestore.DispatchingArticlesNode[" + this.token.getName() + "]";
    }
}