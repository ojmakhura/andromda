package org.andromda.cartridges.jbpm.client;

import org.jbpm.db.GraphSession;
import org.jbpm.db.JbpmSession;
import org.jbpm.db.JbpmSessionFactory;
import org.jbpm.graph.def.ProcessDefinition;
public final class ProcessManager
{
    /**
     * Constructs the jBpm session factory, this will initialize the environment.
     */
    private final static JbpmSessionFactory SESSION_FACTORY =
        JbpmSessionFactory.buildJbpmSessionFactory();

	/**
	 * Injects the process definitions into the database, this should only be done once.
	 */
	public static void injectAllProcessDefinitions() throws Exception
	{
		final ProcessDefinition onlineStoreDefinition =
		    ProcessDefinition.parseXmlResource("org/andromda/cartridges/jbpm/tests/onlinestore/online-store.pdl.xml");
		final ProcessDefinition realScenarioDefinition =
		    ProcessDefinition.parseXmlResource("org/andromda/cartridges/jbpm/tests/realscenario/real-scenario.pdl.xml");

	    final JbpmSession session = SESSION_FACTORY.openJbpmSession();
        final GraphSession graphSession = session.getGraphSession();

	    session.beginTransaction();
	    graphSession.saveProcessDefinition(onlineStoreDefinition);
	    graphSession.saveProcessDefinition(realScenarioDefinition);
        session.commitTransactionAndClose();
	}

    public static void createProcessSchema() throws Exception
    {
        SESSION_FACTORY.getJbpmSchema().createSchema();
    }

    public static void dropProcessSchema() throws Exception
    {
        SESSION_FACTORY.getJbpmSchema().dropSchema();
    }

    public static void cleanProcessSchema() throws Exception
    {
        SESSION_FACTORY.getJbpmSchema().cleanSchema();
    }

    public static boolean isProcessSchemaAvailable() throws Exception
    {
        return SESSION_FACTORY.getJbpmSchema().hasJbpmTables();
    }
}
