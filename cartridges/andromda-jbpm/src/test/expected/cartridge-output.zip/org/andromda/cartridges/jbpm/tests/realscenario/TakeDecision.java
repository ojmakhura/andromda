package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.def.ActionHandler;
import org.jbpm.graph.exe.ExecutionContext;
/**
 * 
 */
public abstract class TakeDecision implements
    ActionHandler
{
    public final void execute(ExecutionContext executionContext)
        throws Exception
    {
        handleExecute(executionContext);
    }

    protected abstract void handleExecute(ExecutionContext executionContext)
        throws Exception;

}
