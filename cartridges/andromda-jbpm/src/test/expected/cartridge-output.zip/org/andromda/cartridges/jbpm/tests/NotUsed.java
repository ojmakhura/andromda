package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface NotUsed extends
{
}
