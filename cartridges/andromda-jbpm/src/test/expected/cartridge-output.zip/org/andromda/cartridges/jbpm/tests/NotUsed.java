package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public abstract class NotUsed implements
{
}
