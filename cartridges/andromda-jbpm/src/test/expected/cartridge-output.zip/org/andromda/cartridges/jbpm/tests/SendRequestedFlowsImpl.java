package org.andromda.cartridges.jbpm.tests;

public class SendRequestedFlowsImpl implements SendRequestedFlows
{
    public void execute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
