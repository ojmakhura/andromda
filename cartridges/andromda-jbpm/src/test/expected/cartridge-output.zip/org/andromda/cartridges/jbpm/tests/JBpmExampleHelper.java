package org.andromda.cartridges.jbpm.tests;

import org.jbpm.db.JbpmSession;
import org.jbpm.db.JbpmSessionFactory;
import org.jbpm.graph.def.ProcessDefinition;

/**
 * This helper class provides static utility methods to more easily handle
 * the jBPM process API for the 'jBpm Example' process.
 */
public class JBpmExampleHelper
{
    public static final String PROCESS_DEFINITION_NAME = "org.andromda.cartridges.jbpm.tests.j-bpm-example.xml";

	private static final JbpmSessionFactory jbpmSessionFactory = JbpmSessionFactory.getInstance();

	/**
	 * Injects the process definition into the database
	 */
	private static void injectProcess()
	{
		final ProcessDefinition processDefinition = ProcessDefinition.parseXmlResource(processFileName);

		//Let's open a new persistence session
	    JbpmSession jbpmSession = jbpmSessionFactory.openJbpmSession();

	    // ... and begin a transaction on the persistence session
	    jbpmSession.beginTransaction();

	    // Save the process definition in the database
	    jbpmSession.getGraphSession().saveProcessDefinition(processDefinition);

	    // Commit the transaction
	    jbpmSession.commitTransaction();

	    // And close the jbpmSession.
	    jbpmSession.close();

	}

	/**
	 * Creates the schema in the database
	 *
	 */
	public static void createSchema()
	{
		jbpmSessionFactory.getJbpmSchema().createSchema();
	}
}

