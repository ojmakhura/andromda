package org.andromda.cartridges.jbpm.tests.onlinestore;

import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.taskmgmt.exe.Assignable;
/**
 * @see {@link CustomerAssignment}
 */
public class CustomerAssignmentImpl extends CustomerAssignment
{
    protected void handleAssign(Assignable assignable, ExecutionContext executionContext)
        throws java.lang.Exception
    {
       // @todo implement code for handleAssign
    }
}
