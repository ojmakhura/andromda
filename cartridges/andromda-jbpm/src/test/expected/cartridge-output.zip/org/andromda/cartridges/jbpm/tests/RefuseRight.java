package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface RefuseRight extends
    org.jbpm.graph.def.ActionHandler
{
}
