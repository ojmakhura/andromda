package org.andromda.cartridges.jbpm.tests;

public class GiveRightImpl extends GiveRight
{
    protected final void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
