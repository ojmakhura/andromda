package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface CheckFileCompleteness extends org.jbpm.graph.node.DecisionHandler
{
}
