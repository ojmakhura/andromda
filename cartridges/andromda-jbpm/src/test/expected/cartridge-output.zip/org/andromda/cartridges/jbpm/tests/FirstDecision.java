package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface FirstDecision extends org.jbpm.graph.node.DecisionHandler
{
}
