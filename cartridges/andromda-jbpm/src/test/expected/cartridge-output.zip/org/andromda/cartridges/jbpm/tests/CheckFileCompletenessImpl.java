package org.andromda.cartridges.jbpm.tests;

public class CheckFileCompletenessImpl implements CheckFileCompleteness
{
    public void decide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }
}
