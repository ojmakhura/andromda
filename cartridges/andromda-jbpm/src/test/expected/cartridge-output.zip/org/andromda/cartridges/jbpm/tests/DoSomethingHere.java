package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public interface DoSomethingHere extends
    org.jbpm.graph.def.ActionHandler
    , org.jbpm.taskmgmt.def.AssignmentHandler
{
}
