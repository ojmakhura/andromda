package org.andromda.cartridges.jbpm.tests;

/**
 * 
 */
public abstract class DoSomethingHere implements
    org.jbpm.graph.def.ActionHandler
    , org.jbpm.taskmgmt.def.AssignmentHandler
{
    public final void execute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        handleExecute(executionContext);
    }

    protected abstract void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;

    public final void assign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        handleAssign(assignable, executionContext);
    }

    protected abstract void handleAssign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;

}
