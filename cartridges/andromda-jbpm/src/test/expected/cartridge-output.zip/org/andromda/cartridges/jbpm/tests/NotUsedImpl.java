package org.andromda.cartridges.jbpm.tests;

public class NotUsedImpl implements NotUsed
{
}
