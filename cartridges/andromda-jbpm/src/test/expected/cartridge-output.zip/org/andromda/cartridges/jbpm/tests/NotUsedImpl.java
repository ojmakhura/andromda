package org.andromda.cartridges.jbpm.tests;

public class NotUsedImpl extends NotUsed
{
}
