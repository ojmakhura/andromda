package org.andromda.cartridges.jbpm.tests;

public class DoSomethingHereImpl extends DoSomethingHere
{
    protected final void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

    protected final void handleAssign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
