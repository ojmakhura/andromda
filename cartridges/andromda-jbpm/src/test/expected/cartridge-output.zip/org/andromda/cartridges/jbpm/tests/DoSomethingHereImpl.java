package org.andromda.cartridges.jbpm.tests;

public class DoSomethingHereImpl implements DoSomethingHere
{
    public void execute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

    public void assign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
