package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.taskmgmt.def.AssignmentHandler;
import org.jbpm.taskmgmt.exe.Assignable;
/**
 * 
 */
public abstract class HumanAssignment implements AssignmentHandler
{
    public final void assign(Assignable assignable, ExecutionContext executionContext)
        throws Exception
    {
        handleAssign(assignable, executionContext);
    }

    protected abstract void handleAssign(Assignable assignable, ExecutionContext executionContext)
        throws Exception;
}
