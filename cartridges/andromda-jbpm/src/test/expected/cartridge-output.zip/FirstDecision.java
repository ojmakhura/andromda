/**
 * 
 */
public abstract class FirstDecision implements org.jbpm.graph.node.DecisionHandler
{
    public final void decide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        handleDecide(executionContext);
    }

    protected abstract void handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;
}
