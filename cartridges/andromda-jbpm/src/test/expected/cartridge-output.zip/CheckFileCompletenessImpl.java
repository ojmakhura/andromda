public class CheckFileCompletenessImpl extends CheckFileCompleteness
{
    protected final void handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }
}
