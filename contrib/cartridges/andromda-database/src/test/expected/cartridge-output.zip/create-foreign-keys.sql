/* ------------- EntityTwo foreign key contraints ------------------ */
ALTER TABLE ENTITY_TWO
    ADD  ( CONSTRAINT FKENTITYONEENTITYTWO
        FOREIGN KEY (ENTITY_ONE_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[entityOne]
            REFERENCES ENTITY_ONE
                ) ;

ALTER TABLE ENTITY_TWO
    ADD  ( CONSTRAINT FKENTITYTHREEENTITYTWO
        FOREIGN KEY (ENTITY_THREE_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[entityThree]
            REFERENCES ENTITY_THREE
                ) ;

/* ------------- many2ManyOnes2many2ManyTwos foreign key contraints ------------------ */
ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2MANYONEMANY2MANYONES2MA
        FOREIGN KEY (MANY2_MANY_ONES_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[many2ManyOnes]
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2MANYTWOMANY2MANYONES2MA
        FOREIGN KEY (MANY2_MANY_TWOS_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[many2ManyTwos]
            REFERENCES MANY2_MANY_TWO
                 ON DELETE CASCADE ) ;

/* ------------- EntityNine foreign key contraints ------------------ */
ALTER TABLE ENTITY_NINE
    ADD  ( CONSTRAINT FKENTITYFOURENTITYNINE
        FOREIGN KEY (ENTITY4_ID)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ColumnLogicImpl[entity4Id]
            REFERENCES ENTITY_FOUR
                 ON DELETE CASCADE ) ;

/* ------------- EntityEight foreign key contraints ------------------ */
ALTER TABLE ENTITY_EIGHT
    ADD  ( CONSTRAINT FKENTITYFOURENTITYEIGHT
        FOREIGN KEY (ENTITY4_ID)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ColumnLogicImpl[entity4Id]
            REFERENCES ENTITY_FOUR
                 ON DELETE CASCADE ) ;

/* ------------- EntityFive foreign key contraints ------------------ */
ALTER TABLE ENTITY_FIVE
    ADD  ( CONSTRAINT FKMANY2MANYONEENTITYFIVE
        FOREIGN KEY (MANY2_MANY_ONE_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[many2ManyOne]
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

/* ------------- EntitySeven foreign key contraints ------------------ */
ALTER TABLE ENTITY_SEVEN
    ADD  ( CONSTRAINT FKENTITYSIXENTITYSEVEN
        FOREIGN KEY (ID)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ColumnLogicImpl[id]
            REFERENCES ENTITY_SIX
                ) ;

/* ------------- EntityThree foreign key contraints ------------------ */
ALTER TABLE ENTITY_THREE
    ADD  ( CONSTRAINT FKENTITYFOURENTITYTHREE
        FOREIGN KEY (ENTITY_FOUR_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[entityFour]
            REFERENCES ENTITY_FOUR
                ) ;

/* ------------- Many2ManyTwo foreign key contraints ------------------ */
ALTER TABLE MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKENTITYSEVENMANY2MANYTWO
        FOREIGN KEY (ENTITY_SEVEN_FK)
        // foreignKeyColumn = org.andromda.cartridges.database.metafacades.ForeignKeyColumnLogicImpl[entitySeven]
            REFERENCES ENTITY_SEVEN
                 ON DELETE CASCADE ) ;


