/* ------------- EntityTwo foreign key contraints ------------------ */
ALTER TABLE EntityTwo
    ADD  ( CONSTRAINT FKENTITY_THREEEntityTwo
        FOREIGN KEY (ENTITY_THREE_FK)
            REFERENCES ENTITY_THREE
                ) ;

/* ------------- EntityFive foreign key contraints ------------------ */
ALTER TABLE EntityFive
    ADD  ( CONSTRAINT FKMANY2_MANY_ONEEntityFive
        FOREIGN KEY (MANY2_MANY_ONE_FK)
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

/* ------------- many2ManyOnes2many2ManyTwos foreign key contraints ------------------ */
ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2_MANY_ONEMANY2_MANY_ONE
        FOREIGN KEY (MANY2_MANY_ONES_FK)
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2_MANY_TWOMANY2_MANY_ONE
        FOREIGN KEY (MANY2_MANY_TWOS_FK)
            REFERENCES MANY2_MANY_TWO
                 ON DELETE CASCADE ) ;


