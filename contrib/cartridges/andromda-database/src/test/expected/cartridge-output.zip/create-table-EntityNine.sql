/* --------------- EntityNine table definition --------------------- */
CREATE TABLE ENTITY_NINE 
(
    ENTITY4_ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_NINE
   ADD  ( CONSTRAINT XPKENTITYNINE PRIMARY KEY (ENTITY4_ID) );
