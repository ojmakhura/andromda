/* --------------- EntityOne table definition --------------------- */
CREATE TABLE ENTITY_ONE (
    ID NUMBER(19) NOT NULL,
    ATTRIBUTE_ONE VARCHAR2(255) NULL,
    ATTRIBUTE_TWO NUMBER(10) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_ONE
   ADD  ( CONSTRAINT XPKENTITY_ONE PRIMARY KEY (ID) );