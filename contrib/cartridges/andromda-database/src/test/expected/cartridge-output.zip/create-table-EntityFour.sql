/* --------------- EntityFour table definition --------------------- */
CREATE TABLE ENTITY_FOUR 
(
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_FOUR
   ADD  ( CONSTRAINT XPKENTITY_FOUR PRIMARY KEY (ID) );
