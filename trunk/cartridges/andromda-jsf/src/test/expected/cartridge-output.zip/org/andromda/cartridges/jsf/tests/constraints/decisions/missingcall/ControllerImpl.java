// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2347399805286204944L;

}