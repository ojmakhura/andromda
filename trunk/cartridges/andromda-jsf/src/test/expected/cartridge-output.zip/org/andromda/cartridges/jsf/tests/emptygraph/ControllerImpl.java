// license-header java merge-point
package org.andromda.cartridges.jsf.tests.emptygraph;

/**
 * @see org.andromda.cartridges.jsf.tests.emptygraph.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -8960834607019898864L;

}