// license-header java merge-point
package org.andromda.cartridges.jsf.tests.pagevariables;

/**
 * 
 */
public class PageVariablesFormImpl
    implements java.io.Serializable
{
    public PageVariablesFormImpl()
    {
        final java.text.DateFormat cDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        cDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("c", cDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.lang.String a;

    /**
     * 
     */
    public java.lang.String getA()
    {
        return this.a;
    }

    /**
     * Keeps track of whether or not the value of a has
     * be populated at least once.
     */
    private boolean aSet = false;

    /**
     * Resets the value of the aSet to false
     */
    public void resetASet()
    {
        this.aSet = false;
    }

    /**
     * Indicates whether or not the value for a has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isASet()
    {
        return this.aSet;
    }

    /**
     * 
     */
    public void setA(java.lang.String a)
    {
        this.a = a;
        this.aSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] aValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] aLabelList;
    public java.lang.Object[] getABackingList()
    {
        java.lang.Object[] values = this.aValueList;
        java.lang.Object[] labels = this.aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getAValueList()
    {
        return this.aValueList;
    }

    public void setAValueList(java.lang.Object[] aValueList)
    {
        this.aValueList = aValueList;
    }

    public java.lang.Object[] getALabelList()
    {
        return this.aLabelList;
    }

    public void setALabelList(java.lang.Object[] aLabelList)
    {
        this.aLabelList = aLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setABackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.aValueList = null;
        this.aLabelList = null;
        if (items != null)
        {
            this.aValueList = new java.lang.Object[items.size()];
            this.aLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.aValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.aLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.aLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private int b;

    /**
     * 
     */
    public int getB()
    {
        return this.b;
    }

    /**
     * Keeps track of whether or not the value of b has
     * be populated at least once.
     */
    private boolean bSet = false;

    /**
     * Resets the value of the bSet to false
     */
    public void resetBSet()
    {
        this.bSet = false;
    }

    /**
     * Indicates whether or not the value for b has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBSet()
    {
        return this.bSet;
    }

    /**
     * 
     */
    public void setB(int b)
    {
        this.b = b;
        this.bSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] bValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] bLabelList;
    public java.lang.Object[] getBBackingList()
    {
        java.lang.Object[] values = this.bValueList;
        java.lang.Object[] labels = this.bLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getBValueList()
    {
        return this.bValueList;
    }

    public void setBValueList(java.lang.Object[] bValueList)
    {
        this.bValueList = bValueList;
    }

    public java.lang.Object[] getBLabelList()
    {
        return this.bLabelList;
    }

    public void setBLabelList(java.lang.Object[] bLabelList)
    {
        this.bLabelList = bLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setBBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.bValueList = null;
        this.bLabelList = null;
        if (items != null)
        {
            this.bValueList = new java.lang.Object[items.size()];
            this.bLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.bValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.bLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.bLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.util.Date c;

    /**
     * 
     */
    public java.util.Date getC()
    {
        return this.c;
    }

    /**
     * Keeps track of whether or not the value of c has
     * be populated at least once.
     */
    private boolean cSet = false;

    /**
     * Resets the value of the cSet to false
     */
    public void resetCSet()
    {
        this.cSet = false;
    }

    /**
     * Indicates whether or not the value for c has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCSet()
    {
        return this.cSet;
    }

    /**
     * 
     */
    public void setC(java.util.Date c)
    {
        this.c = c;
        this.cSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] cValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] cLabelList;
    public java.lang.Object[] getCBackingList()
    {
        java.lang.Object[] values = this.cValueList;
        java.lang.Object[] labels = this.cLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCValueList()
    {
        return this.cValueList;
    }

    public void setCValueList(java.lang.Object[] cValueList)
    {
        this.cValueList = cValueList;
    }

    public java.lang.Object[] getCLabelList()
    {
        return this.cLabelList;
    }

    public void setCLabelList(java.lang.Object[] cLabelList)
    {
        this.cLabelList = cLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.cValueList = null;
        this.cLabelList = null;
        if (items != null)
        {
            this.cValueList = new java.lang.Object[items.size()];
            this.cLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.cValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.cLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.cLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetASet();
         this.resetBSet();
         this.resetCSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 2346092844553720186L;
}
