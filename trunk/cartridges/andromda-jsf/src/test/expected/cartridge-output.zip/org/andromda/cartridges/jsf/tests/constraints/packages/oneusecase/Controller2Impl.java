// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.Controller2
 */
public class Controller2Impl
    extends Controller2
{

}