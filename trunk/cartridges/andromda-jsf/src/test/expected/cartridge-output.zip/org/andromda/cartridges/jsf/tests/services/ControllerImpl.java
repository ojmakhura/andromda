// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

/**
 * @see org.andromda.cartridges.jsf.tests.services.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#crapmeout()
     */
    public void crapmeout()
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation(java.lang.String one)
     */
    public void anOperation(AnOperationForm form)
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation1(java.lang.String one, int two)
     */
    public void anOperation1(AnOperation1Form form)
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation2(java.lang.String one, int two, java.lang.String three)
     */
    public void anOperation2(AnOperation2Form form)
    {
    }
    
}