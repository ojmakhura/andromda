// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.notablelink;

/**
 * 
 */
public class ShowTableDataAgainFormImpl
    implements java.io.Serializable
{
    public ShowTableDataAgainFormImpl()
    {
        final java.text.DateFormat customTableThreeDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yy");
        customTableThreeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("customTable.three", customTableThreeDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.util.Collection tableData;

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Resets the value of the tableDataSet to false
     */
    public void resetTableDataSet()
    {
        this.tableDataSet = false;
    }

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataLabelList;
    public java.lang.Object[] getTableDataBackingList()
    {
        java.lang.Object[] values = this.tableDataValueList;
        java.lang.Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(java.lang.Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public java.lang.Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(java.lang.Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new java.lang.Object[items.size()];
            this.tableDataLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private java.util.Collection tableDataBackingValue;

    public void setTableDataBackingValue(java.util.Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }

    public java.util.Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTable;

    /**
     * 
     */
    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTable()
    {
        return this.customTable;
    }

    /**
     * Keeps track of whether or not the value of customTable has
     * be populated at least once.
     */
    private boolean customTableSet = false;

    /**
     * Resets the value of the customTableSet to false
     */
    public void resetCustomTableSet()
    {
        this.customTableSet = false;
    }

    /**
     * Indicates whether or not the value for customTable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCustomTableSet()
    {
        return this.customTableSet;
    }

    /**
     * 
     */
    public void setCustomTable(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTable)
    {
        this.customTable = customTable;
        this.customTableSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableLabelList;
    public java.lang.Object[] getCustomTableBackingList()
    {
        java.lang.Object[] values = this.customTableValueList;
        java.lang.Object[] labels = this.customTableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableValueList()
    {
        return this.customTableValueList;
    }

    public void setCustomTableValueList(java.lang.Object[] customTableValueList)
    {
        this.customTableValueList = customTableValueList;
    }

    public java.lang.Object[] getCustomTableLabelList()
    {
        return this.customTableLabelList;
    }

    public void setCustomTableLabelList(java.lang.Object[] customTableLabelList)
    {
        this.customTableLabelList = customTableLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTableValueList = null;
        this.customTableLabelList = null;
        if (items != null)
        {
            this.customTableValueList = new java.lang.Object[items.size()];
            this.customTableLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTableBackingValue;

    public void setCustomTableBackingValue(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTableBackingValue)
    {
        this.customTableBackingValue = customTableBackingValue;
    }

    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTableBackingValue()
    {
        return this.customTableBackingValue;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableOneValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableOneLabelList;
    public java.lang.Object[] getCustomTableOneBackingList()
    {
        java.lang.Object[] values = this.customTableOneValueList;
        java.lang.Object[] labels = this.customTableOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableOneValueList()
    {
        return this.customTableOneValueList;
    }

    public void setCustomTableOneValueList(java.lang.Object[] customTableOneValueList)
    {
        this.customTableOneValueList = customTableOneValueList;
    }

    public java.lang.Object[] getCustomTableOneLabelList()
    {
        return this.customTableOneLabelList;
    }

    public void setCustomTableOneLabelList(java.lang.Object[] customTableOneLabelList)
    {
        this.customTableOneLabelList = customTableOneLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTableOneValueList = null;
        this.customTableOneLabelList = null;
        if (items != null)
        {
            this.customTableOneValueList = new java.lang.Object[items.size()];
            this.customTableOneLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableOneValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableOneLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableOneLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableTwoValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableTwoLabelList;
    public java.lang.Object[] getCustomTableTwoBackingList()
    {
        java.lang.Object[] values = this.customTableTwoValueList;
        java.lang.Object[] labels = this.customTableTwoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableTwoValueList()
    {
        return this.customTableTwoValueList;
    }

    public void setCustomTableTwoValueList(java.lang.Object[] customTableTwoValueList)
    {
        this.customTableTwoValueList = customTableTwoValueList;
    }

    public java.lang.Object[] getCustomTableTwoLabelList()
    {
        return this.customTableTwoLabelList;
    }

    public void setCustomTableTwoLabelList(java.lang.Object[] customTableTwoLabelList)
    {
        this.customTableTwoLabelList = customTableTwoLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTableTwoValueList = null;
        this.customTableTwoLabelList = null;
        if (items != null)
        {
            this.customTableTwoValueList = new java.lang.Object[items.size()];
            this.customTableTwoLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableTwoValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableTwoLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableTwoLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableThreeValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableThreeLabelList;
    public java.lang.Object[] getCustomTableThreeBackingList()
    {
        java.lang.Object[] values = this.customTableThreeValueList;
        java.lang.Object[] labels = this.customTableThreeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableThreeValueList()
    {
        return this.customTableThreeValueList;
    }

    public void setCustomTableThreeValueList(java.lang.Object[] customTableThreeValueList)
    {
        this.customTableThreeValueList = customTableThreeValueList;
    }

    public java.lang.Object[] getCustomTableThreeLabelList()
    {
        return this.customTableThreeLabelList;
    }

    public void setCustomTableThreeLabelList(java.lang.Object[] customTableThreeLabelList)
    {
        this.customTableThreeLabelList = customTableThreeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableThreeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTableThreeValueList = null;
        this.customTableThreeLabelList = null;
        if (items != null)
        {
            this.customTableThreeValueList = new java.lang.Object[items.size()];
            this.customTableThreeLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableThreeValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableThreeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableThreeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableNoColumnForThisAttributeValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableNoColumnForThisAttributeLabelList;
    public java.lang.Object[] getCustomTableNoColumnForThisAttributeBackingList()
    {
        java.lang.Object[] values = this.customTableNoColumnForThisAttributeValueList;
        java.lang.Object[] labels = this.customTableNoColumnForThisAttributeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableNoColumnForThisAttributeValueList()
    {
        return this.customTableNoColumnForThisAttributeValueList;
    }

    public void setCustomTableNoColumnForThisAttributeValueList(java.lang.Object[] customTableNoColumnForThisAttributeValueList)
    {
        this.customTableNoColumnForThisAttributeValueList = customTableNoColumnForThisAttributeValueList;
    }

    public java.lang.Object[] getCustomTableNoColumnForThisAttributeLabelList()
    {
        return this.customTableNoColumnForThisAttributeLabelList;
    }

    public void setCustomTableNoColumnForThisAttributeLabelList(java.lang.Object[] customTableNoColumnForThisAttributeLabelList)
    {
        this.customTableNoColumnForThisAttributeLabelList = customTableNoColumnForThisAttributeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCustomTableNoColumnForThisAttributeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.customTableNoColumnForThisAttributeValueList = null;
        this.customTableNoColumnForThisAttributeLabelList = null;
        if (items != null)
        {
            this.customTableNoColumnForThisAttributeValueList = new java.lang.Object[items.size()];
            this.customTableNoColumnForThisAttributeLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableNoColumnForThisAttributeValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.customTableNoColumnForThisAttributeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.customTableNoColumnForThisAttributeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTableDataSet();
         this.resetCustomTableSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 3921616634059689695L;
}
