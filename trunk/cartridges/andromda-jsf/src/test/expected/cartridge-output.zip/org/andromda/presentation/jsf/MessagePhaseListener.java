package org.andromda.presentation.jsf;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Iterator;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import oracle.adf.view.faces.context.AdfFacesContext;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * Used to pass messages to the current faces context (this allows messages to live beyond
 * a request, which is very useful when redirecting).
 *
 * @author Chad Brandon
 */
public class MessagePhaseListener
    implements PhaseListener
{
    /**
     * @see javax.faces.event.PhaseListener#beforePhase(PhaseEvent)
     */
    public void beforePhase(PhaseEvent event)
    {
        final Object form = AdfFacesContext.getCurrentInstance().getProcessScope().get("form");
        if (form != null)
        {
            try
            {
                final Collection messages = (Collection)PropertyUtils.getProperty(form, "jsfMessages");
                if (messages != null)
                {
                    for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
                    {
                        FacesContext.getCurrentInstance().addMessage(null, (FacesMessage)iterator.next());
                    }
                    final Method method = form.getClass().getMethod("clearJsfMessages",null);
                    method.invoke(form,null);
                }
            }
            catch (final Exception exception)
            {
                exception.printStackTrace();
            }
        }
    }

    /**
     * @see javax.faces.event.PhaseListener#afterPhase(PhaseEvent)
     */
    public void afterPhase(PhaseEvent event)
    {
        // - don't need this implemented
    }

    /**
     * @see javax.faces.event.PhaseListener#getPhaseId()
     */
    public PhaseId getPhaseId()
    {
        return PhaseId.RENDER_RESPONSE;
    }
}