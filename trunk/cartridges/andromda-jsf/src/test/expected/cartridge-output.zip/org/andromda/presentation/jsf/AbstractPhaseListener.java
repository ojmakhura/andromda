package org.andromda.presentation.jsf;


import java.util.HashMap;
import java.util.Map;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;

/**
 * An abstract phase listener that can be extended, provides some basic functionality (like
 * the prevention of the phase listener being used more than once if it happens to be
 * registered more than once by the container, like seems to happen with myfaces used with liferay).
 *
 * @author Chad Brandon
 */
public abstract class AbstractPhaseListener
    implements PhaseListener
{
    private static final long serialVersionUID = 1L;

    private static Map<Class, Object> firstInstances = new HashMap<Class, Object>();

    private boolean isFirstInstance()
    {
        return firstInstances.get(this.getClass()).equals(this);
    }

    public AbstractPhaseListener()
    {
        if (!firstInstances.containsKey(this.getClass()))
        {
            firstInstances.put(this.getClass(), this);
        }
    }

    /**
     * @see javax.faces.event.PhaseListener#beforePhase(PhaseEvent)
     */
    public void beforePhase(PhaseEvent event)
    {
        if (this.isFirstInstance())
        {
            this.handleBeforePhase(event);
        }
    }

    protected abstract void handleBeforePhase(PhaseEvent event);

    /**
     * @see javax.faces.event.PhaseListener#afterPhase(PhaseEvent)
     */
    public void afterPhase(PhaseEvent event)
    {
        if (this.isFirstInstance())
        {
            this.handleAfterPhase(event);
        }
    }

    protected abstract void handleAfterPhase(PhaseEvent event);

    /**
     * @see javax.faces.event.PhaseListener#getPhaseId()
     */
    public PhaseId getPhaseId()
    {
        return PhaseId.ANY_PHASE;
    }
}