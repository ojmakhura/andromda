package org.andromda.presentation.jsf;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * This filter populates user role constants into the request scope.
 */
public class UserRoleFilter
    implements Filter
{
    /**
     * Initialize the filter
     *
     * @param config the configuration

     */
    public void init(FilterConfig config)
    {
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain)
        throws IOException, ServletException
    {
        final HttpServletRequest httpRequest = (HttpServletRequest)request;
        final boolean userIsJustSomeGuy = httpRequest.isUserInRole("just some guy")
        ;
        httpRequest.setAttribute("userIsJustSomeGuy",  Boolean.valueOf(userIsJustSomeGuy));
        final boolean userIsAdmin = httpRequest.isUserInRole("admin")
        ;
        httpRequest.setAttribute("userIsAdmin",  Boolean.valueOf(userIsAdmin));
        final boolean userIsSpacesInTheName = httpRequest.isUserInRole("spaces in the name")
        ;
        httpRequest.setAttribute("userIsSpacesInTheName",  Boolean.valueOf(userIsSpacesInTheName));
        final boolean userIsMixedCaseName = httpRequest.isUserInRole("miXed Case naMe")
        ;
        httpRequest.setAttribute("userIsMixedCaseName",  Boolean.valueOf(userIsMixedCaseName));
        final boolean userIsWeirdCharacters = httpRequest.isUserInRole("weird %$! characters")
        ;
        httpRequest.setAttribute("userIsWeirdCharacters",  Boolean.valueOf(userIsWeirdCharacters));
        final boolean userIsGuest = httpRequest.isUserInRole("guest")
            || httpRequest.isUserInRole("user")
        ;
        httpRequest.setAttribute("userIsGuest",  Boolean.valueOf(userIsGuest));
        final boolean userIsUser = httpRequest.isUserInRole("user")
            || httpRequest.isUserInRole("admin")
        ;
        httpRequest.setAttribute("userIsUser",  Boolean.valueOf(userIsUser));
        chain.doFilter(
            request,
            response);
    }

    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
    }
}