// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.myfaces.trinidad.model.UploadedFile;

/**
 * 
 */
public class ThreeGoFormImpl
    implements Serializable
{
    public ThreeGoFormImpl()
    {
        final DateFormat dateDateFormatter = new SimpleDateFormat("MM/dd/yyyy");
        dateDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("date", dateDateFormatter);
        this.dateTimeFormatters.put("time", new SimpleDateFormat("HH:mm"));
        final DateFormat dateWithTimeDateFormatter = new SimpleDateFormat("dddd/MM/yyyy HH:mm:ss");
        dateWithTimeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithTime", dateWithTimeDateFormatter);
        final DateFormat dateWithoutCalendarDateFormatter = new SimpleDateFormat("MM/dd/yyyy");
        dateWithoutCalendarDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithoutCalendar", dateWithoutCalendarDateFormatter);
        // - setup the default Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private Date date;

    /**
     * 
     */
    public Date getDate()
    {
        return this.date;
    }

    /**
     * Keeps track of whether or not the value of date has
     * be populated at least once.
     */
    private boolean dateSet = false;

    /**
     * Resets the value of the dateSet to false
     */
    public void resetDateSet()
    {
        this.dateSet = false;
    }

    /**
     * Indicates whether or not the value for date has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateSet()
    {
        return this.dateSet;
    }

    /**
     * 
     */
    public void setDate(Date date)
    {
        this.date = date;
        this.dateSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateValueList;

    /**
     * Stores the labels
     */
    private Object[] dateLabelList;
    public Object[] getDateBackingList()
    {
        Object[] values = this.dateValueList;
        Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDateBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.dateValueList = null;
        this.dateLabelList = null;
        if (items != null)
        {
            this.dateValueList = new Object[items.size()];
            this.dateLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.dateLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.dateLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date time;

    /**
     * 
     */
    public Date getTime()
    {
        return this.time;
    }

    /**
     * Keeps track of whether or not the value of time has
     * be populated at least once.
     */
    private boolean timeSet = false;

    /**
     * Resets the value of the timeSet to false
     */
    public void resetTimeSet()
    {
        this.timeSet = false;
    }

    /**
     * Indicates whether or not the value for time has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTimeSet()
    {
        return this.timeSet;
    }

    /**
     * 
     */
    public void setTime(Date time)
    {
        this.time = time;
        this.timeSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] timeValueList;

    /**
     * Stores the labels
     */
    private Object[] timeLabelList;
    public Object[] getTimeBackingList()
    {
        Object[] values = this.timeValueList;
        Object[] labels = this.timeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTimeValueList()
    {
        return this.timeValueList;
    }

    public void setTimeValueList(Object[] timeValueList)
    {
        this.timeValueList = timeValueList;
    }

    public Object[] getTimeLabelList()
    {
        return this.timeLabelList;
    }

    public void setTimeLabelList(Object[] timeLabelList)
    {
        this.timeLabelList = timeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTimeBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.timeValueList = null;
        this.timeLabelList = null;
        if (items != null)
        {
            this.timeValueList = new Object[items.size()];
            this.timeLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.timeValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.timeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.timeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String text;

    /**
     * 
     */
    public String getText()
    {
        return this.text;
    }

    /**
     * Keeps track of whether or not the value of text has
     * be populated at least once.
     */
    private boolean textSet = false;

    /**
     * Resets the value of the textSet to false
     */
    public void resetTextSet()
    {
        this.textSet = false;
    }

    /**
     * Indicates whether or not the value for text has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextSet()
    {
        return this.textSet;
    }

    /**
     * 
     */
    public void setText(String text)
    {
        this.text = text;
        this.textSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] textValueList;

    /**
     * Stores the labels
     */
    private Object[] textLabelList;
    public Object[] getTextBackingList()
    {
        Object[] values = this.textValueList;
        Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTextBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.textValueList = null;
        this.textLabelList = null;
        if (items != null)
        {
            this.textValueList = new Object[items.size()];
            this.textLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.textValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.textLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.textLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private int number;

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }

    /**
     * Keeps track of whether or not the value of number has
     * be populated at least once.
     */
    private boolean numberSet = false;

    /**
     * Resets the value of the numberSet to false
     */
    public void resetNumberSet()
    {
        this.numberSet = false;
    }

    /**
     * Indicates whether or not the value for number has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isNumberSet()
    {
        return this.numberSet;
    }

    /**
     * 
     */
    public void setNumber(int number)
    {
        this.number = number;
        this.numberSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] numberValueList;

    /**
     * Stores the labels
     */
    private Object[] numberLabelList;
    public Object[] getNumberBackingList()
    {
        Object[] values = this.numberValueList;
        Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setNumberBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.numberValueList = null;
        this.numberLabelList = null;
        if (items != null)
        {
            this.numberValueList = new Object[items.size()];
            this.numberLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.numberValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.numberLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.numberLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Collection collection;

    /**
     * 
     */
    public Collection getCollection()
    {
        return this.collection;
    }

    /**
     * Keeps track of whether or not the value of collection has
     * be populated at least once.
     */
    private boolean collectionSet = false;

    /**
     * Resets the value of the collectionSet to false
     */
    public void resetCollectionSet()
    {
        this.collectionSet = false;
    }

    /**
     * Indicates whether or not the value for collection has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCollectionSet()
    {
        return this.collectionSet;
    }

    /**
     * 
     */
    public void setCollection(Collection collection)
    {
        this.collection = collection;
        this.collectionSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] collectionValueList;

    /**
     * Stores the labels
     */
    private Object[] collectionLabelList;
    public Object[] getCollectionBackingList()
    {
        Object[] values = this.collectionValueList;
        Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCollectionBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.collectionValueList = null;
        this.collectionLabelList = null;
        if (items != null)
        {
            this.collectionValueList = new Object[items.size()];
            this.collectionLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.collectionValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.collectionLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.collectionLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection collectionBackingValue;

    public void setCollectionBackingValue(Collection collectionBackingValue)
    {
        this.collectionBackingValue = collectionBackingValue;
    }

    public Collection getCollectionBackingValue()
    {
        return this.collectionBackingValue;
    }


    private String selectable;

    /**
     * 
     */
    public String getSelectable()
    {
        return this.selectable;
    }

    /**
     * Keeps track of whether or not the value of selectable has
     * be populated at least once.
     */
    private boolean selectableSet = false;

    /**
     * Resets the value of the selectableSet to false
     */
    public void resetSelectableSet()
    {
        this.selectableSet = false;
    }

    /**
     * Indicates whether or not the value for selectable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSelectableSet()
    {
        return this.selectableSet;
    }

    /**
     * 
     */
    public void setSelectable(String selectable)
    {
        this.selectable = selectable;
        this.selectableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] selectableValueList;

    /**
     * Stores the labels
     */
    private Object[] selectableLabelList;
    public Object[] getSelectableBackingList()
    {
        Object[] values = this.selectableValueList;
        Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSelectableBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.selectableValueList = null;
        this.selectableLabelList = null;
        if (items != null)
        {
            this.selectableValueList = new Object[items.size()];
            this.selectableLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.selectableValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.selectableLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.selectableLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private boolean bool;

    /**
     * 
     */
    public boolean isBool()
    {
        return this.bool;
    }

    /**
     * Keeps track of whether or not the value of bool has
     * be populated at least once.
     */
    private boolean boolSet = false;

    /**
     * Resets the value of the boolSet to false
     */
    public void resetBoolSet()
    {
        this.boolSet = false;
    }

    /**
     * Indicates whether or not the value for bool has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBoolSet()
    {
        return this.boolSet;
    }

    /**
     * 
     */
    public void setBool(boolean bool)
    {
        this.bool = bool;
        this.boolSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] boolValueList;

    /**
     * Stores the labels
     */
    private Object[] boolLabelList;
    public Object[] getBoolBackingList()
    {
        Object[] values = this.boolValueList;
        Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setBoolBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.boolValueList = null;
        this.boolLabelList = null;
        if (items != null)
        {
            this.boolValueList = new Object[items.size()];
            this.boolLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.boolValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.boolLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.boolLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Collection multiSelect;

    /**
     * 
     */
    public Collection getMultiSelect()
    {
        return this.multiSelect;
    }

    /**
     * Keeps track of whether or not the value of multiSelect has
     * be populated at least once.
     */
    private boolean multiSelectSet = false;

    /**
     * Resets the value of the multiSelectSet to false
     */
    public void resetMultiSelectSet()
    {
        this.multiSelectSet = false;
    }

    /**
     * Indicates whether or not the value for multiSelect has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiSelectSet()
    {
        return this.multiSelectSet;
    }

    /**
     * 
     */
    public void setMultiSelect(Collection multiSelect)
    {
        this.multiSelect = multiSelect;
        this.multiSelectSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiSelectValueList;

    /**
     * Stores the labels
     */
    private Object[] multiSelectLabelList;
    public Object[] getMultiSelectBackingList()
    {
        Object[] values = this.multiSelectValueList;
        Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMultiSelectBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        if (items != null)
        {
            this.multiSelectValueList = new Object[items.size()];
            this.multiSelectLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiSelectValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.multiSelectLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.multiSelectLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection multiSelectBackingValue;

    public void setMultiSelectBackingValue(Collection multiSelectBackingValue)
    {
        this.multiSelectBackingValue = multiSelectBackingValue;
    }

    public Collection getMultiSelectBackingValue()
    {
        return this.multiSelectBackingValue;
    }


    private String title;

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public String getTitle()
    {
        return this.title;
    }

    /**
     * Keeps track of whether or not the value of title has
     * be populated at least once.
     */
    private boolean titleSet = false;

    /**
     * Resets the value of the titleSet to false
     */
    public void resetTitleSet()
    {
        this.titleSet = false;
    }

    /**
     * Indicates whether or not the value for title has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTitleSet()
    {
        return this.titleSet;
    }

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public void setTitle(String title)
    {
        this.title = title;
        this.titleSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] titleValueList;

    /**
     * Stores the labels
     */
    private Object[] titleLabelList;
    public Object[] getTitleBackingList()
    {
        Object[] values = this.titleValueList;
        Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTitleBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.titleValueList = null;
        this.titleLabelList = null;
        if (items != null)
        {
            this.titleValueList = new Object[items.size()];
            this.titleLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.titleValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.titleLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.titleLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private UploadedFile file;

    /**
     * 
     */
    public UploadedFile getFile()
    {
        return this.file;
    }

    /**
     * Keeps track of whether or not the value of file has
     * be populated at least once.
     */
    private boolean fileSet = false;

    /**
     * Resets the value of the fileSet to false
     */
    public void resetFileSet()
    {
        this.fileSet = false;
    }

    /**
     * Indicates whether or not the value for file has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFileSet()
    {
        return this.fileSet;
    }

    /**
     * 
     */
    public void setFile(UploadedFile file)
    {
        this.file = file;
        this.fileSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] fileValueList;

    /**
     * Stores the labels
     */
    private Object[] fileLabelList;
    public Object[] getFileBackingList()
    {
        Object[] values = this.fileValueList;
        Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFileBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.fileValueList = null;
        this.fileLabelList = null;
        if (items != null)
        {
            this.fileValueList = new Object[items.size()];
            this.fileLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.fileValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.fileLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.fileLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String multiFormat;

    /**
     * 
     */
    public String getMultiFormat()
    {
        return this.multiFormat;
    }

    /**
     * Keeps track of whether or not the value of multiFormat has
     * be populated at least once.
     */
    private boolean multiFormatSet = false;

    /**
     * Resets the value of the multiFormatSet to false
     */
    public void resetMultiFormatSet()
    {
        this.multiFormatSet = false;
    }

    /**
     * Indicates whether or not the value for multiFormat has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiFormatSet()
    {
        return this.multiFormatSet;
    }

    /**
     * 
     */
    public void setMultiFormat(String multiFormat)
    {
        this.multiFormat = multiFormat;
        this.multiFormatSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiFormatValueList;

    /**
     * Stores the labels
     */
    private Object[] multiFormatLabelList;
    public Object[] getMultiFormatBackingList()
    {
        Object[] values = this.multiFormatValueList;
        Object[] labels = this.multiFormatLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiFormatValueList()
    {
        return this.multiFormatValueList;
    }

    public void setMultiFormatValueList(Object[] multiFormatValueList)
    {
        this.multiFormatValueList = multiFormatValueList;
    }

    public Object[] getMultiFormatLabelList()
    {
        return this.multiFormatLabelList;
    }

    public void setMultiFormatLabelList(Object[] multiFormatLabelList)
    {
        this.multiFormatLabelList = multiFormatLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMultiFormatBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;
        if (items != null)
        {
            this.multiFormatValueList = new Object[items.size()];
            this.multiFormatLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiFormatValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.multiFormatLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.multiFormatLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date dateWithTime;

    /**
     * 
     */
    public Date getDateWithTime()
    {
        return this.dateWithTime;
    }

    /**
     * Keeps track of whether or not the value of dateWithTime has
     * be populated at least once.
     */
    private boolean dateWithTimeSet = false;

    /**
     * Resets the value of the dateWithTimeSet to false
     */
    public void resetDateWithTimeSet()
    {
        this.dateWithTimeSet = false;
    }

    /**
     * Indicates whether or not the value for dateWithTime has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithTimeSet()
    {
        return this.dateWithTimeSet;
    }

    /**
     * 
     */
    public void setDateWithTime(Date dateWithTime)
    {
        this.dateWithTime = dateWithTime;
        this.dateWithTimeSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateWithTimeValueList;

    /**
     * Stores the labels
     */
    private Object[] dateWithTimeLabelList;
    public Object[] getDateWithTimeBackingList()
    {
        Object[] values = this.dateWithTimeValueList;
        Object[] labels = this.dateWithTimeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateWithTimeValueList()
    {
        return this.dateWithTimeValueList;
    }

    public void setDateWithTimeValueList(Object[] dateWithTimeValueList)
    {
        this.dateWithTimeValueList = dateWithTimeValueList;
    }

    public Object[] getDateWithTimeLabelList()
    {
        return this.dateWithTimeLabelList;
    }

    public void setDateWithTimeLabelList(Object[] dateWithTimeLabelList)
    {
        this.dateWithTimeLabelList = dateWithTimeLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDateWithTimeBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;
        if (items != null)
        {
            this.dateWithTimeValueList = new Object[items.size()];
            this.dateWithTimeLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateWithTimeValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.dateWithTimeLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.dateWithTimeLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date dateWithoutCalendar;

    /**
     * 
     */
    public Date getDateWithoutCalendar()
    {
        return this.dateWithoutCalendar;
    }

    /**
     * Keeps track of whether or not the value of dateWithoutCalendar has
     * be populated at least once.
     */
    private boolean dateWithoutCalendarSet = false;

    /**
     * Resets the value of the dateWithoutCalendarSet to false
     */
    public void resetDateWithoutCalendarSet()
    {
        this.dateWithoutCalendarSet = false;
    }

    /**
     * Indicates whether or not the value for dateWithoutCalendar has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithoutCalendarSet()
    {
        return this.dateWithoutCalendarSet;
    }

    /**
     * 
     */
    public void setDateWithoutCalendar(Date dateWithoutCalendar)
    {
        this.dateWithoutCalendar = dateWithoutCalendar;
        this.dateWithoutCalendarSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateWithoutCalendarValueList;

    /**
     * Stores the labels
     */
    private Object[] dateWithoutCalendarLabelList;
    public Object[] getDateWithoutCalendarBackingList()
    {
        Object[] values = this.dateWithoutCalendarValueList;
        Object[] labels = this.dateWithoutCalendarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateWithoutCalendarValueList()
    {
        return this.dateWithoutCalendarValueList;
    }

    public void setDateWithoutCalendarValueList(Object[] dateWithoutCalendarValueList)
    {
        this.dateWithoutCalendarValueList = dateWithoutCalendarValueList;
    }

    public Object[] getDateWithoutCalendarLabelList()
    {
        return this.dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarLabelList(Object[] dateWithoutCalendarLabelList)
    {
        this.dateWithoutCalendarLabelList = dateWithoutCalendarLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDateWithoutCalendarBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;
        if (items != null)
        {
            this.dateWithoutCalendarValueList = new Object[items.size()];
            this.dateWithoutCalendarLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateWithoutCalendarValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.dateWithoutCalendarLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.dateWithoutCalendarLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String hasCustomValidator;

    /**
     * 
     */
    public String getHasCustomValidator()
    {
        return this.hasCustomValidator;
    }

    /**
     * Keeps track of whether or not the value of hasCustomValidator has
     * be populated at least once.
     */
    private boolean hasCustomValidatorSet = false;

    /**
     * Resets the value of the hasCustomValidatorSet to false
     */
    public void resetHasCustomValidatorSet()
    {
        this.hasCustomValidatorSet = false;
    }

    /**
     * Indicates whether or not the value for hasCustomValidator has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHasCustomValidatorSet()
    {
        return this.hasCustomValidatorSet;
    }

    /**
     * 
     */
    public void setHasCustomValidator(String hasCustomValidator)
    {
        this.hasCustomValidator = hasCustomValidator;
        this.hasCustomValidatorSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] hasCustomValidatorValueList;

    /**
     * Stores the labels
     */
    private Object[] hasCustomValidatorLabelList;
    public Object[] getHasCustomValidatorBackingList()
    {
        Object[] values = this.hasCustomValidatorValueList;
        Object[] labels = this.hasCustomValidatorLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getHasCustomValidatorValueList()
    {
        return this.hasCustomValidatorValueList;
    }

    public void setHasCustomValidatorValueList(Object[] hasCustomValidatorValueList)
    {
        this.hasCustomValidatorValueList = hasCustomValidatorValueList;
    }

    public Object[] getHasCustomValidatorLabelList()
    {
        return this.hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorLabelList(Object[] hasCustomValidatorLabelList)
    {
        this.hasCustomValidatorLabelList = hasCustomValidatorLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setHasCustomValidatorBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;
        if (items != null)
        {
            this.hasCustomValidatorValueList = new Object[items.size()];
            this.hasCustomValidatorLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.hasCustomValidatorValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.hasCustomValidatorLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.hasCustomValidatorLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Integer integerClass;

    /**
     * 
     */
    public Integer getIntegerClass()
    {
        return this.integerClass;
    }

    /**
     * Keeps track of whether or not the value of integerClass has
     * be populated at least once.
     */
    private boolean integerClassSet = false;

    /**
     * Resets the value of the integerClassSet to false
     */
    public void resetIntegerClassSet()
    {
        this.integerClassSet = false;
    }

    /**
     * Indicates whether or not the value for integerClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntegerClassSet()
    {
        return this.integerClassSet;
    }

    /**
     * 
     */
    public void setIntegerClass(Integer integerClass)
    {
        this.integerClass = integerClass;
        this.integerClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] integerClassValueList;

    /**
     * Stores the labels
     */
    private Object[] integerClassLabelList;
    public Object[] getIntegerClassBackingList()
    {
        Object[] values = this.integerClassValueList;
        Object[] labels = this.integerClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getIntegerClassValueList()
    {
        return this.integerClassValueList;
    }

    public void setIntegerClassValueList(Object[] integerClassValueList)
    {
        this.integerClassValueList = integerClassValueList;
    }

    public Object[] getIntegerClassLabelList()
    {
        return this.integerClassLabelList;
    }

    public void setIntegerClassLabelList(Object[] integerClassLabelList)
    {
        this.integerClassLabelList = integerClassLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setIntegerClassBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.integerClassValueList = null;
        this.integerClassLabelList = null;
        if (items != null)
        {
            this.integerClassValueList = new Object[items.size()];
            this.integerClassLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.integerClassValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.integerClassLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.integerClassLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Collection setClass;

    /**
     * 
     */
    public Collection getSetClass()
    {
        return this.setClass;
    }

    /**
     * Keeps track of whether or not the value of setClass has
     * be populated at least once.
     */
    private boolean setClassSet = false;

    /**
     * Resets the value of the setClassSet to false
     */
    public void resetSetClassSet()
    {
        this.setClassSet = false;
    }

    /**
     * Indicates whether or not the value for setClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSetClassSet()
    {
        return this.setClassSet;
    }

    /**
     * 
     */
    public void setSetClass(Collection setClass)
    {
        this.setClass = setClass;
        this.setClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] setClassValueList;

    /**
     * Stores the labels
     */
    private Object[] setClassLabelList;
    public Object[] getSetClassBackingList()
    {
        Object[] values = this.setClassValueList;
        Object[] labels = this.setClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSetClassValueList()
    {
        return this.setClassValueList;
    }

    public void setSetClassValueList(Object[] setClassValueList)
    {
        this.setClassValueList = setClassValueList;
    }

    public Object[] getSetClassLabelList()
    {
        return this.setClassLabelList;
    }

    public void setSetClassLabelList(Object[] setClassLabelList)
    {
        this.setClassLabelList = setClassLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSetClassBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setClassValueList = null;
        this.setClassLabelList = null;
        if (items != null)
        {
            this.setClassValueList = new Object[items.size()];
            this.setClassLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.setClassValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.setClassLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.setClassLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Set setClassBackingValue;

    public void setSetClassBackingValue(Set setClassBackingValue)
    {
        this.setClassBackingValue = setClassBackingValue;
    }

    public Set getSetClassBackingValue()
    {
        return this.setClassBackingValue;
    }


    private Map mapClass;

    /**
     * 
     */
    public Map getMapClass()
    {
        return this.mapClass;
    }

    /**
     * Keeps track of whether or not the value of mapClass has
     * be populated at least once.
     */
    private boolean mapClassSet = false;

    /**
     * Resets the value of the mapClassSet to false
     */
    public void resetMapClassSet()
    {
        this.mapClassSet = false;
    }

    /**
     * Indicates whether or not the value for mapClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMapClassSet()
    {
        return this.mapClassSet;
    }

    /**
     * 
     */
    public void setMapClass(Map mapClass)
    {
        this.mapClass = mapClass;
        this.mapClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] mapClassValueList;

    /**
     * Stores the labels
     */
    private Object[] mapClassLabelList;
    public Object[] getMapClassBackingList()
    {
        Object[] values = this.mapClassValueList;
        Object[] labels = this.mapClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMapClassValueList()
    {
        return this.mapClassValueList;
    }

    public void setMapClassValueList(Object[] mapClassValueList)
    {
        this.mapClassValueList = mapClassValueList;
    }

    public Object[] getMapClassLabelList()
    {
        return this.mapClassLabelList;
    }

    public void setMapClassLabelList(Object[] mapClassLabelList)
    {
        this.mapClassLabelList = mapClassLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMapClassBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.mapClassValueList = null;
        this.mapClassLabelList = null;
        if (items != null)
        {
            this.mapClassValueList = new Object[items.size()];
            this.mapClassLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.mapClassValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.mapClassLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.mapClassLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Boolean booleanClass;

    /**
     * 
     */
    public Boolean getBooleanClass()
    {
        return this.booleanClass;
    }

    /**
     * Keeps track of whether or not the value of booleanClass has
     * be populated at least once.
     */
    private boolean booleanClassSet = false;

    /**
     * Resets the value of the booleanClassSet to false
     */
    public void resetBooleanClassSet()
    {
        this.booleanClassSet = false;
    }

    /**
     * Indicates whether or not the value for booleanClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBooleanClassSet()
    {
        return this.booleanClassSet;
    }

    /**
     * 
     */
    public void setBooleanClass(Boolean booleanClass)
    {
        this.booleanClass = booleanClass;
        this.booleanClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] booleanClassValueList;

    /**
     * Stores the labels
     */
    private Object[] booleanClassLabelList;
    public Object[] getBooleanClassBackingList()
    {
        Object[] values = this.booleanClassValueList;
        Object[] labels = this.booleanClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBooleanClassValueList()
    {
        return this.booleanClassValueList;
    }

    public void setBooleanClassValueList(Object[] booleanClassValueList)
    {
        this.booleanClassValueList = booleanClassValueList;
    }

    public Object[] getBooleanClassLabelList()
    {
        return this.booleanClassLabelList;
    }

    public void setBooleanClassLabelList(Object[] booleanClassLabelList)
    {
        this.booleanClassLabelList = booleanClassLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setBooleanClassBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;
        if (items != null)
        {
            this.booleanClassValueList = new Object[items.size()];
            this.booleanClassLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.booleanClassValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.booleanClassLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.booleanClassLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Float floatClass;

    /**
     * 
     */
    public Float getFloatClass()
    {
        return this.floatClass;
    }

    /**
     * Keeps track of whether or not the value of floatClass has
     * be populated at least once.
     */
    private boolean floatClassSet = false;

    /**
     * Resets the value of the floatClassSet to false
     */
    public void resetFloatClassSet()
    {
        this.floatClassSet = false;
    }

    /**
     * Indicates whether or not the value for floatClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatClassSet()
    {
        return this.floatClassSet;
    }

    /**
     * 
     */
    public void setFloatClass(Float floatClass)
    {
        this.floatClass = floatClass;
        this.floatClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] floatClassValueList;

    /**
     * Stores the labels
     */
    private Object[] floatClassLabelList;
    public Object[] getFloatClassBackingList()
    {
        Object[] values = this.floatClassValueList;
        Object[] labels = this.floatClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFloatClassValueList()
    {
        return this.floatClassValueList;
    }

    public void setFloatClassValueList(Object[] floatClassValueList)
    {
        this.floatClassValueList = floatClassValueList;
    }

    public Object[] getFloatClassLabelList()
    {
        return this.floatClassLabelList;
    }

    public void setFloatClassLabelList(Object[] floatClassLabelList)
    {
        this.floatClassLabelList = floatClassLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFloatClassBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.floatClassValueList = null;
        this.floatClassLabelList = null;
        if (items != null)
        {
            this.floatClassValueList = new Object[items.size()];
            this.floatClassLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.floatClassValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.floatClassLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.floatClassLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String hiddenWithDefaultValue = "someDefaultValue";

    /**
     * 
     */
    public String getHiddenWithDefaultValue()
    {
        return this.hiddenWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of hiddenWithDefaultValue has
     * be populated at least once.
     */
    private boolean hiddenWithDefaultValueSet = false;

    /**
     * Resets the value of the hiddenWithDefaultValueSet to false
     */
    public void resetHiddenWithDefaultValueSet()
    {
        this.hiddenWithDefaultValueSet = false;
    }

    /**
     * Indicates whether or not the value for hiddenWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenWithDefaultValueSet()
    {
        return this.hiddenWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setHiddenWithDefaultValue(String hiddenWithDefaultValue)
    {
        this.hiddenWithDefaultValue = hiddenWithDefaultValue;
        this.hiddenWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] hiddenWithDefaultValueValueList;

    /**
     * Stores the labels
     */
    private Object[] hiddenWithDefaultValueLabelList;
    public Object[] getHiddenWithDefaultValueBackingList()
    {
        Object[] values = this.hiddenWithDefaultValueValueList;
        Object[] labels = this.hiddenWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getHiddenWithDefaultValueValueList()
    {
        return this.hiddenWithDefaultValueValueList;
    }

    public void setHiddenWithDefaultValueValueList(Object[] hiddenWithDefaultValueValueList)
    {
        this.hiddenWithDefaultValueValueList = hiddenWithDefaultValueValueList;
    }

    public Object[] getHiddenWithDefaultValueLabelList()
    {
        return this.hiddenWithDefaultValueLabelList;
    }

    public void setHiddenWithDefaultValueLabelList(Object[] hiddenWithDefaultValueLabelList)
    {
        this.hiddenWithDefaultValueLabelList = hiddenWithDefaultValueLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setHiddenWithDefaultValueBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.hiddenWithDefaultValueValueList = null;
        this.hiddenWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.hiddenWithDefaultValueValueList = new Object[items.size()];
            this.hiddenWithDefaultValueLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.hiddenWithDefaultValueValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.hiddenWithDefaultValueLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.hiddenWithDefaultValueLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String bAdName;

    /**
     * 
     */
    public String getBAdName()
    {
        return this.bAdName;
    }

    /**
     * Keeps track of whether or not the value of bAdName has
     * be populated at least once.
     */
    private boolean bAdNameSet = false;

    /**
     * Resets the value of the bAdNameSet to false
     */
    public void resetBAdNameSet()
    {
        this.bAdNameSet = false;
    }

    /**
     * Indicates whether or not the value for bAdName has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBAdNameSet()
    {
        return this.bAdNameSet;
    }

    /**
     * 
     */
    public void setBAdName(String bAdName)
    {
        this.bAdName = bAdName;
        this.bAdNameSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] bAdNameValueList;

    /**
     * Stores the labels
     */
    private Object[] bAdNameLabelList;
    public Object[] getBAdNameBackingList()
    {
        Object[] values = this.bAdNameValueList;
        Object[] labels = this.bAdNameLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBAdNameValueList()
    {
        return this.bAdNameValueList;
    }

    public void setBAdNameValueList(Object[] bAdNameValueList)
    {
        this.bAdNameValueList = bAdNameValueList;
    }

    public Object[] getBAdNameLabelList()
    {
        return this.bAdNameLabelList;
    }

    public void setBAdNameLabelList(Object[] bAdNameLabelList)
    {
        this.bAdNameLabelList = bAdNameLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setBAdNameBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.bAdNameValueList = null;
        this.bAdNameLabelList = null;
        if (items != null)
        {
            this.bAdNameValueList = new Object[items.size()];
            this.bAdNameLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.bAdNameValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.bAdNameLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.bAdNameLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private SubValueObject complexParameter;

    /**
     * 
     */
    public SubValueObject getComplexParameter()
    {
        if (this.complexParameter == null)
        {
            this.complexParameter = new SubValueObject();
            this.setComplexParameter(this.complexParameter);
        }
        return this.complexParameter;
    }

    /**
     * Keeps track of whether or not the value of complexParameter has
     * be populated at least once.
     */
    private boolean complexParameterSet = false;

    /**
     * Resets the value of the complexParameterSet to false
     */
    public void resetComplexParameterSet()
    {
        this.complexParameterSet = false;
    }

    /**
     * Indicates whether or not the value for complexParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isComplexParameterSet()
    {
        return this.complexParameterSet;
    }

    /**
     * 
     */
    public void setComplexParameter(SubValueObject complexParameter)
    {
        this.complexParameter = complexParameter;
        this.complexParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] complexParameterValueList;

    /**
     * Stores the labels
     */
    private Object[] complexParameterLabelList;
    public Object[] getComplexParameterBackingList()
    {
        Object[] values = this.complexParameterValueList;
        Object[] labels = this.complexParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getComplexParameterValueList()
    {
        return this.complexParameterValueList;
    }

    public void setComplexParameterValueList(Object[] complexParameterValueList)
    {
        this.complexParameterValueList = complexParameterValueList;
    }

    public Object[] getComplexParameterLabelList()
    {
        return this.complexParameterLabelList;
    }

    public void setComplexParameterLabelList(Object[] complexParameterLabelList)
    {
        this.complexParameterLabelList = complexParameterLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setComplexParameterBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.complexParameterValueList = null;
        this.complexParameterLabelList = null;
        if (items != null)
        {
            this.complexParameterValueList = new Object[items.size()];
            this.complexParameterLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.complexParameterValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.complexParameterLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.complexParameterLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private Object[] complexParameterSubValueObjectAttributeOneValueList;

    /**
     * Stores the labels
     */
    private Object[] complexParameterSubValueObjectAttributeOneLabelList;
    public Object[] getComplexParameterSubValueObjectAttributeOneBackingList()
    {
        Object[] values = this.complexParameterSubValueObjectAttributeOneValueList;
        Object[] labels = this.complexParameterSubValueObjectAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getComplexParameterSubValueObjectAttributeOneValueList()
    {
        return this.complexParameterSubValueObjectAttributeOneValueList;
    }

    public void setComplexParameterSubValueObjectAttributeOneValueList(Object[] complexParameterSubValueObjectAttributeOneValueList)
    {
        this.complexParameterSubValueObjectAttributeOneValueList = complexParameterSubValueObjectAttributeOneValueList;
    }

    public Object[] getComplexParameterSubValueObjectAttributeOneLabelList()
    {
        return this.complexParameterSubValueObjectAttributeOneLabelList;
    }

    public void setComplexParameterSubValueObjectAttributeOneLabelList(Object[] complexParameterSubValueObjectAttributeOneLabelList)
    {
        this.complexParameterSubValueObjectAttributeOneLabelList = complexParameterSubValueObjectAttributeOneLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setComplexParameterSubValueObjectAttributeOneBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.complexParameterSubValueObjectAttributeOneValueList = null;
        this.complexParameterSubValueObjectAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterSubValueObjectAttributeOneValueList = new Object[items.size()];
            this.complexParameterSubValueObjectAttributeOneLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.complexParameterSubValueObjectAttributeOneValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.complexParameterSubValueObjectAttributeOneLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.complexParameterSubValueObjectAttributeOneLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }

    /**
     * Stores the values.
     */
    private Object[] complexParameterRootAttributeOneValueList;

    /**
     * Stores the labels
     */
    private Object[] complexParameterRootAttributeOneLabelList;
    public Object[] getComplexParameterRootAttributeOneBackingList()
    {
        Object[] values = this.complexParameterRootAttributeOneValueList;
        Object[] labels = this.complexParameterRootAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getComplexParameterRootAttributeOneValueList()
    {
        return this.complexParameterRootAttributeOneValueList;
    }

    public void setComplexParameterRootAttributeOneValueList(Object[] complexParameterRootAttributeOneValueList)
    {
        this.complexParameterRootAttributeOneValueList = complexParameterRootAttributeOneValueList;
    }

    public Object[] getComplexParameterRootAttributeOneLabelList()
    {
        return this.complexParameterRootAttributeOneLabelList;
    }

    public void setComplexParameterRootAttributeOneLabelList(Object[] complexParameterRootAttributeOneLabelList)
    {
        this.complexParameterRootAttributeOneLabelList = complexParameterRootAttributeOneLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setComplexParameterRootAttributeOneBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.complexParameterRootAttributeOneValueList = null;
        this.complexParameterRootAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterRootAttributeOneValueList = new Object[items.size()];
            this.complexParameterRootAttributeOneLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.complexParameterRootAttributeOneValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.complexParameterRootAttributeOneLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.complexParameterRootAttributeOneLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetDateSet();
         this.resetTimeSet();
         this.resetTextSet();
         this.resetNumberSet();
         this.resetCollectionSet();
         this.resetSelectableSet();
         this.resetBoolSet();
         this.resetMultiSelectSet();
         this.resetTitleSet();
         this.resetFileSet();
         this.resetMultiFormatSet();
         this.resetDateWithTimeSet();
         this.resetDateWithoutCalendarSet();
         this.resetHasCustomValidatorSet();
         this.resetIntegerClassSet();
         this.resetSetClassSet();
         this.resetMapClassSet();
         this.resetBooleanClassSet();
         this.resetFloatClassSet();
         this.resetHiddenWithDefaultValueSet();
         this.resetBAdNameSet();
         this.resetComplexParameterSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -8807402253146928878L;
}
