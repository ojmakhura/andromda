package org.andromda.cartridges.jsf.tests.validation;

/**
 * Stores all forward paths available in the use case Validation Activity keyed by forward name.
 */
final class ValidationActivityForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("validation-activity-usecase", "/org/andromda/cartridges/jsf/tests/validation/validation-activity.jsf");
            forwards.put("enter-data", "/org/andromda/cartridges/jsf/tests/validation/enter-data.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}