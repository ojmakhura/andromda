// license-header java merge-point
package org.andromda.cartridges.jsf.tests.validation;

import java.io.Serializable;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class EnterDataValidateFormImpl
    implements Serializable
{
    public EnterDataValidateFormImpl()
    {
        final DateFormat lenientDateTestDateFormatter = new SimpleDateFormat("dd/MMM/yyyy");
        lenientDateTestDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("lenientDateTest", lenientDateTestDateFormatter);
        final DateFormat strictDateTestDateFormatter = new SimpleDateFormat("strict dd/MM/yyyy");
        strictDateTestDateFormatter.setLenient(false);
        this.dateTimeFormatters.put("strictDateTest", strictDateTestDateFormatter);
        final DateFormat hiddenNotValidatedDateFormatter = new SimpleDateFormat("MM/dd/yyyy");
        hiddenNotValidatedDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("hiddenNotValidated", hiddenNotValidatedDateFormatter);
        // - setup the default Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private String minlengthTest;

    /**
     * 
     */
    public String getMinlengthTest()
    {
        return this.minlengthTest;
    }

    /**
     * Keeps track of whether or not the value of minlengthTest has
     * be populated at least once.
     */
    private boolean minlengthTestSet = false;

    /**
     * Resets the value of the minlengthTestSet to false
     */
    public void resetMinlengthTestSet()
    {
        this.minlengthTestSet = false;
    }

    /**
     * Indicates whether or not the value for minlengthTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMinlengthTestSet()
    {
        return this.minlengthTestSet;
    }

    /**
     * 
     */
    public void setMinlengthTest(String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
        this.minlengthTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] minlengthTestValueList;

    /**
     * Stores the labels
     */
    private Object[] minlengthTestLabelList;
    public Object[] getMinlengthTestBackingList()
    {
        Object[] values = this.minlengthTestValueList;
        Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMinlengthTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;
        if (items != null)
        {
            this.minlengthTestValueList = new Object[items.size()];
            this.minlengthTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.minlengthTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.minlengthTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.minlengthTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String maxlengthTest;

    /**
     * 
     */
    public String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }

    /**
     * Keeps track of whether or not the value of maxlengthTest has
     * be populated at least once.
     */
    private boolean maxlengthTestSet = false;

    /**
     * Resets the value of the maxlengthTestSet to false
     */
    public void resetMaxlengthTestSet()
    {
        this.maxlengthTestSet = false;
    }

    /**
     * Indicates whether or not the value for maxlengthTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMaxlengthTestSet()
    {
        return this.maxlengthTestSet;
    }

    /**
     * 
     */
    public void setMaxlengthTest(String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
        this.maxlengthTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] maxlengthTestValueList;

    /**
     * Stores the labels
     */
    private Object[] maxlengthTestLabelList;
    public Object[] getMaxlengthTestBackingList()
    {
        Object[] values = this.maxlengthTestValueList;
        Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMaxlengthTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;
        if (items != null)
        {
            this.maxlengthTestValueList = new Object[items.size()];
            this.maxlengthTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.maxlengthTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.maxlengthTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.maxlengthTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String patternTest;

    /**
     * 
     */
    public String getPatternTest()
    {
        return this.patternTest;
    }

    /**
     * Keeps track of whether or not the value of patternTest has
     * be populated at least once.
     */
    private boolean patternTestSet = false;

    /**
     * Resets the value of the patternTestSet to false
     */
    public void resetPatternTestSet()
    {
        this.patternTestSet = false;
    }

    /**
     * Indicates whether or not the value for patternTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPatternTestSet()
    {
        return this.patternTestSet;
    }

    /**
     * 
     */
    public void setPatternTest(String patternTest)
    {
        this.patternTest = patternTest;
        this.patternTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] patternTestValueList;

    /**
     * Stores the labels
     */
    private Object[] patternTestLabelList;
    public Object[] getPatternTestBackingList()
    {
        Object[] values = this.patternTestValueList;
        Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setPatternTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.patternTestValueList = null;
        this.patternTestLabelList = null;
        if (items != null)
        {
            this.patternTestValueList = new Object[items.size()];
            this.patternTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.patternTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.patternTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.patternTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String creditcardTest;

    /**
     * 
     */
    public String getCreditcardTest()
    {
        return this.creditcardTest;
    }

    /**
     * Keeps track of whether or not the value of creditcardTest has
     * be populated at least once.
     */
    private boolean creditcardTestSet = false;

    /**
     * Resets the value of the creditcardTestSet to false
     */
    public void resetCreditcardTestSet()
    {
        this.creditcardTestSet = false;
    }

    /**
     * Indicates whether or not the value for creditcardTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCreditcardTestSet()
    {
        return this.creditcardTestSet;
    }

    /**
     * 
     */
    public void setCreditcardTest(String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
        this.creditcardTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] creditcardTestValueList;

    /**
     * Stores the labels
     */
    private Object[] creditcardTestLabelList;
    public Object[] getCreditcardTestBackingList()
    {
        Object[] values = this.creditcardTestValueList;
        Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setCreditcardTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;
        if (items != null)
        {
            this.creditcardTestValueList = new Object[items.size()];
            this.creditcardTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.creditcardTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.creditcardTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.creditcardTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String emailTest;

    /**
     * 
     */
    public String getEmailTest()
    {
        return this.emailTest;
    }

    /**
     * Keeps track of whether or not the value of emailTest has
     * be populated at least once.
     */
    private boolean emailTestSet = false;

    /**
     * Resets the value of the emailTestSet to false
     */
    public void resetEmailTestSet()
    {
        this.emailTestSet = false;
    }

    /**
     * Indicates whether or not the value for emailTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isEmailTestSet()
    {
        return this.emailTestSet;
    }

    /**
     * 
     */
    public void setEmailTest(String emailTest)
    {
        this.emailTest = emailTest;
        this.emailTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] emailTestValueList;

    /**
     * Stores the labels
     */
    private Object[] emailTestLabelList;
    public Object[] getEmailTestBackingList()
    {
        Object[] values = this.emailTestValueList;
        Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setEmailTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.emailTestValueList = null;
        this.emailTestLabelList = null;
        if (items != null)
        {
            this.emailTestValueList = new Object[items.size()];
            this.emailTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.emailTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.emailTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.emailTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private URL urlTest;

    /**
     * 
     */
    public URL getUrlTest()
    {
        return this.urlTest;
    }

    /**
     * Keeps track of whether or not the value of urlTest has
     * be populated at least once.
     */
    private boolean urlTestSet = false;

    /**
     * Resets the value of the urlTestSet to false
     */
    public void resetUrlTestSet()
    {
        this.urlTestSet = false;
    }

    /**
     * Indicates whether or not the value for urlTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUrlTestSet()
    {
        return this.urlTestSet;
    }

    /**
     * 
     */
    public void setUrlTest(URL urlTest)
    {
        this.urlTest = urlTest;
        this.urlTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] urlTestValueList;

    /**
     * Stores the labels
     */
    private Object[] urlTestLabelList;
    public Object[] getUrlTestBackingList()
    {
        Object[] values = this.urlTestValueList;
        Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setUrlTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.urlTestValueList = null;
        this.urlTestLabelList = null;
        if (items != null)
        {
            this.urlTestValueList = new Object[items.size()];
            this.urlTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.urlTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.urlTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.urlTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private int intRangeTest;

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }

    /**
     * Keeps track of whether or not the value of intRangeTest has
     * be populated at least once.
     */
    private boolean intRangeTestSet = false;

    /**
     * Resets the value of the intRangeTestSet to false
     */
    public void resetIntRangeTestSet()
    {
        this.intRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for intRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntRangeTestSet()
    {
        return this.intRangeTestSet;
    }

    /**
     * 
     */
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
        this.intRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] intRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] intRangeTestLabelList;
    public Object[] getIntRangeTestBackingList()
    {
        Object[] values = this.intRangeTestValueList;
        Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setIntRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;
        if (items != null)
        {
            this.intRangeTestValueList = new Object[items.size()];
            this.intRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.intRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.intRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.intRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private float floatRangeTest;

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }

    /**
     * Keeps track of whether or not the value of floatRangeTest has
     * be populated at least once.
     */
    private boolean floatRangeTestSet = false;

    /**
     * Resets the value of the floatRangeTestSet to false
     */
    public void resetFloatRangeTestSet()
    {
        this.floatRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for floatRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatRangeTestSet()
    {
        return this.floatRangeTestSet;
    }

    /**
     * 
     */
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
        this.floatRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] floatRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] floatRangeTestLabelList;
    public Object[] getFloatRangeTestBackingList()
    {
        Object[] values = this.floatRangeTestValueList;
        Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFloatRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;
        if (items != null)
        {
            this.floatRangeTestValueList = new Object[items.size()];
            this.floatRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.floatRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.floatRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.floatRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private double doubleRangeTest;

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }

    /**
     * Keeps track of whether or not the value of doubleRangeTest has
     * be populated at least once.
     */
    private boolean doubleRangeTestSet = false;

    /**
     * Resets the value of the doubleRangeTestSet to false
     */
    public void resetDoubleRangeTestSet()
    {
        this.doubleRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for doubleRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDoubleRangeTestSet()
    {
        return this.doubleRangeTestSet;
    }

    /**
     * 
     */
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
        this.doubleRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] doubleRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] doubleRangeTestLabelList;
    public Object[] getDoubleRangeTestBackingList()
    {
        Object[] values = this.doubleRangeTestValueList;
        Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDoubleRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;
        if (items != null)
        {
            this.doubleRangeTestValueList = new Object[items.size()];
            this.doubleRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.doubleRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.doubleRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.doubleRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Integer intWrapperRangeTest;

    /**
     * 
     */
    public Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of intWrapperRangeTest has
     * be populated at least once.
     */
    private boolean intWrapperRangeTestSet = false;

    /**
     * Resets the value of the intWrapperRangeTestSet to false
     */
    public void resetIntWrapperRangeTestSet()
    {
        this.intWrapperRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for intWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntWrapperRangeTestSet()
    {
        return this.intWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setIntWrapperRangeTest(Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
        this.intWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] intWrapperRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] intWrapperRangeTestLabelList;
    public Object[] getIntWrapperRangeTestBackingList()
    {
        Object[] values = this.intWrapperRangeTestValueList;
        Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setIntWrapperRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.intWrapperRangeTestValueList = new Object[items.size()];
            this.intWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.intWrapperRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.intWrapperRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.intWrapperRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Float floatWrapperRangeTest;

    /**
     * 
     */
    public Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of floatWrapperRangeTest has
     * be populated at least once.
     */
    private boolean floatWrapperRangeTestSet = false;

    /**
     * Resets the value of the floatWrapperRangeTestSet to false
     */
    public void resetFloatWrapperRangeTestSet()
    {
        this.floatWrapperRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for floatWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatWrapperRangeTestSet()
    {
        return this.floatWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setFloatWrapperRangeTest(Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
        this.floatWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] floatWrapperRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] floatWrapperRangeTestLabelList;
    public Object[] getFloatWrapperRangeTestBackingList()
    {
        Object[] values = this.floatWrapperRangeTestValueList;
        Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFloatWrapperRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.floatWrapperRangeTestValueList = new Object[items.size()];
            this.floatWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.floatWrapperRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.floatWrapperRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.floatWrapperRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Double doubleWrapperRangeTest;

    /**
     * 
     */
    public Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of doubleWrapperRangeTest has
     * be populated at least once.
     */
    private boolean doubleWrapperRangeTestSet = false;

    /**
     * Resets the value of the doubleWrapperRangeTestSet to false
     */
    public void resetDoubleWrapperRangeTestSet()
    {
        this.doubleWrapperRangeTestSet = false;
    }

    /**
     * Indicates whether or not the value for doubleWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDoubleWrapperRangeTestSet()
    {
        return this.doubleWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setDoubleWrapperRangeTest(Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
        this.doubleWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] doubleWrapperRangeTestValueList;

    /**
     * Stores the labels
     */
    private Object[] doubleWrapperRangeTestLabelList;
    public Object[] getDoubleWrapperRangeTestBackingList()
    {
        Object[] values = this.doubleWrapperRangeTestValueList;
        Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDoubleWrapperRangeTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.doubleWrapperRangeTestValueList = new Object[items.size()];
            this.doubleWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.doubleWrapperRangeTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.doubleWrapperRangeTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.doubleWrapperRangeTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date lenientDateTest;

    /**
     * 
     */
    public Date getLenientDateTest()
    {
        return this.lenientDateTest;
    }

    /**
     * Keeps track of whether or not the value of lenientDateTest has
     * be populated at least once.
     */
    private boolean lenientDateTestSet = false;

    /**
     * Resets the value of the lenientDateTestSet to false
     */
    public void resetLenientDateTestSet()
    {
        this.lenientDateTestSet = false;
    }

    /**
     * Indicates whether or not the value for lenientDateTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isLenientDateTestSet()
    {
        return this.lenientDateTestSet;
    }

    /**
     * 
     */
    public void setLenientDateTest(Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
        this.lenientDateTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] lenientDateTestValueList;

    /**
     * Stores the labels
     */
    private Object[] lenientDateTestLabelList;
    public Object[] getLenientDateTestBackingList()
    {
        Object[] values = this.lenientDateTestValueList;
        Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setLenientDateTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;
        if (items != null)
        {
            this.lenientDateTestValueList = new Object[items.size()];
            this.lenientDateTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.lenientDateTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.lenientDateTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.lenientDateTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date strictDateTest;

    /**
     * 
     */
    public Date getStrictDateTest()
    {
        return this.strictDateTest;
    }

    /**
     * Keeps track of whether or not the value of strictDateTest has
     * be populated at least once.
     */
    private boolean strictDateTestSet = false;

    /**
     * Resets the value of the strictDateTestSet to false
     */
    public void resetStrictDateTestSet()
    {
        this.strictDateTestSet = false;
    }

    /**
     * Indicates whether or not the value for strictDateTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isStrictDateTestSet()
    {
        return this.strictDateTestSet;
    }

    /**
     * 
     */
    public void setStrictDateTest(Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
        this.strictDateTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] strictDateTestValueList;

    /**
     * Stores the labels
     */
    private Object[] strictDateTestLabelList;
    public Object[] getStrictDateTestBackingList()
    {
        Object[] values = this.strictDateTestValueList;
        Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setStrictDateTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;
        if (items != null)
        {
            this.strictDateTestValueList = new Object[items.size()];
            this.strictDateTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.strictDateTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.strictDateTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.strictDateTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String requiredTest;

    /**
     * 
     */
    public String getRequiredTest()
    {
        return this.requiredTest;
    }

    /**
     * Keeps track of whether or not the value of requiredTest has
     * be populated at least once.
     */
    private boolean requiredTestSet = false;

    /**
     * Resets the value of the requiredTestSet to false
     */
    public void resetRequiredTestSet()
    {
        this.requiredTestSet = false;
    }

    /**
     * Indicates whether or not the value for requiredTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRequiredTestSet()
    {
        return this.requiredTestSet;
    }

    /**
     * 
     */
    public void setRequiredTest(String requiredTest)
    {
        this.requiredTest = requiredTest;
        this.requiredTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] requiredTestValueList;

    /**
     * Stores the labels
     */
    private Object[] requiredTestLabelList;
    public Object[] getRequiredTestBackingList()
    {
        Object[] values = this.requiredTestValueList;
        Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setRequiredTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;
        if (items != null)
        {
            this.requiredTestValueList = new Object[items.size()];
            this.requiredTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.requiredTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.requiredTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.requiredTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private Date hiddenNotValidated;

    /**
     * 
     */
    public Date getHiddenNotValidated()
    {
        return this.hiddenNotValidated;
    }

    /**
     * Keeps track of whether or not the value of hiddenNotValidated has
     * be populated at least once.
     */
    private boolean hiddenNotValidatedSet = false;

    /**
     * Resets the value of the hiddenNotValidatedSet to false
     */
    public void resetHiddenNotValidatedSet()
    {
        this.hiddenNotValidatedSet = false;
    }

    /**
     * Indicates whether or not the value for hiddenNotValidated has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenNotValidatedSet()
    {
        return this.hiddenNotValidatedSet;
    }

    /**
     * 
     */
    public void setHiddenNotValidated(Date hiddenNotValidated)
    {
        this.hiddenNotValidated = hiddenNotValidated;
        this.hiddenNotValidatedSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] hiddenNotValidatedValueList;

    /**
     * Stores the labels
     */
    private Object[] hiddenNotValidatedLabelList;
    public Object[] getHiddenNotValidatedBackingList()
    {
        Object[] values = this.hiddenNotValidatedValueList;
        Object[] labels = this.hiddenNotValidatedLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getHiddenNotValidatedValueList()
    {
        return this.hiddenNotValidatedValueList;
    }

    public void setHiddenNotValidatedValueList(Object[] hiddenNotValidatedValueList)
    {
        this.hiddenNotValidatedValueList = hiddenNotValidatedValueList;
    }

    public Object[] getHiddenNotValidatedLabelList()
    {
        return this.hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedLabelList(Object[] hiddenNotValidatedLabelList)
    {
        this.hiddenNotValidatedLabelList = hiddenNotValidatedLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setHiddenNotValidatedBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.hiddenNotValidatedValueList = null;
        this.hiddenNotValidatedLabelList = null;
        if (items != null)
        {
            this.hiddenNotValidatedValueList = new Object[items.size()];
            this.hiddenNotValidatedLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.hiddenNotValidatedValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.hiddenNotValidatedLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.hiddenNotValidatedLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String minLengthOnPasswordTest;

    /**
     * 
     */
    public String getMinLengthOnPasswordTest()
    {
        return this.minLengthOnPasswordTest;
    }

    /**
     * Keeps track of whether or not the value of minLengthOnPasswordTest has
     * be populated at least once.
     */
    private boolean minLengthOnPasswordTestSet = false;

    /**
     * Resets the value of the minLengthOnPasswordTestSet to false
     */
    public void resetMinLengthOnPasswordTestSet()
    {
        this.minLengthOnPasswordTestSet = false;
    }

    /**
     * Indicates whether or not the value for minLengthOnPasswordTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMinLengthOnPasswordTestSet()
    {
        return this.minLengthOnPasswordTestSet;
    }

    /**
     * 
     */
    public void setMinLengthOnPasswordTest(String minLengthOnPasswordTest)
    {
        this.minLengthOnPasswordTest = minLengthOnPasswordTest;
        this.minLengthOnPasswordTestSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] minLengthOnPasswordTestValueList;

    /**
     * Stores the labels
     */
    private Object[] minLengthOnPasswordTestLabelList;
    public Object[] getMinLengthOnPasswordTestBackingList()
    {
        Object[] values = this.minLengthOnPasswordTestValueList;
        Object[] labels = this.minLengthOnPasswordTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMinLengthOnPasswordTestValueList()
    {
        return this.minLengthOnPasswordTestValueList;
    }

    public void setMinLengthOnPasswordTestValueList(Object[] minLengthOnPasswordTestValueList)
    {
        this.minLengthOnPasswordTestValueList = minLengthOnPasswordTestValueList;
    }

    public Object[] getMinLengthOnPasswordTestLabelList()
    {
        return this.minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestLabelList(Object[] minLengthOnPasswordTestLabelList)
    {
        this.minLengthOnPasswordTestLabelList = minLengthOnPasswordTestLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMinLengthOnPasswordTestBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.minLengthOnPasswordTestValueList = null;
        this.minLengthOnPasswordTestLabelList = null;
        if (items != null)
        {
            this.minLengthOnPasswordTestValueList = new Object[items.size()];
            this.minLengthOnPasswordTestLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.minLengthOnPasswordTestValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.minLengthOnPasswordTestLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.minLengthOnPasswordTestLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetMinlengthTestSet();
         this.resetMaxlengthTestSet();
         this.resetPatternTestSet();
         this.resetCreditcardTestSet();
         this.resetEmailTestSet();
         this.resetUrlTestSet();
         this.resetIntRangeTestSet();
         this.resetFloatRangeTestSet();
         this.resetDoubleRangeTestSet();
         this.resetIntWrapperRangeTestSet();
         this.resetFloatWrapperRangeTestSet();
         this.resetDoubleWrapperRangeTestSet();
         this.resetLenientDateTestSet();
         this.resetStrictDateTestSet();
         this.resetRequiredTestSet();
         this.resetHiddenNotValidatedSet();
         this.resetMinLengthOnPasswordTestSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 175428435667633554L;
}
