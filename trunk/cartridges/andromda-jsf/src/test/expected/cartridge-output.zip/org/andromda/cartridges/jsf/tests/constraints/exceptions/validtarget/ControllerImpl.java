// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.Controller
 */
public class ControllerImpl
    extends Controller
{

}