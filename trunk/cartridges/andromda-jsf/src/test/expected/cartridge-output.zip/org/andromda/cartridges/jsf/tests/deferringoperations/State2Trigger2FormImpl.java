// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class State2Trigger2FormImpl
    implements Serializable, Operation2Form
{
    public State2Trigger2FormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private String testParam2;

    /**
     * 
     */
    public String getTestParam2()
    {
        return this.testParam2;
    }

    /**
     * Keeps track of whether or not the value of testParam2 has
     * be populated at least once.
     */
    private boolean testParam2Set = false;

    /**
     * Resets the value of the testParam2Set to false
     */
    public void resetTestParam2Set()
    {
        this.testParam2Set = false;
    }

    /**
     * Indicates whether or not the value for testParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParam2Set()
    {
        return this.testParam2Set;
    }

    /**
     * 
     */
    public void setTestParam2(String testParam2)
    {
        this.testParam2 = testParam2;
        this.testParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] testParam2ValueList;

    /**
     * Stores the labels
     */
    private Object[] testParam2LabelList;
    public Object[] getTestParam2BackingList()
    {
        Object[] values = this.testParam2ValueList;
        Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTestParam2BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
        if (items != null)
        {
            this.testParam2ValueList = new Object[items.size()];
            this.testParam2LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.testParam2ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.testParam2LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.testParam2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private int param4;

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }

    /**
     * Keeps track of whether or not the value of param4 has
     * be populated at least once.
     */
    private boolean param4Set = false;

    /**
     * Resets the value of the param4Set to false
     */
    public void resetParam4Set()
    {
        this.param4Set = false;
    }

    /**
     * Indicates whether or not the value for param4 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParam4Set()
    {
        return this.param4Set;
    }

    /**
     * 
     */
    public void setParam4(int param4)
    {
        this.param4 = param4;
        this.param4Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] param4ValueList;

    /**
     * Stores the labels
     */
    private Object[] param4LabelList;
    public Object[] getParam4BackingList()
    {
        Object[] values = this.param4ValueList;
        Object[] labels = this.param4LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParam4ValueList()
    {
        return this.param4ValueList;
    }

    public void setParam4ValueList(Object[] param4ValueList)
    {
        this.param4ValueList = param4ValueList;
    }

    public Object[] getParam4LabelList()
    {
        return this.param4LabelList;
    }

    public void setParam4LabelList(Object[] param4LabelList)
    {
        this.param4LabelList = param4LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setParam4BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.param4ValueList = null;
        this.param4LabelList = null;
        if (items != null)
        {
            this.param4ValueList = new Object[items.size()];
            this.param4LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.param4ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.param4LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.param4LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private int decisionTestParam;

    /**
     * 
     */
    public int getDecisionTestParam()
    {
        return this.decisionTestParam;
    }

    /**
     * Keeps track of whether or not the value of decisionTestParam has
     * be populated at least once.
     */
    private boolean decisionTestParamSet = false;

    /**
     * Resets the value of the decisionTestParamSet to false
     */
    public void resetDecisionTestParamSet()
    {
        this.decisionTestParamSet = false;
    }

    /**
     * Indicates whether or not the value for decisionTestParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDecisionTestParamSet()
    {
        return this.decisionTestParamSet;
    }

    /**
     * 
     */
    public void setDecisionTestParam(int decisionTestParam)
    {
        this.decisionTestParam = decisionTestParam;
        this.decisionTestParamSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] decisionTestParamValueList;

    /**
     * Stores the labels
     */
    private Object[] decisionTestParamLabelList;
    public Object[] getDecisionTestParamBackingList()
    {
        Object[] values = this.decisionTestParamValueList;
        Object[] labels = this.decisionTestParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDecisionTestParamValueList()
    {
        return this.decisionTestParamValueList;
    }

    public void setDecisionTestParamValueList(Object[] decisionTestParamValueList)
    {
        this.decisionTestParamValueList = decisionTestParamValueList;
    }

    public Object[] getDecisionTestParamLabelList()
    {
        return this.decisionTestParamLabelList;
    }

    public void setDecisionTestParamLabelList(Object[] decisionTestParamLabelList)
    {
        this.decisionTestParamLabelList = decisionTestParamLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setDecisionTestParamBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.decisionTestParamValueList = null;
        this.decisionTestParamLabelList = null;
        if (items != null)
        {
            this.decisionTestParamValueList = new Object[items.size()];
            this.decisionTestParamLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.decisionTestParamValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.decisionTestParamLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.decisionTestParamLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String testParam;

    /**
     * 
     */
    public String getTestParam()
    {
        return this.testParam;
    }

    /**
     * Keeps track of whether or not the value of testParam has
     * be populated at least once.
     */
    private boolean testParamSet = false;

    /**
     * Resets the value of the testParamSet to false
     */
    public void resetTestParamSet()
    {
        this.testParamSet = false;
    }

    /**
     * Indicates whether or not the value for testParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParamSet()
    {
        return this.testParamSet;
    }

    /**
     * 
     */
    public void setTestParam(String testParam)
    {
        this.testParam = testParam;
        this.testParamSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] testParamValueList;

    /**
     * Stores the labels
     */
    private Object[] testParamLabelList;
    public Object[] getTestParamBackingList()
    {
        Object[] values = this.testParamValueList;
        Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTestParamBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.testParamValueList = null;
        this.testParamLabelList = null;
        if (items != null)
        {
            this.testParamValueList = new Object[items.size()];
            this.testParamLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.testParamValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.testParamLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.testParamLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTestParam2Set();
         this.resetParam4Set();
         this.resetDecisionTestParamSet();
         this.resetTestParamSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 3119262259452261955L;
}
