// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.named;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.named.Controller
 */
public class ControllerImpl
    extends Controller
{

}