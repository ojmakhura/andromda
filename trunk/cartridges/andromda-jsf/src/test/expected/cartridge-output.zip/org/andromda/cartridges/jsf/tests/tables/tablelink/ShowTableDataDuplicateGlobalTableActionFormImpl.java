// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class ShowTableDataDuplicateGlobalTableActionFormImpl
    implements Serializable
{
    public ShowTableDataDuplicateGlobalTableActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private Collection tableData;

    /**
     * 
     */
    public Collection getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Resets the value of the tableDataSet to false
     */
    public void resetTableDataSet()
    {
        this.tableDataSet = false;
    }

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(Collection tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataValueList;

    /**
     * Stores the labels
     */
    private Object[] tableDataLabelList;
    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new Object[items.size()];
            this.tableDataLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection tableDataBackingValue;

    public void setTableDataBackingValue(Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }

    public Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private String[] multiboxThing;

    /**
     * 
     */
    public String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }

    /**
     * Keeps track of whether or not the value of multiboxThing has
     * be populated at least once.
     */
    private boolean multiboxThingSet = false;

    /**
     * Resets the value of the multiboxThingSet to false
     */
    public void resetMultiboxThingSet()
    {
        this.multiboxThingSet = false;
    }

    /**
     * Indicates whether or not the value for multiboxThing has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiboxThingSet()
    {
        return this.multiboxThingSet;
    }

    /**
     * 
     */
    public void setMultiboxThing(String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
        this.multiboxThingSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiboxThingValueList;

    /**
     * Stores the labels
     */
    private Object[] multiboxThingLabelList;
    public Object[] getMultiboxThingBackingList()
    {
        Object[] values = this.multiboxThingValueList;
        Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setMultiboxThingBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;
        if (items != null)
        {
            this.multiboxThingValueList = new Object[items.size()];
            this.multiboxThingLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiboxThingValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.multiboxThingLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.multiboxThingLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private String[] multiboxThingBackingValue;

    public void setMultiboxThingBackingValue(String[] multiboxThingBackingValue)
    {
        this.multiboxThingBackingValue = multiboxThingBackingValue;
    }

    public String[] getMultiboxThingBackingValue()
    {
        return this.multiboxThingBackingValue;
    }


    private Collection tableDataDefaultExportTypes;

    /**
     * 
     */
    public Collection getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataDefaultExportTypes has
     * be populated at least once.
     */
    private boolean tableDataDefaultExportTypesSet = false;

    /**
     * Resets the value of the tableDataDefaultExportTypesSet to false
     */
    public void resetTableDataDefaultExportTypesSet()
    {
        this.tableDataDefaultExportTypesSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataDefaultExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataDefaultExportTypesSet()
    {
        return this.tableDataDefaultExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataDefaultExportTypes(Collection tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
        this.tableDataDefaultExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataDefaultExportTypesValueList;

    /**
     * Stores the labels
     */
    private Object[] tableDataDefaultExportTypesLabelList;
    public Object[] getTableDataDefaultExportTypesBackingList()
    {
        Object[] values = this.tableDataDefaultExportTypesValueList;
        Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataDefaultExportTypesBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataDefaultExportTypesValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataDefaultExportTypesLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataDefaultExportTypesLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection tableDataDefaultExportTypesBackingValue;

    public void setTableDataDefaultExportTypesBackingValue(Collection tableDataDefaultExportTypesBackingValue)
    {
        this.tableDataDefaultExportTypesBackingValue = tableDataDefaultExportTypesBackingValue;
    }

    public Collection getTableDataDefaultExportTypesBackingValue()
    {
        return this.tableDataDefaultExportTypesBackingValue;
    }


    private Collection tableDataNoExportTypes;

    /**
     * 
     */
    public Collection getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataNoExportTypes has
     * be populated at least once.
     */
    private boolean tableDataNoExportTypesSet = false;

    /**
     * Resets the value of the tableDataNoExportTypesSet to false
     */
    public void resetTableDataNoExportTypesSet()
    {
        this.tableDataNoExportTypesSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataNoExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNoExportTypesSet()
    {
        return this.tableDataNoExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataNoExportTypes(Collection tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
        this.tableDataNoExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataNoExportTypesValueList;

    /**
     * Stores the labels
     */
    private Object[] tableDataNoExportTypesLabelList;
    public Object[] getTableDataNoExportTypesBackingList()
    {
        Object[] values = this.tableDataNoExportTypesValueList;
        Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataNoExportTypesBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new Object[items.size()];
            this.tableDataNoExportTypesLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataNoExportTypesValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataNoExportTypesLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataNoExportTypesLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection tableDataNoExportTypesBackingValue;

    public void setTableDataNoExportTypesBackingValue(Collection tableDataNoExportTypesBackingValue)
    {
        this.tableDataNoExportTypesBackingValue = tableDataNoExportTypesBackingValue;
    }

    public Collection getTableDataNoExportTypesBackingValue()
    {
        return this.tableDataNoExportTypesBackingValue;
    }


    private Collection tableDataNotSortable;

    /**
     * 
     */
    public Collection getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }

    /**
     * Keeps track of whether or not the value of tableDataNotSortable has
     * be populated at least once.
     */
    private boolean tableDataNotSortableSet = false;

    /**
     * Resets the value of the tableDataNotSortableSet to false
     */
    public void resetTableDataNotSortableSet()
    {
        this.tableDataNotSortableSet = false;
    }

    /**
     * Indicates whether or not the value for tableDataNotSortable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNotSortableSet()
    {
        return this.tableDataNotSortableSet;
    }

    /**
     * 
     */
    public void setTableDataNotSortable(Collection tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
        this.tableDataNotSortableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataNotSortableValueList;

    /**
     * Stores the labels
     */
    private Object[] tableDataNotSortableLabelList;
    public Object[] getTableDataNotSortableBackingList()
    {
        Object[] values = this.tableDataNotSortableValueList;
        Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTableDataNotSortableBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;
        if (items != null)
        {
            this.tableDataNotSortableValueList = new Object[items.size()];
            this.tableDataNotSortableLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataNotSortableValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.tableDataNotSortableLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.tableDataNotSortableLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    private Collection tableDataNotSortableBackingValue;

    public void setTableDataNotSortableBackingValue(Collection tableDataNotSortableBackingValue)
    {
        this.tableDataNotSortableBackingValue = tableDataNotSortableBackingValue;
    }

    public Collection getTableDataNotSortableBackingValue()
    {
        return this.tableDataNotSortableBackingValue;
    }


    private int first;

    /**
     * 
     */
    public int getFirst()
    {
        return this.first;
    }

    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;

    /**
     * Resets the value of the firstSet to false
     */
    public void resetFirstSet()
    {
        this.firstSet = false;
    }

    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(int first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] firstValueList;

    /**
     * Stores the labels
     */
    private Object[] firstLabelList;
    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFirstBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new Object[items.size()];
            this.firstLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.firstValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.firstLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.firstLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String third;

    /**
     * 
     */
    public String getThird()
    {
        return this.third;
    }

    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;

    /**
     * Resets the value of the thirdSet to false
     */
    public void resetThirdSet()
    {
        this.thirdSet = false;
    }

    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thirdValueList;

    /**
     * Stores the labels
     */
    private Object[] thirdLabelList;
    public Object[] getThirdBackingList()
    {
        Object[] values = this.thirdValueList;
        Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThirdBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new Object[items.size()];
            this.thirdLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thirdValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.thirdLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.thirdLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String two;

    /**
     * 
     */
    public String getTwo()
    {
        return this.two;
    }

    /**
     * Keeps track of whether or not the value of two has
     * be populated at least once.
     */
    private boolean twoSet = false;

    /**
     * Resets the value of the twoSet to false
     */
    public void resetTwoSet()
    {
        this.twoSet = false;
    }

    /**
     * Indicates whether or not the value for two has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTwoSet()
    {
        return this.twoSet;
    }

    /**
     * 
     */
    public void setTwo(String two)
    {
        this.two = two;
        this.twoSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] twoValueList;

    /**
     * Stores the labels
     */
    private Object[] twoLabelList;
    public Object[] getTwoBackingList()
    {
        Object[] values = this.twoValueList;
        Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setTwoBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.twoValueList = null;
        this.twoLabelList = null;
        if (items != null)
        {
            this.twoValueList = new Object[items.size()];
            this.twoLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.twoValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.twoLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.twoLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String second;

    /**
     * 
     */
    public String getSecond()
    {
        return this.second;
    }

    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;

    /**
     * Resets the value of the secondSet to false
     */
    public void resetSecondSet()
    {
        this.secondSet = false;
    }

    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] secondValueList;

    /**
     * Stores the labels
     */
    private Object[] secondLabelList;
    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSecondBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new Object[items.size()];
            this.secondLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.secondValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.secondLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.secondLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private int formParam1;

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }

    /**
     * Keeps track of whether or not the value of formParam1 has
     * be populated at least once.
     */
    private boolean formParam1Set = false;

    /**
     * Resets the value of the formParam1Set to false
     */
    public void resetFormParam1Set()
    {
        this.formParam1Set = false;
    }

    /**
     * Indicates whether or not the value for formParam1 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam1Set()
    {
        return this.formParam1Set;
    }

    /**
     * 
     */
    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
        this.formParam1Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] formParam1ValueList;

    /**
     * Stores the labels
     */
    private Object[] formParam1LabelList;
    public Object[] getFormParam1BackingList()
    {
        Object[] values = this.formParam1ValueList;
        Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFormParam1BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.formParam1ValueList = null;
        this.formParam1LabelList = null;
        if (items != null)
        {
            this.formParam1ValueList = new Object[items.size()];
            this.formParam1LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.formParam1ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.formParam1LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.formParam1LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String formParam2;

    /**
     * 
     */
    public String getFormParam2()
    {
        return this.formParam2;
    }

    /**
     * Keeps track of whether or not the value of formParam2 has
     * be populated at least once.
     */
    private boolean formParam2Set = false;

    /**
     * Resets the value of the formParam2Set to false
     */
    public void resetFormParam2Set()
    {
        this.formParam2Set = false;
    }

    /**
     * Indicates whether or not the value for formParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam2Set()
    {
        return this.formParam2Set;
    }

    /**
     * 
     */
    public void setFormParam2(String formParam2)
    {
        this.formParam2 = formParam2;
        this.formParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] formParam2ValueList;

    /**
     * Stores the labels
     */
    private Object[] formParam2LabelList;
    public Object[] getFormParam2BackingList()
    {
        Object[] values = this.formParam2ValueList;
        Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFormParam2BackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.formParam2ValueList = null;
        this.formParam2LabelList = null;
        if (items != null)
        {
            this.formParam2ValueList = new Object[items.size()];
            this.formParam2LabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.formParam2ValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.formParam2LabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.formParam2LabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String parameterWithDefaultValue = "aDefaultValue";

    /**
     * 
     */
    public String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;

    /**
     * Resets the value of the parameterWithDefaultValueSet to false
     */
    public void resetParameterWithDefaultValueSet()
    {
        this.parameterWithDefaultValueSet = false;
    }

    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setParameterWithDefaultValue(String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
        this.parameterWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] parameterWithDefaultValueValueList;

    /**
     * Stores the labels
     */
    private Object[] parameterWithDefaultValueLabelList;
    public Object[] getParameterWithDefaultValueBackingList()
    {
        Object[] values = this.parameterWithDefaultValueValueList;
        Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setParameterWithDefaultValueBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new Object[items.size()];
            this.parameterWithDefaultValueLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.parameterWithDefaultValueValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.parameterWithDefaultValueLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.parameterWithDefaultValueLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String fourth;

    /**
     * 
     */
    public String getFourth()
    {
        return this.fourth;
    }

    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;

    /**
     * Resets the value of the fourthSet to false
     */
    public void resetFourthSet()
    {
        this.fourthSet = false;
    }

    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] fourthValueList;

    /**
     * Stores the labels
     */
    private Object[] fourthLabelList;
    public Object[] getFourthBackingList()
    {
        Object[] values = this.fourthValueList;
        Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFourthBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new Object[items.size()];
            this.fourthLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.fourthValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.fourthLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.fourthLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String thisOneShouldbeNamedFirst;

    /**
     * 
     */
    public String getThisOneShouldbeNamedFirst()
    {
        return this.thisOneShouldbeNamedFirst;
    }

    /**
     * Keeps track of whether or not the value of thisOneShouldbeNamedFirst has
     * be populated at least once.
     */
    private boolean thisOneShouldbeNamedFirstSet = false;

    /**
     * Resets the value of the thisOneShouldbeNamedFirstSet to false
     */
    public void resetThisOneShouldbeNamedFirstSet()
    {
        this.thisOneShouldbeNamedFirstSet = false;
    }

    /**
     * Indicates whether or not the value for thisOneShouldbeNamedFirst has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisOneShouldbeNamedFirstSet()
    {
        return this.thisOneShouldbeNamedFirstSet;
    }

    /**
     * 
     */
    public void setThisOneShouldbeNamedFirst(String thisOneShouldbeNamedFirst)
    {
        this.thisOneShouldbeNamedFirst = thisOneShouldbeNamedFirst;
        this.thisOneShouldbeNamedFirstSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thisOneShouldbeNamedFirstValueList;

    /**
     * Stores the labels
     */
    private Object[] thisOneShouldbeNamedFirstLabelList;
    public Object[] getThisOneShouldbeNamedFirstBackingList()
    {
        Object[] values = this.thisOneShouldbeNamedFirstValueList;
        Object[] labels = this.thisOneShouldbeNamedFirstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThisOneShouldbeNamedFirstValueList()
    {
        return this.thisOneShouldbeNamedFirstValueList;
    }

    public void setThisOneShouldbeNamedFirstValueList(Object[] thisOneShouldbeNamedFirstValueList)
    {
        this.thisOneShouldbeNamedFirstValueList = thisOneShouldbeNamedFirstValueList;
    }

    public Object[] getThisOneShouldbeNamedFirstLabelList()
    {
        return this.thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstLabelList(Object[] thisOneShouldbeNamedFirstLabelList)
    {
        this.thisOneShouldbeNamedFirstLabelList = thisOneShouldbeNamedFirstLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThisOneShouldbeNamedFirstBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.thisOneShouldbeNamedFirstValueList = null;
        this.thisOneShouldbeNamedFirstLabelList = null;
        if (items != null)
        {
            this.thisOneShouldbeNamedFirstValueList = new Object[items.size()];
            this.thisOneShouldbeNamedFirstLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thisOneShouldbeNamedFirstValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.thisOneShouldbeNamedFirstLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.thisOneShouldbeNamedFirstLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String unknownParameter;

    /**
     * 
     */
    public String getUnknownParameter()
    {
        return this.unknownParameter;
    }

    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;

    /**
     * Resets the value of the unknownParameterSet to false
     */
    public void resetUnknownParameterSet()
    {
        this.unknownParameterSet = false;
    }

    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] unknownParameterValueList;

    /**
     * Stores the labels
     */
    private Object[] unknownParameterLabelList;
    public Object[] getUnknownParameterBackingList()
    {
        Object[] values = this.unknownParameterValueList;
        Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setUnknownParameterBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new Object[items.size()];
            this.unknownParameterLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.unknownParameterValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.unknownParameterLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.unknownParameterLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;

    /**
     * Resets the value of the thisParameterNameDoesNotExistAsTableColumnSet to false
     */
    public void resetThisParameterNameDoesNotExistAsTableColumnSet()
    {
        this.thisParameterNameDoesNotExistAsTableColumnSet = false;
    }

    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thisParameterNameDoesNotExistAsTableColumnValueList;

    /**
     * Stores the labels
     */
    private Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetTableDataSet();
         this.resetMultiboxThingSet();
         this.resetTableDataDefaultExportTypesSet();
         this.resetTableDataNoExportTypesSet();
         this.resetTableDataNotSortableSet();
         this.resetFirstSet();
         this.resetThirdSet();
         this.resetTwoSet();
         this.resetSecondSet();
         this.resetFormParam1Set();
         this.resetFormParam2Set();
         this.resetParameterWithDefaultValueSet();
         this.resetFourthSet();
         this.resetThisOneShouldbeNamedFirstSet();
         this.resetUnknownParameterSet();
         this.resetThisParameterNameDoesNotExistAsTableColumnSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 2385526135196919787L;
}
