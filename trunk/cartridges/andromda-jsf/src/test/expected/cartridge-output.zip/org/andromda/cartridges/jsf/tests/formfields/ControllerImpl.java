// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * @see org.andromda.cartridges.jsf.tests.formfields.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.formfields.Controller#someOperation(java.util.Date date, int number, java.util.Collection collection, java.lang.String selectable, java.io.File file, java.lang.Integer integerClass, java.util.Set setClass, java.util.Map mapClass, java.lang.Boolean booleanClass, boolean bool, java.lang.Float floatClass)
     */
    public void someOperation(SomeOperationForm form)
    {
        form.setSelectableValueList(new Object[] {"selectable-1", "selectable-2", "selectable-3", "selectable-4", "selectable-5"});
        form.setSelectableLabelList(form.getSelectableValueList());
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.formfields.Controller#anotherOperation(java.lang.String notused, int unusedNumber)
     */
    public void anotherOperation(AnotherOperationForm form)
    {
    }
    
}