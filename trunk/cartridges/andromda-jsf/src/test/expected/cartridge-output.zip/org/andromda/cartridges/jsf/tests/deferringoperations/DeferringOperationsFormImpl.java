// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * 
 */
public class DeferringOperationsFormImpl
    implements java.io.Serializable, Operation2Form
{
    public DeferringOperationsFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String pageVariable;

    /**
     * 
     */
    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }

    /**
     * Keeps track of whether or not the value of pageVariable has
     * be populated at least once.
     */
    private boolean pageVariableSet = false;

    /**
     * Indicates whether or not the value for pageVariable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPageVariableSet()
    {
        return this.pageVariableSet;
    }

    /**
     * 
     */
    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
        this.pageVariableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] pageVariableValueList;
    
    /**
     * Stores the labels
     */
    private Object[] pageVariableLabelList;
    public Object[] getPageVariableBackingList()
    {
        Object[] values = this.pageVariableValueList;
        Object[] labels = this.pageVariableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getPageVariableValueList()
    {
        return this.pageVariableValueList;
    }

    public void setPageVariableValueList(Object[] pageVariableValueList)
    {
        this.pageVariableValueList = pageVariableValueList;
    }

    public Object[] getPageVariableLabelList()
    {
        return this.pageVariableLabelList;
    }

    public void setPageVariableLabelList(Object[] pageVariableLabelList)
    {
        this.pageVariableLabelList = pageVariableLabelList;
    }

    public void setPageVariableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("DeferringOperationsFormImpl.setPageVariableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.pageVariableValueList = null;
        this.pageVariableLabelList = null;
        if (items != null)
        {
            this.pageVariableValueList = new Object[items.size()];
            this.pageVariableLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.pageVariableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.pageVariableValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.pageVariableValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.pageVariableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setPageVariableBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setPageVariableBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String testParam;

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    /**
     * Keeps track of whether or not the value of testParam has
     * be populated at least once.
     */
    private boolean testParamSet = false;

    /**
     * Indicates whether or not the value for testParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParamSet()
    {
        return this.testParamSet;
    }

    /**
     * 
     */
    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
        this.testParamSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] testParamValueList;
    
    /**
     * Stores the labels
     */
    private Object[] testParamLabelList;
    public Object[] getTestParamBackingList()
    {
        Object[] values = this.testParamValueList;
        Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    public void setTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("DeferringOperationsFormImpl.setTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.testParamValueList = null;
        this.testParamLabelList = null;
        if (items != null)
        {
            this.testParamValueList = new Object[items.size()];
            this.testParamLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.testParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.testParamValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.testParamValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.testParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTestParamBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String param2a;

    /**
     * 
     */
    public java.lang.String getParam2a()
    {
        return this.param2a;
    }

    /**
     * Keeps track of whether or not the value of param2a has
     * be populated at least once.
     */
    private boolean param2aSet = false;

    /**
     * Indicates whether or not the value for param2a has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParam2aSet()
    {
        return this.param2aSet;
    }

    /**
     * 
     */
    public void setParam2a(java.lang.String param2a)
    {
        this.param2a = param2a;
        this.param2aSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] param2aValueList;
    
    /**
     * Stores the labels
     */
    private Object[] param2aLabelList;
    public Object[] getParam2aBackingList()
    {
        Object[] values = this.param2aValueList;
        Object[] labels = this.param2aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParam2aValueList()
    {
        return this.param2aValueList;
    }

    public void setParam2aValueList(Object[] param2aValueList)
    {
        this.param2aValueList = param2aValueList;
    }

    public Object[] getParam2aLabelList()
    {
        return this.param2aLabelList;
    }

    public void setParam2aLabelList(Object[] param2aLabelList)
    {
        this.param2aLabelList = param2aLabelList;
    }

    public void setParam2aBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("DeferringOperationsFormImpl.setParam2aBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.param2aValueList = null;
        this.param2aLabelList = null;
        if (items != null)
        {
            this.param2aValueList = new Object[items.size()];
            this.param2aLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.param2aValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.param2aValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.param2aValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.param2aLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setParam2aBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setParam2aBackingList(items, valueProperty, labelProperty, null);
    }
    


    private int testParam2;

    /**
     * 
     */
    public int getTestParam2()
    {
        return this.testParam2;
    }

    /**
     * Keeps track of whether or not the value of testParam2 has
     * be populated at least once.
     */
    private boolean testParam2Set = false;

    /**
     * Indicates whether or not the value for testParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParam2Set()
    {
        return this.testParam2Set;
    }

    /**
     * 
     */
    public void setTestParam2(int testParam2)
    {
        this.testParam2 = testParam2;
        this.testParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] testParam2ValueList;
    
    /**
     * Stores the labels
     */
    private Object[] testParam2LabelList;
    public Object[] getTestParam2BackingList()
    {
        Object[] values = this.testParam2ValueList;
        Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    public void setTestParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("DeferringOperationsFormImpl.setTestParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
        if (items != null)
        {
            this.testParam2ValueList = new Object[items.size()];
            this.testParam2LabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.testParam2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.testParam2ValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.testParam2ValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.testParam2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTestParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTestParam2BackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -4893565821221753997L;
}