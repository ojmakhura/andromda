// license-header java merge-point
package org.andromda.cartridges.jsf.tests.messages;

/**
 * @see org.andromda.cartridges.jsf.tests.messages.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 6495477455676086069L;

    /**
     * @see org.andromda.cartridges.jsf.tests.messages.Controller#doSomething()
     */
    @Override
    public boolean doSomething()
    {
        return false;
    }

}