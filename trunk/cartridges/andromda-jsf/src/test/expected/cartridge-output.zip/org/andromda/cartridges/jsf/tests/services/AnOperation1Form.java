// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation1</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation1(java.lang.String one, int two)
 */
public interface AnOperation1Form
{
    /**
     * 
     */
    public java.lang.String getOne();

    /**
     * 
     */
    public void setOne(java.lang.String one);
    
    /**
     * 
     */
    public int getTwo();

    /**
     * 
     */
    public void setTwo(int two);
    
}