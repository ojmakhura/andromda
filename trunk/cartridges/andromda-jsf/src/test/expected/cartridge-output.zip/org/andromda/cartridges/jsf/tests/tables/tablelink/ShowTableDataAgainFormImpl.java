// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * 
 */
public class ShowTableDataAgainFormImpl
    implements Serializable
{
    public ShowTableDataAgainFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private String second;

    /**
     * 
     */
    public String getSecond()
    {
        return this.second;
    }

    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;

    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] secondValueList;
    
    /**
     * Stores the labels
     */
    private Object[] secondLabelList;
    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setSecondBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new Object[items.size()];
            this.secondLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.secondValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.secondValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.secondValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.secondLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setSecondBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setSecondBackingList(items, valueProperty, labelProperty, null);
    }
    


    private String third;

    /**
     * 
     */
    public String getThird()
    {
        return this.third;
    }

    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;

    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thirdValueList;
    
    /**
     * Stores the labels
     */
    private Object[] thirdLabelList;
    public Object[] getThirdBackingList()
    {
        Object[] values = this.thirdValueList;
        Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setThirdBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new Object[items.size()];
            this.thirdLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thirdValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.thirdValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.thirdValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.thirdLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setThirdBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setThirdBackingList(items, valueProperty, labelProperty, null);
    }
    


    private String fourth;

    /**
     * 
     */
    public String getFourth()
    {
        return this.fourth;
    }

    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;

    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] fourthValueList;
    
    /**
     * Stores the labels
     */
    private Object[] fourthLabelList;
    public Object[] getFourthBackingList()
    {
        Object[] values = this.fourthValueList;
        Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setFourthBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new Object[items.size()];
            this.fourthLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.fourthValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.fourthValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.fourthValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.fourthLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFourthBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setFourthBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map dateTimeFormatters = new HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private Map jsfMessages = new LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 289748190800866424L;
}