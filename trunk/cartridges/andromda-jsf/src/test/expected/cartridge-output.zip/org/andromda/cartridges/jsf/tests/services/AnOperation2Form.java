// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation2</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation2(String one, int two, String three)
 */
public interface AnOperation2Form
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     *
     * @return the faces ValueChangeEvent associated to this form.
     */
    public ValueChangeEvent getValueChangeEvent();

    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     *
     * @return the faces ActionEvent associated to this form.
     */
    public ActionEvent getActionEvent();

    /**
     * Sets the event (if any) that is associated with this form.
     *
     * @param event the faces event to associate to this form.
     */
    public void setEvent(FacesEvent event);

    /**
     * 
     */
    public String getOne();

    /**
     * 
     */
    public void setOne(String one);

    /**
     * 
     */
    public int getTwo();

    /**
     * 
     */
    public void setTwo(int two);

    /**
     * 
     */
    public String getThree();

    /**
     * 
     */
    public void setThree(String three);

}
