// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#operation1()
     */
    public void operation1() throws Exception
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#operation2(java.lang.String testParam2)
     */
    public void operation2(Operation2Form form) throws Exception
    {
        form.setTestParam2ValueList(new Object[] {"testParam2-1", "testParam2-2", "testParam2-3", "testParam2-4", "testParam2-5"});
        form.setTestParam2LabelList(form.getTestParam2ValueList());
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#operation3()
     */
    public void operation3() throws Exception
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#deferringOperations(java.lang.String testParam2)
     */
    public void deferringOperations(DeferringOperationsForm form) throws Exception
    {
        form.setTestParam2ValueList(new Object[] {"testParam2-1", "testParam2-2", "testParam2-3", "testParam2-4", "testParam2-5"});
        form.setTestParam2LabelList(form.getTestParam2ValueList());
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#testMissingArgumentField(java.lang.String thisArgumentIsMissingFromTheActionForm)
     */
    public void testMissingArgumentField(TestMissingArgumentFieldForm form) throws Exception
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#missingArgumentName(java.lang.String )
     */
    public void missingArgumentName(MissingArgumentNameForm form) throws Exception
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#testPageToPage(int decisionTestParam)
     */
    public boolean testPageToPage(TestPageToPageForm form) throws Exception
    {
        return false;
    }
    
}