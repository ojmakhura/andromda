package org.andromda.cartridges.jsf.tests.exceptions;

/**
 * Stores all forward paths available in the use case Exceptions Activity keyed by forward name.
 */
final class ExceptionsActivityForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("show-something", "/org/andromda/cartridges/jsf/tests/exceptions/show-something.jsf");
            forwards.put("exceptions-activity-usecase", "/org/andromda/cartridges/jsf/tests/exceptions/exceptions-activity.jsf");
            forwards.put("enter-info", "/org/andromda/cartridges/jsf/tests/exceptions/enter-info.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}