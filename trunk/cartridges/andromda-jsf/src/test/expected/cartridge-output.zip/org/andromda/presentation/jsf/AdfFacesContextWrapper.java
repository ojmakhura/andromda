package org.andromda.presentation.jsf;

import java.io.Serializable;
import oracle.adf.view.faces.context.AdfFacesContext;
/**
 * This wrapper just allows us to store the current AdfFacesContext instance
 * in the session since the AdfFacesContext is not serializable.
 * 
 * @author Chad Brandon
 */
public class AdfFacesContextWrapper
    implements Serializable
{    
    private transient AdfFacesContext currentInstance = null;
    
    public AdfFacesContext getCurrentInstance()
    {
        if (this.currentInstance == null)
        {
            this.currentInstance = AdfFacesContext.getCurrentInstance();
        }
        return this.currentInstance;
    }
    
    private static final long serialVersionUID = 1L;
}
