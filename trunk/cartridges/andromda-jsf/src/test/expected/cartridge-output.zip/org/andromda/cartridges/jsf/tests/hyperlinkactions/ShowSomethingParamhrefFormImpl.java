// license-header java merge-point
package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * 
 */
public class ShowSomethingParamhrefFormImpl
    implements java.io.Serializable
{
    public ShowSomethingParamhrefFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.lang.String someParameter;

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }

    /**
     * Keeps track of whether or not the value of someParameter has
     * be populated at least once.
     */
    private boolean someParameterSet = false;

    /**
     * Resets the value of the someParameterSet to false
     */
    public void resetSomeParameterSet()
    {
        this.someParameterSet = false;
    }

    /**
     * Indicates whether or not the value for someParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSomeParameterSet()
    {
        return this.someParameterSet;
    }

    /**
     * 
     */
    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
        this.someParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] someParameterValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] someParameterLabelList;
    public java.lang.Object[] getSomeParameterBackingList()
    {
        java.lang.Object[] values = this.someParameterValueList;
        java.lang.Object[] labels = this.someParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSomeParameterValueList()
    {
        return this.someParameterValueList;
    }

    public void setSomeParameterValueList(java.lang.Object[] someParameterValueList)
    {
        this.someParameterValueList = someParameterValueList;
    }

    public java.lang.Object[] getSomeParameterLabelList()
    {
        return this.someParameterLabelList;
    }

    public void setSomeParameterLabelList(java.lang.Object[] someParameterLabelList)
    {
        this.someParameterLabelList = someParameterLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setSomeParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.someParameterValueList = null;
        this.someParameterLabelList = null;
        if (items != null)
        {
            this.someParameterValueList = new java.lang.Object[items.size()];
            this.someParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.someParameterValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.someParameterLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.someParameterLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String parameterWithDefaultValue = "someValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;

    /**
     * Resets the value of the parameterWithDefaultValueSet to false
     */
    public void resetParameterWithDefaultValueSet()
    {
        this.parameterWithDefaultValueSet = false;
    }

    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
        this.parameterWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] parameterWithDefaultValueValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] parameterWithDefaultValueLabelList;
    public java.lang.Object[] getParameterWithDefaultValueBackingList()
    {
        java.lang.Object[] values = this.parameterWithDefaultValueValueList;
        java.lang.Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(java.lang.Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public java.lang.Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(java.lang.Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setParameterWithDefaultValueBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new java.lang.Object[items.size()];
            this.parameterWithDefaultValueLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.parameterWithDefaultValueValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.parameterWithDefaultValueLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.parameterWithDefaultValueLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetSomeParameterSet();
         this.resetParameterWithDefaultValueSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -1820141436527385775L;
}
