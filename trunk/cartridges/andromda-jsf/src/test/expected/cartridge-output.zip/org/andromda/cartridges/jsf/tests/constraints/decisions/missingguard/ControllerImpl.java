// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 1459225067887670972L;

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller#operation()
     */
    @Override
    public String operation()
    {
        return null;
    }

}