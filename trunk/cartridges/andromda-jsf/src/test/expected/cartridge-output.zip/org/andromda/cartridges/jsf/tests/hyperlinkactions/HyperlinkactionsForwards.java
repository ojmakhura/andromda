package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * Stores all forward paths available in the use case Hyperlinkactions keyed by forward name.
 */
final class HyperlinkactionsForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("show-something", "/org/andromda/cartridges/jsf/tests/hyperlinkactions/show-something.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}