// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formscope;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * 
 */
public class FormScopeFormImpl
    implements Serializable
{
    public FormScopeFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private String eventParam;

    /**
     * 
     */
    public String getEventParam()
    {
        return this.eventParam;
    }

    /**
     * Keeps track of whether or not the value of eventParam has
     * be populated at least once.
     */
    private boolean eventParamSet = false;

    /**
     * Indicates whether or not the value for eventParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isEventParamSet()
    {
        return this.eventParamSet;
    }

    /**
     * 
     */
    public void setEventParam(String eventParam)
    {
        this.eventParam = eventParam;
        this.eventParamSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] eventParamValueList;
    
    /**
     * Stores the labels
     */
    private Object[] eventParamLabelList;
    public Object[] getEventParamBackingList()
    {
        Object[] values = this.eventParamValueList;
        Object[] labels = this.eventParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getEventParamValueList()
    {
        return this.eventParamValueList;
    }

    public void setEventParamValueList(Object[] eventParamValueList)
    {
        this.eventParamValueList = eventParamValueList;
    }

    public Object[] getEventParamLabelList()
    {
        return this.eventParamLabelList;
    }

    public void setEventParamLabelList(Object[] eventParamLabelList)
    {
        this.eventParamLabelList = eventParamLabelList;
    }

    public void setEventParamBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setEventParamBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.eventParamValueList = null;
        this.eventParamLabelList = null;
        if (items != null)
        {
            this.eventParamValueList = new Object[items.size()];
            this.eventParamLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.eventParamValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.eventParamValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.eventParamValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.eventParamLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setEventParamBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setEventParamBackingList(items, valueProperty, labelProperty, null);
    }
    


    private String pageVar;

    /**
     * 
     */
    public String getPageVar()
    {
        return this.pageVar;
    }

    /**
     * Keeps track of whether or not the value of pageVar has
     * be populated at least once.
     */
    private boolean pageVarSet = false;

    /**
     * Indicates whether or not the value for pageVar has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPageVarSet()
    {
        return this.pageVarSet;
    }

    /**
     * 
     */
    public void setPageVar(String pageVar)
    {
        this.pageVar = pageVar;
        this.pageVarSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] pageVarValueList;
    
    /**
     * Stores the labels
     */
    private Object[] pageVarLabelList;
    public Object[] getPageVarBackingList()
    {
        Object[] values = this.pageVarValueList;
        Object[] labels = this.pageVarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getPageVarValueList()
    {
        return this.pageVarValueList;
    }

    public void setPageVarValueList(Object[] pageVarValueList)
    {
        this.pageVarValueList = pageVarValueList;
    }

    public Object[] getPageVarLabelList()
    {
        return this.pageVarLabelList;
    }

    public void setPageVarLabelList(Object[] pageVarLabelList)
    {
        this.pageVarLabelList = pageVarLabelList;
    }

    public void setPageVarBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setPageVarBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.pageVarValueList = null;
        this.pageVarLabelList = null;
        if (items != null)
        {
            this.pageVarValueList = new Object[items.size()];
            this.pageVarLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.pageVarValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.pageVarValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.pageVarValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.pageVarLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setPageVarBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setPageVarBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map dateTimeFormatters = new HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private Map jsfMessages = new LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7342294526456317665L;
}