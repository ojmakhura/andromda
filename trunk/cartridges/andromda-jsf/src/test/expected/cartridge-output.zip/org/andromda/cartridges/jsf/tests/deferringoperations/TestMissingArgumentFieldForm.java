// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>testMissingArgumentField</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 * The action deferring to this operation has no form field with
 * the same name and type.
 * </p>
 *
 * @see org.andromda.cartridges.jsf.tests.deferringoperations.Controller#testMissingArgumentField(String thisArgumentIsMissingFromTheActionForm)
 */
public interface TestMissingArgumentFieldForm
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     *
     * @return the faces ValueChangeEvent associated to this form.
     */
    public ValueChangeEvent getValueChangeEvent();

    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     *
     * @return the faces ActionEvent associated to this form.
     */
    public ActionEvent getActionEvent();

    /**
     * Sets the event (if any) that is associated with this form.
     *
     * @param event the faces event to associate to this form.
     */
    public void setEvent(FacesEvent event);

    /**
     * 
     */
    public String getThisArgumentIsMissingFromTheActionForm();

    /**
     * 
     */
    public void setThisArgumentIsMissingFromTheActionForm(String thisArgumentIsMissingFromTheActionForm);

}
