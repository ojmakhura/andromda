// license-header java merge-point
package org.andromda.cartridges.jsf.tests.widgets;

/**
 * @see org.andromda.cartridges.jsf.tests.widgets.Controller
 */
public class ControllerImpl
    extends Controller
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -383813975041405125L;

    /**
     * @see org.andromda.cartridges.jsf.tests.widgets.Controller#preloadSelects()
     */
    @Override
    public void preloadSelects()
    {
    }

}