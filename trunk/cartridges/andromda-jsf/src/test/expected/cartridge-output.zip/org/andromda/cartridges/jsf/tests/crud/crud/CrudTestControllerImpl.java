// license-header java merge-point
package org.andromda.cartridges.jsf.tests.crud.crud;

import java.io.Serializable;

/**
 * @see org.andromda.cartridges.jsf.tests.crud.crud.CrudTestController
 */
public class CrudTestControllerImpl
    extends CrudTestController
    implements Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 4913831644145054351L;


}