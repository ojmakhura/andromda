package org.andromda.cartridges.jsf.tests.finalstates.hyperlinked;

/**
 * Stores all forward paths available in the use case Hyperlinked keyed by forward name.
 */
final class HyperlinkedForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("hyperlinked-usecase", "/org/andromda/cartridges/jsf/tests/finalstates/hyperlinked/hyperlinked.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}