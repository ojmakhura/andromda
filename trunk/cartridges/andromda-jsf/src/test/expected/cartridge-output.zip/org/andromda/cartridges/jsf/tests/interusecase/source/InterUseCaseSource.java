package org.andromda.cartridges.jsf.tests.interusecase.source;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.andromda.presentation.jsf.FacesContextUtils;
import org.andromda.presentation.jsf.UseCaseForwards;

/**
 * This servlet is used to allow controller operation execution through
 * a URL call.
 */
public class InterUseCaseSource
    extends HttpServlet
{
    /**
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void doGet(
        final HttpServletRequest request,
        final HttpServletResponse response)
        throws ServletException, IOException
    {
        // - we need to resolve the controller differently since we're outside of the faces servlet
        Controller controller =
            (Controller)FacesContextUtils.resolveVariable(
                request, response,
                "controller");
        final String forwardPath = UseCaseForwards.getPath(controller.interUseCaseSource());
        response.sendRedirect(request.getContextPath() + forwardPath + (request.getQueryString() != null ? "?" + request.getQueryString() : ""));
    }

    /**
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void doPost(
        final HttpServletRequest request,
        final HttpServletResponse response)
        throws ServletException, IOException
    {
        this.doGet(request, response);
    }
}