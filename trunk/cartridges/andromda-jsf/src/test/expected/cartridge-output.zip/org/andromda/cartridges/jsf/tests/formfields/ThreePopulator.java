package org.andromda.cartridges.jsf.tests.formfields;

import java.io.IOException;

import javax.faces.context.FacesContext;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import javax.faces.el.VariableResolver;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import oracle.adf.view.faces.context.AdfFacesContext;
import org.andromda.presentation.jsf.AdfFacesContextWrapper;
import org.andromda.presentation.jsf.FacesContextUtils;
import org.andromda.presentation.jsf.FormPopulator;
import org.andromda.presentation.jsf.JsfUtils;
/**
 * This filter handles the population of forms for the <em>three</code>
 * view.
 */
public class ThreePopulator
    implements Filter
{
    /**
     * @see javax.servlet.Filter#setFilterConfig(FilterConfig)
     */
    public void init(FilterConfig config)
    {
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        this.populateFormAndViewVariables(request, response, null);
        chain.doFilter(request, response);
    }
    
    private void populateFormAndViewVariables(final ServletRequest request, final ServletResponse response, Object form)
        throws ServletException
    {
        // - we need to retrieve the faces context different than normal because we're outside of the
        //   faces servlet
        final FacesContext facesContext = FacesContextUtils.getFacesContext(request, response);
                
        AdfFacesContext adfContext = AdfFacesContext.getCurrentInstance();
        final VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        final HttpSession session = ((HttpServletRequest)request).getSession();
        if (form == null)
        {  
            // - first try getting the form from the ADF processScope
            form = adfContext.getProcessScope().get("form");
            // - if the form is null, try getting the current adfContext from the session (and then remove it from the session)
            if (form == null)
            {
                final AdfFacesContextWrapper contextWrapper = 
                    (AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;    
                form = adfContext != null ? adfContext.getProcessScope().get("form") : null;   
                // - if the form is still null, see if we can get it from a serialized state
                if (form == null)
                {
                    form = JsfUtils.getSerializedForm(session);
                }
                if (form != null)
                {
                    // - add the form to the current process scope since it wasn't in the current one to begin with
                    AdfFacesContext.getCurrentInstance().getProcessScope().put("form", form);   
                }
            }
            else
            {
                // - remove the ADF context in the event that its present
                session.removeAttribute("AndroMDAADFContext");
            }
        }
        else
        {
            // - since the form argument is not null, set it as the "form" in the processScope 
            //   (to replace the existing "form" attribute)
            adfContext.getProcessScope().put("form", form);
        }
        try
        {
            // - populate the forms
            if (form != null)
            {    
                ThreeGoFormImpl formFieldsThreeGoForm =
                    (ThreeGoFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "formFieldsThreeGoForm");
                // - populate the formFieldsThreeGoForm with any parameters from the previous form
                FormPopulator.populateForm(form, formFieldsThreeGoForm);
                request.setAttribute("formFieldsThreeGoForm", formFieldsThreeGoForm);
            }
            // - serialize the form
            if (form != null)
            {
                JsfUtils.serializeForm(session, form);
            }
        }
        catch (final Throwable throwable)
        {
            throw new ServletException(throwable);
        }
    }
    
    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
    }
}