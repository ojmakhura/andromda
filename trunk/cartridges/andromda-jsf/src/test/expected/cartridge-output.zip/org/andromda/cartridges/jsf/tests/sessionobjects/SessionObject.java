// license-header java merge-point
package org.andromda.cartridges.jsf.tests.sessionobjects;

import java.io.Serializable;

/**
 * 
 */
public class SessionObject implements Serializable
{
    private String attribute1;

    /**
     * 
     */
    public String getAttribute1()
    {
        return this.attribute1;
    }

    public void setAttribute1(String attribute1)
    {
        this.attribute1 = attribute1;
    }

    private int attribute2;

    /**
     * 
     */
    public int getAttribute2()
    {
        return this.attribute2;
    }

    public void setAttribute2(int attribute2)
    {
        this.attribute2 = attribute2;
    }

    private String privateAttribute;

    /**
     * 
     */
    private String getPrivateAttribute()
    {
        return this.privateAttribute;
    }

    private void setPrivateAttribute(String privateAttribute)
    {
        this.privateAttribute = privateAttribute;
    }


}
