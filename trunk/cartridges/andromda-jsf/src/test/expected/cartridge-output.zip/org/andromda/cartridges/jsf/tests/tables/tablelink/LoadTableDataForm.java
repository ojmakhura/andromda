// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>loadTableData</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.tables.tablelink.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.tables.tablelink.Controller#loadTableData(java.util.Collection tableData, java.lang.String[] multiboxThing)
 */
public interface LoadTableDataForm
{
    /**
     * 
     */
    public java.util.List getTableData();

    /**
     * 
     */
    public void setTableData(java.util.List tableData);
    
    /**
     * 
     */
    public java.lang.String[] getMultiboxThing();

    /**
     * 
     */
    public void setMultiboxThing(java.lang.String[] multiboxThing);
    
}