// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

import java.util.List;
/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>loadTableData</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.tables.tablelink.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.tables.tablelink.Controller#loadTableData(java.util.Collection tableData, String[] multiboxThing)
 */
public interface LoadTableDataForm
{
    /**
     * 
     */
    public List getTableData();

    /**
     * 
     */
    public void setTableData(List tableData);
    
    /**
     * 
     */
    public String[] getMultiboxThing();

    /**
     * 
     */
    public void setMultiboxThing(String[] multiboxThing);
    
}