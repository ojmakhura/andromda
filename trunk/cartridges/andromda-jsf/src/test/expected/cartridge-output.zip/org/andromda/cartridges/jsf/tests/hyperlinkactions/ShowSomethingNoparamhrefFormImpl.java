// license-header java merge-point
package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * 
 */
public class ShowSomethingNoparamhrefFormImpl
    implements java.io.Serializable    
{
    public ShowSomethingNoparamhrefFormImpl()
    {
    }

    private java.lang.String someParameter;

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }
    
    /**
     * Keeps track of whether or not the value of someParameter has
     * be populated at least once.
     */
    private boolean someParameterSet = false;
    
    /**
     * Indicates whether or not the value for someParameter has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isSomeParameterSet()
    {
        return this.someParameterSet;
    }

    /**
     * 
     */
    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
        this.someParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] someParameterValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] someParameterLabelList;
    public java.lang.Object[] getSomeParameterBackingList()
    {
        java.lang.Object[] values = this.someParameterValueList;
        java.lang.Object[] labels = this.someParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSomeParameterValueList()
    {
        return this.someParameterValueList;
    }

    public void setSomeParameterValueList(java.lang.Object[] someParameterValueList)
    {
        this.someParameterValueList = someParameterValueList;
    }

    public java.lang.Object[] getSomeParameterLabelList()
    {
        return this.someParameterLabelList;
    }

    public void setSomeParameterLabelList(java.lang.Object[] someParameterLabelList)
    {
        this.someParameterLabelList = someParameterLabelList;
    }

    public void setSomeParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingNoparamhrefFormImpl.setSomeParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.someParameterValueList = null;
        this.someParameterLabelList = null;
        if (items != null)
        {
            this.someParameterValueList = new java.lang.Object[items.size()];
            this.someParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.someParameterValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.someParameterLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String parameterWithDefaultValue = "someValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }
    
    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;
    
    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 5464757755574216607L;
}