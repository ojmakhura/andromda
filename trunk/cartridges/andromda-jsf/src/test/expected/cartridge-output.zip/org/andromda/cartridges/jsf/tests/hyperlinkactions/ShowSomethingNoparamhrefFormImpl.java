// license-header java merge-point
package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * 
 */
public class ShowSomethingNoparamhrefFormImpl
    implements java.io.Serializable
{
    public ShowSomethingNoparamhrefFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String someParameter;

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }

    /**
     * Keeps track of whether or not the value of someParameter has
     * be populated at least once.
     */
    private boolean someParameterSet = false;

    /**
     * Indicates whether or not the value for someParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSomeParameterSet()
    {
        return this.someParameterSet;
    }

    /**
     * 
     */
    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
        this.someParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] someParameterValueList;
    
    /**
     * Stores the labels
     */
    private Object[] someParameterLabelList;
    public Object[] getSomeParameterBackingList()
    {
        Object[] values = this.someParameterValueList;
        Object[] labels = this.someParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSomeParameterValueList()
    {
        return this.someParameterValueList;
    }

    public void setSomeParameterValueList(Object[] someParameterValueList)
    {
        this.someParameterValueList = someParameterValueList;
    }

    public Object[] getSomeParameterLabelList()
    {
        return this.someParameterLabelList;
    }

    public void setSomeParameterLabelList(Object[] someParameterLabelList)
    {
        this.someParameterLabelList = someParameterLabelList;
    }

    public void setSomeParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingNoparamhrefFormImpl.setSomeParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.someParameterValueList = null;
        this.someParameterLabelList = null;
        if (items != null)
        {
            this.someParameterValueList = new Object[items.size()];
            this.someParameterLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.someParameterValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.someParameterValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.someParameterValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.someParameterLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setSomeParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setSomeParameterBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String parameterWithDefaultValue = "someValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;

    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
        this.parameterWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] parameterWithDefaultValueValueList;
    
    /**
     * Stores the labels
     */
    private Object[] parameterWithDefaultValueLabelList;
    public Object[] getParameterWithDefaultValueBackingList()
    {
        Object[] values = this.parameterWithDefaultValueValueList;
        Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingNoparamhrefFormImpl.setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new Object[items.size()];
            this.parameterWithDefaultValueLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.parameterWithDefaultValueValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.parameterWithDefaultValueValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.parameterWithDefaultValueValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.parameterWithDefaultValueLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setParameterWithDefaultValueBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 5685763609422164421L;
}