// license-header java merge-point
package org.andromda.cartridges.jsf.tests.hyperlinkactions;

/**
 * @see org.andromda.cartridges.jsf.tests.hyperlinkactions.Controller
 */
public class ControllerImpl
    extends Controller
{

}