// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation(String one)
 */
public interface AnOperationForm
{
    /**
     * Gets the ValueChangeEvent (if any) that is associated with this form.
     *
     * @return the faces ValueChangeEvent associated to this form.
     */
    public ValueChangeEvent getValueChangeEvent();

    /**
     * Gets the ActionEvent (if any) that is associated with this form.
     *
     * @return the faces ActionEvent associated to this form.
     */
    public ActionEvent getActionEvent();

    /**
     * Sets the event (if any) that is associated with this form.
     *
     * @param event the faces event to associate to this form.
     */
    public void setEvent(FacesEvent event);

    /**
     * 
     */
    public String getOne();

    /**
     * 
     */
    public void setOne(String one);

}