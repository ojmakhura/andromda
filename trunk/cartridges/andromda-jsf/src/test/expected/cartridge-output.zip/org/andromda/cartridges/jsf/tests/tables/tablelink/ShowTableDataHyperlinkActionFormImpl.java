// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.PropertyUtils;
/**
 * 
 */
public class ShowTableDataHyperlinkActionFormImpl
    implements Serializable
{
    public ShowTableDataHyperlinkActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private String first;

    /**
     * 
     */
    public String getFirst()
    {
        return this.first;
    }

    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;

    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(String first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] firstValueList;
    
    /**
     * Stores the labels
     */
    private Object[] firstLabelList;
    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    public void setFirstBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionFormImpl.setFirstBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new Object[items.size()];
            this.firstLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.firstValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.firstValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.firstValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.firstLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFirstBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setFirstBackingList(items, valueProperty, labelProperty, null);
    }
    


    private String unknownParameter;

    /**
     * 
     */
    public String getUnknownParameter()
    {
        return this.unknownParameter;
    }

    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;

    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] unknownParameterValueList;
    
    /**
     * Stores the labels
     */
    private Object[] unknownParameterLabelList;
    public Object[] getUnknownParameterBackingList()
    {
        Object[] values = this.unknownParameterValueList;
        Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    public void setUnknownParameterBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataHyperlinkActionFormImpl.setUnknownParameterBackingList(Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new Object[items.size()];
            this.unknownParameterLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.unknownParameterValueList[ctr] = PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.unknownParameterValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.unknownParameterValueList[ctr] = ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.unknownParameterLabelList[ctr] = PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setUnknownParameterBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.setUnknownParameterBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map dateTimeFormatters = new HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private Map jsfMessages = new LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7930484190843311977L;
}