// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataHyperlinkActionFormImpl
    implements java.io.Serializable
{
    public ShowTableDataHyperlinkActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient javax.faces.event.FacesEvent event;

    public void setEvent(javax.faces.event.FacesEvent event)
    {
        this.event = event;
    }

    public javax.faces.event.ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof javax.faces.event.ValueChangeEvent
            ? (javax.faces.event.ValueChangeEvent)this.event : null;
    }

    public javax.faces.event.ActionEvent getActionEvent()
    {
        return this.event instanceof javax.faces.event.ActionEvent
            ? (javax.faces.event.ActionEvent)this.event : null;
    }

    private java.lang.String first;

    /**
     * 
     */
    public java.lang.String getFirst()
    {
        return this.first;
    }

    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;

    /**
     * Resets the value of the firstSet to false
     */
    public void resetFirstSet()
    {
        this.firstSet = false;
    }

    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(java.lang.String first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] firstValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] firstLabelList;
    public java.lang.Object[] getFirstBackingList()
    {
        java.lang.Object[] values = this.firstValueList;
        java.lang.Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(java.lang.Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public java.lang.Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(java.lang.Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new java.lang.Object[items.size()];
            this.firstLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.firstValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.firstLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.firstLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    private java.lang.String unknownParameter;

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }

    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;

    /**
     * Resets the value of the unknownParameterSet to false
     */
    public void resetUnknownParameterSet()
    {
        this.unknownParameterSet = false;
    }

    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] unknownParameterValueList;

    /**
     * Stores the labels
     */
    private java.lang.Object[] unknownParameterLabelList;
    public java.lang.Object[] getUnknownParameterBackingList()
    {
        java.lang.Object[] values = this.unknownParameterValueList;
        java.lang.Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(java.lang.Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public java.lang.Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(java.lang.Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setUnknownParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new java.lang.Object[items.size()];
            this.unknownParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                final java.util.List<String> labelProperties =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final java.util.List<String> labelDelimiters =
                    labelProperty == null ? null : new java.util.ArrayList(java.util.Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.unknownParameterValueList[ctr] = valueProperty == null ? item :
                        org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.unknownParameterLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (org.apache.commons.beanutils.PropertyUtils.isReadable(item, property))
                                {
                                    Object value = org.apache.commons.beanutils.PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.unknownParameterLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetFirstSet();
         this.resetUnknownParameterSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map<java.lang.String, java.text.DateFormat> dateTimeFormatters =
        new java.util.HashMap<java.lang.String, java.text.DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map<java.lang.String, java.text.DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient java.util.Map<java.lang.String, javax.faces.application.FacesMessage> jsfMessages =
        new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection<javax.faces.application.FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new java.util.LinkedHashMap<java.lang.String, javax.faces.application.FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection<javax.faces.application.FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public javax.faces.application.FacesMessage.Severity getMaximumMessageSeverity()
    {
        javax.faces.application.FacesMessage.Severity maxSeverity = null;
        for (final javax.faces.application.FacesMessage message : this.getJsfMessages())
        {
            final javax.faces.application.FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7930484190843311977L;
}
