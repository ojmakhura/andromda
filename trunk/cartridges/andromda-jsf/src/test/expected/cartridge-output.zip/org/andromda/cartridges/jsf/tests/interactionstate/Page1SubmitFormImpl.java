// license-header java merge-point
package org.andromda.cartridges.jsf.tests.interactionstate;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.faces.application.FacesMessage;
import javax.faces.event.ActionEvent;
import javax.faces.event.FacesEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import org.apache.commons.beanutils.PropertyUtils;

/**
 * 
 */
public class Page1SubmitFormImpl
    implements Serializable
{
    public Page1SubmitFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        final DateFormat dateFormatter = new SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private transient FacesEvent event;

    public void setEvent(FacesEvent event)
    {
        this.event = event;
    }

    public ValueChangeEvent getValueChangeEvent()
    {
        return this.event instanceof ValueChangeEvent
            ? (ValueChangeEvent)this.event : null;
    }

    public ActionEvent getActionEvent()
    {
        return this.event instanceof ActionEvent
            ? (ActionEvent)this.event : null;
    }

    private int interActionStateParam;

    /**
     * 
     */
    public int getInterActionStateParam()
    {
        return this.interActionStateParam;
    }

    /**
     * Keeps track of whether or not the value of interActionStateParam has
     * be populated at least once.
     */
    private boolean interActionStateParamSet = false;

    /**
     * Resets the value of the interActionStateParamSet to false
     */
    public void resetInterActionStateParamSet()
    {
        this.interActionStateParamSet = false;
    }

    /**
     * Indicates whether or not the value for interActionStateParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isInterActionStateParamSet()
    {
        return this.interActionStateParamSet;
    }

    /**
     * 
     */
    public void setInterActionStateParam(int interActionStateParam)
    {
        this.interActionStateParam = interActionStateParam;
        this.interActionStateParamSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] interActionStateParamValueList;

    /**
     * Stores the labels
     */
    private Object[] interActionStateParamLabelList;
    public Object[] getInterActionStateParamBackingList()
    {
        Object[] values = this.interActionStateParamValueList;
        Object[] labels = this.interActionStateParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getInterActionStateParamValueList()
    {
        return this.interActionStateParamValueList;
    }

    public void setInterActionStateParamValueList(Object[] interActionStateParamValueList)
    {
        this.interActionStateParamValueList = interActionStateParamValueList;
    }

    public Object[] getInterActionStateParamLabelList()
    {
        return this.interActionStateParamLabelList;
    }

    public void setInterActionStateParamLabelList(Object[] interActionStateParamLabelList)
    {
        this.interActionStateParamLabelList = interActionStateParamLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setInterActionStateParamBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.interActionStateParamValueList = null;
        this.interActionStateParamLabelList = null;
        if (items != null)
        {
            this.interActionStateParamValueList = new Object[items.size()];
            this.interActionStateParamLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.interActionStateParamValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.interActionStateParamLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.interActionStateParamLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    private String param;

    /**
     * 
     */
    public String getParam()
    {
        return this.param;
    }

    /**
     * Keeps track of whether or not the value of param has
     * be populated at least once.
     */
    private boolean paramSet = false;

    /**
     * Resets the value of the paramSet to false
     */
    public void resetParamSet()
    {
        this.paramSet = false;
    }

    /**
     * Indicates whether or not the value for param has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParamSet()
    {
        return this.paramSet;
    }

    /**
     * 
     */
    public void setParam(String param)
    {
        this.param = param;
        this.paramSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] paramValueList;

    /**
     * Stores the labels
     */
    private Object[] paramLabelList;
    public Object[] getParamBackingList()
    {
        Object[] values = this.paramValueList;
        Object[] labels = this.paramLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        SelectItem[] backingList = new SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParamValueList()
    {
        return this.paramValueList;
    }

    public void setParamValueList(Object[] paramValueList)
    {
        this.paramValueList = paramValueList;
    }

    public Object[] getParamLabelList()
    {
        return this.paramLabelList;
    }

    public void setParamLabelList(Object[] paramLabelList)
    {
        this.paramLabelList = paramLabelList;
    }

    @SuppressWarnings("unchecked")
    public void setParamBackingList(Collection items, String valueProperty, String labelProperty)
    {
        this.paramValueList = null;
        this.paramLabelList = null;
        if (items != null)
        {
            this.paramValueList = new Object[items.size()];
            this.paramLabelList = new Object[items.size()];

            try
            {
                final List<String> labelProperties =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\W&&[^\\.]]+")));
                final List<String> labelDelimiters =
                    labelProperty == null ? null : new ArrayList(Arrays.asList(labelProperty.split("[\\w\\.]+")));
                int ctr = 0;
                for (final Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.paramValueList[ctr] = valueProperty == null ? item :
                        PropertyUtils.getProperty(item, valueProperty.trim());
                    if (labelProperties == null)
                    {
                        this.paramLabelList[ctr] = item;
                    }
                    else
                    {
                        final StringBuilder labelText = new StringBuilder();
                        int ctr2 = 0;
                        do
                        {
                            if (!labelDelimiters.isEmpty())
                            {
                                labelText.append(labelDelimiters.get(ctr2));
                            }
                            String property = null;
                            if (ctr2 < labelProperties.size())
                            {
                                property = labelProperties.get(ctr2);
                            }
                            if (property != null && property.length() > 0)
                            {
                                if (PropertyUtils.isReadable(item, property))
                                {
                                    Object value = PropertyUtils.getProperty(item, property);
                                    if (value != null)
                                    {
                                        if (value instanceof String)
                                        {
                                            if (((String)value).trim().length() == 0)
                                            {
                                                value = null;
                                            }
                                        }
                                        if (value != null)
                                        {
                                            labelText.append(value);
                                        }
                                    }
                                }
                                else
                                {
                                    labelText.append(property);
                                }
                            }
                            ctr2++;
                        }
                        while (ctr2 < labelDelimiters.size());
                        this.paramLabelList[ctr] = labelText.toString().replaceAll("\\s+", " ").trim();
                    }
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }


    /**
     * Resets all the "isSet" flags.
     */
     public void resetIsSetFlags()
     {
         this.resetInterActionStateParamSet();
         this.resetParamSet();
     }

    /**
     * Stores any date or time formatters for this form.
     */
    private final Map<String, DateFormat> dateTimeFormatters =
        new HashMap<String, DateFormat>();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public Map<String, DateFormat> getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private transient Map<String, FacesMessage> jsfMessages =
        new LinkedHashMap<String, FacesMessage>();


    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(FacesMessage jsfMessage)
    {
        if (this.jsfMessages != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public Collection<FacesMessage> getJsfMessages()
    {
        if (this.jsfMessages == null)
        {
            this.jsfMessages = new LinkedHashMap<String, FacesMessage>();
        }
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final Collection<FacesMessage> messages)
    {
        if (messages != null)
        {
            for (final Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                FacesMessage jsfMessage = (FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The faces message title (used on a view).
     */
    private String jsfMessagesTitle;

    /**
     * The optional faces message title to set (used on a view).  If not set, the default title
     * will be used.
     *
     * @param jsfMessagesTitle the title to use for the messages on the view.
     */
    public void setJsfMessagesTitle(final String jsfMessagesTitle)
    {
        this.jsfMessagesTitle = jsfMessagesTitle;
    }

    /**
     * Gets the faces messages title to use.
     *
     * @return the faces messages title.
     */
    public String getJsfMessagesTitle()
    {
        return this.jsfMessagesTitle;
    }

    /**
     * Gets the maximum severity of the messages stored in this form.
     *
     * @return the maximum severity or null if no messages are present and/or severity isn't set.
     */
    public FacesMessage.Severity getMaximumMessageSeverity()
    {
        FacesMessage.Severity maxSeverity = null;
        for (final FacesMessage message : this.getJsfMessages())
        {
            final FacesMessage.Severity severity = message.getSeverity();
            if (maxSeverity == null || (severity != null && severity.getOrdinal() > maxSeverity.getOrdinal()))
            {
                maxSeverity = severity;
            }
        }
        return maxSeverity;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7106929459913775820L;
}
