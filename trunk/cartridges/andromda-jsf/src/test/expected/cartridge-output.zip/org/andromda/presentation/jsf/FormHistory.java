package org.andromda.presentation.jsf;

/**
 * This class keeps track of the history of the flow of the application
 * as the user navigates through, the maximum size of the history can be
 * configured throught the maximumSize property (which is set through the 
 * <em>maximumFormsInHistory</em> namespace property.
 * 
 * @author Chad Brandon
 */
public class FormHistory
    implements java.io.Serializable
{
    /**
     * The max forms kept in history.
     */
    private static final int maximumSize = 5;
    
    /**
     * Keeps the previous forms that have been used in a history.
     */
    private java.util.Stack formHistory = new java.util.Stack();
    
    /**
     * Adds a form to the history.
     *
     * @param form the form to add.
     */
    public void addFormToHistory(final Object form)
    {
        if (form != null)
        {
            if (!this.formHistory.isEmpty())
            {
                // - check to see if the last form is of the same type, if so,
                //   replace the last form with this new form
                final int lastIndex = this.formHistory.size() - 1;
                final Object lastForm = this.formHistory.get(lastIndex);
                if (lastForm != null && lastForm.getClass() == form.getClass())
                {
                    this.formHistory.remove(lastIndex);
                }
                else if (this.formHistory.size() > maximumSize)
                {
                    // otherwise we remove the first form added in the list
                    this.formHistory.remove(0);
                }
            }
            this.formHistory.add(form);
        }
    }

    /**
     * Retrieves the last form from the history and removes it.
     *
     * @return the last form.
     */
    public Object getLastFormInHistory()
    {
        Object lastForm = null;
        if (!this.formHistory.isEmpty())
        {
            final int lastIndex = this.formHistory.size() - 1;
            lastForm = this.formHistory.get(lastIndex);
            this.formHistory.remove(lastIndex);
        }
        return lastForm;
    }
    
    private static final java.util.Map triggersAndFormBeanNamesByUseCase = new java.util.HashMap();
    
    /**
     * Attemps to retrieve the trigger method name with the No Table Link Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getNoTableLinkActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("No Table Link Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.tables.notablelink.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.tables.notablelink.ShowTableDataAgainFormImpl", controllerClass.getMethod("showTableDataAgain", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.notablelink.NoTableLinkActivityFormImpl", controllerClass.getMethod("noTableLinkActivity", null));
                triggersAndFormBeanNamesByUseCase.put("No Table Link Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Table Link Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getTableLinkActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Table Link Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.tables.tablelink.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl", controllerClass.getMethod("showTableDataAgain", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl", controllerClass.getMethod("showTableDataHyperlinkAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl", controllerClass.getMethod("showTableDataBadAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl", controllerClass.getMethod("showTableDataHyperlinkActionDuplicatingParameter", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl", controllerClass.getMethod("showTableDataHyperlinkNotSpecifyingColumn", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl", controllerClass.getMethod("showTableDataActionWithBadTableLink", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl", controllerClass.getMethod("showTableDataRealisticFormAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl", controllerClass.getMethod("showTableDataImageLinkAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataGlobalTableAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataDuplicateGlobalTableAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataAnotherDuplicateGlobalTableAction", null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl", controllerClass.getMethod("tableLinkActivity", null));
                triggersAndFormBeanNamesByUseCase.put("Table Link Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Validation Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getValidationActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Validation Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.validation.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.validation.EnterDataValidateFormImpl", controllerClass.getMethod("enterDataValidate", null));
                map.put("org.andromda.cartridges.jsf.tests.validation.ValidationActivityFormImpl", controllerClass.getMethod("validationActivity", null));
                triggersAndFormBeanNamesByUseCase.put("Validation Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the TriggerPresent UseCase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getTriggerPresentUseCaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("TriggerPresent UseCase");
        if (map == null)
        {
            final Class controllerClass = ${useCase.controller.fullyQualifiedName}.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.actions.triggerpresent.SomePageDoSomethingElseFormImpl", controllerClass.getMethod("somePageDoSomethingElse", null));
                map.put("org.andromda.cartridges.jsf.tests.constraints.actions.triggerpresent.TriggerPresentUseCaseFormImpl", controllerClass.getMethod("triggerPresentUseCase", null));
                triggersAndFormBeanNamesByUseCase.put("TriggerPresent UseCase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the JspsCannotDeferCanStop 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getJspsCannotDeferCanStopTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("JspsCannotDeferCanStop");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.JspsCannotDeferCanStopFormImpl", controllerClass.getMethod("jspsCannotDeferCanStop", null));
                triggersAndFormBeanNamesByUseCase.put("JspsCannotDeferCanStop", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the OneUseCase UseCase1 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getOneUseCaseUseCase1TriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("OneUseCase UseCase1");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.Controller1.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.OneUseCaseUseCase1FormImpl", controllerClass.getMethod("oneUseCaseUseCase1", null));
                triggersAndFormBeanNamesByUseCase.put("OneUseCase UseCase1", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the OneUseCase UseCase2 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getOneUseCaseUseCase2TriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("OneUseCase UseCase2");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.Controller2.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase.OneUseCaseUseCase2FormImpl", controllerClass.getMethod("oneUseCaseUseCase2", null));
                triggersAndFormBeanNamesByUseCase.put("OneUseCase UseCase2", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the duplicate operation names 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDuplicateOperationNamesTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("duplicate operation names");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.DuplicateOperationNamesFormImpl", controllerClass.getMethod("duplicateOperationNames", null));
                triggersAndFormBeanNamesByUseCase.put("duplicate operation names", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the OperationNameAsUseCase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getOperationNameAsUseCaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("OperationNameAsUseCase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.OperationNameAsUseCaseFormImpl", controllerClass.getMethod("operationNameAsUseCase", null));
                triggersAndFormBeanNamesByUseCase.put("OperationNameAsUseCase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the ValidExceptionTarget 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getValidExceptionTargetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("ValidExceptionTarget");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.AXFormImpl", controllerClass.getMethod("aX", null));
                map.put("org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.AYFormImpl", controllerClass.getMethod("aY", null));
                map.put("org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.ValidExceptionTargetFormImpl", controllerClass.getMethod("validExceptionTarget", null));
                triggersAndFormBeanNamesByUseCase.put("ValidExceptionTarget", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsReturnTypeVoid 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsReturnTypeVoidTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsReturnTypeVoid");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.DecisionsReturnTypeVoidFormImpl", controllerClass.getMethod("decisionsReturnTypeVoid", null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsReturnTypeVoid", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsMissingCall 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsMissingCallTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsMissingCall");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall.DecisionsMissingCallFormImpl", controllerClass.getMethod("decisionsMissingCall", null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsMissingCall", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsMissingGuard 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsMissingGuardTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsMissingGuard");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.DecisionsMissingGuardFormImpl", controllerClass.getMethod("decisionsMissingGuard", null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsMissingGuard", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsBadTarget 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsBadTargetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsBadTarget");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.DecisionsBadTargetFormImpl", controllerClass.getMethod("decisionsBadTarget", null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsBadTarget", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the ActionStatesNoForward 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getActionStatesNoForwardTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("ActionStatesNoForward");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.actionstates.noforward.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.actionstates.noforward.ActionStatesNoForwardFormImpl", controllerClass.getMethod("actionStatesNoForward", null));
                triggersAndFormBeanNamesByUseCase.put("ActionStatesNoForward", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Exceptions Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getExceptionsActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Exceptions Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.exceptions.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.exceptions.EnterInfoSubmitFormImpl", controllerClass.getMethod("enterInfoSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.exceptions.ShowSomethingSubmit2FormImpl", controllerClass.getMethod("showSomethingSubmit2", null));
                map.put("org.andromda.cartridges.jsf.tests.exceptions.ExceptionsActivityFormImpl", controllerClass.getMethod("exceptionsActivity", null));
                triggersAndFormBeanNamesByUseCase.put("Exceptions Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Nohrefnoname 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getNohrefnonameTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Nohrefnoname");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.nohrefnoname.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.nohrefnoname.NohrefnonameFormImpl", controllerClass.getMethod("nohrefnoname", null));
                triggersAndFormBeanNamesByUseCase.put("Nohrefnoname", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Hyperlinked 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getHyperlinkedTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Hyperlinked");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.hyperlinked.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.hyperlinked.HyperlinkedFormImpl", controllerClass.getMethod("hyperlinked", null));
                triggersAndFormBeanNamesByUseCase.put("Hyperlinked", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Named 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getNamedTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Named");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.named.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.named.NamedFormImpl", controllerClass.getMethod("named", null));
                triggersAndFormBeanNamesByUseCase.put("Named", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Hyperlinkednotusecase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getHyperlinkednotusecaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Hyperlinkednotusecase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.hyperlinkednotusecase.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.hyperlinkednotusecase.HyperlinkednotusecaseFormImpl", controllerClass.getMethod("hyperlinkednotusecase", null));
                triggersAndFormBeanNamesByUseCase.put("Hyperlinkednotusecase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Namednotusecase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getNamednotusecaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Namednotusecase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.namednotusecase.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.namednotusecase.NamednotusecaseFormImpl", controllerClass.getMethod("namednotusecase", null));
                triggersAndFormBeanNamesByUseCase.put("Namednotusecase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the FinalStatesWebPage 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getFinalStatesWebPageTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("FinalStatesWebPage");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.finalstates.webpage.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.finalstates.webpage.SomethingAFormImpl", controllerClass.getMethod("somethingA", null));
                map.put("org.andromda.cartridges.jsf.tests.finalstates.webpage.SomethingBFormImpl", controllerClass.getMethod("somethingB", null));
                map.put("org.andromda.cartridges.jsf.tests.finalstates.webpage.SomethingCFormImpl", controllerClass.getMethod("somethingC", null));
                map.put("org.andromda.cartridges.jsf.tests.finalstates.webpage.SomethingDFormImpl", controllerClass.getMethod("somethingD", null));
                map.put("org.andromda.cartridges.jsf.tests.finalstates.webpage.FinalStatesWebPageFormImpl", controllerClass.getMethod("finalStatesWebPage", null));
                triggersAndFormBeanNamesByUseCase.put("FinalStatesWebPage", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the SessionObject Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getSessionObjectActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("SessionObject Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.sessionobjects.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.sessionobjects.SessionObjectActivityFormImpl", controllerClass.getMethod("sessionObjectActivity", null));
                triggersAndFormBeanNamesByUseCase.put("SessionObject Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Widgets Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getWidgetsActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Widgets Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.widgets.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.widgets.ShowWidgetsSubmitFormImpl", controllerClass.getMethod("showWidgetsSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.widgets.WidgetsActivityFormImpl", controllerClass.getMethod("widgetsActivity", null));
                triggersAndFormBeanNamesByUseCase.put("Widgets Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Hyperlinkactions 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getHyperlinkactionsTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Hyperlinkactions");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.hyperlinkactions.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingParamhrefFormImpl", controllerClass.getMethod("showSomethingParamhref", null));
                map.put("org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingNoparamhrefFormImpl", controllerClass.getMethod("showSomethingNoparamhref", null));
                map.put("org.andromda.cartridges.jsf.tests.hyperlinkactions.HyperlinkactionsFormImpl", controllerClass.getMethod("hyperlinkactions", null));
                triggersAndFormBeanNamesByUseCase.put("Hyperlinkactions", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DeferringOperations 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDeferringOperationsTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DeferringOperations");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.deferringoperations.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl", controllerClass.getMethod("state2Trigger2", null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl", controllerClass.getMethod("state2Trigger2b", null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl", controllerClass.getMethod("state4Trigger4", null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl", controllerClass.getMethod("state4Null", null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl", controllerClass.getMethod("deferringOperations", null));
                triggersAndFormBeanNamesByUseCase.put("DeferringOperations", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DuplicateActions usecase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDuplicateActionsUsecaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DuplicateActions usecase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.duplicateactions.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.duplicateactions.ShowSomethingSendFormImpl", controllerClass.getMethod("showSomethingSend", null));
                map.put("org.andromda.cartridges.jsf.tests.duplicateactions.ShowSomethingSubmitFormImpl", controllerClass.getMethod("showSomethingSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.duplicateactions.ShowSomethingSubmitFormImpl", controllerClass.getMethod("showSomethingSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.duplicateactions.DuplicateActionsUsecaseFormImpl", controllerClass.getMethod("duplicateActionsUsecase", null));
                triggersAndFormBeanNamesByUseCase.put("DuplicateActions usecase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Messages Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getMessagesActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Messages Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.messages.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.messages.ThreeSubmitFormImpl", controllerClass.getMethod("threeSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.messages.MessagesActivityFormImpl", controllerClass.getMethod("messagesActivity", null));
                triggersAndFormBeanNamesByUseCase.put("Messages Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the FormFields 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getFormFieldsTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("FormFields");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.formfields.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl", controllerClass.getMethod("oneSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl", controllerClass.getMethod("threeGo", null));
                map.put("org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl", controllerClass.getMethod("formFields", null));
                triggersAndFormBeanNamesByUseCase.put("FormFields", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the EmptyGraph 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getEmptyGraphTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("EmptyGraph");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.emptygraph.Controller.class;
            try
            {
                triggersAndFormBeanNamesByUseCase.put("EmptyGraph", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the EmptyUseCase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getEmptyUseCaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("EmptyUseCase");
        if (map == null)
        {
            final Class controllerClass = ${useCase.controller.fullyQualifiedName}.class;
            try
            {
                triggersAndFormBeanNamesByUseCase.put("EmptyUseCase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the PageVariables 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getPageVariablesTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("PageVariables");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.pagevariables.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.pagevariables.ShowSomethingSubmitFormImpl", controllerClass.getMethod("showSomethingSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.pagevariables.PageVariablesFormImpl", controllerClass.getMethod("pageVariables", null));
                triggersAndFormBeanNamesByUseCase.put("PageVariables", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the InterUseCaseSource 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getInterUseCaseSourceTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("InterUseCaseSource");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.interusecase.source.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.interusecase.source.SourceSubmitFormImpl", controllerClass.getMethod("sourceSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.interusecase.source.InterUseCaseSourceFormImpl", controllerClass.getMethod("interUseCaseSource", null));
                triggersAndFormBeanNamesByUseCase.put("InterUseCaseSource", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the InterUseCaseTarget 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getInterUseCaseTargetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("InterUseCaseTarget");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.interusecase.target.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.interusecase.target.InterUseCaseTargetFormImpl", controllerClass.getMethod("interUseCaseTarget", null));
                triggersAndFormBeanNamesByUseCase.put("InterUseCaseTarget", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Redirect 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getRedirectTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Redirect");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.redirect.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.redirect.RedirectFormImpl", controllerClass.getMethod("redirect", null));
                triggersAndFormBeanNamesByUseCase.put("Redirect", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Services 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getServicesTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Services");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.services.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.services.ServicesFormImpl", controllerClass.getMethod("services", null));
                triggersAndFormBeanNamesByUseCase.put("Services", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Reset 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getResetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Reset");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.reset.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.reset.ResetPageSendWithResetFormImpl", controllerClass.getMethod("resetPageSendWithReset", null));
                map.put("org.andromda.cartridges.jsf.tests.reset.ResetFormImpl", controllerClass.getMethod("reset", null));
                triggersAndFormBeanNamesByUseCase.put("Reset", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the InterActionState 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getInterActionStateTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("InterActionState");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.interactionstate.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.interactionstate.Page1SubmitFormImpl", controllerClass.getMethod("page1Submit", null));
                map.put("org.andromda.cartridges.jsf.tests.interactionstate.InterActionStateFormImpl", controllerClass.getMethod("interActionState", null));
                triggersAndFormBeanNamesByUseCase.put("InterActionState", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the GraphOutUseCase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getGraphOutUseCaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("GraphOutUseCase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.graphoutusecase.usecase.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.graphoutusecase.usecase.GraphOutUseCaseFormImpl", controllerClass.getMethod("graphOutUseCase", null));
                triggersAndFormBeanNamesByUseCase.put("GraphOutUseCase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the ControllerTV 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getControllerTVTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("ControllerTV");
        if (map == null)
        {
            final Class controllerClass = ${useCase.controller.fullyQualifiedName}.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.controllertv.ControllerTVFormImpl", controllerClass.getMethod("controllerTV", null));
                triggersAndFormBeanNamesByUseCase.put("ControllerTV", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the FormScope 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getFormScopeTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("FormScope");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.formscope.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.formscope.APageSubmitFormImpl", controllerClass.getMethod("aPageSubmit", null));
                map.put("org.andromda.cartridges.jsf.tests.formscope.FormScopeFormImpl", controllerClass.getMethod("formScope", null));
                triggersAndFormBeanNamesByUseCase.put("FormScope", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    
}
