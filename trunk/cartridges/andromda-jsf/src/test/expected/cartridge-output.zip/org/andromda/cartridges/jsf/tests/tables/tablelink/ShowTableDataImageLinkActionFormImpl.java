// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataImageLinkActionFormImpl
    implements java.io.Serializable
{
    public ShowTableDataImageLinkActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.util.List tableData;

    /**
     * 
     */
    public java.util.List getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(java.util.List tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataValueList;
    
    /**
     * Stores the labels
     */
    private Object[] tableDataLabelList;
    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    public void setTableDataBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new Object[items.size()];
            this.tableDataLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.tableDataValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.tableDataValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.tableDataLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTableDataBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTableDataBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection tableDataBackingValue;

    public void setTableDataBackingValue(java.util.Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }
    
    public java.util.Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private java.lang.String[] multiboxThing;

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }

    /**
     * Keeps track of whether or not the value of multiboxThing has
     * be populated at least once.
     */
    private boolean multiboxThingSet = false;

    /**
     * Indicates whether or not the value for multiboxThing has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiboxThingSet()
    {
        return this.multiboxThingSet;
    }

    /**
     * 
     */
    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
        this.multiboxThingSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiboxThingValueList;
    
    /**
     * Stores the labels
     */
    private Object[] multiboxThingLabelList;
    public Object[] getMultiboxThingBackingList()
    {
        Object[] values = this.multiboxThingValueList;
        Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    public void setMultiboxThingBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setMultiboxThingBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;
        if (items != null)
        {
            this.multiboxThingValueList = new Object[items.size()];
            this.multiboxThingLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiboxThingValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.multiboxThingValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.multiboxThingValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.multiboxThingLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setMultiboxThingBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setMultiboxThingBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.lang.String[] multiboxThingBackingValue;

    public void setMultiboxThingBackingValue(java.lang.String[] multiboxThingBackingValue)
    {
        this.multiboxThingBackingValue = multiboxThingBackingValue;
    }
    
    public java.lang.String[] getMultiboxThingBackingValue()
    {
        return this.multiboxThingBackingValue;
    }


    private java.util.List tableDataDefaultExportTypes;

    /**
     * 
     */
    public java.util.List getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataDefaultExportTypes has
     * be populated at least once.
     */
    private boolean tableDataDefaultExportTypesSet = false;

    /**
     * Indicates whether or not the value for tableDataDefaultExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataDefaultExportTypesSet()
    {
        return this.tableDataDefaultExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataDefaultExportTypes(java.util.List tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
        this.tableDataDefaultExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataDefaultExportTypesValueList;
    
    /**
     * Stores the labels
     */
    private Object[] tableDataDefaultExportTypesLabelList;
    public Object[] getTableDataDefaultExportTypesBackingList()
    {
        Object[] values = this.tableDataDefaultExportTypesValueList;
        Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataDefaultExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataDefaultExportTypesValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.tableDataDefaultExportTypesValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.tableDataDefaultExportTypesValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.tableDataDefaultExportTypesLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTableDataDefaultExportTypesBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection tableDataDefaultExportTypesBackingValue;

    public void setTableDataDefaultExportTypesBackingValue(java.util.Collection tableDataDefaultExportTypesBackingValue)
    {
        this.tableDataDefaultExportTypesBackingValue = tableDataDefaultExportTypesBackingValue;
    }
    
    public java.util.Collection getTableDataDefaultExportTypesBackingValue()
    {
        return this.tableDataDefaultExportTypesBackingValue;
    }


    private java.util.List tableDataNoExportTypes;

    /**
     * 
     */
    public java.util.List getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    /**
     * Keeps track of whether or not the value of tableDataNoExportTypes has
     * be populated at least once.
     */
    private boolean tableDataNoExportTypesSet = false;

    /**
     * Indicates whether or not the value for tableDataNoExportTypes has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNoExportTypesSet()
    {
        return this.tableDataNoExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataNoExportTypes(java.util.List tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
        this.tableDataNoExportTypesSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataNoExportTypesValueList;
    
    /**
     * Stores the labels
     */
    private Object[] tableDataNoExportTypesLabelList;
    public Object[] getTableDataNoExportTypesBackingList()
    {
        Object[] values = this.tableDataNoExportTypesValueList;
        Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataNoExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new Object[items.size()];
            this.tableDataNoExportTypesLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataNoExportTypesValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.tableDataNoExportTypesValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.tableDataNoExportTypesValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.tableDataNoExportTypesLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTableDataNoExportTypesBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTableDataNoExportTypesBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection tableDataNoExportTypesBackingValue;

    public void setTableDataNoExportTypesBackingValue(java.util.Collection tableDataNoExportTypesBackingValue)
    {
        this.tableDataNoExportTypesBackingValue = tableDataNoExportTypesBackingValue;
    }
    
    public java.util.Collection getTableDataNoExportTypesBackingValue()
    {
        return this.tableDataNoExportTypesBackingValue;
    }


    private java.util.List tableDataNotSortable;

    /**
     * 
     */
    public java.util.List getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }

    /**
     * Keeps track of whether or not the value of tableDataNotSortable has
     * be populated at least once.
     */
    private boolean tableDataNotSortableSet = false;

    /**
     * Indicates whether or not the value for tableDataNotSortable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataNotSortableSet()
    {
        return this.tableDataNotSortableSet;
    }

    /**
     * 
     */
    public void setTableDataNotSortable(java.util.List tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
        this.tableDataNotSortableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] tableDataNotSortableValueList;
    
    /**
     * Stores the labels
     */
    private Object[] tableDataNotSortableLabelList;
    public Object[] getTableDataNotSortableBackingList()
    {
        Object[] values = this.tableDataNotSortableValueList;
        Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataNotSortableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;
        if (items != null)
        {
            this.tableDataNotSortableValueList = new Object[items.size()];
            this.tableDataNotSortableLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.tableDataNotSortableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.tableDataNotSortableValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.tableDataNotSortableValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.tableDataNotSortableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTableDataNotSortableBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTableDataNotSortableBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection tableDataNotSortableBackingValue;

    public void setTableDataNotSortableBackingValue(java.util.Collection tableDataNotSortableBackingValue)
    {
        this.tableDataNotSortableBackingValue = tableDataNotSortableBackingValue;
    }
    
    public java.util.Collection getTableDataNotSortableBackingValue()
    {
        return this.tableDataNotSortableBackingValue;
    }


    private int first;

    /**
     * 
     */
    public int getFirst()
    {
        return this.first;
    }

    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;

    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(int first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] firstValueList;
    
    /**
     * Stores the labels
     */
    private Object[] firstLabelList;
    public Object[] getFirstBackingList()
    {
        Object[] values = this.firstValueList;
        Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    public void setFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new Object[items.size()];
            this.firstLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.firstValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.firstValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.firstValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.firstLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFirstBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String third;

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }

    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;

    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(java.lang.String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thirdValueList;
    
    /**
     * Stores the labels
     */
    private Object[] thirdLabelList;
    public Object[] getThirdBackingList()
    {
        Object[] values = this.thirdValueList;
        Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThirdBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new Object[items.size()];
            this.thirdLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thirdValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.thirdValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.thirdValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.thirdLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setThirdBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setThirdBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String two;

    /**
     * 
     */
    public java.lang.String getTwo()
    {
        return this.two;
    }

    /**
     * Keeps track of whether or not the value of two has
     * be populated at least once.
     */
    private boolean twoSet = false;

    /**
     * Indicates whether or not the value for two has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTwoSet()
    {
        return this.twoSet;
    }

    /**
     * 
     */
    public void setTwo(java.lang.String two)
    {
        this.two = two;
        this.twoSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] twoValueList;
    
    /**
     * Stores the labels
     */
    private Object[] twoLabelList;
    public Object[] getTwoBackingList()
    {
        Object[] values = this.twoValueList;
        Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    public void setTwoBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTwoBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.twoValueList = null;
        this.twoLabelList = null;
        if (items != null)
        {
            this.twoValueList = new Object[items.size()];
            this.twoLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.twoValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.twoValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.twoValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.twoLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTwoBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTwoBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String second;

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }

    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;

    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(java.lang.String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] secondValueList;
    
    /**
     * Stores the labels
     */
    private Object[] secondLabelList;
    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setSecondBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new Object[items.size()];
            this.secondLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.secondValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.secondValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.secondValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.secondLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setSecondBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setSecondBackingList(items, valueProperty, labelProperty, null);
    }
    


    private int formParam1;

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }

    /**
     * Keeps track of whether or not the value of formParam1 has
     * be populated at least once.
     */
    private boolean formParam1Set = false;

    /**
     * Indicates whether or not the value for formParam1 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam1Set()
    {
        return this.formParam1Set;
    }

    /**
     * 
     */
    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
        this.formParam1Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] formParam1ValueList;
    
    /**
     * Stores the labels
     */
    private Object[] formParam1LabelList;
    public Object[] getFormParam1BackingList()
    {
        Object[] values = this.formParam1ValueList;
        Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    public void setFormParam1BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFormParam1BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.formParam1ValueList = null;
        this.formParam1LabelList = null;
        if (items != null)
        {
            this.formParam1ValueList = new Object[items.size()];
            this.formParam1LabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.formParam1ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.formParam1ValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.formParam1ValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.formParam1LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFormParam1BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFormParam1BackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String formParam2;

    /**
     * 
     */
    public java.lang.String getFormParam2()
    {
        return this.formParam2;
    }

    /**
     * Keeps track of whether or not the value of formParam2 has
     * be populated at least once.
     */
    private boolean formParam2Set = false;

    /**
     * Indicates whether or not the value for formParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFormParam2Set()
    {
        return this.formParam2Set;
    }

    /**
     * 
     */
    public void setFormParam2(java.lang.String formParam2)
    {
        this.formParam2 = formParam2;
        this.formParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private Object[] formParam2ValueList;
    
    /**
     * Stores the labels
     */
    private Object[] formParam2LabelList;
    public Object[] getFormParam2BackingList()
    {
        Object[] values = this.formParam2ValueList;
        Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    public void setFormParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFormParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.formParam2ValueList = null;
        this.formParam2LabelList = null;
        if (items != null)
        {
            this.formParam2ValueList = new Object[items.size()];
            this.formParam2LabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.formParam2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.formParam2ValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.formParam2ValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.formParam2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFormParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFormParam2BackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String parameterWithDefaultValue = "aDefaultValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;

    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
        this.parameterWithDefaultValueSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] parameterWithDefaultValueValueList;
    
    /**
     * Stores the labels
     */
    private Object[] parameterWithDefaultValueLabelList;
    public Object[] getParameterWithDefaultValueBackingList()
    {
        Object[] values = this.parameterWithDefaultValueValueList;
        Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new Object[items.size()];
            this.parameterWithDefaultValueLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.parameterWithDefaultValueValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.parameterWithDefaultValueValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.parameterWithDefaultValueValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.parameterWithDefaultValueLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setParameterWithDefaultValueBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setParameterWithDefaultValueBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String fourth;

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }

    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;

    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] fourthValueList;
    
    /**
     * Stores the labels
     */
    private Object[] fourthLabelList;
    public Object[] getFourthBackingList()
    {
        Object[] values = this.fourthValueList;
        Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFourthBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new Object[items.size()];
            this.fourthLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.fourthValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.fourthValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.fourthValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.fourthLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFourthBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFourthBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String thisOneShouldbeNamedFirst;

    /**
     * 
     */
    public java.lang.String getThisOneShouldbeNamedFirst()
    {
        return this.thisOneShouldbeNamedFirst;
    }

    /**
     * Keeps track of whether or not the value of thisOneShouldbeNamedFirst has
     * be populated at least once.
     */
    private boolean thisOneShouldbeNamedFirstSet = false;

    /**
     * Indicates whether or not the value for thisOneShouldbeNamedFirst has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisOneShouldbeNamedFirstSet()
    {
        return this.thisOneShouldbeNamedFirstSet;
    }

    /**
     * 
     */
    public void setThisOneShouldbeNamedFirst(java.lang.String thisOneShouldbeNamedFirst)
    {
        this.thisOneShouldbeNamedFirst = thisOneShouldbeNamedFirst;
        this.thisOneShouldbeNamedFirstSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thisOneShouldbeNamedFirstValueList;
    
    /**
     * Stores the labels
     */
    private Object[] thisOneShouldbeNamedFirstLabelList;
    public Object[] getThisOneShouldbeNamedFirstBackingList()
    {
        Object[] values = this.thisOneShouldbeNamedFirstValueList;
        Object[] labels = this.thisOneShouldbeNamedFirstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThisOneShouldbeNamedFirstValueList()
    {
        return this.thisOneShouldbeNamedFirstValueList;
    }

    public void setThisOneShouldbeNamedFirstValueList(Object[] thisOneShouldbeNamedFirstValueList)
    {
        this.thisOneShouldbeNamedFirstValueList = thisOneShouldbeNamedFirstValueList;
    }

    public Object[] getThisOneShouldbeNamedFirstLabelList()
    {
        return this.thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstLabelList(Object[] thisOneShouldbeNamedFirstLabelList)
    {
        this.thisOneShouldbeNamedFirstLabelList = thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.thisOneShouldbeNamedFirstValueList = null;
        this.thisOneShouldbeNamedFirstLabelList = null;
        if (items != null)
        {
            this.thisOneShouldbeNamedFirstValueList = new Object[items.size()];
            this.thisOneShouldbeNamedFirstLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thisOneShouldbeNamedFirstValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.thisOneShouldbeNamedFirstValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.thisOneShouldbeNamedFirstValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.thisOneShouldbeNamedFirstLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setThisOneShouldbeNamedFirstBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String unknownParameter;

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }

    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;

    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] unknownParameterValueList;
    
    /**
     * Stores the labels
     */
    private Object[] unknownParameterLabelList;
    public Object[] getUnknownParameterBackingList()
    {
        Object[] values = this.unknownParameterValueList;
        Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    public void setUnknownParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setUnknownParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new Object[items.size()];
            this.unknownParameterLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.unknownParameterValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.unknownParameterValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.unknownParameterValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.unknownParameterLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setUnknownParameterBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setUnknownParameterBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;

    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    
    /**
     * Stores the labels
     */
    private Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setThisParameterNameDoesNotExistAsTableColumnBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -8781870034843984613L;
}