// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataImageLinkActionFormImpl
    implements java.io.Serializable    
{
    public ShowTableDataImageLinkActionFormImpl()
    {
    }

    private int first;

    /**
     * 
     */
    public int getFirst()
    {
        return this.first;
    }
    
    /**
     * Keeps track of whether or not the value of first has
     * be populated at least once.
     */
    private boolean firstSet = false;
    
    /**
     * Indicates whether or not the value for first has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isFirstSet()
    {
        return this.firstSet;
    }

    /**
     * 
     */
    public void setFirst(int first)
    {
        this.first = first;
        this.firstSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] firstValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] firstLabelList;
    public java.lang.Object[] getFirstBackingList()
    {
        java.lang.Object[] values = this.firstValueList;
        java.lang.Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(java.lang.Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public java.lang.Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(java.lang.Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    public void setFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.firstValueList = null;
        this.firstLabelList = null;
        if (items != null)
        {
            this.firstValueList = new java.lang.Object[items.size()];
            this.firstLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.firstValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.firstLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String[] multiboxThing;

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        if (this.multiboxThing != null)
        {
            this.multiboxThing = (java.lang.String[])org.andromda.presentation.jsf.CollectionSorter.sort(
                java.util.Arrays.asList(this.multiboxThing), 
                this.getMultiboxThingSortColumn(), 
                this.isMultiboxThingSortAscending()).toArray(new java.lang.String[]{});
        }
        return this.multiboxThing;
    }
    
    /**
     * Keeps track of whether or not the value of multiboxThing has
     * be populated at least once.
     */
    private boolean multiboxThingSet = false;
    
    /**
     * Indicates whether or not the value for multiboxThing has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isMultiboxThingSet()
    {
        return this.multiboxThingSet;
    }

    /**
     * 
     */
    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
        this.multiboxThingSet = true;
    }
    /**
     * The name of the sort column for the {@link #multiboxThing} collection.
     */
    private String multiboxThingSortColumn;

    /**
     * Gets the name of the sort column for the {@link #multiboxThing} collection.
     * 
     * @return the name of the sort column.
     */
    public String getMultiboxThingSortColumn()
    {
        return this.multiboxThingSortColumn;
    }

    /**
     * Sets the name of the {@link #multiboxThing} sort column.
     * 
     * @param multiboxThingSortColumn the name of the column by which {@link #multiboxThing}
     *        are sorted by.
     */
    public void setMultiboxThingSortColumn(final String multiboxThingSortColumn)
    {
        this.multiboxThingSortColumn = multiboxThingSortColumn;
    }
    
    /**
     * The flag indicating whether or not {@link #multiboxThing} should be sorted
     * ascending.
     */
    private boolean multiboxThingSortAscending = false;

    /**
     * Indicates whether or not {@link #multiboxThing} should be sorted ascending
     * or not.
     * 
     * @return true/false
     */
    public boolean isMultiboxThingSortAscending()
    {
        return this.multiboxThingSortAscending;
    }

    /**
     * Sets whether or not {@link #multiboxThing} should be sorted ascending.
     * 
     * @param multiboxThingSortAscending true/false
     */
    public void setMultiboxThingSortAscending(final boolean multiboxThingSortAscending)
    {
        this.multiboxThingSortAscending = multiboxThingSortAscending;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] multiboxThingValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] multiboxThingLabelList;
    public java.lang.Object[] getMultiboxThingBackingList()
    {
        java.lang.Object[] values = this.multiboxThingValueList;
        java.lang.Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(java.lang.Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public java.lang.Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(java.lang.Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    public void setMultiboxThingBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setMultiboxThingBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;
        if (items != null)
        {
            this.multiboxThingValueList = new java.lang.Object[items.size()];
            this.multiboxThingLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.multiboxThingValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiboxThingLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    private java.lang.String[] multiboxThingBackingValue;

    public void setMultiboxThingBackingValue(java.lang.String[] multiboxThingBackingValue)
    {
        this.multiboxThingBackingValue = multiboxThingBackingValue;
    }
    
    public java.lang.String[] getMultiboxThingBackingValue()
    {
        return this.multiboxThingBackingValue;
    }


    private java.lang.String parameterWithDefaultValue = "aDefaultValue";

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }
    
    /**
     * Keeps track of whether or not the value of parameterWithDefaultValue has
     * be populated at least once.
     */
    private boolean parameterWithDefaultValueSet = false;
    
    /**
     * Indicates whether or not the value for parameterWithDefaultValue has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isParameterWithDefaultValueSet()
    {
        return this.parameterWithDefaultValueSet;
    }


    private java.util.List tableData;

    /**
     * 
     */
    public java.util.List getTableData()
    {
        return this.tableData;
    }
    
    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;
    
    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(java.util.List tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }
    /**
     * The name of the sort column for the {@link #tableData} collection.
     */
    private String tableDataSortColumn;

    /**
     * Gets the name of the sort column for the {@link #tableData} collection.
     * 
     * @return the name of the sort column.
     */
    public String getTableDataSortColumn()
    {
        return this.tableDataSortColumn;
    }

    /**
     * Sets the name of the {@link #tableData} sort column.
     * 
     * @param tableDataSortColumn the name of the column by which {@link #tableData}
     *        are sorted by.
     */
    public void setTableDataSortColumn(final String tableDataSortColumn)
    {
        this.tableDataSortColumn = tableDataSortColumn;
    }
    
    /**
     * The flag indicating whether or not {@link #tableData} should be sorted
     * ascending.
     */
    private boolean tableDataSortAscending = false;

    /**
     * Indicates whether or not {@link #tableData} should be sorted ascending
     * or not.
     * 
     * @return true/false
     */
    public boolean isTableDataSortAscending()
    {
        return this.tableDataSortAscending;
    }

    /**
     * Sets whether or not {@link #tableData} should be sorted ascending.
     * 
     * @param tableDataSortAscending true/false
     */
    public void setTableDataSortAscending(final boolean tableDataSortAscending)
    {
        this.tableDataSortAscending = tableDataSortAscending;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataLabelList;
    public java.lang.Object[] getTableDataBackingList()
    {
        java.lang.Object[] values = this.tableDataValueList;
        java.lang.Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(java.lang.Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public java.lang.Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(java.lang.Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new java.lang.Object[items.size()];
            this.tableDataLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    private java.util.Collection tableDataBackingValue;

    public void setTableDataBackingValue(java.util.Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }
    
    public java.util.Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private java.lang.String third;

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }
    
    /**
     * Keeps track of whether or not the value of third has
     * be populated at least once.
     */
    private boolean thirdSet = false;
    
    /**
     * Indicates whether or not the value for third has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isThirdSet()
    {
        return this.thirdSet;
    }

    /**
     * 
     */
    public void setThird(java.lang.String third)
    {
        this.third = third;
        this.thirdSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thirdValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thirdLabelList;
    public java.lang.Object[] getThirdBackingList()
    {
        java.lang.Object[] values = this.thirdValueList;
        java.lang.Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(java.lang.Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public java.lang.Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(java.lang.Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.thirdValueList = null;
        this.thirdLabelList = null;
        if (items != null)
        {
            this.thirdValueList = new java.lang.Object[items.size()];
            this.thirdLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thirdValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thirdLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String second;

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    
    /**
     * Keeps track of whether or not the value of second has
     * be populated at least once.
     */
    private boolean secondSet = false;
    
    /**
     * Indicates whether or not the value for second has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isSecondSet()
    {
        return this.secondSet;
    }

    /**
     * 
     */
    public void setSecond(java.lang.String second)
    {
        this.second = second;
        this.secondSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] secondValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] secondLabelList;
    public java.lang.Object[] getSecondBackingList()
    {
        java.lang.Object[] values = this.secondValueList;
        java.lang.Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(java.lang.Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public java.lang.Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(java.lang.Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.secondValueList = null;
        this.secondLabelList = null;
        if (items != null)
        {
            this.secondValueList = new java.lang.Object[items.size()];
            this.secondLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.secondValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.secondLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String thisOneShouldbeNamedFirst;

    /**
     * 
     */
    public java.lang.String getThisOneShouldbeNamedFirst()
    {
        return this.thisOneShouldbeNamedFirst;
    }
    
    /**
     * Keeps track of whether or not the value of thisOneShouldbeNamedFirst has
     * be populated at least once.
     */
    private boolean thisOneShouldbeNamedFirstSet = false;
    
    /**
     * Indicates whether or not the value for thisOneShouldbeNamedFirst has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isThisOneShouldbeNamedFirstSet()
    {
        return this.thisOneShouldbeNamedFirstSet;
    }

    /**
     * 
     */
    public void setThisOneShouldbeNamedFirst(java.lang.String thisOneShouldbeNamedFirst)
    {
        this.thisOneShouldbeNamedFirst = thisOneShouldbeNamedFirst;
        this.thisOneShouldbeNamedFirstSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisOneShouldbeNamedFirstValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thisOneShouldbeNamedFirstLabelList;
    public java.lang.Object[] getThisOneShouldbeNamedFirstBackingList()
    {
        java.lang.Object[] values = this.thisOneShouldbeNamedFirstValueList;
        java.lang.Object[] labels = this.thisOneShouldbeNamedFirstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstValueList()
    {
        return this.thisOneShouldbeNamedFirstValueList;
    }

    public void setThisOneShouldbeNamedFirstValueList(java.lang.Object[] thisOneShouldbeNamedFirstValueList)
    {
        this.thisOneShouldbeNamedFirstValueList = thisOneShouldbeNamedFirstValueList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstLabelList()
    {
        return this.thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstLabelList(java.lang.Object[] thisOneShouldbeNamedFirstLabelList)
    {
        this.thisOneShouldbeNamedFirstLabelList = thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.thisOneShouldbeNamedFirstValueList = null;
        this.thisOneShouldbeNamedFirstLabelList = null;
        if (items != null)
        {
            this.thisOneShouldbeNamedFirstValueList = new java.lang.Object[items.size()];
            this.thisOneShouldbeNamedFirstLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thisOneShouldbeNamedFirstValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisOneShouldbeNamedFirstLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String formParam2;

    /**
     * 
     */
    public java.lang.String getFormParam2()
    {
        return this.formParam2;
    }
    
    /**
     * Keeps track of whether or not the value of formParam2 has
     * be populated at least once.
     */
    private boolean formParam2Set = false;
    
    /**
     * Indicates whether or not the value for formParam2 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isFormParam2Set()
    {
        return this.formParam2Set;
    }

    /**
     * 
     */
    public void setFormParam2(java.lang.String formParam2)
    {
        this.formParam2 = formParam2;
        this.formParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] formParam2ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] formParam2LabelList;
    public java.lang.Object[] getFormParam2BackingList()
    {
        java.lang.Object[] values = this.formParam2ValueList;
        java.lang.Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(java.lang.Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public java.lang.Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(java.lang.Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    public void setFormParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFormParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.formParam2ValueList = null;
        this.formParam2LabelList = null;
        if (items != null)
        {
            this.formParam2ValueList = new java.lang.Object[items.size()];
            this.formParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.formParam2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.List tableDataNoExportTypes;

    /**
     * 
     */
    public java.util.List getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }
    
    /**
     * Keeps track of whether or not the value of tableDataNoExportTypes has
     * be populated at least once.
     */
    private boolean tableDataNoExportTypesSet = false;
    
    /**
     * Indicates whether or not the value for tableDataNoExportTypes has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTableDataNoExportTypesSet()
    {
        return this.tableDataNoExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataNoExportTypes(java.util.List tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
        this.tableDataNoExportTypesSet = true;
    }
    /**
     * The name of the sort column for the {@link #tableDataNoExportTypes} collection.
     */
    private String tableDataNoExportTypesSortColumn;

    /**
     * Gets the name of the sort column for the {@link #tableDataNoExportTypes} collection.
     * 
     * @return the name of the sort column.
     */
    public String getTableDataNoExportTypesSortColumn()
    {
        return this.tableDataNoExportTypesSortColumn;
    }

    /**
     * Sets the name of the {@link #tableDataNoExportTypes} sort column.
     * 
     * @param tableDataNoExportTypesSortColumn the name of the column by which {@link #tableDataNoExportTypes}
     *        are sorted by.
     */
    public void setTableDataNoExportTypesSortColumn(final String tableDataNoExportTypesSortColumn)
    {
        this.tableDataNoExportTypesSortColumn = tableDataNoExportTypesSortColumn;
    }
    
    /**
     * The flag indicating whether or not {@link #tableDataNoExportTypes} should be sorted
     * ascending.
     */
    private boolean tableDataNoExportTypesSortAscending = false;

    /**
     * Indicates whether or not {@link #tableDataNoExportTypes} should be sorted ascending
     * or not.
     * 
     * @return true/false
     */
    public boolean isTableDataNoExportTypesSortAscending()
    {
        return this.tableDataNoExportTypesSortAscending;
    }

    /**
     * Sets whether or not {@link #tableDataNoExportTypes} should be sorted ascending.
     * 
     * @param tableDataNoExportTypesSortAscending true/false
     */
    public void setTableDataNoExportTypesSortAscending(final boolean tableDataNoExportTypesSortAscending)
    {
        this.tableDataNoExportTypesSortAscending = tableDataNoExportTypesSortAscending;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataNoExportTypesValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataNoExportTypesLabelList;
    public java.lang.Object[] getTableDataNoExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataNoExportTypesValueList;
        java.lang.Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(java.lang.Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public java.lang.Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(java.lang.Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataNoExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataNoExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataNoExportTypesValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNoExportTypesLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    private java.util.Collection tableDataNoExportTypesBackingValue;

    public void setTableDataNoExportTypesBackingValue(java.util.Collection tableDataNoExportTypesBackingValue)
    {
        this.tableDataNoExportTypesBackingValue = tableDataNoExportTypesBackingValue;
    }
    
    public java.util.Collection getTableDataNoExportTypesBackingValue()
    {
        return this.tableDataNoExportTypesBackingValue;
    }


    private java.util.List tableDataDefaultExportTypes;

    /**
     * 
     */
    public java.util.List getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }
    
    /**
     * Keeps track of whether or not the value of tableDataDefaultExportTypes has
     * be populated at least once.
     */
    private boolean tableDataDefaultExportTypesSet = false;
    
    /**
     * Indicates whether or not the value for tableDataDefaultExportTypes has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTableDataDefaultExportTypesSet()
    {
        return this.tableDataDefaultExportTypesSet;
    }

    /**
     * 
     */
    public void setTableDataDefaultExportTypes(java.util.List tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
        this.tableDataDefaultExportTypesSet = true;
    }
    /**
     * The name of the sort column for the {@link #tableDataDefaultExportTypes} collection.
     */
    private String tableDataDefaultExportTypesSortColumn;

    /**
     * Gets the name of the sort column for the {@link #tableDataDefaultExportTypes} collection.
     * 
     * @return the name of the sort column.
     */
    public String getTableDataDefaultExportTypesSortColumn()
    {
        return this.tableDataDefaultExportTypesSortColumn;
    }

    /**
     * Sets the name of the {@link #tableDataDefaultExportTypes} sort column.
     * 
     * @param tableDataDefaultExportTypesSortColumn the name of the column by which {@link #tableDataDefaultExportTypes}
     *        are sorted by.
     */
    public void setTableDataDefaultExportTypesSortColumn(final String tableDataDefaultExportTypesSortColumn)
    {
        this.tableDataDefaultExportTypesSortColumn = tableDataDefaultExportTypesSortColumn;
    }
    
    /**
     * The flag indicating whether or not {@link #tableDataDefaultExportTypes} should be sorted
     * ascending.
     */
    private boolean tableDataDefaultExportTypesSortAscending = false;

    /**
     * Indicates whether or not {@link #tableDataDefaultExportTypes} should be sorted ascending
     * or not.
     * 
     * @return true/false
     */
    public boolean isTableDataDefaultExportTypesSortAscending()
    {
        return this.tableDataDefaultExportTypesSortAscending;
    }

    /**
     * Sets whether or not {@link #tableDataDefaultExportTypes} should be sorted ascending.
     * 
     * @param tableDataDefaultExportTypesSortAscending true/false
     */
    public void setTableDataDefaultExportTypesSortAscending(final boolean tableDataDefaultExportTypesSortAscending)
    {
        this.tableDataDefaultExportTypesSortAscending = tableDataDefaultExportTypesSortAscending;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataDefaultExportTypesValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataDefaultExportTypesLabelList;
    public java.lang.Object[] getTableDataDefaultExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataDefaultExportTypesValueList;
        java.lang.Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(java.lang.Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(java.lang.Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataDefaultExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;
        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataDefaultExportTypesValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataDefaultExportTypesLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    private java.util.Collection tableDataDefaultExportTypesBackingValue;

    public void setTableDataDefaultExportTypesBackingValue(java.util.Collection tableDataDefaultExportTypesBackingValue)
    {
        this.tableDataDefaultExportTypesBackingValue = tableDataDefaultExportTypesBackingValue;
    }
    
    public java.util.Collection getTableDataDefaultExportTypesBackingValue()
    {
        return this.tableDataDefaultExportTypesBackingValue;
    }


    private java.lang.String two;

    /**
     * 
     */
    public java.lang.String getTwo()
    {
        return this.two;
    }
    
    /**
     * Keeps track of whether or not the value of two has
     * be populated at least once.
     */
    private boolean twoSet = false;
    
    /**
     * Indicates whether or not the value for two has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTwoSet()
    {
        return this.twoSet;
    }

    /**
     * 
     */
    public void setTwo(java.lang.String two)
    {
        this.two = two;
        this.twoSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] twoValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] twoLabelList;
    public java.lang.Object[] getTwoBackingList()
    {
        java.lang.Object[] values = this.twoValueList;
        java.lang.Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(java.lang.Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public java.lang.Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(java.lang.Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    public void setTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.twoValueList = null;
        this.twoLabelList = null;
        if (items != null)
        {
            this.twoValueList = new java.lang.Object[items.size()];
            this.twoLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.twoValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.twoLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private int formParam1;

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }
    
    /**
     * Keeps track of whether or not the value of formParam1 has
     * be populated at least once.
     */
    private boolean formParam1Set = false;
    
    /**
     * Indicates whether or not the value for formParam1 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isFormParam1Set()
    {
        return this.formParam1Set;
    }

    /**
     * 
     */
    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
        this.formParam1Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] formParam1ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] formParam1LabelList;
    public java.lang.Object[] getFormParam1BackingList()
    {
        java.lang.Object[] values = this.formParam1ValueList;
        java.lang.Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(java.lang.Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public java.lang.Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(java.lang.Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    public void setFormParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFormParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.formParam1ValueList = null;
        this.formParam1LabelList = null;
        if (items != null)
        {
            this.formParam1ValueList = new java.lang.Object[items.size()];
            this.formParam1LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.formParam1ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam1LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.List tableDataNotSortable;

    /**
     * 
     */
    public java.util.List getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }
    
    /**
     * Keeps track of whether or not the value of tableDataNotSortable has
     * be populated at least once.
     */
    private boolean tableDataNotSortableSet = false;
    
    /**
     * Indicates whether or not the value for tableDataNotSortable has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTableDataNotSortableSet()
    {
        return this.tableDataNotSortableSet;
    }

    /**
     * 
     */
    public void setTableDataNotSortable(java.util.List tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
        this.tableDataNotSortableSet = true;
    }
    /**
     * The name of the sort column for the {@link #tableDataNotSortable} collection.
     */
    private String tableDataNotSortableSortColumn;

    /**
     * Gets the name of the sort column for the {@link #tableDataNotSortable} collection.
     * 
     * @return the name of the sort column.
     */
    public String getTableDataNotSortableSortColumn()
    {
        return this.tableDataNotSortableSortColumn;
    }

    /**
     * Sets the name of the {@link #tableDataNotSortable} sort column.
     * 
     * @param tableDataNotSortableSortColumn the name of the column by which {@link #tableDataNotSortable}
     *        are sorted by.
     */
    public void setTableDataNotSortableSortColumn(final String tableDataNotSortableSortColumn)
    {
        this.tableDataNotSortableSortColumn = tableDataNotSortableSortColumn;
    }
    
    /**
     * The flag indicating whether or not {@link #tableDataNotSortable} should be sorted
     * ascending.
     */
    private boolean tableDataNotSortableSortAscending = false;

    /**
     * Indicates whether or not {@link #tableDataNotSortable} should be sorted ascending
     * or not.
     * 
     * @return true/false
     */
    public boolean isTableDataNotSortableSortAscending()
    {
        return this.tableDataNotSortableSortAscending;
    }

    /**
     * Sets whether or not {@link #tableDataNotSortable} should be sorted ascending.
     * 
     * @param tableDataNotSortableSortAscending true/false
     */
    public void setTableDataNotSortableSortAscending(final boolean tableDataNotSortableSortAscending)
    {
        this.tableDataNotSortableSortAscending = tableDataNotSortableSortAscending;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataNotSortableValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataNotSortableLabelList;
    public java.lang.Object[] getTableDataNotSortableBackingList()
    {
        java.lang.Object[] values = this.tableDataNotSortableValueList;
        java.lang.Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(java.lang.Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public java.lang.Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(java.lang.Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setTableDataNotSortableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;
        if (items != null)
        {
            this.tableDataNotSortableValueList = new java.lang.Object[items.size()];
            this.tableDataNotSortableLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataNotSortableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNotSortableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    private java.util.Collection tableDataNotSortableBackingValue;

    public void setTableDataNotSortableBackingValue(java.util.Collection tableDataNotSortableBackingValue)
    {
        this.tableDataNotSortableBackingValue = tableDataNotSortableBackingValue;
    }
    
    public java.util.Collection getTableDataNotSortableBackingValue()
    {
        return this.tableDataNotSortableBackingValue;
    }


    private java.lang.String fourth;

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }
    
    /**
     * Keeps track of whether or not the value of fourth has
     * be populated at least once.
     */
    private boolean fourthSet = false;
    
    /**
     * Indicates whether or not the value for fourth has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isFourthSet()
    {
        return this.fourthSet;
    }

    /**
     * 
     */
    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
        this.fourthSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] fourthValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] fourthLabelList;
    public java.lang.Object[] getFourthBackingList()
    {
        java.lang.Object[] values = this.fourthValueList;
        java.lang.Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(java.lang.Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public java.lang.Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(java.lang.Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.fourthValueList = null;
        this.fourthLabelList = null;
        if (items != null)
        {
            this.fourthValueList = new java.lang.Object[items.size()];
            this.fourthLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.fourthValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fourthLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String unknownParameter;

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }
    
    /**
     * Keeps track of whether or not the value of unknownParameter has
     * be populated at least once.
     */
    private boolean unknownParameterSet = false;
    
    /**
     * Indicates whether or not the value for unknownParameter has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isUnknownParameterSet()
    {
        return this.unknownParameterSet;
    }

    /**
     * 
     */
    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
        this.unknownParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] unknownParameterValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] unknownParameterLabelList;
    public java.lang.Object[] getUnknownParameterBackingList()
    {
        java.lang.Object[] values = this.unknownParameterValueList;
        java.lang.Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(java.lang.Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public java.lang.Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(java.lang.Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    public void setUnknownParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setUnknownParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        if (items != null)
        {
            this.unknownParameterValueList = new java.lang.Object[items.size()];
            this.unknownParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.unknownParameterValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.unknownParameterLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }
    
    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;
    
    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        java.lang.Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        java.lang.Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataImageLinkActionFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new java.lang.Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = -7485557834506805134L;
}