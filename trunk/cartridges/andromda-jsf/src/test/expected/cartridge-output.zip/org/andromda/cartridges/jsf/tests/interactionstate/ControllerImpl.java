// license-header java merge-point
package org.andromda.cartridges.jsf.tests.interactionstate;

/**
 * @see org.andromda.cartridges.jsf.tests.interactionstate.Controller
 */
public class ControllerImpl
    extends Controller
{

}