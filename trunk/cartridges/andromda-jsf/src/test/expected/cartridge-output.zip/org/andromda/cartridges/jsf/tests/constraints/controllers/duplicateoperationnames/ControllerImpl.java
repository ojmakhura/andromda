// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName()
     */
    public void duplicateName() throws java.lang.Exception
    {
    }
    
    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName(java.lang.String diffParam)
     */
    public void duplicateName(DuplicateNameForm form) throws java.lang.Exception
    {
    }
    
}