// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.hyperlinked;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.hyperlinked.Controller
 */
public class ControllerImpl
    extends Controller
{

}