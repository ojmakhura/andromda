package org.andromda.presentation.jsf;

import java.util.HashMap;
import java.util.Map;

/**
 * Stores all forward paths available in all use cases keyed by forward name.
 */
public final class UseCaseForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    public static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
        }
        return (String)forwards.get(name);
    }

    /**
     * Stores the keyed forward paths.
     */
    private static final Map<String, String> forwards = new HashMap<String, String>();
}