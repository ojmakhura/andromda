/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
//
/**
 * @author GENERATED CODE! Do not modify by hand!
 *
 * TEMPLATE:     ValueObject.vsl in andromda-java-cartridge.
 * MODEL CLASS:  JavaCartridgeTestModel::org.andromda.cartridges.java::ValueObject
 * METAFACADE:   org.andromda.metafacades.uml.ValueObject
 * STEREOTYPE:   ValueObject
 */
package org.andromda.cartridges.java;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * <p>
 * A test complex type.
 * </p>
 */
@XmlRootElement(name = "ValueObject")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValueObject", // namespace="http://java.cartridges.andromda.org/",
  propOrder = {
    "attributeOnes",
    "attributeTwo",
    "relatedValueObjects",
    "orderedValueObjects"
})
public class ValueObject
    implements Serializable, Comparable<ValueObject>
    {
    /** The serial version UID of this class. Needed for serialization. */
    private static final long serialVersionUID = -9079321366055628495L;

    // Class attributes
    /** TODO: Model Documentation for attribute attributeOnes */
    @XmlElement(name = "attributeOnes")
    protected Collection<String> attributeOnes;
    /** TODO: Model Documentation for attribute attributeTwo */
    @XmlElement(name = "attributeTwo", defaultValue="12")
    protected int attributeTwo = 12;
    protected boolean setAttributeTwo = false;

    // Class associationEnds
    @XmlElement(name="relatedValueObjects")
    protected Collection<RelatedValueObject> relatedValueObjects;
    @XmlElement(name="orderedValueObjects")
    protected List<OrderedValueObject> orderedValueObjects;

    /** Default Constructor with no properties */
    public ValueObject()
    {
        // Documented empty block - avoid compiler warning - no super constructor
    }

    /**
     * Constructor taking only required properties
     * @param attributeTwoIn int
     */
    public ValueObject(final int attributeTwoIn)
    {
        this.attributeTwo = attributeTwoIn;
        this.setAttributeTwo = true;
    }

    /**
     * Constructor with all properties
     * @param attributeOnesIn Collection<String>
     * @param attributeTwoIn int
     * @param relatedValueObjectsIn Collection<RelatedValueObject>
     * @param orderedValueObjectsIn List<OrderedValueObject>
     */
    public ValueObject(final Collection<String> attributeOnesIn, final int attributeTwoIn, final Collection<RelatedValueObject> relatedValueObjectsIn, final List<OrderedValueObject> orderedValueObjectsIn)
    {
        this.attributeOnes = attributeOnesIn;
        this.attributeTwo = attributeTwoIn;
        this.setAttributeTwo = true;
        this.relatedValueObjects = relatedValueObjectsIn;
        this.orderedValueObjects = orderedValueObjectsIn;
    }

    /**
     * Copies constructor from other ValueObject
     *
     * @param otherBean Cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public ValueObject(final ValueObject otherBean)
    {
        this.attributeOnes = otherBean.getAttributeOnes();
        this.attributeTwo = otherBean.getAttributeTwo();
        this.setAttributeTwo = true;
        this.relatedValueObjects = otherBean.getRelatedValueObjects();
        this.orderedValueObjects = otherBean.getOrderedValueObjects();
    }

    /**
     * Copies all properties from the argument value object into this value object.
     * @param otherBean Cannot be <code>null</code>
     * @return this
     */
    public void copy(final ValueObject otherBean)
    {
        if (null != otherBean)
        {
            this.setAttributeOnes(otherBean.getAttributeOnes());
            this.setAttributeTwo(otherBean.getAttributeTwo());
            this.setAttributeTwo = true;
            this.setRelatedValueObjects(otherBean.getRelatedValueObjects());
            this.setOrderedValueObjects(otherBean.getOrderedValueObjects());
        }
    }

    /**
     * TODO: Model Documentation for attribute attributeOnes
     * Get the attributeOnes Attribute
     * @return attributeOnes Collection<String>
     */
    public Collection<String> getAttributeOnes()
    {
        if (this.attributeOnes == null)
        {
            this.attributeOnes = new ArrayList<String>();
        }
        return this.attributeOnes;
    }

    /**
     * 
     * @param value Collection<String>
     */
    public void setAttributeOnes(final Collection<String> value)
    {
        this.attributeOnes = value;
    }

    /**
     * TODO: Model Documentation for attribute attributeTwo
     * Get the attributeTwo Attribute
     * @return attributeTwo int
     */
    public int getAttributeTwo()
    {
        return this.attributeTwo;
    }

    /**
     * 
     * @param value int
     */
    public void setAttributeTwo(final int value)
    {
        this.attributeTwo = value;
        this.setAttributeTwo = true;
    }

    /**
     * Return true if the primitive attribute attributeTwo is set, through the setter or constructor
     * @return true if the attribute value has been set
     */
    public boolean isSetAttributeTwo()
    {
        return this.setAttributeTwo;
    }

    /**
     * TODO: Model Documentation for association relatedValueObjects
     * Get the relatedValueObjects Association
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the object.
     * @return this.relatedValueObjects Collection<RelatedValueObject>
     */
    public Collection<RelatedValueObject> getRelatedValueObjects()
    {
        if (this.relatedValueObjects == null)
        {
            this.relatedValueObjects = new ArrayList<RelatedValueObject>();
        }
        return this.relatedValueObjects;
    }

    /**
     * Sets the relatedValueObjects
     * @param value Collection<RelatedValueObject>
     */
    public void setRelatedValueObjects(Collection<RelatedValueObject> value)
    {
        this.relatedValueObjects = value;
    }

    /**
     * TODO: Model Documentation for association orderedValueObjects
     * Get the orderedValueObjects Association
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the object.
     * @return this.orderedValueObjects List<OrderedValueObject>
     */
    public List<OrderedValueObject> getOrderedValueObjects()
    {
        if (this.orderedValueObjects == null)
        {
            this.orderedValueObjects = new ArrayList<OrderedValueObject>();
        }
        return this.orderedValueObjects;
    }

    /**
     * Sets the orderedValueObjects
     * @param value List<OrderedValueObject>
     */
    public void setOrderedValueObjects(List<OrderedValueObject> value)
    {
        this.orderedValueObjects = value;
    }

    /**
     * @param object to compare this object against
     * @return boolean if equal
     * @see Object#equals(Object)
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object object)
    {
        if (object==null || !(object instanceof ValueObject))
        {
             return false;
        }
        ValueObject rhs = (ValueObject) object;
        return new EqualsBuilder()
            .append(this.getAttributeOnes(), rhs.getAttributeOnes())
            .append(this.getAttributeTwo(), rhs.getAttributeTwo())
            .append(this.getRelatedValueObjects(), rhs.getRelatedValueObjects())
            .append(this.getOrderedValueObjects(), rhs.getOrderedValueObjects())
            .isEquals();
    }

    /**
     * @param object to compare this object against
     * @return int if equal
     * @see Comparable#compareTo(Object)
     */
    @SuppressWarnings("unchecked")
    public int compareTo(final ValueObject object)
    {
        if (object==null)
        {
            return -1;
        }
        return new CompareToBuilder()
            .append(this.getAttributeOnes(), object.getAttributeOnes())
            .append(this.getAttributeTwo(), object.getAttributeTwo())
            .append(this.getRelatedValueObjects(), object.getRelatedValueObjects())
            .append(this.getOrderedValueObjects(), object.getOrderedValueObjects())
            .toComparison();
    }

    /**
     * @return int hashCode value
     * @see Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1249046965, -82296885)
            .append(this.getAttributeOnes())
            .append(this.getAttributeTwo())
            //Commented out to avoid commons-lang-2.4 recursion StackOverflowError: https://issues.apache.org/jira/browse/LANG-456
            //.append(this.getRelatedValueObjects())
            //Commented out to avoid commons-lang-2.4 recursion StackOverflowError: https://issues.apache.org/jira/browse/LANG-456
            //.append(this.getOrderedValueObjects())
            .toHashCode();
    }

    /**
     * @return String representation of object
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        return new ToStringBuilder(this)
            .append("attributeOnes", this.getAttributeOnes())
            .append("attributeTwo", this.getAttributeTwo())
            .append("relatedValueObjects", this.getRelatedValueObjects())
            .append("orderedValueObjects", this.getOrderedValueObjects())
            .toString();
    }

    /**
     * Compares the properties of this instance to the properties of the argument. This method will return
     * {@code false} as soon as it detects that the argument is {@code null} or not of the same type as
     * (or a sub-type of) this instance's type.
     *
     * <p/>For array, collection or map properties the comparison will be done one level deep, in other words:
     * the elements will be compared using the {@code equals()} operation.
     *
     * <p/>Note that two properties will be considered equal when both values are {@code null}.
     *
     * @param thatObject the object containing the properties to compare against this instance
     * @return this method will return {@code true} in case the argument has the same type as this class, or is a
     *      sub-type of this class and all properties as found on this class have equal values when queried on that
     *      argument instance; in all other cases this method will return {@code false}
     */
    @SuppressWarnings("unchecked")
    public boolean equalProperties(final Object thatObject)
    {
        if (thatObject == null || !this.getClass().isAssignableFrom(thatObject.getClass()))
        {
            return false;
        }

        final ValueObject that = (ValueObject)thatObject;

        return
            equal(this.getAttributeOnes(), that.getAttributeOnes())
            && equal(this.getAttributeTwo(), that.getAttributeTwo())
            && equal(this.getRelatedValueObjects(), that.getRelatedValueObjects())
            && equal(this.getOrderedValueObjects(), that.getOrderedValueObjects())
        ;
    }

    /**
     * This is a convenient helper method which is able to detect whether or not two values are equal. Two values
     * are equal when they are both {@code null}, are arrays of the same length with equal elements or are
     * equal objects (this includes {@link Collection} and {@link java.util.Map} instances).
     *
     * <p/>Note that for array, collection or map instances the comparison runs one level deep.
     *
     * @param first the first object to compare, may be {@code null}
     * @param second the second object to compare, may be {@code null}
     * @return this method will return {@code true} in case both objects are equal as explained above;
     *      in all other cases this method will return {@code false}
     */
    protected static boolean equal(final Object first, final Object second)
    {
        final boolean equal;

        if (first == null)
        {
            equal = second == null;
        }
        else if (first.getClass().isArray() && (second != null) && second.getClass().isArray())
        {
            equal = Arrays.equals((Object[])first, (Object[])second);
        }
        else // note that the following also covers Collection and java.util.Map
        {
            equal = first.equals(second);
        }

        return equal;
    }

    // ValueObject value-object java merge-point
}