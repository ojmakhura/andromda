/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
//
/**
 * @author GENERATED CODE! Do not modify by hand!
 * 
 * TEMPLATE:     ValueObject.vsl in andromda-java-cartridge.
 * MODEL CLASS:  Data::org.andromda.cartridges.java::TemplateTestVO
 * METAFACADE:   org.andromda.metafacades.uml.ValueObject
 * STEREOTYPE:   ValueObject
 */
package org.andromda.cartridges.java;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
/**
 * 
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TemplateTestVO", namespace="http://java.cartridges.andromda.org/", 
  propOrder = {
    "someAttribute",
    "references"
})
public class TemplateTestVO
    implements Serializable, Comparable<Object>
    {
    /** The serial version UID of this class. Needed for serialization. */
    private static final long serialVersionUID = 6914230736496702206L;

    // Class attributes
    @XmlElement(name = "someAttribute")
    protected int someAttribute;
    // Class associationEnds
    @XmlElement(name="references", namespace="http:///")
    protected Collection<TemplateTestVO<String, Integer>> references;

    /** Default Constructor with no properties */
    public TemplateTestVO()
    {
        // Documented empty block - avoid compiler warning - no super constructor
    }

    /** 
     * Constructor taking only required properties 
     * @param someAttributeIn int
     */
    public TemplateTestVO(int someAttributeIn)
    {
        this.someAttribute = someAttributeIn;
    }

    /** 
     * Constructor with all properties 
     * @param someAttributeIn int
     * @param referencesIn Collection<TemplateTestVO<String, Integer>>
     */
    public TemplateTestVO(int someAttributeIn, Collection<TemplateTestVO<String, Integer>> referencesIn)
    {
        this.someAttribute = someAttributeIn;
        this.references = referencesIn;
    }

    /**
     * Copies constructor from other TemplateTestVO
     *
     * @param otherBean Cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public TemplateTestVO(TemplateTestVO otherBean)
    {
        super();
        this.someAttribute = otherBean.getSomeAttribute();
        this.references = otherBean.getReferences();
    }

    /**
     * Copies all properties from the argument value object into this value object.
     * @param otherBean Cannot be <code>null</code>
     * @return this
     */
    public void copy(TemplateTestVO otherBean)
    {
        if (otherBean != null)
        {
            this.setSomeAttribute(otherBean.getSomeAttribute());
            this.setReferences(otherBean.getReferences());
        }
    }


    /**
     * 
     * Get the someAttribute Attribute
     * @return someAttribute int
     */
    public int getSomeAttribute()
    {
        return this.someAttribute;
    }

    /**
     * 
     * @param someAttributeIn int
     */
    public void setSomeAttribute(int someAttributeIn)
    {
        this.someAttribute = someAttributeIn;
    }


    /**
     * Get the references Association
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the object.
     * @return this.references Collection<TemplateTestVO<String, Integer>>
     * 
     */
    public Collection<TemplateTestVO<String, Integer>> getReferences()
    {
        if (this.references == null) 
        {
            this.references = new ArrayList<TemplateTestVO<String, Integer>>();
        }
        return this.references;
    }

    /**
     * Sets the references
     * @param referencesIn Collection<TemplateTestVO<String, Integer>>
     */
    public void setReferences(Collection<TemplateTestVO<String, Integer>> referencesIn)
    {
        this.references = referencesIn;
    }

    /**
     * @param object to compare this object against
     * @return boolean if equal
     * @see Object#equals(Object)
     */
    @Override
    public boolean equals(Object object) 
    {
        if (object==null || !(object instanceof TemplateTestVO<String, Integer>))
        {
             return false;
        }
        TemplateTestVO<String, Integer> rhs = (TemplateTestVO<String, Integer>) object;
        return new EqualsBuilder().appendSuper(super.equals(object))
            .append(this.getSomeAttribute(), rhs.getSomeAttribute())
            .append(this.getReferences(), rhs.getReferences())
            .isEquals();
    }

    /**
     * @param object to compare this object against
     * @return int if equal
     * @see Comparable#compareTo(Object)
     */
    public int compareTo(Object object)
    {
        if (object==null || !(object instanceof TemplateTestVO<String, Integer>))
        {
            return -1;
        }
        TemplateTestVO<String, Integer> myClass = (TemplateTestVO<String, Integer>) object;
        return new CompareToBuilder()
            .append(this.getSomeAttribute(), myClass.getSomeAttribute())
            .append(this.getReferences(), myClass.getReferences())
            .toComparison();
    }

    /**
     * @return int hashCode value
     * @see Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1249046965, -82296885).appendSuper(super.hashCode())
            .append(this.getSomeAttribute())
            //Commented out to avoid commons-lang-2.4 recursion StackOverflowError: https://issues.apache.org/jira/browse/LANG-456
            //.append(this.getReferences())
            .toHashCode();
    }

    /**
     * @return String representation of object
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        return new ToStringBuilder(this)
            .append("someAttribute", this.getSomeAttribute())
            .append("references", this.getReferences())
            .toString();
    }

    /**
     * Compares the properties of this instance to the properties of the argument. This method will return
     * {@code false} as soon as it detects that the argument is {@code null} or not of the same type as
     * (or a sub-type of) this instance's type.
     *
     * <p/>For array, collection or map properties the comparison will be done one level deep, in other words:
     * the elements will be compared using the {@code equals()} operation.
     *
     * <p/>Note that two properties will be considered equal when both values are {@code null}.
     *
     * @param thatObject the object containing the properties to compare against this instance
     * @return this method will return {@code true} in case the argument has the same type as this class, or is a
     *      sub-type of this class and all properties as found on this class have equal values when queried on that
     *      argument instance; in all other cases this method will return {@code false}
     */
    public boolean equalProperties(Object thatObject)
    {
        if (thatObject == null || !this.getClass().isAssignableFrom(thatObject.getClass()))
        {
            return false;
        }

        final TemplateTestVO<String, Integer> that = (TemplateTestVO<String, Integer>)thatObject;

        return
            equal(this.getSomeAttribute(), that.getSomeAttribute())
            && equal(this.getReferences(), that.getReferences())
        ;
    }

    /**
     * This is a convenient helper method which is able to detect whether or not two values are equal. Two values
     * are equal when they are both {@code null}, are arrays of the same length with equal elements or are
     * equal objects (this includes {@link java.util.Collection} and {@link java.util.Map} instances).
     *
     * <p/>Note that for array, collection or map instances the comparison runs one level deep.
     *
     * @param first the first object to compare, may be {@code null}
     * @param second the second object to compare, may be {@code null}
     * @return this method will return {@code true} in case both objects are equal as explained above;
     *      in all other cases this method will return {@code false}
     */
    protected static boolean equal(Object first, Object second)
    {
        final boolean equal;

        if (first == null)
        {
            equal = second == null;
        }
        else if (first.getClass().isArray() && (second != null) && second.getClass().isArray())
        {
            equal = Arrays.equals((Object[])first, (Object[])second);
        }
        else // note that the following also covers Collection and java.util.Map
        {
            equal = first.equals(second);
        }

        return equal;
    }

    // TemplateTestVO<String, Integer> value-object java merge-point
}
