/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
//
/**
 * @author Generated on 10/27/2011 12:41:38-0400 Do not modify by hand!
 *
 * TEMPLATE:     ValueObject.vsl in andromda-java-cartridge.
 * MODEL CLASS:  JavaCartridgeTestModel::org.andromda.cartridges.java::ValueObjectChildChild
 * STEREOTYPE:   ValueObject
 */
package org.andromda.cartridges.java;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import org.apache.commons.lang.builder.CompareToBuilder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * <p>
 * Inherits from ValueObjectChild
 * </p>
 */
@XmlRootElement(name = "ValueObjectChildChild")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValueObjectChildChild", // namespace="http://java.cartridges.andromda.org/",
  propOrder = {
    "attributeFour",
    "testAssociation"
})
public class ValueObjectChildChild
    extends ValueObjectChild
{
    /** The serial version UID of this class. Needed for serialization. */
    private static final long serialVersionUID = -6403162344881781815L;

    // Class attributes
    /** TODO: Model Documentation for attribute attributeFour */
    @XmlElement(name = "attributeFour")
    protected String attributeFour;

    // Class associationEnds
    /** TODO: Model Documentation for attribute testAssociation */
    @XmlElement(name="testAssociation")
    protected ValueObject testAssociation;

    /** Default Constructor with no properties */
    public ValueObjectChildChild()
    {
        super();
    }

    /**
     * Constructor taking only required properties
     * @param attributeFourIn String
     * @param attributeTwoIn String
     * @param attributeThreeIn String
     * @param attributeOneIn String
     */
    public ValueObjectChildChild(final String attributeFourIn, final String attributeTwoIn, final String attributeThreeIn, final String attributeOneIn)
    {
        super(attributeTwoIn, attributeThreeIn, attributeOneIn);
        this.attributeFour = attributeFourIn;
    }

    /**
     * Constructor with all properties
     * @param attributeFourIn String
     * @param attributeTwoIn String
     * @param attributeThreeIn String
     * @param attributeOneIn String
     * @param testAssociationIn ValueObject
     */
    public ValueObjectChildChild(final String attributeFourIn, final String attributeTwoIn, final String attributeThreeIn, final String attributeOneIn, final ValueObject testAssociationIn)
    {
        super(attributeTwoIn, attributeThreeIn, attributeOneIn);
        this.attributeFour = attributeFourIn;
        this.testAssociation = testAssociationIn;
    }

    /**
     * Copies constructor from other ValueObjectChildChild
     *
     * @param otherBean Cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public ValueObjectChildChild(final ValueObjectChildChild otherBean)
    {
        super(otherBean);
        this.attributeFour = otherBean.getAttributeFour();
        this.testAssociation = otherBean.getTestAssociation();
    }

    /**
     * Copies all properties from the argument value object into this value object.
     * @param otherBean Cannot be <code>null</code>
     */
    public void copy(final ValueObjectChildChild otherBean)
    {
        if (null != otherBean)
        {
            super.copy(otherBean);
            this.setAttributeFour(otherBean.getAttributeFour());
            this.setTestAssociation(otherBean.getTestAssociation());
        }
    }

    /**
     * TODO: Model Documentation for attribute attributeFour
     * Get the attributeFour Attribute
     * @return attributeFour String
     */
    public String getAttributeFour()
    {
        return this.attributeFour;
    }

    /**
     * 
     * @param value String
     */
    public void setAttributeFour(final String value)
    {
        this.attributeFour = value;
    }

    /**
     * TODO: Model Documentation for association testAssociation
     * Get the testAssociation Association
     * @return this.testAssociation ValueObject
     */
    public ValueObject getTestAssociation()
    {
        return this.testAssociation;
    }

    /**
     * Sets the testAssociation
     * @param value ValueObject
     */
    public void setTestAssociation(ValueObject value)
    {
        this.testAssociation = value;
    }

    /**
     * @param object to compare this object against
     * @return boolean if equal
     * @see Object#equals(Object)
     */
    @Override
    public boolean equals(final Object object)
    {
        if (object==null || object.getClass() != this.getClass())
        {
             return false;
        }
        // Check if the same object instance
        if (object==this)
        {
            return true;
        }
        ValueObjectChildChild rhs = (ValueObjectChildChild) object;
        return new EqualsBuilder()
            .appendSuper(super.equals(object))
            .append(this.getAttributeFour(), rhs.getAttributeFour())
            .append(this.getTestAssociation(), rhs.getTestAssociation())
            .isEquals();
    }

    /**
     * @param object to compare this object against
     * @return int if equal
     * @see Comparable#compareTo(Object)
     */
    public int compareTo(final ValueObjectParent object)
    {
        if (object==null)
        {
            return -1;
        }
        // Check if the same object instance
        if (object==this)
        {
            return 0;
        }
        if (!(object instanceof ValueObjectChildChild))
        {
            return -1;
        }
        ValueObjectChildChild myClass = (ValueObjectChildChild)object;
        return new CompareToBuilder()
            .appendSuper(super.compareTo(object))
            .append(this.getAttributeFour(), myClass.getAttributeFour())
            .append(this.getTestAssociation(), myClass.getTestAssociation())
            .toComparison();
    }

    /**
     * @return int hashCode value
     * @see Object#hashCode()
     */
    @Override
    public int hashCode()
    {
        return new HashCodeBuilder(1249046965, -82296885)
            .appendSuper(super.hashCode())
            .append(this.getAttributeFour())
            .append(this.getTestAssociation())
            .toHashCode();
    }

    /**
     * @return String representation of object
     * @see Object#toString()
     */
    @Override
    public String toString()
    {
        return new ToStringBuilder(this)
            .append("attributeFour", this.getAttributeFour())
            .append("attributeTwo", this.getAttributeTwo())
            .append("attributeThree", this.getAttributeThree())
            .append("attributeOne", this.getAttributeOne())
            .append("testAssociation", this.getTestAssociation())
            .toString();
    }

    /**
     * Compares the properties of this instance to the properties of the argument. This method will return
     * {@code false} as soon as it detects that the argument is {@code null} or not of the same type as
     * (or a sub-type of) this instance's type.
     *
     * <p/>For array, collection or map properties the comparison will be done one level deep, in other words:
     * the elements will be compared using the {@code equals()} operation.
     *
     * <p/>Note that two properties will be considered equal when both values are {@code null}.
     *
     * @param thatObject the object containing the properties to compare against this instance
     * @return this method will return {@code true} in case the argument has the same type as this class, or is a
     *      sub-type of this class and all properties as found on this class have equal values when queried on that
     *      argument instance; in all other cases this method will return {@code false}
     */
    @Override
    public boolean equalProperties(final Object thatObject)
    {
        if (thatObject == null || !this.getClass().isAssignableFrom(thatObject.getClass()))
        {
            return false;
        }

        final ValueObjectChildChild that = (ValueObjectChildChild)thatObject;

        return super.equalProperties(that)
            && equal(this.getAttributeFour(), that.getAttributeFour())
            && equal(this.getTestAssociation(), that.getTestAssociation())
        ;
    }

    // ValueObjectChildChild value-object java merge-point
}