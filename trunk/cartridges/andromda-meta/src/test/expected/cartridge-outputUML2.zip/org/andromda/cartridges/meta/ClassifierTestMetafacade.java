// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

import java.util.Collection;
import org.andromda.metafacades.uml.ClassifierFacade;

/**
 * TODO: Model Documentation for org.andromda.cartridges.meta.ClassifierTestMetafacade
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ClassifierTestMetafacade
    extends ClassifierFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isClassifierTestMetafacadeMetaType();

    /**
     * TODO: Model Documentation for
     * org.andromda.cartridges.meta.ClassifierTestMetafacade.testAttribute
     * @return String
     */
    public String getTestAttribute();

    /**
     * TODO: Model Documentation for OperationTestMetafacade
     * @return Collection<OperationTestMetafacade>
     */
    public Collection<OperationTestMetafacade> getTestOperations();

    /**
     * TODO: Model Documentation for
     * org.andromda.cartridges.meta.ClassifierTestMetafacade.isTestMetafacade
     * @return boolean
     */
    public boolean isTestMetafacade();
}