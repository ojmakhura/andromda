//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAssociationEndFacade
 *
 * @see org.andromda.metafacades.uml.EntityAssociationEndFacade
 */
public abstract class EntityAssociationEndFacadeLogic
    extends org.andromda.metafacades.uml.AssociationEndFacadeLogicImpl
    implements org.andromda.metafacades.uml.EntityAssociationEndFacade
{

    protected Object metaObject;

    public EntityAssociationEndFacadeLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.AssociationEnd)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAssociationEndFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName1aPreCondition()
    {
    }

    private void handleGetColumnName1aPostCondition()
    {
    }

    public final java.lang.String getColumnName()
    {
        java.lang.String columnName1a = null;
        handleGetColumnName1aPreCondition();
        columnName1a = handleGetColumnName();
        handleGetColumnName1aPostCondition();
        return columnName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getForeignKeySuffix()
    */
    protected abstract java.lang.String handleGetForeignKeySuffix();

    private void handleGetForeignKeySuffix2aPreCondition()
    {
    }

    private void handleGetForeignKeySuffix2aPostCondition()
    {
    }

    public final java.lang.String getForeignKeySuffix()
    {
        java.lang.String foreignKeySuffix2a = null;
        handleGetForeignKeySuffix2aPreCondition();
        foreignKeySuffix2a = handleGetForeignKeySuffix();
        handleGetForeignKeySuffix2aPostCondition();
        return foreignKeySuffix2a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#isForeignIdentifier()
    */
    protected abstract boolean handleIsForeignIdentifier();

    private void handleIsForeignIdentifier3aPreCondition()
    {
    }

    private void handleIsForeignIdentifier3aPostCondition()
    {
    }

    public final boolean isForeignIdentifier()
    {
        boolean foreignIdentifier3a = false;
        handleIsForeignIdentifier3aPreCondition();
        foreignIdentifier3a = handleIsForeignIdentifier();
        handleIsForeignIdentifier3aPostCondition();
        return foreignIdentifier3a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"foreignIdentifier"))).booleanValue()?(Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"one2One"))).booleanValue()&&Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"child"))).booleanValue()&&org.andromda.translation.validation.OCLCollections.one(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"type.associationEnds"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(org.andromda.translation.validation.OCLIntrospector.invoke(object,"foreignIdentifier"))).booleanValue();}})):true));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Only ONE association end on an entity can be flagged as having a foreign identifier at any given time. It also MUST be the child end (the other side is flagged as having composite aggregation) of a one-to-one association."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
