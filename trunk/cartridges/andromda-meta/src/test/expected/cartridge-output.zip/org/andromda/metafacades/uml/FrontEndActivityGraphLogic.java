//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndActivityGraph
 *
 * @see org.andromda.metafacades.uml.FrontEndActivityGraph
 */
public abstract class FrontEndActivityGraphLogic
    extends org.andromda.metafacades.uml.ActivityGraphFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndActivityGraph
{

    protected Object metaObject;

    public FrontEndActivityGraphLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.activitygraphs.ActivityGraph)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndActivityGraph";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndActivityGraph#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase1aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase1aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase1a;
    private boolean __containedInFrontEndUseCase1aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase1a = this.__containedInFrontEndUseCase1a;
        if (!this.__containedInFrontEndUseCase1aSet)
        {
            handleIsContainedInFrontEndUseCase1aPreCondition();
            containedInFrontEndUseCase1a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase1aPostCondition();
            this.__containedInFrontEndUseCase1a = containedInFrontEndUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase1aSet = true;
            }
        }
        return containedInFrontEndUseCase1a;
    }

    // ------------- associations ------------------

    private void handleGetController2rPreCondition()
    {
    }

    private void handleGetController2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndController __getController2r;
    private boolean __getController2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndController getController()
    {
        org.andromda.metafacades.uml.FrontEndController getController2r = this.__getController2r;
        if (!this.__getController2rSet)
        {
            handleGetController2rPreCondition();
            Object result = this.shieldedElement(handleGetController());
            try
            {
                getController2r = (org.andromda.metafacades.uml.FrontEndController)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetController2rPostCondition();
            this.__getController2r = getController2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController2rSet = true;
            }
        }
        return getController2r;
    }

    protected abstract java.lang.Object handleGetController();

    private void handleGetInitialAction5rPreCondition()
    {
    }

    private void handleGetInitialAction5rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndAction __getInitialAction5r;
    private boolean __getInitialAction5rSet = false;

    public final org.andromda.metafacades.uml.FrontEndAction getInitialAction()
    {
        org.andromda.metafacades.uml.FrontEndAction getInitialAction5r = this.__getInitialAction5r;
        if (!this.__getInitialAction5rSet)
        {
            handleGetInitialAction5rPreCondition();
            Object result = this.shieldedElement(handleGetInitialAction());
            try
            {
                getInitialAction5r = (org.andromda.metafacades.uml.FrontEndAction)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialAction5rPostCondition();
            this.__getInitialAction5r = getInitialAction5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialAction5rSet = true;
            }
        }
        return getInitialAction5r;
    }

    protected abstract java.lang.Object handleGetInitialAction();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"controller"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "An activity graph must have a controller class context to which (optionally) operations can be deferred. Make sure this graph's use-case has the FrontEndUseCase stereotype."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}