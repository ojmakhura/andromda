//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AttributeFacade
 *
 * @see org.andromda.metafacades.uml.AttributeFacade
 */
public abstract class AttributeFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.AttributeFacade
{

    protected org.omg.uml.foundation.core.Attribute metaObject;

    public AttributeFacadeLogic (org.omg.uml.foundation.core.Attribute metaObject, String context)
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AttributeFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName1aPreCondition()
    {
    }

    private void handleGetGetterName1aPostCondition()
    {
    }

    public final java.lang.String getGetterName()
    {
        java.lang.String getterName1a = null;
        handleGetGetterName1aPreCondition();
        getterName1a = handleGetGetterName();
        handleGetGetterName1aPostCondition();
        return getterName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName2aPreCondition()
    {
    }

    private void handleGetSetterName2aPostCondition()
    {
    }

    public final java.lang.String getSetterName()
    {
        java.lang.String setterName2a = null;
        handleGetSetterName2aPreCondition();
        setterName2a = handleGetSetterName();
        handleGetSetterName2aPostCondition();
        return setterName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isReadOnly()
    */
    protected abstract boolean handleIsReadOnly();

    private void handleIsReadOnly3aPreCondition()
    {
    }

    private void handleIsReadOnly3aPostCondition()
    {
    }

    public final boolean isReadOnly()
    {
        boolean readOnly3a = false;
        handleIsReadOnly3aPreCondition();
        readOnly3a = handleIsReadOnly();
        handleIsReadOnly3aPostCondition();
        return readOnly3a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getDefaultValue()
    */
    protected abstract java.lang.String handleGetDefaultValue();

    private void handleGetDefaultValue4aPreCondition()
    {
    }

    private void handleGetDefaultValue4aPostCondition()
    {
    }

    public final java.lang.String getDefaultValue()
    {
        java.lang.String defaultValue4a = null;
        handleGetDefaultValue4aPreCondition();
        defaultValue4a = handleGetDefaultValue();
        handleGetDefaultValue4aPostCondition();
        return defaultValue4a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isStatic()
    */
    protected abstract boolean handleIsStatic();

    private void handleIsStatic5aPreCondition()
    {
    }

    private void handleIsStatic5aPostCondition()
    {
    }

    public final boolean isStatic()
    {
        boolean static5a = false;
        handleIsStatic5aPreCondition();
        static5a = handleIsStatic();
        handleIsStatic5aPostCondition();
        return static5a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired6aPreCondition()
    {
    }

    private void handleIsRequired6aPostCondition()
    {
    }

    public final boolean isRequired()
    {
        boolean required6a = false;
        handleIsRequired6aPreCondition();
        required6a = handleIsRequired();
        handleIsRequired6aPostCondition();
        return required6a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isMany()
    */
    protected abstract boolean handleIsMany();

    private void handleIsMany7aPreCondition()
    {
    }

    private void handleIsMany7aPostCondition()
    {
    }

    public final boolean isMany()
    {
        boolean many7a = false;
        handleIsMany7aPreCondition();
        many7a = handleIsMany();
        handleIsMany7aPostCondition();
        return many7a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isChangeable()
    */
    protected abstract boolean handleIsChangeable();

    private void handleIsChangeable8aPreCondition()
    {
    }

    private void handleIsChangeable8aPostCondition()
    {
    }

    public final boolean isChangeable()
    {
        boolean changeable8a = false;
        handleIsChangeable8aPreCondition();
        changeable8a = handleIsChangeable();
        handleIsChangeable8aPostCondition();
        return changeable8a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isAddOnly()
    */
    protected abstract boolean handleIsAddOnly();

    private void handleIsAddOnly9aPreCondition()
    {
    }

    private void handleIsAddOnly9aPostCondition()
    {
    }

    public final boolean isAddOnly()
    {
        boolean addOnly9a = false;
        handleIsAddOnly9aPreCondition();
        addOnly9a = handleIsAddOnly();
        handleIsAddOnly9aPostCondition();
        return addOnly9a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#isEnumerationLiteral()
    */
    protected abstract boolean handleIsEnumerationLiteral();

    private void handleIsEnumerationLiteral10aPreCondition()
    {
    }

    private void handleIsEnumerationLiteral10aPostCondition()
    {
    }

    public final boolean isEnumerationLiteral()
    {
        boolean enumerationLiteral10a = false;
        handleIsEnumerationLiteral10aPreCondition();
        enumerationLiteral10a = handleIsEnumerationLiteral();
        handleIsEnumerationLiteral10aPostCondition();
        return enumerationLiteral10a;
    }

   /**
    * @see org.andromda.metafacades.uml.AttributeFacade#getEnumerationValue()
    */
    protected abstract java.lang.String handleGetEnumerationValue();

    private void handleGetEnumerationValue11aPreCondition()
    {
    }

    private void handleGetEnumerationValue11aPostCondition()
    {
    }

    public final java.lang.String getEnumerationValue()
    {
        java.lang.String enumerationValue11a = null;
        handleGetEnumerationValue11aPreCondition();
        enumerationValue11a = handleGetEnumerationValue();
        handleGetEnumerationValue11aPostCondition();
        return enumerationValue11a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(name, follow);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOwner1rPreCondition()
    {
    }

    private void handleGetOwner1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        org.andromda.metafacades.uml.ClassifierFacade getOwner1r = null;
        handleGetOwner1rPreCondition();
        Object result = this.shieldedElement(handleGetOwner());
        try
        {
            getOwner1r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOwner1rPostCondition();
        return getOwner1r;
    }

    protected abstract java.lang.Object handleGetOwner();

    private void handleGetType2rPreCondition()
    {
    }

    private void handleGetType2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType2r = null;
        handleGetType2rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType2r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType2rPostCondition();
        return getType2r;
    }

    protected abstract java.lang.Object handleGetType();

    private void handleGetEnumeration5rPreCondition()
    {
    }

    private void handleGetEnumeration5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EnumerationFacade getEnumeration()
    {
        org.andromda.metafacades.uml.EnumerationFacade getEnumeration5r = null;
        handleGetEnumeration5rPreCondition();
        Object result = this.shieldedElement(handleGetEnumeration());
        try
        {
            getEnumeration5r = (org.andromda.metafacades.uml.EnumerationFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEnumeration5rPostCondition();
        return getEnumeration5r;
    }

    protected abstract java.lang.Object handleGetEnumeration();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"type")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each attribute needs a type, you cannot leave the type unspecified."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each attribute must have a non-empty name."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
