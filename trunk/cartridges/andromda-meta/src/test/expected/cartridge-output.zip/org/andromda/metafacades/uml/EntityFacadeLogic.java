//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityFacade
 *
 * @see org.andromda.metafacades.uml.EntityFacade
 */
public abstract class EntityFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.EntityFacade
{
    protected Object metaObject;
    private org.andromda.metafacades.uml.ClassifierFacade super_;

    public EntityFacadeLogic (Object metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ClassifierFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ClassifierFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.EntityFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see java.util.Collection#getBusinessOperations()
    */
    protected abstract java.util.Collection handleGetBusinessOperations();

    private void handleGetBusinessOperations1aPreCondition()
    {
    }

    private void handleGetBusinessOperations1aPostCondition()
    {
    }

    public final java.util.Collection getBusinessOperations()
    {
        handleGetBusinessOperations1aPreCondition();
        java.util.Collection businessOperations1a = handleGetBusinessOperations();
        handleGetBusinessOperations1aPostCondition();
        return businessOperations1a;
    }

   /**
	* @see java.util.Collection#getFinders()
    */
    protected abstract java.util.Collection handleGetFinders();

    private void handleGetFinders2aPreCondition()
    {
    }

    private void handleGetFinders2aPostCondition()
    {
    }

    public final java.util.Collection getFinders()
    {
        handleGetFinders2aPreCondition();
        java.util.Collection finders2a = handleGetFinders();
        handleGetFinders2aPostCondition();
        return finders2a;
    }

   /**
	* @see java.util.Collection#getIdentifiers()
    */
    protected abstract java.util.Collection handleGetIdentifiers();

    private void handleGetIdentifiers3aPreCondition()
    {
    }

    private void handleGetIdentifiers3aPostCondition()
    {
    }

    public final java.util.Collection getIdentifiers()
    {
        handleGetIdentifiers3aPreCondition();
        java.util.Collection identifiers3a = handleGetIdentifiers();
        handleGetIdentifiers3aPostCondition();
        return identifiers3a;
    }

   /**
	* @see java.lang.String#getTableName()
    */
    protected abstract java.lang.String handleGetTableName();

    private void handleGetTableName4aPreCondition()
    {
    }

    private void handleGetTableName4aPostCondition()
    {
    }

    public final java.lang.String getTableName()
    {
        handleGetTableName4aPreCondition();
        java.lang.String tableName4a = handleGetTableName();
        handleGetTableName4aPostCondition();
        return tableName4a;
    }

   /**
	* @see boolean#isIdentifiersPresent()
    */
    protected abstract boolean handleIsIdentifiersPresent();

    private void handleIsIdentifiersPresent5aPreCondition()
    {
    }

    private void handleIsIdentifiersPresent5aPostCondition()
    {
    }

    public final boolean isIdentifiersPresent()
    {
        handleIsIdentifiersPresent5aPreCondition();
        boolean identifiersPresent5a = handleIsIdentifiersPresent();
        handleIsIdentifiersPresent5aPostCondition();
        return identifiersPresent5a;
    }

   /**
	* @see boolean#isChild()
    */
    protected abstract boolean handleIsChild();

    private void handleIsChild6aPreCondition()
    {
    }

    private void handleIsChild6aPostCondition()
    {
    }

    public final boolean isChild()
    {
        handleIsChild6aPreCondition();
        boolean child6a = handleIsChild();
        handleIsChild6aPostCondition();
        return child6a;
    }

   /**
	* @see java.lang.Short#getMaxSqlNameLength()
    */
    protected abstract java.lang.Short handleGetMaxSqlNameLength();

    private void handleGetMaxSqlNameLength7aPreCondition()
    {
    }

    private void handleGetMaxSqlNameLength7aPostCondition()
    {
    }

    public final java.lang.Short getMaxSqlNameLength()
    {
        handleGetMaxSqlNameLength7aPreCondition();
        java.lang.Short maxSqlNameLength7a = handleGetMaxSqlNameLength();
        handleGetMaxSqlNameLength7aPostCondition();
        return maxSqlNameLength7a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers);

    private void handleGetOperationCallFromAttributes1oPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes1oPostCondition()
    {
    }

    public java.lang.String getOperationCallFromAttributes(boolean withIdentifiers)
    {
        handleGetOperationCallFromAttributes1oPreCondition();
        java.lang.String returnValue = handleGetOperationCallFromAttributes(withIdentifiers);
        handleGetOperationCallFromAttributes1oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetIdentifiers(boolean follow);

    private void handleGetIdentifiers2oPreCondition()
    {
    }

    private void handleGetIdentifiers2oPostCondition()
    {
    }

    public java.util.Collection getIdentifiers(boolean follow)
    {
        handleGetIdentifiers2oPreCondition();
        java.util.Collection returnValue = handleGetIdentifiers(follow);
        handleGetIdentifiers2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers, boolean follow);

    private void handleGetOperationCallFromAttributes3oPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes3oPostCondition()
    {
    }

    public java.lang.String getOperationCallFromAttributes(boolean withIdentifiers, boolean follow)
    {
        handleGetOperationCallFromAttributes3oPreCondition();
        java.lang.String returnValue = handleGetOperationCallFromAttributes(withIdentifiers, follow);
        handleGetOperationCallFromAttributes3oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetRequiredAttributes(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributes4oPreCondition()
    {
    }

    private void handleGetRequiredAttributes4oPostCondition()
    {
    }

    public java.util.Collection getRequiredAttributes(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributes4oPreCondition();
        java.util.Collection returnValue = handleGetRequiredAttributes(follow, withIdentifiers);
        handleGetRequiredAttributes4oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetRequiredProperties(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredProperties5oPreCondition()
    {
    }

    private void handleGetRequiredProperties5oPostCondition()
    {
    }

    public java.util.Collection getRequiredProperties(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredProperties5oPreCondition();
        java.util.Collection returnValue = handleGetRequiredProperties(follow, withIdentifiers);
        handleGetRequiredProperties5oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetAttributes(boolean follow, boolean withIdentifiers);

    private void handleGetAttributes6oPreCondition()
    {
    }

    private void handleGetAttributes6oPostCondition()
    {
    }

    public java.util.Collection getAttributes(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributes6oPreCondition();
        java.util.Collection returnValue = handleGetAttributes(follow, withIdentifiers);
        handleGetAttributes6oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetAttributeTypeList(boolean follow, boolean withIdentifiers);

    private void handleGetAttributeTypeList7oPreCondition()
    {
    }

    private void handleGetAttributeTypeList7oPostCondition()
    {
    }

    public java.lang.String getAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributeTypeList7oPreCondition();
        java.lang.String returnValue = handleGetAttributeTypeList(follow, withIdentifiers);
        handleGetAttributeTypeList7oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetAttributeNameList(boolean follow, boolean withIdentifiers);

    private void handleGetAttributeNameList8oPreCondition()
    {
    }

    private void handleGetAttributeNameList8oPostCondition()
    {
    }

    public java.lang.String getAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        handleGetAttributeNameList8oPreCondition();
        java.lang.String returnValue = handleGetAttributeNameList(follow, withIdentifiers);
        handleGetAttributeNameList8oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredAttributeTypeList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributeTypeList9oPreCondition()
    {
    }

    private void handleGetRequiredAttributeTypeList9oPostCondition()
    {
    }

    public java.lang.String getRequiredAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributeTypeList9oPreCondition();
        java.lang.String returnValue = handleGetRequiredAttributeTypeList(follow, withIdentifiers);
        handleGetRequiredAttributeTypeList9oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetRequiredAttributeNameList(boolean follow, boolean withIdentifiers);

    private void handleGetRequiredAttributeNameList10oPreCondition()
    {
    }

    private void handleGetRequiredAttributeNameList10oPostCondition()
    {
    }

    public java.lang.String getRequiredAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        handleGetRequiredAttributeNameList10oPreCondition();
        java.lang.String returnValue = handleGetRequiredAttributeNameList(follow, withIdentifiers);
        handleGetRequiredAttributeNameList10oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetFinders(boolean follow);

    private void handleGetFinders11oPreCondition()
    {
    }

    private void handleGetFinders11oPostCondition()
    {
    }

    public java.util.Collection getFinders(boolean follow)
    {
        handleGetFinders11oPreCondition();
        java.util.Collection returnValue = handleGetFinders(follow);
        handleGetFinders11oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetParent1rPreCondition()
    {
    }

    private void handleGetParent1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EntityFacade getParent()
    {
        handleGetParent1rPreCondition();
        org.andromda.metafacades.uml.EntityFacade getParent1r = (org.andromda.metafacades.uml.EntityFacade)shieldedElement(handleGetParent());
        handleGetParent1rPostCondition();
        return getParent1r;
    }

    protected abstract java.lang.Object handleGetParent();

    private void handleGetChildren2rPreCondition()
    {
    }

    private void handleGetChildren2rPostCondition()
    {
    }

    public final java.util.Collection getChildren()
    {
        handleGetChildren2rPreCondition();
        java.util.Collection getChildren2r = shieldedElements(handleGetChildren());
        handleGetChildren2rPostCondition();
        return getChildren2r;
    }

    protected abstract java.util.Collection handleGetChildren();

    private void handleGetEntityReferences3rPreCondition()
    {
    }

    private void handleGetEntityReferences3rPostCondition()
    {
    }

    public final java.util.Collection getEntityReferences()
    {
        handleGetEntityReferences3rPreCondition();
        java.util.Collection getEntityReferences3r = shieldedElements(handleGetEntityReferences());
        handleGetEntityReferences3rPostCondition();
        return getEntityReferences3r;
    }

    protected abstract java.util.Collection handleGetEntityReferences();

    // ----------- delegates to org.andromda.metafacades.uml.ClassifierFacade ------------
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getAbstractions()
	{
        return super_.getAbstractions();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public org.andromda.metafacades.uml.ClassifierFacade getArray()
	{
        return super_.getArray();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getAssociationEnds()
	{
        return super_.getAssociationEnds();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getAttributes()
	{
        return super_.getAttributes();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getAttributes(boolean follow)
	{
        return super_.getAttributes(follow);
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getInstanceAttributes()
	{
        return super_.getInstanceAttributes();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.lang.String getJavaNullString()
	{
        return super_.getJavaNullString();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public org.andromda.metafacades.uml.ClassifierFacade getNonArray()
	{
        return super_.getNonArray();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.lang.String getOperationCallFromAttributes()
	{
        return super_.getOperationCallFromAttributes();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getOperations()
	{
        return super_.getOperations();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getProperties()
	{
        return super_.getProperties();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.util.Collection getStaticAttributes()
	{
        return super_.getStaticAttributes();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public java.lang.String getWrapperName()
	{
        return super_.getWrapperName();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isAbstract()
	{
        return super_.isAbstract();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isArrayType()
	{
        return super_.isArrayType();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isCollectionType()
	{
        return super_.isCollectionType();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isDataType()
	{
        return super_.isDataType();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isDateType()
	{
        return super_.isDateType();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isEnumeration()
	{
        return super_.isEnumeration();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isInterface()
	{
        return super_.isInterface();
	}
	
    // from org.andromda.metafacades.uml.ClassifierFacade
	public boolean isPrimitive()
	{
        return super_.isPrimitive();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getAllGeneralizations()
	{
        return super_.getAllGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
	{
        return super_.getGeneralization();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getGeneralizations()
	{
        return super_.getGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getSpecializations()
	{
        return super_.getSpecializations();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"identifiersPresent"));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.getClass(),
                        this.getName(),
                        "Each entity must have at least one identifier defined."));
        }
    }
}
