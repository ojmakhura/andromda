package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityAssociationFacade.
 *
 * @see org.andromda.metafacades.uml.EntityAssociationFacade
 */
public class EntityAssociationFacadeLogicImpl
       extends EntityAssociationFacadeLogic
       implements org.andromda.metafacades.uml.EntityAssociationFacade
{
    // ---------------- constructor -------------------------------

    public EntityAssociationFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAssociationFacade#getTableName()
     */
    protected java.lang.String handleGetTableName()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

}
