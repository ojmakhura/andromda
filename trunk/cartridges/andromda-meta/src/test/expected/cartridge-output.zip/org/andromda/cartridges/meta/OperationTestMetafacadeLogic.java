//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * MetafacadeLogic for org.andromda.cartridges.meta.OperationTestMetafacade
 *
 * @see org.andromda.cartridges.meta.OperationTestMetafacade
 */
public abstract class OperationTestMetafacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.cartridges.meta.OperationTestMetafacade
{

    protected Object metaObject;
    private org.andromda.metafacades.uml.OperationFacade super_;

    public OperationTestMetafacadeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.OperationFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.OperationFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.cartridges.meta.OperationTestMetafacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
    */
    protected abstract boolean handleIsTestAttribute();

    private void handleIsTestAttribute1aPreCondition()
    {
    }

    private void handleIsTestAttribute1aPostCondition()
    {
    }

    private boolean __testAttribute1a;
    private boolean __testAttribute1aSet = false;

    public final boolean isTestAttribute()
    {
        boolean testAttribute1a = this.__testAttribute1a;
        if (!this.__testAttribute1aSet)
        {
            handleIsTestAttribute1aPreCondition();
            testAttribute1a = handleIsTestAttribute();
            handleIsTestAttribute1aPostCondition();
            this.__testAttribute1a = testAttribute1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__testAttribute1aSet = true;
            }
        }
        return testAttribute1a;
    }

    // ------------- associations ------------------

    private void handleGetTestClassifier1rPreCondition()
    {
    }

    private void handleGetTestClassifier1rPostCondition()
    {
    }

    public final org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier()
    {
        org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier1r = null;
        handleGetTestClassifier1rPreCondition();
        Object result = this.shieldedElement(handleGetTestClassifier());
        try
        {
            getTestClassifier1r = (org.andromda.cartridges.meta.ClassifierTestMetafacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTestClassifier1rPostCondition();
        return getTestClassifier1r;
    }

    protected abstract java.lang.Object handleGetTestClassifier();

    // ----------- delegates to org.andromda.metafacades.uml.OperationFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName(boolean modelName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPackageName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean isConstraintsPresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isConstraintsPresent();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.translateConstraints(kind, translation);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.findTaggedValue(name, follow);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentNames()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getArgumentNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getArgumentTypeNames()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getArgumentTypeNames();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getArguments()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getArguments();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getCall()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getConcurrency()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getConcurrency();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList(java.lang.String initialExceptions)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getExceptionList(initialExceptions);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getExceptionList()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getExceptionList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getExceptions()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getExceptions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getOwner();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getParameters()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getParameters();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPostconditionName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPostconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPostconditions()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPostconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionCall()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPreconditionCall();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionName()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPreconditionName();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getPreconditionSignature()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPreconditionSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.util.Collection getPreconditions()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getPreconditions();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public org.andromda.metafacades.uml.ClassifierFacade getReturnType()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getReturnType();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(boolean withArgumentNames)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getSignature(withArgumentNames);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getSignature();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getSignature(java.lang.String argumentModifier)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getSignature(argumentModifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList(java.lang.String modifier)
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getTypedArgumentList(modifier);
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public java.lang.String getTypedArgumentList()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.getTypedArgumentList();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isAbstract()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isAbstract();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isExceptionsPresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isExceptionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPostconditionsPresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isPostconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isPreconditionsPresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isPreconditionsPresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isQuery()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isQuery();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isReturnTypePresent()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isReturnTypePresent();
    }

    // from org.andromda.metafacades.uml.OperationFacade
    public boolean isStatic()
    {
        ((org.andromda.core.metafacade.MetafacadeBase)super_).setMetafacadeContext(this.getMetafacadeContext());
        return super_.isStatic();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        return super_.getValidationOwner();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        return super_.getValidationName();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.nonEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"testAttribute")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Test attribute is required."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
