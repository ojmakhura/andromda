//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents an attribute of an entity.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface EntityAttributeFacade
       extends org.andromda.metafacades.uml.AttributeFacade
{

   /**
    * <p>
    *  Gets the length of the column that persists this entity
    *  attribute.
    * </p>
    */
    public java.lang.String getColumnLength();

   /**
    * <p>
    *  Gets the name of the table column to which this entity is
    *  mapped.
    * </p>
    */
    public java.lang.String getColumnName();

   /**
    * <p>
    *  Gets the PIM to language specific mappings for JDBC.
    * </p>
    */
    public org.andromda.core.mapping.Mappings getJdbcMappings();

   /**
    * <p>
    *  Gets the JDBC type for this entity attribute.
    * </p>
    */
    public java.lang.String getJdbcType();

   /**
    * <p>
    *  Gets the SQL mappings (i.e. the mappings which provide PIM to
    *  SQL mappings).
    * </p>
    */
    public org.andromda.core.mapping.Mappings getSqlMappings();

   /**
    * <p>
    *  Gets the SQL type for this attribute.
    * </p>
    */
    public java.lang.String getSqlType();

   /**
    * <p>
    *  Returns true if this attribute is an identifier for its entity.
    * </p>
    */
    public boolean isIdentifier();

}
