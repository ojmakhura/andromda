//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.DependencyFacade
 *
 * @see org.andromda.metafacades.uml.DependencyFacade
 */
public abstract class DependencyFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.DependencyFacade
{

    protected org.omg.uml.foundation.core.Dependency metaObject;

    public DependencyFacadeLogic(org.omg.uml.foundation.core.Dependency metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.DependencyFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.DependencyFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName1aPreCondition()
    {
    }

    private void handleGetGetterName1aPostCondition()
    {
    }

    private java.lang.String __getterName1a;
    private boolean __getterName1aSet = false;

    public final java.lang.String getGetterName()
    {
        java.lang.String getterName1a = this.__getterName1a;
        if (!this.__getterName1aSet)
        {
            handleGetGetterName1aPreCondition();
            getterName1a = handleGetGetterName();
            handleGetGetterName1aPostCondition();
            this.__getterName1a = getterName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterName1aSet = true;
            }
        }
        return getterName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.DependencyFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName2aPreCondition()
    {
    }

    private void handleGetSetterName2aPostCondition()
    {
    }

    private java.lang.String __setterName2a;
    private boolean __setterName2aSet = false;

    public final java.lang.String getSetterName()
    {
        java.lang.String setterName2a = this.__setterName2a;
        if (!this.__setterName2aSet)
        {
            handleGetSetterName2aPreCondition();
            setterName2a = handleGetSetterName();
            handleGetSetterName2aPostCondition();
            this.__setterName2a = setterName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__setterName2aSet = true;
            }
        }
        return setterName2a;
    }

    // ------------- associations ------------------

    private void handleGetTargetElement1rPreCondition()
    {
    }

    private void handleGetTargetElement1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getTargetElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getTargetElement1r = null;
        handleGetTargetElement1rPreCondition();
        Object result = this.shieldedElement(handleGetTargetElement());
        try
        {
            getTargetElement1r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTargetElement1rPostCondition();
        return getTargetElement1r;
    }

    protected abstract java.lang.Object handleGetTargetElement();

    private void handleGetSourceElement5rPreCondition()
    {
    }

    private void handleGetSourceElement5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getSourceElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getSourceElement5r = null;
        handleGetSourceElement5rPreCondition();
        Object result = this.shieldedElement(handleGetSourceElement());
        try
        {
            getSourceElement5r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSourceElement5rPostCondition();
        return getSourceElement5r;
    }

    protected abstract java.lang.Object handleGetSourceElement();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}