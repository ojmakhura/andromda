//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a service.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ServiceFacade
       extends org.andromda.metafacades.uml.ClassifierFacade
{

   /**
    * <p>
    *  References to all entities to which this service has a
    *  dependency.
    * </p>
    */
    public java.util.Collection getEntityReferences();

   /**
    * <p>
    *  References to all services to which this service has a
    *  dependency.
    * </p>
    */
    public java.util.Collection getServiceReferences();

}
