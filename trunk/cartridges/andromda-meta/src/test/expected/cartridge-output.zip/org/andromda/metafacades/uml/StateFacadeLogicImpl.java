package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.StateFacade.
 *
 * @see org.andromda.metafacades.uml.StateFacade
 */
public class StateFacadeLogicImpl
    extends StateFacadeLogic
{
    // ---------------- constructor -------------------------------

    public StateFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.State metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.StateFacade#getDeferrableEvents()
     */
    protected java.util.Collection handleGetState()
    {
        // TODO: add your implementation here!
        return null;
    }

}