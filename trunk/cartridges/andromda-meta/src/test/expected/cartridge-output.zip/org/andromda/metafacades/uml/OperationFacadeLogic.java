//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.OperationFacade
 *
 * @see org.andromda.metafacades.uml.OperationFacade
 */
public abstract class OperationFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.OperationFacade
{

    protected org.omg.uml.foundation.core.Operation metaObject;

    public OperationFacadeLogic(org.omg.uml.foundation.core.Operation metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.OperationFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getSignature()
    */
    protected abstract java.lang.String handleGetSignature();

    private void handleGetSignature1aPreCondition()
    {
    }

    private void handleGetSignature1aPostCondition()
    {
    }

    private java.lang.String __signature1a;
    private boolean __signature1aSet = false;

    public final java.lang.String getSignature()
    {
        java.lang.String signature1a = this.__signature1a;
        if (!this.__signature1aSet)
        {
            handleGetSignature1aPreCondition();
            signature1a = handleGetSignature();
            handleGetSignature1aPostCondition();
            this.__signature1a = signature1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__signature1aSet = true;
            }
        }
        return signature1a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getCall()
    */
    protected abstract java.lang.String handleGetCall();

    private void handleGetCall2aPreCondition()
    {
    }

    private void handleGetCall2aPostCondition()
    {
    }

    private java.lang.String __call2a;
    private boolean __call2aSet = false;

    public final java.lang.String getCall()
    {
        java.lang.String call2a = this.__call2a;
        if (!this.__call2aSet)
        {
            handleGetCall2aPreCondition();
            call2a = handleGetCall();
            handleGetCall2aPostCondition();
            this.__call2a = call2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__call2aSet = true;
            }
        }
        return call2a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getTypedArgumentList()
    */
    protected abstract java.lang.String handleGetTypedArgumentList();

    private void handleGetTypedArgumentList3aPreCondition()
    {
    }

    private void handleGetTypedArgumentList3aPostCondition()
    {
    }

    private java.lang.String __typedArgumentList3a;
    private boolean __typedArgumentList3aSet = false;

    public final java.lang.String getTypedArgumentList()
    {
        java.lang.String typedArgumentList3a = this.__typedArgumentList3a;
        if (!this.__typedArgumentList3aSet)
        {
            handleGetTypedArgumentList3aPreCondition();
            typedArgumentList3a = handleGetTypedArgumentList();
            handleGetTypedArgumentList3aPostCondition();
            this.__typedArgumentList3a = typedArgumentList3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__typedArgumentList3aSet = true;
            }
        }
        return typedArgumentList3a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#isStatic()
    */
    protected abstract boolean handleIsStatic();

    private void handleIsStatic4aPreCondition()
    {
    }

    private void handleIsStatic4aPostCondition()
    {
    }

    private boolean __static4a;
    private boolean __static4aSet = false;

    public final boolean isStatic()
    {
        boolean static4a = this.__static4a;
        if (!this.__static4aSet)
        {
            handleIsStatic4aPreCondition();
            static4a = handleIsStatic();
            handleIsStatic4aPostCondition();
            this.__static4a = static4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__static4aSet = true;
            }
        }
        return static4a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#isAbstract()
    */
    protected abstract boolean handleIsAbstract();

    private void handleIsAbstract5aPreCondition()
    {
    }

    private void handleIsAbstract5aPostCondition()
    {
    }

    private boolean __abstract5a;
    private boolean __abstract5aSet = false;

    public final boolean isAbstract()
    {
        boolean abstract5a = this.__abstract5a;
        if (!this.__abstract5aSet)
        {
            handleIsAbstract5aPreCondition();
            abstract5a = handleIsAbstract();
            handleIsAbstract5aPostCondition();
            this.__abstract5a = abstract5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__abstract5aSet = true;
            }
        }
        return abstract5a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getExceptionList()
    */
    protected abstract java.lang.String handleGetExceptionList();

    private void handleGetExceptionList6aPreCondition()
    {
    }

    private void handleGetExceptionList6aPostCondition()
    {
    }

    private java.lang.String __exceptionList6a;
    private boolean __exceptionList6aSet = false;

    public final java.lang.String getExceptionList()
    {
        java.lang.String exceptionList6a = this.__exceptionList6a;
        if (!this.__exceptionList6aSet)
        {
            handleGetExceptionList6aPreCondition();
            exceptionList6a = handleGetExceptionList();
            handleGetExceptionList6aPostCondition();
            this.__exceptionList6a = exceptionList6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exceptionList6aSet = true;
            }
        }
        return exceptionList6a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getExceptions()
    */
    protected abstract java.util.Collection handleGetExceptions();

    private void handleGetExceptions7aPreCondition()
    {
    }

    private void handleGetExceptions7aPostCondition()
    {
    }

    private java.util.Collection __exceptions7a;
    private boolean __exceptions7aSet = false;

    public final java.util.Collection getExceptions()
    {
        java.util.Collection exceptions7a = this.__exceptions7a;
        if (!this.__exceptions7aSet)
        {
            handleGetExceptions7aPreCondition();
            exceptions7a = handleGetExceptions();
            handleGetExceptions7aPostCondition();
            this.__exceptions7a = exceptions7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exceptions7aSet = true;
            }
        }
        return exceptions7a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#isReturnTypePresent()
    */
    protected abstract boolean handleIsReturnTypePresent();

    private void handleIsReturnTypePresent8aPreCondition()
    {
    }

    private void handleIsReturnTypePresent8aPostCondition()
    {
    }

    private boolean __returnTypePresent8a;
    private boolean __returnTypePresent8aSet = false;

    public final boolean isReturnTypePresent()
    {
        boolean returnTypePresent8a = this.__returnTypePresent8a;
        if (!this.__returnTypePresent8aSet)
        {
            handleIsReturnTypePresent8aPreCondition();
            returnTypePresent8a = handleIsReturnTypePresent();
            handleIsReturnTypePresent8aPostCondition();
            this.__returnTypePresent8a = returnTypePresent8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__returnTypePresent8aSet = true;
            }
        }
        return returnTypePresent8a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#isExceptionsPresent()
    */
    protected abstract boolean handleIsExceptionsPresent();

    private void handleIsExceptionsPresent9aPreCondition()
    {
    }

    private void handleIsExceptionsPresent9aPostCondition()
    {
    }

    private boolean __exceptionsPresent9a;
    private boolean __exceptionsPresent9aSet = false;

    public final boolean isExceptionsPresent()
    {
        boolean exceptionsPresent9a = this.__exceptionsPresent9a;
        if (!this.__exceptionsPresent9aSet)
        {
            handleIsExceptionsPresent9aPreCondition();
            exceptionsPresent9a = handleIsExceptionsPresent();
            handleIsExceptionsPresent9aPostCondition();
            this.__exceptionsPresent9a = exceptionsPresent9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exceptionsPresent9aSet = true;
            }
        }
        return exceptionsPresent9a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getArgumentNames()
    */
    protected abstract java.lang.String handleGetArgumentNames();

    private void handleGetArgumentNames10aPreCondition()
    {
    }

    private void handleGetArgumentNames10aPostCondition()
    {
    }

    private java.lang.String __argumentNames10a;
    private boolean __argumentNames10aSet = false;

    public final java.lang.String getArgumentNames()
    {
        java.lang.String argumentNames10a = this.__argumentNames10a;
        if (!this.__argumentNames10aSet)
        {
            handleGetArgumentNames10aPreCondition();
            argumentNames10a = handleGetArgumentNames();
            handleGetArgumentNames10aPostCondition();
            this.__argumentNames10a = argumentNames10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__argumentNames10aSet = true;
            }
        }
        return argumentNames10a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getArgumentTypeNames()
    */
    protected abstract java.lang.String handleGetArgumentTypeNames();

    private void handleGetArgumentTypeNames11aPreCondition()
    {
    }

    private void handleGetArgumentTypeNames11aPostCondition()
    {
    }

    private java.lang.String __argumentTypeNames11a;
    private boolean __argumentTypeNames11aSet = false;

    public final java.lang.String getArgumentTypeNames()
    {
        java.lang.String argumentTypeNames11a = this.__argumentTypeNames11a;
        if (!this.__argumentTypeNames11aSet)
        {
            handleGetArgumentTypeNames11aPreCondition();
            argumentTypeNames11a = handleGetArgumentTypeNames();
            handleGetArgumentTypeNames11aPostCondition();
            this.__argumentTypeNames11a = argumentTypeNames11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__argumentTypeNames11aSet = true;
            }
        }
        return argumentTypeNames11a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#isQuery()
    */
    protected abstract boolean handleIsQuery();

    private void handleIsQuery12aPreCondition()
    {
    }

    private void handleIsQuery12aPostCondition()
    {
    }

    private boolean __query12a;
    private boolean __query12aSet = false;

    public final boolean isQuery()
    {
        boolean query12a = this.__query12a;
        if (!this.__query12aSet)
        {
            handleIsQuery12aPreCondition();
            query12a = handleIsQuery();
            handleIsQuery12aPostCondition();
            this.__query12a = query12a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__query12aSet = true;
            }
        }
        return query12a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getConcurrency()
    */
    protected abstract java.lang.String handleGetConcurrency();

    private void handleGetConcurrency13aPreCondition()
    {
    }

    private void handleGetConcurrency13aPostCondition()
    {
    }

    private java.lang.String __concurrency13a;
    private boolean __concurrency13aSet = false;

    public final java.lang.String getConcurrency()
    {
        java.lang.String concurrency13a = this.__concurrency13a;
        if (!this.__concurrency13aSet)
        {
            handleGetConcurrency13aPreCondition();
            concurrency13a = handleGetConcurrency();
            handleGetConcurrency13aPostCondition();
            this.__concurrency13a = concurrency13a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__concurrency13aSet = true;
            }
        }
        return concurrency13a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getPreconditionName()
    */
    protected abstract java.lang.String handleGetPreconditionName();

    private void handleGetPreconditionName14aPreCondition()
    {
    }

    private void handleGetPreconditionName14aPostCondition()
    {
    }

    private java.lang.String __preconditionName14a;
    private boolean __preconditionName14aSet = false;

    public final java.lang.String getPreconditionName()
    {
        java.lang.String preconditionName14a = this.__preconditionName14a;
        if (!this.__preconditionName14aSet)
        {
            handleGetPreconditionName14aPreCondition();
            preconditionName14a = handleGetPreconditionName();
            handleGetPreconditionName14aPostCondition();
            this.__preconditionName14a = preconditionName14a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__preconditionName14aSet = true;
            }
        }
        return preconditionName14a;
    }

   /**
    * @see org.andromda.metafacades.uml.OperationFacade#getPostconditionName()
    */
    protected abstract java.lang.String handleGetPostconditionName();

    private void handleGetPostconditionName15aPreCondition()
    {
    }

    private void handleGetPostconditionName15aPostCondition()
    {
    }

    private java.lang.String __postconditionName15a;
    private boolean __postconditionName15aSet = false;

    public final java.lang.String getPostconditionName()
    {
        java.lang.String postconditionName15a = this.__postconditionName15a;
        if (!this.__postconditionName15aSet)
        {
            handleGetPostconditionName15aPreCondition();
            postconditionName15a = handleGetPostconditionName();
            handleGetPostconditionName15aPostCondition();
            this.__postconditionName15a = postconditionName15a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__postconditionName15aSet = true;
            }
        }
        return postconditionName15a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String name, boolean follow);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(name, follow);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetExceptionList(java.lang.String initialExceptions);

    private void handleGetExceptionList2oPreCondition()
    {
    }

    private void handleGetExceptionList2oPostCondition()
    {
    }

    public java.lang.String getExceptionList(java.lang.String initialExceptions)
    {
        handleGetExceptionList2oPreCondition();
        java.lang.String returnValue = handleGetExceptionList(initialExceptions);
        handleGetExceptionList2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetSignature(boolean withArgumentNames);

    private void handleGetSignature3oPreCondition()
    {
    }

    private void handleGetSignature3oPostCondition()
    {
    }

    public java.lang.String getSignature(boolean withArgumentNames)
    {
        handleGetSignature3oPreCondition();
        java.lang.String returnValue = handleGetSignature(withArgumentNames);
        handleGetSignature3oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetTypedArgumentList(java.lang.String modifier);

    private void handleGetTypedArgumentList4oPreCondition()
    {
    }

    private void handleGetTypedArgumentList4oPostCondition()
    {
    }

    public java.lang.String getTypedArgumentList(java.lang.String modifier)
    {
        handleGetTypedArgumentList4oPreCondition();
        java.lang.String returnValue = handleGetTypedArgumentList(modifier);
        handleGetTypedArgumentList4oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetSignature(java.lang.String argumentModifier);

    private void handleGetSignature5oPreCondition()
    {
    }

    private void handleGetSignature5oPostCondition()
    {
    }

    public java.lang.String getSignature(java.lang.String argumentModifier)
    {
        handleGetSignature5oPreCondition();
        java.lang.String returnValue = handleGetSignature(argumentModifier);
        handleGetSignature5oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetOwner1rPreCondition()
    {
    }

    private void handleGetOwner1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        org.andromda.metafacades.uml.ClassifierFacade getOwner1r = null;
        handleGetOwner1rPreCondition();
        Object result = this.shieldedElement(handleGetOwner());
        try
        {
            getOwner1r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOwner1rPostCondition();
        return getOwner1r;
    }

    protected abstract java.lang.Object handleGetOwner();

    private void handleGetParameters2rPreCondition()
    {
    }

    private void handleGetParameters2rPostCondition()
    {
    }

    public final java.util.Collection getParameters()
    {
        java.util.Collection getParameters2r = null;
        handleGetParameters2rPreCondition();
        Object result = this.shieldedElements(handleGetParameters());
        try
        {
            getParameters2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetParameters2rPostCondition();
        return getParameters2r;
    }

    protected abstract java.util.Collection handleGetParameters();

    private void handleGetReturnType5rPreCondition()
    {
    }

    private void handleGetReturnType5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getReturnType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getReturnType5r = null;
        handleGetReturnType5rPreCondition();
        Object result = this.shieldedElement(handleGetReturnType());
        try
        {
            getReturnType5r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetReturnType5rPostCondition();
        return getReturnType5r;
    }

    protected abstract java.lang.Object handleGetReturnType();

    private void handleGetArguments9rPreCondition()
    {
    }

    private void handleGetArguments9rPostCondition()
    {
    }

    public final java.util.Collection getArguments()
    {
        java.util.Collection getArguments9r = null;
        handleGetArguments9rPreCondition();
        Object result = this.shieldedElements(handleGetArguments());
        try
        {
            getArguments9r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetArguments9rPostCondition();
        return getArguments9r;
    }

    protected abstract java.util.Collection handleGetArguments();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"returnType")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each operation needs a return type, you cannot leave the type unspecified, even if you want void you'll need to explicitely specify it."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Each operation must have a non-empty name."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
