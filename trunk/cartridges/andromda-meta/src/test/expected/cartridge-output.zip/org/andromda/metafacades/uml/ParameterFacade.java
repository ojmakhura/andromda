//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ParameterFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.lang.String getDefaultValue();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * <p>
    *  Returns whether or not this parameter represents a return
    *  parameter.
    * </p>
    */
    public boolean isReturn();

}
