package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ParameterFacade.
 *
 * @see org.andromda.metafacades.uml.ParameterFacade
 */
public class ParameterFacadeLogicImpl
       extends ParameterFacadeLogic
       implements org.andromda.metafacades.uml.ParameterFacade
{
    // ---------------- constructor -------------------------------

    public ParameterFacadeLogicImpl (org.omg.uml.foundation.core.Parameter metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ParameterFacade#getDefaultValue()
     */
    public java.lang.String handleGetDefaultValue() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.ParameterFacade#isReturn()
     */
    public boolean handleIsReturn() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.ParameterFacade#isRequired()
     */
    public boolean handleIsRequired() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.ParameterFacade#getType()
     */
    public java.lang.Object handleGetType()
    {
        // TODO: add your implementation here!
        return null;
    }

}
