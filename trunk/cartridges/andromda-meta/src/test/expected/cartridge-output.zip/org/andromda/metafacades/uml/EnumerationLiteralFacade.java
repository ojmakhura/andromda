//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface EnumerationLiteralFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * <p>
    *  Returns the value of this enumeration literal, by default the
    *  value is the same as the name.
    * </p>
    */
    public java.lang.String getValue();

}
