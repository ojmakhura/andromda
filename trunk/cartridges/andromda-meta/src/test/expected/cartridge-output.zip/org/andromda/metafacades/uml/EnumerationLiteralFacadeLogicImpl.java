package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EnumerationLiteralFacade.
 *
 * @see org.andromda.metafacades.uml.EnumerationLiteralFacade
 */
public class EnumerationLiteralFacadeLogicImpl
       extends EnumerationLiteralFacadeLogic
       implements org.andromda.metafacades.uml.EnumerationLiteralFacade
{
    // ---------------- constructor -------------------------------

    public EnumerationLiteralFacadeLogicImpl (org.omg.uml.foundation.core.EnumerationLiteral metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EnumerationLiteralFacade#getValue()
     */
    protected java.lang.String handleGetValue() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EnumerationLiteralFacade#getEnumeration()
     */
    protected java.lang.Object handleGetEnumeration()
    {
        // TODO: add your implementation here!
        return null;
    }

}
