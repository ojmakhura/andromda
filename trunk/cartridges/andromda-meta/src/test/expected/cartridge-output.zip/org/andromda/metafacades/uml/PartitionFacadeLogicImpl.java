package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.PartitionFacade.
 *
 * @see org.andromda.metafacades.uml.PartitionFacade
 */
public class PartitionFacadeLogicImpl
    extends PartitionFacadeLogic
{

    public PartitionFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.Partition metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.PartitionFacade#getActivityGraph()
     */
    protected java.lang.Object handleGetActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

}