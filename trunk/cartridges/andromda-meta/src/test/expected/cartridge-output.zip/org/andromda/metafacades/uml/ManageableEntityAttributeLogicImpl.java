package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntityAttribute.
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public class ManageableEntityAttributeLogicImpl
    extends ManageableEntityAttributeLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityAttributeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudGetterName()
     */
    protected java.lang.String handleGetCrudGetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudName()
     */
    protected java.lang.String handleGetCrudName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudSetterName()
     */
    protected java.lang.String handleGetCrudSetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

}