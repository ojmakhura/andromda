package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.StereotypeFacade.
 *
 * @see org.andromda.metafacades.uml.StereotypeFacade
 */
public class StereotypeFacadeLogicImpl
    extends StereotypeFacadeLogic
{
    // ---------------- constructor -------------------------------

    public StereotypeFacadeLogicImpl (org.omg.uml.foundation.core.Stereotype metaObject, String context)
    {
        super (metaObject, context);
    }
}