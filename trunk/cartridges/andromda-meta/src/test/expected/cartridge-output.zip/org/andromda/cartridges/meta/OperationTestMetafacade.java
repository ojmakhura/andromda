// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

import org.andromda.metafacades.uml.OperationFacade;
/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface OperationTestMetafacade
    extends OperationFacade
{
    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isOperationTestMetafacadeMetaType();

   /**
    * 
    * @return ClassifierTestMetafacade
    */
    public ClassifierTestMetafacade getTestClassifier();

   /**
    * 
    * @return boolean
    */
    public boolean isTestAttribute();
}