//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ParameterFacade
 *
 * @see org.andromda.metafacades.uml.ParameterFacade
 */
public abstract class ParameterFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ParameterFacade
{

    protected org.omg.uml.foundation.core.Parameter metaObject;

    public ParameterFacadeLogic(org.omg.uml.foundation.core.Parameter metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ParameterFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#getDefaultValue()
    */
    protected abstract java.lang.String handleGetDefaultValue();

    private void handleGetDefaultValue1aPreCondition()
    {
    }

    private void handleGetDefaultValue1aPostCondition()
    {
    }

    private java.lang.String __defaultValue1a;
    private boolean __defaultValue1aSet = false;

    public final java.lang.String getDefaultValue()
    {
        java.lang.String defaultValue1a = this.__defaultValue1a;
        if (!this.__defaultValue1aSet)
        {
            handleGetDefaultValue1aPreCondition();
            defaultValue1a = handleGetDefaultValue();
            handleGetDefaultValue1aPostCondition();
            this.__defaultValue1a = defaultValue1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__defaultValue1aSet = true;
            }
        }
        return defaultValue1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isReturn()
    */
    protected abstract boolean handleIsReturn();

    private void handleIsReturn2aPreCondition()
    {
    }

    private void handleIsReturn2aPostCondition()
    {
    }

    private boolean __return2a;
    private boolean __return2aSet = false;

    public final boolean isReturn()
    {
        boolean return2a = this.__return2a;
        if (!this.__return2aSet)
        {
            handleIsReturn2aPreCondition();
            return2a = handleIsReturn();
            handleIsReturn2aPostCondition();
            this.__return2a = return2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__return2aSet = true;
            }
        }
        return return2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired3aPreCondition()
    {
    }

    private void handleIsRequired3aPostCondition()
    {
    }

    private boolean __required3a;
    private boolean __required3aSet = false;

    public final boolean isRequired()
    {
        boolean required3a = this.__required3a;
        if (!this.__required3aSet)
        {
            handleIsRequired3aPreCondition();
            required3a = handleIsRequired();
            handleIsRequired3aPostCondition();
            this.__required3a = required3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__required3aSet = true;
            }
        }
        return required3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName4aPreCondition()
    {
    }

    private void handleGetGetterName4aPostCondition()
    {
    }

    private java.lang.String __getterName4a;
    private boolean __getterName4aSet = false;

    public final java.lang.String getGetterName()
    {
        java.lang.String getterName4a = this.__getterName4a;
        if (!this.__getterName4aSet)
        {
            handleGetGetterName4aPreCondition();
            getterName4a = handleGetGetterName();
            handleGetGetterName4aPostCondition();
            this.__getterName4a = getterName4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getterName4aSet = true;
            }
        }
        return getterName4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName5aPreCondition()
    {
    }

    private void handleGetSetterName5aPostCondition()
    {
    }

    private java.lang.String __setterName5a;
    private boolean __setterName5aSet = false;

    public final java.lang.String getSetterName()
    {
        java.lang.String setterName5a = this.__setterName5a;
        if (!this.__setterName5aSet)
        {
            handleGetSetterName5aPreCondition();
            setterName5a = handleGetSetterName();
            handleGetSetterName5aPostCondition();
            this.__setterName5a = setterName5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__setterName5aSet = true;
            }
        }
        return setterName5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isReadable()
    */
    protected abstract boolean handleIsReadable();

    private void handleIsReadable6aPreCondition()
    {
    }

    private void handleIsReadable6aPostCondition()
    {
    }

    private boolean __readable6a;
    private boolean __readable6aSet = false;

    public final boolean isReadable()
    {
        boolean readable6a = this.__readable6a;
        if (!this.__readable6aSet)
        {
            handleIsReadable6aPreCondition();
            readable6a = handleIsReadable();
            handleIsReadable6aPostCondition();
            this.__readable6a = readable6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__readable6aSet = true;
            }
        }
        return readable6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isWritable()
    */
    protected abstract boolean handleIsWritable();

    private void handleIsWritable7aPreCondition()
    {
    }

    private void handleIsWritable7aPostCondition()
    {
    }

    private boolean __writable7a;
    private boolean __writable7aSet = false;

    public final boolean isWritable()
    {
        boolean writable7a = this.__writable7a;
        if (!this.__writable7aSet)
        {
            handleIsWritable7aPreCondition();
            writable7a = handleIsWritable();
            handleIsWritable7aPostCondition();
            this.__writable7a = writable7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__writable7aSet = true;
            }
        }
        return writable7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ParameterFacade#isDefaultValuePresent()
    */
    protected abstract boolean handleIsDefaultValuePresent();

    private void handleIsDefaultValuePresent8aPreCondition()
    {
    }

    private void handleIsDefaultValuePresent8aPostCondition()
    {
    }

    private boolean __defaultValuePresent8a;
    private boolean __defaultValuePresent8aSet = false;

    public final boolean isDefaultValuePresent()
    {
        boolean defaultValuePresent8a = this.__defaultValuePresent8a;
        if (!this.__defaultValuePresent8aSet)
        {
            handleIsDefaultValuePresent8aPreCondition();
            defaultValuePresent8a = handleIsDefaultValuePresent();
            handleIsDefaultValuePresent8aPostCondition();
            this.__defaultValuePresent8a = defaultValuePresent8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__defaultValuePresent8aSet = true;
            }
        }
        return defaultValuePresent8a;
    }

    // ------------- associations ------------------

    private void handleGetOperation1rPreCondition()
    {
    }

    private void handleGetOperation1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.OperationFacade getOperation()
    {
        org.andromda.metafacades.uml.OperationFacade getOperation1r = null;
        handleGetOperation1rPreCondition();
        Object result = this.shieldedElement(handleGetOperation());
        try
        {
            getOperation1r = (org.andromda.metafacades.uml.OperationFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOperation1rPostCondition();
        return getOperation1r;
    }

    protected abstract java.lang.Object handleGetOperation();

    private void handleGetEvent2rPreCondition()
    {
    }

    private void handleGetEvent2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EventFacade getEvent()
    {
        org.andromda.metafacades.uml.EventFacade getEvent2r = null;
        handleGetEvent2rPreCondition();
        Object result = this.shieldedElement(handleGetEvent());
        try
        {
            getEvent2r = (org.andromda.metafacades.uml.EventFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEvent2rPostCondition();
        return getEvent2r;
    }

    protected abstract java.lang.Object handleGetEvent();

    private void handleGetType3rPreCondition()
    {
    }

    private void handleGetType3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getType3r = null;
        handleGetType3rPreCondition();
        Object result = this.shieldedElement(handleGetType());
        try
        {
            getType3r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetType3rPostCondition();
        return getType3r;
    }

    protected abstract java.lang.Object handleGetType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"type")):true)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each parameter needs a type, you cannot leave the type unspecified."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure((Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"return"),false))).booleanValue()?org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name")):true)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each parameter that is NOT a return parameter must have a non-empty name."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}