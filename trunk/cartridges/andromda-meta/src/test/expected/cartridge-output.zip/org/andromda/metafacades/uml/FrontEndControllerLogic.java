//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndController
 *
 * @see org.andromda.metafacades.uml.FrontEndController
 */
public abstract class FrontEndControllerLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndController
{

    protected Object metaObject;

    public FrontEndControllerLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndController";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndController#getFullPath()
    */
    protected abstract java.lang.String handleGetFullPath();

    private void handleGetFullPath1aPreCondition()
    {
    }

    private void handleGetFullPath1aPostCondition()
    {
    }

    private java.lang.String __fullPath1a;
    private boolean __fullPath1aSet = false;

    public final java.lang.String getFullPath()
    {
        java.lang.String fullPath1a = this.__fullPath1a;
        if (!this.__fullPath1aSet)
        {
            handleGetFullPath1aPreCondition();
            fullPath1a = handleGetFullPath();
            handleGetFullPath1aPostCondition();
            this.__fullPath1a = fullPath1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullPath1aSet = true;
            }
        }
        return fullPath1a;
    }

    // ------------- associations ------------------

    private void handleGetServiceReferences1rPreCondition()
    {
    }

    private void handleGetServiceReferences1rPostCondition()
    {
    }

    private java.util.List __getServiceReferences1r;
    private boolean __getServiceReferences1rSet = false;

    public final java.util.List getServiceReferences()
    {
        java.util.List getServiceReferences1r = this.__getServiceReferences1r;
        if (!this.__getServiceReferences1rSet)
        {
            handleGetServiceReferences1rPreCondition();
            Object result = this.shieldedElements(handleGetServiceReferences());
            try
            {
                getServiceReferences1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetServiceReferences1rPostCondition();
            this.__getServiceReferences1r = getServiceReferences1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getServiceReferences1rSet = true;
            }
        }
        return getServiceReferences1r;
    }

    protected abstract java.util.List handleGetServiceReferences();

    private void handleGetUseCase2rPreCondition()
    {
    }

    private void handleGetUseCase2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndUseCase __getUseCase2r;
    private boolean __getUseCase2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndUseCase getUseCase()
    {
        org.andromda.metafacades.uml.FrontEndUseCase getUseCase2r = this.__getUseCase2r;
        if (!this.__getUseCase2rSet)
        {
            handleGetUseCase2rPreCondition();
            Object result = this.shieldedElement(handleGetUseCase());
            try
            {
                getUseCase2r = (org.andromda.metafacades.uml.FrontEndUseCase)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetUseCase2rPostCondition();
            this.__getUseCase2r = getUseCase2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUseCase2rSet = true;
            }
        }
        return getUseCase2r;
    }

    protected abstract java.lang.Object handleGetUseCase();

    private void handleGetDeferringActions5rPreCondition()
    {
    }

    private void handleGetDeferringActions5rPostCondition()
    {
    }

    private java.util.List __getDeferringActions5r;
    private boolean __getDeferringActions5rSet = false;

    public final java.util.List getDeferringActions()
    {
        java.util.List getDeferringActions5r = this.__getDeferringActions5r;
        if (!this.__getDeferringActions5rSet)
        {
            handleGetDeferringActions5rPreCondition();
            Object result = this.shieldedElements(handleGetDeferringActions());
            try
            {
                getDeferringActions5r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDeferringActions5rPostCondition();
            this.__getDeferringActions5r = getDeferringActions5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDeferringActions5rSet = true;
            }
        }
        return getDeferringActions5r;
    }

    protected abstract java.util.List handleGetDeferringActions();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}