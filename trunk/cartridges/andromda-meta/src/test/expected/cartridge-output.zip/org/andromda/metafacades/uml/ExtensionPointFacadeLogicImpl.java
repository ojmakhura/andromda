package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ExtensionPointFacade.
 *
 * @see org.andromda.metafacades.uml.ExtensionPointFacade
 */
public class ExtensionPointFacadeLogicImpl
    extends ExtensionPointFacadeLogic
{

    public ExtensionPointFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.ExtensionPoint metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ExtensionPointFacade#getUseCase()
     */
    protected java.lang.Object handleGetExtensionPoints()
    {
        // TODO: add your implementation here!
        return null;
    }

}