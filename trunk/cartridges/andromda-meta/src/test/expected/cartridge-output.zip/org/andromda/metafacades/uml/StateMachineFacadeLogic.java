//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.StateMachineFacade
 *
 * @see org.andromda.metafacades.uml.StateMachineFacade
 */
public abstract class StateMachineFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.StateMachineFacade
{

    protected org.omg.uml.behavioralelements.statemachines.StateMachine metaObject;

    public StateMachineFacadeLogic(org.omg.uml.behavioralelements.statemachines.StateMachine metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateMachineFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetContextElement1rPreCondition()
    {
    }

    private void handleGetContextElement1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getContextElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getContextElement1r = null;
        handleGetContextElement1rPreCondition();
        Object result = this.shieldedElement(handleGetContextElement());
        try
        {
            getContextElement1r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetContextElement1rPostCondition();
        return getContextElement1r;
    }

    protected abstract java.lang.Object handleGetContextElement();

    private void handleGetFinalStates2rPreCondition()
    {
    }

    private void handleGetFinalStates2rPostCondition()
    {
    }

    public final java.util.Collection getFinalStates()
    {
        java.util.Collection getFinalStates2r = null;
        handleGetFinalStates2rPreCondition();
        Object result = this.shieldedElements(handleGetFinalStates());
        try
        {
            getFinalStates2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetFinalStates2rPostCondition();
        return getFinalStates2r;
    }

    protected abstract java.util.Collection handleGetFinalStates();

    private void handleGetInitialTransition4rPreCondition()
    {
    }

    private void handleGetInitialTransition4rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.TransitionFacade __getInitialTransition4r;
    private boolean __getInitialTransition4rSet = false;

    public final org.andromda.metafacades.uml.TransitionFacade getInitialTransition()
    {
        org.andromda.metafacades.uml.TransitionFacade getInitialTransition4r = this.__getInitialTransition4r;
        if (!this.__getInitialTransition4rSet)
        {
            handleGetInitialTransition4rPreCondition();
            Object result = this.shieldedElement(handleGetInitialTransition());
            try
            {
                getInitialTransition4r = (org.andromda.metafacades.uml.TransitionFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialTransition4rPostCondition();
            this.__getInitialTransition4r = getInitialTransition4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialTransition4rSet = true;
            }
        }
        return getInitialTransition4r;
    }

    protected abstract java.lang.Object handleGetInitialTransition();

    private void handleGetTransitions5rPreCondition()
    {
    }

    private void handleGetTransitions5rPostCondition()
    {
    }

    public final java.util.Collection getTransitions()
    {
        java.util.Collection getTransitions5r = null;
        handleGetTransitions5rPreCondition();
        Object result = this.shieldedElements(handleGetTransitions());
        try
        {
            getTransitions5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTransitions5rPostCondition();
        return getTransitions5r;
    }

    protected abstract java.util.Collection handleGetTransitions();

    private void handleGetInitialStates6rPreCondition()
    {
    }

    private void handleGetInitialStates6rPostCondition()
    {
    }

    public final java.util.Collection getInitialStates()
    {
        java.util.Collection getInitialStates6r = null;
        handleGetInitialStates6rPreCondition();
        Object result = this.shieldedElements(handleGetInitialStates());
        try
        {
            getInitialStates6r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetInitialStates6rPostCondition();
        return getInitialStates6r;
    }

    protected abstract java.util.Collection handleGetInitialStates();

    private void handleGetInitialState7rPreCondition()
    {
    }

    private void handleGetInitialState7rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.PseudostateFacade __getInitialState7r;
    private boolean __getInitialState7rSet = false;

    public final org.andromda.metafacades.uml.PseudostateFacade getInitialState()
    {
        org.andromda.metafacades.uml.PseudostateFacade getInitialState7r = this.__getInitialState7r;
        if (!this.__getInitialState7rSet)
        {
            handleGetInitialState7rPreCondition();
            Object result = this.shieldedElement(handleGetInitialState());
            try
            {
                getInitialState7r = (org.andromda.metafacades.uml.PseudostateFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialState7rPostCondition();
            this.__getInitialState7r = getInitialState7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialState7rSet = true;
            }
        }
        return getInitialState7r;
    }

    protected abstract java.lang.Object handleGetInitialState();

    private void handleGetPseudostates8rPreCondition()
    {
    }

    private void handleGetPseudostates8rPostCondition()
    {
    }

    public final java.util.Collection getPseudostates()
    {
        java.util.Collection getPseudostates8r = null;
        handleGetPseudostates8rPreCondition();
        Object result = this.shieldedElements(handleGetPseudostates());
        try
        {
            getPseudostates8r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetPseudostates8rPostCondition();
        return getPseudostates8r;
    }

    protected abstract java.util.Collection handleGetPseudostates();

    private void handleGetStates10rPreCondition()
    {
    }

    private void handleGetStates10rPostCondition()
    {
    }

    private java.util.Collection __getStates10r;
    private boolean __getStates10rSet = false;

    public final java.util.Collection getStates()
    {
        java.util.Collection getStates10r = this.__getStates10r;
        if (!this.__getStates10rSet)
        {
            handleGetStates10rPreCondition();
            Object result = this.shieldedElements(handleGetStates());
            try
            {
                getStates10r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetStates10rPostCondition();
            this.__getStates10r = getStates10r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getStates10rSet = true;
            }
        }
        return getStates10r;
    }

    protected abstract java.util.Collection handleGetStates();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}