package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.GuardFacade.
 *
 * @see org.andromda.metafacades.uml.GuardFacade
 */
public class GuardFacadeLogicImpl
    extends GuardFacadeLogic
{
    // ---------------- constructor -------------------------------

    public GuardFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.Guard metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.GuardFacade#getTransition()
     */
    protected java.lang.Object handleGetTransition()
    {
        // TODO: add your implementation here!
        return null;
    }

}
