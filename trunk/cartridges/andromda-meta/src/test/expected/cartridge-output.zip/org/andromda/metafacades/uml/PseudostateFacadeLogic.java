//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PseudostateFacade
 *
 * @see org.andromda.metafacades.uml.PseudostateFacade
 */
public abstract class PseudostateFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.PseudostateFacade
{
    protected org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject;
    private org.andromda.metafacades.uml.StateVertexFacade super_;

    public PseudostateFacadeLogic (org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.StateVertexFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.StateVertexFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.PseudostateFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see boolean#isChoice()
    */
    protected abstract boolean handleIsChoice();

    private void handleIsChoice1aPreCondition()
    {
    }

    private void handleIsChoice1aPostCondition()
    {
    }

    public final boolean isChoice()
    {
        handleIsChoice1aPreCondition();
        boolean choice1a = handleIsChoice();
        handleIsChoice1aPostCondition();
        return choice1a;
    }

   /**
	* @see boolean#isDecisionPoint()
    */
    protected abstract boolean handleIsDecisionPoint();

    private void handleIsDecisionPoint2aPreCondition()
    {
    }

    private void handleIsDecisionPoint2aPostCondition()
    {
    }

    public final boolean isDecisionPoint()
    {
        handleIsDecisionPoint2aPreCondition();
        boolean decisionPoint2a = handleIsDecisionPoint();
        handleIsDecisionPoint2aPostCondition();
        return decisionPoint2a;
    }

   /**
	* @see boolean#isDeepHistory()
    */
    protected abstract boolean handleIsDeepHistory();

    private void handleIsDeepHistory3aPreCondition()
    {
    }

    private void handleIsDeepHistory3aPostCondition()
    {
    }

    public final boolean isDeepHistory()
    {
        handleIsDeepHistory3aPreCondition();
        boolean deepHistory3a = handleIsDeepHistory();
        handleIsDeepHistory3aPostCondition();
        return deepHistory3a;
    }

   /**
	* @see boolean#isFork()
    */
    protected abstract boolean handleIsFork();

    private void handleIsFork4aPreCondition()
    {
    }

    private void handleIsFork4aPostCondition()
    {
    }

    public final boolean isFork()
    {
        handleIsFork4aPreCondition();
        boolean fork4a = handleIsFork();
        handleIsFork4aPostCondition();
        return fork4a;
    }

   /**
	* @see boolean#isInitialState()
    */
    protected abstract boolean handleIsInitialState();

    private void handleIsInitialState5aPreCondition()
    {
    }

    private void handleIsInitialState5aPostCondition()
    {
    }

    public final boolean isInitialState()
    {
        handleIsInitialState5aPreCondition();
        boolean initialState5a = handleIsInitialState();
        handleIsInitialState5aPostCondition();
        return initialState5a;
    }

   /**
	* @see boolean#isJoin()
    */
    protected abstract boolean handleIsJoin();

    private void handleIsJoin6aPreCondition()
    {
    }

    private void handleIsJoin6aPostCondition()
    {
    }

    public final boolean isJoin()
    {
        handleIsJoin6aPreCondition();
        boolean join6a = handleIsJoin();
        handleIsJoin6aPostCondition();
        return join6a;
    }

   /**
	* @see boolean#isJunction()
    */
    protected abstract boolean handleIsJunction();

    private void handleIsJunction7aPreCondition()
    {
    }

    private void handleIsJunction7aPostCondition()
    {
    }

    public final boolean isJunction()
    {
        handleIsJunction7aPreCondition();
        boolean junction7a = handleIsJunction();
        handleIsJunction7aPostCondition();
        return junction7a;
    }

   /**
	* @see boolean#isMergePoint()
    */
    protected abstract boolean handleIsMergePoint();

    private void handleIsMergePoint8aPreCondition()
    {
    }

    private void handleIsMergePoint8aPostCondition()
    {
    }

    public final boolean isMergePoint()
    {
        handleIsMergePoint8aPreCondition();
        boolean mergePoint8a = handleIsMergePoint();
        handleIsMergePoint8aPostCondition();
        return mergePoint8a;
    }

   /**
	* @see boolean#isShallowHistory()
    */
    protected abstract boolean handleIsShallowHistory();

    private void handleIsShallowHistory9aPreCondition()
    {
    }

    private void handleIsShallowHistory9aPostCondition()
    {
    }

    public final boolean isShallowHistory()
    {
        handleIsShallowHistory9aPreCondition();
        boolean shallowHistory9a = handleIsShallowHistory();
        handleIsShallowHistory9aPostCondition();
        return shallowHistory9a;
    }

    // ------------- associations ------------------

    // ----------- delegates to org.andromda.metafacades.uml.StateVertexFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph()
	{
        return super_.getActivityGraph();
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public java.util.Collection getIncoming()
	{
        return super_.getIncoming();
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public java.util.Collection getOutgoing()
	{
        return super_.getOutgoing();
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
