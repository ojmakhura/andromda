//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PseudostateFacade
 *
 * @see org.andromda.metafacades.uml.PseudostateFacade
 */
public abstract class PseudostateFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.PseudostateFacade
{
    protected org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject;
    private org.andromda.metafacades.uml.StateVertexFacade super_;

    public PseudostateFacadeLogic (org.omg.uml.behavioralelements.statemachines.Pseudostate metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.StateVertexFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.StateVertexFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.PseudostateFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    public abstract boolean handleIsChoice();

    private void handleIsChoice1oPreCondition()
    {
    }

    private void handleIsChoice1oPostCondition()
    {
    }

    public final boolean isChoice()
    {
        handleIsChoice1oPreCondition();
        boolean returnValue = handleIsChoice();
        handleIsChoice1oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsInitialState();

    private void handleIsInitialState2oPreCondition()
    {
    }

    private void handleIsInitialState2oPostCondition()
    {
    }

    public final boolean isInitialState()
    {
        handleIsInitialState2oPreCondition();
        boolean returnValue = handleIsInitialState();
        handleIsInitialState2oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsJoin();

    private void handleIsJoin3oPreCondition()
    {
    }

    private void handleIsJoin3oPostCondition()
    {
    }

    public final boolean isJoin()
    {
        handleIsJoin3oPreCondition();
        boolean returnValue = handleIsJoin();
        handleIsJoin3oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsDeepHistory();

    private void handleIsDeepHistory4oPreCondition()
    {
    }

    private void handleIsDeepHistory4oPostCondition()
    {
    }

    public final boolean isDeepHistory()
    {
        handleIsDeepHistory4oPreCondition();
        boolean returnValue = handleIsDeepHistory();
        handleIsDeepHistory4oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsFork();

    private void handleIsFork5oPreCondition()
    {
    }

    private void handleIsFork5oPostCondition()
    {
    }

    public final boolean isFork()
    {
        handleIsFork5oPreCondition();
        boolean returnValue = handleIsFork();
        handleIsFork5oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsJunction();

    private void handleIsJunction6oPreCondition()
    {
    }

    private void handleIsJunction6oPostCondition()
    {
    }

    public final boolean isJunction()
    {
        handleIsJunction6oPreCondition();
        boolean returnValue = handleIsJunction();
        handleIsJunction6oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsShallowHistory();

    private void handleIsShallowHistory7oPreCondition()
    {
    }

    private void handleIsShallowHistory7oPostCondition()
    {
    }

    public final boolean isShallowHistory()
    {
        handleIsShallowHistory7oPreCondition();
        boolean returnValue = handleIsShallowHistory();
        handleIsShallowHistory7oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsDecisionPoint();

    private void handleIsDecisionPoint8oPreCondition()
    {
    }

    private void handleIsDecisionPoint8oPostCondition()
    {
    }

    public final boolean isDecisionPoint()
    {
        handleIsDecisionPoint8oPreCondition();
        boolean returnValue = handleIsDecisionPoint();
        handleIsDecisionPoint8oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsMergePoint();

    private void handleIsMergePoint9oPreCondition()
    {
    }

    private void handleIsMergePoint9oPostCondition()
    {
    }

    public final boolean isMergePoint()
    {
        handleIsMergePoint9oPreCondition();
        boolean returnValue = handleIsMergePoint();
        handleIsMergePoint9oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    // ----------- delegates to org.andromda.metafacades.uml.StateVertexFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph()
	{
        return super_.getActivityGraph();
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public java.util.Collection getIncoming()
	{
        return super_.getIncoming();
	}
	
    // from org.andromda.metafacades.uml.StateVertexFacade
	public java.util.Collection getOutgoing()
	{
        return super_.getOutgoing();
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
