package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.DependencyFacade.
 *
 * @see org.andromda.metafacades.uml.DependencyFacade
 */
public class DependencyFacadeLogicImpl
       extends DependencyFacadeLogic
       implements org.andromda.metafacades.uml.DependencyFacade
{
    // ---------------- constructor -------------------------------

    public DependencyFacadeLogicImpl (org.omg.uml.foundation.core.Dependency metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getGetterName()
     */
    public java.lang.String handleGetGetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getSetterName()
     */
    public java.lang.String handleGetSetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getTargetElement()
     */
    public java.lang.Object handleGetTargetElement()
    {
        // TODO: add your implementation here!
        return null;
    }

}
