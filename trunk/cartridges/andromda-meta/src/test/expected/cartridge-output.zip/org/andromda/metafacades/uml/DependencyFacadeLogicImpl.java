package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.DependencyFacade.
 *
 * @see org.andromda.metafacades.uml.DependencyFacade
 */
public class DependencyFacadeLogicImpl
    extends DependencyFacadeLogic
{
    // ---------------- constructor -------------------------------

    public DependencyFacadeLogicImpl (org.omg.uml.foundation.core.Dependency metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getGetterName()
     */
    protected java.lang.String handleGetGetterName()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getSetterName()
     */
    protected java.lang.String handleGetSetterName()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getTargetElement()
     */
    protected java.lang.Object handleGetTargetElement()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.DependencyFacade#getSourceElement()
     */
    protected java.lang.Object handleGetSourceElement()
    {
        // TODO: add your implementation here!
        return null;
    }

}
