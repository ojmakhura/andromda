package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActionFacade.
 *
 * @see org.andromda.metafacades.uml.ActionFacade
 */
public class ActionFacadeLogicImpl
    extends ActionFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ActionFacadeLogicImpl (org.omg.uml.behavioralelements.commonbehavior.Action metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActionFacade#getTransition()
     */
    protected java.lang.Object handleGetTransition()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActionFacade#getActionState()
     */
    protected java.lang.Object handleGetActionState()
    {
        // TODO: add your implementation here!
        return null;
    }

}
