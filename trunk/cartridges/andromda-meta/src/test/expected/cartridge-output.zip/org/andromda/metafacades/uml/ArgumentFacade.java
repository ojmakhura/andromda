//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ArgumentFacade
{
    /**
     * Provides any required initialization of the metafacade.
     */
    void initialize();
    
    /**
     * Performs validation of any invariants found on this model element 
     * and stores the messages within the <code>validationMessages</code>
     * collection.
     *
     * @param validationMessages the collection of messages to which additional
     *        validation messages will be added if invariants are broken.
     */
    void validateInvariants(java.util.Collection validationMessages);

}
