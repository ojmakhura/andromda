//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.UseCaseFacade
 *
 * @see org.andromda.metafacades.uml.UseCaseFacade
 */
public abstract class UseCaseFacadeLogic
    extends org.andromda.metafacades.uml.NamespaceFacadeLogicImpl
    implements org.andromda.metafacades.uml.UseCaseFacade
{

    protected org.omg.uml.behavioralelements.usecases.UseCase metaObject;

    public UseCaseFacadeLogic(org.omg.uml.behavioralelements.usecases.UseCase metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.UseCaseFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetFirstActivityGraph2rPreCondition()
    {
    }

    private void handleGetFirstActivityGraph2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getFirstActivityGraph()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getFirstActivityGraph2r = null;
        handleGetFirstActivityGraph2rPreCondition();
        Object result = this.shieldedElement(handleGetFirstActivityGraph());
        try
        {
            getFirstActivityGraph2r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetFirstActivityGraph2rPostCondition();
        return getFirstActivityGraph2r;
    }

    protected abstract java.lang.Object handleGetFirstActivityGraph();

    private void handleGetExtensionPoints3rPreCondition()
    {
    }

    private void handleGetExtensionPoints3rPostCondition()
    {
    }

    private java.util.Collection __getExtensionPoints3r;
    private boolean __getExtensionPoints3rSet = false;

    public final java.util.Collection getExtensionPoints()
    {
        java.util.Collection getExtensionPoints3r = this.__getExtensionPoints3r;
        if (!this.__getExtensionPoints3rSet)
        {
            handleGetExtensionPoints3rPreCondition();
            Object result = this.shieldedElements(handleGetExtensionPoints());
            try
            {
                getExtensionPoints3r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetExtensionPoints3rPostCondition();
            this.__getExtensionPoints3r = getExtensionPoints3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtensionPoints3rSet = true;
            }
        }
        return getExtensionPoints3r;
    }

    protected abstract java.util.Collection handleGetExtensionPoints();

    private void handleGetExtends4rPreCondition()
    {
    }

    private void handleGetExtends4rPostCondition()
    {
    }

    private java.util.Collection __getExtends4r;
    private boolean __getExtends4rSet = false;

    public final java.util.Collection getExtends()
    {
        java.util.Collection getExtends4r = this.__getExtends4r;
        if (!this.__getExtends4rSet)
        {
            handleGetExtends4rPreCondition();
            Object result = this.shieldedElements(handleGetExtends());
            try
            {
                getExtends4r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetExtends4rPostCondition();
            this.__getExtends4r = getExtends4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExtends4rSet = true;
            }
        }
        return getExtends4r;
    }

    protected abstract java.util.Collection handleGetExtends();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}