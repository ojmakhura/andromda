//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ActionFacade
 *
 * @see org.andromda.metafacades.uml.ActionFacade
 */
public abstract class ActionFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ActionFacade
{

    protected org.omg.uml.behavioralelements.commonbehavior.Action metaObject;

    public ActionFacadeLogic(org.omg.uml.behavioralelements.commonbehavior.Action metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActionFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetTransition1rPreCondition()
    {
    }

    private void handleGetTransition1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.TransitionFacade getTransition()
    {
        org.andromda.metafacades.uml.TransitionFacade getTransition1r = null;
        handleGetTransition1rPreCondition();
        Object result = this.shieldedElement(handleGetTransition());
        try
        {
            getTransition1r = (org.andromda.metafacades.uml.TransitionFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTransition1rPostCondition();
        return getTransition1r;
    }

    protected abstract java.lang.Object handleGetTransition();

    private void handleGetActionState2rPreCondition()
    {
    }

    private void handleGetActionState2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActionStateFacade getActionState()
    {
        org.andromda.metafacades.uml.ActionStateFacade getActionState2r = null;
        handleGetActionState2rPreCondition();
        Object result = this.shieldedElement(handleGetActionState());
        try
        {
            getActionState2r = (org.andromda.metafacades.uml.ActionStateFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActionState2rPostCondition();
        return getActionState2r;
    }

    protected abstract java.lang.Object handleGetActionState();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}