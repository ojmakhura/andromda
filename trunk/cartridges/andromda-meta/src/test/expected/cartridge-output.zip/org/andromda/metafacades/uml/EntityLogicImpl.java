package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.Entity.
 *
 * @see org.andromda.metafacades.uml.Entity
 */
public class EntityLogicImpl
    extends EntityLogic
{
    // ---------------- constructor -------------------------------

    public EntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getTableName()
     */
    protected java.lang.String handleGetTableName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#isIdentifiersPresent()
     */
    protected boolean handleIsIdentifiersPresent()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getMaxSqlNameLength()
     */
    protected java.lang.Short handleGetMaxSqlNameLength()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#isChild()
     */
    protected boolean handleIsChild()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#isUsingForeignIdentifier()
     */
    protected boolean handleIsUsingForeignIdentifier()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#isDynamicIdentifiersPresent()
     */
    protected boolean handleIsDynamicIdentifiersPresent()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getOperationCallFromAttributes(boolean)
     */
    protected java.lang.String handleGetOperationCallFromAttributes()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getIdentifiers(boolean)
     */
    protected java.util.Collection handleGetIdentifiers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getOperationCallFromAttributes(boolean, boolean)
     */
    protected java.lang.String handleGetOperationCallFromAttributes()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getRequiredAttributes(boolean, boolean)
     */
    protected java.util.Collection handleGetRequiredAttributes()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getRequiredProperties(boolean, boolean)
     */
    protected java.util.Collection handleGetRequiredProperties()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getAttributes(boolean, boolean)
     */
    protected java.util.Collection handleGetAttributes()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getAttributeTypeList(boolean, boolean)
     */
    protected java.lang.String handleGetAttributeTypeList()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getAttributeNameList(boolean, boolean)
     */
    protected java.lang.String handleGetAttributeNameList()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getRequiredAttributeTypeList(boolean, boolean)
     */
    protected java.lang.String handleGetRequiredAttributeTypeList()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getRequiredAttributeNameList(boolean, boolean)
     */
    protected java.lang.String handleGetRequiredAttributeNameList()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getQueryOperations(boolean)
     */
    protected java.util.Collection handleGetQueryOperations()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getEntityReferences()
     */
    protected java.util.Collection handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getParentEnd()
     */
    protected java.lang.Object handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getChildEnds()
     */
    protected java.util.Collection handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getQueryOperations()
     */
    protected java.util.Collection handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getBusinessOperations()
     */
    protected java.util.Collection handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Entity#getIdentifiers()
     */
    protected java.util.Collection handleGetEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

}