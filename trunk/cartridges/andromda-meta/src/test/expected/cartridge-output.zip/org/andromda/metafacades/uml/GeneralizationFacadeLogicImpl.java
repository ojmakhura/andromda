package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.GeneralizationFacade.
 *
 * @see org.andromda.metafacades.uml.GeneralizationFacade
 */
public class GeneralizationFacadeLogicImpl
    extends GeneralizationFacadeLogic
{
    // ---------------- constructor -------------------------------

    public GeneralizationFacadeLogicImpl (org.omg.uml.foundation.core.Generalization metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.GeneralizationFacade#getChild()
     */
    protected java.lang.Object handleGetChild()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.GeneralizationFacade#getParent()
     */
    protected java.lang.Object handleGetParent()
    {
        // TODO: add your implementation here!
        return null;
    }

}
