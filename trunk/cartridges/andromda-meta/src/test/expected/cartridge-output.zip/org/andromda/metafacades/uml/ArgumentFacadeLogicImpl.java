package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ArgumentFacade.
 *
 * @see org.andromda.metafacades.uml.ArgumentFacade
 */
public class ArgumentFacadeLogicImpl
    extends ArgumentFacadeLogic
{

    public ArgumentFacadeLogicImpl (org.omg.uml.behavioralelements.commonbehavior.Argument metaObject, String context)
    {
        super (metaObject, context);
    }
}