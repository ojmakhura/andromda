package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ModelFacade.
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public class ModelFacadeLogicImpl
       extends ModelFacadeLogic
       implements org.andromda.metafacades.uml.ModelFacade
{
    // ---------------- constructor -------------------------------

    public ModelFacadeLogicImpl (org.omg.uml.UmlPackage metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getUseCase(org.andromda.metafacades.uml.ActivityGraphFacade)
     */
    public org.andromda.metafacades.uml.UseCaseFacade handleGetUseCase(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getActivityGraph(org.andromda.metafacades.uml.UseCaseFacade)
     */
    public org.andromda.metafacades.uml.ActivityGraphFacade handleGetActivityGraph(org.andromda.metafacades.uml.UseCaseFacade useCase) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseWithTaggedValueOrHyperlink(java.lang.String, java.lang.String)
     */
    public org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findClassWithTaggedValueOrHyperlink(java.lang.String, java.lang.String)
     */
    public org.andromda.metafacades.uml.ClassifierFacade handleFindClassWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getActivityGraphContext(org.andromda.metafacades.uml.ModelElementFacade)
     */
    public org.andromda.metafacades.uml.ActivityGraphFacade handleGetActivityGraphContext(org.andromda.metafacades.uml.ModelElementFacade modelElement) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findActivityGraphByName(java.lang.String)
     */
    public org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByName(java.lang.String name) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findActivityGraphByNameAndStereotype(java.lang.String, java.lang.String)
     */
    public org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByNameAndStereotype(java.lang.String name, java.lang.String stereotypeName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseByName(java.lang.String)
     */
    public org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseByName(java.lang.String name) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findUseCaseWithNameAndStereotype(java.lang.String, java.lang.String)
     */
    public org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithNameAndStereotype(java.lang.String name, java.lang.String stereotypeName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getParameterTransition(org.andromda.metafacades.uml.ParameterFacade)
     */
    public org.andromda.metafacades.uml.TransitionFacade handleGetParameterTransition(org.andromda.metafacades.uml.ParameterFacade parameter) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getEventTransition(org.andromda.metafacades.uml.EventFacade)
     */
    public org.andromda.metafacades.uml.TransitionFacade handleGetEventTransition(org.andromda.metafacades.uml.EventFacade event) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getParameterOperation(org.andromda.metafacades.uml.ParameterFacade)
     */
    public org.andromda.metafacades.uml.OperationFacade handleGetParameterOperation(org.andromda.metafacades.uml.ParameterFacade parameter) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#findFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade)
     */
    public java.util.Collection handleFindFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade useCase) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade, java.lang.String)
     */
    public java.util.Collection handleGetAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph, java.lang.String stereotypeName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getRootPackage()
     */
    public java.lang.Object handleGetRootPackage()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActors()
     */
    public java.util.Collection handleGetAllActors()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllUseCases()
     */
    public java.util.Collection handleGetAllUseCases()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelFacade#getAllActionStates()
     */
    public java.util.Collection handleGetAllActionStates()
    {
        // TODO: add your implementation here!
        return null;
    }

}
