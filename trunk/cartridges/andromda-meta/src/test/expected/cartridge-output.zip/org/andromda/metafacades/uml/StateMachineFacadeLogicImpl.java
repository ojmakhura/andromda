package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.StateMachineFacade.
 *
 * @see org.andromda.metafacades.uml.StateMachineFacade
 */
public class StateMachineFacadeLogicImpl
    extends StateMachineFacadeLogic
{

    public StateMachineFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.StateMachine metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getContextElement()
     */
    protected java.lang.Object handleGetContextElement()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getFinalStates()
     */
    protected java.util.Collection handleGetFinalStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getInitialTransition()
     */
    protected java.lang.Object handleGetInitialTransition()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getTransitions()
     */
    protected java.util.Collection handleGetTransitions()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getInitialStates()
     */
    protected java.util.Collection handleGetInitialStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getInitialState()
     */
    protected java.lang.Object handleGetInitialState()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getPseudostates()
     */
    protected java.util.Collection handleGetPseudostates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.StateMachineFacade#getStates()
     */
    protected java.util.Collection handleGetStates()
    {
        // TODO: add your implementation here!
        return null;
    }

}