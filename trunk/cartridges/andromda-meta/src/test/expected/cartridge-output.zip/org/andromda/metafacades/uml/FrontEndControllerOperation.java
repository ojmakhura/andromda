//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents an operation modeled on a controller.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndControllerOperation
    extends org.andromda.metafacades.uml.OperationFacade
{

   /**
    * <p>
    *  The set of fields in the form made up form this controller
    *  operation's parameters.
    * </p>
    */
    public java.util.List getFormFields();

   /**
    * <p>
    *  Indicates if the owner of this operation is a controller.
    * </p>
    */
    public boolean isOwnerIsController();

}