//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AssociationEndFacade
 *
 * @see org.andromda.metafacades.uml.AssociationEndFacade
 */
public abstract class AssociationEndFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.AssociationEndFacade
{
    protected org.omg.uml.foundation.core.AssociationEnd metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public AssociationEndFacadeLogic (org.omg.uml.foundation.core.AssociationEnd metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.AssociationEndFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2One()
    */
    protected abstract boolean handleIsOne2One();

    private void handleIsOne2One1aPreCondition()
    {
    }

    private void handleIsOne2One1aPostCondition()
    {
    }

    public final boolean isOne2One()
    {
        handleIsOne2One1aPreCondition();
        boolean one2One1a = handleIsOne2One();
        handleIsOne2One1aPostCondition();
        return one2One1a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2Many()
    */
    protected abstract boolean handleIsOne2Many();

    private void handleIsOne2Many2aPreCondition()
    {
    }

    private void handleIsOne2Many2aPostCondition()
    {
    }

    public final boolean isOne2Many()
    {
        handleIsOne2Many2aPreCondition();
        boolean one2Many2a = handleIsOne2Many();
        handleIsOne2Many2aPostCondition();
        return one2Many2a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2One()
    */
    protected abstract boolean handleIsMany2One();

    private void handleIsMany2One3aPreCondition()
    {
    }

    private void handleIsMany2One3aPostCondition()
    {
    }

    public final boolean isMany2One()
    {
        handleIsMany2One3aPreCondition();
        boolean many2One3a = handleIsMany2One();
        handleIsMany2One3aPostCondition();
        return many2One3a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2Many()
    */
    protected abstract boolean handleIsMany2Many();

    private void handleIsMany2Many4aPreCondition()
    {
    }

    private void handleIsMany2Many4aPostCondition()
    {
    }

    public final boolean isMany2Many()
    {
        handleIsMany2Many4aPreCondition();
        boolean many2Many4a = handleIsMany2Many();
        handleIsMany2Many4aPostCondition();
        return many2Many4a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isAggregation()
    */
    protected abstract boolean handleIsAggregation();

    private void handleIsAggregation5aPreCondition()
    {
    }

    private void handleIsAggregation5aPostCondition()
    {
    }

    public final boolean isAggregation()
    {
        handleIsAggregation5aPreCondition();
        boolean aggregation5a = handleIsAggregation();
        handleIsAggregation5aPostCondition();
        return aggregation5a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isComposition()
    */
    protected abstract boolean handleIsComposition();

    private void handleIsComposition6aPreCondition()
    {
    }

    private void handleIsComposition6aPostCondition()
    {
    }

    public final boolean isComposition()
    {
        handleIsComposition6aPreCondition();
        boolean composition6a = handleIsComposition();
        handleIsComposition6aPostCondition();
        return composition6a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isOrdered()
    */
    protected abstract boolean handleIsOrdered();

    private void handleIsOrdered7aPreCondition()
    {
    }

    private void handleIsOrdered7aPostCondition()
    {
    }

    public final boolean isOrdered()
    {
        handleIsOrdered7aPreCondition();
        boolean ordered7a = handleIsOrdered();
        handleIsOrdered7aPostCondition();
        return ordered7a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isReadOnly()
    */
    protected abstract boolean handleIsReadOnly();

    private void handleIsReadOnly8aPreCondition()
    {
    }

    private void handleIsReadOnly8aPostCondition()
    {
    }

    public final boolean isReadOnly()
    {
        handleIsReadOnly8aPreCondition();
        boolean readOnly8a = handleIsReadOnly();
        handleIsReadOnly8aPostCondition();
        return readOnly8a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isNavigable()
    */
    protected abstract boolean handleIsNavigable();

    private void handleIsNavigable9aPreCondition()
    {
    }

    private void handleIsNavigable9aPostCondition()
    {
    }

    public final boolean isNavigable()
    {
        handleIsNavigable9aPreCondition();
        boolean navigable9a = handleIsNavigable();
        handleIsNavigable9aPostCondition();
        return navigable9a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterName()
    */
    protected abstract java.lang.String handleGetGetterName();

    private void handleGetGetterName10aPreCondition()
    {
    }

    private void handleGetGetterName10aPostCondition()
    {
    }

    public final java.lang.String getGetterName()
    {
        handleGetGetterName10aPreCondition();
        java.lang.String getterName10a = handleGetGetterName();
        handleGetGetterName10aPostCondition();
        return getterName10a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#getSetterName()
    */
    protected abstract java.lang.String handleGetSetterName();

    private void handleGetSetterName11aPreCondition()
    {
    }

    private void handleGetSetterName11aPostCondition()
    {
    }

    public final java.lang.String getSetterName()
    {
        handleGetSetterName11aPreCondition();
        java.lang.String setterName11a = handleGetSetterName();
        handleGetSetterName11aPostCondition();
        return setterName11a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterSetterTypeName()
    */
    protected abstract java.lang.String handleGetGetterSetterTypeName();

    private void handleGetGetterSetterTypeName12aPreCondition()
    {
    }

    private void handleGetGetterSetterTypeName12aPostCondition()
    {
    }

    public final java.lang.String getGetterSetterTypeName()
    {
        handleGetGetterSetterTypeName12aPreCondition();
        java.lang.String getterSetterTypeName12a = handleGetGetterSetterTypeName();
        handleGetGetterSetterTypeName12aPostCondition();
        return getterSetterTypeName12a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isMany()
    */
    protected abstract boolean handleIsMany();

    private void handleIsMany13aPreCondition()
    {
    }

    private void handleIsMany13aPostCondition()
    {
    }

    public final boolean isMany()
    {
        handleIsMany13aPreCondition();
        boolean many13a = handleIsMany();
        handleIsMany13aPostCondition();
        return many13a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isRequired()
    */
    protected abstract boolean handleIsRequired();

    private void handleIsRequired14aPreCondition()
    {
    }

    private void handleIsRequired14aPostCondition()
    {
    }

    public final boolean isRequired()
    {
        handleIsRequired14aPreCondition();
        boolean required14a = handleIsRequired();
        handleIsRequired14aPostCondition();
        return required14a;
    }

   /**
	* @see org.andromda.metafacades.uml.AssociationEndFacade#isChild()
    */
    protected abstract boolean handleIsChild();

    private void handleIsChild15aPreCondition()
    {
    }

    private void handleIsChild15aPostCondition()
    {
    }

    public final boolean isChild()
    {
        handleIsChild15aPreCondition();
        boolean child15a = handleIsChild();
        handleIsChild15aPostCondition();
        return child15a;
    }

    // ------------- associations ------------------

    private void handleGetOtherEnd1rPreCondition()
    {
    }

    private void handleGetOtherEnd1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd()
    {
        handleGetOtherEnd1rPreCondition();
        org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd1r = (org.andromda.metafacades.uml.AssociationEndFacade)shieldedElement(handleGetOtherEnd());
        handleGetOtherEnd1rPostCondition();
        return getOtherEnd1r;
    }

    protected abstract java.lang.Object handleGetOtherEnd();

    private void handleGetAssociation4rPreCondition()
    {
    }

    private void handleGetAssociation4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.AssociationFacade getAssociation()
    {
        handleGetAssociation4rPreCondition();
        org.andromda.metafacades.uml.AssociationFacade getAssociation4r = (org.andromda.metafacades.uml.AssociationFacade)shieldedElement(handleGetAssociation());
        handleGetAssociation4rPostCondition();
        return getAssociation4r;
    }

    protected abstract java.lang.Object handleGetAssociation();

    private void handleGetType5rPreCondition()
    {
    }

    private void handleGetType5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        handleGetType5rPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade getType5r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetType());
        handleGetType5rPostCondition();
        return getType5r;
    }

    protected abstract java.lang.Object handleGetType();

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"type")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.getClass(),
                        this.getName(),
                        "Each association end needs a type, you cannot leave the type unspecified."));
        }
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        String name = this.getFullyQualifiedName(true);
        toString.append("[");
        toString.append(name);
        toString.append("]");
        return toString.toString();
    }      
}
