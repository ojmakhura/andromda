//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ModelFacade
{
    /**
     * Provides any required initialization of the metafacade.
     */
    void initialize();
    
    /**
     * Performs validation of any invariants found on this model element 
     * and stores the messages within the <code>validationMessages</code>
     * collection.
     *
     * @param validationMessages the collection of messages to which additional
     *        validation messages will be added if invariants are broken.
     */
    void validateInvariants(java.util.Collection validationMessages);

   /**
    * 
    */
    public java.util.Collection getAllActionStates();

   /**
    * 
    */
    public java.util.Collection getAllActivityGraphs();

   /**
    * 
    */
    public java.util.Collection getAllActors();

   /**
    * 
    */
    public java.util.Collection getAllFinalStates();

   /**
    * <p>
    *  All operations found in the model.
    * </p>
    */
    public java.util.Collection getAllOperations();

   /**
    * 
    */
    public java.util.Collection getAllTransitions();

   /**
    * 
    */
    public java.util.Collection getAllUseCases();

   /**
    * 
    */
    public org.andromda.metafacades.uml.PackageFacade getRootPackage();

}
