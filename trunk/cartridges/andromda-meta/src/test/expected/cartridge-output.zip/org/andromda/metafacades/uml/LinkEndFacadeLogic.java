//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.LinkEndFacade
 *
 * @see org.andromda.metafacades.uml.LinkEndFacade
 */
public abstract class LinkEndFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.LinkEndFacade
{

    protected org.omg.uml.behavioralelements.commonbehavior.LinkEnd metaObject;

    public LinkEndFacadeLogic(org.omg.uml.behavioralelements.commonbehavior.LinkEnd metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.LinkEndFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetInstance1rPreCondition()
    {
    }

    private void handleGetInstance1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.InstanceFacade __getInstance1r;
    private boolean __getInstance1rSet = false;

    public final org.andromda.metafacades.uml.InstanceFacade getInstance()
    {
        org.andromda.metafacades.uml.InstanceFacade getInstance1r = this.__getInstance1r;
        if (!this.__getInstance1rSet)
        {
            handleGetInstance1rPreCondition();
            Object result = this.shieldedElement(handleGetInstance());
            try
            {
                getInstance1r = (org.andromda.metafacades.uml.InstanceFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInstance1rPostCondition();
            this.__getInstance1r = getInstance1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInstance1rSet = true;
            }
        }
        return getInstance1r;
    }

    protected abstract java.lang.Object handleGetInstance();

    private void handleGetAssociationEnd2rPreCondition()
    {
    }

    private void handleGetAssociationEnd2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.AssociationEndFacade __getAssociationEnd2r;
    private boolean __getAssociationEnd2rSet = false;

    public final org.andromda.metafacades.uml.AssociationEndFacade getAssociationEnd()
    {
        org.andromda.metafacades.uml.AssociationEndFacade getAssociationEnd2r = this.__getAssociationEnd2r;
        if (!this.__getAssociationEnd2rSet)
        {
            handleGetAssociationEnd2rPreCondition();
            Object result = this.shieldedElement(handleGetAssociationEnd());
            try
            {
                getAssociationEnd2r = (org.andromda.metafacades.uml.AssociationEndFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAssociationEnd2rPostCondition();
            this.__getAssociationEnd2r = getAssociationEnd2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAssociationEnd2rSet = true;
            }
        }
        return getAssociationEnd2r;
    }

    protected abstract java.lang.Object handleGetAssociationEnd();

    private void handleGetLink3rPreCondition()
    {
    }

    private void handleGetLink3rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.LinkFacade __getLink3r;
    private boolean __getLink3rSet = false;

    public final org.andromda.metafacades.uml.LinkFacade getLink()
    {
        org.andromda.metafacades.uml.LinkFacade getLink3r = this.__getLink3r;
        if (!this.__getLink3rSet)
        {
            handleGetLink3rPreCondition();
            Object result = this.shieldedElement(handleGetLink());
            try
            {
                getLink3r = (org.andromda.metafacades.uml.LinkFacade)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetLink3rPostCondition();
            this.__getLink3r = getLink3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getLink3rSet = true;
            }
        }
        return getLink3r;
    }

    protected abstract java.lang.Object handleGetLink();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}