//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface GeneralizableElementFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * <p>
    *  All generalizations for this generalizable element, goes up the
    *  inheritance tree.
    * </p>
    */
    public java.util.Collection getAllGeneralizations();

   /**
    * <p>
    *  Gets the direct generalization for this generalizable element.
    * </p>
    */
    public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization();

   /**
    * 
    */
    public java.util.Collection getGeneralizations();

   /**
    * <p>
    *  Gets the direct specializations (i.e. sub elements) for this
    *  generalizatble element.
    * </p>
    */
    public java.util.Collection getSpecializations();

}
