package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.FrontEndPackage.
 *
 * @see org.andromda.metafacades.uml.FrontEndPackage
 */
public class FrontEndPackageLogicImpl
    extends FrontEndPackageLogic
{

    public FrontEndPackageLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.FrontEndPackage#getFrontEndControllers()
     */
    protected java.util.List handleGetFrontEndControllers()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndPackage#getFrontEndUseCases()
     */
    protected java.util.List handleGetFrontEndUseCases()
    {
        // TODO: add your implementation here!
        return null;
    }

}