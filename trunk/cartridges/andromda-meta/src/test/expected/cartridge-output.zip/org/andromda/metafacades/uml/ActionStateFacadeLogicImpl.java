package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActionStateFacade.
 *
 * @see org.andromda.metafacades.uml.ActionStateFacade
 */
public class ActionStateFacadeLogicImpl
       extends ActionStateFacadeLogic
       implements org.andromda.metafacades.uml.ActionStateFacade
{
    // ---------------- constructor -------------------------------

    public ActionStateFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ActionState metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActionStateFacade#getEntry()
     */
    public java.lang.Object handleGetEntry()
    {
        // TODO: add your implementation here!
        return null;
    }

}
