package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActionStateFacade.
 *
 * @see org.andromda.metafacades.uml.ActionStateFacade
 */
public class ActionStateFacadeLogicImpl
    extends ActionStateFacadeLogic
{

    public ActionStateFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ActionState metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActionStateFacade#getEntry()
     */
    protected java.lang.Object handleGetActionState()
    {
        // TODO: add your implementation here!
        return null;
    }

}