package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.AssociationClassFacade.
 *
 * @see org.andromda.metafacades.uml.AssociationClassFacade
 */
public class AssociationClassFacadeLogicImpl
    extends AssociationClassFacadeLogic
{

    public AssociationClassFacadeLogicImpl (org.omg.uml.foundation.core.AssociationClass metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationClassFacade#getConnectionAssociationEnds()
     */
    protected java.util.Collection handleGetAssociationClassFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

}