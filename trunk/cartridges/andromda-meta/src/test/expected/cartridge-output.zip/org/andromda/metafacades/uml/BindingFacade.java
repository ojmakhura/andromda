//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 * Represents a UML binding.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface BindingFacade
    extends org.andromda.metafacades.uml.DependencyFacade
{

   /**
    * 
    */
    public java.util.Collection getArguments();

}