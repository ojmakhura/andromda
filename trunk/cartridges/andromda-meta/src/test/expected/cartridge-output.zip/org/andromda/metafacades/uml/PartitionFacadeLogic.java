//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.PartitionFacade
 *
 * @see org.andromda.metafacades.uml.PartitionFacade
 */
public abstract class PartitionFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.PartitionFacade
{

    protected org.omg.uml.behavioralelements.activitygraphs.Partition metaObject;

    public PartitionFacadeLogic(org.omg.uml.behavioralelements.activitygraphs.Partition metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.PartitionFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetActivityGraph1rPreCondition()
    {
    }

    private void handleGetActivityGraph1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph1r = null;
        handleGetActivityGraph1rPreCondition();
        Object result = this.shieldedElement(handleGetActivityGraph());
        try
        {
            getActivityGraph1r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActivityGraph1rPostCondition();
        return getActivityGraph1r;
    }

    protected abstract java.lang.Object handleGetActivityGraph();

    private void handleGetVertices2rPreCondition()
    {
    }

    private void handleGetVertices2rPostCondition()
    {
    }

    private java.util.Collection __getVertices2r;
    private boolean __getVertices2rSet = false;

    public final java.util.Collection getVertices()
    {
        java.util.Collection getVertices2r = this.__getVertices2r;
        if (!this.__getVertices2rSet)
        {
            handleGetVertices2rPreCondition();
            Object result = this.shieldedElements(handleGetVertices());
            try
            {
                getVertices2r = (java.util.Collection)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetVertices2rPostCondition();
            this.__getVertices2r = getVertices2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getVertices2rSet = true;
            }
        }
        return getVertices2r;
    }

    protected abstract java.util.Collection handleGetVertices();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}