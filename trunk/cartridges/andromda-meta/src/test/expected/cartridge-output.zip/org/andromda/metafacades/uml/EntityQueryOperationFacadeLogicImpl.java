package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityQueryOperationFacade.
 *
 * @see org.andromda.metafacades.uml.EntityQueryOperationFacade
 */
public class EntityQueryOperationFacadeLogicImpl
       extends EntityQueryOperationFacadeLogic
       implements org.andromda.metafacades.uml.EntityQueryOperationFacade
{
    // ---------------- constructor -------------------------------

    public EntityQueryOperationFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.EntityQueryOperationFacade#getQuery(java.lang.String)
     */
    protected java.lang.String handleGetQuery(java.lang.String translation)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

}
