package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.Service.
 *
 * @see org.andromda.metafacades.uml.Service
 */
public class ServiceLogicImpl
    extends ServiceLogic
{
    // ---------------- constructor -------------------------------

    public ServiceLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.Service#getServiceReferences()
     */
    protected java.util.Collection handleGetServiceReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Service#getEntityReferences()
     */
    protected java.util.Collection handleGetEntityReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Service#getRoles()
     */
    protected java.util.Collection handleGetRoles()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.Service#getAllRoles()
     */
    protected java.util.Collection handleGetAllRoles()
    {
        // TODO: add your implementation here!
        return null;
    }

}
