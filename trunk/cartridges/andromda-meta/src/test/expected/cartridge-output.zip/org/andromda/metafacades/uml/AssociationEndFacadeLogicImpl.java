package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.AssociationEndFacade.
 *
 * @see org.andromda.metafacades.uml.AssociationEndFacade
 */
public class AssociationEndFacadeLogicImpl
       extends AssociationEndFacadeLogic
       implements org.andromda.metafacades.uml.AssociationEndFacade
{
    // ---------------- constructor -------------------------------

    public AssociationEndFacadeLogicImpl (org.omg.uml.foundation.core.AssociationEnd metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2One()
     */
    public boolean handleIsOne2One() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isOne2Many()
     */
    public boolean handleIsOne2Many() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2One()
     */
    public boolean handleIsMany2One() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany2Many()
     */
    public boolean handleIsMany2Many() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isAggregation()
     */
    public boolean handleIsAggregation() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isComposition()
     */
    public boolean handleIsComposition() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isOrdered()
     */
    public boolean handleIsOrdered() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isReadOnly()
     */
    public boolean handleIsReadOnly() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isNavigable()
     */
    public boolean handleIsNavigable() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterName()
     */
    public java.lang.String handleGetGetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getSetterName()
     */
    public java.lang.String handleGetSetterName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getGetterSetterTypeName()
     */
    public java.lang.String handleGetGetterSetterTypeName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isMany()
     */
    public boolean handleIsMany() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#isRequired()
     */
    public boolean handleIsRequired() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getOtherEnd()
     */
    public java.lang.Object handleGetOtherEnd()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getAssociation()
     */
    public java.lang.Object handleGetAssociation()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.AssociationEndFacade#getType()
     */
    public java.lang.Object handleGetType()
    {
        // TODO: add your implementation here!
        return null;
    }

}
