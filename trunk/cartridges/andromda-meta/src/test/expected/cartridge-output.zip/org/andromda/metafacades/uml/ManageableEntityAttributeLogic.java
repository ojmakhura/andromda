//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAttribute
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public abstract class ManageableEntityAttributeLogic
    extends org.andromda.metafacades.uml.EntityAttributeLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAttribute
{

    protected Object metaObject;

    public ManageableEntityAttributeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAttribute";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudGetterName()
    */
    protected abstract java.lang.String handleGetCrudGetterName();

    private void handleGetCrudGetterName1aPreCondition()
    {
    }

    private void handleGetCrudGetterName1aPostCondition()
    {
    }

    private java.lang.String __crudGetterName1a;
    private boolean __crudGetterName1aSet = false;

    public final java.lang.String getCrudGetterName()
    {
        java.lang.String crudGetterName1a = this.__crudGetterName1a;
        if (!this.__crudGetterName1aSet)
        {
            handleGetCrudGetterName1aPreCondition();
            crudGetterName1a = handleGetCrudGetterName();
            handleGetCrudGetterName1aPostCondition();
            this.__crudGetterName1a = crudGetterName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudGetterName1aSet = true;
            }
        }
        return crudGetterName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudName()
    */
    protected abstract java.lang.String handleGetCrudName();

    private void handleGetCrudName2aPreCondition()
    {
    }

    private void handleGetCrudName2aPostCondition()
    {
    }

    private java.lang.String __crudName2a;
    private boolean __crudName2aSet = false;

    public final java.lang.String getCrudName()
    {
        java.lang.String crudName2a = this.__crudName2a;
        if (!this.__crudName2aSet)
        {
            handleGetCrudName2aPreCondition();
            crudName2a = handleGetCrudName();
            handleGetCrudName2aPostCondition();
            this.__crudName2a = crudName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudName2aSet = true;
            }
        }
        return crudName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#getCrudSetterName()
    */
    protected abstract java.lang.String handleGetCrudSetterName();

    private void handleGetCrudSetterName3aPreCondition()
    {
    }

    private void handleGetCrudSetterName3aPostCondition()
    {
    }

    private java.lang.String __crudSetterName3a;
    private boolean __crudSetterName3aSet = false;

    public final java.lang.String getCrudSetterName()
    {
        java.lang.String crudSetterName3a = this.__crudSetterName3a;
        if (!this.__crudSetterName3aSet)
        {
            handleGetCrudSetterName3aPreCondition();
            crudSetterName3a = handleGetCrudSetterName();
            handleGetCrudSetterName3aPostCondition();
            this.__crudSetterName3a = crudSetterName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudSetterName3aSet = true;
            }
        }
        return crudSetterName3a;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}