//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.GeneralizationFacade
 *
 * @see org.andromda.metafacades.uml.GeneralizationFacade
 */
public abstract class GeneralizationFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.GeneralizationFacade
{

    protected org.omg.uml.foundation.core.Generalization metaObject;

    public GeneralizationFacadeLogic(org.omg.uml.foundation.core.Generalization metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizationFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetChild1rPreCondition()
    {
    }

    private void handleGetChild1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GeneralizableElementFacade getChild()
    {
        org.andromda.metafacades.uml.GeneralizableElementFacade getChild1r = null;
        handleGetChild1rPreCondition();
        Object result = this.shieldedElement(handleGetChild());
        try
        {
            getChild1r = (org.andromda.metafacades.uml.GeneralizableElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetChild1rPostCondition();
        return getChild1r;
    }

    protected abstract java.lang.Object handleGetChild();

    private void handleGetParent2rPreCondition()
    {
    }

    private void handleGetParent2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GeneralizableElementFacade getParent()
    {
        org.andromda.metafacades.uml.GeneralizableElementFacade getParent2r = null;
        handleGetParent2rPreCondition();
        Object result = this.shieldedElement(handleGetParent());
        try
        {
            getParent2r = (org.andromda.metafacades.uml.GeneralizableElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetParent2rPostCondition();
        return getParent2r;
    }

    protected abstract java.lang.Object handleGetParent();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}