//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ClassifierFacade
 *
 * @see org.andromda.metafacades.uml.ClassifierFacade
 */
public abstract class ClassifierFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ClassifierFacade
{
    protected org.omg.uml.foundation.core.Classifier metaObject;
    private org.andromda.metafacades.uml.GeneralizableElementFacade super_;

    public ClassifierFacadeLogic (org.omg.uml.foundation.core.Classifier metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.GeneralizableElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.GeneralizableElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ClassifierFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    public abstract boolean handleIsPrimitiveType();

    private void handleIsPrimitiveType1oPreCondition()
    {
    }

    private void handleIsPrimitiveType1oPostCondition()
    {
    }

    public final boolean isPrimitiveType()
    {
        handleIsPrimitiveType1oPreCondition();
        boolean returnValue = handleIsPrimitiveType();
        handleIsPrimitiveType1oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetOperationCallFromAttributes();

    private void handleGetOperationCallFromAttributes2oPreCondition()
    {
    }

    private void handleGetOperationCallFromAttributes2oPostCondition()
    {
    }

    public final java.lang.String getOperationCallFromAttributes()
    {
        handleGetOperationCallFromAttributes2oPreCondition();
        java.lang.String returnValue = handleGetOperationCallFromAttributes();
        handleGetOperationCallFromAttributes2oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetInstanceAttributes();

    private void handleGetInstanceAttributes3oPreCondition()
    {
    }

    private void handleGetInstanceAttributes3oPostCondition()
    {
    }

    public final java.util.Collection getInstanceAttributes()
    {
        handleGetInstanceAttributes3oPreCondition();
        java.util.Collection returnValue = handleGetInstanceAttributes();
        handleGetInstanceAttributes3oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetStaticAttributes();

    private void handleGetStaticAttributes4oPreCondition()
    {
    }

    private void handleGetStaticAttributes4oPostCondition()
    {
    }

    public final java.util.Collection getStaticAttributes()
    {
        handleGetStaticAttributes4oPreCondition();
        java.util.Collection returnValue = handleGetStaticAttributes();
        handleGetStaticAttributes4oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetAbstractions();

    private void handleGetAbstractions5oPreCondition()
    {
    }

    private void handleGetAbstractions5oPostCondition()
    {
    }

    public final java.util.Collection getAbstractions()
    {
        handleGetAbstractions5oPreCondition();
        java.util.Collection returnValue = handleGetAbstractions();
        handleGetAbstractions5oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsAbstract();

    private void handleIsAbstract6oPreCondition()
    {
    }

    private void handleIsAbstract6oPostCondition()
    {
    }

    public final boolean isAbstract()
    {
        handleIsAbstract6oPreCondition();
        boolean returnValue = handleIsAbstract();
        handleIsAbstract6oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetAttributes(boolean follow);

    private void handleGetAttributes7oPreCondition()
    {
    }

    private void handleGetAttributes7oPostCondition()
    {
    }

    public final java.util.Collection getAttributes(boolean follow)
    {
        handleGetAttributes7oPreCondition();
        java.util.Collection returnValue = handleGetAttributes(follow);
        handleGetAttributes7oPostCondition();
        return returnValue;
    }

    public abstract java.util.Collection handleGetProperties();

    private void handleGetProperties8oPreCondition()
    {
    }

    private void handleGetProperties8oPostCondition()
    {
    }

    public final java.util.Collection getProperties()
    {
        handleGetProperties8oPreCondition();
        java.util.Collection returnValue = handleGetProperties();
        handleGetProperties8oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsDatatype();

    private void handleIsDatatype9oPreCondition()
    {
    }

    private void handleIsDatatype9oPostCondition()
    {
    }

    public final boolean isDatatype()
    {
        handleIsDatatype9oPreCondition();
        boolean returnValue = handleIsDatatype();
        handleIsDatatype9oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsArrayType();

    private void handleIsArrayType10oPreCondition()
    {
    }

    private void handleIsArrayType10oPostCondition()
    {
    }

    public final boolean isArrayType()
    {
        handleIsArrayType10oPreCondition();
        boolean returnValue = handleIsArrayType();
        handleIsArrayType10oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsCollectionType();

    private void handleIsCollectionType11oPreCondition()
    {
    }

    private void handleIsCollectionType11oPostCondition()
    {
    }

    public final boolean isCollectionType()
    {
        handleIsCollectionType11oPreCondition();
        boolean returnValue = handleIsCollectionType();
        handleIsCollectionType11oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsEnumeration();

    private void handleIsEnumeration12oPreCondition()
    {
    }

    private void handleIsEnumeration12oPostCondition()
    {
    }

    public final boolean isEnumeration()
    {
        handleIsEnumeration12oPreCondition();
        boolean returnValue = handleIsEnumeration();
        handleIsEnumeration12oPostCondition();
        return returnValue;
    }

    public abstract java.lang.String handleGetWrapperName();

    private void handleGetWrapperName13oPreCondition()
    {
    }

    private void handleGetWrapperName13oPostCondition()
    {
    }

    public final java.lang.String getWrapperName()
    {
        handleGetWrapperName13oPreCondition();
        java.lang.String returnValue = handleGetWrapperName();
        handleGetWrapperName13oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsDateType();

    private void handleIsDateType14oPreCondition()
    {
    }

    private void handleIsDateType14oPostCondition()
    {
    }

    public final boolean isDateType()
    {
        handleIsDateType14oPreCondition();
        boolean returnValue = handleIsDateType();
        handleIsDateType14oPostCondition();
        return returnValue;
    }

    public abstract boolean handleIsInterface();

    private void handleIsInterface15oPreCondition()
    {
    }

    private void handleIsInterface15oPostCondition()
    {
    }

    public final boolean isInterface()
    {
        handleIsInterface15oPreCondition();
        boolean returnValue = handleIsInterface();
        handleIsInterface15oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private java.util.Collection getOperations1r;

    private void handleGetOperations1rPreCondition()
    {
    }

    private void handleGetOperations1rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetOperations();

    public final java.util.Collection getOperations()
    {
        handleGetOperations1rPreCondition();
        getOperations1r = shieldedElements(handleGetOperations());
        handleGetOperations1rPostCondition();
        return getOperations1r;
    }

    private java.util.Collection getAttributes2r;

    private void handleGetAttributes2rPreCondition()
    {
    }

    private void handleGetAttributes2rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetAttributes();

    public final java.util.Collection getAttributes()
    {
        handleGetAttributes2rPreCondition();
        getAttributes2r = shieldedElements(handleGetAttributes());
        handleGetAttributes2rPostCondition();
        return getAttributes2r;
    }

    private java.util.Collection getAssociationEnds3r;

    private void handleGetAssociationEnds3rPreCondition()
    {
    }

    private void handleGetAssociationEnds3rPostCondition()
    {
    }

    protected abstract java.util.Collection handleGetAssociationEnds();

    public final java.util.Collection getAssociationEnds()
    {
        handleGetAssociationEnds3rPreCondition();
        getAssociationEnds3r = shieldedElements(handleGetAssociationEnds());
        handleGetAssociationEnds3rPostCondition();
        return getAssociationEnds3r;
    }

    private org.andromda.metafacades.uml.ClassifierFacade getNonArray5r;

    private void handleGetNonArray5rPreCondition()
    {
    }

    private void handleGetNonArray5rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetNonArray();

    public final org.andromda.metafacades.uml.ClassifierFacade getNonArray()
    {
        handleGetNonArray5rPreCondition();
        getNonArray5r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetNonArray());
        handleGetNonArray5rPostCondition();
        return getNonArray5r;
    }

    private org.andromda.metafacades.uml.ClassifierFacade getArray6r;

    private void handleGetArray6rPreCondition()
    {
    }

    private void handleGetArray6rPostCondition()
    {
    }

    protected abstract java.lang.Object handleGetArray();

    public final org.andromda.metafacades.uml.ClassifierFacade getArray()
    {
        handleGetArray6rPreCondition();
        getArray6r = (org.andromda.metafacades.uml.ClassifierFacade)shieldedElement(handleGetArray());
        handleGetArray6rPostCondition();
        return getArray6r;
    }

    // ----------- delegates to org.andromda.metafacades.uml.GeneralizableElementFacade ------------
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getAllGeneralizations()
	{
        return super_.getAllGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
	{
        return super_.getGeneralization();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getGeneralizations()
	{
        return super_.getGeneralizations();
	}
	
    // from org.andromda.metafacades.uml.GeneralizableElementFacade
	public java.util.Collection getSpecializations()
	{
        return super_.getSpecializations();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.validation.OCLResultEnsurer.ensure(org.andromda.translation.validation.OCLCollections.notEmpty(org.andromda.translation.validation.OCLIntrospector.invoke(contextElement,"name")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.getClass(),
                        this.getName(),
                        "Each classifier must have a non-empty name."));
        }
    }
}
