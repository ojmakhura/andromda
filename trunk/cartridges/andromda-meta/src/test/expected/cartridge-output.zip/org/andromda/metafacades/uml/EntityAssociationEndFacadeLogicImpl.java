package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityAssociationEndFacade.
 *
 * @see org.andromda.metafacades.uml.EntityAssociationEndFacade
 */
public class EntityAssociationEndFacadeLogicImpl
       extends EntityAssociationEndFacadeLogic
       implements org.andromda.metafacades.uml.EntityAssociationEndFacade
{
    // ---------------- constructor -------------------------------

    public EntityAssociationEndFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getColumnName()
     */
    protected java.lang.String handleGetColumnName()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#getForeignKeySuffix()
     */
    protected java.lang.String handleGetForeignKeySuffix()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAssociationEndFacade#isForeignIdentifier()
     */
    protected boolean handleIsForeignIdentifier()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

}
