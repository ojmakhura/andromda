package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityFacade.
 *
 * @see org.andromda.metafacades.uml.EntityFacade
 */
public class EntityFacadeLogicImpl
       extends EntityFacadeLogic
       implements org.andromda.metafacades.uml.EntityFacade
{
    // ---------------- constructor -------------------------------

    public EntityFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getIdentifiers()
     */
    protected java.util.Collection handleGetIdentifiers() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getTableName()
     */
    protected java.lang.String handleGetTableName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#isIdentifiersPresent()
     */
    protected boolean handleIsIdentifiersPresent() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getMaxSqlNameLength()
     */
    protected java.lang.Short handleGetMaxSqlNameLength() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#isChild()
     */
    protected boolean handleIsChild() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#isUsingForeignIdentifier()
     */
    protected boolean handleIsUsingForeignIdentifier() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getOperationCallFromAttributes(boolean)
     */
    protected java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getIdentifiers(boolean)
     */
    protected java.util.Collection handleGetIdentifiers(boolean follow)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getOperationCallFromAttributes(boolean, boolean)
     */
    protected java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers, boolean follow)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributes(boolean, boolean)
     */
    protected java.util.Collection handleGetRequiredAttributes(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredProperties(boolean, boolean)
     */
    protected java.util.Collection handleGetRequiredProperties(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributes(boolean, boolean)
     */
    protected java.util.Collection handleGetAttributes(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributeTypeList(boolean, boolean)
     */
    protected java.lang.String handleGetAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributeNameList(boolean, boolean)
     */
    protected java.lang.String handleGetAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributeTypeList(boolean, boolean)
     */
    protected java.lang.String handleGetRequiredAttributeTypeList(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributeNameList(boolean, boolean)
     */
    protected java.lang.String handleGetRequiredAttributeNameList(boolean follow, boolean withIdentifiers)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getQueryOperations(boolean)
     */
    protected java.util.Collection handleGetQueryOperations(boolean follow)
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getEntityReferences()
     */
    protected java.util.Collection handleGetEntityReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getParentEnd()
     */
    protected java.lang.Object handleGetParentEnd()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getChildEnds()
     */
    protected java.util.Collection handleGetChildEnds()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getQueryOperations()
     */
    protected java.util.Collection handleGetQueryOperations()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getBusinessOperations()
     */
    protected java.util.Collection handleGetBusinessOperations()
    {
        // TODO: add your implementation here!
        return null;
    }

}
