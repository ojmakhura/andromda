package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityFacade.
 *
 * @see org.andromda.metafacades.uml.EntityFacade
 */
public class EntityFacadeLogicImpl
       extends EntityFacadeLogic
       implements org.andromda.metafacades.uml.EntityFacade
{
    // ---------------- constructor -------------------------------

    public EntityFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getBusinessOperations()
     */
    public java.util.Collection handleGetBusinessOperations() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getFinders()
     */
    public java.util.Collection handleGetFinders() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getIdentifiers()
     */
    public java.util.Collection handleGetIdentifiers() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getTableName()
     */
    public java.lang.String handleGetTableName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#isIdentifiersPresent()
     */
    public boolean handleIsIdentifiersPresent() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#isChild()
     */
    public boolean handleIsChild() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getMaxSqlNameLength()
     */
    public java.lang.Short handleGetMaxSqlNameLength() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getOperationCallFromAttributes(boolean)
     */
    public java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getIdentifiers(boolean)
     */
    public java.util.Collection handleGetIdentifiers(boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getOperationCallFromAttributes(boolean, boolean)
     */
    public java.lang.String handleGetOperationCallFromAttributes(boolean withIdentifiers, boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributes(boolean, boolean)
     */
    public java.util.Collection handleGetRequiredAttributes(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredProperties(boolean, boolean)
     */
    public java.util.Collection handleGetRequiredProperties(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributes(boolean, boolean)
     */
    public java.util.Collection handleGetAttributes(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributeTypeList(boolean, boolean)
     */
    public java.lang.String handleGetAttributeTypeList(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getAttributeNameList(boolean, boolean)
     */
    public java.lang.String handleGetAttributeNameList(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributeTypeList(boolean, boolean)
     */
    public java.lang.String handleGetRequiredAttributeTypeList(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getRequiredAttributeNameList(boolean, boolean)
     */
    public java.lang.String handleGetRequiredAttributeNameList(boolean follow, boolean withIdentifiers) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getFinders(boolean)
     */
    public java.util.Collection handleGetFinders(boolean follow) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getParent()
     */
    public java.lang.Object handleGetParent()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getChildren()
     */
    public java.util.Collection handleGetChildren()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityFacade#getEntityReferences()
     */
    public java.util.Collection handleGetEntityReferences()
    {
        // TODO: add your implementation here!
        return null;
    }

}
