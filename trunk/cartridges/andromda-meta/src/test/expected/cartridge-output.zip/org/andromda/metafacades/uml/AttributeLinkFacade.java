//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AttributeLinkFacade
    extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.AttributeFacade getAttribute();

   /**
    * 
    */
    public org.andromda.metafacades.uml.InstanceFacade getInstance();

   /**
    * 
    */
    public org.andromda.metafacades.uml.LinkEndFacade getLinkEnd();

   /**
    * 
    */
    public org.andromda.metafacades.uml.InstanceFacade getValue();

}