//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.GeneralizableElementFacade
 *
 * @see org.andromda.metafacades.uml.GeneralizableElementFacade
 */
public abstract class GeneralizableElementFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.GeneralizableElementFacade
{

    protected org.omg.uml.foundation.core.GeneralizableElement metaObject;

    public GeneralizableElementFacadeLogic(org.omg.uml.foundation.core.GeneralizableElement metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.GeneralizableElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.GeneralizableElementFacade#getGeneralizationList()
    */
    protected abstract java.lang.String handleGetGeneralizationList();

    private void handleGetGeneralizationList1aPreCondition()
    {
    }

    private void handleGetGeneralizationList1aPostCondition()
    {
    }

    private java.lang.String __generalizationList1a;
    private boolean __generalizationList1aSet = false;

    public final java.lang.String getGeneralizationList()
    {
        java.lang.String generalizationList1a = this.__generalizationList1a;
        if (!this.__generalizationList1aSet)
        {
            handleGetGeneralizationList1aPreCondition();
            generalizationList1a = handleGetGeneralizationList();
            handleGetGeneralizationList1aPostCondition();
            this.__generalizationList1a = generalizationList1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__generalizationList1aSet = true;
            }
        }
        return generalizationList1a;
    }

    // ------------- associations ------------------

    private void handleGetGeneralization1rPreCondition()
    {
    }

    private void handleGetGeneralization1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization()
    {
        org.andromda.metafacades.uml.GeneralizableElementFacade getGeneralization1r = null;
        handleGetGeneralization1rPreCondition();
        Object result = this.shieldedElement(handleGetGeneralization());
        try
        {
            getGeneralization1r = (org.andromda.metafacades.uml.GeneralizableElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralization1rPostCondition();
        return getGeneralization1r;
    }

    protected abstract java.lang.Object handleGetGeneralization();

    private void handleGetSpecializations6rPreCondition()
    {
    }

    private void handleGetSpecializations6rPostCondition()
    {
    }

    public final java.util.Collection getSpecializations()
    {
        java.util.Collection getSpecializations6r = null;
        handleGetSpecializations6rPreCondition();
        Object result = this.shieldedElements(handleGetSpecializations());
        try
        {
            getSpecializations6r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSpecializations6rPostCondition();
        return getSpecializations6r;
    }

    protected abstract java.util.Collection handleGetSpecializations();

    private void handleGetGeneralizations7rPreCondition()
    {
    }

    private void handleGetGeneralizations7rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizations()
    {
        java.util.Collection getGeneralizations7r = null;
        handleGetGeneralizations7rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizations());
        try
        {
            getGeneralizations7r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizations7rPostCondition();
        return getGeneralizations7r;
    }

    protected abstract java.util.Collection handleGetGeneralizations();

    private void handleGetGeneralizationLinks9rPreCondition()
    {
    }

    private void handleGetGeneralizationLinks9rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizationLinks()
    {
        java.util.Collection getGeneralizationLinks9r = null;
        handleGetGeneralizationLinks9rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizationLinks());
        try
        {
            getGeneralizationLinks9r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizationLinks9rPostCondition();
        return getGeneralizationLinks9r;
    }

    protected abstract java.util.Collection handleGetGeneralizationLinks();

    private void handleGetAllSpecializations10rPreCondition()
    {
    }

    private void handleGetAllSpecializations10rPostCondition()
    {
    }

    public final java.util.Collection getAllSpecializations()
    {
        java.util.Collection getAllSpecializations10r = null;
        handleGetAllSpecializations10rPreCondition();
        Object result = this.shieldedElements(handleGetAllSpecializations());
        try
        {
            getAllSpecializations10r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllSpecializations10rPostCondition();
        return getAllSpecializations10r;
    }

    protected abstract java.util.Collection handleGetAllSpecializations();

    private void handleGetAllGeneralizations12rPreCondition()
    {
    }

    private void handleGetAllGeneralizations12rPostCondition()
    {
    }

    public final java.util.Collection getAllGeneralizations()
    {
        java.util.Collection getAllGeneralizations12r = null;
        handleGetAllGeneralizations12rPreCondition();
        Object result = this.shieldedElements(handleGetAllGeneralizations());
        try
        {
            getAllGeneralizations12r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllGeneralizations12rPostCondition();
        return getAllGeneralizations12r;
    }

    protected abstract java.util.Collection handleGetAllGeneralizations();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}