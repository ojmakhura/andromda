package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityQueryOperation.
 *
 * @see org.andromda.metafacades.uml.EntityQueryOperation
 */
public class EntityQueryOperationLogicImpl
    extends EntityQueryOperationLogic
{

    public EntityQueryOperationLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.EntityQueryOperation#getQuery(java.lang.String)
     */
    protected java.lang.String handleGetQuery(java.lang.String translation)
    {
        // TODO: put your implementation here.
        return null;
    }

}