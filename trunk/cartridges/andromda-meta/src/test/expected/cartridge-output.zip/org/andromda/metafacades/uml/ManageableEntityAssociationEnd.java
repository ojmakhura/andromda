//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntityAssociationEnd
    extends org.andromda.metafacades.uml.EntityAssociationEnd
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.EntityAttribute getManageableIdentifier();

   /**
    * <p>
    *  Whether or not this association end should be displayed.
    * </p>
    */
    public boolean isDisplay();

}