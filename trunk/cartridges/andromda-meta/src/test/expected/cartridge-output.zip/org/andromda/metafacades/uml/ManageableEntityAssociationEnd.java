//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntityAssociationEnd
    extends org.andromda.metafacades.uml.EntityAssociationEnd
{

   /**
    * 
    */
    public java.lang.String getForeignGetterName(org.andromda.metafacades.uml.EntityAttribute attribute);

   /**
    * 
    */
    public java.lang.String getForeignName(org.andromda.metafacades.uml.EntityAttribute attribute);

   /**
    * 
    */
    public java.lang.String getForeignSetterName(org.andromda.metafacades.uml.EntityAttribute attribute);

}