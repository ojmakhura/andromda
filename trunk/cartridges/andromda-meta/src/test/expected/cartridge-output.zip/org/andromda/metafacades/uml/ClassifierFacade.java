//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a Classifier model element
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ClassifierFacade
       extends org.andromda.metafacades.uml.GeneralizableElementFacade
{

   /**
    * <p>
    *  The collection of interfaces implemented by the Classifier.
    * </p>
    */
    public java.util.Collection getAbstractions();

   /**
    * <p>
    *  Gets the array type for this classifier. If this classifier
    *  already represents an array, it just returns itself.
    * </p>
    */
    public org.andromda.metafacades.uml.ClassifierFacade getArray();

   /**
    * <p>
    *  Gets the association ends belonging to a classifier.
    * </p>
    */
    public java.util.Collection getAssociationEnds();

   /**
    * <p>
    *  Gets the attributes that belong to the classifier.
    * </p>
    */
    public java.util.Collection getAttributes();

   /**
    * <p>
    *  Gets all attributes for the classifier and if 'follow' is true
    *  goes up the inheritance hierachy and gets the attributes from
    *  the super classes as well.
    * </p>
    */
    public java.util.Collection getAttributes(boolean follow);

   /**
    * <p>
    *  The non-static attributes of the specified classifier.
    * </p>
    */
    public java.util.Collection getInstanceAttributes();

   /**
    * <p>
    *  A String representing the null-value for this classifier type
    *  to be used in a Java environment.
    * </p>
    */
    public java.lang.String getJavaNullString();

   /**
    * <p>
    *  Assuming that the classifier is an array, this will return the
    *  non array type of the classifier from the model. If the
    *  classifier is NOT an array, it will just return itself.
    * </p>
    */
    public org.andromda.metafacades.uml.ClassifierFacade getNonArray();

   /**
    * <p>
    *  The attributes from this classifier in the form of an operation
    *  call (this example would be in Java): '(java.lang.String
    *  attributeOne, java.lang.String attributeTwo). If there were no
    *  attributes on the classifier, the result would be an empty
    *  '()'.
    * </p>
    */
    public java.lang.String getOperationCallFromAttributes();

   /**
    * 
    */
    public java.util.Collection getOperations();

   /**
    * <p>
    *  A collection containing all 'properties' of the classifier.
    *  Properties are any attributes and navigable connecting
    *  association ends.
    * </p>
    */
    public java.util.Collection getProperties();

   /**
    * <p>
    *  The static attributes of the specified Classifier object.
    * </p>
    */
    public java.util.Collection getStaticAttributes();

   /**
    * <p>
    *  The wrapper name for this classifier if a mapped type has a
    *  defined wrapper class (ie. 'int' maps to 'Long'). If the
    *  classifier doesn't have a wrapper defined for it, this method
    *  will return a null. Note that wrapper mappings must be defined
    *  for the namespace by defining the 'wrapperMappingsUri', this
    *  property must point to the location of the mappings file which
    *  maps the primitives to wrapper types.
    * </p>
    */
    public java.lang.String getWrapperName();

   /**
    * 
    */
    public boolean isAbstract();

   /**
    * <p>
    *  True if this classifier represents an array type. False
    *  otherwise.
    * </p>
    */
    public boolean isArrayType();

   /**
    * <p>
    *  True if this classifier represents a collection type. False
    *  otherwise.
    * </p>
    */
    public boolean isCollectionType();

   /**
    * <p>
    *  True/false depending on whether or not this classifier
    *  represents a datatype.
    * </p>
    */
    public boolean isDataType();

   /**
    * <p>
    *  True when this classifier is a date type, this means it is a
    *  descendant of java.util.Date.
    * </p>
    */
    public boolean isDateType();

   /**
    * <p>
    *  True/false depending on whether or not the classifier
    *  represents an enumeration.
    * </p>
    */
    public boolean isEnumeration();

   /**
    * 
    */
    public boolean isFileType();

   /**
    * <p>
    *  True/false depending on whether or not this Classifier
    *  represents an interface or not.
    * </p>
    */
    public boolean isInterface();

   /**
    * <p>
    *  True if this classifier represents a list type. False
    *  otherwise.
    * </p>
    */
    public boolean isListType();

   /**
    * 
    */
    public boolean isPrimitive();

   /**
    * <p>
    *  True if this classifier represents a set type. False otherwise.
    * </p>
    */
    public boolean isSetType();

}
