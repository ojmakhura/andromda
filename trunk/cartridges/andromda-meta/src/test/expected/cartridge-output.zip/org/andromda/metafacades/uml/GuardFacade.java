//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface GuardFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.lang.String getBody();

   /**
    * 
    */
    public org.andromda.metafacades.uml.TransitionFacade getTransition();

}
