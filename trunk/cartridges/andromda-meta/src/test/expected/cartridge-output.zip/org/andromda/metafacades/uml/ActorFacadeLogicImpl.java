package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActorFacade.
 *
 * @see org.andromda.metafacades.uml.ActorFacade
 */
public class ActorFacadeLogicImpl
    extends ActorFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ActorFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.Actor metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActorFacade#getGeneralizedByActors()
     */
    protected java.util.Collection handleGetGeneralizedByActors()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActorFacade#getGeneralizedActors()
     */
    protected java.util.Collection handleGetGeneralizedActors()
    {
        // TODO: add your implementation here!
        return null;
    }

}
