package org.andromda.cartridges.meta;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.meta.OperationTestMetafacade.
 *
 * @see org.andromda.cartridges.meta.OperationTestMetafacade
 */
public class OperationTestMetafacadeLogicImpl
    extends OperationTestMetafacadeLogic
{

    public OperationTestMetafacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
     */
    protected boolean handleIsTestAttribute()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.cartridges.meta.OperationTestMetafacade#getTestClassifier()
     */
    protected java.lang.Object handleGetTestOperations()
    {
        // TODO: add your implementation here!
        return null;
    }

}