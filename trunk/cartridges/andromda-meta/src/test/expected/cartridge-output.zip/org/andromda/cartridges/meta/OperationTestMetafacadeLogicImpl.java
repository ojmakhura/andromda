package org.andromda.cartridges.meta;


/**
 * MetafacadeLogic implementation for org.andromda.cartridges.meta.OperationTestMetafacade.
 *
 * @see org.andromda.cartridges.meta.OperationTestMetafacade
 */
public class OperationTestMetafacadeLogicImpl
       extends OperationTestMetafacadeLogic
       implements org.andromda.cartridges.meta.OperationTestMetafacade
{
    // ---------------- constructor -------------------------------

    public OperationTestMetafacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.cartridges.meta.OperationTestMetafacade#isTestAttribute()
     */
    protected boolean handleIsTestAttribute()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.cartridges.meta.OperationTestMetafacade#getTestClassifier()
     */
    protected java.lang.Object handleGetTestClassifier()
    {
        // TODO: add your implementation here!
        return null;
    }

}
