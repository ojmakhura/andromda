package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.FrontEndActionState.
 *
 * @see org.andromda.metafacades.uml.FrontEndActionState
 */
public class FrontEndActionStateLogicImpl
    extends FrontEndActionStateLogic
{

    public FrontEndActionStateLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#isServerSide()
     */
    protected boolean handleIsServerSide()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#isContainedInFrontEndUseCase()
     */
    protected boolean handleIsContainedInFrontEndUseCase()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#getActionMethodName()
     */
    protected java.lang.String handleGetActionMethodName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#getForward()
     */
    protected java.lang.Object handleGetForward()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#getControllerCalls()
     */
    protected java.util.List handleGetControllerCalls()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.FrontEndActionState#getExceptions()
     */
    protected java.util.List handleGetExceptions()
    {
        // TODO: add your implementation here!
        return null;
    }

}