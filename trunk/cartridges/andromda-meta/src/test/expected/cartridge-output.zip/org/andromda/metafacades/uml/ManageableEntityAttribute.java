//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntityAttribute
    extends org.andromda.metafacades.uml.EntityAttribute
{

   /**
    * 
    */
    public java.lang.String getCrudGetterName();

   /**
    * 
    */
    public java.lang.String getCrudName();

   /**
    * 
    */
    public java.lang.String getCrudSetterName();

}