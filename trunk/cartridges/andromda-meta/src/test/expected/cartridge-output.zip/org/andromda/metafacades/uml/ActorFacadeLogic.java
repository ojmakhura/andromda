//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ActorFacade
 *
 * @see org.andromda.metafacades.uml.ActorFacade
 */
public abstract class ActorFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.ActorFacade
{

    protected org.omg.uml.behavioralelements.usecases.Actor metaObject;

    public ActorFacadeLogic(org.omg.uml.behavioralelements.usecases.Actor metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActorFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetGeneralizedByActors2rPreCondition()
    {
    }

    private void handleGetGeneralizedByActors2rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizedByActors()
    {
        java.util.Collection getGeneralizedByActors2r = null;
        handleGetGeneralizedByActors2rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizedByActors());
        try
        {
            getGeneralizedByActors2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizedByActors2rPostCondition();
        return getGeneralizedByActors2r;
    }

    protected abstract java.util.Collection handleGetGeneralizedByActors();

    private void handleGetGeneralizedActors3rPreCondition()
    {
    }

    private void handleGetGeneralizedActors3rPostCondition()
    {
    }

    public final java.util.Collection getGeneralizedActors()
    {
        java.util.Collection getGeneralizedActors3r = null;
        handleGetGeneralizedActors3rPreCondition();
        Object result = this.shieldedElements(handleGetGeneralizedActors());
        try
        {
            getGeneralizedActors3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGeneralizedActors3rPostCondition();
        return getGeneralizedActors3r;
    }

    protected abstract java.util.Collection handleGetGeneralizedActors();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
