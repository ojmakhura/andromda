package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EventFacade.
 *
 * @see org.andromda.metafacades.uml.EventFacade
 */
public class EventFacadeLogicImpl
       extends EventFacadeLogic
       implements org.andromda.metafacades.uml.EventFacade
{
    // ---------------- constructor -------------------------------

    public EventFacadeLogicImpl (org.omg.uml.behavioralelements.statemachines.Event metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.EventFacade#getTransition()
     */
    public java.lang.Object handleGetTransition()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EventFacade#getParameters()
     */
    public java.util.Collection handleGetParameters()
    {
        // TODO: add your implementation here!
        return null;
    }

}
