package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.PackageFacade.
 *
 * @see org.andromda.metafacades.uml.PackageFacade
 */
public class PackageFacadeLogicImpl
       extends PackageFacadeLogic
       implements org.andromda.metafacades.uml.PackageFacade
{
    // ---------------- constructor -------------------------------

    public PackageFacadeLogicImpl (org.omg.uml.modelmanagement.UmlPackage metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.PackageFacade#findModelElement(java.lang.String)
     */
    public org.andromda.metafacades.uml.ModelElementFacade handleFindModelElement(java.lang.String fullyQualifiedName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getClasses()
     */
    public java.util.Collection handleGetClasses()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getSubPackages()
     */
    public java.util.Collection handleGetSubPackages()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.PackageFacade#getModelElements()
     */
    public java.util.Collection handleGetModelElements()
    {
        // TODO: add your implementation here!
        return null;
    }

}
