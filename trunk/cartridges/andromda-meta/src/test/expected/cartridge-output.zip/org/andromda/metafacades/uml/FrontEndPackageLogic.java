//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndPackage
 *
 * @see org.andromda.metafacades.uml.FrontEndPackage
 */
public abstract class FrontEndPackageLogic
    extends org.andromda.metafacades.uml.PackageFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndPackage
{

    protected Object metaObject;

    public FrontEndPackageLogic(Object metaObject, String context)
    {
        super((org.omg.uml.modelmanagement.UmlPackage)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndPackage";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetFrontEndControllers1rPreCondition()
    {
    }

    private void handleGetFrontEndControllers1rPostCondition()
    {
    }

    private java.util.List __getFrontEndControllers1r;
    private boolean __getFrontEndControllers1rSet = false;

    public final java.util.List getFrontEndControllers()
    {
        java.util.List getFrontEndControllers1r = this.__getFrontEndControllers1r;
        if (!this.__getFrontEndControllers1rSet)
        {
            handleGetFrontEndControllers1rPreCondition();
            Object result = this.shieldedElements(handleGetFrontEndControllers());
            try
            {
                getFrontEndControllers1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFrontEndControllers1rPostCondition();
            this.__getFrontEndControllers1r = getFrontEndControllers1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndControllers1rSet = true;
            }
        }
        return getFrontEndControllers1r;
    }

    protected abstract java.util.List handleGetFrontEndControllers();

    private void handleGetFrontEndUseCases2rPreCondition()
    {
    }

    private void handleGetFrontEndUseCases2rPostCondition()
    {
    }

    private java.util.List __getFrontEndUseCases2r;
    private boolean __getFrontEndUseCases2rSet = false;

    public final java.util.List getFrontEndUseCases()
    {
        java.util.List getFrontEndUseCases2r = this.__getFrontEndUseCases2r;
        if (!this.__getFrontEndUseCases2rSet)
        {
            handleGetFrontEndUseCases2rPreCondition();
            Object result = this.shieldedElements(handleGetFrontEndUseCases());
            try
            {
                getFrontEndUseCases2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFrontEndUseCases2rPostCondition();
            this.__getFrontEndUseCases2r = getFrontEndUseCases2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndUseCases2rSet = true;
            }
        }
        return getFrontEndUseCases2r;
    }

    protected abstract java.util.List handleGetFrontEndUseCases();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.less(org.andromda.translation.ocl.validation.OCLCollections.size(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"frontEndControllers")),2)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndPackage::no more than one controller per package",
                        "In order to avoid possible naming collisions at most one controller per package is allowed. It is recommended to refactor your model."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.less(org.andromda.translation.ocl.validation.OCLCollections.size(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"frontEndUseCases")),2)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        (org.andromda.core.metafacade.MetafacadeBase)contextElement ,
                        "org::andromda::metafacades::uml::FrontEndPackage::no more than one usecase per package",
                        "In order to avoid possible naming collisions at most one FrontEndUseCase per package is allowed. It is recommended to refactor your model."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}