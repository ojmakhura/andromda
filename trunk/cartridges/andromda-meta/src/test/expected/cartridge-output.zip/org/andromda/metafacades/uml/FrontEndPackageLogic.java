//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndPackage
 *
 * @see org.andromda.metafacades.uml.FrontEndPackage
 */
public abstract class FrontEndPackageLogic
    extends org.andromda.metafacades.uml.PackageFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndPackage
{

    protected Object metaObject;

    public FrontEndPackageLogic(Object metaObject, String context)
    {
        super((org.omg.uml.modelmanagement.UmlPackage)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndPackage";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetFrontEndUseCases1rPreCondition()
    {
    }

    private void handleGetFrontEndUseCases1rPostCondition()
    {
    }

    private java.util.List __getFrontEndUseCases1r;
    private boolean __getFrontEndUseCases1rSet = false;

    public final java.util.List getFrontEndUseCases()
    {
        java.util.List getFrontEndUseCases1r = this.__getFrontEndUseCases1r;
        if (!this.__getFrontEndUseCases1rSet)
        {
            handleGetFrontEndUseCases1rPreCondition();
            Object result = this.shieldedElements(handleGetFrontEndUseCases());
            try
            {
                getFrontEndUseCases1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFrontEndUseCases1rPostCondition();
            this.__getFrontEndUseCases1r = getFrontEndUseCases1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndUseCases1rSet = true;
            }
        }
        return getFrontEndUseCases1r;
    }

    protected abstract java.util.List handleGetFrontEndUseCases();

    private void handleGetFrontEndControllers2rPreCondition()
    {
    }

    private void handleGetFrontEndControllers2rPostCondition()
    {
    }

    private java.util.List __getFrontEndControllers2r;
    private boolean __getFrontEndControllers2rSet = false;

    public final java.util.List getFrontEndControllers()
    {
        java.util.List getFrontEndControllers2r = this.__getFrontEndControllers2r;
        if (!this.__getFrontEndControllers2rSet)
        {
            handleGetFrontEndControllers2rPreCondition();
            Object result = this.shieldedElements(handleGetFrontEndControllers());
            try
            {
                getFrontEndControllers2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetFrontEndControllers2rPostCondition();
            this.__getFrontEndControllers2r = getFrontEndControllers2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getFrontEndControllers2rSet = true;
            }
        }
        return getFrontEndControllers2r;
    }

    protected abstract java.util.List handleGetFrontEndControllers();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.less(org.andromda.translation.ocl.validation.OCLCollections.size(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"frontEndControllers")),2)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "In order to avoid possible naming collisions at most one controller per package is allowed. It is recommended to refactor your model."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLExpressions.less(org.andromda.translation.ocl.validation.OCLCollections.size(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"frontEndUseCases")),2)); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "In order to avoid possible naming collisions at most one FrontEndUseCase per package is allowed. It is recommended to refactor your model."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}