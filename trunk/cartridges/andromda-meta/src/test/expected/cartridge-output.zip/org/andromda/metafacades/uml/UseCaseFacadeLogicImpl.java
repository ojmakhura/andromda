package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.UseCaseFacade.
 *
 * @see org.andromda.metafacades.uml.UseCaseFacade
 */
public class UseCaseFacadeLogicImpl
       extends UseCaseFacadeLogic
       implements org.andromda.metafacades.uml.UseCaseFacade
{
    // ---------------- constructor -------------------------------

    public UseCaseFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.UseCase metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.UseCaseFacade#getFirstActivityGraph()
     */
    public java.lang.Object handleGetFirstActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

}
