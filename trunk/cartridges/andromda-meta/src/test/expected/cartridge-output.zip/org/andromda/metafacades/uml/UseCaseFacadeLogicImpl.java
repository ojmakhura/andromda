package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.UseCaseFacade.
 *
 * @see org.andromda.metafacades.uml.UseCaseFacade
 */
public class UseCaseFacadeLogicImpl
    extends UseCaseFacadeLogic
{

    public UseCaseFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.UseCase metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.UseCaseFacade#getFirstActivityGraph()
     */
    protected java.lang.Object handleGetUseCase()
    {
        // TODO: add your implementation here!
        return null;
    }

}