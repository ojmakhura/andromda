package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntity.
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public class ManageableEntityLogicImpl
    extends ManageableEntityLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageablePackageName()
     */
    protected java.lang.String handleGetManageablePackageName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceAccessorCall()
     */
    protected java.lang.String handleGetManageableServiceAccessorCall()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
     */
    protected boolean handleIsRead()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
     */
    protected boolean handleIsCreate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
     */
    protected boolean handleIsUpdate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
     */
    protected boolean handleIsDelete()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageablePackagePath()
     */
    protected java.lang.String handleGetManageablePackagePath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceName()
     */
    protected java.lang.String handleGetManageableServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getFullyQualifiedManageableServiceName()
     */
    protected java.lang.String handleGetFullyQualifiedManageableServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceFullPath()
     */
    protected java.lang.String handleGetManageableServiceFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableMembers()
     */
    protected java.util.List handleGetManageableMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableName()
     */
    protected java.lang.String handleGetManageableName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isManageable()
     */
    protected boolean handleIsManageable()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#listManageableMembers(boolean)
     */
    protected java.lang.String handleListManageableMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableAssociationEnds()
     */
    protected java.util.List handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getReferencingManageables()
     */
    protected java.util.Collection handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getDisplayAttribute()
     */
    protected java.lang.Object handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

}