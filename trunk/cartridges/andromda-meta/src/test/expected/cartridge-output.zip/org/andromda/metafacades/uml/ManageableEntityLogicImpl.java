package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntity.
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public class ManageableEntityLogicImpl
    extends ManageableEntityLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getFullCreateControllerPath()
     */
    protected java.lang.String handleGetFullCreateControllerPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCreateModelClassName()
     */
    protected java.lang.String handleGetCreateModelClassName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackageName()
     */
    protected java.lang.String handleGetCrudPackageName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCreateControllerName()
     */
    protected java.lang.String handleGetCreateControllerName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getServiceAccessorCall()
     */
    protected java.lang.String handleGetServiceAccessorCall()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
     */
    protected boolean handleIsRead()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
     */
    protected boolean handleIsCreate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
     */
    protected boolean handleIsUpdate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
     */
    protected boolean handleIsDelete()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getAssociatedEntities()
     */
    protected java.util.List handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

}