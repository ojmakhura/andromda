package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntity.
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public class ManageableEntityLogicImpl
    extends ManageableEntityLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackageName()
     */
    protected java.lang.String handleGetCrudPackageName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceAccessorCall()
     */
    protected java.lang.String handleGetCrudServiceAccessorCall()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
     */
    protected boolean handleIsRead()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
     */
    protected boolean handleIsCreate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
     */
    protected boolean handleIsUpdate()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
     */
    protected boolean handleIsDelete()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackagePath()
     */
    protected java.lang.String handleGetCrudPackagePath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceName()
     */
    protected java.lang.String handleGetCrudServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getFullyQualifiedCrudServiceName()
     */
    protected java.lang.String handleGetFullyQualifiedCrudServiceName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudServiceFullPath()
     */
    protected java.lang.String handleGetCrudServiceFullPath()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getCrudMembers()
     */
    protected java.util.List handleGetCrudMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#listCrudMembers(boolean, boolean)
     */
    protected java.lang.String handleListCrudMembers()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntity#getManageableAssociationEnds()
     */
    protected java.util.List handleGetManageableEntity()
    {
        // TODO: add your implementation here!
        return null;
    }

}