package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ConstraintFacade.
 *
 * @see org.andromda.metafacades.uml.ConstraintFacade
 */
public class ConstraintFacadeLogicImpl
    extends ConstraintFacadeLogic
{

    public ConstraintFacadeLogicImpl (org.omg.uml.foundation.core.Constraint metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getBody()
     */
    protected java.lang.String handleGetBody()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isInvariant()
     */
    protected boolean handleIsInvariant()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isPreCondition()
     */
    protected boolean handleIsPreCondition()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isPostCondition()
     */
    protected boolean handleIsPostCondition()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isDefinition()
     */
    protected boolean handleIsDefinition()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isBodyExpression()
     */
    protected boolean handleIsBodyExpression()
    {
        // TODO: put your implementation here.
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getTranslation(java.lang.String)
     */
    protected java.lang.String handleGetTranslation(java.lang.String language)
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getContextElement()
     */
    protected java.lang.Object handleGetContextElement()
    {
        // TODO: add your implementation here!
        return null;
    }

}