package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ConstraintFacade.
 *
 * @see org.andromda.metafacades.uml.ConstraintFacade
 */
public class ConstraintFacadeLogicImpl
       extends ConstraintFacadeLogic
       implements org.andromda.metafacades.uml.ConstraintFacade
{
    // ---------------- constructor -------------------------------

    public ConstraintFacadeLogicImpl (org.omg.uml.foundation.core.Constraint metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getBody()
     */
    public java.lang.String handleGetBody() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isInvariant()
     */
    public boolean handleIsInvariant() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isPreCondition()
     */
    public boolean handleIsPreCondition() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isPostCondition()
     */
    public boolean handleIsPostCondition() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isDefinition()
     */
    public boolean handleIsDefinition() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#isBodyExpression()
     */
    public boolean handleIsBodyExpression() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getTranslation(java.lang.String)
     */
    public java.lang.String handleGetTranslation(java.lang.String language) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ConstraintFacade#getContextElement()
     */
    public java.lang.Object handleGetContextElement()
    {
        // TODO: add your implementation here!
        return null;
    }

}
