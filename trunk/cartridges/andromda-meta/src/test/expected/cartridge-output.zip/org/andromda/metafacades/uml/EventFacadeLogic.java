//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EventFacade
 *
 * @see org.andromda.metafacades.uml.EventFacade
 */
public abstract class EventFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.EventFacade
{

    protected org.omg.uml.behavioralelements.statemachines.Event metaObject;

    public EventFacadeLogic(org.omg.uml.behavioralelements.statemachines.Event metaObject, String context)
    {  
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EventFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetTransition1rPreCondition()
    {
    }

    private void handleGetTransition1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.TransitionFacade getTransition()
    {
        org.andromda.metafacades.uml.TransitionFacade getTransition1r = null;
        handleGetTransition1rPreCondition();
        Object result = this.shieldedElement(handleGetTransition());
        try
        {
            getTransition1r = (org.andromda.metafacades.uml.TransitionFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTransition1rPostCondition();
        return getTransition1r;
    }

    protected abstract java.lang.Object handleGetTransition();

    private void handleGetParameters2rPreCondition()
    {
    }

    private void handleGetParameters2rPostCondition()
    {
    }

    public final java.util.Collection getParameters()
    {
        java.util.Collection getParameters2r = null;
        handleGetParameters2rPreCondition();
        Object result = this.shieldedElements(handleGetParameters());
        try
        {
            getParameters2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetParameters2rPostCondition();
        return getParameters2r;
    }

    protected abstract java.util.Collection handleGetParameters();

    private void handleGetState3rPreCondition()
    {
    }

    private void handleGetState3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateFacade getState()
    {
        org.andromda.metafacades.uml.StateFacade getState3r = null;
        handleGetState3rPreCondition();
        Object result = this.shieldedElement(handleGetState());
        try
        {
            getState3r = (org.andromda.metafacades.uml.StateFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetState3rPostCondition();
        return getState3r;
    }

    protected abstract java.lang.Object handleGetState();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}