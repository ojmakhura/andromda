//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.RoleFacade
 *
 * @see org.andromda.metafacades.uml.RoleFacade
 */
public abstract class RoleFacadeLogic
    extends org.andromda.metafacades.uml.ActorFacadeLogicImpl
    implements org.andromda.metafacades.uml.RoleFacade
{

    protected Object metaObject;

    public RoleFacadeLogic (Object metaObject, String context)
    {
        super ((org.omg.uml.behavioralelements.usecases.Actor)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.RoleFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.RoleFacade#isEnabled()
    */
    protected abstract boolean handleIsEnabled();

    private void handleIsEnabled1aPreCondition()
    {
    }

    private void handleIsEnabled1aPostCondition()
    {
    }

    public final boolean isEnabled()
    {
        boolean enabled1a = false;
        handleIsEnabled1aPreCondition();
        enabled1a = handleIsEnabled();
        handleIsEnabled1aPostCondition();
        return enabled1a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
