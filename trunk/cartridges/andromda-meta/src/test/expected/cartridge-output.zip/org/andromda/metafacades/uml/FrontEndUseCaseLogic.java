//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndUseCase
 *
 * @see org.andromda.metafacades.uml.FrontEndUseCase
 */
public abstract class FrontEndUseCaseLogic
    extends org.andromda.metafacades.uml.UseCaseFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndUseCase
{

    protected Object metaObject;

    public FrontEndUseCaseLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.usecases.UseCase)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndUseCase";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndUseCase#isEntryUseCase()
    */
    protected abstract boolean handleIsEntryUseCase();

    private void handleIsEntryUseCase1aPreCondition()
    {
    }

    private void handleIsEntryUseCase1aPostCondition()
    {
    }

    private boolean __entryUseCase1a;
    private boolean __entryUseCase1aSet = false;

    public final boolean isEntryUseCase()
    {
        boolean entryUseCase1a = this.__entryUseCase1a;
        if (!this.__entryUseCase1aSet)
        {
            handleIsEntryUseCase1aPreCondition();
            entryUseCase1a = handleIsEntryUseCase();
            handleIsEntryUseCase1aPostCondition();
            this.__entryUseCase1a = entryUseCase1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__entryUseCase1aSet = true;
            }
        }
        return entryUseCase1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndUseCase#isSecured()
    */
    protected abstract boolean handleIsSecured();

    private void handleIsSecured2aPreCondition()
    {
    }

    private void handleIsSecured2aPostCondition()
    {
    }

    private boolean __secured2a;
    private boolean __secured2aSet = false;

    public final boolean isSecured()
    {
        boolean secured2a = this.__secured2a;
        if (!this.__secured2aSet)
        {
            handleIsSecured2aPreCondition();
            secured2a = handleIsSecured();
            handleIsSecured2aPostCondition();
            this.__secured2a = secured2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__secured2aSet = true;
            }
        }
        return secured2a;
    }

    // ------------- associations ------------------

    private void handleGetController1rPreCondition()
    {
    }

    private void handleGetController1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndController __getController1r;
    private boolean __getController1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndController getController()
    {
        org.andromda.metafacades.uml.FrontEndController getController1r = this.__getController1r;
        if (!this.__getController1rSet)
        {
            handleGetController1rPreCondition();
            Object result = this.shieldedElement(handleGetController());
            try
            {
                getController1r = (org.andromda.metafacades.uml.FrontEndController)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetController1rPostCondition();
            this.__getController1r = getController1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getController1rSet = true;
            }
        }
        return getController1r;
    }

    protected abstract java.lang.Object handleGetController();

    private void handleGetActivityGraph2rPreCondition()
    {
    }

    private void handleGetActivityGraph2rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndActivityGraph __getActivityGraph2r;
    private boolean __getActivityGraph2rSet = false;

    public final org.andromda.metafacades.uml.FrontEndActivityGraph getActivityGraph()
    {
        org.andromda.metafacades.uml.FrontEndActivityGraph getActivityGraph2r = this.__getActivityGraph2r;
        if (!this.__getActivityGraph2rSet)
        {
            handleGetActivityGraph2rPreCondition();
            Object result = this.shieldedElement(handleGetActivityGraph());
            try
            {
                getActivityGraph2r = (org.andromda.metafacades.uml.FrontEndActivityGraph)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActivityGraph2rPostCondition();
            this.__getActivityGraph2r = getActivityGraph2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActivityGraph2rSet = true;
            }
        }
        return getActivityGraph2r;
    }

    protected abstract java.lang.Object handleGetActivityGraph();

    private void handleGetAllUseCases4rPreCondition()
    {
    }

    private void handleGetAllUseCases4rPostCondition()
    {
    }

    private java.util.List __getAllUseCases4r;
    private boolean __getAllUseCases4rSet = false;

    public final java.util.List getAllUseCases()
    {
        java.util.List getAllUseCases4r = this.__getAllUseCases4r;
        if (!this.__getAllUseCases4rSet)
        {
            handleGetAllUseCases4rPreCondition();
            Object result = this.shieldedElements(handleGetAllUseCases());
            try
            {
                getAllUseCases4r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAllUseCases4rPostCondition();
            this.__getAllUseCases4r = getAllUseCases4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllUseCases4rSet = true;
            }
        }
        return getAllUseCases4r;
    }

    protected abstract java.util.List handleGetAllUseCases();

    private void handleGetRoles6rPreCondition()
    {
    }

    private void handleGetRoles6rPostCondition()
    {
    }

    private java.util.List __getRoles6r;
    private boolean __getRoles6rSet = false;

    public final java.util.List getRoles()
    {
        java.util.List getRoles6r = this.__getRoles6r;
        if (!this.__getRoles6rSet)
        {
            handleGetRoles6rPreCondition();
            Object result = this.shieldedElements(handleGetRoles());
            try
            {
                getRoles6r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetRoles6rPostCondition();
            this.__getRoles6r = getRoles6r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getRoles6rSet = true;
            }
        }
        return getRoles6r;
    }

    protected abstract java.util.List handleGetRoles();

    private void handleGetAllRoles7rPreCondition()
    {
    }

    private void handleGetAllRoles7rPostCondition()
    {
    }

    private java.util.List __getAllRoles7r;
    private boolean __getAllRoles7rSet = false;

    public final java.util.List getAllRoles()
    {
        java.util.List getAllRoles7r = this.__getAllRoles7r;
        if (!this.__getAllRoles7rSet)
        {
            handleGetAllRoles7rPreCondition();
            Object result = this.shieldedElements(handleGetAllRoles());
            try
            {
                getAllRoles7r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetAllRoles7rPostCondition();
            this.__getAllRoles7r = getAllRoles7r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getAllRoles7rSet = true;
            }
        }
        return getAllRoles7r;
    }

    protected abstract java.util.List handleGetAllRoles();

    private void handleGetViews8rPreCondition()
    {
    }

    private void handleGetViews8rPostCondition()
    {
    }

    private java.util.List __getViews8r;
    private boolean __getViews8rSet = false;

    public final java.util.List getViews()
    {
        java.util.List getViews8r = this.__getViews8r;
        if (!this.__getViews8rSet)
        {
            handleGetViews8rPreCondition();
            Object result = this.shieldedElements(handleGetViews());
            try
            {
                getViews8r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetViews8rPostCondition();
            this.__getViews8r = getViews8r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getViews8rSet = true;
            }
        }
        return getViews8r;
    }

    protected abstract java.util.List handleGetViews();

    private void handleGetReferencingFinalStates10rPreCondition()
    {
    }

    private void handleGetReferencingFinalStates10rPostCondition()
    {
    }

    private java.util.List __getReferencingFinalStates10r;
    private boolean __getReferencingFinalStates10rSet = false;

    public final java.util.List getReferencingFinalStates()
    {
        java.util.List getReferencingFinalStates10r = this.__getReferencingFinalStates10r;
        if (!this.__getReferencingFinalStates10rSet)
        {
            handleGetReferencingFinalStates10rPreCondition();
            Object result = this.shieldedElements(handleGetReferencingFinalStates());
            try
            {
                getReferencingFinalStates10r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetReferencingFinalStates10rPostCondition();
            this.__getReferencingFinalStates10r = getReferencingFinalStates10r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getReferencingFinalStates10rSet = true;
            }
        }
        return getReferencingFinalStates10r;
    }

    protected abstract java.util.List handleGetReferencingFinalStates();

    private void handleGetActions11rPreCondition()
    {
    }

    private void handleGetActions11rPostCondition()
    {
    }

    private java.util.List __getActions11r;
    private boolean __getActions11rSet = false;

    public final java.util.List getActions()
    {
        java.util.List getActions11r = this.__getActions11r;
        if (!this.__getActions11rSet)
        {
            handleGetActions11rPreCondition();
            Object result = this.shieldedElements(handleGetActions());
            try
            {
                getActions11r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetActions11rPostCondition();
            this.__getActions11r = getActions11r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getActions11rSet = true;
            }
        }
        return getActions11r;
    }

    protected abstract java.util.List handleGetActions();

    private void handleGetInitialView12rPreCondition()
    {
    }

    private void handleGetInitialView12rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndView __getInitialView12r;
    private boolean __getInitialView12rSet = false;

    public final org.andromda.metafacades.uml.FrontEndView getInitialView()
    {
        org.andromda.metafacades.uml.FrontEndView getInitialView12r = this.__getInitialView12r;
        if (!this.__getInitialView12rSet)
        {
            handleGetInitialView12rPreCondition();
            Object result = this.shieldedElement(handleGetInitialView());
            try
            {
                getInitialView12r = (org.andromda.metafacades.uml.FrontEndView)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetInitialView12rPostCondition();
            this.__getInitialView12r = getInitialView12r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getInitialView12rSet = true;
            }
        }
        return getInitialView12r;
    }

    protected abstract java.lang.Object handleGetInitialView();

    private void handleGetViewVariables13rPreCondition()
    {
    }

    private void handleGetViewVariables13rPostCondition()
    {
    }

    private java.util.List __getViewVariables13r;
    private boolean __getViewVariables13rSet = false;

    public final java.util.List getViewVariables()
    {
        java.util.List getViewVariables13r = this.__getViewVariables13r;
        if (!this.__getViewVariables13rSet)
        {
            handleGetViewVariables13rPreCondition();
            Object result = this.shieldedElements(handleGetViewVariables());
            try
            {
                getViewVariables13r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetViewVariables13rPostCondition();
            this.__getViewVariables13r = getViewVariables13r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getViewVariables13rSet = true;
            }
        }
        return getViewVariables13r;
    }

    protected abstract java.util.List handleGetViewVariables();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"activityGraph"))); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each use-case needs one and only one activity graph."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.one(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"allUseCases"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"entryUseCase"),true))).booleanValue();}})); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "One and only one use-case must be marked as the application entry use-case. Currently this is done by adding the FrontEndApplication stereotype to it."));
        }
        {
            final java.lang.Object contextElement = this.THIS(); boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"name"))&&org.andromda.translation.ocl.validation.OCLCollections.isUnique(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"model.allUseCases"),new org.apache.commons.collections.Transformer(){public Object transform(java.lang.Object object){return org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"name");}})); 
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this.THIS(),
                        "Each use-case must have a non-empty name that is unique among all use-cases."));
        }
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}