//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EnumerationFacade
 *
 * @see org.andromda.metafacades.uml.EnumerationFacade
 */
public abstract class EnumerationFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.EnumerationFacade
{

    protected Object metaObject;

    public EnumerationFacadeLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EnumerationFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetLiterals1rPreCondition()
    {
    }

    private void handleGetLiterals1rPostCondition()
    {
    }

    public final java.util.Collection getLiterals()
    {
        java.util.Collection getLiterals1r = null;
        handleGetLiterals1rPreCondition();
        Object result = this.shieldedElements(handleGetLiterals());
        try
        {
            getLiterals1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetLiterals1rPostCondition();
        return getLiterals1r;
    }

    protected abstract java.util.Collection handleGetLiterals();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
