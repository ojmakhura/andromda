//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAttributeFacade
 *
 * @see org.andromda.metafacades.uml.EntityAttributeFacade
 */
public abstract class EntityAttributeFacadeLogic
    extends org.andromda.metafacades.uml.AttributeFacadeLogicImpl
    implements org.andromda.metafacades.uml.EntityAttributeFacade
{

    protected Object metaObject;

    public EntityAttributeFacadeLogic (Object metaObject, String context)
    {
        super ((org.omg.uml.foundation.core.Attribute)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAttributeFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnLength()
    */
    protected abstract java.lang.String handleGetColumnLength();

    private void handleGetColumnLength1aPreCondition()
    {
    }

    private void handleGetColumnLength1aPostCondition()
    {
    }

    public final java.lang.String getColumnLength()
    {
        java.lang.String columnLength1a = null;
        handleGetColumnLength1aPreCondition();
        columnLength1a = handleGetColumnLength();
        handleGetColumnLength1aPostCondition();
        return columnLength1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName2aPreCondition()
    {
    }

    private void handleGetColumnName2aPostCondition()
    {
    }

    public final java.lang.String getColumnName()
    {
        java.lang.String columnName2a = null;
        handleGetColumnName2aPreCondition();
        columnName2a = handleGetColumnName();
        handleGetColumnName2aPostCondition();
        return columnName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcMappings()
    */
    protected abstract org.andromda.core.mapping.Mappings handleGetJdbcMappings();

    private void handleGetJdbcMappings3aPreCondition()
    {
    }

    private void handleGetJdbcMappings3aPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getJdbcMappings()
    {
        org.andromda.core.mapping.Mappings jdbcMappings3a = null;
        handleGetJdbcMappings3aPreCondition();
        jdbcMappings3a = handleGetJdbcMappings();
        handleGetJdbcMappings3aPostCondition();
        return jdbcMappings3a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcType()
    */
    protected abstract java.lang.String handleGetJdbcType();

    private void handleGetJdbcType4aPreCondition()
    {
    }

    private void handleGetJdbcType4aPostCondition()
    {
    }

    public final java.lang.String getJdbcType()
    {
        java.lang.String jdbcType4a = null;
        handleGetJdbcType4aPreCondition();
        jdbcType4a = handleGetJdbcType();
        handleGetJdbcType4aPostCondition();
        return jdbcType4a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlMappings()
    */
    protected abstract org.andromda.core.mapping.Mappings handleGetSqlMappings();

    private void handleGetSqlMappings5aPreCondition()
    {
    }

    private void handleGetSqlMappings5aPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getSqlMappings()
    {
        org.andromda.core.mapping.Mappings sqlMappings5a = null;
        handleGetSqlMappings5aPreCondition();
        sqlMappings5a = handleGetSqlMappings();
        handleGetSqlMappings5aPostCondition();
        return sqlMappings5a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlType()
    */
    protected abstract java.lang.String handleGetSqlType();

    private void handleGetSqlType6aPreCondition()
    {
    }

    private void handleGetSqlType6aPostCondition()
    {
    }

    public final java.lang.String getSqlType()
    {
        java.lang.String sqlType6a = null;
        handleGetSqlType6aPreCondition();
        sqlType6a = handleGetSqlType();
        handleGetSqlType6aPostCondition();
        return sqlType6a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#isIdentifier()
    */
    protected abstract boolean handleIsIdentifier();

    private void handleIsIdentifier7aPreCondition()
    {
    }

    private void handleIsIdentifier7aPostCondition()
    {
    }

    public final boolean isIdentifier()
    {
        boolean identifier7a = false;
        handleIsIdentifier7aPreCondition();
        identifier7a = handleIsIdentifier();
        handleIsIdentifier7aPostCondition();
        return identifier7a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#isUnique()
    */
    protected abstract boolean handleIsUnique();

    private void handleIsUnique8aPreCondition()
    {
    }

    private void handleIsUnique8aPostCondition()
    {
    }

    public final boolean isUnique()
    {
        boolean unique8a = false;
        handleIsUnique8aPreCondition();
        unique8a = handleIsUnique();
        handleIsUnique8aPostCondition();
        return unique8a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnIndex()
    */
    protected abstract java.lang.String handleGetColumnIndex();

    private void handleGetColumnIndex9aPreCondition()
    {
    }

    private void handleGetColumnIndex9aPostCondition()
    {
    }

    public final java.lang.String getColumnIndex()
    {
        java.lang.String columnIndex9a = null;
        handleGetColumnIndex9aPreCondition();
        columnIndex9a = handleGetColumnIndex();
        handleGetColumnIndex9aPostCondition();
        return columnIndex9a;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
