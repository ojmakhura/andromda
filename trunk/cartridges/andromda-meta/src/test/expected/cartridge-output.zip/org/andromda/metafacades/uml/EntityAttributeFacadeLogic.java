//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EntityAttributeFacade
 *
 * @see org.andromda.metafacades.uml.EntityAttributeFacade
 */
public abstract class EntityAttributeFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.EntityAttributeFacade
{
    protected Object metaObject;
    private org.andromda.metafacades.uml.AttributeFacade super_;

    public EntityAttributeFacadeLogic (Object metaObject, String context)
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.AttributeFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.AttributeFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EntityAttributeFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnLength()
    */
    protected abstract java.lang.String handleGetColumnLength();

    private void handleGetColumnLength1aPreCondition()
    {
    }

    private void handleGetColumnLength1aPostCondition()
    {
    }

    public final java.lang.String getColumnLength()
    {
        java.lang.String columnLength1a = null;
        handleGetColumnLength1aPreCondition();
        columnLength1a = handleGetColumnLength();
        handleGetColumnLength1aPostCondition();
        return columnLength1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnName()
    */
    protected abstract java.lang.String handleGetColumnName();

    private void handleGetColumnName2aPreCondition()
    {
    }

    private void handleGetColumnName2aPostCondition()
    {
    }

    public final java.lang.String getColumnName()
    {
        java.lang.String columnName2a = null;
        handleGetColumnName2aPreCondition();
        columnName2a = handleGetColumnName();
        handleGetColumnName2aPostCondition();
        return columnName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcMappings()
    */
    protected abstract org.andromda.core.mapping.Mappings handleGetJdbcMappings();

    private void handleGetJdbcMappings3aPreCondition()
    {
    }

    private void handleGetJdbcMappings3aPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getJdbcMappings()
    {
        org.andromda.core.mapping.Mappings jdbcMappings3a = null;
        handleGetJdbcMappings3aPreCondition();
        jdbcMappings3a = handleGetJdbcMappings();
        handleGetJdbcMappings3aPostCondition();
        return jdbcMappings3a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcType()
    */
    protected abstract java.lang.String handleGetJdbcType();

    private void handleGetJdbcType4aPreCondition()
    {
    }

    private void handleGetJdbcType4aPostCondition()
    {
    }

    public final java.lang.String getJdbcType()
    {
        java.lang.String jdbcType4a = null;
        handleGetJdbcType4aPreCondition();
        jdbcType4a = handleGetJdbcType();
        handleGetJdbcType4aPostCondition();
        return jdbcType4a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlMappings()
    */
    protected abstract org.andromda.core.mapping.Mappings handleGetSqlMappings();

    private void handleGetSqlMappings5aPreCondition()
    {
    }

    private void handleGetSqlMappings5aPostCondition()
    {
    }

    public final org.andromda.core.mapping.Mappings getSqlMappings()
    {
        org.andromda.core.mapping.Mappings sqlMappings5a = null;
        handleGetSqlMappings5aPreCondition();
        sqlMappings5a = handleGetSqlMappings();
        handleGetSqlMappings5aPostCondition();
        return sqlMappings5a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlType()
    */
    protected abstract java.lang.String handleGetSqlType();

    private void handleGetSqlType6aPreCondition()
    {
    }

    private void handleGetSqlType6aPostCondition()
    {
    }

    public final java.lang.String getSqlType()
    {
        java.lang.String sqlType6a = null;
        handleGetSqlType6aPreCondition();
        sqlType6a = handleGetSqlType();
        handleGetSqlType6aPostCondition();
        return sqlType6a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#isIdentifier()
    */
    protected abstract boolean handleIsIdentifier();

    private void handleIsIdentifier7aPreCondition()
    {
    }

    private void handleIsIdentifier7aPostCondition()
    {
    }

    public final boolean isIdentifier()
    {
        boolean identifier7a = false;
        handleIsIdentifier7aPreCondition();
        identifier7a = handleIsIdentifier();
        handleIsIdentifier7aPostCondition();
        return identifier7a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#isUnique()
    */
    protected abstract boolean handleIsUnique();

    private void handleIsUnique8aPreCondition()
    {
    }

    private void handleIsUnique8aPostCondition()
    {
    }

    public final boolean isUnique()
    {
        boolean unique8a = false;
        handleIsUnique8aPreCondition();
        unique8a = handleIsUnique();
        handleIsUnique8aPostCondition();
        return unique8a;
    }

   /**
    * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnIndex()
    */
    protected abstract java.lang.String handleGetColumnIndex();

    private void handleGetColumnIndex9aPreCondition()
    {
    }

    private void handleGetColumnIndex9aPostCondition()
    {
    }

    public final java.lang.String getColumnIndex()
    {
        java.lang.String columnIndex9a = null;
        handleGetColumnIndex9aPreCondition();
        columnIndex9a = handleGetColumnIndex();
        handleGetColumnIndex9aPostCondition();
        return columnIndex9a;
    }

    // ----------- delegates to org.andromda.metafacades.uml.AttributeFacade ------------
    // from org.andromda.metafacades.uml.AttributeFacade
    public java.lang.Object findTaggedValue(java.lang.String name, boolean follow)
    {
        return super_.findTaggedValue(name, follow);
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public java.lang.String getDefaultValue()
    {
        return super_.getDefaultValue();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public org.andromda.metafacades.uml.EnumerationFacade getEnumeration()
    {
        return super_.getEnumeration();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public java.lang.String getEnumerationValue()
    {
        return super_.getEnumerationValue();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public java.lang.String getGetterName()
    {
        return super_.getGetterName();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public org.andromda.metafacades.uml.ClassifierFacade getOwner()
    {
        return super_.getOwner();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public java.lang.String getSetterName()
    {
        return super_.getSetterName();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public org.andromda.metafacades.uml.ClassifierFacade getType()
    {
        return super_.getType();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isAddOnly()
    {
        return super_.isAddOnly();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isChangeable()
    {
        return super_.isChangeable();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isEnumerationLiteral()
    {
        return super_.isEnumerationLiteral();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isMany()
    {
        return super_.isMany();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isReadOnly()
    {
        return super_.isReadOnly();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isRequired()
    {
        return super_.isRequired();
    }

    // from org.andromda.metafacades.uml.AttributeFacade
    public boolean isStatic()
    {
        return super_.isStatic();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        return super_.findTaggedValue(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        return super_.findTaggedValues(tagName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        return super_.getActivityGraphContext();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints()
    {
        return super_.getConstraints();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getConstraints(java.lang.String kind)
    {
        return super_.getConstraints(kind);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        return super_.getDocumentation(indent, lineLength, htmlStyle);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        return super_.getDocumentation(indent, lineLength);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getDocumentation(java.lang.String indent)
    {
        return super_.getDocumentation(indent);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        return super_.getFullyQualifiedName(modelName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedName()
    {
        return super_.getFullyQualifiedName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getFullyQualifiedNamePath()
    {
        return super_.getFullyQualifiedNamePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getId()
    {
        return super_.getId();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.core.mapping.Mappings getLanguageMappings()
    {
        return super_.getLanguageMappings();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelFacade getModel()
    {
        return super_.getModel();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getName()
    {
        return super_.getName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        return super_.getNameSpace();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        return super_.getPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackageName()
    {
        return super_.getPackageName();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getPackagePath()
    {
        return super_.getPackagePath();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        return super_.getRootPackage();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getSourceDependencies()
    {
        return super_.getSourceDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypeNames()
    {
        return super_.getStereotypeNames();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getStereotypes()
    {
        return super_.getStereotypes();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTaggedValues()
    {
        return super_.getTaggedValues();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.util.Collection getTargetDependencies()
    {
        return super_.getTargetDependencies();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String getVisibility()
    {
        return super_.getVisibility();
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        return super_.hasExactStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        return super_.hasStereotype(stereotypeName);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        return super_.translateConstraint(name, translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        return super_.translateConstraints(translation);
    }

    // from org.andromda.metafacades.uml.ModelElementFacade
    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        return super_.translateConstraints(kind, translation);
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationOwner()
     */
    public Object getValidationOwner()
    {
        return super_.getValidationOwner();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#getValidationName()
     */
    public String getValidationName()
    {
        return super_.getValidationName();
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");
        }
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }
        return toString.toString();
    }
}
