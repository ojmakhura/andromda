//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface AssociationEndFacade
       extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public org.andromda.metafacades.uml.AssociationFacade getAssociation();

   /**
    * <p>
    *  Returns the "getter" name for this association end.
    * </p>
    */
    public java.lang.String getGetterName();

   /**
    * 
    */
    public java.lang.String getGetterSetterTypeName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.AssociationEndFacade getOtherEnd();

   /**
    * <p>
    *  Returns the "setter" name for this associaiton end.
    * </p>
    */
    public java.lang.String getSetterName();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * 
    */
    public boolean isAggregation();

   /**
    * 
    */
    public boolean isComposition();

   /**
    * <p>
    *  Returns true if the association end represents a 'many' side of
    *  an association.
    * </p>
    */
    public boolean isMany();

   /**
    * 
    */
    public boolean isMany2Many();

   /**
    * 
    */
    public boolean isMany2One();

   /**
    * 
    */
    public boolean isNavigable();

   /**
    * 
    */
    public boolean isOne2Many();

   /**
    * 
    */
    public boolean isOne2One();

   /**
    * <p>
    *  Returns true if the association end is ordered, false
    *  otherwise.
    * </p>
    */
    public boolean isOrdered();

   /**
    * 
    */
    public boolean isReadOnly();

   /**
    * <p>
    *  Returns true if this association end is required, false
    *  otherwise.
    * </p>
    */
    public boolean isRequired();

}
