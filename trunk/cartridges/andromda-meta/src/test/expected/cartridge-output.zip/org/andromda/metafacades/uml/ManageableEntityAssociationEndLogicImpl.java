package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntityAssociationEnd.
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public class ManageableEntityAssociationEndLogicImpl
    extends ManageableEntityAssociationEndLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityAssociationEndLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getForeignName(org.andromda.metafacades.uml.EntityAttribute)
     */
    protected java.lang.String handleGetForeignName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getForeignGetterName(org.andromda.metafacades.uml.EntityAttribute)
     */
    protected java.lang.String handleGetForeignGetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getForeignSetterName(org.andromda.metafacades.uml.EntityAttribute)
     */
    protected java.lang.String handleGetForeignSetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

}