package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ManageableEntityAssociationEnd.
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public class ManageableEntityAssociationEndLogicImpl
    extends ManageableEntityAssociationEndLogic
{
    // ---------------- constructor -------------------------------

    public ManageableEntityAssociationEndLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudName()
     */
    protected java.lang.String handleGetCrudName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudGetterName()
     */
    protected java.lang.String handleGetCrudGetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudSetterName()
     */
    protected java.lang.String handleGetCrudSetterName()
    {
        // TODO: put your implementation here.
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd#getCrudType()
     */
    protected java.lang.Object handleGetManageableEntityAssociationEnd()
    {
        // TODO: add your implementation here!
        return null;
    }

}