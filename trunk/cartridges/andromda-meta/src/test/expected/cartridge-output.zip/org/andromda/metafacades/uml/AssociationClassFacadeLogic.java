//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AssociationClassFacade
 *
 * @see org.andromda.metafacades.uml.AssociationClassFacade
 */
public abstract class AssociationClassFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.AssociationClassFacade
{

    protected org.omg.uml.foundation.core.AssociationClass metaObject;

    public AssociationClassFacadeLogic(org.omg.uml.foundation.core.AssociationClass metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AssociationClassFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetConnectionAssociationEnds1rPreCondition()
    {
    }

    private void handleGetConnectionAssociationEnds1rPostCondition()
    {
    }

    public final java.util.Collection getConnectionAssociationEnds()
    {
        java.util.Collection getConnectionAssociationEnds1r = null;
        handleGetConnectionAssociationEnds1rPreCondition();
        Object result = this.shieldedElements(handleGetConnectionAssociationEnds());
        try
        {
            getConnectionAssociationEnds1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetConnectionAssociationEnds1rPostCondition();
        return getConnectionAssociationEnds1r;
    }

    protected abstract java.util.Collection handleGetConnectionAssociationEnds();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
}