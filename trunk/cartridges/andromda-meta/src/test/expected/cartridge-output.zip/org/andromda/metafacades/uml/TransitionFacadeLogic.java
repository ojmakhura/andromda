//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TransitionFacade
 *
 * @see org.andromda.metafacades.uml.TransitionFacade
 */
public abstract class TransitionFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.TransitionFacade
{
    protected org.omg.uml.behavioralelements.statemachines.Transition metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public TransitionFacadeLogic (org.omg.uml.behavioralelements.statemachines.Transition metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.TransitionFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.TransitionFacade#isTriggerPresent()
    */
    protected abstract boolean handleIsTriggerPresent();

    private void handleIsTriggerPresent1aPreCondition()
    {
    }

    private void handleIsTriggerPresent1aPostCondition()
    {
    }

    private boolean __triggerPresent1a;
    private boolean __triggerPresent1aSet = false;

    public final boolean isTriggerPresent()
    {
        if (!this.__triggerPresent1aSet)
        {
            handleIsTriggerPresent1aPreCondition();
            this.__triggerPresent1a = handleIsTriggerPresent();
            handleIsTriggerPresent1aPostCondition();
            this.__triggerPresent1aSet = true;
        }
        return this.__triggerPresent1a;
    }

    // ------------- associations ------------------

    private void handleGetEffect1rPreCondition()
    {
    }

    private void handleGetEffect1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActionFacade getEffect()
    {
        handleGetEffect1rPreCondition();
        org.andromda.metafacades.uml.ActionFacade getEffect1r = (org.andromda.metafacades.uml.ActionFacade)shieldedElement(handleGetEffect());
        handleGetEffect1rPostCondition();
        return getEffect1r;
    }

    protected abstract java.lang.Object handleGetEffect();

    private void handleGetTrigger2rPreCondition()
    {
    }

    private void handleGetTrigger2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EventFacade getTrigger()
    {
        handleGetTrigger2rPreCondition();
        org.andromda.metafacades.uml.EventFacade getTrigger2r = (org.andromda.metafacades.uml.EventFacade)shieldedElement(handleGetTrigger());
        handleGetTrigger2rPostCondition();
        return getTrigger2r;
    }

    protected abstract java.lang.Object handleGetTrigger();

    private void handleGetTarget3rPreCondition()
    {
    }

    private void handleGetTarget3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getTarget()
    {
        handleGetTarget3rPreCondition();
        org.andromda.metafacades.uml.StateVertexFacade getTarget3r = (org.andromda.metafacades.uml.StateVertexFacade)shieldedElement(handleGetTarget());
        handleGetTarget3rPostCondition();
        return getTarget3r;
    }

    protected abstract java.lang.Object handleGetTarget();

    private void handleGetSource4rPreCondition()
    {
    }

    private void handleGetSource4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getSource()
    {
        handleGetSource4rPreCondition();
        org.andromda.metafacades.uml.StateVertexFacade getSource4r = (org.andromda.metafacades.uml.StateVertexFacade)shieldedElement(handleGetSource());
        handleGetSource4rPostCondition();
        return getSource4r;
    }

    protected abstract java.lang.Object handleGetSource();

    private void handleGetGuard5rPreCondition()
    {
    }

    private void handleGetGuard5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GuardFacade getGuard()
    {
        handleGetGuard5rPreCondition();
        org.andromda.metafacades.uml.GuardFacade getGuard5r = (org.andromda.metafacades.uml.GuardFacade)shieldedElement(handleGetGuard());
        handleGetGuard5rPostCondition();
        return getGuard5r;
    }

    protected abstract java.lang.Object handleGetGuard();

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");  
        } 
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }      
        return toString.toString();
    }      
}
