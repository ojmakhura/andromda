//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TransitionFacade
 *
 * @see org.andromda.metafacades.uml.TransitionFacade
 */
public abstract class TransitionFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.TransitionFacade
{

    protected org.omg.uml.behavioralelements.statemachines.Transition metaObject;

    public TransitionFacadeLogic(org.omg.uml.behavioralelements.statemachines.Transition metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TransitionFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isTriggerPresent()
    */
    protected abstract boolean handleIsTriggerPresent();

    private void handleIsTriggerPresent1aPreCondition()
    {
    }

    private void handleIsTriggerPresent1aPostCondition()
    {
    }

    private boolean __triggerPresent1a;
    private boolean __triggerPresent1aSet = false;

    public final boolean isTriggerPresent()
    {
        boolean triggerPresent1a = this.__triggerPresent1a;
        if (!this.__triggerPresent1aSet)
        {
            handleIsTriggerPresent1aPreCondition();
            triggerPresent1a = handleIsTriggerPresent();
            handleIsTriggerPresent1aPostCondition();
            this.__triggerPresent1a = triggerPresent1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__triggerPresent1aSet = true;
            }
        }
        return triggerPresent1a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingDecisionPoint()
    */
    protected abstract boolean handleIsExitingDecisionPoint();

    private void handleIsExitingDecisionPoint2aPreCondition()
    {
    }

    private void handleIsExitingDecisionPoint2aPostCondition()
    {
    }

    private boolean __exitingDecisionPoint2a;
    private boolean __exitingDecisionPoint2aSet = false;

    public final boolean isExitingDecisionPoint()
    {
        boolean exitingDecisionPoint2a = this.__exitingDecisionPoint2a;
        if (!this.__exitingDecisionPoint2aSet)
        {
            handleIsExitingDecisionPoint2aPreCondition();
            exitingDecisionPoint2a = handleIsExitingDecisionPoint();
            handleIsExitingDecisionPoint2aPostCondition();
            this.__exitingDecisionPoint2a = exitingDecisionPoint2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exitingDecisionPoint2aSet = true;
            }
        }
        return exitingDecisionPoint2a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringDecisionPoint()
    */
    protected abstract boolean handleIsEnteringDecisionPoint();

    private void handleIsEnteringDecisionPoint3aPreCondition()
    {
    }

    private void handleIsEnteringDecisionPoint3aPostCondition()
    {
    }

    private boolean __enteringDecisionPoint3a;
    private boolean __enteringDecisionPoint3aSet = false;

    public final boolean isEnteringDecisionPoint()
    {
        boolean enteringDecisionPoint3a = this.__enteringDecisionPoint3a;
        if (!this.__enteringDecisionPoint3aSet)
        {
            handleIsEnteringDecisionPoint3aPreCondition();
            enteringDecisionPoint3a = handleIsEnteringDecisionPoint();
            handleIsEnteringDecisionPoint3aPostCondition();
            this.__enteringDecisionPoint3a = enteringDecisionPoint3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enteringDecisionPoint3aSet = true;
            }
        }
        return enteringDecisionPoint3a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingActionState()
    */
    protected abstract boolean handleIsExitingActionState();

    private void handleIsExitingActionState4aPreCondition()
    {
    }

    private void handleIsExitingActionState4aPostCondition()
    {
    }

    private boolean __exitingActionState4a;
    private boolean __exitingActionState4aSet = false;

    public final boolean isExitingActionState()
    {
        boolean exitingActionState4a = this.__exitingActionState4a;
        if (!this.__exitingActionState4aSet)
        {
            handleIsExitingActionState4aPreCondition();
            exitingActionState4a = handleIsExitingActionState();
            handleIsExitingActionState4aPostCondition();
            this.__exitingActionState4a = exitingActionState4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exitingActionState4aSet = true;
            }
        }
        return exitingActionState4a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringActionState()
    */
    protected abstract boolean handleIsEnteringActionState();

    private void handleIsEnteringActionState5aPreCondition()
    {
    }

    private void handleIsEnteringActionState5aPostCondition()
    {
    }

    private boolean __enteringActionState5a;
    private boolean __enteringActionState5aSet = false;

    public final boolean isEnteringActionState()
    {
        boolean enteringActionState5a = this.__enteringActionState5a;
        if (!this.__enteringActionState5aSet)
        {
            handleIsEnteringActionState5aPreCondition();
            enteringActionState5a = handleIsEnteringActionState();
            handleIsEnteringActionState5aPostCondition();
            this.__enteringActionState5a = enteringActionState5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enteringActionState5aSet = true;
            }
        }
        return enteringActionState5a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingInitialState()
    */
    protected abstract boolean handleIsExitingInitialState();

    private void handleIsExitingInitialState6aPreCondition()
    {
    }

    private void handleIsExitingInitialState6aPostCondition()
    {
    }

    private boolean __exitingInitialState6a;
    private boolean __exitingInitialState6aSet = false;

    public final boolean isExitingInitialState()
    {
        boolean exitingInitialState6a = this.__exitingInitialState6a;
        if (!this.__exitingInitialState6aSet)
        {
            handleIsExitingInitialState6aPreCondition();
            exitingInitialState6a = handleIsExitingInitialState();
            handleIsExitingInitialState6aPostCondition();
            this.__exitingInitialState6a = exitingInitialState6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__exitingInitialState6aSet = true;
            }
        }
        return exitingInitialState6a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringFinalState()
    */
    protected abstract boolean handleIsEnteringFinalState();

    private void handleIsEnteringFinalState7aPreCondition()
    {
    }

    private void handleIsEnteringFinalState7aPostCondition()
    {
    }

    private boolean __enteringFinalState7a;
    private boolean __enteringFinalState7aSet = false;

    public final boolean isEnteringFinalState()
    {
        boolean enteringFinalState7a = this.__enteringFinalState7a;
        if (!this.__enteringFinalState7aSet)
        {
            handleIsEnteringFinalState7aPreCondition();
            enteringFinalState7a = handleIsEnteringFinalState();
            handleIsEnteringFinalState7aPostCondition();
            this.__enteringFinalState7a = enteringFinalState7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__enteringFinalState7aSet = true;
            }
        }
        return enteringFinalState7a;
    }

    // ------------- associations ------------------

    private void handleGetEffect1rPreCondition()
    {
    }

    private void handleGetEffect1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActionFacade getEffect()
    {
        org.andromda.metafacades.uml.ActionFacade getEffect1r = null;
        handleGetEffect1rPreCondition();
        Object result = this.shieldedElement(handleGetEffect());
        try
        {
            getEffect1r = (org.andromda.metafacades.uml.ActionFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEffect1rPostCondition();
        return getEffect1r;
    }

    protected abstract java.lang.Object handleGetEffect();

    private void handleGetTrigger2rPreCondition()
    {
    }

    private void handleGetTrigger2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EventFacade getTrigger()
    {
        org.andromda.metafacades.uml.EventFacade getTrigger2r = null;
        handleGetTrigger2rPreCondition();
        Object result = this.shieldedElement(handleGetTrigger());
        try
        {
            getTrigger2r = (org.andromda.metafacades.uml.EventFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTrigger2rPostCondition();
        return getTrigger2r;
    }

    protected abstract java.lang.Object handleGetTrigger();

    private void handleGetTarget3rPreCondition()
    {
    }

    private void handleGetTarget3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getTarget()
    {
        org.andromda.metafacades.uml.StateVertexFacade getTarget3r = null;
        handleGetTarget3rPreCondition();
        Object result = this.shieldedElement(handleGetTarget());
        try
        {
            getTarget3r = (org.andromda.metafacades.uml.StateVertexFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTarget3rPostCondition();
        return getTarget3r;
    }

    protected abstract java.lang.Object handleGetTarget();

    private void handleGetSource4rPreCondition()
    {
    }

    private void handleGetSource4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getSource()
    {
        org.andromda.metafacades.uml.StateVertexFacade getSource4r = null;
        handleGetSource4rPreCondition();
        Object result = this.shieldedElement(handleGetSource());
        try
        {
            getSource4r = (org.andromda.metafacades.uml.StateVertexFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSource4rPostCondition();
        return getSource4r;
    }

    protected abstract java.lang.Object handleGetSource();

    private void handleGetGuard5rPreCondition()
    {
    }

    private void handleGetGuard5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GuardFacade getGuard()
    {
        org.andromda.metafacades.uml.GuardFacade getGuard5r = null;
        handleGetGuard5rPreCondition();
        Object result = this.shieldedElement(handleGetGuard());
        try
        {
            getGuard5r = (org.andromda.metafacades.uml.GuardFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGuard5rPostCondition();
        return getGuard5r;
    }

    protected abstract java.lang.Object handleGetGuard();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}