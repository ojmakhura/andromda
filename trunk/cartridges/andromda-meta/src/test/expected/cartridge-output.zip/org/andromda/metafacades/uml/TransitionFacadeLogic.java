//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TransitionFacade
 *
 * @see org.andromda.metafacades.uml.TransitionFacade
 */
public abstract class TransitionFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.TransitionFacade
{

    protected org.omg.uml.behavioralelements.statemachines.Transition metaObject;

    public TransitionFacadeLogic(org.omg.uml.behavioralelements.statemachines.Transition metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TransitionFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isTriggerPresent()
    */
    protected abstract boolean handleIsTriggerPresent();

    private void handleIsTriggerPresent1aPreCondition()
    {
    }

    private void handleIsTriggerPresent1aPostCondition()
    {
    }

    public final boolean isTriggerPresent()
    {
        boolean triggerPresent1a = false;
        handleIsTriggerPresent1aPreCondition();
        triggerPresent1a = handleIsTriggerPresent();
        handleIsTriggerPresent1aPostCondition();
        return triggerPresent1a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingDecisionPoint()
    */
    protected abstract boolean handleIsExitingDecisionPoint();

    private void handleIsExitingDecisionPoint2aPreCondition()
    {
    }

    private void handleIsExitingDecisionPoint2aPostCondition()
    {
    }

    public final boolean isExitingDecisionPoint()
    {
        boolean exitingDecisionPoint2a = false;
        handleIsExitingDecisionPoint2aPreCondition();
        exitingDecisionPoint2a = handleIsExitingDecisionPoint();
        handleIsExitingDecisionPoint2aPostCondition();
        return exitingDecisionPoint2a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringDecisionPoint()
    */
    protected abstract boolean handleIsEnteringDecisionPoint();

    private void handleIsEnteringDecisionPoint3aPreCondition()
    {
    }

    private void handleIsEnteringDecisionPoint3aPostCondition()
    {
    }

    public final boolean isEnteringDecisionPoint()
    {
        boolean enteringDecisionPoint3a = false;
        handleIsEnteringDecisionPoint3aPreCondition();
        enteringDecisionPoint3a = handleIsEnteringDecisionPoint();
        handleIsEnteringDecisionPoint3aPostCondition();
        return enteringDecisionPoint3a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingActionState()
    */
    protected abstract boolean handleIsExitingActionState();

    private void handleIsExitingActionState4aPreCondition()
    {
    }

    private void handleIsExitingActionState4aPostCondition()
    {
    }

    public final boolean isExitingActionState()
    {
        boolean exitingActionState4a = false;
        handleIsExitingActionState4aPreCondition();
        exitingActionState4a = handleIsExitingActionState();
        handleIsExitingActionState4aPostCondition();
        return exitingActionState4a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringActionState()
    */
    protected abstract boolean handleIsEnteringActionState();

    private void handleIsEnteringActionState5aPreCondition()
    {
    }

    private void handleIsEnteringActionState5aPostCondition()
    {
    }

    public final boolean isEnteringActionState()
    {
        boolean enteringActionState5a = false;
        handleIsEnteringActionState5aPreCondition();
        enteringActionState5a = handleIsEnteringActionState();
        handleIsEnteringActionState5aPostCondition();
        return enteringActionState5a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isExitingInitialState()
    */
    protected abstract boolean handleIsExitingInitialState();

    private void handleIsExitingInitialState6aPreCondition()
    {
    }

    private void handleIsExitingInitialState6aPostCondition()
    {
    }

    public final boolean isExitingInitialState()
    {
        boolean exitingInitialState6a = false;
        handleIsExitingInitialState6aPreCondition();
        exitingInitialState6a = handleIsExitingInitialState();
        handleIsExitingInitialState6aPostCondition();
        return exitingInitialState6a;
    }

   /**
    * @see org.andromda.metafacades.uml.TransitionFacade#isEnteringFinalState()
    */
    protected abstract boolean handleIsEnteringFinalState();

    private void handleIsEnteringFinalState7aPreCondition()
    {
    }

    private void handleIsEnteringFinalState7aPostCondition()
    {
    }

    public final boolean isEnteringFinalState()
    {
        boolean enteringFinalState7a = false;
        handleIsEnteringFinalState7aPreCondition();
        enteringFinalState7a = handleIsEnteringFinalState();
        handleIsEnteringFinalState7aPostCondition();
        return enteringFinalState7a;
    }

    // ------------- associations ------------------

    private void handleGetEffect1rPreCondition()
    {
    }

    private void handleGetEffect1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActionFacade getEffect()
    {
        org.andromda.metafacades.uml.ActionFacade getEffect1r = null;
        handleGetEffect1rPreCondition();
        Object result = this.shieldedElement(handleGetEffect());
        try
        {
            getEffect1r = (org.andromda.metafacades.uml.ActionFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetEffect1rPostCondition();
        return getEffect1r;
    }

    protected abstract java.lang.Object handleGetEffect();

    private void handleGetTrigger2rPreCondition()
    {
    }

    private void handleGetTrigger2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.EventFacade getTrigger()
    {
        org.andromda.metafacades.uml.EventFacade getTrigger2r = null;
        handleGetTrigger2rPreCondition();
        Object result = this.shieldedElement(handleGetTrigger());
        try
        {
            getTrigger2r = (org.andromda.metafacades.uml.EventFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTrigger2rPostCondition();
        return getTrigger2r;
    }

    protected abstract java.lang.Object handleGetTrigger();

    private void handleGetTarget3rPreCondition()
    {
    }

    private void handleGetTarget3rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getTarget()
    {
        org.andromda.metafacades.uml.StateVertexFacade getTarget3r = null;
        handleGetTarget3rPreCondition();
        Object result = this.shieldedElement(handleGetTarget());
        try
        {
            getTarget3r = (org.andromda.metafacades.uml.StateVertexFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTarget3rPostCondition();
        return getTarget3r;
    }

    protected abstract java.lang.Object handleGetTarget();

    private void handleGetSource4rPreCondition()
    {
    }

    private void handleGetSource4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateVertexFacade getSource()
    {
        org.andromda.metafacades.uml.StateVertexFacade getSource4r = null;
        handleGetSource4rPreCondition();
        Object result = this.shieldedElement(handleGetSource());
        try
        {
            getSource4r = (org.andromda.metafacades.uml.StateVertexFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSource4rPostCondition();
        return getSource4r;
    }

    protected abstract java.lang.Object handleGetSource();

    private void handleGetGuard5rPreCondition()
    {
    }

    private void handleGetGuard5rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.GuardFacade getGuard()
    {
        org.andromda.metafacades.uml.GuardFacade getGuard5r = null;
        handleGetGuard5rPreCondition();
        Object result = this.shieldedElement(handleGetGuard());
        try
        {
            getGuard5r = (org.andromda.metafacades.uml.GuardFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetGuard5rPostCondition();
        return getGuard5r;
    }

    protected abstract java.lang.Object handleGetGuard();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
