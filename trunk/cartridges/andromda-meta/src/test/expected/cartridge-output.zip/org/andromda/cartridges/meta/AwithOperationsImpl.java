// license-header java merge-point
/**
 * This is only generated once by PSMmetaclassImpl.vsl! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see AwithOperations
 */
public class AwithOperationsImpl
    extends AwithOperations
{
    /**
     * Public default constructor for AwithOperationsImpl
     */
    public AwithOperationsImpl()
    {
        super();
    }

    /**
     * Public constructor for AwithOperationsImpl with all properties.
     * @param xIn int 
     */
    public AwithOperationsImpl(int x)
    {
        super(x);
    }

    /**
     * Copy-constructor from other AwithOperations
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws NullPointerException if the argument is <code>null</code>
     */
    public AwithOperationsImpl(AwithOperations otherBean)
    {
        this(otherBean.getX());
    }

    /**
     * @see org.andromda.cartridges.meta.AwithOperations#operation1()
     */
    public void operation1()
    {
        // TODO implement public void operation1()
        throw new UnsupportedOperationException("org.andromda.cartridges.meta.AwithOperations.operation1() Not implemented!");
    }

}
