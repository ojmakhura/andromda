package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityAttributeFacade.
 *
 * @see org.andromda.metafacades.uml.EntityAttributeFacade
 */
public class EntityAttributeFacadeLogicImpl
       extends EntityAttributeFacadeLogic
       implements org.andromda.metafacades.uml.EntityAttributeFacade
{
    // ---------------- constructor -------------------------------

    public EntityAttributeFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnLength()
     */
    public java.lang.String handleGetColumnLength() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnName()
     */
    public java.lang.String handleGetColumnName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcMappings()
     */
    public org.andromda.core.mapping.Mappings handleGetJdbcMappings() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcType()
     */
    public java.lang.String handleGetJdbcType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlMappings()
     */
    public org.andromda.core.mapping.Mappings handleGetSqlMappings() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlType()
     */
    public java.lang.String handleGetSqlType() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    
    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#isIdentifier()
     */
    public boolean handleIsIdentifier() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }
    
}
