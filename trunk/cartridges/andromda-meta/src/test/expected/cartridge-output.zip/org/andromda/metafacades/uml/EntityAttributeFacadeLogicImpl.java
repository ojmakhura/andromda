package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.EntityAttributeFacade.
 *
 * @see org.andromda.metafacades.uml.EntityAttributeFacade
 */
public class EntityAttributeFacadeLogicImpl
    extends EntityAttributeFacadeLogic
{
    // ---------------- constructor -------------------------------

    public EntityAttributeFacadeLogicImpl (Object metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnLength()
     */
    protected java.lang.String handleGetColumnLength()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnName()
     */
    protected java.lang.String handleGetColumnName()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcMappings()
     */
    protected org.andromda.core.mapping.Mappings handleGetJdbcMappings()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getJdbcType()
     */
    protected java.lang.String handleGetJdbcType()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlMappings()
     */
    protected org.andromda.core.mapping.Mappings handleGetSqlMappings()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getSqlType()
     */
    protected java.lang.String handleGetSqlType()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#isIdentifier()
     */
    protected boolean handleIsIdentifier()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#isUnique()
     */
    protected boolean handleIsUnique()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.EntityAttributeFacade#getColumnIndex()
     */
    protected java.lang.String handleGetColumnIndex()
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

}
