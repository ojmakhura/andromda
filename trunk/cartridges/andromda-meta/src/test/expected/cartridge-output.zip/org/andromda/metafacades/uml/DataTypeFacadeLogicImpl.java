package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.DataTypeFacade.
 *
 * @see org.andromda.metafacades.uml.DataTypeFacade
 */
public class DataTypeFacadeLogicImpl
       extends DataTypeFacadeLogic
       implements org.andromda.metafacades.uml.DataTypeFacade
{
    // ---------------- constructor -------------------------------

    public DataTypeFacadeLogicImpl (org.omg.uml.foundation.core.DataType metaObject, String context)
    {
        super (metaObject, context);
    }
}
