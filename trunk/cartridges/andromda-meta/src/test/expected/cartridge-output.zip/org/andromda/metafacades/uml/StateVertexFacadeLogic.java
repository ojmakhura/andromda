//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.StateVertexFacade
 *
 * @see org.andromda.metafacades.uml.StateVertexFacade
 */
public abstract class StateVertexFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.StateVertexFacade
{

    protected org.omg.uml.behavioralelements.statemachines.StateVertex metaObject;

    public StateVertexFacadeLogic(org.omg.uml.behavioralelements.statemachines.StateVertex metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateVertexFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetActivityGraph1rPreCondition()
    {
    }

    private void handleGetActivityGraph1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph1r = null;
        handleGetActivityGraph1rPreCondition();
        Object result = this.shieldedElement(handleGetActivityGraph());
        try
        {
            getActivityGraph1r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActivityGraph1rPostCondition();
        return getActivityGraph1r;
    }

    protected abstract java.lang.Object handleGetActivityGraph();

    private void handleGetOutgoing2rPreCondition()
    {
    }

    private void handleGetOutgoing2rPostCondition()
    {
    }

    public final java.util.Collection getOutgoing()
    {
        java.util.Collection getOutgoing2r = null;
        handleGetOutgoing2rPreCondition();
        Object result = this.shieldedElements(handleGetOutgoing());
        try
        {
            getOutgoing2r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOutgoing2rPostCondition();
        return getOutgoing2r;
    }

    protected abstract java.util.Collection handleGetOutgoing();

    private void handleGetIncoming3rPreCondition()
    {
    }

    private void handleGetIncoming3rPostCondition()
    {
    }

    public final java.util.Collection getIncoming()
    {
        java.util.Collection getIncoming3r = null;
        handleGetIncoming3rPreCondition();
        Object result = this.shieldedElements(handleGetIncoming());
        try
        {
            getIncoming3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetIncoming3rPostCondition();
        return getIncoming3r;
    }

    protected abstract java.util.Collection handleGetIncoming();

    private void handleGetContainer4rPreCondition()
    {
    }

    private void handleGetContainer4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.StateFacade getContainer()
    {
        org.andromda.metafacades.uml.StateFacade getContainer4r = null;
        handleGetContainer4rPreCondition();
        Object result = this.shieldedElement(handleGetContainer());
        try
        {
            getContainer4r = (org.andromda.metafacades.uml.StateFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetContainer4rPostCondition();
        return getContainer4r;
    }

    protected abstract java.lang.Object handleGetContainer();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}