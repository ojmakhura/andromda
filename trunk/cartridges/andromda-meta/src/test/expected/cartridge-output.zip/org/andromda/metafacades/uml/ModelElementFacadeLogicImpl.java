package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ModelElementFacade.
 *
 * @see org.andromda.metafacades.uml.ModelElementFacade
 */
public class ModelElementFacadeLogicImpl
       extends ModelElementFacadeLogic
       implements org.andromda.metafacades.uml.ModelElementFacade
{
    // ---------------- constructor -------------------------------

    public ModelElementFacadeLogicImpl (org.omg.uml.foundation.core.ModelElement metaObject, String context)
    {
        super (metaObject, context);
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getVisibility()
     */
    public java.lang.String handleGetVisibility() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackagePath()
     */
    public java.lang.String handleGetPackagePath() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getName()
     */
    public java.lang.String handleGetName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName()
     */
    public java.lang.String handleGetPackageName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName()
     */
    public java.lang.String handleGetFullyQualifiedName() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }
    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedNamePath()
     */
    public java.lang.String handleGetFullyQualifiedNamePath() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValue(java.lang.String)
     */
    public java.lang.Object handleFindTaggedValue(java.lang.String tagName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasStereotype(java.lang.String)
     */
    public boolean handleHasStereotype(java.lang.String stereotypeName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String)
     */
    public java.lang.String handleGetDocumentation(java.lang.String indent) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypeNames()
     */
    public java.util.Collection handleGetStereotypeNames() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName(boolean)
     */
    public java.lang.String handleGetFullyQualifiedName(boolean modelName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getLanguageMappings()
     */
    public org.andromda.core.mapping.Mappings handleGetLanguageMappings() 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String, int)
     */
    public java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDocumentation(java.lang.String, int, boolean)
     */
    public java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#hasExactStereotype(java.lang.String)
     */
    public boolean handleHasExactStereotype(java.lang.String stereotypeName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return false;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraint(java.lang.String, java.lang.String)
     */
    public java.lang.String handleTranslateConstraint(java.lang.String name, java.lang.String translation) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(java.lang.String, java.lang.String)
     */
    public java.lang.String[] handleTranslateConstraints(java.lang.String kind, java.lang.String translation) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#translateConstraints(java.lang.String)
     */
    public java.lang.String[] handleTranslateConstraints(java.lang.String translation) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints(java.lang.String)
     */
    public java.util.Collection handleGetConstraints(java.lang.String kind) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#findTaggedValues(java.lang.String)
     */
    public java.util.Collection handleFindTaggedValues(java.lang.String tagName) 
    {
        // TODO: put your implementation here.

        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getTaggedValues()
     */
    public java.util.Collection handleGetTaggedValues()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getPackage()
     */
    public java.lang.Object handleGetPackage()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getRootPackage()
     */
    public java.lang.Object handleGetRootPackage()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getDependencies()
     */
    public java.util.Collection handleGetDependencies()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getNameSpace()
     */
    public java.lang.Object handleGetNameSpace()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getModel()
     */
    public java.lang.Object handleGetModel()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypes()
     */
    public java.util.Collection handleGetStereotypes()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ModelElementFacade#getConstraints()
     */
    public java.util.Collection handleGetConstraints()
    {
        // TODO: add your implementation here!
        return null;
    }

}
