//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.SubactivityStateFacade
 *
 * @see org.andromda.metafacades.uml.SubactivityStateFacade
 */
public abstract class SubactivityStateFacadeLogic
    extends org.andromda.metafacades.uml.StateFacadeLogicImpl
    implements org.andromda.metafacades.uml.SubactivityStateFacade
{

    protected org.omg.uml.behavioralelements.activitygraphs.SubactivityState metaObject;

    public SubactivityStateFacadeLogic(org.omg.uml.behavioralelements.activitygraphs.SubactivityState metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.SubactivityStateFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.SubactivityStateFacade#isDynamic()
    */
    protected abstract boolean handleIsDynamic();

    private void handleIsDynamic1aPreCondition()
    {
    }

    private void handleIsDynamic1aPostCondition()
    {
    }

    private boolean __dynamic1a;
    private boolean __dynamic1aSet = false;

    public final boolean isDynamic()
    {
        boolean dynamic1a = this.__dynamic1a;
        if (!this.__dynamic1aSet)
        {
            handleIsDynamic1aPreCondition();
            dynamic1a = handleIsDynamic();
            handleIsDynamic1aPostCondition();
            this.__dynamic1a = dynamic1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__dynamic1aSet = true;
            }
        }
        return dynamic1a;
    }

    // ------------- associations ------------------

    private void handleGetSubmachine1rPreCondition()
    {
    }

    private void handleGetSubmachine1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getSubmachine()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getSubmachine1r = null;
        handleGetSubmachine1rPreCondition();
        Object result = this.shieldedElement(handleGetSubmachine());
        try
        {
            getSubmachine1r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSubmachine1rPostCondition();
        return getSubmachine1r;
    }

    protected abstract java.lang.Object handleGetSubmachine();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
