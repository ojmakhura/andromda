//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntity
    extends org.andromda.metafacades.uml.Entity
{

   /**
    * <p>
    *  An attribute from this entity, it will represent this entity
    *  when referenced from another entity. By default this takes the
    *  first unique attribute that is not an identifier. If not found,
    *  it will take the first identifier found, if there would be no
    *  identifiers it will take the first attribute found. In case
    *  nothing is found this property is null.
    * </p>
    */
    public org.andromda.metafacades.uml.ManageableEntityAttribute getDisplayAttribute();

   /**
    * 
    */
    public java.lang.String getFullyQualifiedManageableServiceName();

   /**
    * 
    */
    public java.util.List getManageableAssociationEnds();

   /**
    * 
    */
    public java.util.List getManageableMembers();

   /**
    * 
    */
    public java.lang.String getManageableName();

   /**
    * 
    */
    public java.lang.String getManageablePackageName();

   /**
    * 
    */
    public java.lang.String getManageablePackagePath();

   /**
    * 
    */
    public java.lang.String getManageableServiceAccessorCall();

   /**
    * 
    */
    public java.lang.String getManageableServiceFullPath();

   /**
    * 
    */
    public java.lang.String getManageableServiceName();

   /**
    * 
    */
    public java.util.Collection getReferencingManageables();

   /**
    * 
    */
    public boolean isCreate();

   /**
    * 
    */
    public boolean isDelete();

   /**
    * 
    */
    public boolean isManageable();

   /**
    * 
    */
    public boolean isRead();

   /**
    * 
    */
    public boolean isUpdate();

   /**
    * 
    */
    public java.lang.String listManageableMembers(boolean withTypes);

}