//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntity
    extends org.andromda.metafacades.uml.Entity
{

   /**
    * 
    */
    public java.util.List getAssociatedEntities();

   /**
    * 
    */
    public java.lang.String getCreateControllerName();

   /**
    * 
    */
    public java.lang.String getCreateModelClassName();

   /**
    * 
    */
    public java.lang.String getCrudPackageName();

   /**
    * 
    */
    public java.lang.String getFullCreateControllerPath();

   /**
    * 
    */
    public java.lang.String getServiceAccessorCall();

   /**
    * 
    */
    public boolean isCreate();

   /**
    * 
    */
    public boolean isDelete();

   /**
    * 
    */
    public boolean isRead();

   /**
    * 
    */
    public boolean isUpdate();

}