//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntity
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public abstract class ManageableEntityLogic
    extends org.andromda.metafacades.uml.EntityLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntity
{

    protected Object metaObject;

    public ManageableEntityLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntity";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getFullCreateControllerPath()
    */
    protected abstract java.lang.String handleGetFullCreateControllerPath();

    private void handleGetFullCreateControllerPath1aPreCondition()
    {
    }

    private void handleGetFullCreateControllerPath1aPostCondition()
    {
    }

    private java.lang.String __fullCreateControllerPath1a;
    private boolean __fullCreateControllerPath1aSet = false;

    public final java.lang.String getFullCreateControllerPath()
    {
        java.lang.String fullCreateControllerPath1a = this.__fullCreateControllerPath1a;
        if (!this.__fullCreateControllerPath1aSet)
        {
            handleGetFullCreateControllerPath1aPreCondition();
            fullCreateControllerPath1a = handleGetFullCreateControllerPath();
            handleGetFullCreateControllerPath1aPostCondition();
            this.__fullCreateControllerPath1a = fullCreateControllerPath1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullCreateControllerPath1aSet = true;
            }
        }
        return fullCreateControllerPath1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCreateModelClassName()
    */
    protected abstract java.lang.String handleGetCreateModelClassName();

    private void handleGetCreateModelClassName2aPreCondition()
    {
    }

    private void handleGetCreateModelClassName2aPostCondition()
    {
    }

    private java.lang.String __createModelClassName2a;
    private boolean __createModelClassName2aSet = false;

    public final java.lang.String getCreateModelClassName()
    {
        java.lang.String createModelClassName2a = this.__createModelClassName2a;
        if (!this.__createModelClassName2aSet)
        {
            handleGetCreateModelClassName2aPreCondition();
            createModelClassName2a = handleGetCreateModelClassName();
            handleGetCreateModelClassName2aPostCondition();
            this.__createModelClassName2a = createModelClassName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__createModelClassName2aSet = true;
            }
        }
        return createModelClassName2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCrudPackageName()
    */
    protected abstract java.lang.String handleGetCrudPackageName();

    private void handleGetCrudPackageName3aPreCondition()
    {
    }

    private void handleGetCrudPackageName3aPostCondition()
    {
    }

    private java.lang.String __crudPackageName3a;
    private boolean __crudPackageName3aSet = false;

    public final java.lang.String getCrudPackageName()
    {
        java.lang.String crudPackageName3a = this.__crudPackageName3a;
        if (!this.__crudPackageName3aSet)
        {
            handleGetCrudPackageName3aPreCondition();
            crudPackageName3a = handleGetCrudPackageName();
            handleGetCrudPackageName3aPostCondition();
            this.__crudPackageName3a = crudPackageName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__crudPackageName3aSet = true;
            }
        }
        return crudPackageName3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getCreateControllerName()
    */
    protected abstract java.lang.String handleGetCreateControllerName();

    private void handleGetCreateControllerName4aPreCondition()
    {
    }

    private void handleGetCreateControllerName4aPostCondition()
    {
    }

    private java.lang.String __createControllerName4a;
    private boolean __createControllerName4aSet = false;

    public final java.lang.String getCreateControllerName()
    {
        java.lang.String createControllerName4a = this.__createControllerName4a;
        if (!this.__createControllerName4aSet)
        {
            handleGetCreateControllerName4aPreCondition();
            createControllerName4a = handleGetCreateControllerName();
            handleGetCreateControllerName4aPostCondition();
            this.__createControllerName4a = createControllerName4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__createControllerName4aSet = true;
            }
        }
        return createControllerName4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getServiceAccessorCall()
    */
    protected abstract java.lang.String handleGetServiceAccessorCall();

    private void handleGetServiceAccessorCall5aPreCondition()
    {
    }

    private void handleGetServiceAccessorCall5aPostCondition()
    {
    }

    private java.lang.String __serviceAccessorCall5a;
    private boolean __serviceAccessorCall5aSet = false;

    public final java.lang.String getServiceAccessorCall()
    {
        java.lang.String serviceAccessorCall5a = this.__serviceAccessorCall5a;
        if (!this.__serviceAccessorCall5aSet)
        {
            handleGetServiceAccessorCall5aPreCondition();
            serviceAccessorCall5a = handleGetServiceAccessorCall();
            handleGetServiceAccessorCall5aPostCondition();
            this.__serviceAccessorCall5a = serviceAccessorCall5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__serviceAccessorCall5aSet = true;
            }
        }
        return serviceAccessorCall5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
    */
    protected abstract boolean handleIsRead();

    private void handleIsRead6aPreCondition()
    {
    }

    private void handleIsRead6aPostCondition()
    {
    }

    private boolean __read6a;
    private boolean __read6aSet = false;

    public final boolean isRead()
    {
        boolean read6a = this.__read6a;
        if (!this.__read6aSet)
        {
            handleIsRead6aPreCondition();
            read6a = handleIsRead();
            handleIsRead6aPostCondition();
            this.__read6a = read6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__read6aSet = true;
            }
        }
        return read6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
    */
    protected abstract boolean handleIsCreate();

    private void handleIsCreate7aPreCondition()
    {
    }

    private void handleIsCreate7aPostCondition()
    {
    }

    private boolean __create7a;
    private boolean __create7aSet = false;

    public final boolean isCreate()
    {
        boolean create7a = this.__create7a;
        if (!this.__create7aSet)
        {
            handleIsCreate7aPreCondition();
            create7a = handleIsCreate();
            handleIsCreate7aPostCondition();
            this.__create7a = create7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__create7aSet = true;
            }
        }
        return create7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
    */
    protected abstract boolean handleIsUpdate();

    private void handleIsUpdate8aPreCondition()
    {
    }

    private void handleIsUpdate8aPostCondition()
    {
    }

    private boolean __update8a;
    private boolean __update8aSet = false;

    public final boolean isUpdate()
    {
        boolean update8a = this.__update8a;
        if (!this.__update8aSet)
        {
            handleIsUpdate8aPreCondition();
            update8a = handleIsUpdate();
            handleIsUpdate8aPostCondition();
            this.__update8a = update8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__update8aSet = true;
            }
        }
        return update8a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
    */
    protected abstract boolean handleIsDelete();

    private void handleIsDelete9aPreCondition()
    {
    }

    private void handleIsDelete9aPostCondition()
    {
    }

    private boolean __delete9a;
    private boolean __delete9aSet = false;

    public final boolean isDelete()
    {
        boolean delete9a = this.__delete9a;
        if (!this.__delete9aSet)
        {
            handleIsDelete9aPreCondition();
            delete9a = handleIsDelete();
            handleIsDelete9aPostCondition();
            this.__delete9a = delete9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__delete9aSet = true;
            }
        }
        return delete9a;
    }

    // ------------- associations ------------------

    private void handleGetAssociatedEntities1rPreCondition()
    {
    }

    private void handleGetAssociatedEntities1rPostCondition()
    {
    }

    public final java.util.List getAssociatedEntities()
    {
        java.util.List getAssociatedEntities1r = null;
        handleGetAssociatedEntities1rPreCondition();
        Object result = this.shieldedElements(handleGetAssociatedEntities());
        try
        {
            getAssociatedEntities1r = (java.util.List)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAssociatedEntities1rPostCondition();
        return getAssociatedEntities1r;
    }

    protected abstract java.util.Collection handleGetAssociatedEntities();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}