//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntity
 *
 * @see org.andromda.metafacades.uml.ManageableEntity
 */
public abstract class ManageableEntityLogic
    extends org.andromda.metafacades.uml.EntityLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntity
{

    protected Object metaObject;

    public ManageableEntityLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntity";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageablePackageName()
    */
    protected abstract java.lang.String handleGetManageablePackageName();

    private void handleGetManageablePackageName1aPreCondition()
    {
    }

    private void handleGetManageablePackageName1aPostCondition()
    {
    }

    private java.lang.String __manageablePackageName1a;
    private boolean __manageablePackageName1aSet = false;

    public final java.lang.String getManageablePackageName()
    {
        java.lang.String manageablePackageName1a = this.__manageablePackageName1a;
        if (!this.__manageablePackageName1aSet)
        {
            handleGetManageablePackageName1aPreCondition();
            manageablePackageName1a = handleGetManageablePackageName();
            handleGetManageablePackageName1aPostCondition();
            this.__manageablePackageName1a = manageablePackageName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageablePackageName1aSet = true;
            }
        }
        return manageablePackageName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceAccessorCall()
    */
    protected abstract java.lang.String handleGetManageableServiceAccessorCall();

    private void handleGetManageableServiceAccessorCall2aPreCondition()
    {
    }

    private void handleGetManageableServiceAccessorCall2aPostCondition()
    {
    }

    private java.lang.String __manageableServiceAccessorCall2a;
    private boolean __manageableServiceAccessorCall2aSet = false;

    public final java.lang.String getManageableServiceAccessorCall()
    {
        java.lang.String manageableServiceAccessorCall2a = this.__manageableServiceAccessorCall2a;
        if (!this.__manageableServiceAccessorCall2aSet)
        {
            handleGetManageableServiceAccessorCall2aPreCondition();
            manageableServiceAccessorCall2a = handleGetManageableServiceAccessorCall();
            handleGetManageableServiceAccessorCall2aPostCondition();
            this.__manageableServiceAccessorCall2a = manageableServiceAccessorCall2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableServiceAccessorCall2aSet = true;
            }
        }
        return manageableServiceAccessorCall2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isRead()
    */
    protected abstract boolean handleIsRead();

    private void handleIsRead3aPreCondition()
    {
    }

    private void handleIsRead3aPostCondition()
    {
    }

    private boolean __read3a;
    private boolean __read3aSet = false;

    public final boolean isRead()
    {
        boolean read3a = this.__read3a;
        if (!this.__read3aSet)
        {
            handleIsRead3aPreCondition();
            read3a = handleIsRead();
            handleIsRead3aPostCondition();
            this.__read3a = read3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__read3aSet = true;
            }
        }
        return read3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isCreate()
    */
    protected abstract boolean handleIsCreate();

    private void handleIsCreate4aPreCondition()
    {
    }

    private void handleIsCreate4aPostCondition()
    {
    }

    private boolean __create4a;
    private boolean __create4aSet = false;

    public final boolean isCreate()
    {
        boolean create4a = this.__create4a;
        if (!this.__create4aSet)
        {
            handleIsCreate4aPreCondition();
            create4a = handleIsCreate();
            handleIsCreate4aPostCondition();
            this.__create4a = create4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__create4aSet = true;
            }
        }
        return create4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isUpdate()
    */
    protected abstract boolean handleIsUpdate();

    private void handleIsUpdate5aPreCondition()
    {
    }

    private void handleIsUpdate5aPostCondition()
    {
    }

    private boolean __update5a;
    private boolean __update5aSet = false;

    public final boolean isUpdate()
    {
        boolean update5a = this.__update5a;
        if (!this.__update5aSet)
        {
            handleIsUpdate5aPreCondition();
            update5a = handleIsUpdate();
            handleIsUpdate5aPostCondition();
            this.__update5a = update5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__update5aSet = true;
            }
        }
        return update5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isDelete()
    */
    protected abstract boolean handleIsDelete();

    private void handleIsDelete6aPreCondition()
    {
    }

    private void handleIsDelete6aPostCondition()
    {
    }

    private boolean __delete6a;
    private boolean __delete6aSet = false;

    public final boolean isDelete()
    {
        boolean delete6a = this.__delete6a;
        if (!this.__delete6aSet)
        {
            handleIsDelete6aPreCondition();
            delete6a = handleIsDelete();
            handleIsDelete6aPostCondition();
            this.__delete6a = delete6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__delete6aSet = true;
            }
        }
        return delete6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageablePackagePath()
    */
    protected abstract java.lang.String handleGetManageablePackagePath();

    private void handleGetManageablePackagePath7aPreCondition()
    {
    }

    private void handleGetManageablePackagePath7aPostCondition()
    {
    }

    private java.lang.String __manageablePackagePath7a;
    private boolean __manageablePackagePath7aSet = false;

    public final java.lang.String getManageablePackagePath()
    {
        java.lang.String manageablePackagePath7a = this.__manageablePackagePath7a;
        if (!this.__manageablePackagePath7aSet)
        {
            handleGetManageablePackagePath7aPreCondition();
            manageablePackagePath7a = handleGetManageablePackagePath();
            handleGetManageablePackagePath7aPostCondition();
            this.__manageablePackagePath7a = manageablePackagePath7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageablePackagePath7aSet = true;
            }
        }
        return manageablePackagePath7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceName()
    */
    protected abstract java.lang.String handleGetManageableServiceName();

    private void handleGetManageableServiceName8aPreCondition()
    {
    }

    private void handleGetManageableServiceName8aPostCondition()
    {
    }

    private java.lang.String __manageableServiceName8a;
    private boolean __manageableServiceName8aSet = false;

    public final java.lang.String getManageableServiceName()
    {
        java.lang.String manageableServiceName8a = this.__manageableServiceName8a;
        if (!this.__manageableServiceName8aSet)
        {
            handleGetManageableServiceName8aPreCondition();
            manageableServiceName8a = handleGetManageableServiceName();
            handleGetManageableServiceName8aPostCondition();
            this.__manageableServiceName8a = manageableServiceName8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableServiceName8aSet = true;
            }
        }
        return manageableServiceName8a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getFullyQualifiedManageableServiceName()
    */
    protected abstract java.lang.String handleGetFullyQualifiedManageableServiceName();

    private void handleGetFullyQualifiedManageableServiceName9aPreCondition()
    {
    }

    private void handleGetFullyQualifiedManageableServiceName9aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedManageableServiceName9a;
    private boolean __fullyQualifiedManageableServiceName9aSet = false;

    public final java.lang.String getFullyQualifiedManageableServiceName()
    {
        java.lang.String fullyQualifiedManageableServiceName9a = this.__fullyQualifiedManageableServiceName9a;
        if (!this.__fullyQualifiedManageableServiceName9aSet)
        {
            handleGetFullyQualifiedManageableServiceName9aPreCondition();
            fullyQualifiedManageableServiceName9a = handleGetFullyQualifiedManageableServiceName();
            handleGetFullyQualifiedManageableServiceName9aPostCondition();
            this.__fullyQualifiedManageableServiceName9a = fullyQualifiedManageableServiceName9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullyQualifiedManageableServiceName9aSet = true;
            }
        }
        return fullyQualifiedManageableServiceName9a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageableServiceFullPath()
    */
    protected abstract java.lang.String handleGetManageableServiceFullPath();

    private void handleGetManageableServiceFullPath10aPreCondition()
    {
    }

    private void handleGetManageableServiceFullPath10aPostCondition()
    {
    }

    private java.lang.String __manageableServiceFullPath10a;
    private boolean __manageableServiceFullPath10aSet = false;

    public final java.lang.String getManageableServiceFullPath()
    {
        java.lang.String manageableServiceFullPath10a = this.__manageableServiceFullPath10a;
        if (!this.__manageableServiceFullPath10aSet)
        {
            handleGetManageableServiceFullPath10aPreCondition();
            manageableServiceFullPath10a = handleGetManageableServiceFullPath();
            handleGetManageableServiceFullPath10aPostCondition();
            this.__manageableServiceFullPath10a = manageableServiceFullPath10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableServiceFullPath10aSet = true;
            }
        }
        return manageableServiceFullPath10a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getManageableMembers()
    */
    protected abstract java.util.List handleGetManageableMembers();

    private void handleGetManageableMembers11aPreCondition()
    {
    }

    private void handleGetManageableMembers11aPostCondition()
    {
    }

    private java.util.List __manageableMembers11a;
    private boolean __manageableMembers11aSet = false;

    public final java.util.List getManageableMembers()
    {
        java.util.List manageableMembers11a = this.__manageableMembers11a;
        if (!this.__manageableMembers11aSet)
        {
            handleGetManageableMembers11aPreCondition();
            manageableMembers11a = handleGetManageableMembers();
            handleGetManageableMembers11aPostCondition();
            this.__manageableMembers11a = manageableMembers11a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageableMembers11aSet = true;
            }
        }
        return manageableMembers11a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isManageable()
    */
    protected abstract boolean handleIsManageable();

    private void handleIsManageable12aPreCondition()
    {
    }

    private void handleIsManageable12aPostCondition()
    {
    }

    private boolean __manageable12a;
    private boolean __manageable12aSet = false;

    public final boolean isManageable()
    {
        boolean manageable12a = this.__manageable12a;
        if (!this.__manageable12aSet)
        {
            handleIsManageable12aPreCondition();
            manageable12a = handleIsManageable();
            handleIsManageable12aPostCondition();
            this.__manageable12a = manageable12a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__manageable12aSet = true;
            }
        }
        return manageable12a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getMaximumListSize()
    */
    protected abstract int handleGetMaximumListSize();

    private void handleGetMaximumListSize13aPreCondition()
    {
    }

    private void handleGetMaximumListSize13aPostCondition()
    {
    }

    private int __maximumListSize13a;
    private boolean __maximumListSize13aSet = false;

    public final int getMaximumListSize()
    {
        int maximumListSize13a = this.__maximumListSize13a;
        if (!this.__maximumListSize13aSet)
        {
            handleGetMaximumListSize13aPreCondition();
            maximumListSize13a = handleGetMaximumListSize();
            handleGetMaximumListSize13aPostCondition();
            this.__maximumListSize13a = maximumListSize13a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__maximumListSize13aSet = true;
            }
        }
        return maximumListSize13a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#getPageSize()
    */
    protected abstract int handleGetPageSize();

    private void handleGetPageSize14aPreCondition()
    {
    }

    private void handleGetPageSize14aPostCondition()
    {
    }

    private int __pageSize14a;
    private boolean __pageSize14aSet = false;

    public final int getPageSize()
    {
        int pageSize14a = this.__pageSize14a;
        if (!this.__pageSize14aSet)
        {
            handleGetPageSize14aPreCondition();
            pageSize14a = handleGetPageSize();
            handleGetPageSize14aPostCondition();
            this.__pageSize14a = pageSize14a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__pageSize14aSet = true;
            }
        }
        return pageSize14a;
    }

   /**
    * @see org.andromda.metafacades.uml.ManageableEntity#isResolveable()
    */
    protected abstract boolean handleIsResolveable();

    private void handleIsResolveable15aPreCondition()
    {
    }

    private void handleIsResolveable15aPostCondition()
    {
    }

    private boolean __resolveable15a;
    private boolean __resolveable15aSet = false;

    public final boolean isResolveable()
    {
        boolean resolveable15a = this.__resolveable15a;
        if (!this.__resolveable15aSet)
        {
            handleIsResolveable15aPreCondition();
            resolveable15a = handleIsResolveable();
            handleIsResolveable15aPostCondition();
            this.__resolveable15a = resolveable15a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__resolveable15aSet = true;
            }
        }
        return resolveable15a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleListManageableMembers(boolean withTypes);

    private void handleListManageableMembers1oPreCondition()
    {
    }

    private void handleListManageableMembers1oPostCondition()
    {
    }

    public java.lang.String listManageableMembers(boolean withTypes)
    {
        handleListManageableMembers1oPreCondition();
        java.lang.String returnValue = handleListManageableMembers(withTypes);
        handleListManageableMembers1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetManageableAssociationEnds1rPreCondition()
    {
    }

    private void handleGetManageableAssociationEnds1rPostCondition()
    {
    }

    private java.util.List __getManageableAssociationEnds1r;
    private boolean __getManageableAssociationEnds1rSet = false;

    public final java.util.List getManageableAssociationEnds()
    {
        java.util.List getManageableAssociationEnds1r = this.__getManageableAssociationEnds1r;
        if (!this.__getManageableAssociationEnds1rSet)
        {
            handleGetManageableAssociationEnds1rPreCondition();
            Object result = this.shieldedElements(handleGetManageableAssociationEnds());
            try
            {
                getManageableAssociationEnds1r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetManageableAssociationEnds1rPostCondition();
            this.__getManageableAssociationEnds1r = getManageableAssociationEnds1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getManageableAssociationEnds1rSet = true;
            }
        }
        return getManageableAssociationEnds1r;
    }

    protected abstract java.util.Collection handleGetManageableAssociationEnds();

    private void handleGetReferencingManageables2rPreCondition()
    {
    }

    private void handleGetReferencingManageables2rPostCondition()
    {
    }

    public final java.util.List getReferencingManageables()
    {
        java.util.List getReferencingManageables2r = null;
        handleGetReferencingManageables2rPreCondition();
        Object result = this.shieldedElements(handleGetReferencingManageables());
        try
        {
            getReferencingManageables2r = (java.util.List)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetReferencingManageables2rPostCondition();
        return getReferencingManageables2r;
    }

    protected abstract java.util.Collection handleGetReferencingManageables();

    private void handleGetDisplayAttribute4rPreCondition()
    {
    }

    private void handleGetDisplayAttribute4rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.ManageableEntityAttribute __getDisplayAttribute4r;
    private boolean __getDisplayAttribute4rSet = false;

    public final org.andromda.metafacades.uml.ManageableEntityAttribute getDisplayAttribute()
    {
        org.andromda.metafacades.uml.ManageableEntityAttribute getDisplayAttribute4r = this.__getDisplayAttribute4r;
        if (!this.__getDisplayAttribute4rSet)
        {
            handleGetDisplayAttribute4rPreCondition();
            Object result = this.shieldedElement(handleGetDisplayAttribute());
            try
            {
                getDisplayAttribute4r = (org.andromda.metafacades.uml.ManageableEntityAttribute)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetDisplayAttribute4rPostCondition();
            this.__getDisplayAttribute4r = getDisplayAttribute4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getDisplayAttribute4rSet = true;
            }
        }
        return getDisplayAttribute4r;
    }

    protected abstract java.lang.Object handleGetDisplayAttribute();

    private void handleGetUsers5rPreCondition()
    {
    }

    private void handleGetUsers5rPostCondition()
    {
    }

    private java.util.List __getUsers5r;
    private boolean __getUsers5rSet = false;

    public final java.util.List getUsers()
    {
        java.util.List getUsers5r = this.__getUsers5r;
        if (!this.__getUsers5rSet)
        {
            handleGetUsers5rPreCondition();
            Object result = this.shieldedElements(handleGetUsers());
            try
            {
                getUsers5r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetUsers5rPostCondition();
            this.__getUsers5r = getUsers5r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getUsers5rSet = true;
            }
        }
        return getUsers5r;
    }

    protected abstract java.util.Collection handleGetUsers();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}