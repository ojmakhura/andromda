//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.AssociationFacade
 *
 * @see org.andromda.metafacades.uml.AssociationFacade
 */
public abstract class AssociationFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.AssociationFacade
{

    protected org.omg.uml.foundation.core.UmlAssociation metaObject;

    public AssociationFacadeLogic(org.omg.uml.foundation.core.UmlAssociation metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.AssociationFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.AssociationFacade#getRelationName()
    */
    protected abstract java.lang.String handleGetRelationName();

    private void handleGetRelationName1aPreCondition()
    {
    }

    private void handleGetRelationName1aPostCondition()
    {
    }

    private java.lang.String __relationName1a;
    private boolean __relationName1aSet = false;

    public final java.lang.String getRelationName()
    {
        java.lang.String relationName1a = this.__relationName1a;
        if (!this.__relationName1aSet)
        {
            handleGetRelationName1aPreCondition();
            relationName1a = handleGetRelationName();
            handleGetRelationName1aPostCondition();
            this.__relationName1a = relationName1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__relationName1aSet = true;
            }
        }
        return relationName1a;
    }

   /**
    * @see org.andromda.metafacades.uml.AssociationFacade#isMany2Many()
    */
    protected abstract boolean handleIsMany2Many();

    private void handleIsMany2Many2aPreCondition()
    {
    }

    private void handleIsMany2Many2aPostCondition()
    {
    }

    private boolean __many2Many2a;
    private boolean __many2Many2aSet = false;

    public final boolean isMany2Many()
    {
        boolean many2Many2a = this.__many2Many2a;
        if (!this.__many2Many2aSet)
        {
            handleIsMany2Many2aPreCondition();
            many2Many2a = handleIsMany2Many();
            handleIsMany2Many2aPostCondition();
            this.__many2Many2a = many2Many2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__many2Many2aSet = true;
            }
        }
        return many2Many2a;
    }

    // ------------- associations ------------------

    private void handleGetAssociationEnds1rPreCondition()
    {
    }

    private void handleGetAssociationEnds1rPostCondition()
    {
    }

    public final java.util.List getAssociationEnds()
    {
        java.util.List getAssociationEnds1r = null;
        handleGetAssociationEnds1rPreCondition();
        Object result = this.shieldedElements(handleGetAssociationEnds());
        try
        {
            getAssociationEnds1r = (java.util.List)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAssociationEnds1rPostCondition();
        return getAssociationEnds1r;
    }

    protected abstract java.util.Collection handleGetAssociationEnds();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
