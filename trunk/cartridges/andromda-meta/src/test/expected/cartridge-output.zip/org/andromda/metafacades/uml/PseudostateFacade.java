//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface PseudostateFacade
       extends org.andromda.metafacades.uml.StateVertexFacade
{

   /**
    * 
    */
    public boolean isChoice();

   /**
    * 
    */
    public boolean isDecisionPoint();

   /**
    * 
    */
    public boolean isDeepHistory();

   /**
    * 
    */
    public boolean isFork();

   /**
    * 
    */
    public boolean isInitialState();

   /**
    * 
    */
    public boolean isJoin();

   /**
    * 
    */
    public boolean isJunction();

   /**
    * 
    */
    public boolean isMergePoint();

   /**
    * 
    */
    public boolean isShallowHistory();

}
