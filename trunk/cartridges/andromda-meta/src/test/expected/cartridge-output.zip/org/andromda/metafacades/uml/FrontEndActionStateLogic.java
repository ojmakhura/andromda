//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.FrontEndActionState
 *
 * @see org.andromda.metafacades.uml.FrontEndActionState
 */
public abstract class FrontEndActionStateLogic
    extends org.andromda.metafacades.uml.ActionStateFacadeLogicImpl
    implements org.andromda.metafacades.uml.FrontEndActionState
{

    protected Object metaObject;

    public FrontEndActionStateLogic(Object metaObject, String context)
    {
        super((org.omg.uml.behavioralelements.activitygraphs.ActionState)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.FrontEndActionState";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.FrontEndActionState#isServerSide()
    */
    protected abstract boolean handleIsServerSide();

    private void handleIsServerSide1aPreCondition()
    {
    }

    private void handleIsServerSide1aPostCondition()
    {
    }

    private boolean __serverSide1a;
    private boolean __serverSide1aSet = false;

    public final boolean isServerSide()
    {
        boolean serverSide1a = this.__serverSide1a;
        if (!this.__serverSide1aSet)
        {
            handleIsServerSide1aPreCondition();
            serverSide1a = handleIsServerSide();
            handleIsServerSide1aPostCondition();
            this.__serverSide1a = serverSide1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__serverSide1aSet = true;
            }
        }
        return serverSide1a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndActionState#isContainedInFrontEndUseCase()
    */
    protected abstract boolean handleIsContainedInFrontEndUseCase();

    private void handleIsContainedInFrontEndUseCase2aPreCondition()
    {
    }

    private void handleIsContainedInFrontEndUseCase2aPostCondition()
    {
    }

    private boolean __containedInFrontEndUseCase2a;
    private boolean __containedInFrontEndUseCase2aSet = false;

    public final boolean isContainedInFrontEndUseCase()
    {
        boolean containedInFrontEndUseCase2a = this.__containedInFrontEndUseCase2a;
        if (!this.__containedInFrontEndUseCase2aSet)
        {
            handleIsContainedInFrontEndUseCase2aPreCondition();
            containedInFrontEndUseCase2a = handleIsContainedInFrontEndUseCase();
            handleIsContainedInFrontEndUseCase2aPostCondition();
            this.__containedInFrontEndUseCase2a = containedInFrontEndUseCase2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__containedInFrontEndUseCase2aSet = true;
            }
        }
        return containedInFrontEndUseCase2a;
    }

   /**
    * @see org.andromda.metafacades.uml.FrontEndActionState#getActionMethodName()
    */
    protected abstract java.lang.String handleGetActionMethodName();

    private void handleGetActionMethodName3aPreCondition()
    {
    }

    private void handleGetActionMethodName3aPostCondition()
    {
    }

    private java.lang.String __actionMethodName3a;
    private boolean __actionMethodName3aSet = false;

    public final java.lang.String getActionMethodName()
    {
        java.lang.String actionMethodName3a = this.__actionMethodName3a;
        if (!this.__actionMethodName3aSet)
        {
            handleGetActionMethodName3aPreCondition();
            actionMethodName3a = handleGetActionMethodName();
            handleGetActionMethodName3aPostCondition();
            this.__actionMethodName3a = actionMethodName3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__actionMethodName3aSet = true;
            }
        }
        return actionMethodName3a;
    }

    // ------------- associations ------------------

    private void handleGetForward1rPreCondition()
    {
    }

    private void handleGetForward1rPostCondition()
    {
    }

    private org.andromda.metafacades.uml.FrontEndForward __getForward1r;
    private boolean __getForward1rSet = false;

    public final org.andromda.metafacades.uml.FrontEndForward getForward()
    {
        org.andromda.metafacades.uml.FrontEndForward getForward1r = this.__getForward1r;
        if (!this.__getForward1rSet)
        {
            handleGetForward1rPreCondition();
            Object result = this.shieldedElement(handleGetForward());
            try
            {
                getForward1r = (org.andromda.metafacades.uml.FrontEndForward)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetForward1rPostCondition();
            this.__getForward1r = getForward1r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getForward1rSet = true;
            }
        }
        return getForward1r;
    }

    protected abstract java.lang.Object handleGetForward();

    private void handleGetControllerCalls2rPreCondition()
    {
    }

    private void handleGetControllerCalls2rPostCondition()
    {
    }

    private java.util.List __getControllerCalls2r;
    private boolean __getControllerCalls2rSet = false;

    public final java.util.List getControllerCalls()
    {
        java.util.List getControllerCalls2r = this.__getControllerCalls2r;
        if (!this.__getControllerCalls2rSet)
        {
            handleGetControllerCalls2rPreCondition();
            Object result = this.shieldedElements(handleGetControllerCalls());
            try
            {
                getControllerCalls2r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetControllerCalls2rPostCondition();
            this.__getControllerCalls2r = getControllerCalls2r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getControllerCalls2rSet = true;
            }
        }
        return getControllerCalls2r;
    }

    protected abstract java.util.List handleGetControllerCalls();

    private void handleGetExceptions3rPreCondition()
    {
    }

    private void handleGetExceptions3rPostCondition()
    {
    }

    private java.util.List __getExceptions3r;
    private boolean __getExceptions3rSet = false;

    public final java.util.List getExceptions()
    {
        java.util.List getExceptions3r = this.__getExceptions3r;
        if (!this.__getExceptions3rSet)
        {
            handleGetExceptions3rPreCondition();
            Object result = this.shieldedElements(handleGetExceptions());
            try
            {
                getExceptions3r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetExceptions3rPostCondition();
            this.__getExceptions3r = getExceptions3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getExceptions3rSet = true;
            }
        }
        return getExceptions3r;
    }

    protected abstract java.util.List handleGetExceptions();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}