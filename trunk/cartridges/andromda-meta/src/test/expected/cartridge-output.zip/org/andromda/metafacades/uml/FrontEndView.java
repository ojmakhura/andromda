//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a view within a front end application.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndView
    extends org.andromda.metafacades.uml.FrontEndActionState
{

   /**
    * <p>
    *  All actions that can be triggered on this view.
    * </p>
    */
    public java.util.List getActions();

   /**
    * <p>
    *  The use-case of which this view is a member.
    * </p>
    */
    public org.andromda.metafacades.uml.FrontEndUseCase getUseCase();

   /**
    * <p>
    *  True if this element carries the FrontEndView stereotype.
    * </p>
    */
    public boolean isFrontEndView();

}