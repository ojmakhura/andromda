//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents a view within a front end application.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface FrontEndView
    extends org.andromda.metafacades.uml.FrontEndActionState
{

   /**
    * <p>
    *  True if this element carries the FrontEndView stereotype.
    * </p>
    */
    public boolean isFrontEndView();

}