//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Represents an association end of an entity.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface EntityAssociationEndFacade
       extends org.andromda.metafacades.uml.AssociationEndFacade
{

   /**
    * <p>
    *  Gets the name of the column that makes up the foreign key.
    * </p>
    */
    public java.lang.String getColumnName();

   /**
    * <p>
    *  Gets the current foreign key suffix specified for this entity
    *  association end facade.
    * </p>
    */
    public java.lang.String getForeignKeySuffix();

}
