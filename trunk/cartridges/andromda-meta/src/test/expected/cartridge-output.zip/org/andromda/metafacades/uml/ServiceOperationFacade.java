//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * <p>
 *  Reprsents an operation of a service.
 * </p>
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ServiceOperationFacade
       extends org.andromda.metafacades.uml.OperationFacade
{

   /**
    * <p>
    *  The users of the service operation, these are the actor's that
    *  can access this operation.
    * </p>
    */
    public java.util.Collection getRoles();

   /**
    * <p>
    *  Stores the transaction type associated with this service
    *  operation (if one exists).
    * </p>
    */
    public java.lang.String getTransactionType();

}
