//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAssociationEnd
 */
public abstract class ManageableEntityAssociationEndLogic
    extends org.andromda.metafacades.uml.EntityAssociationEndLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAssociationEnd
{

    protected Object metaObject;

    public ManageableEntityAssociationEndLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAssociationEnd";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetForeignName(org.andromda.metafacades.uml.EntityAttribute attribute);

    private void handleGetForeignName1oPreCondition()
    {
    }

    private void handleGetForeignName1oPostCondition()
    {
    }

    public java.lang.String getForeignName(org.andromda.metafacades.uml.EntityAttribute attribute)
    {
        handleGetForeignName1oPreCondition();
        java.lang.String returnValue = handleGetForeignName(attribute);
        handleGetForeignName1oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetForeignGetterName(org.andromda.metafacades.uml.EntityAttribute attribute);

    private void handleGetForeignGetterName2oPreCondition()
    {
    }

    private void handleGetForeignGetterName2oPostCondition()
    {
    }

    public java.lang.String getForeignGetterName(org.andromda.metafacades.uml.EntityAttribute attribute)
    {
        handleGetForeignGetterName2oPreCondition();
        java.lang.String returnValue = handleGetForeignGetterName(attribute);
        handleGetForeignGetterName2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetForeignSetterName(org.andromda.metafacades.uml.EntityAttribute attribute);

    private void handleGetForeignSetterName3oPreCondition()
    {
    }

    private void handleGetForeignSetterName3oPostCondition()
    {
    }

    public java.lang.String getForeignSetterName(org.andromda.metafacades.uml.EntityAttribute attribute)
    {
        handleGetForeignSetterName3oPreCondition();
        java.lang.String returnValue = handleGetForeignSetterName(attribute);
        handleGetForeignSetterName3oPostCondition();
        return returnValue;
    }

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}