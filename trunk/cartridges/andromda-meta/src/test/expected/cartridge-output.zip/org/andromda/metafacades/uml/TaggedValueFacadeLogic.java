//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TaggedValueFacade
 *
 * @see org.andromda.metafacades.uml.TaggedValueFacade
 */
public abstract class TaggedValueFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.TaggedValueFacade
{

    protected org.omg.uml.foundation.core.TaggedValue metaObject;

    public TaggedValueFacadeLogic(org.omg.uml.foundation.core.TaggedValue metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TaggedValueFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.TaggedValueFacade#getValue()
    */
    protected abstract java.lang.Object handleGetValue();

    private void handleGetValue1aPreCondition()
    {
    }

    private void handleGetValue1aPostCondition()
    {
    }

    private java.lang.Object __value1a;
    private boolean __value1aSet = false;

    public final java.lang.Object getValue()
    {
        java.lang.Object value1a = this.__value1a;
        if (!this.__value1aSet)
        {
            handleGetValue1aPreCondition();
            value1a = handleGetValue();
            handleGetValue1aPostCondition();
            this.__value1a = value1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__value1aSet = true;
            }
        }
        return value1a;
    }

   /**
    * @see org.andromda.metafacades.uml.TaggedValueFacade#getValues()
    */
    protected abstract java.util.Collection handleGetValues();

    private void handleGetValues2aPreCondition()
    {
    }

    private void handleGetValues2aPostCondition()
    {
    }

    private java.util.Collection __values2a;
    private boolean __values2aSet = false;

    public final java.util.Collection getValues()
    {
        java.util.Collection values2a = this.__values2a;
        if (!this.__values2aSet)
        {
            handleGetValues2aPreCondition();
            values2a = handleGetValues();
            handleGetValues2aPostCondition();
            this.__values2a = values2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__values2aSet = true;
            }
        }
        return values2a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}