//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.TaggedValueFacade
 *
 * @see org.andromda.metafacades.uml.TaggedValueFacade
 */
public abstract class TaggedValueFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.TaggedValueFacade
{

    protected org.omg.uml.foundation.core.TaggedValue metaObject;

    public TaggedValueFacadeLogic(org.omg.uml.foundation.core.TaggedValue metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.TaggedValueFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.TaggedValueFacade#getValue()
    */
    protected abstract java.lang.Object handleGetValue();

    private void handleGetValue1aPreCondition()
    {
    }

    private void handleGetValue1aPostCondition()
    {
    }

    public final java.lang.Object getValue()
    {
        java.lang.Object value1a = null;
        handleGetValue1aPreCondition();
        value1a = handleGetValue();
        handleGetValue1aPostCondition();
        return value1a;
    }

   /**
    * @see org.andromda.metafacades.uml.TaggedValueFacade#getValues()
    */
    protected abstract java.util.Collection handleGetValues();

    private void handleGetValues2aPreCondition()
    {
    }

    private void handleGetValues2aPostCondition()
    {
    }

    public final java.util.Collection getValues()
    {
        java.util.Collection values2a = null;
        handleGetValues2aPreCondition();
        values2a = handleGetValues();
        handleGetValues2aPostCondition();
        return values2a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.util.Collection handleFormatHTMLStringAsParagraphs();

    private void handleFormatHTMLStringAsParagraphs1oPreCondition()
    {
    }

    private void handleFormatHTMLStringAsParagraphs1oPostCondition()
    {
    }

    public java.util.Collection formatHTMLStringAsParagraphs()
    {
        handleFormatHTMLStringAsParagraphs1oPreCondition();
        java.util.Collection returnValue = handleFormatHTMLStringAsParagraphs();
        handleFormatHTMLStringAsParagraphs1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}
