//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelFacade
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public abstract class ModelFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ModelFacade
{
    protected org.omg.uml.UmlPackage metaObject;

    public ModelFacadeLogic (org.omg.uml.UmlPackage metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ModelFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetRootPackage1rPreCondition()
    {
    }

    private void handleGetRootPackage1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        handleGetRootPackage1rPreCondition();
        org.andromda.metafacades.uml.PackageFacade getRootPackage1r = (org.andromda.metafacades.uml.PackageFacade)shieldedElement(handleGetRootPackage());
        handleGetRootPackage1rPostCondition();
        return getRootPackage1r;
    }

    protected abstract java.lang.Object handleGetRootPackage();

    private void handleGetAllUseCases2rPreCondition()
    {
    }

    private void handleGetAllUseCases2rPostCondition()
    {
    }

    public final java.util.Collection getAllUseCases()
    {
        handleGetAllUseCases2rPreCondition();
        java.util.Collection getAllUseCases2r = shieldedElements(handleGetAllUseCases());
        handleGetAllUseCases2rPostCondition();
        return getAllUseCases2r;
    }

    protected abstract java.util.Collection handleGetAllUseCases();

    private void handleGetAllActionStates4rPreCondition()
    {
    }

    private void handleGetAllActionStates4rPostCondition()
    {
    }

    public final java.util.Collection getAllActionStates()
    {
        handleGetAllActionStates4rPreCondition();
        java.util.Collection getAllActionStates4r = shieldedElements(handleGetAllActionStates());
        handleGetAllActionStates4rPostCondition();
        return getAllActionStates4r;
    }

    protected abstract java.util.Collection handleGetAllActionStates();

    private void handleGetAllActors5rPreCondition()
    {
    }

    private void handleGetAllActors5rPostCondition()
    {
    }

    public final java.util.Collection getAllActors()
    {
        handleGetAllActors5rPreCondition();
        java.util.Collection getAllActors5r = shieldedElements(handleGetAllActors());
        handleGetAllActors5rPostCondition();
        return getAllActors5r;
    }

    protected abstract java.util.Collection handleGetAllActors();

    private void handleGetAllFinalStates6rPreCondition()
    {
    }

    private void handleGetAllFinalStates6rPostCondition()
    {
    }

    public final java.util.Collection getAllFinalStates()
    {
        handleGetAllFinalStates6rPreCondition();
        java.util.Collection getAllFinalStates6r = shieldedElements(handleGetAllFinalStates());
        handleGetAllFinalStates6rPostCondition();
        return getAllFinalStates6r;
    }

    protected abstract java.util.Collection handleGetAllFinalStates();

    private void handleGetAllActivityGraphs7rPreCondition()
    {
    }

    private void handleGetAllActivityGraphs7rPostCondition()
    {
    }

    public final java.util.Collection getAllActivityGraphs()
    {
        handleGetAllActivityGraphs7rPreCondition();
        java.util.Collection getAllActivityGraphs7r = shieldedElements(handleGetAllActivityGraphs());
        handleGetAllActivityGraphs7rPostCondition();
        return getAllActivityGraphs7r;
    }

    protected abstract java.util.Collection handleGetAllActivityGraphs();

    private void handleGetAllTransitions8rPreCondition()
    {
    }

    private void handleGetAllTransitions8rPostCondition()
    {
    }

    public final java.util.Collection getAllTransitions()
    {
        handleGetAllTransitions8rPreCondition();
        java.util.Collection getAllTransitions8r = shieldedElements(handleGetAllTransitions());
        handleGetAllTransitions8rPostCondition();
        return getAllTransitions8r;
    }

    protected abstract java.util.Collection handleGetAllTransitions();

    private void handleGetAllOperations9rPreCondition()
    {
    }

    private void handleGetAllOperations9rPostCondition()
    {
    }

    public final java.util.Collection getAllOperations()
    {
        handleGetAllOperations9rPreCondition();
        java.util.Collection getAllOperations9r = shieldedElements(handleGetAllOperations());
        handleGetAllOperations9rPostCondition();
        return getAllOperations9r;
    }

    protected abstract java.util.Collection handleGetAllOperations();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        String name = this.getFullyQualifiedName(true);
        toString.append("[");
        toString.append(name);
        toString.append("]");
        return toString.toString();
    }      
}
