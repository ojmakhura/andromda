//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelFacade
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public abstract class ModelFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.ModelFacade
{

    protected org.omg.uml.UmlPackage metaObject;

    public ModelFacadeLogic(org.omg.uml.UmlPackage metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ModelFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value);

    private void handleFindUseCaseWithTaggedValueOrHyperlink1oPreCondition()
    {
    }

    private void handleFindUseCaseWithTaggedValueOrHyperlink1oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value)
    {
        handleFindUseCaseWithTaggedValueOrHyperlink1oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseWithTaggedValueOrHyperlink(tag, value);
        handleFindUseCaseWithTaggedValueOrHyperlink1oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ClassifierFacade handleFindClassWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value);

    private void handleFindClassWithTaggedValueOrHyperlink2oPreCondition()
    {
    }

    private void handleFindClassWithTaggedValueOrHyperlink2oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ClassifierFacade findClassWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value)
    {
        handleFindClassWithTaggedValueOrHyperlink2oPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade returnValue = handleFindClassWithTaggedValueOrHyperlink(tag, value);
        handleFindClassWithTaggedValueOrHyperlink2oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByName(java.lang.String name);

    private void handleFindActivityGraphByName3oPreCondition()
    {
    }

    private void handleFindActivityGraphByName3oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade findActivityGraphByName(java.lang.String name)
    {
        handleFindActivityGraphByName3oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleFindActivityGraphByName(name);
        handleFindActivityGraphByName3oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByNameAndStereotype(java.lang.String name, java.lang.String stereotypeName);

    private void handleFindActivityGraphByNameAndStereotype4oPreCondition()
    {
    }

    private void handleFindActivityGraphByNameAndStereotype4oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade findActivityGraphByNameAndStereotype(java.lang.String name, java.lang.String stereotypeName)
    {
        handleFindActivityGraphByNameAndStereotype4oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleFindActivityGraphByNameAndStereotype(name, stereotypeName);
        handleFindActivityGraphByNameAndStereotype4oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseByName(java.lang.String name);

    private void handleFindUseCaseByName5oPreCondition()
    {
    }

    private void handleFindUseCaseByName5oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseByName(java.lang.String name)
    {
        handleFindUseCaseByName5oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseByName(name);
        handleFindUseCaseByName5oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithNameAndStereotype(java.lang.String name, java.lang.String stereotypeName);

    private void handleFindUseCaseWithNameAndStereotype6oPreCondition()
    {
    }

    private void handleFindUseCaseWithNameAndStereotype6oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseWithNameAndStereotype(java.lang.String name, java.lang.String stereotypeName)
    {
        handleFindUseCaseWithNameAndStereotype6oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseWithNameAndStereotype(name, stereotypeName);
        handleFindUseCaseWithNameAndStereotype6oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleFindFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade useCase);

    private void handleFindFinalStatesWithNameOrHyperlink7oPreCondition()
    {
    }

    private void handleFindFinalStatesWithNameOrHyperlink7oPostCondition()
    {
    }

    public java.util.Collection findFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade useCase)
    {
        handleFindFinalStatesWithNameOrHyperlink7oPreCondition();
        java.util.Collection returnValue = handleFindFinalStatesWithNameOrHyperlink(useCase);
        handleFindFinalStatesWithNameOrHyperlink7oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph, java.lang.String stereotypeName);

    private void handleGetAllActionStatesWithStereotype8oPreCondition()
    {
    }

    private void handleGetAllActionStatesWithStereotype8oPostCondition()
    {
    }

    public java.util.Collection getAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph, java.lang.String stereotypeName)
    {
        handleGetAllActionStatesWithStereotype8oPreCondition();
        java.util.Collection returnValue = handleGetAllActionStatesWithStereotype(activityGraph, stereotypeName);
        handleGetAllActionStatesWithStereotype8oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetRootPackage1rPreCondition()
    {
    }

    private void handleGetRootPackage1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        org.andromda.metafacades.uml.PackageFacade getRootPackage1r = null;
        handleGetRootPackage1rPreCondition();
        Object result = this.shieldedElement(handleGetRootPackage());
        try
        {
            getRootPackage1r = (org.andromda.metafacades.uml.PackageFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetRootPackage1rPostCondition();
        return getRootPackage1r;
    }

    protected abstract java.lang.Object handleGetRootPackage();

    private void handleGetAllActors3rPreCondition()
    {
    }

    private void handleGetAllActors3rPostCondition()
    {
    }

    public final java.util.Collection getAllActors()
    {
        java.util.Collection getAllActors3r = null;
        handleGetAllActors3rPreCondition();
        Object result = this.shieldedElements(handleGetAllActors());
        try
        {
            getAllActors3r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllActors3rPostCondition();
        return getAllActors3r;
    }

    protected abstract java.util.Collection handleGetAllActors();

    private void handleGetAllUseCases4rPreCondition()
    {
    }

    private void handleGetAllUseCases4rPostCondition()
    {
    }

    public final java.util.Collection getAllUseCases()
    {
        java.util.Collection getAllUseCases4r = null;
        handleGetAllUseCases4rPreCondition();
        Object result = this.shieldedElements(handleGetAllUseCases());
        try
        {
            getAllUseCases4r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllUseCases4rPostCondition();
        return getAllUseCases4r;
    }

    protected abstract java.util.Collection handleGetAllUseCases();

    private void handleGetAllActionStates5rPreCondition()
    {
    }

    private void handleGetAllActionStates5rPostCondition()
    {
    }

    public final java.util.Collection getAllActionStates()
    {
        java.util.Collection getAllActionStates5r = null;
        handleGetAllActionStates5rPreCondition();
        Object result = this.shieldedElements(handleGetAllActionStates());
        try
        {
            getAllActionStates5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetAllActionStates5rPostCondition();
        return getAllActionStates5r;
    }

    protected abstract java.util.Collection handleGetAllActionStates();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}