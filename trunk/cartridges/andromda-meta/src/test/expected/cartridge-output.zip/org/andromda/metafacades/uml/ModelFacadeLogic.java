//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelFacade
 *
 * @see org.andromda.metafacades.uml.ModelFacade
 */
public abstract class ModelFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ModelFacade
{
    protected org.omg.uml.UmlPackage metaObject;

    public ModelFacadeLogic (org.omg.uml.UmlPackage metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ModelFacade";
        }
        return context;
    }

    // ---------------- business methods ----------------------

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleGetUseCase(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph);

    private void handleGetUseCase1oPreCondition()
    {
    }

    private void handleGetUseCase1oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade getUseCase(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph)
    {
        handleGetUseCase1oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleGetUseCase(activityGraph);
        handleGetUseCase1oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleGetActivityGraph(org.andromda.metafacades.uml.UseCaseFacade useCase);

    private void handleGetActivityGraph2oPreCondition()
    {
    }

    private void handleGetActivityGraph2oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraph(org.andromda.metafacades.uml.UseCaseFacade useCase)
    {
        handleGetActivityGraph2oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleGetActivityGraph(useCase);
        handleGetActivityGraph2oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value);

    private void handleFindUseCaseWithTaggedValueOrHyperlink3oPreCondition()
    {
    }

    private void handleFindUseCaseWithTaggedValueOrHyperlink3oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value)
    {
        handleFindUseCaseWithTaggedValueOrHyperlink3oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseWithTaggedValueOrHyperlink(tag, value);
        handleFindUseCaseWithTaggedValueOrHyperlink3oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ClassifierFacade handleFindClassWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value);

    private void handleFindClassWithTaggedValueOrHyperlink4oPreCondition()
    {
    }

    private void handleFindClassWithTaggedValueOrHyperlink4oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ClassifierFacade findClassWithTaggedValueOrHyperlink(java.lang.String tag, java.lang.String value)
    {
        handleFindClassWithTaggedValueOrHyperlink4oPreCondition();
        org.andromda.metafacades.uml.ClassifierFacade returnValue = handleFindClassWithTaggedValueOrHyperlink(tag, value);
        handleFindClassWithTaggedValueOrHyperlink4oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleGetActivityGraphContext(org.andromda.metafacades.uml.ModelElementFacade modelElement);

    private void handleGetActivityGraphContext5oPreCondition()
    {
    }

    private void handleGetActivityGraphContext5oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext(org.andromda.metafacades.uml.ModelElementFacade modelElement)
    {
        handleGetActivityGraphContext5oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleGetActivityGraphContext(modelElement);
        handleGetActivityGraphContext5oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByName(java.lang.String name);

    private void handleFindActivityGraphByName6oPreCondition()
    {
    }

    private void handleFindActivityGraphByName6oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade findActivityGraphByName(java.lang.String name)
    {
        handleFindActivityGraphByName6oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleFindActivityGraphByName(name);
        handleFindActivityGraphByName6oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.ActivityGraphFacade handleFindActivityGraphByNameAndStereotype(java.lang.String name, java.lang.String stereotypeName);

    private void handleFindActivityGraphByNameAndStereotype7oPreCondition()
    {
    }

    private void handleFindActivityGraphByNameAndStereotype7oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.ActivityGraphFacade findActivityGraphByNameAndStereotype(java.lang.String name, java.lang.String stereotypeName)
    {
        handleFindActivityGraphByNameAndStereotype7oPreCondition();
        org.andromda.metafacades.uml.ActivityGraphFacade returnValue = handleFindActivityGraphByNameAndStereotype(name, stereotypeName);
        handleFindActivityGraphByNameAndStereotype7oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseByName(java.lang.String name);

    private void handleFindUseCaseByName8oPreCondition()
    {
    }

    private void handleFindUseCaseByName8oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseByName(java.lang.String name)
    {
        handleFindUseCaseByName8oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseByName(name);
        handleFindUseCaseByName8oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.UseCaseFacade handleFindUseCaseWithNameAndStereotype(java.lang.String name, java.lang.String stereotypeName);

    private void handleFindUseCaseWithNameAndStereotype9oPreCondition()
    {
    }

    private void handleFindUseCaseWithNameAndStereotype9oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.UseCaseFacade findUseCaseWithNameAndStereotype(java.lang.String name, java.lang.String stereotypeName)
    {
        handleFindUseCaseWithNameAndStereotype9oPreCondition();
        org.andromda.metafacades.uml.UseCaseFacade returnValue = handleFindUseCaseWithNameAndStereotype(name, stereotypeName);
        handleFindUseCaseWithNameAndStereotype9oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.TransitionFacade handleGetParameterTransition(org.andromda.metafacades.uml.ParameterFacade parameter);

    private void handleGetParameterTransition10oPreCondition()
    {
    }

    private void handleGetParameterTransition10oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.TransitionFacade getParameterTransition(org.andromda.metafacades.uml.ParameterFacade parameter)
    {
        handleGetParameterTransition10oPreCondition();
        org.andromda.metafacades.uml.TransitionFacade returnValue = handleGetParameterTransition(parameter);
        handleGetParameterTransition10oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.TransitionFacade handleGetEventTransition(org.andromda.metafacades.uml.EventFacade event);

    private void handleGetEventTransition11oPreCondition()
    {
    }

    private void handleGetEventTransition11oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.TransitionFacade getEventTransition(org.andromda.metafacades.uml.EventFacade event)
    {
        handleGetEventTransition11oPreCondition();
        org.andromda.metafacades.uml.TransitionFacade returnValue = handleGetEventTransition(event);
        handleGetEventTransition11oPostCondition();
        return returnValue;
    }

    protected abstract org.andromda.metafacades.uml.OperationFacade handleGetParameterOperation(org.andromda.metafacades.uml.ParameterFacade parameter);

    private void handleGetParameterOperation12oPreCondition()
    {
    }

    private void handleGetParameterOperation12oPostCondition()
    {
    }

    public org.andromda.metafacades.uml.OperationFacade getParameterOperation(org.andromda.metafacades.uml.ParameterFacade parameter)
    {
        handleGetParameterOperation12oPreCondition();
        org.andromda.metafacades.uml.OperationFacade returnValue = handleGetParameterOperation(parameter);
        handleGetParameterOperation12oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleFindFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade useCase);

    private void handleFindFinalStatesWithNameOrHyperlink13oPreCondition()
    {
    }

    private void handleFindFinalStatesWithNameOrHyperlink13oPostCondition()
    {
    }

    public java.util.Collection findFinalStatesWithNameOrHyperlink(org.andromda.metafacades.uml.UseCaseFacade useCase)
    {
        handleFindFinalStatesWithNameOrHyperlink13oPreCondition();
        java.util.Collection returnValue = handleFindFinalStatesWithNameOrHyperlink(useCase);
        handleFindFinalStatesWithNameOrHyperlink13oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph, java.lang.String stereotypeName);

    private void handleGetAllActionStatesWithStereotype14oPreCondition()
    {
    }

    private void handleGetAllActionStatesWithStereotype14oPostCondition()
    {
    }

    public java.util.Collection getAllActionStatesWithStereotype(org.andromda.metafacades.uml.ActivityGraphFacade activityGraph, java.lang.String stereotypeName)
    {
        handleGetAllActionStatesWithStereotype14oPreCondition();
        java.util.Collection returnValue = handleGetAllActionStatesWithStereotype(activityGraph, stereotypeName);
        handleGetAllActionStatesWithStereotype14oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetRootPackage1rPreCondition()
    {
    }

    private void handleGetRootPackage1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        handleGetRootPackage1rPreCondition();
        org.andromda.metafacades.uml.PackageFacade getRootPackage1r = (org.andromda.metafacades.uml.PackageFacade)shieldedElement(handleGetRootPackage());
        handleGetRootPackage1rPostCondition();
        return getRootPackage1r;
    }

    protected abstract java.lang.Object handleGetRootPackage();

    private void handleGetAllActors3rPreCondition()
    {
    }

    private void handleGetAllActors3rPostCondition()
    {
    }

    public final java.util.Collection getAllActors()
    {
        handleGetAllActors3rPreCondition();
        java.util.Collection getAllActors3r = shieldedElements(handleGetAllActors());
        handleGetAllActors3rPostCondition();
        return getAllActors3r;
    }

    protected abstract java.util.Collection handleGetAllActors();

    private void handleGetAllUseCases4rPreCondition()
    {
    }

    private void handleGetAllUseCases4rPostCondition()
    {
    }

    public final java.util.Collection getAllUseCases()
    {
        handleGetAllUseCases4rPreCondition();
        java.util.Collection getAllUseCases4r = shieldedElements(handleGetAllUseCases());
        handleGetAllUseCases4rPostCondition();
        return getAllUseCases4r;
    }

    protected abstract java.util.Collection handleGetAllUseCases();

    private void handleGetAllActionStates5rPreCondition()
    {
    }

    private void handleGetAllActionStates5rPostCondition()
    {
    }

    public final java.util.Collection getAllActionStates()
    {
        handleGetAllActionStates5rPreCondition();
        java.util.Collection getAllActionStates5r = shieldedElements(handleGetAllActionStates());
        handleGetAllActionStates5rPostCondition();
        return getAllActionStates5r;
    }

    protected abstract java.util.Collection handleGetAllActionStates();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        try
        {
            toString.append("[");
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
            toString.append("]");  
        } 
        catch (Throwable th)
        {
             // Just ignore when the metafacade doesn't have a name property
        }      
        return toString.toString();
    }      
}
