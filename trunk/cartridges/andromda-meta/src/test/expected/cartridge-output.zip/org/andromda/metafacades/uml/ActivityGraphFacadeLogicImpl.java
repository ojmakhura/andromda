package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActivityGraphFacade.
 *
 * @see org.andromda.metafacades.uml.ActivityGraphFacade
 */
public class ActivityGraphFacadeLogicImpl
       extends ActivityGraphFacadeLogic
       implements org.andromda.metafacades.uml.ActivityGraphFacade
{
    // ---------------- constructor -------------------------------

    public ActivityGraphFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getPseudostates()
     */
    public java.util.Collection handleGetPseudostates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getActionStates()
     */
    public java.util.Collection handleGetActionStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getObjectFlowStates()
     */
    public java.util.Collection handleGetObjectFlowStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getInitialStates()
     */
    public java.util.Collection handleGetInitialStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getFinalStates()
     */
    public java.util.Collection handleGetFinalStates()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getContextElement()
     */
    public java.lang.Object handleGetContextElement()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getTransitions()
     */
    public java.util.Collection handleGetTransitions()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getUseCase()
     */
    public java.lang.Object handleGetUseCase()
    {
        // TODO: add your implementation here!
        return null;
    }

}
