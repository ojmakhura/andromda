package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ActivityGraphFacade.
 *
 * @see org.andromda.metafacades.uml.ActivityGraphFacade
 */
public class ActivityGraphFacadeLogicImpl
    extends ActivityGraphFacadeLogic
{
    // ---------------- constructor -------------------------------

    public ActivityGraphFacadeLogicImpl (org.omg.uml.behavioralelements.activitygraphs.ActivityGraph metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getPseudostates()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getActionStates()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getObjectFlowStates()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getInitialStates()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getFinalStates()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getContextElement()
     */
    protected java.lang.Object handleGetActivityGraphContext()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getTransitions()
     */
    protected java.util.Collection handleGetActivityGraphFacade()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getUseCase()
     */
    protected java.lang.Object handleGetFirstActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ActivityGraphFacade#getPartitions()
     */
    protected java.util.Collection handleGetActivityGraph()
    {
        // TODO: add your implementation here!
        return null;
    }

}