//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ActorFacade
       extends org.andromda.metafacades.uml.ClassifierFacade
{

   /**
    * <p>
    *  The actors generalized by this actor.
    * </p>
    */
    public java.util.Collection getGeneralizedActors();

   /**
    * <p>
    *  The actors that generalize this actor.
    * </p>
    */
    public java.util.Collection getGeneralizedByActors();

}
