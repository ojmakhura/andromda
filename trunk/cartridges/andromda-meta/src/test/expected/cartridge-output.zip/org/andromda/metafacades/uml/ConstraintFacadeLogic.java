//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ConstraintFacade
 *
 * @see org.andromda.metafacades.uml.ConstraintFacade
 */
public abstract class ConstraintFacadeLogic
    extends org.andromda.metafacades.uml.ModelElementFacadeLogicImpl
    implements org.andromda.metafacades.uml.ConstraintFacade
{

    protected org.omg.uml.foundation.core.Constraint metaObject;

    public ConstraintFacadeLogic(org.omg.uml.foundation.core.Constraint metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ConstraintFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#getBody()
    */
    protected abstract java.lang.String handleGetBody();

    private void handleGetBody1aPreCondition()
    {
    }

    private void handleGetBody1aPostCondition()
    {
    }

    private java.lang.String __body1a;
    private boolean __body1aSet = false;

    public final java.lang.String getBody()
    {
        java.lang.String body1a = this.__body1a;
        if (!this.__body1aSet)
        {
            handleGetBody1aPreCondition();
            body1a = handleGetBody();
            handleGetBody1aPostCondition();
            this.__body1a = body1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__body1aSet = true;
            }
        }
        return body1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#isInvariant()
    */
    protected abstract boolean handleIsInvariant();

    private void handleIsInvariant2aPreCondition()
    {
    }

    private void handleIsInvariant2aPostCondition()
    {
    }

    private boolean __invariant2a;
    private boolean __invariant2aSet = false;

    public final boolean isInvariant()
    {
        boolean invariant2a = this.__invariant2a;
        if (!this.__invariant2aSet)
        {
            handleIsInvariant2aPreCondition();
            invariant2a = handleIsInvariant();
            handleIsInvariant2aPostCondition();
            this.__invariant2a = invariant2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__invariant2aSet = true;
            }
        }
        return invariant2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#isPreCondition()
    */
    protected abstract boolean handleIsPreCondition();

    private void handleIsPreCondition3aPreCondition()
    {
    }

    private void handleIsPreCondition3aPostCondition()
    {
    }

    private boolean __preCondition3a;
    private boolean __preCondition3aSet = false;

    public final boolean isPreCondition()
    {
        boolean preCondition3a = this.__preCondition3a;
        if (!this.__preCondition3aSet)
        {
            handleIsPreCondition3aPreCondition();
            preCondition3a = handleIsPreCondition();
            handleIsPreCondition3aPostCondition();
            this.__preCondition3a = preCondition3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__preCondition3aSet = true;
            }
        }
        return preCondition3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#isPostCondition()
    */
    protected abstract boolean handleIsPostCondition();

    private void handleIsPostCondition4aPreCondition()
    {
    }

    private void handleIsPostCondition4aPostCondition()
    {
    }

    private boolean __postCondition4a;
    private boolean __postCondition4aSet = false;

    public final boolean isPostCondition()
    {
        boolean postCondition4a = this.__postCondition4a;
        if (!this.__postCondition4aSet)
        {
            handleIsPostCondition4aPreCondition();
            postCondition4a = handleIsPostCondition();
            handleIsPostCondition4aPostCondition();
            this.__postCondition4a = postCondition4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__postCondition4aSet = true;
            }
        }
        return postCondition4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#isDefinition()
    */
    protected abstract boolean handleIsDefinition();

    private void handleIsDefinition5aPreCondition()
    {
    }

    private void handleIsDefinition5aPostCondition()
    {
    }

    private boolean __definition5a;
    private boolean __definition5aSet = false;

    public final boolean isDefinition()
    {
        boolean definition5a = this.__definition5a;
        if (!this.__definition5aSet)
        {
            handleIsDefinition5aPreCondition();
            definition5a = handleIsDefinition();
            handleIsDefinition5aPostCondition();
            this.__definition5a = definition5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__definition5aSet = true;
            }
        }
        return definition5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ConstraintFacade#isBodyExpression()
    */
    protected abstract boolean handleIsBodyExpression();

    private void handleIsBodyExpression6aPreCondition()
    {
    }

    private void handleIsBodyExpression6aPostCondition()
    {
    }

    private boolean __bodyExpression6a;
    private boolean __bodyExpression6aSet = false;

    public final boolean isBodyExpression()
    {
        boolean bodyExpression6a = this.__bodyExpression6a;
        if (!this.__bodyExpression6aSet)
        {
            handleIsBodyExpression6aPreCondition();
            bodyExpression6a = handleIsBodyExpression();
            handleIsBodyExpression6aPostCondition();
            this.__bodyExpression6a = bodyExpression6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__bodyExpression6aSet = true;
            }
        }
        return bodyExpression6a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetTranslation(java.lang.String language);

    private void handleGetTranslation1oPreCondition()
    {
    }

    private void handleGetTranslation1oPostCondition()
    {
    }

    public java.lang.String getTranslation(java.lang.String language)
    {
        handleGetTranslation1oPreCondition();
        java.lang.String returnValue = handleGetTranslation(language);
        handleGetTranslation1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetContextElement1rPreCondition()
    {
    }

    private void handleGetContextElement1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getContextElement()
    {
        org.andromda.metafacades.uml.ModelElementFacade getContextElement1r = null;
        handleGetContextElement1rPreCondition();
        Object result = this.shieldedElement(handleGetContextElement());
        try
        {
            getContextElement1r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetContextElement1rPostCondition();
        return getContextElement1r;
    }

    protected abstract java.lang.Object handleGetContextElement();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }
    
    /**
     * The property that stores the name of the metafacade.
     */
    private static final String NAME_PROPERTY = "name";
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        final StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.andromda.core.common.Introspector.instance().getProperty(this, NAME_PROPERTY));
        }
        catch (final Throwable throwable)
        {
            // - just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}