//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ConstraintFacade
 *
 * @see org.andromda.metafacades.uml.ConstraintFacade
 */
public abstract class ConstraintFacadeLogic
       extends        org.andromda.core.metafacade.MetafacadeBase
       implements     org.andromda.metafacades.uml.ConstraintFacade
{
    protected org.omg.uml.foundation.core.Constraint metaObject;
    private org.andromda.metafacades.uml.ModelElementFacade super_;

    public ConstraintFacadeLogic (org.omg.uml.foundation.core.Constraint metaObject, String context) 
    {
        super (metaObject, getContext(context));
        this.super_ =
           (org.andromda.metafacades.uml.ModelElementFacade)
            org.andromda.core.metafacade.MetafacadeFactory
                .getInstance()
                .createFacadeImpl(
                    "org.andromda.metafacades.uml.ModelElementFacade",
                    metaObject,
                    getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context) 
    {
    	if (context == null) {
            context = "org.andromda.metafacades.uml.ConstraintFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------
    
   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#getBody()
    */
    protected abstract java.lang.String handleGetBody();

    private void handleGetBody1aPreCondition()
    {
    }

    private void handleGetBody1aPostCondition()
    {
    }

    private java.lang.String __body1a;
    private boolean __body1aSet = false;

    public final java.lang.String getBody()
    {
        if (!this.__body1aSet)
        {
            handleGetBody1aPreCondition();
            this.__body1a = handleGetBody();
            handleGetBody1aPostCondition();
            this.__body1aSet = true;
        }
        return this.__body1a;
    }

   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#isInvariant()
    */
    protected abstract boolean handleIsInvariant();

    private void handleIsInvariant2aPreCondition()
    {
    }

    private void handleIsInvariant2aPostCondition()
    {
    }

    public final boolean isInvariant()
    {
        handleIsInvariant2aPreCondition();
        boolean invariant2a = handleIsInvariant();
        handleIsInvariant2aPostCondition();
        return invariant2a;
    }

   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#isPreCondition()
    */
    protected abstract boolean handleIsPreCondition();

    private void handleIsPreCondition3aPreCondition()
    {
    }

    private void handleIsPreCondition3aPostCondition()
    {
    }

    public final boolean isPreCondition()
    {
        handleIsPreCondition3aPreCondition();
        boolean preCondition3a = handleIsPreCondition();
        handleIsPreCondition3aPostCondition();
        return preCondition3a;
    }

   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#isPostCondition()
    */
    protected abstract boolean handleIsPostCondition();

    private void handleIsPostCondition4aPreCondition()
    {
    }

    private void handleIsPostCondition4aPostCondition()
    {
    }

    public final boolean isPostCondition()
    {
        handleIsPostCondition4aPreCondition();
        boolean postCondition4a = handleIsPostCondition();
        handleIsPostCondition4aPostCondition();
        return postCondition4a;
    }

   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#isDefinition()
    */
    protected abstract boolean handleIsDefinition();

    private void handleIsDefinition5aPreCondition()
    {
    }

    private void handleIsDefinition5aPostCondition()
    {
    }

    public final boolean isDefinition()
    {
        handleIsDefinition5aPreCondition();
        boolean definition5a = handleIsDefinition();
        handleIsDefinition5aPostCondition();
        return definition5a;
    }

   /**
	* @see org.andromda.metafacades.uml.ConstraintFacade#isBodyExpression()
    */
    protected abstract boolean handleIsBodyExpression();

    private void handleIsBodyExpression6aPreCondition()
    {
    }

    private void handleIsBodyExpression6aPostCondition()
    {
    }

    public final boolean isBodyExpression()
    {
        handleIsBodyExpression6aPreCondition();
        boolean bodyExpression6a = handleIsBodyExpression();
        handleIsBodyExpression6aPostCondition();
        return bodyExpression6a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.String handleGetTranslation(java.lang.String language);

    private void handleGetTranslation1oPreCondition()
    {
    }

    private void handleGetTranslation1oPostCondition()
    {
    }

    public java.lang.String getTranslation(java.lang.String language)
    {
        handleGetTranslation1oPreCondition();
        java.lang.String returnValue = handleGetTranslation(language);
        handleGetTranslation1oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetContextElement1rPreCondition()
    {
    }

    private void handleGetContextElement1rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getContextElement()
    {
        handleGetContextElement1rPreCondition();
        org.andromda.metafacades.uml.ModelElementFacade getContextElement1r = (org.andromda.metafacades.uml.ModelElementFacade)shieldedElement(handleGetContextElement());
        handleGetContextElement1rPostCondition();
        return getContextElement1r;
    }

    protected abstract java.lang.Object handleGetContextElement();

    // ----------- delegates to org.andromda.metafacades.uml.ModelElementFacade ------------
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.Object findTaggedValue(java.lang.String tagName)
	{
        return super_.findTaggedValue(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection findTaggedValues(java.lang.String tagName)
	{
        return super_.findTaggedValues(tagName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints()
	{
        return super_.getConstraints();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getConstraints(java.lang.String kind)
	{
        return super_.getConstraints(kind);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getDependencies()
	{
        return super_.getDependencies();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
	{
        return super_.getDocumentation(indent, lineLength, htmlStyle);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
	{
        return super_.getDocumentation(indent, lineLength);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getDocumentation(java.lang.String indent)
	{
        return super_.getDocumentation(indent);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName(boolean modelName)
	{
        return super_.getFullyQualifiedName(modelName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedName()
	{
        return super_.getFullyQualifiedName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getFullyQualifiedNamePath()
	{
        return super_.getFullyQualifiedNamePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getId()
	{
        return super_.getId();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.core.mapping.Mappings getLanguageMappings()
	{
        return super_.getLanguageMappings();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelFacade getModel()
	{
        return super_.getModel();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getName()
	{
        return super_.getName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
	{
        return super_.getNameSpace();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.ModelElementFacade getPackage()
	{
        return super_.getPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackageName()
	{
        return super_.getPackageName();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getPackagePath()
	{
        return super_.getPackagePath();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public org.andromda.metafacades.uml.PackageFacade getRootPackage()
	{
        return super_.getRootPackage();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypeNames()
	{
        return super_.getStereotypeNames();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getStereotypes()
	{
        return super_.getStereotypes();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.util.Collection getTaggedValues()
	{
        return super_.getTaggedValues();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String getVisibility()
	{
        return super_.getVisibility();
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasExactStereotype(java.lang.String stereotypeName)
	{
        return super_.hasExactStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public boolean hasStereotype(java.lang.String stereotypeName)
	{
        return super_.hasStereotype(stereotypeName);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
	{
        return super_.translateConstraint(name, translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String translation)
	{
        return super_.translateConstraints(translation);
	}
	
    // from org.andromda.metafacades.uml.ModelElementFacade
	public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
	{
        return super_.translateConstraints(kind, translation);
	}
	
	/**
	 * @see java.lang.Object#toString()
     */
    public String toString()
    {
        return super_.toString();
    }   
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#initialize()
     */
    public void initialize()
    {
        super_.initialize();
    }
    
    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super_.validateInvariants(validationMessages);
    }
}
