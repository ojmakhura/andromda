/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceSubclassSubclass2.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceSubclassSubclass2
 */
public abstract class InheritanceSubclassSubclass2Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceSubclassSubclass2 object.
    *
    * @param attributeSSC2a
    * @param baseAttributeSSC1a
    * @return InheritanceSubclassSubclass2 the created object
    */
    public static InheritanceSubclassSubclass2 create (int attributeSSC2a, java.lang.String baseAttributeSSC1a)
    {
        InheritanceSubclassSubclass2 object = new InheritanceSubclassSubclass2Impl();

        object.setAttributeSSC2a (attributeSSC2a);
        object.setBaseAttributeSSC1a (baseAttributeSSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceSubclassSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceSubclassSubclass2 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceSubclassSubclass2 object = (InheritanceSubclassSubclass2) session.load(InheritanceSubclassSubclass2Impl.class, id);
        return object;
    }

}