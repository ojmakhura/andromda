/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.class
 *     table="INHERITANCE_INTERFACE_ROOT"
 */
public class InheritanceInterfaceRootImpl
    implements InheritanceInterfaceRoot
{
    // concrete business methods that were declared
    // abstract in class InheritanceInterfaceRoot ...
 }
