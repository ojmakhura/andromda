/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 *  Tests generation with a primary key defined.
 * </p>
 *
 * @hibernate.class
 *     table="ENTITY_TWO"
 * @hibernate.discriminator
 *     column="class"
 *
 */
public abstract class EntityTwo
{
    // --------------- attributes ---------------------
    private java.lang.Long attributeOne;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_ONE"
     *     type="java.lang.Long"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_ONE"
     *     sql-type="NUMBER(19)"
     *     not-null="true"
     */
    public java.lang.Long getAttributeOne()
    {
        return this.attributeOne;
    }

    public void setAttributeOne(java.lang.Long attributeOne)
    {
        this.attributeOne = attributeOne;
    }

    private java.lang.String name;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="NAME"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="NAME"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getName()
    {
        return this.name;
    }

    public void setName(java.lang.String name)
    {
        this.name = name;
    }

    // ------------- relations ------------------

    /**
     * 
     *
     * @hibernate.many-to-one
     *     column="ENTITY_THREE_FK"
     *     class="org.andromda.cartridges.hibernate.EntityThree"
     */
    public org.andromda.cartridges.hibernate.EntityThree getEntityThree()
    {
        return this.entityThree;
    }

    public void setEntityThree(org.andromda.cartridges.hibernate.EntityThree entityThree)
    {
        this.entityThree = entityThree;
    }

    private org.andromda.cartridges.hibernate.EntityThree entityThree;


    // ---------------- business methods  ----------------------


}
