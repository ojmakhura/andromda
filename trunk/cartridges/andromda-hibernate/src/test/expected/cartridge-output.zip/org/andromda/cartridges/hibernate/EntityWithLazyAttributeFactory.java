/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithLazyAttribute.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithLazyAttribute
 */
public abstract class EntityWithLazyAttributeFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityWithLazyAttribute object.
    *
    * @param lazyAttribute
    * @return EntityWithLazyAttribute the created object
    */
    public static EntityWithLazyAttribute create (byte[] lazyAttribute)
    {
        EntityWithLazyAttribute object = new EntityWithLazyAttributeImpl();

        object.setLazyAttribute (lazyAttribute);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityWithLazyAttribute object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithLazyAttribute findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityWithLazyAttribute object = (EntityWithLazyAttribute) session.load(EntityWithLazyAttributeImpl.class, id);
        return object;
    }

}