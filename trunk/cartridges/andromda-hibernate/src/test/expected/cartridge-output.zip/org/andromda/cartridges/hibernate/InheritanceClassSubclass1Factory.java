/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceClassSubclass1.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceClassSubclass1
 */
public abstract class InheritanceClassSubclass1Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceClassSubclass1 object.
    *
    * @param attributeCSC1a
    * @param baseAttributeCSC1a
    * @return InheritanceClassSubclass1 the created object
    */
    public static InheritanceClassSubclass1 create (java.lang.Double attributeCSC1a, java.util.Date baseAttributeCSC1a)
    {
        InheritanceClassSubclass1 object = new InheritanceClassSubclass1Impl();

        object.setAttributeCSC1a (attributeCSC1a);
        object.setBaseAttributeCSC1a (baseAttributeCSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceClassSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceClassSubclass1 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceClassSubclass1 object = (InheritanceClassSubclass1) session.load(InheritanceClassSubclass1Impl.class, id);
        return object;
    }

}