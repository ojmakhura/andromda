/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceIfSubclass.
 * Hibernate inheritance subclass
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceIfSubclass
 */
public abstract class InheritanceIfSubclassFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceIfSubclass object.
    *
    * @param attributeISC2a
    * @param baseAttributeI1a
    * @return InheritanceIfSubclass the created object
    */
    public static InheritanceIfSubclass create (float attributeISC2a, float baseAttributeI1a)
    {
        InheritanceIfSubclass object = new InheritanceIfSubclassImpl();

        object.setAttributeISC2a (attributeISC2a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceIfSubclass object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceIfSubclass findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceIfSubclass object = (InheritanceIfSubclass) session.load(InheritanceIfSubclassImpl.class, id);
        return object;
    }

}
