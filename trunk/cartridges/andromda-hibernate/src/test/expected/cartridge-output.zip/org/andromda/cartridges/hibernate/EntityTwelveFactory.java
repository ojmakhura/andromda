/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityTwelve.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityTwelve
 */
public abstract class EntityTwelveFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityTwelve object.
    *
    * @return EntityTwelve the created object
    */
    public static EntityTwelve create ()
    {
        EntityTwelve object = new EntityTwelveImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityTwelve object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityTwelve findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityTwelve object = (EntityTwelve) session.load(EntityTwelveImpl.class, id);
        return object;
    }

}