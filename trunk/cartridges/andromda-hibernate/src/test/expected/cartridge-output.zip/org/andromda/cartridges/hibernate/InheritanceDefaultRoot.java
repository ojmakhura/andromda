/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.class
 *     table="INHERITANCE_DEFAULT_ROOT"
 * @hibernate.discriminator
 *     column="class"
 *     discriminator-value="InheritanceDefaultRoot"
   *
 */
public abstract class InheritanceDefaultRoot
 {

 
    // --------------- attributes ---------------------
    private java.util.Date baseAttributeDSC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="BASE_ATTRIBUTE_D_S_C1A"
     *     type="java.util.Date"
     *
     * @hibernate.column
     *     name="BASE_ATTRIBUTE_D_S_C1A"
     *     sql-type="TIMESTAMP(3)"
     *     not-null="true"
     */
    public java.util.Date getBaseAttributeDSC1a()
    {
        return this.baseAttributeDSC1a;
    }

    public void setBaseAttributeDSC1a(java.util.Date baseAttributeDSC1a)
    {
        this.baseAttributeDSC1a = baseAttributeDSC1a;
    }

    private java.lang.String id;

    /**
     * 
     *
     * @hibernate.id
     *     generator-class="uuid.hex"
     *     column="ID"
     *     type="java.lang.String"
     *
     * @hibernate.column
     *     name="ID"
     *     sql-type="VARCHAR2(255)"
     *     not-null="true"
     */
    public java.lang.String getId()
    {
        return this.id;
    }

    public void setId(java.lang.String id)
    {
        this.id = id;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
