package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceOne
 */
public class ServiceOneBeanImpl
    extends ServiceOneBean
    implements javax.ejb.SessionBean
{
    // concrete business methods that were declared
    // abstract in class ServiceOneBean ...

    protected void handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session) 
    {
        // TODO: put your implementation here.
    }
    
    protected java.lang.String handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session) 
    {
        // TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected java.util.Collection handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session) 
    {
        // TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected java.lang.String handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session, java.util.Date argumentOne) 
    {
        // TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }
    
    protected void handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session, java.lang.Long firstArgument, java.lang.Boolean secondArgument) 
    {
        // TODO: put your implementation here.
    }
    
    // ---------- the usual session bean stuff... ------------

    public void setSessionContext(javax.ejb.SessionContext ctx)
    {
        super.setSessionContext (ctx);
    }

    public void ejbRemove()
    {
    }

    public void ejbPassivate()
    {
    }

    public void ejbActivate()
    {
    }
}
