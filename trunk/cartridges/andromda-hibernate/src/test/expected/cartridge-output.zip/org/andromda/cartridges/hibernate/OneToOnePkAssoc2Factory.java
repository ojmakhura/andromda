/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type OneToOnePkAssoc2.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.OneToOnePkAssoc2
 */
public abstract class OneToOnePkAssoc2Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) OneToOnePkAssoc2 object.
    *
    * @return OneToOnePkAssoc2 the created object
    */
    public static OneToOnePkAssoc2 create ()
    {
        OneToOnePkAssoc2 object = new OneToOnePkAssoc2Impl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds OneToOnePkAssoc2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static OneToOnePkAssoc2 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        OneToOnePkAssoc2 object = (OneToOnePkAssoc2) session.load(OneToOnePkAssoc2Impl.class, id);
        return object;
    }

}