/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.joined-subclass
 *     table="INHERITANCE_SUBCLASS_SUBCLASS2"
 * @hibernate.joined-subclass-key
 *     column="ID"
 *    
  *
 */
public abstract class InheritanceSubclassSubclass2
 	extends org.andromda.cartridges.hibernate.InheritanceSubclassRootImpl
   {

  
    // --------------- attributes ---------------------
    private int attributeSSC2a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_S_S_C2A"
     *     type="int"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_S_S_C2A"
     *     sql-type="NUMBER(10)"
     */
    public int getAttributeSSC2a()
    {
        return this.attributeSSC2a;
    }

    public void setAttributeSSC2a(int attributeSSC2a)
    {
        this.attributeSSC2a = attributeSSC2a;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
