/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type SubVeriySubclassValidation.
 * Hibernate inheritance class
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.SubVeriySubclassValidation
 */
public abstract class SubVeriySubclassValidationFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) SubVeriySubclassValidation object.
    *
    * @return SubVeriySubclassValidation the created object
    */
    public static SubVeriySubclassValidation create ()
    {
        SubVeriySubclassValidation object = new SubVeriySubclassValidationImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds SubVeriySubclassValidation object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static SubVeriySubclassValidation findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        SubVeriySubclassValidation object = (SubVeriySubclassValidation) session.load(SubVeriySubclassValidationImpl.class, id);
        return object;
    }

}