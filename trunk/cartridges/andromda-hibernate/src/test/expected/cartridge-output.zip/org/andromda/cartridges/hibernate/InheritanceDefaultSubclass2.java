/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.subclass
 *    discriminator-value="InheritanceDefaultSubclass2"
  *
 */
public abstract class InheritanceDefaultSubclass2
 	extends org.andromda.cartridges.hibernate.InheritanceDefaultRootImpl
   {

  
    // --------------- attributes ---------------------
    private java.lang.Double attributeDSC2a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_D_S_C2A"
     *     type="java.lang.Double"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_D_S_C2A"
     *     sql-type="NUMBER(38,15)"
     */
    public java.lang.Double getAttributeDSC2a()
    {
        return this.attributeDSC2a;
    }

    public void setAttributeDSC2a(java.lang.Double attributeDSC2a)
    {
        this.attributeDSC2a = attributeDSC2a;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
