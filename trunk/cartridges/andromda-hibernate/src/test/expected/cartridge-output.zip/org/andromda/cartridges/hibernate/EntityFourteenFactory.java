/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFourteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityFourteen
 */
public abstract class EntityFourteenFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityFourteen object.
    *
    * @return EntityFourteen the created object
    */
    public static EntityFourteen create ()
    {
        EntityFourteen object = new EntityFourteenImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityFourteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityFourteen findByPrimaryKey (net.sf.hibernate.Session session, int one)
        throws net.sf.hibernate.HibernateException
    {
        EntityFourteen object = (EntityFourteen) session.load(EntityFourteenImpl.class, new java.lang.Integer(one));
        return object;
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static int findAttributeOneSum(net.sf.hibernate.Session session)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("select sum(entityFourteen.one) from EntityFourteen entityFourteen");
        return ((java.lang.Integer)query.uniqueResult()).intValue();
    }

    /**
     * 
     *
     * Finds EntityFourteen instance(s) using a query.
     */
    public static org.andromda.cartridges.hibernate.EntityFourteen findEntityFourteenByFive(net.sf.hibernate.Session session)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("select distinct(entityFourteen.one) from EntityFourteenImp entityFourteen");
        return (org.andromda.cartridges.hibernate.EntityFourteen)query.uniqueResult();
    }

}