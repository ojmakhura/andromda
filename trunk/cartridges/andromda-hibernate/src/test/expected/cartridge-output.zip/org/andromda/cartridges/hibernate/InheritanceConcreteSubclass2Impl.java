/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.class
 *     table="$tableNamePrefixINHERITANCE_CONCRETE_SUBCLASS2"
 */
public class InheritanceConcreteSubclass2Impl
    extends InheritanceConcreteSubclass2
{
    // concrete business methods that were declared
    // abstract in class InheritanceConcreteSubclass2 ...
 }
