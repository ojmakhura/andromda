/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.joined-subclass
 *     table="$tableNamePrefixINHERITANCE_SUBCLASS_SUBCLASS2"
 * @hibernate.joined-subclass-key
 *     column="ID"
 */
public class InheritanceSubclassSubclass2Impl
    extends InheritanceSubclassSubclass2
{
    // concrete business methods that were declared
    // abstract in class InheritanceSubclassSubclass2 ...
 }
