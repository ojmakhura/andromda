/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityTwo.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityTwo
 */
public abstract class EntityTwoFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityTwo object.
    *
    * @param attributeOne
    * @return EntityTwo the created object
    */
    public static EntityTwo create (java.lang.Long attributeOne)
    {
        EntityTwo object = new EntityTwoImpl();

        object.setAttributeOne (attributeOne);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityTwo object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityTwo findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String name)
        throws net.sf.hibernate.HibernateException
    {
        EntityTwo object = (EntityTwo) session.load(EntityTwoImpl.class, name);
        return object;
    }

}