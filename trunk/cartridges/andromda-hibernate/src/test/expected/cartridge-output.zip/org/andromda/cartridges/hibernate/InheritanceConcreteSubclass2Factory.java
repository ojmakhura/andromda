/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceConcreteSubclass2.
 * Hibernate inheritance concrete
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceConcreteSubclass2
 */
public abstract class InheritanceConcreteSubclass2Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceConcreteSubclass2 object.
    *
    * @param attributeCCSC2a
    * @param baseAttributeCC1a
    * @return InheritanceConcreteSubclass2 the created object
    */
    public static InheritanceConcreteSubclass2 create (double attributeCCSC2a, int baseAttributeCC1a)
    {
        InheritanceConcreteSubclass2 object = new InheritanceConcreteSubclass2Impl();

        object.setAttributeCCSC2a (attributeCCSC2a);
        object.setBaseAttributeCC1a (baseAttributeCC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceConcreteSubclass2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceConcreteSubclass2 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceConcreteSubclass2 object = (InheritanceConcreteSubclass2) session.load(InheritanceConcreteSubclass2Impl.class, id);
        return object;
    }

}