/**
 * Attention: Generated source (HibernateEntity.vsl)! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * 
 *
 * @hibernate.subclass
 *    discriminator-value="InheritanceDefaultSubclass1"
  *
 */
public abstract class InheritanceDefaultSubclass1
     extends org.andromda.cartridges.hibernate.InheritanceDefaultRootImpl
   {

  
    // --------------- attributes ---------------------
    private java.lang.Double attributeDSC1a;

    /**
     * 
     *
     * @hibernate.property
     *     column="ATTRIBUTE_D_S_C1A"
     *     type="java.lang.Double"
     *
     * @hibernate.column
     *     name="ATTRIBUTE_D_S_C1A"
     *     sql-type="NUMBER(38,15)"
     */
    public java.lang.Double getAttributeDSC1a()
    {
        return this.attributeDSC1a;
    }

    public void setAttributeDSC1a(java.lang.Double attributeDSC1a)
    {
        this.attributeDSC1a = attributeDSC1a;
    }

    // ------------- relations ------------------

     // ---------------- business methods  ----------------------

 
}
