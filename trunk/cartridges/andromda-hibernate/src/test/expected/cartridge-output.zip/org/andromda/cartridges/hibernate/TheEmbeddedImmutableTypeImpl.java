/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.TheEmbeddedImmutableType
 */
public class TheEmbeddedImmutableTypeImpl
    extends org.andromda.cartridges.hibernate.TheEmbeddedImmutableType
    implements java.io.Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = -3646577996542929283L;
    
}