/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest
 */

public abstract class InheritanceBusinessMethodTestImpl
    extends org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest
{
    /**
     * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest#realMethod()
     */
    public boolean realMethod()
    {
        //@todo implement public boolean realMethod()
        return false;
    }

    /**
     * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest#abstractMethod()
     */
    public byte abstractMethod()
    {
        //@todo implement public byte abstractMethod()
        return 0;
    }

}