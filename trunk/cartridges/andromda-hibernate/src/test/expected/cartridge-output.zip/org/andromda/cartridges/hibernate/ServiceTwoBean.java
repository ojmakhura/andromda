package org.andromda.cartridges.hibernate;

import javax.ejb.EJBException;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import net.sf.hibernate.HibernateException;
import net.sf.hibernate.Session;
import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.cfg.Configuration;

import org.andromda.persistence.hibernate.HibernateUtils;


/**
 * <p>
 *  Just another service for testing the hibernate cartridge.
 * </p>
 *
 * @ejb.bean 
 *        name="ServiceTwo"
 *        type="Stateless"
 *        jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceTwo"
 *        local-jndi-name="ejb/org.andromda.cartridges.hibernate.ServiceTwo/Local"
 *        view-type="both"
 * @ejb.interface 
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceTwo"
 *        local-class="org.andromda.cartridges.hibernate.ServiceTwoLocal"
 * @ejb.home 
 *        generate="local,remote"
 *        remote-class="org.andromda.cartridges.hibernate.ServiceTwoHome"
 *        local-class="org.andromda.cartridges.hibernate.ServiceTwoLocalHome"
 * @ejb.util generate="physical"
 */
public abstract class ServiceTwoBean 
    implements javax.ejb.SessionBean
{

    // ---------------- business methods  ----------------------
    protected abstract org.andromda.cartridges.hibernate.TestValueObject handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session);

    /**
     * <p>
     *  An operation that IS exposed as a webservice.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public org.andromda.cartridges.hibernate.TestValueObject operationOne()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handle${str.capitalize($operation.name)}(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceTwoBean.operationOne: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceTwoBean.operationOne: " + he.getMessage());
                }
            }
        }
    }
    
    protected abstract java.lang.String handle${str.capitalize(${operation.name})} (net.sf.hibernate.Session session);

    /**
     * <p>
     *  An operation on the service which is NOT exposed as a
     *  webservice.
     * </p>
     *
     * @ejb.interface-method view-type="both"
     * @ejb.transaction type="Required"
     */
    public java.lang.String operationTwo()
    {
        Session session = null;
        try
        {
            session = getSession();
            return handle${str.capitalize($operation.name)}(session);
        }
        catch (Throwable th)
        {
            throw new EJBException("ServiceTwoBean.operationTwo: " + th.toString());
        }
        finally
        {
            if (session != null)
            {
                try
                {
                    session.flush();
                    session.close();
                }
                catch (HibernateException he)
                {
                    throw new EJBException("ServiceTwoBean.operationTwo: " + he.getMessage());
                }
            }
        }
    }
    
   // ---------------- create methods -------------------------

   /**
    * @ejb.create-method
    * @ejb.transaction type="Required"
    */
    public void ejbCreate ()
           throws javax.ejb.CreateException
    {
    }

    public void ejbPostCreate ()
           throws javax.ejb.CreateException
    {
    }

   // ---------------- Hibernate helpers -------------------------

    protected javax.ejb.SessionContext _ctx = null;

    private static SessionFactory _sessionFactory = null;
    
    public void setSessionContext( javax.ejb.SessionContext ctx )
    {
        _ctx = ctx;
    }

    private SessionFactory getSessionFactory() throws HibernateException, NamingException
    {
        if( _sessionFactory == null )
        {
            _sessionFactory = HibernateUtils.getSessionFactory();
        }
        return _sessionFactory;
    }

    private Session getSession() throws HibernateException, NamingException
    {
        return getSessionFactory().openSession();
    }

    // ---------------- accessor methods for (session!) bean references ---------------
}
