/**
 * This class is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @hibernate.joined-subclass
 *     table="$tableNamePrefixINHERITANCE_SUBCLASS_ROOT"
 * @hibernate.joined-subclass-key
 *     column="ID"
 */
public class InheritanceSubclassRootImpl
    extends InheritanceSubclassRoot
{
    // concrete business methods that were declared
    // abstract in class InheritanceSubclassRoot ...
 }
