/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityOne.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityOne
 */
public abstract class EntityOneFactory {

   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityOne object.
    *
    * @param attributeOne
    * @return EntityOne the created object
    */
    public static EntityOne create (java.lang.String attributeOne)
    {
        EntityOne object = new EntityOneImpl();

        object.setAttributeOne (attributeOne);

        return object;
    }
    
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityOne object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityOne findByPrimaryKey (net.sf.hibernate.Session session, java.lang.String id)
        throws net.sf.hibernate.HibernateException
    {
        EntityOne object = (EntityOne) session.load(EntityOneImpl.class, id);
        return object;
    }

    /**
     * <p>
     *  Tests automatic finder generation.
     * </p>
     *
     * Finds EntityOne instance(s) using a query.
     */
    public static java.util.Collection findByAttributeOne(net.sf.hibernate.Session session, java.lang.String attributeOne)
        throws net.sf.hibernate.HibernateException
    {
        net.sf.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityOne as entityOne where entityOne.attributeOne = ?");
		query.setString(0, attributeOne);
        return query.list();
    }

}
