/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibInterfaceSubclass1
 */
public class HibInterfaceSubclass1Impl
    extends org.andromda.cartridges.spring.HibInterfaceSubclass1
{
    /**
     * @see org.andromda.cartridges.spring.HibInterfaceSubclass1#sc1Op()
     */
    public int sc1Op()
    {
        //@todo implement public int sc1Op()
        return 0;
    }

}
