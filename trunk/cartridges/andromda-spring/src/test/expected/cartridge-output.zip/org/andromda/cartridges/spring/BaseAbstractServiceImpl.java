/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.BaseAbstractService
 */
public abstract class BaseAbstractServiceImpl
    extends BaseAbstractServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.BaseAbstractService#operationOne()
     */
    protected  String handleOperationOne()
        throws Exception
    {
        // @todo implement protected  String handleOperationOne()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.BaseAbstractService.handleOperationOne() Not implemented!");
    }

}