/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Futurenum;
import org.andromda.cartridges.spring.crud.Garden;
import org.andromda.cartridges.spring.crud.House;
import org.andromda.cartridges.spring.crud.Mansion;
import org.andromda.cartridges.spring.crud.Room;
public final class MansionManageableServiceBase
    implements MansionManageableService
{
    private MansionManageableDao dao;

    public void setDao(MansionManageableDao dao)
    {
        this.dao = dao;
    }

    protected MansionManageableDao getDao()
    {
        return this.dao;
    }

    public MansionValueObject create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception
    {
        if (name == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'name' can not be null");
        }

        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'enumAttribute' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'room' can not be null");
        }

        if (mansion == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'mansion' can not be null");
        }

        return toValueObject(dao.create(name, something, enumAttribute, id, houses, room, gardens, mansion));
    }

    public MansionValueObject readById(Long id)
        throws Exception
    {
        return toValueObject(dao.readById(id));
    }

    public List read(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception
    {
        return toValueObjects(dao.read(name, something, enumAttribute, id, houses, room, gardens, mansion));
    }

    public List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public MansionValueObject update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
        throws Exception
    {
        if (name == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'name' can not be null");
        }

        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'enumAttribute' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'id' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'room' can not be null");
        }

        if (mansion == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion) - 'mansion' can not be null");
        }

        return toValueObject(dao.update(name, something, enumAttribute, id, houses, room, gardens, mansion));
    }

    public void delete(Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.delete(Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private static List toValueObjects(Collection entities)
    {
        final List list = new ArrayList();

        for (Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((Mansion)iterator.next()));
        }

        return list;
    }

    private static MansionValueObject toValueObject(Mansion entity)
    {
        final MansionValueObject valueObject = new MansionValueObject();

        valueObject.setName(entity.getName());
        valueObject.setSomething(entity.getSomething());
        valueObject.setEnumAttribute(entity.getEnumAttribute());
        valueObject.setId(entity.getId());

        final Collection houses = entity.getHouses();
        if (houses == null || houses.isEmpty())
        {
            valueObject.setHouses(null);
        }
        else
        {
            final Long[] values = new Long[houses.size()];
            int counter = 0;
            for (final Iterator iterator = houses.iterator(); iterator.hasNext();counter++)
            {
                final House element = (House)iterator.next();
                values[counter] = element.getId();
            }
            valueObject.setHouses(values);
        }

        final Room room = entity.getRoom();
        if (room != null)
        {
            valueObject.setRoom(room.getSpecificId());
        }

        final Collection gardens = entity.getGardens();
        if (gardens == null || gardens.isEmpty())
        {
            valueObject.setGardens(null);
            valueObject.setGardensLabels(null);
        }
        else
        {
            final Long[] values = new Long[gardens.size()];
            final int[] labels = new int[gardens.size()];
            int counter = 0;
            for (final Iterator iterator = gardens.iterator(); iterator.hasNext();counter++)
            {
                final Garden element = (Garden)iterator.next();
                values[counter] = element.getId();
                labels[counter] = element.getInteger();
            }
            valueObject.setGardens(values);
            valueObject.setGardensLabels(labels);
        }

        final Mansion mansion = entity.getMansion();
        if (mansion != null)
        {
            valueObject.setMansion(mansion.getId());
        }

        return valueObject;
    }
}
