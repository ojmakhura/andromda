/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.hibernate.HibernateException;
import org.andromda.cartridges.spring.crud.GardenDao;
import org.andromda.cartridges.spring.crud.GardenImpl;
import org.andromda.cartridges.spring.crud.House;
import org.andromda.cartridges.spring.crud.HouseDao;
import org.andromda.cartridges.spring.crud.HouseImpl;
import org.andromda.cartridges.spring.crud.Room;
import org.andromda.cartridges.spring.crud.RoomDao;
import org.andromda.cartridges.spring.crud.RoomImpl;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;
public final class RoomManageableDaoBase
    extends HibernateDaoSupport
    implements RoomManageableDao
{
    private RoomDao dao;

    public void setDao(RoomDao dao)
    {
        this.dao = dao;
    }

    protected RoomDao getDao()
    {
        return this.dao;
    }

    private GardenDao gardensDao = null;

    public void setGardensDao(GardenDao gardensDao)
    {
        this.gardensDao = gardensDao;
    }

    protected GardenDao getGardensDao()
    {
        return this.gardensDao;
    }

    private HouseDao namedDao = null;

    public void setNamedDao(HouseDao namedDao)
    {
        this.namedDao = namedDao;
    }

    protected HouseDao getNamedDao()
    {
        return this.namedDao;
    }

    private GardenDao hellosDao = null;

    public void setHellosDao(GardenDao hellosDao)
    {
        this.hellosDao = hellosDao;
    }

    protected GardenDao getHellosDao()
    {
        return this.hellosDao;
    }

    private Set findGardenByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private Set findHouseByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Room create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
    {
        final Room entity = new RoomImpl();
        entity.setDate(date);
        entity.setSpecificId(specificId);
        final Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        House namedEntity = null;
        if (named != null)
        {
            namedEntity = (House)getNamedDao().load(named);
        }

        entity.setNamed(namedEntity);

        final Set hellosEntities = (hellos != null && hellos.length > 0)
            ? this.findGardenByIds(hellos)
            : Collections.EMPTY_SET;

        entity.setHellos(hellosEntities);


        return (Room)this.getDao().create(entity);
    }

    public Room readById(Long specificId)
    {
        return getDao().load(specificId);
    }

    public List read(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);

            if (date != null)
            {
                // we check whether or not the user supplied time information within this particular date argument
                // if he/she didn't we assume he/she wishes to search in the scope of the entire day
                final Calendar calendar = new GregorianCalendar();
                calendar.setTime(date);
                if ( calendar.get(Calendar.HOUR) != 0
                     || calendar.get(Calendar.MINUTE) != 0
                     || calendar.get(Calendar.SECOND) != 0
                     || calendar.get(Calendar.MILLISECOND) != 0 )
                {
                    criteria.add(Expression.eq("date", date));
                }
                else
                {
                    calendar.add(Calendar.DATE, 1);
                    criteria.add(Expression.between("date", date, calendar.getTime()));
                }
            }
            if (specificId != null)
            criteria.add(Expression.eq("specificId", specificId));
            if (gardens != null && gardens.length > 0) criteria.createCriteria("gardens").add(Expression.in("id", gardens));
            if (named != null) criteria.createCriteria("named").add(Expression.eq("id", named));
            if (hellos != null && hellos.length > 0) criteria.createCriteria("hellos").add(Expression.in("id", hellos));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Map readBackingLists()
    {
        final Map lists = new HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("gardens", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
            lists.put("named", session.createQuery("select item.id, item.id from House item order by item.id").list());
            lists.put("hellos", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public Room update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
    {
        final Room entity = this.getDao().load(specificId);

        entity.setDate(date);
        final Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        House namedEntity = null;
        if (named != null)
        {
            namedEntity = getNamedDao().load(named);
        }

        entity.setNamed(namedEntity);

        final Set hellosEntities = (hellos != null && hellos.length > 0)
            ? this.findGardenByIds(hellos)
            : Collections.EMPTY_SET;

        entity.setHellos(hellosEntities);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            final List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}