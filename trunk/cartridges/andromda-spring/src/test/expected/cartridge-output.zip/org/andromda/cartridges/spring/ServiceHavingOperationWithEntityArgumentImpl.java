/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument
 */
public class ServiceHavingOperationWithEntityArgumentImpl
    extends ServiceHavingOperationWithEntityArgumentBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument#operationHavingEntity(EntityFour)
     */
    protected  void handleOperationHavingEntity(EntityFour entity)
        throws Exception
    {
        // @todo implement protected  void handleOperationHavingEntity(EntityFour entity)
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument.handleOperationHavingEntity(EntityFour entity) Not implemented!");
    }

}