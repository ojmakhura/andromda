/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.Many2ManyOne
 */
public class Many2ManyOneDaoImpl
    extends org.andromda.cartridges.spring.Many2ManyOneDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.Many2ManyOneDaoBase#transformEntity(org.andromda.cartridges.spring.Many2ManyOne)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.Many2ManyOne entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}