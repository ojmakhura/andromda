/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoImpl
	extends org.andromda.cartridges.spring.ServiceTwoBase
{
    
	/**
	 * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
	 */
    public org.andromda.cartridges.spring.TestValueObject operationOne() 
    {
        //@todo implement public org.andromda.cartridges.spring.TestValueObject operationOne()
        return null;
    }
	
	/**
	 * @see org.andromda.cartridges.spring.ServiceTwo#operationTwo()
	 */
    public java.lang.String operationTwo() 
    {
        //@todo implement public java.lang.String operationTwo()
        return null;
    }
	
}
