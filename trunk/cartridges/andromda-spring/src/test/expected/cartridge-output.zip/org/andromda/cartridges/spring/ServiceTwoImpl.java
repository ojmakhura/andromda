/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 * TEMPLATE:    SpringServiceImpl.vsl in andromda-spring cartridge
 * MODEL CLASS: SpringCartridgeTestModel::org.andromda.cartridges.spring::ServiceTwo
 * STEREOTYPE:  Service
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoImpl
    extends ServiceTwoBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    protected  TestValueObject handleOperationOne()
        throws Exception
    {
        // TODO implement protected  TestValueObject handleOperationOne()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceTwo.handleOperationOne() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationTwo()
     */
    protected  String handleOperationTwo()
        throws Exception
    {
        // TODO implement protected  String handleOperationTwo()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceTwo.handleOperationTwo() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    protected  boolean handleOperationThree()
        throws Exception
    {
        // TODO implement protected  boolean handleOperationThree()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceTwo.handleOperationThree() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#doSomething()
     */
    protected  String[] handleDoSomething()
        throws Exception
    {
        // TODO implement protected  String[] handleDoSomething()
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.ServiceTwo.handleDoSomething() Not implemented!");
    }

}