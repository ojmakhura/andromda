/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Futurenum;
public interface HouseManageableService
{
    public HouseValueObject create(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public HouseValueObject readById(Long id)
        throws Exception;

    public List read(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public List readAll()
        throws Exception;

    public Map readBackingLists()
        throws Exception;

    public HouseValueObject update(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion)
        throws Exception;

    public void delete(Long[] ids)
        throws Exception;

}
