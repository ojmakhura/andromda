package org.andromda.cartridges.spring;

/**
 * Web service delegator for <code>org.andromda.cartridges.spring.ServiceOne</code>.
 *
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneWSDelegator
{

    /**
     * Gets an instance of <code>org.andromda.cartridges.spring.ServiceOne</code>
     */
    private final org.andromda.cartridges.spring.ServiceOne getServiceOne()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        getServiceOne().operationWithVoidReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    public java.lang.String operationWithSimpleReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        return getServiceOne().operationWithSimpleReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    public java.util.Collection operationWithComplexReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        return getServiceOne().operationWithComplexReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(java.util.Date)
     */
    public java.lang.String operationWithSingleArgument(java.util.Date argumentOne)
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        return getServiceOne().operationWithSingleArgument(argumentOne);
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws org.andromda.cartridges.spring.ServiceTestException, org.andromda.cartridges.spring.OperationTestException
    {
        getServiceOne().operationWithMultipleArguments(firstArgument, secondArgument);
    }

}
