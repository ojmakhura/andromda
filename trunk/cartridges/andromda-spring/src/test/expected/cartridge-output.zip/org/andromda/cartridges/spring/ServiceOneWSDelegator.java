/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceOne}.
 *
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceOne}
     */
    private final org.andromda.cartridges.spring.ServiceOne getServiceOne()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
    {
        getServiceOne().operationWithVoidReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    public java.lang.String operationWithSimpleReturnType()
    {
        return getServiceOne().operationWithSimpleReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    public java.util.Collection operationWithComplexReturnType()
    {
        return getServiceOne().operationWithComplexReturnType();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(java.util.Date)
     */
    public java.lang.String operationWithSingleArgument(java.util.Date argumentOne)
    {
        return getServiceOne().operationWithSingleArgument(argumentOne);
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
    {
        getServiceOne().operationWithMultipleArguments(firstArgument, secondArgument);
    }

}