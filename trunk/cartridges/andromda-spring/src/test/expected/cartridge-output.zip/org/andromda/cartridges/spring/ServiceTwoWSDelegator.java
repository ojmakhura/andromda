package org.andromda.cartridges.spring;

/**
 * Web service delegator for <code>org.andromda.cartridges.spring.ServiceTwo</code>.
 *
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoWSDelegator
{

    /**
     * Gets an instance of <code>org.andromda.cartridges.spring.ServiceTwo</code>
     */
    private final org.andromda.cartridges.spring.ServiceTwo getServiceTwo()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceTwo();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    public org.andromda.cartridges.spring.TestValueObject operationOne()
    {
        return getServiceTwo().operationOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    public boolean operationThree()
    {
        return getServiceTwo().operationThree();
    }

}
