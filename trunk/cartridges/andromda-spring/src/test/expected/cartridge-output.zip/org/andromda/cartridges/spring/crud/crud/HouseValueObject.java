/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.io.Serializable;
import org.andromda.cartridges.spring.crud.Futurenum;
public class HouseValueObject
    implements Serializable
{
    private String something;

    public String getSomething()
    {
        return this.something;
    }

    public void setSomething(String something)
    {
        this.something = something;
    }

    private Futurenum enumAttribute;

    public Futurenum getEnumAttribute()
    {
        return this.enumAttribute;
    }

    public void setEnumAttribute(Futurenum enumAttribute)
    {
        this.enumAttribute = enumAttribute;
    }

    private Long id;

    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    private Long room;

    public Long getRoom()
    {
        return this.room;
    }

    public void setRoom(Long room)
    {
        this.room = room;
    }

    private Long[] gardens;

    public Long[] getGardens()
    {
        return this.gardens;
    }

    public void setGardens(Long[] gardens)
    {
        this.gardens = gardens;
    }

    private int[] gardensLabels;

    public int[] getGardensLabels()
    {
        return this.gardensLabels;
    }

    public void setGardensLabels(int[] gardensLabels)
    {
        this.gardensLabels = gardensLabels;
    }

    private Long mansion;

    public Long getMansion()
    {
        return this.mansion;
    }

    public void setMansion(Long mansion)
    {
        this.mansion = mansion;
    }

}