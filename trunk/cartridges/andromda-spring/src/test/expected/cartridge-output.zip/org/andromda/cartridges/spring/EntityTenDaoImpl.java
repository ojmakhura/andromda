/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see EntityTen
 */
public class EntityTenDaoImpl
    extends EntityTenDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#toValueObjectTen(EntityTen, ValueObjectTen)
     */
    public void toValueObjectTen(
        EntityTen source,
        ValueObjectTen target)
    {
        // @todo verify behavior of toValueObjectTen
        super.toValueObjectTen(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#toValueObjectTen(EntityTen)
     */
    public ValueObjectTen toValueObjectTen(final EntityTen entity)
    {
        // @todo verify behavior of toValueObjectTen
        return super.toValueObjectTen(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private EntityTen loadEntityTenFromValueObjectTen(ValueObjectTen valueObjectTen)
    {
        // @todo implement loadEntityTenFromValueObjectTen
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityTenFromValueObjectTen(ValueObjectTen) not yet implemented.");

        /* A typical implementation looks like this:
        EntityTen entityTen = this.load(valueObjectTen.getId());
        if (entityTen == null)
        {
            entityTen = EntityTen.Factory.newInstance();
        }
        return entityTen;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#valueObjectTenToEntity(ValueObjectTen)
     */
    public EntityTen valueObjectTenToEntity(ValueObjectTen valueObjectTen)
    {
        // @todo verify behavior of valueObjectTenToEntity
        EntityTen entity = this.loadEntityTenFromValueObjectTen(valueObjectTen);
        this.valueObjectTenToEntity(valueObjectTen, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#valueObjectTenToEntity(ValueObjectTen, EntityTen)
     */
    public void valueObjectTenToEntity(
        ValueObjectTen source,
        EntityTen target,
        boolean copyIfNull)
    {
        // @todo verify behavior of valueObjectTenToEntity
        super.valueObjectTenToEntity(source, target, copyIfNull);
    }

}