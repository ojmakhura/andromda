/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityTen
 */
public class EntityTenDaoImpl
    extends org.andromda.cartridges.spring.EntityTenDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#toValueObjectTen(org.andromda.cartridges.spring.EntityTen)
     */
    public org.andromda.cartridges.spring.ValueObjectTen toValueObjectTen(final org.andromda.cartridges.spring.EntityTen entity)
    {
        // @todo implement toValueObjectTen
        return null;
    }
    
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#valueObjectTenToEntity(org.andromda.cartridges.spring.ValueObjectTen)
     */
    public org.andromda.cartridges.spring.EntityTen valueObjectTenToEntity(org.andromda.cartridges.spring.ValueObjectTen valueObjectTen)
    {
        // @todo implement valueObjectTenToEntity
        return null;    
    }

}