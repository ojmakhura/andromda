/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Futurenum;
import org.andromda.cartridges.spring.crud.House;
public interface HouseManageableDao
{
    public House create(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion);

    public House readById(Long id);

    public List read(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion);

    public List readAll();

    public Map readBackingLists();

    public House update(String something, Futurenum enumAttribute, Long id, Long room, Long[] gardens, Long mansion);

    public void delete(Long[] ids);

}