/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceThree
 */
public class ServiceThreeImpl
    extends org.andromda.cartridges.spring.ServiceThreeBase
{

}