/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityTwo
 */
public class EntityTwoDaoImpl
    extends org.andromda.cartridges.spring.EntityTwoDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityTwoDaoBase#transformEntity(org.andromda.cartridges.spring.EntityTwo)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.EntityTwo entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}