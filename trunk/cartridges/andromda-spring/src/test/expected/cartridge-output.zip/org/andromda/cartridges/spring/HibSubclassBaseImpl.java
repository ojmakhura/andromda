/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibSubclassBase
 */
public class HibSubclassBaseImpl
    extends org.andromda.cartridges.spring.HibSubclassBase
{
	/**
	 * @see org.andromda.cartridges.spring.HibSubclassBaseDao#baseOp()
	 */
    public java.lang.String baseOp() 
    {
        //@todo implement public java.lang.String baseOp()
        return null;
    }
	
}
