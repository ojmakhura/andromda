/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibInterfaceBase
 */
public class HibInterfaceBaseImpl
    extends org.andromda.cartridges.spring.HibInterfaceBase
{
    /**
     * @see org.andromda.cartridges.spring.HibInterfaceBaseDao#baseOperation()
     */
    public double baseOperation()
    {
        //@todo implement public double baseOperation()
        return 0;
    }

}
