/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SubService
 */
public class SubServiceImpl
    extends org.andromda.cartridges.spring.SubServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.SubService#subOperation(java.lang.String)
     */
    protected java.lang.Long handleSubOperation(java.lang.String paramOne)
        throws java.lang.Exception
    {
        // @todo implement protected java.lang.Long handleSubOperation(java.lang.String paramOne)
        return null;
    }

}