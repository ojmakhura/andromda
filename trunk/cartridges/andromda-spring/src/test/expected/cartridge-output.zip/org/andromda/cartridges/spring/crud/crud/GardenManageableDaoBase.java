/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.hibernate.HibernateException;
import org.andromda.cartridges.spring.crud.Garden;
import org.andromda.cartridges.spring.crud.GardenDao;
import org.andromda.cartridges.spring.crud.GardenImpl;
import org.andromda.cartridges.spring.crud.HouseDao;
import org.andromda.cartridges.spring.crud.HouseImpl;
import org.andromda.cartridges.spring.crud.Room;
import org.andromda.cartridges.spring.crud.RoomDao;
import org.andromda.cartridges.spring.crud.RoomImpl;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;
public final class GardenManageableDaoBase
    extends HibernateDaoSupport
    implements GardenManageableDao
{
    private GardenDao dao;

    public void setDao(GardenDao dao)
    {
        this.dao = dao;
    }

    protected GardenDao getDao()
    {
        return this.dao;
    }

    private RoomDao roomDao = null;

    public void setRoomDao(RoomDao roomDao)
    {
        this.roomDao = roomDao;
    }

    protected RoomDao getRoomDao()
    {
        return this.roomDao;
    }

    private HouseDao housesDao = null;

    public void setHousesDao(HouseDao housesDao)
    {
        this.housesDao = housesDao;
    }

    protected HouseDao getHousesDao()
    {
        return this.housesDao;
    }

    private Set findRoomByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private Set findHouseByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Garden create(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
    {
        final Garden entity = new GardenImpl();
        entity.setInteger(integer);
        entity.setIntWrapper(intWrapper);
        entity.setId(id);
        Room roomEntity = null;
        if (room != null)
        {
            roomEntity = (Room)getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : Collections.EMPTY_SET;

        entity.setHouses(housesEntities);


        return (Garden)this.getDao().create(entity);
    }

    public Garden readById(Long id)
    {
        return getDao().load(id);
    }

    public List read(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);

            criteria.add(Expression.eq("integer", new Integer(integer)));
            if (intWrapper != null)
            criteria.add(Expression.eq("intWrapper", intWrapper));
            if (id != null)
            criteria.add(Expression.eq("id", id));
            if (room != null) criteria.createCriteria("room").add(Expression.eq("specificId", room));
            if (houses != null && houses.length > 0) criteria.createCriteria("houses").add(Expression.in("id", houses));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Map readBackingLists()
    {
        final Map lists = new HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("room", session.createQuery("select item.specificId, item.specificId from Room item order by item.specificId").list());
            lists.put("houses", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public Garden update(int integer, Integer intWrapper, Long id, Long room, Long[] houses)
    {
        final Garden entity = this.getDao().load(id);

        entity.setInteger(integer);
        entity.setIntWrapper(intWrapper);
        Room roomEntity = null;
        if (room != null)
        {
            roomEntity = getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : Collections.EMPTY_SET;

        entity.setHouses(housesEntities);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            final List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}