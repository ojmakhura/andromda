/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.sf.hibernate.HibernateException;
import org.andromda.cartridges.spring.crud.Futurenum;
import org.andromda.cartridges.spring.crud.GardenDao;
import org.andromda.cartridges.spring.crud.GardenImpl;
import org.andromda.cartridges.spring.crud.HouseDao;
import org.andromda.cartridges.spring.crud.HouseImpl;
import org.andromda.cartridges.spring.crud.Mansion;
import org.andromda.cartridges.spring.crud.MansionDao;
import org.andromda.cartridges.spring.crud.MansionImpl;
import org.andromda.cartridges.spring.crud.Room;
import org.andromda.cartridges.spring.crud.RoomDao;
import org.andromda.cartridges.spring.crud.RoomImpl;
import org.springframework.orm.hibernate.support.HibernateDaoSupport;
public final class MansionManageableDaoBase
    extends HibernateDaoSupport
    implements MansionManageableDao
{
    private MansionDao dao;

    public void setDao(MansionDao dao)
    {
        this.dao = dao;
    }

    protected MansionDao getDao()
    {
        return this.dao;
    }

    private HouseDao housesDao = null;

    public void setHousesDao(HouseDao housesDao)
    {
        this.housesDao = housesDao;
    }

    protected HouseDao getHousesDao()
    {
        return this.housesDao;
    }

    private RoomDao roomDao = null;

    public void setRoomDao(RoomDao roomDao)
    {
        this.roomDao = roomDao;
    }

    protected RoomDao getRoomDao()
    {
        return this.roomDao;
    }

    private GardenDao gardensDao = null;

    public void setGardensDao(GardenDao gardensDao)
    {
        this.gardensDao = gardensDao;
    }

    protected GardenDao getGardensDao()
    {
        return this.gardensDao;
    }

    private MansionDao mansionDao = null;

    public void setMansionDao(MansionDao mansionDao)
    {
        this.mansionDao = mansionDao;
    }

    protected MansionDao getMansionDao()
    {
        return this.mansionDao;
    }

    private Set findHouseByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private Set findRoomByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private Set findGardenByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private Set findMansionByIds(Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(MansionImpl.class);
            criteria.add(Expression.in("id", ids));
            return new HashSet(criteria.list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Mansion create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
    {
        final Mansion entity = new MansionImpl();
        entity.setName(name);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        entity.setId(id);
        final Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        Room roomEntity = null;
        if (room != null)
        {
            roomEntity = (Room)getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        Mansion mansionEntity = null;
        if (mansion != null)
        {
            mansionEntity = (Mansion)getMansionDao().load(mansion);
        }

        entity.setMansion(mansionEntity);


        return (Mansion)this.getDao().create(entity);
    }

    public Mansion readById(Long id)
    {
        return getDao().load(id);
    }

    public List read(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(MansionImpl.class);

            if (name != null)
                criteria.add(Expression.ilike("name", name, MatchMode.START));
            if (something != null)
                criteria.add(Expression.ilike("something", something, MatchMode.START));
            if (enumAttribute != null)
            criteria.add(Expression.eq("enumAttribute", enumAttribute));
            if (id != null)
            criteria.add(Expression.eq("id", id));
            if (houses != null && houses.length > 0) criteria.createCriteria("houses").add(Expression.in("id", houses));
            if (room != null) criteria.createCriteria("room").add(Expression.eq("specificId", room));
            if (gardens != null && gardens.length > 0) criteria.createCriteria("gardens").add(Expression.in("id", gardens));
            if (mansion != null) criteria.createCriteria("mansion").add(Expression.eq("id", mansion));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(MansionImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public Map readBackingLists()
    {
        final Map lists = new HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("houses", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
            lists.put("room", session.createQuery("select item.specificId, item.specificId from Room item order by item.specificId").list());
            lists.put("gardens", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
            lists.put("mansion", session.createQuery("select item.id, item.id from Mansion item order by item.id").list());
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public Mansion update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion)
    {
        final Mansion entity = (Mansion) this.getDao().load(id);

        entity.setName(name);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        final Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        Room roomEntity = null;
        if (room != null)
        {
            roomEntity = getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        Mansion mansionEntity = null;
        if (mansion != null)
        {
            mansionEntity = (Mansion) getMansionDao().load(mansion);
        }

        entity.setMansion(mansionEntity);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            final List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}