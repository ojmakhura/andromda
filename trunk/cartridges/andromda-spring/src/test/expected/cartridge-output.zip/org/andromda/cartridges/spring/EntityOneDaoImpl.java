/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityOne
 */
public class EntityOneDaoImpl
    extends org.andromda.cartridges.spring.EntityOneDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityOneDaoBase#transformEntity(org.andromda.cartridges.spring.EntityOne)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.EntityOne entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}
