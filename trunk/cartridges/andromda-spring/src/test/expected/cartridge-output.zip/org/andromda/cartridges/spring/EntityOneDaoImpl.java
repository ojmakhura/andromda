/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see EntityOne
 */
public class EntityOneDaoImpl
    extends EntityOneDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#toValueObject(EntityOne, TestValueObject)
     */
    public void toValueObject(
        EntityOne source,
        TestValueObject target)
    {
        // @todo verify behavior of toValueObject
        super.toValueObject(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#toValueObject(EntityOne)
     */
    public TestValueObject toValueObject(final EntityOne entity)
    {
        // @todo verify behavior of toValueObject
        return super.toValueObject(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private EntityOne loadEntityOneFromTestValueObject(TestValueObject valueObject)
    {
        // @todo implement loadEntityOneFromTestValueObject
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityOneFromTestValueObject(TestValueObject) not yet implemented.");

        /* A typical implementation looks like this:
        EntityOne entityOne = this.load(valueObject.getId());
        if (entityOne == null)
        {
            entityOne = EntityOne.Factory.newInstance();
        }
        return entityOne;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#valueObjectToEntity(TestValueObject)
     */
    public EntityOne valueObjectToEntity(TestValueObject valueObject)
    {
        // @todo verify behavior of valueObjectToEntity
        EntityOne entity = this.loadEntityOneFromTestValueObject(valueObject);
        this.valueObjectToEntity(valueObject, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#valueObjectToEntity(TestValueObject, EntityOne)
     */
    public void valueObjectToEntity(
        TestValueObject source,
        EntityOne target,
        boolean copyIfNull)
    {
        // @todo verify behavior of valueObjectToEntity
        super.valueObjectToEntity(source, target, copyIfNull);
    }

}