/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.SuperEntity
 */
public class SuperEntityDaoImpl
    extends org.andromda.cartridges.spring.SuperEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO2(org.andromda.cartridges.spring.SuperEntity)
     */
    public org.andromda.cartridges.spring.SuperEntityVO2 toSuperEntityVO2(final org.andromda.cartridges.spring.SuperEntity entity)
    {
        // put your implementation here
        return null;
    }
    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO2ToEntity(org.andromda.cartridges.spring.SuperEntityVO2)
     */
    public org.andromda.cartridges.spring.SuperEntity superEntityVO2ToEntity(org.andromda.cartridges.spring.SuperEntityVO2 superEntityVO2)
    {
        // put your implementation here
        return null;    
    }

    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO1(org.andromda.cartridges.spring.SuperEntity)
     */
    public org.andromda.cartridges.spring.SuperEntityVO1 toSuperEntityVO1(final org.andromda.cartridges.spring.SuperEntity entity)
    {
        // put your implementation here
        return null;
    }
    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO1ToEntity(org.andromda.cartridges.spring.SuperEntityVO1)
     */
    public org.andromda.cartridges.spring.SuperEntity superEntityVO1ToEntity(org.andromda.cartridges.spring.SuperEntityVO1 superEntityVO1)
    {
        // put your implementation here
        return null;    
    }

}