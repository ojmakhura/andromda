/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Futurenum;
import org.andromda.cartridges.spring.crud.Mansion;
public interface MansionManageableDao
{
    public Mansion create(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion);

    public Mansion readById(Long id);

    public List read(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion);

    public List readAll();

    public Map readBackingLists();

    public Mansion update(String name, String something, Futurenum enumAttribute, Long id, Long[] houses, Long room, Long[] gardens, Long mansion);

    public void delete(Long[] ids);

}