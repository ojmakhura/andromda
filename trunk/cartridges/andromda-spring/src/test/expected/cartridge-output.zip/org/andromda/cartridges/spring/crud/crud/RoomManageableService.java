/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.Date;
import java.util.List;
import java.util.Map;
public interface RoomManageableService
{
    public RoomValueObject create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception;

    public RoomValueObject readById(Long specificId)
        throws Exception;

    public List read(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception;

    public List readAll()
        throws Exception;

    public Map readBackingLists()
        throws Exception;

    public RoomValueObject update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception;

    public void delete(Long[] ids)
        throws Exception;

}
