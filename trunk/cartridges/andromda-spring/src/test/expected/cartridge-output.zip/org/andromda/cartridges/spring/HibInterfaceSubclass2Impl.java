/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.HibInterfaceSubclass2
 */
public class HibInterfaceSubclass2Impl
	extends org.andromda.cartridges.spring.HibInterfaceSubclassImpl
{
	/**
	 * @see org.andromda.cartridges.spring.HibInterfaceSubclass2Dao#sc2Op()
	 */
    public java.lang.String sc2Op() 
    {
        //@todo implement public java.lang.String sc2Op()
        return null;
    }
	
}
