/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ChildEntity
 */
public class ChildEntityDaoImpl
	extends org.andromda.cartridges.spring.SubEntityDaoImpl
{
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDaoBase#transformEntity(org.andromda.cartridges.spring.ChildEntity)
     */ 
    protected Object transformEntity(org.andromda.cartridges.spring.ChildEntity entity)
    {
        /* 
         * This method provides the ability to transform 
         * any returned entity (from finders or a call to load) 
         * into value objects.  If you aren't using value objects, 
         * and just want to return the entities directly, leave 
         * this method unchanged
         */
        return entity;
    }
    
}