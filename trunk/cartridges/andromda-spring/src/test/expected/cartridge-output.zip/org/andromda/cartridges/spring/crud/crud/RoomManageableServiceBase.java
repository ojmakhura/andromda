/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.andromda.cartridges.spring.crud.Garden;
import org.andromda.cartridges.spring.crud.House;
import org.andromda.cartridges.spring.crud.Room;
public final class RoomManageableServiceBase
    implements RoomManageableService
{
    private RoomManageableDao dao;

    public void setDao(RoomManageableDao dao)
    {
        this.dao = dao;
    }

    protected RoomManageableDao getDao()
    {
        return this.dao;
    }

    public RoomValueObject create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception
    {
        if (date == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos) - 'date' can not be null");
        }

        if (named == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.create(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos) - 'named' can not be null");
        }

        return toValueObject(dao.create(date, specificId, gardens, named, hellos));
    }

    public RoomValueObject readById(Long specificId)
        throws Exception
    {
        return toValueObject(dao.readById(specificId));
    }

    public List read(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception
    {
        return toValueObjects(dao.read(date, specificId, gardens, named, hellos));
    }

    public List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public RoomValueObject update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos)
        throws Exception
    {
        if (date == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos) - 'date' can not be null");
        }

        if (specificId == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos) - 'specificId' can not be null");
        }

        if (named == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(Date date, Long specificId, Long[] gardens, Long named, Long[] hellos) - 'named' can not be null");
        }

        return toValueObject(dao.update(date, specificId, gardens, named, hellos));
    }

    public void delete(Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.delete(Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private static List toValueObjects(Collection entities)
    {
        final List list = new ArrayList();

        for (Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((Room)iterator.next()));
        }

        return list;
    }

    private static RoomValueObject toValueObject(Room entity)
    {
        final RoomValueObject valueObject = new RoomValueObject();

        valueObject.setDate(entity.getDate());
        valueObject.setSpecificId(entity.getSpecificId());

        final Collection gardens = entity.getGardens();
        if (gardens == null || gardens.isEmpty())
        {
            valueObject.setGardens(null);
            valueObject.setGardensLabels(null);
        }
        else
        {
            final Long[] values = new Long[gardens.size()];
            final int[] labels = new int[gardens.size()];
            int counter = 0;
            for (final Iterator iterator = gardens.iterator(); iterator.hasNext();counter++)
            {
                final Garden element = (Garden)iterator.next();
                values[counter] = element.getId();
                labels[counter] = element.getInteger();
            }
            valueObject.setGardens(values);
            valueObject.setGardensLabels(labels);
        }

        final House named = entity.getNamed();
        if (named != null)
        {
            valueObject.setNamed(named.getId());
        }

        final Collection hellos = entity.getHellos();
        if (hellos == null || hellos.isEmpty())
        {
            valueObject.setHellos(null);
            valueObject.setHellosLabels(null);
        }
        else
        {
            final Long[] values = new Long[hellos.size()];
            final int[] labels = new int[hellos.size()];
            int counter = 0;
            for (final Iterator iterator = hellos.iterator(); iterator.hasNext();counter++)
            {
                final Garden element = (Garden)iterator.next();
                values[counter] = element.getId();
                labels[counter] = element.getInteger();
            }
            valueObject.setHellos(values);
            valueObject.setHellosLabels(labels);
        }

        return valueObject;
    }
}
