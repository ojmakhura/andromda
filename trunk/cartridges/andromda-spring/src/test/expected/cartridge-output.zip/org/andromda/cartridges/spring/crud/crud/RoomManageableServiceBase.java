/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public final class RoomManageableServiceBase
    implements RoomManageableService
{
    private org.andromda.cartridges.spring.crud.crud.RoomManageableDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.crud.RoomManageableDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.crud.RoomManageableDao getDao()
    {
        return this.dao;
    }

    public void create(java.util.Date date, java.lang.Long specificId, java.lang.Long named)
        throws Exception
    {
        if (date == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.create(java.util.Date date, java.lang.Long specificId, java.lang.Long named) - 'date' can not be null");
        }

        if (named == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.create(java.util.Date date, java.lang.Long specificId, java.lang.Long named) - 'named' can not be null");
        }

        dao.create(date, specificId, named);
    }

    public java.util.List read(java.util.Date date, java.lang.Long specificId, java.lang.Long named)
        throws Exception
    {
        return toValueObjects(dao.read(date, specificId, named));
    }

    public java.util.List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public java.util.Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public void update(java.util.Date date, java.lang.Long specificId, java.lang.Long named)
        throws Exception
    {
        if (date == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(java.util.Date date, java.lang.Long specificId, java.lang.Long named) - 'date' can not be null");
        }

        if (specificId == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(java.util.Date date, java.lang.Long specificId, java.lang.Long named) - 'specificId' can not be null");
        }

        if (named == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.update(java.util.Date date, java.lang.Long specificId, java.lang.Long named) - 'named' can not be null");
        }

        dao.update(date, specificId, named);
    }

    public void delete(java.lang.Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.RoomManageableService.delete(java.lang.Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private java.util.List toValueObjects(java.util.Collection entities)
    {
        final java.util.List list = new java.util.ArrayList();

        for (java.util.Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((org.andromda.cartridges.spring.crud.Room)iterator.next()));
        }

        return list;
    }

    private org.andromda.cartridges.spring.crud.crud.RoomValueObject toValueObject(org.andromda.cartridges.spring.crud.Room entity)
    {
        final org.andromda.cartridges.spring.crud.crud.RoomValueObject valueObject = new org.andromda.cartridges.spring.crud.crud.RoomValueObject();

        valueObject.setDate(entity.getDate());
        valueObject.setSpecificId(entity.getSpecificId());

        final org.andromda.cartridges.spring.crud.House named = entity.getNamed();
        if (named != null)
        {
            valueObject.setNamed(named.getId());
        }

        return valueObject;
    }
}
