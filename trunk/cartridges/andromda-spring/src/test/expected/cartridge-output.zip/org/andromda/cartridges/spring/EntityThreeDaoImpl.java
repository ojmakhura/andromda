/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityThree
 */
public class EntityThreeDaoImpl
    extends org.andromda.cartridges.spring.EntityThreeDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#toAttributeTwo(org.andromda.cartridges.spring.EntityThree)
     */
    public java.lang.Long toAttributeTwo(final org.andromda.cartridges.spring.EntityThree entity)
    {
        // @todo implement toAttributeTwo
        return null;
    }
    
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#attributeTwoToEntity(java.lang.Long)
     */
    public org.andromda.cartridges.spring.EntityThree attributeTwoToEntity(java.lang.Long attributeTwo)
    {
        // @todo implement attributeTwoToEntity
        return null;    
    }

}