/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see EntityThree
 */
public class EntityThreeDaoImpl
    extends EntityThreeDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#toAttributeTwo(EntityThree, Long)
     */
    public void toAttributeTwo(
        EntityThree source,
        Long target)
    {
        // @todo verify behavior of toAttributeTwo
        super.toAttributeTwo(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#toAttributeTwo(EntityThree)
     */
    public Long toAttributeTwo(final EntityThree entity)
    {
        // @todo verify behavior of toAttributeTwo
        return super.toAttributeTwo(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private EntityThree loadEntityThreeFromLong(Long attributeTwo)
    {
        // @todo implement loadEntityThreeFromLong
        throw new UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityThreeFromLong(Long) not yet implemented.");

        /* A typical implementation looks like this:
        EntityThree entityThree = this.load(attributeTwo.getId());
        if (entityThree == null)
        {
            entityThree = EntityThree.Factory.newInstance();
        }
        return entityThree;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#attributeTwoToEntity(Long)
     */
    public EntityThree attributeTwoToEntity(Long attributeTwo)
    {
        // @todo verify behavior of attributeTwoToEntity
        EntityThree entity = this.loadEntityThreeFromLong(attributeTwo);
        this.attributeTwoToEntity(attributeTwo, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityThreeDao#attributeTwoToEntity(Long, EntityThree)
     */
    public void attributeTwoToEntity(
        Long source,
        EntityThree target,
        boolean copyIfNull)
    {
        // @todo verify behavior of attributeTwoToEntity
        super.attributeTwoToEntity(source, target, copyIfNull);
    }

}