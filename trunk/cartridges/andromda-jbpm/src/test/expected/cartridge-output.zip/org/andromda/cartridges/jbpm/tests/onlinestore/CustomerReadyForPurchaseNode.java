package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * The node representing the customer ready for purchase state in the <em>Online Store</em> process.
 */
public final class CustomerReadyForPurchaseNode implements OnlineStoreNode
{
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    CustomerReadyForPurchaseNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Signals the process to leave this node via the <em>select article</em> transition and proceed to the next one.
     *
     * @return the next node in the process after following the <em>select article</em> transition
     */
    public ArticleSelectedNode signalSelectArticle()
    {
        this.token.signal("select article");
        return new ArticleSelectedNode(this.token);
    }

    /**
     * Signals the process to leave this node via the <em>check out</em> transition and proceed to the next one.
     * Since this transition leads into a node that will split it up into different transitions
     * this method returns the {@link OnlineStoreNode} instead of a concrete implementing class type.
     *
     * @return the next node in the process after following the <em>check out</em> transition
     */
    public OnlineStoreNode signalCheckOut()
    {
        this.token.signal("check out");
        OnlineStoreNode targetNode = null;
        final java.lang.String nodeName = this.token.getNode().getName();

        if ("checking out".equals(nodeName)) targetNode = new CheckingOutNode(this.token); else
        throw new IllegalArgumentException("No matching node could be found for target token: " + nodeName);

        return targetNode;
    }

}