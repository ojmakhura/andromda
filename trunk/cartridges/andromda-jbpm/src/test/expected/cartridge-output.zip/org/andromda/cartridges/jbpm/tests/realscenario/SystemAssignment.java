package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * 
 */
public abstract class SystemAssignment implements org.jbpm.taskmgmt.def.AssignmentHandler
{
    public final void assign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        handleAssign(assignable, executionContext);
    }

    protected abstract void handleAssign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;
}
