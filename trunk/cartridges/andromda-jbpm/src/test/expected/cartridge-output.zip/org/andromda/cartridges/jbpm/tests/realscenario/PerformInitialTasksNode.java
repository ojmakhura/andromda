package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * The node representing the perform initial tasks state in the <em>Real Scenario</em> process.
 */
public final class PerformInitialTasksNode implements RealScenarioProcessNode
{
    /**
     * This is the token encapsulated by this node class. It represents the internal jBpm state of the corresponding
     * process instance.
     */
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    PerformInitialTasksNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Returns true if all tasks for this node are ended.
     *
     * @return true if this node does not have any tasks that have not yet been finished, false otherwise
     */
    public boolean isTasksFinished()
    {
        return !this.token.getProcessInstance().getTaskMgmtInstance().hasUnfinishedTasks(this.token);
    }

    /**
     * Starts this node's <em>createFile</em> task.
     */
    public void startCreateFile()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getCreateFileTask();
        if (task != null)
        {
            task.start();
        }
    }

    /**
     * Finishes this node's <em>createFile</em> task.
     */
    public void finishCreateFile()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getCreateFileTask();
        if (task != null)
        {
            task.end();
        }
    }

    /**
     * Checks whether or not this node's <em>createFile</em> task has been finished.
     *
     * @return true if this node's createFile has been finished, false otherwise
     */
    public boolean isCreateFileFinished()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getCreateFileTask();
        return task == null || task.hasEnded();
    }

    private org.jbpm.taskmgmt.exe.TaskInstance taskCreateFile = null;

    /**
     * Returns the first unfinished <em>CreateFile</em> task that can be found.
     */
    public org.jbpm.taskmgmt.exe.TaskInstance getCreateFileTask()
    {
        if (this.taskCreateFile == null)
        {
            final java.util.Collection tasks = this.token.getProcessInstance().getTaskMgmtInstance().getTaskInstances();
            for (final java.util.Iterator taskIterator = tasks.iterator(); taskIterator.hasNext() && this.taskCreateFile == null;)
            {
                final org.jbpm.taskmgmt.exe.TaskInstance taskInstance = (org.jbpm.taskmgmt.exe.TaskInstance)taskIterator.next();
                if ("createFile".equals(taskInstance.getName()) && taskInstance.getEnd() == null)
                {
                    this.taskCreateFile = taskInstance;
                }
            }
        }
        return this.taskCreateFile;
    }

    /**
     * Starts this node's <em>integrateMember</em> task.
     */
    public void startIntegrateMember()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getIntegrateMemberTask();
        if (task != null)
        {
            task.start();
        }
    }

    /**
     * Finishes this node's <em>integrateMember</em> task.
     */
    public void finishIntegrateMember()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getIntegrateMemberTask();
        if (task != null)
        {
            task.end();
        }
    }

    /**
     * Checks whether or not this node's <em>integrateMember</em> task has been finished.
     *
     * @return true if this node's integrateMember has been finished, false otherwise
     */
    public boolean isIntegrateMemberFinished()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getIntegrateMemberTask();
        return task == null || task.hasEnded();
    }

    private org.jbpm.taskmgmt.exe.TaskInstance taskIntegrateMember = null;

    /**
     * Returns the first unfinished <em>IntegrateMember</em> task that can be found.
     */
    public org.jbpm.taskmgmt.exe.TaskInstance getIntegrateMemberTask()
    {
        if (this.taskIntegrateMember == null)
        {
            final java.util.Collection tasks = this.token.getProcessInstance().getTaskMgmtInstance().getTaskInstances();
            for (final java.util.Iterator taskIterator = tasks.iterator(); taskIterator.hasNext() && this.taskIntegrateMember == null;)
            {
                final org.jbpm.taskmgmt.exe.TaskInstance taskInstance = (org.jbpm.taskmgmt.exe.TaskInstance)taskIterator.next();
                if ("integrateMember".equals(taskInstance.getName()) && taskInstance.getEnd() == null)
                {
                    this.taskIntegrateMember = taskInstance;
                }
            }
        }
        return this.taskIntegrateMember;
    }

    /**
     * Starts this node's <em>sendFlows</em> task.
     */
    public void startSendFlows()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getSendFlowsTask();
        if (task != null)
        {
            task.start();
        }
    }

    /**
     * Finishes this node's <em>sendFlows</em> task.
     */
    public void finishSendFlows()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getSendFlowsTask();
        if (task != null)
        {
            task.end();
        }
    }

    /**
     * Checks whether or not this node's <em>sendFlows</em> task has been finished.
     *
     * @return true if this node's sendFlows has been finished, false otherwise
     */
    public boolean isSendFlowsFinished()
    {
        final org.jbpm.taskmgmt.exe.TaskInstance task = this.getSendFlowsTask();
        return task == null || task.hasEnded();
    }

    private org.jbpm.taskmgmt.exe.TaskInstance taskSendFlows = null;

    /**
     * Returns the first unfinished <em>SendFlows</em> task that can be found.
     */
    public org.jbpm.taskmgmt.exe.TaskInstance getSendFlowsTask()
    {
        if (this.taskSendFlows == null)
        {
            final java.util.Collection tasks = this.token.getProcessInstance().getTaskMgmtInstance().getTaskInstances();
            for (final java.util.Iterator taskIterator = tasks.iterator(); taskIterator.hasNext() && this.taskSendFlows == null;)
            {
                final org.jbpm.taskmgmt.exe.TaskInstance taskInstance = (org.jbpm.taskmgmt.exe.TaskInstance)taskIterator.next();
                if ("sendFlows".equals(taskInstance.getName()) && taskInstance.getEnd() == null)
                {
                    this.taskSendFlows = taskInstance;
                }
            }
        }
        return this.taskSendFlows;
    }

    /**
     * Signals the process to leave this node
     * and proceed to the next one.
     *
     * @return the next node in the process
     */
    public CheckFileCompletenessNode signal()
    {
        // signal this token to leave its node
        this.token.signal();

        // simply return the next node instance
        return new CheckFileCompletenessNode(this.token);
    }

    /**
     * Overrides the default behavior of the <code>toString()</code> method in order
     * to be able to display this node's name as well as the name of the encapsulated token.
     */
    public String toString()
    {
        return "org.andromda.cartridges.jbpm.tests.realscenario.PerformInitialTasksNode[" + this.token.getName() + "]";
    }
}