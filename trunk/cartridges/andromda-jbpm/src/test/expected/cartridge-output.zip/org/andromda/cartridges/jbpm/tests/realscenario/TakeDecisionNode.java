package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.Token;
/**
 * The node representing the take decision state in the <em>Real Scenario</em> process.
 */
public final class TakeDecisionNode implements RealScenarioProcessNode
{
    /**
     * This is the token encapsulated by this node class. It represents the internal jBpm state of the corresponding
     * process instance.
     */
    private Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    TakeDecisionNode(final Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public Long getProcessInstanceId()
    {
        return new Long(this.token.getProcessInstance().getId());
    }

    /**
     * The name of one of the transitions exiting this node.
     */
    public static final String TRANSITION_CHECK_USEFUL_PERIOD_AND_TAKE_DECISION = "check useful period and take decision";

    /**
     * The name of one of the transitions exiting this node.
     */
    public static final String TRANSITION_ADDITIONAL_REQUESTS = "additional requests";

    /**
     * Signals the process to leave this node
     * via the <em>check useful period and take decision</em> transition
     * and proceed to the next one. The transition taken is represented by the
     * <code>TRANSITION_CHECK_USEFUL_PERIOD_AND_TAKE_DECISION</code> constant.
     *
     * @return the next node in the process
     *      after following the <em>check useful period and take decision</em> transition
     * @see ##renderTransitionName(check useful period and take decision)
     */
    public DecisionTakenNode signalCheckUsefulPeriodAndTakeDecision()
    {
        // signal this token to leave its node
        this.token.signal(TRANSITION_CHECK_USEFUL_PERIOD_AND_TAKE_DECISION);

        // simply return the next node instance
        return new DecisionTakenNode(this.token);
    }

    /**
     * Signals the process to leave this node
     * via the <em>additional requests</em> transition
     * and proceed to the next one. The transition taken is represented by the
     * <code>TRANSITION_ADDITIONAL_REQUESTS</code> constant.
     *
     * @return the next node in the process
     *      after following the <em>additional requests</em> transition
     * @see ##renderTransitionName(additional requests)
     */
    public CheckFileCompletenessNode signalAdditionalRequests()
    {
        // signal this token to leave its node
        this.token.signal(TRANSITION_ADDITIONAL_REQUESTS);

        // simply return the next node instance
        return new CheckFileCompletenessNode(this.token);
    }

    /**
     * Overrides the default behavior of the <code>toString()</code> method in order
     * to be able to display this node's name as well as the name of the encapsulated token.
     */
    public String toString()
    {
        return "org.andromda.cartridges.jbpm.tests.realscenario.TakeDecisionNode[" + this.token.getName() + "]";
    }
}