package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * @see {@link CustomerCheckOutCredentialsOkay}
 */
public class CustomerCheckOutCredentialsOkayImpl extends CustomerCheckOutCredentialsOkay
{
    protected final java.lang.String handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        return null;
    }
}
