package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * This helper class provides static utility methods to more easily handle
 * the jBPM process API for the 'Real Scenario' process.
 */
public class RealScenario
{
    /**
     * The name for this process, this is the name used in the corresponding jPDL descriptor file.
     */
    public static final java.lang.String PROCESS_NAME = "Real Scenario";

    /**
     * Creates a new process instance and returns the node representing the start state
     * in which the root token will be present.
     *
     * @param session the session into which to perform this operation
     * @return the node in which the process is started
     */
    public static StartNode startProcess(final org.jbpm.db.JbpmSession session)
    {
        // the graph session allows us to work with the process definition
        final org.jbpm.db.GraphSession graphSession = session.getGraphSession();

        // find the latest process definition we can use
        final org.jbpm.graph.def.ProcessDefinition processDefinition =
                graphSession.findLatestProcessDefinition(PROCESS_NAME);

        // create a new process
        final org.jbpm.graph.exe.ProcessInstance processInstance = processDefinition.createProcessInstance();

        // return the first node in the process
        return new StartNode(processInstance.getRootToken());
    }

    /**
     * Finds the process instance with the given id and returns the node representing the state in which
     * the process is in.
     *
     * @param session the session into which to perform this operation
     * @param processInstanceId the identifier for the process instance to load
     * @return the node in which the process instance with the argument id is currently present
     */
    public static RealScenarioNode getProcess(final org.jbpm.db.JbpmSession session, final java.lang.Long processInstanceId)
    {
        // the graph session allows us to work with the process definition
        final org.jbpm.db.GraphSession graphSession = session.getGraphSession();

        // load the process using the unique identifier argument
        final org.jbpm.graph.exe.ProcessInstance processInstance = graphSession.loadProcessInstance(processInstanceId.longValue());

        // the token for this process instance
        final org.jbpm.graph.exe.Token token = processInstance.getRootToken();

        // find the node we're in
        RealScenarioNode currentNode = null;
        final String nodeName = token.getNode().getName();
        if ("start".equals(nodeName)) currentNode = new StartNode(token); else
        if ("await responses".equals(nodeName)) currentNode = new AwaitResponsesNode(token); else
        if ("perform initial tasks".equals(nodeName)) currentNode = new PerformInitialTasksNode(token); else
        if ("take decision".equals(nodeName)) currentNode = new TakeDecisionNode(token); else
        if ("decision taken".equals(nodeName)) currentNode = new DecisionTakenNode(token); else
        if ("conflicts in file".equals(nodeName)) currentNode = new ConflictsInFileNode(token); else
        {
            throw new IllegalArgumentException("No matching node could be found for the process instance: " + nodeName);
        }

        return currentNode;
    }

    public static final String TASK_CREATE_FILE_NAME = "createFile";
    public static final String TASK_INTEGRATE_MEMBER_NAME = "integrateMember";
    public static final String TASK_SEND_FLOWS_NAME = "sendFlows";

    /**
     * Checks whether or not the argument node represent the start state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.StartNode}
     */
    public static boolean isStartNode(final RealScenarioNode node)
    {
        return node instanceof StartNode;
    }

    /**
     * Checks whether or not the argument node represent the await responses state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.AwaitResponsesNode}
     */
    public static boolean isAwaitResponsesNode(final RealScenarioNode node)
    {
        return node instanceof AwaitResponsesNode;
    }

    /**
     * Checks whether or not the argument node represent the perform initial tasks state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.PerformInitialTasksNode}
     */
    public static boolean isPerformInitialTasksNode(final RealScenarioNode node)
    {
        return node instanceof PerformInitialTasksNode;
    }

    /**
     * Checks whether or not the argument node represent the take decision state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.TakeDecisionNode}
     */
    public static boolean isTakeDecisionNode(final RealScenarioNode node)
    {
        return node instanceof TakeDecisionNode;
    }

    /**
     * Checks whether or not the argument node represent the decision taken state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.DecisionTakenNode}
     */
    public static boolean isDecisionTakenNode(final RealScenarioNode node)
    {
        return node instanceof DecisionTakenNode;
    }

    /**
     * Checks whether or not the argument node represent the conflicts in file state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.realscenario.ConflictsInFileNode}
     */
    public static boolean isConflictsInFileNode(final RealScenarioNode node)
    {
        return node instanceof ConflictsInFileNode;
    }


    /**
     * Saves the process instance to which this node is associated.
     *
     * @param session the session into which to perform this operation
     * @param node the process instance to persist will be retrieved from this node
     */
    public static void save(final org.jbpm.db.JbpmSession session, final RealScenarioNode node)
    {
        session.getGraphSession().saveProcessInstance(node.getToken().getProcessInstance());
    }
}

