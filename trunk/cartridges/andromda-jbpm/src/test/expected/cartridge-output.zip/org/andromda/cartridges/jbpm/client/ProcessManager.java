package org.andromda.cartridges.jbpm.client;

public final class ProcessManager
{
    /**
     * Constructs the jBpm session factory, this will initialize the environment.
     */
    private final static org.jbpm.db.JbpmSessionFactory SESSION_FACTORY =
        org.jbpm.db.JbpmSessionFactory.buildJbpmSessionFactory();

	/**
	 * Injects the process definitions into the database, this should only be done once.
	 */
	public static void injectAllProcessDefinitions() throws java.lang.Exception
	{
		final org.jbpm.graph.def.ProcessDefinition onlineStoreDefinition =
		    org.jbpm.graph.def.ProcessDefinition.parseXmlResource("org/andromda/cartridges/jbpm/tests/onlinestore/online-store.pdl.xml");
		final org.jbpm.graph.def.ProcessDefinition realScenarioDefinition =
		    org.jbpm.graph.def.ProcessDefinition.parseXmlResource("org/andromda/cartridges/jbpm/tests/realscenario/real-scenario.pdl.xml");

	    final org.jbpm.db.JbpmSession session = SESSION_FACTORY.openJbpmSession();
        final org.jbpm.db.GraphSession graphSession = session.getGraphSession();

	    session.beginTransaction();
	    graphSession.saveProcessDefinition(onlineStoreDefinition);
	    graphSession.saveProcessDefinition(realScenarioDefinition);
        session.commitTransactionAndClose();
	}

    public static void createProcessSchema() throws java.lang.Exception
    {
        SESSION_FACTORY.getJbpmSchema().createSchema();
    }

    public static void dropProcessSchema() throws java.lang.Exception
    {
        SESSION_FACTORY.getJbpmSchema().dropSchema();
    }

    public static void cleanProcessSchema() throws java.lang.Exception
    {
        SESSION_FACTORY.getJbpmSchema().cleanSchema();
    }

    public static boolean isProcessSchemaAvailable() throws java.lang.Exception
    {
        return SESSION_FACTORY.getJbpmSchema().hasJbpmTables();
    }
}
