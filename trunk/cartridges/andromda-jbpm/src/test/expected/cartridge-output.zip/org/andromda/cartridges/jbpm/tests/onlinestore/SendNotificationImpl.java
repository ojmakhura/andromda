package org.andromda.cartridges.jbpm.tests.onlinestore;

import org.jbpm.graph.exe.ExecutionContext;
/**
 * @see {@link SendNotification}
 */
public class SendNotificationImpl extends SendNotification
{
    protected final void handleExecute(ExecutionContext executionContext)
        throws java.lang.Exception
    {
        // @todo implement code for handleExecute
    }

}
