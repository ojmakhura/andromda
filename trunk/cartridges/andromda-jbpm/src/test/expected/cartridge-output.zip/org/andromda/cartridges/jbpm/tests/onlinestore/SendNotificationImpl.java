package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * @see {@link SendNotification}
 */
public class SendNotificationImpl extends SendNotification
{
    protected final void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        // @todo implement code for handleExecute
    }

}
