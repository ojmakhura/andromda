package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * @see {@link TakeDecision}
 */
public class TakeDecisionImpl extends TakeDecision
{
    protected final void handleExecute(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }

}
