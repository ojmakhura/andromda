package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * 
 */
public abstract class CustomerCheckOutCredentialsOkay implements org.jbpm.graph.node.DecisionHandler
{
    public final java.lang.String decide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        return handleDecide(executionContext);
    }

    protected abstract java.lang.String handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception;
}
