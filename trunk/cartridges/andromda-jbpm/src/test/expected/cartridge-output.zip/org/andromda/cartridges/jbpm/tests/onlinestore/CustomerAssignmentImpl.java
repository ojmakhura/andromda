package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * @see {@link CustomerAssignment}
 */
public class CustomerAssignmentImpl extends CustomerAssignment
{
    protected void handleAssign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
    }
}
