package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * @see {@link SystemAssignment}
 */
public class SystemAssignmentImpl extends SystemAssignment
{
    protected void handleAssign(org.jbpm.taskmgmt.exe.Assignable assignable, org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
       // @todo implement code for handleAssign
    }
}
