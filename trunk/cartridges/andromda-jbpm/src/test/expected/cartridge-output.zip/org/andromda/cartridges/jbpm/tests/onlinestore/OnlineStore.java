package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * This helper class provides static utility methods to more easily handle
 * the jBPM process API for the 'Online Store' process.
 */
public class OnlineStore
{
    /**
     * The name for this process, this is the name used in the corresponding jPDL descriptor file.
     */
    public static final java.lang.String PROCESS_NAME = "Online Store";

    /**
     * Creates a new process instance and returns the node representing the start state
     * in which the root token will be present.
     *
     * @param session the session into which to perform this operation
     * @return the node in which the process is started
     */
    public static StartNode startProcess(final org.jbpm.db.JbpmSession session)
    {
        // the graph session allows us to work with the process definition
        final org.jbpm.db.GraphSession graphSession = session.getGraphSession();

        // find the latest process definition we can use
        final org.jbpm.graph.def.ProcessDefinition processDefinition =
                graphSession.findLatestProcessDefinition(PROCESS_NAME);

        // create a new process
        final org.jbpm.graph.exe.ProcessInstance processInstance = processDefinition.createProcessInstance();

        // return the first node in the process
        return new StartNode(processInstance.getRootToken());
    }

    /**
     * Finds the process instance with the given id and returns the node representing the state in which
     * the process is in.
     *
     * @param session the session into which to perform this operation
     * @param processInstanceId the identifier for the process instance to load
     * @return the node in which the process instance with the argument id is currently present
     */
    public static OnlineStoreNode getProcess(final org.jbpm.db.JbpmSession session, final java.lang.Long processInstanceId)
    {
        // the graph session allows us to work with the process definition
        final org.jbpm.db.GraphSession graphSession = session.getGraphSession();

        // load the process using the unique identifier argument
        final org.jbpm.graph.exe.ProcessInstance processInstance = graphSession.loadProcessInstance(processInstanceId.longValue());

        // the token for this process instance
        final org.jbpm.graph.exe.Token token = processInstance.getRootToken();

        // find the node we're in
        OnlineStoreNode currentNode = null;
        final String nodeName = token.getNode().getName();
        if ("start".equals(nodeName)) currentNode = new StartNode(token); else
        if ("article selected".equals(nodeName)) currentNode = new ArticleSelectedNode(token); else
        if ("check out confirmed".equals(nodeName)) currentNode = new CheckOutConfirmedNode(token); else
        if ("dispatching articles".equals(nodeName)) currentNode = new DispatchingArticlesNode(token); else
        if ("update credentials".equals(nodeName)) currentNode = new UpdateCredentialsNode(token); else
        if ("customer ready for purchase".equals(nodeName)) currentNode = new CustomerReadyForPurchaseNode(token); else
        if ("checking out".equals(nodeName)) currentNode = new CheckingOutNode(token); else
        if ("notifying customer".equals(nodeName)) currentNode = new NotifyingCustomerNode(token); else
        if ("items dispatched".equals(nodeName)) currentNode = new ItemsDispatchedNode(token); else
        {
            throw new IllegalArgumentException("No matching node could be found for the process instance: " + nodeName);
        }

        return currentNode;
    }

    public static final String TASK_ADD_ARTICLE_TO_BASKET_NAME = "addArticleToBasket";
    public static final String TASK_CONFIRM_CHECKOUT_CREDENTIALS_NAME = "confirmCheckoutCredentials";
    public static final String TASK_DISPATCH_ARTICLES_NAME = "dispatchArticles";
    public static final String TASK_UPDATE_CREDENTIALS_NAME = "updateCredentials";

    /**
     * Checks whether or not the argument node represent the start state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.StartNode}
     */
    public static boolean isStartNode(final OnlineStoreNode node)
    {
        return node instanceof StartNode;
    }

    /**
     * Checks whether or not the argument node represent the article selected state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.ArticleSelectedNode}
     */
    public static boolean isArticleSelectedNode(final OnlineStoreNode node)
    {
        return node instanceof ArticleSelectedNode;
    }

    /**
     * Checks whether or not the argument node represent the check out confirmed state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CheckOutConfirmedNode}
     */
    public static boolean isCheckOutConfirmedNode(final OnlineStoreNode node)
    {
        return node instanceof CheckOutConfirmedNode;
    }

    /**
     * Checks whether or not the argument node represent the dispatching articles state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.DispatchingArticlesNode}
     */
    public static boolean isDispatchingArticlesNode(final OnlineStoreNode node)
    {
        return node instanceof DispatchingArticlesNode;
    }

    /**
     * Checks whether or not the argument node represent the update credentials state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.UpdateCredentialsNode}
     */
    public static boolean isUpdateCredentialsNode(final OnlineStoreNode node)
    {
        return node instanceof UpdateCredentialsNode;
    }

    /**
     * Checks whether or not the argument node represent the customer ready for purchase state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CustomerReadyForPurchaseNode}
     */
    public static boolean isCustomerReadyForPurchaseNode(final OnlineStoreNode node)
    {
        return node instanceof CustomerReadyForPurchaseNode;
    }

    /**
     * Checks whether or not the argument node represent the checking out state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.CheckingOutNode}
     */
    public static boolean isCheckingOutNode(final OnlineStoreNode node)
    {
        return node instanceof CheckingOutNode;
    }

    /**
     * Checks whether or not the argument node represent the notifying customer state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.NotifyingCustomerNode}
     */
    public static boolean isNotifyingCustomerNode(final OnlineStoreNode node)
    {
        return node instanceof NotifyingCustomerNode;
    }

    /**
     * Checks whether or not the argument node represent the items dispatched state in this process.
     *
     * @param node the node instance to check
     * @return true if the argument is an instance of {@link org.andromda.cartridges.jbpm.tests.onlinestore.ItemsDispatchedNode}
     */
    public static boolean isItemsDispatchedNode(final OnlineStoreNode node)
    {
        return node instanceof ItemsDispatchedNode;
    }


    /**
     * Saves the process instance to which this node is associated.
     *
     * @param session the session into which to perform this operation
     * @param node the process instance to persist will be retrieved from this node
     */
    public static void save(final org.jbpm.db.JbpmSession session, final OnlineStoreNode node)
    {
        session.getGraphSession().saveProcessInstance(node.getToken().getProcessInstance());
    }
}

