package org.andromda.cartridges.jbpm.tests.realscenario;

/**
 * @see {@link CheckFileCompleteness}
 */
public class CheckFileCompletenessImpl extends CheckFileCompleteness
{
    protected final java.lang.String handleDecide(org.jbpm.graph.exe.ExecutionContext executionContext)
        throws java.lang.Exception
    {
        return null;
    }
}
