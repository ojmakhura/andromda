package org.andromda.cartridges.jbpm.tests.realscenario;

import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.graph.node.DecisionHandler;
/**
 * 
 */
public abstract class CheckFlowConflicts implements DecisionHandler
{
    public final String decide(ExecutionContext executionContext)
        throws Exception
    {
        return handleDecide(executionContext);
    }

    protected abstract String handleDecide(ExecutionContext executionContext)
        throws Exception;
}
