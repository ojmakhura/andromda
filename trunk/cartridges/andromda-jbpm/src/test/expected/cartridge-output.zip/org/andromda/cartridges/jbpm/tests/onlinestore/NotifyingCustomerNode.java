package org.andromda.cartridges.jbpm.tests.onlinestore;

/**
 * The node representing the notifying customer state in the <em>Online Store</em> process.
 */
public final class NotifyingCustomerNode implements OnlineStoreNode
{
    /**
     * This is the token encapsulated by this node class. It represents the internal jBpm state of the corresponding
     * process instance.
     */
    private org.jbpm.graph.exe.Token token = null;

    /**
     * Constructs a new node using the specific process instance token. This constructor is package private
     * because it is not supposed to be instantiated by other regular classes.
     *
     * @param token the token for which this node is constructed
     */
    NotifyingCustomerNode(final org.jbpm.graph.exe.Token token)
    {
        this.token = token;
    }

    /**
     * This node is associated with a specific process instance and this method return the root token
     * for that instance.
     *
     * @return the token with which this node has been associated (constructed)
     */
    public org.jbpm.graph.exe.Token getToken()
    {
        return this.token;
    }

    /**
     * Returns the identifier for the underlying process instance. This method is a conveniece method as it
     * is perfectly equivalent to <code>new java.lang.Long(getToken().getProcessInstance().getId())</code>.
     *
     * @return the identifier for the proces instance to which this node is associated
     */
    public java.lang.Long getProcessInstanceId()
    {
        return new java.lang.Long(this.token.getProcessInstance().getId());
    }

    /**
     * Signals the process to leave this node
     * and proceed to the next one. The transition taken is represented by the
     * <code>TRANSITION_$stringUtils.separate($name,"_").toUpperCase()</code> constant.
     *
     * @return the next node in the process
     * @see #TRANSITION_$stringUtils.separate($name,"_").toUpperCase()
     */
    public CustomerNotifiedDuringDispatchingNode signal()
    {
        // signal this token to leave its node
        this.token.signal();

        // simply return the next node instance
        return new CustomerNotifiedDuringDispatchingNode(this.token);
    }

    /**
     * Overrides the default behavior of the <code>toString()</code> method in order
     * to be able to display this node's name as well as the name of the encapsulated token.
     */
    public String toString()
    {
        return "org.andromda.cartridges.jbpm.tests.onlinestore.NotifyingCustomerNode[" + this.token.getName() + "]";
    }
}