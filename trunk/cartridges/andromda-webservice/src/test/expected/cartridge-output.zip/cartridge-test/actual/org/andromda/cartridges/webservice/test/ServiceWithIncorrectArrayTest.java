package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.ServiceWithIncorrectArray}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.ServiceWithIncorrectArray WSDL 
 *   using axis's java2wsdl tool in order to run these tests. 
 * </p>
 *
 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray
 */
public abstract class ServiceWithIncorrectArrayTest
    extends TestCase 
{

	protected ServiceWithIncorrectArray service = null;

	/**
	 * Constructor for ServiceWithIncorrectArrayTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithIncorrectArrayTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithIncorrectArray client.
	 */
	public void setUp() throws Exception
	{
		try 
		{
			this.service = org.andromda.webservice.test.TestServiceLocator.instance().getServiceWithIncorrectArray();	
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithIncorrectArrayTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithIncorrectArrayTestImpl.class);
	}

	/**
	 * Runs the ServiceWithIncorrectArrayTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithIncorrectArrayTestImpl.class.getName()});
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.ServiceWithIncorrectArray#exposedOperationWithNoNonArrayType()}
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray#exposedOperationWithNoNonArrayType()
     */ 
	public void testExposedOperationWithNoNonArrayType()
	{
		try 
		{
			this.handleTestExposedOperationWithNoNonArrayType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #exposedOperationWithNoNonArrayType()}
	 */ 
	protected abstract void handleTestExposedOperationWithNoNonArrayType()
	    throws Exception;
	
}
