/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.TestWebService2}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.TestWebService2 WSDL
 *   using axis's java2wsdl tool in order to run these tests.
 * </p>
 *
 * @see org.andromda.cartridges.webservice.TestWebService2
 */
public abstract class TestWebService2Test
    extends TestCase
{

    /**
     * Constructor for TestWebService2Test.
     *
     * @param testName name of the test.
     */
    public TestWebService2Test(String testName)
    {
        super(testName);
    }

    /**
     * Allows the TestWebService2Test to be run by JUnit as a suite.
     */
    public static Test suite()
    {
           return new TestSuite(TestWebService2TestImpl.class);
    }

    /**
     * Runs the TestWebService2Test test case.
     */
    public static void main(String[] args)
    {
        junit.textui.TestRunner.main(new String[] {TestWebService2TestImpl.class.getName()});
    }

    /**
     * The service under test.
     */
    private org.andromda.cartridges.webservice.test.TestWebService2SoapBindingStub service = null;

    /**
     * Returns the service under test {@link org.andromda.cartridges.webservice.test.TestWebService2}
     */
    protected org.andromda.cartridges.webservice.test.TestWebService2SoapBindingStub getService()
        throws Exception
    {
        if (this.username != null || this.password != null)
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestWebService2(username, password);
        }
        else
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestWebService2();
        }
        return this.service;
    }

    /**
     * The username providing access to the service under test.
     */
    private String username;

    /**
     * Sets the <code>username</code> providing access to the
     * service under test.
     *
     * @param username the username providing access to the
     *        service under test.
     */
    protected void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * The password providing access to the service under test.
     */
    private String password;

    /**
     * Sets the <code>password</code> for the service under test.
     *
     * @param password the password for the service under test.
     */
    protected void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Tests: {@link org.andromda.cartridges.webservice.TestWebService2#firstComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)}
     *
     * @see org.andromda.cartridges.webservice.TestWebService2#firstComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)
     */
    public void testFirstComplexTypeOperation()
        throws java.lang.Exception
    {
        this.handleTestFirstComplexTypeOperation();
    }

    /**
     * Provides the actual test implementation for {@link #firstComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)}
     */
    protected abstract void handleTestFirstComplexTypeOperation()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.TestWebService2#fourComplexTypeOperation()}
     *
     * @see org.andromda.cartridges.webservice.TestWebService2#fourComplexTypeOperation()
     */
    public void testFourComplexTypeOperation()
        throws java.lang.Exception
    {
        this.handleTestFourComplexTypeOperation();
    }

    /**
     * Provides the actual test implementation for {@link #fourComplexTypeOperation()}
     */
    protected abstract void handleTestFourComplexTypeOperation()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.TestWebService2#secondComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)}
     *
     * @see org.andromda.cartridges.webservice.TestWebService2#secondComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)
     */
    public void testSecondComplexTypeOperation()
        throws java.lang.Exception
    {
        this.handleTestSecondComplexTypeOperation();
    }

    /**
     * Provides the actual test implementation for {@link #secondComplexTypeOperation(java.lang.Integer paramOne, java.lang.String paramTwo)}
     */
    protected abstract void handleTestSecondComplexTypeOperation()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.TestWebService2#thirdComplexTypeOperation()}
     *
     * @see org.andromda.cartridges.webservice.TestWebService2#thirdComplexTypeOperation()
     */
    public void testThirdComplexTypeOperation()
        throws java.lang.Exception
    {
        this.handleTestThirdComplexTypeOperation();
    }

    /**
     * Provides the actual test implementation for {@link #thirdComplexTypeOperation()}
     */
    protected abstract void handleTestThirdComplexTypeOperation()
        throws java.lang.Exception;

}