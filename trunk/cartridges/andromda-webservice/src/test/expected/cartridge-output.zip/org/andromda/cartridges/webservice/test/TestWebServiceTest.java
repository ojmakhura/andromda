package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.TestWebService}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.TestWebService WSDL 
 *   using axis's java2wsdl tool in order to run these tests. 
 * </p>
 *
 * @see org.andromda.cartridges.webservice.TestWebService
 */
public abstract class TestWebServiceTest
    extends TestCase 
{

	/**
	 * Constructor for TestWebServiceTest.
	 *
	 * @param testName name of the test.
	 */
	public TestWebServiceTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Allows the TestWebServiceTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(TestWebServiceTestImpl.class);
	}

	/**
	 * Runs the TestWebServiceTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {TestWebServiceTestImpl.class.getName()});
	}
	
	/**
	 * The service under test.
	 */
	private org.andromda.cartridges.webservice.test.TestWebService service = null;
	
	/**
	 * Returns the service under test {@link org.andromda.cartridges.webservice.test.TestWebService}
	 */
	protected org.andromda.cartridges.webservice.test.TestWebService getService() 
	    throws Exception
	{
	    if (this.username != null || this.password != null)
	    {
	        this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestWebService(username, password); 
	    }
	    else
	    {
	        this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestWebService();
	    }
	    return this.service;
	}
	
	/**
	 * The username providing access to the service under test.
	 */
	private String username;
	
	/**
	 * Sets the <code>username</code> providing access to the 
	 * service under test.
	 *
	 * @param username the username providing access to the 
	 *        service under test.
	 */ 
	protected void setUsername(String username)
    {
        this.username = username;
    }
	
	/**
	 * The password providing access to the service under test.
	 */ 
	private String password;
	
	/**
	 * Sets the <code>password</code> for the service under test.
	 *
	 * @param password the password for the service under test.
	 */
	protected void setPassword(String password)
	{
	    this.password = password;
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.TestWebService#operationWithSingleComplexReturnType(java.lang.String firstParameter)}
	 *
	 * @see org.andromda.cartridges.webservice.TestWebService#operationWithSingleComplexReturnType(java.lang.String firstParameter)
     */ 
	public void testOperationWithSingleComplexReturnType()
	    throws java.lang.Exception
	{
        this.handleTestOperationWithSingleComplexReturnType();
	}
	
	/**
	 * Provides the actual test implementation for {@link #operationWithSingleComplexReturnType(java.lang.String firstParameter)}
	 */ 
	protected abstract void handleTestOperationWithSingleComplexReturnType()
	    throws java.lang.Exception;
	
}
