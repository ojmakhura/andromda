package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.TestServiceWithCollection}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.TestServiceWithCollection WSDL 
 *   using axis's java2wsdl tool in order to run these tests. 
 * </p>
 *
 * @see org.andromda.cartridges.webservice.TestServiceWithCollection
 */
public abstract class TestServiceWithCollectionTest
    extends TestCase 
{

	/**
	 * Constructor for TestServiceWithCollectionTest.
	 *
	 * @param testName name of the test.
	 */
	public TestServiceWithCollectionTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Allows the TestServiceWithCollectionTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(TestServiceWithCollectionTestImpl.class);
	}

	/**
	 * Runs the TestServiceWithCollectionTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {TestServiceWithCollectionTestImpl.class.getName()});
	}
	
	/**
	 * The service under test.
	 */
	private org.andromda.cartridges.webservice.test.TestServiceWithCollection service = null;
	
	/**
	 * Returns the service under test {@link org.andromda.cartridges.webservice.test.TestServiceWithCollection}
	 */
	protected org.andromda.cartridges.webservice.test.TestServiceWithCollection getService() 
	    throws Exception
	{
	    if (this.username != null || this.password != null)
	    {
	        this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestServiceWithCollection(username, password); 
	    }
	    else
	    {
	        this.service = org.andromda.webservice.test.TestServiceLocator.instance().getTestServiceWithCollection();
	    }
	    return this.service;
	}
	
	/**
	 * The username providing access to the service under test.
	 */
	private String username;
	
	/**
	 * Sets the <code>username</code> providing access to the 
	 * service under test.
	 *
	 * @param username the username providing access to the 
	 *        service under test.
	 */ 
	protected void setUsername(String username)
    {
        this.username = username;
    }
	
	/**
	 * The password providing access to the service under test.
	 */ 
	private String password;
	
	/**
	 * Sets the <code>password</code> for the service under test.
	 *
	 * @param password the password for the service under test.
	 */
	protected void setPassword(String password)
	{
	    this.password = password;
	}
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)}
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)
     */ 
	public void testExposedOperationWithCollectionReturnType()
	{
		try 
		{
			this.handleTestExposedOperationWithCollectionReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #exposedOperationWithCollectionReturnType(java.lang.String nonRequiredParameter, java.lang.String requiredParameter)}
	 */ 
	protected abstract void handleTestExposedOperationWithCollectionReturnType()
	    throws Exception;
	
	/**
	 * Tests: {@link org.andromda.cartridges.webservice.TestServiceWithCollection#testUniqueName(java.lang.String paramOne)}
	 *
	 * @see org.andromda.cartridges.webservice.TestServiceWithCollection#testUniqueName(java.lang.String paramOne)
     */ 
	public void testTestUniqueName()
	{
		try 
		{
			this.handleTestTestUniqueName();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
	}
	
	/**
	 * Provides the actual test implementation for {@link #testUniqueName(java.lang.String paramOne)}
	 */ 
	protected abstract void handleTestTestUniqueName()
	    throws Exception;
	
}
