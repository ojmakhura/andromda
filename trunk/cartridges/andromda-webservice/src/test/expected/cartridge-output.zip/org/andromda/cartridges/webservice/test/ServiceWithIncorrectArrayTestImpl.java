/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.ServiceWithIncorrectArrayTest
 */
public class ServiceWithIncorrectArrayTestImpl
    extends ServiceWithIncorrectArrayTest
{

    /**
     * Constructor for ServiceWithIncorrectArrayTest.
     *
     * @param testName name of the test.
     */
    public ServiceWithIncorrectArrayTestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithIncorrectArrayTest#testExposedOperationWithNoNonArrayType()
     */
    public void handleTestExposedOperationWithNoNonArrayType()
        throws Exception
    {
        this.getService().exposedOperationWithNoNonArrayType();
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithIncorrectArrayTest.handleTestExposedOperationWithNoNonArrayType()
    }

}