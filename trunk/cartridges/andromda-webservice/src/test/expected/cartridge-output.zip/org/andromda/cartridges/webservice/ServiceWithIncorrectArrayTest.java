package org.andromda.cartridges.webservice;


import org.andromda.cartridges.webservice.test.ServiceWithIncorrectArrayServiceLocator;
import org.andromda.cartridges.webservice.test.ServiceWithIncorrectArray;
import org.andromda.cartridges.webservice.test.ServiceWithIncorrectArraySoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test for web service 'org.andromda.cartridges.webservice.ServiceWithIncorrectArray'.
 *
 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray
 */
public class ServiceWithIncorrectArrayTest
    extends TestCase 
{

	private ServiceWithIncorrectArray service = null;

	/**
	 * Constructor for ServiceWithIncorrectArrayTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithIncorrectArrayTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithIncorrectArray client.
	 */
	public void setUp() {
		try 
		{
			ServiceWithIncorrectArrayServiceLocator locator = 
				new ServiceWithIncorrectArrayServiceLocator();
			this.service = locator.getServiceWithIncorrectArray();
			ServiceWithIncorrectArraySoapBindingStub stub = 
				(ServiceWithIncorrectArraySoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithIncorrectArrayTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithIncorrectArrayTest.class);
	}

	/**
	 * Runs the ServiceWithIncorrectArrayTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithIncorrectArrayTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithIncorrectArray.exposedOperationWithNoNonArrayType()
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithIncorrectArray#exposedOperationWithNoNonArrayType()()
     */ 
	public void testExposedOperationWithNoNonArrayType() 
	{
		try 
		{
			this.service.exposedOperationWithNoNonArrayType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithIncorrectArrayTest.testExposedOperationWithNoNonArrayType()  
	}
	

}
