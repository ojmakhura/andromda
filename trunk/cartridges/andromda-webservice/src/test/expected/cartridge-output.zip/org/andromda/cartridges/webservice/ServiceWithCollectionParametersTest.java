package org.andromda.cartridges.webservice;


import org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersServiceLocator;
import org.andromda.cartridges.webservice.test.ServiceWithCollectionParameters;
import org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersSoapBindingStub;

import javax.xml.rpc.ServiceException;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;


/**
 * JUnit test for web service 'org.andromda.cartridges.webservice.ServiceWithCollectionParameters'.
 *
 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters
 */
public class ServiceWithCollectionParametersTest
    extends TestCase 
{

	private ServiceWithCollectionParameters service = null;

	/**
	 * Constructor for ServiceWithCollectionParametersTest.
	 *
	 * @param testName name of the test.
	 */
	public ServiceWithCollectionParametersTest(String testName) 
	{
		super(testName);
	}
	
	/**
	 * Sets up the ServiceWithCollectionParameters client.
	 */
	public void setUp() {
		try 
		{
			ServiceWithCollectionParametersServiceLocator locator = 
				new ServiceWithCollectionParametersServiceLocator();
			this.service = locator.getServiceWithCollectionParameters();
			ServiceWithCollectionParametersSoapBindingStub stub = 
				(ServiceWithCollectionParametersSoapBindingStub)this.service;	
		} 
		catch (ServiceException ex) 
		{
			TestCase.fail(ex.toString());
		}
	}
	
	/**
	 * Allows the ServiceWithCollectionParametersTest to be run by JUnit as a suite.
	 */
	public static Test suite() 
	{
   		return new TestSuite(ServiceWithCollectionParametersTest.class);
	}

	/**
	 * Runs the ServiceWithCollectionParametersTest test case.
	 */
	public static void main(String[] args) 
	{
    	junit.textui.TestRunner.main(new String[] {ServiceWithCollectionParametersTest.class.getName()});
	}
	
	/* ------------------ Actual Tests -------------------- */
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithCollectionParameters.operationWithCollectionReturnType()
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionReturnType()()
     */ 
	public void testOperationWithCollectionReturnType() 
	{
		try 
		{
			this.service.operationWithCollectionReturnType();
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithCollectionParametersTest.testOperationWithCollectionReturnType()  
	}
	
	/**
	 * Tests: org.andromda.cartridges.webservice.ServiceWithCollectionParameters.operationWithCollectionTypeParameter(java.util.Collection invalidParameter)
	 *
	 * @see org.andromda.cartridges.webservice.ServiceWithCollectionParameters#operationWithCollectionTypeParameter(java.util.Collection invalidParameter)()
     */ 
	public void testOperationWithCollectionTypeParameter() 
	{
        java.util.Collection invalidParameter = null;
		try 
		{
			this.service.operationWithCollectionTypeParameter(invalidParameter);
		} 
		catch (Throwable th) 
		{
			TestCase.fail(th.toString());
		}
		//@todo implement ServiceWithCollectionParametersTest.testOperationWithCollectionTypeParameter()  
	}
	

}
