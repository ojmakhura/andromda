// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto2.d;

/**
 * @see org.andromda.test.howto2.d.Car
 */
public class CarDaoImpl
    extends org.andromda.test.howto2.d.CarDaoBase
{
    /**
     * @see org.andromda.test.howto2.d.CarDao#allCarsAreRented()
     */
    protected boolean handleAllCarsAreRented()
    {
        // TODO implement public boolean handleAllCarsAreRented()
        return false;
    }

}