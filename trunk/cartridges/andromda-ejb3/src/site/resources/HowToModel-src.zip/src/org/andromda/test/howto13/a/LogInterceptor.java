// license-header java merge-point
package org.andromda.test.howto13.a;

/**
 * Interceptor class LogInterceptor
 */
public class LogInterceptor 
{
    /**
     * Default interceptor execution method
     *
     * @param ctx the invocation context
     * @return 
     */
    @javax.ejb.AroundInvoke
    public Object execute(javax.ejb.InvocationContext ctx)
        throws Exception 
    {
        // Add implementation
        
        try
        {
            return ctx.proceed();
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}
