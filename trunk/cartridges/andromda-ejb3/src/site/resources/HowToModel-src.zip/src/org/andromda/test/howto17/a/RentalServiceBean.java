// license-header java merge-point
package org.andromda.howto2.rental;

/**
 * @see org.andromda.howto2.rental.RentalServiceBean
 */
/**
 * Do not specify the javax.ejb.Stateless annotation
 * Instead, define the session bean in the ejb-jar.xml descriptor
 * @javax.ejb.Stateless
 */
/**
 * Uncomment to enable webservices for RentalServiceBean
 *@javax.jws.WebService(endpointInterface = "org.andromda.howto2.rental.RentalServiceWSInterface")
 */
public class RentalServiceBean 
    extends org.andromda.howto2.rental.RentalServiceBase 
{
    // --------------- Constructors ---------------
    
    public RentalServiceBean()
    {
        super();
    }

    // -------- Business Methods Impl --------------
    
    /**
     * @see org.andromda.howto2.rental.RentalServiceBase#getAllCars()
     */
    protected java.util.List handleGetAllCars()
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.howto2.rental.RentalServiceBase#getCustomersByName(java.lang.String)
     */
    protected java.util.List handleGetCustomersByName(java.lang.String name)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }


    // -------- Lifecycle Callback Impl --------------
    
}
