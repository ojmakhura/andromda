// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto4.b;

/**
 * @see org.andromda.test.howto4.b.Car
 */
public class CarDaoImpl
    extends org.andromda.test.howto4.b.CarDaoBase
{
    /**
     * @see org.andromda.test.howto4.b.CarDao#allCarsAreRented()
     */
    protected boolean handleAllCarsAreRented()
    {
        // TODO implement public boolean handleAllCarsAreRented()
        return false;
    }

}