// license-header java merge-point
package org.andromda.test.howto18.a;

/**
 * Web service delegator for {@link org.andromda.test.howto18.a.UserEndPointServiceBean}.
 *
 * @see org.andromda.test.howto18.a.UserEndPointServiceBean
 */
public class UserEndPointServiceDelegate
{
    /**
     * Environment properties
     */
    private java.util.Properties env = null;
    
    /**
     * Default constructor
     */
    public UserEndPointServiceDelegate()
    {
        // Null implementation
    }
    
    /**
     * Constructor setting the envirinment properties.
     *
     * @param env
     */
    public UserEndPointServiceDelegate(java.util.Properties env)
    {
        this.env = env;
    }
    
    /**
     * Gets an instance of {@link org.andromda.test.howto18.a.UserEndPointServiceRemote}
     */
    private final org.andromda.test.howto18.a.UserEndPointServiceRemote getUserEndPointServiceRemote()
        throws javax.naming.NamingException
    {
        return org.andromda.test.ServiceLocator.getInstance().get_org_andromda_test_howto18_a_UserEndPointServiceBean_Remote(env);
    }
    
    /**
     * @see org.andromda.test.howto18.a.UserEndPointServiceBean#addUser(java.lang.String)
     *
     * Use the remote interface for calling session bean operations.
     */
    public void addUser(java.lang.String name)
        throws org.andromda.test.howto18.a.UserException
    {
        try
        {
            getUserEndPointServiceRemote().addUser(name);
        }
        catch (org.andromda.test.howto18.a.UserException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto18.a.UserEndPointServiceException(
                "Error performing 'org.andromda.test.howto18.a.UserEndPointService.addUser(java.lang.String name)' --> " + ex, ex);
        }
    }

    /**
     * @see org.andromda.test.howto18.a.UserEndPointServiceBean#getUser(java.lang.Long)
     *
     * Use the remote interface for calling session bean operations.
     */
    public org.andromda.test.howto18.a.User getUser(java.lang.Long id)
        throws org.andromda.test.howto18.a.UserException
    {
        try
        {
            return getUserEndPointServiceRemote().getUser(id);
        }
        catch (org.andromda.test.howto18.a.UserException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto18.a.UserEndPointServiceException(
                "Error performing 'org.andromda.test.howto18.a.UserEndPointService.getUser(java.lang.Long id)' --> " + ex, ex);
        }
    }

    /**
     * Close down service delegate resources
     */
    public void close()
    {
        org.andromda.test.ServiceLocator.getInstance().shutdown();
    }
}