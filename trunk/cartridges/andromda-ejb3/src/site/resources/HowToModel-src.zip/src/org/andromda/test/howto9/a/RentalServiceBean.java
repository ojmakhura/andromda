// license-header java merge-point
package org.andromda.test.howto9.a;

/**
 * @see org.andromda.test.howto9.a.RentalServiceBean
 */
/**
 * Do not specify the javax.ejb.Stateless annotation
 * Instead, define the session bean in the ejb-jar.xml descriptor
 * @javax.ejb.Stateless
 */
/**
 * Uncomment to enable webservices for RentalServiceBean
 *@javax.jws.WebService(endpointInterface = "org.andromda.test.howto9.a.RentalServiceWSInterface")
 */
public class RentalServiceBean 
    extends org.andromda.test.howto9.a.RentalServiceBase 
{
    // --------------- Constructors ---------------
    
    public RentalServiceBean()
    {
        super();
    }

    // -------- Business Methods Impl --------------
    
    /**
     * @see org.andromda.test.howto9.a.RentalServiceBase#getAllCars()
     */
    protected java.util.List handleGetAllCars()
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.test.howto9.a.RentalServiceBase#getCustomersByName(java.lang.String)
     */
    protected java.util.List handleGetCustomersByName(java.lang.String name)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }


    // -------- Lifecycle Callback Impl --------------
    
}
