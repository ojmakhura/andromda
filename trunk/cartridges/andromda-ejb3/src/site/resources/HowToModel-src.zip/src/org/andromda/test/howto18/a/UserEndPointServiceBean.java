// license-header java merge-point
package org.andromda.test.howto18.a;

/**
 * @see org.andromda.test.howto18.a.UserEndPointServiceBean
 */
/**
 * Do not specify the javax.ejb.Stateless annotation
 * Instead, define the session bean in the ejb-jar.xml descriptor
 * @javax.ejb.Stateless
 */
@javax.jws.WebService(endpointInterface = "org.andromda.test.howto18.a.UserEndPointServiceWSInterface")
public class UserEndPointServiceBean 
    extends org.andromda.test.howto18.a.UserEndPointServiceBase 
{
    // --------------- Constructors ---------------
    
    public UserEndPointServiceBean()
    {
        super();
    }

    // -------- Business Methods Impl --------------
    
    /**
     * @see org.andromda.test.howto18.a.UserEndPointServiceBase#addUser(java.lang.String)
     */
    protected void handleAddUser(java.lang.String name)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        throw new java.lang.UnsupportedOperationException("org.andromda.test.howto18.a.UserEndPointServiceBean.handleAddUser(java.lang.String name) Not implemented!");
    }

    /**
     * @see org.andromda.test.howto18.a.UserEndPointServiceBase#getUser(java.lang.Long)
     */
    protected org.andromda.test.howto18.a.User handleGetUser(java.lang.Long id)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }


    // -------- Lifecycle Callback Impl --------------
    
}
