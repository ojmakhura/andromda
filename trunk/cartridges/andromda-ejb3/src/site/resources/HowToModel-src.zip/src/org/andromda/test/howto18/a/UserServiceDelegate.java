// license-header java merge-point
package org.andromda.test.howto18.a;

/**
 * Web service delegator for {@link org.andromda.test.howto18.a.UserServiceBean}.
 *
 * @see org.andromda.test.howto18.a.UserServiceBean
 */
public class UserServiceDelegate
{
    /**
     * Environment properties
     */
    private java.util.Properties env = null;
    
    /**
     * Default constructor
     */
    public UserServiceDelegate()
    {
        // Null implementation
    }
    
    /**
     * Constructor setting the envirinment properties.
     *
     * @param env
     */
    public UserServiceDelegate(java.util.Properties env)
    {
        this.env = env;
    }
    
    /**
     * Gets an instance of {@link org.andromda.test.howto18.a.UserServiceRemote}
     */
    private final org.andromda.test.howto18.a.UserServiceRemote getUserServiceRemote()
        throws javax.naming.NamingException
    {
        return org.andromda.test.ServiceLocator.getInstance().get_org_andromda_test_howto18_a_UserServiceBean_Remote(env);
    }
    
    /**
     * @see org.andromda.test.howto18.a.UserServiceBean#addUser(org.andromda.test.howto18.a.User)
     *
     * Use the remote interface for calling session bean operations.
     */
    public void addUser(org.andromda.test.howto18.a.User user)
        throws org.andromda.test.howto18.a.UserException
    {
        try
        {
            getUserServiceRemote().addUser(user);
        }
        catch (org.andromda.test.howto18.a.UserException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto18.a.UserServiceException(
                "Error performing 'org.andromda.test.howto18.a.UserService.addUser(org.andromda.test.howto18.a.User user)' --> " + ex, ex);
        }
    }

    /**
     * @see org.andromda.test.howto18.a.UserServiceBean#getUser(java.lang.Long)
     *
     * Use the remote interface for calling session bean operations.
     */
    public org.andromda.test.howto18.a.User getUser(java.lang.Long id)
        throws org.andromda.test.howto18.a.UserException
    {
        try
        {
            return getUserServiceRemote().getUser(id);
        }
        catch (org.andromda.test.howto18.a.UserException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto18.a.UserServiceException(
                "Error performing 'org.andromda.test.howto18.a.UserService.getUser(java.lang.Long id)' --> " + ex, ex);
        }
    }

    /**
     * @see org.andromda.test.howto18.a.UserServiceBean#getAllUsers()
     *
     * Use the remote interface for calling session bean operations.
     */
    public java.util.Collection getAllUsers()
        throws org.andromda.test.howto18.a.UserException
    {
        try
        {
            return getUserServiceRemote().getAllUsers();
        }
        catch (org.andromda.test.howto18.a.UserException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto18.a.UserServiceException(
                "Error performing 'org.andromda.test.howto18.a.UserService.getAllUsers()' --> " + ex, ex);
        }
    }

    /**
     * Close down service delegate resources
     */
    public void close()
    {
        org.andromda.test.ServiceLocator.getInstance().shutdown();
    }
}