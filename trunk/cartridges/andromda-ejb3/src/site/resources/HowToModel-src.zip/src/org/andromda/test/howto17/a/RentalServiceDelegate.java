// license-header java merge-point
package org.andromda.howto2.rental;

/**
 * Web service delegator for {@link org.andromda.howto2.rental.RentalServiceBean}.
 *
 * @see org.andromda.howto2.rental.RentalServiceBean
 */
public class RentalServiceDelegate
{
    /**
     * Environment properties
     */
    private java.util.Properties env = null;
    
    /**
     * Default constructor
     */
    public RentalServiceDelegate()
    {
        // Null implementation
    }
    
    /**
     * Constructor setting the envirinment properties.
     *
     * @param env
     */
    public RentalServiceDelegate(java.util.Properties env)
    {
        this.env = env;
    }
    
    /**
     * Gets an instance of {@link org.andromda.howto2.rental.RentalServiceRemote}
     */
    private final org.andromda.howto2.rental.RentalServiceRemote getRentalServiceRemote()
        throws javax.naming.NamingException
    {
        return org.andromda.test.ServiceLocator.getInstance().get_org_andromda_howto2_rental_RentalServiceBean_Remote(env);
    }
    
    /**
     * @see org.andromda.howto2.rental.RentalServiceBean#getAllCars()
     *
     * Use the remote interface for calling session bean operations.
     */
    public java.util.List getAllCars()
        throws org.andromda.howto2.rental.RentalException
    {
        try
        {
            return getRentalServiceRemote().getAllCars();
        }
        catch (org.andromda.howto2.rental.RentalException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.howto2.rental.RentalServiceException(
                "Error performing 'org.andromda.howto2.rental.RentalService.getAllCars()' --> " + ex, ex);
        }
    }

    /**
     * @see org.andromda.howto2.rental.RentalServiceBean#getCustomersByName(java.lang.String)
     *
     * Use the remote interface for calling session bean operations.
     */
    public java.util.List getCustomersByName(java.lang.String name)
        throws org.andromda.howto2.rental.RentalException
    {
        try
        {
            return getRentalServiceRemote().getCustomersByName(name);
        }
        catch (org.andromda.howto2.rental.RentalException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.howto2.rental.RentalServiceException(
                "Error performing 'org.andromda.howto2.rental.RentalService.getCustomersByName(java.lang.String name)' --> " + ex, ex);
        }
    }

    /**
     * Close down service delegate resources
     */
    public void close()
    {
        org.andromda.test.ServiceLocator.getInstance().shutdown();
    }
}