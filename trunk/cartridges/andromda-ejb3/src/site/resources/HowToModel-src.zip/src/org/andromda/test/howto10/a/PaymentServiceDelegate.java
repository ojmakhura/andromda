// license-header java merge-point
package org.andromda.test.howto10.a;

/**
 * Web service delegator for {@link org.andromda.test.howto10.a.PaymentServiceBean}.
 *
 * @see org.andromda.test.howto10.a.PaymentServiceBean
 */
public class PaymentServiceDelegate
{
    /**
     * Environment properties
     */
    private java.util.Properties env = null;
    
    /**
     * Default constructor
     */
    public PaymentServiceDelegate()
    {
        // Null implementation
    }
    
    /**
     * Constructor setting the envirinment properties.
     *
     * @param env
     */
    public PaymentServiceDelegate(java.util.Properties env)
    {
        this.env = env;
    }
    
    /**
     * Gets an instance of {@link org.andromda.test.howto10.a.PaymentServiceRemote}
     */
    private final org.andromda.test.howto10.a.PaymentServiceRemote getPaymentServiceRemote()
        throws javax.naming.NamingException
    {
        return org.andromda.test.ServiceLocator.getInstance().get_org_andromda_test_howto10_a_PaymentServiceBean_Remote(env);
    }
    
    /**
     * @see org.andromda.test.howto10.a.PaymentServiceBean#register(org.andromda.test.howto10.a.Person, org.andromda.test.howto10.a.Car, int)
     *
     * Use the remote interface for calling session bean operations.
     */
    public void register(org.andromda.test.howto10.a.Person owner, org.andromda.test.howto10.a.Car car, int leasePeriod)
    {
        try
        {
            getPaymentServiceRemote().register(owner, car, leasePeriod);
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto10.a.PaymentServiceException(
                "Error performing 'org.andromda.test.howto10.a.PaymentService.register(org.andromda.test.howto10.a.Person owner, org.andromda.test.howto10.a.Car car, int leasePeriod)' --> " + ex, ex);
        }
    }

    /**
     * Close down service delegate resources
     */
    public void close()
    {
        org.andromda.test.ServiceLocator.getInstance().shutdown();
    }
}