// license-header java merge-point
package org.andromda.test.howto18.a;

/**
 * @see org.andromda.test.howto18.a.UserServiceBean
 */
/**
 * Do not specify the javax.ejb.Stateless annotation
 * Instead, define the session bean in the ejb-jar.xml descriptor
 * @javax.ejb.Stateless
 */
@javax.jws.WebService(endpointInterface = "org.andromda.test.howto18.a.UserServiceWSInterface")
public class UserServiceBean 
    extends org.andromda.test.howto18.a.UserServiceBase 
{
    // --------------- Constructors ---------------
    
    public UserServiceBean()
    {
        super();
    }

    // -------- Business Methods Impl --------------
    
    /**
     * @see org.andromda.test.howto18.a.UserServiceBase#addUser(org.andromda.test.howto18.a.User)
     */
    protected void handleAddUser(org.andromda.test.howto18.a.User user)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        throw new java.lang.UnsupportedOperationException("org.andromda.test.howto18.a.UserServiceBean.handleAddUser(org.andromda.test.howto18.a.User user) Not implemented!");
    }

    /**
     * @see org.andromda.test.howto18.a.UserServiceBase#getUser(java.lang.Long)
     */
    protected org.andromda.test.howto18.a.User handleGetUser(java.lang.Long id)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.test.howto18.a.UserServiceBase#getAllUsers()
     */
    protected java.util.Collection handleGetAllUsers()
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }


    // -------- Lifecycle Callback Impl --------------
    
}
