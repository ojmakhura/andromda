// license-header java merge-point
package org.andromda.test.howto10.a;

/**
 * @see org.andromda.test.howto10.a.PaymentServiceBean
 */
/**
 * Do not specify the javax.ejb.Stateless annotation
 * Instead, define the session bean in the ejb-jar.xml descriptor
 * @javax.ejb.Stateless
 */
/**
 * Uncomment to enable webservices for PaymentServiceBean
 *@javax.jws.WebService(endpointInterface = "org.andromda.test.howto10.a.PaymentServiceWSInterface")
 */
public class PaymentServiceBean 
    extends org.andromda.test.howto10.a.PaymentServiceBase 
{
    // --------------- Constructors ---------------
    
    public PaymentServiceBean()
    {
        super();
    }

    // -------- Business Methods Impl --------------
    
    /**
     * @see org.andromda.test.howto10.a.PaymentServiceBase#register(org.andromda.test.howto10.a.Person, org.andromda.test.howto10.a.Car, int)
     */
    protected void handleRegister(org.andromda.test.howto10.a.Person owner, org.andromda.test.howto10.a.Car car, int leasePeriod)
        throws java.lang.Exception
    {
        //TODO: put your implementation here.
        throw new java.lang.UnsupportedOperationException("org.andromda.test.howto10.a.PaymentServiceBean.handleRegister(org.andromda.test.howto10.a.Person owner, org.andromda.test.howto10.a.Car car, int leasePeriod) Not implemented!");
    }


    // -------- Lifecycle Callback Impl --------------
    
}
