// license-header java merge-point
package org.andromda.test.howto10.a;

/**
 * @see org.andromda.test.howto10.a.PaymentProcessorMDBBean
 */
public class PaymentProcessorMDBBeanImpl
    extends org.andromda.test.howto10.a.PaymentProcessorMDBBean
{


    // --------- Default Constructor ----------
    
    public PaymentProcessorMDBBeanImpl()
    {
        super();
    }
    
    /**
     * MessageListener callback on arrival of a JMS message
     *
     * @param message The inbound JMS message to process
     */
    public void onMessage(javax.jms.Message message)
    {
        // Implementation
    }

}