// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto6.a;

/**
 * @see org.andromda.test.howto6.a.Car
 */
public class CarDaoImpl
    extends org.andromda.test.howto6.a.CarDaoBase
{
    /**
     * @see org.andromda.test.howto6.a.CarDao#allCarsAreRented()
     */
    protected boolean handleAllCarsAreRented()
    {
        // TODO implement public boolean handleAllCarsAreRented()
        return false;
    }

    /**
     * @see org.andromda.test.howto6.a.CarDao#toCarDetails(org.andromda.test.howto6.a.Car, org.andromda.test.howto6.a.CarDetails)
     */
    public void toCarDetails(
        org.andromda.test.howto6.a.Car sourceEntity, 
        org.andromda.test.howto6.a.CarDetails targetVO)
    {
        // ${toDoTag} verify behavior of toCarDetails
        super.toCarDetails(sourceEntity, targetVO);
        // WARNING! No conversion for targetVO.name (can't convert sourceEntity.getName():java.lang.String to java.lang.String
        // WARNING! No conversion for targetVO.serial (can't convert sourceEntity.getSerial():java.lang.String to java.lang.String
    }


    /**
     * @see org.andromda.test.howto6.a.CarDao#toCarDetails(org.andromda.test.howto6.a.Car)
     */
    public org.andromda.test.howto6.a.CarDetails toCarDetails(final org.andromda.test.howto6.a.Car entity)
    {
        // ${toDoTag} verify behavior of toCarDetails
        return super.toCarDetails(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store, 
     * a new, blank entity is created
     */
    private org.andromda.test.howto6.a.Car loadCarFromCarDetails(org.andromda.test.howto6.a.CarDetails carDetails)
    {
        // ${toDoTag} implement loadCarFromCarDetails
        throw new java.lang.UnsupportedOperationException("org.andromda.test.howto6.a.loadCarFromCarDetails(org.andromda.test.howto6.a.CarDetails) not yet implemented.");

        /* A typical implementation looks like this:        
        org.andromda.test.howto6.a.Car car = this.load(carDetails.getId());
        if (car == null)
        {
            car = org.andromda.test.howto6.a.Car.Factory.newInstance();
        }
        return car;
        */
    }

    
    /**
     * @see org.andromda.test.howto6.a.CarDao#carDetailsToEntity(org.andromda.test.howto6.a.CarDetails)
     */
    public org.andromda.test.howto6.a.Car carDetailsToEntity(org.andromda.test.howto6.a.CarDetails carDetails)
    {
        // ${toDoTag} verify behavior of carDetailsToEntity
        org.andromda.test.howto6.a.Car entity = this.loadCarFromCarDetails(carDetails);
        this.carDetailsToEntity(carDetails, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.test.howto6.a.CarDao#carDetailsToEntity(org.andromda.test.howto6.a.CarDetails, org.andromda.test.howto6.a.Car)
     */
    public void carDetailsToEntity(
        org.andromda.test.howto6.a.CarDetails sourceVO,
        org.andromda.test.howto6.a.Car targetEntity,
        boolean copyIfNull)
    {
        // ${toDoTag} verify behavior of carDetailsToEntity
        super.carDetailsToEntity(sourceVO, targetEntity, copyIfNull);
        // No conversion for targetEntity.serial (can't convert sourceVO.getSerial():java.lang.String to java.lang.String
        // No conversion for targetEntity.name (can't convert sourceVO.getName():java.lang.String to java.lang.String
    }

    /**
     * @see org.andromda.test.howto6.a.CarDao#toCarListItem(org.andromda.test.howto6.a.Car, org.andromda.test.howto6.a.CarListItem)
     */
    public void toCarListItem(
        org.andromda.test.howto6.a.Car sourceEntity, 
        org.andromda.test.howto6.a.CarListItem targetVO)
    {
        // ${toDoTag} verify behavior of toCarListItem
        super.toCarListItem(sourceEntity, targetVO);
        // WARNING! No conversion for targetVO.name (can't convert sourceEntity.getName():java.lang.String to java.lang.String
        // WARNING! No conversion for targetVO.serial (can't convert sourceEntity.getSerial():java.lang.String to java.lang.String
    }


    /**
     * @see org.andromda.test.howto6.a.CarDao#toCarListItem(org.andromda.test.howto6.a.Car)
     */
    public org.andromda.test.howto6.a.CarListItem toCarListItem(final org.andromda.test.howto6.a.Car entity)
    {
        // ${toDoTag} verify behavior of toCarListItem
        return super.toCarListItem(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store, 
     * a new, blank entity is created
     */
    private org.andromda.test.howto6.a.Car loadCarFromCarListItem(org.andromda.test.howto6.a.CarListItem carListItem)
    {
        // ${toDoTag} implement loadCarFromCarListItem
        throw new java.lang.UnsupportedOperationException("org.andromda.test.howto6.a.loadCarFromCarListItem(org.andromda.test.howto6.a.CarListItem) not yet implemented.");

        /* A typical implementation looks like this:        
        org.andromda.test.howto6.a.Car car = this.load(carListItem.getId());
        if (car == null)
        {
            car = org.andromda.test.howto6.a.Car.Factory.newInstance();
        }
        return car;
        */
    }

    
    /**
     * @see org.andromda.test.howto6.a.CarDao#carListItemToEntity(org.andromda.test.howto6.a.CarListItem)
     */
    public org.andromda.test.howto6.a.Car carListItemToEntity(org.andromda.test.howto6.a.CarListItem carListItem)
    {
        // ${toDoTag} verify behavior of carListItemToEntity
        org.andromda.test.howto6.a.Car entity = this.loadCarFromCarListItem(carListItem);
        this.carListItemToEntity(carListItem, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.test.howto6.a.CarDao#carListItemToEntity(org.andromda.test.howto6.a.CarListItem, org.andromda.test.howto6.a.Car)
     */
    public void carListItemToEntity(
        org.andromda.test.howto6.a.CarListItem sourceVO,
        org.andromda.test.howto6.a.Car targetEntity,
        boolean copyIfNull)
    {
        // ${toDoTag} verify behavior of carListItemToEntity
        super.carListItemToEntity(sourceVO, targetEntity, copyIfNull);
        // No conversion for targetEntity.serial (can't convert sourceVO.getSerial():java.lang.String to java.lang.String
        // No conversion for targetEntity.name (can't convert sourceVO.getName():java.lang.String to java.lang.String
    }

}