// license-header java merge-point
package org.andromda.test.howto8.b;

/**
 * Web service delegator for {@link org.andromda.test.howto8.b.RentalServiceBean}.
 *
 * @see org.andromda.test.howto8.b.RentalServiceBean
 */
public class RentalServiceDelegate
{
    /**
     * Environment properties
     */
    private java.util.Properties env = null;
    
    /**
     * Default constructor
     */
    public RentalServiceDelegate()
    {
        // Null implementation
    }
    
    /**
     * Constructor setting the envirinment properties.
     *
     * @param env
     */
    public RentalServiceDelegate(java.util.Properties env)
    {
        this.env = env;
    }
    
    /**
     * Gets an instance of {@link org.andromda.test.howto8.b.RentalServiceRemote}
     */
    private final org.andromda.test.howto8.b.RentalServiceRemote getRentalServiceRemote()
        throws javax.naming.NamingException
    {
        return org.andromda.test.ServiceLocator.getInstance().get_org_andromda_test_howto8_b_RentalServiceBean_Remote(env);
    }
    
    /**
     * @see org.andromda.test.howto8.b.RentalServiceBean#getAllCars()
     *
     * Use the remote interface for calling session bean operations.
     */
    public java.util.List getAllCars()
        throws org.andromda.test.howto8.b.RentalException
    {
        try
        {
            return getRentalServiceRemote().getAllCars();
        }
        catch (org.andromda.test.howto8.b.RentalException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto8.b.RentalServiceException(
                "Error performing 'org.andromda.test.howto8.b.RentalService.getAllCars()' --> " + ex, ex);
        }
    }

    /**
     * @see org.andromda.test.howto8.b.RentalServiceBean#getCustomersByName(java.lang.String)
     *
     * Use the remote interface for calling session bean operations.
     */
    public java.util.List getCustomersByName(java.lang.String name)
        throws org.andromda.test.howto8.b.RentalException
    {
        try
        {
            return getRentalServiceRemote().getCustomersByName(name);
        }
        catch (org.andromda.test.howto8.b.RentalException ex)
        {
            throw ex;
        }
        catch (javax.naming.NamingException ex)
        {
            throw new org.andromda.test.howto8.b.RentalServiceException(
                "Error performing 'org.andromda.test.howto8.b.RentalService.getCustomersByName(java.lang.String name)' --> " + ex, ex);
        }
    }

    /**
     * Close down service delegate resources
     */
    public void close()
    {
        org.andromda.test.ServiceLocator.getInstance().shutdown();
    }
}