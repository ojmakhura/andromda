// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto20.a;

/**
 * @see org.andromda.test.howto20.a.PersonName
 */
public class PersonNameImpl
    extends org.andromda.test.howto20.a.PersonName
    implements java.io.Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 7925424099780948089L;
    
}