// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.test.howto9.b;

/**
 * @see org.andromda.test.howto9.b.Person
 */
public class PersonDaoImpl
    extends org.andromda.test.howto9.b.PersonDaoBase
{
}