/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.persistence.PostLoad;
import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import javax.persistence.PrePersist;
import javax.persistence.PreRemove;
import javax.persistence.PreUpdate;

/**
 * Callback Listener for Entity POJO EJB EntitySeventeen
 *
 * @see EntitySeventeen
 */
public class EntitySeventeenListener
{
    /**
     * Default public no-args constructor
     */
    public EntitySeventeenListener()
    {
        // empty constructor
    }

    @PrePersist
    public void prePersist(EntitySeventeen entitySeventeen)
    {
        // pre persist implementation
    }

    @PostPersist
    public void postPersist(EntitySeventeen entitySeventeen)
    {
        // post persist implementation
    }

    @PreRemove
    public void preRemove(EntitySeventeen entitySeventeen)
    {
        // pre remove implementation
    }

    @PostRemove
    public void postRemove(EntitySeventeen entitySeventeen)
    {
        // post remove implementation
    }

    @PreUpdate
    public void preUpdate(EntitySeventeen entitySeventeen) {
        // pre update implementation
    }

    @PostUpdate
    public void postUpdate(EntitySeventeen entitySeventeen)
    {
        // post update implementation
    }

    @PostLoad
    public void postLoad(EntitySeventeen entitySeventeen)
    {
        // post load implementation
    }
}