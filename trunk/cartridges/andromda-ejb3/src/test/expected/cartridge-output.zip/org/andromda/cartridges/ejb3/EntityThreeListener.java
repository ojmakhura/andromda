/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;


/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntityThree
 *
 * @see org.andromda.cartridges.ejb3.EntityThree
 */
public class EntityThreeListener 
{
    /**
     * Default public no-args constructor
     */
    public EntityThreeListener() 
    { 
    }
    
    @javax.persistence.PrePersist
    public void prePersist(EntityThree entityThree) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(EntityThree entityThree) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(EntityThree entityThree) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(EntityThree entityThree) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(EntityThree entityThree) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(EntityThree entityThree) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(EntityThree entityThree) 
	{
		// post load implementation
	}
}
