/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.jms.Message;

/**
 * @see MessageBeanOneMDBBean
 */
public class MessageBeanOneMDBBeanImpl
    extends MessageBeanOneMDBBean
{


    // --------- Default Constructor ----------
    
    public MessageBeanOneMDBBeanImpl()
    {
        super();
    }
    
    /**
     * MessageListener callback on arrival of a JMS message
     *
     * @param message The inbound JMS message to process
     */
    public void onMessage(Message message)
    {
        // Implementation
    }

}