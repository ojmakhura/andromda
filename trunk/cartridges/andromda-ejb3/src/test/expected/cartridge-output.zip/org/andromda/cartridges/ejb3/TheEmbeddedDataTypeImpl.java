/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.ejb3;

import java.io.Serializable;

/**
 * @see TheEmbeddedDataType
 */
public class TheEmbeddedDataTypeImpl
    extends TheEmbeddedDataType
    implements Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = -9159183374587321952L;
    
    /**
     * @see TheEmbeddedDataType#someConversion()
     */
    public void someConversion()
    {
        // ${toDoTag} implement public void someConversion()
        throw new UnsupportedOperationException("org.andromda.cartridges.ejb3.TheEmbeddedDataType.someConversion() Not implemented!");
    }

    /**
     * @see TheEmbeddedDataType#normalize()
     */
    public void normalize()
    {
        // ${toDoTag} implement public void normalize()
        throw new UnsupportedOperationException("org.andromda.cartridges.ejb3.TheEmbeddedDataType.normalize() Not implemented!");
    }

}