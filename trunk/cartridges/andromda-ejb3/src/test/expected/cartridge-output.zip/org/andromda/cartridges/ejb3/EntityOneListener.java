/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;


/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntityOne
 *
 * @see org.andromda.cartridges.ejb3.EntityOne
 */
public class EntityOneListener 
{
    /**
     * Default public no-args constructor
     */
    public EntityOneListener() 
    { 
    }
    
    @javax.persistence.PrePersist
    public void prePersist(EntityOne entityOne) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(EntityOne entityOne) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(EntityOne entityOne) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(EntityOne entityOne) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(EntityOne entityOne) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(EntityOne entityOne) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(EntityOne entityOne) 
	{
		// post load implementation
	}
}
