/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;


/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntityWithAutoKey
 *
 * @see org.andromda.cartridges.ejb3.EntityWithAutoKey
 */
public class EntityWithAutoKeyListener 
{
    /**
     * Default public no-args constructor
     */
    public EntityWithAutoKeyListener() 
    { 
    }
    
    @javax.persistence.PrePersist
    public void prePersist(EntityWithAutoKey entityWithAutoKey) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(EntityWithAutoKey entityWithAutoKey) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(EntityWithAutoKey entityWithAutoKey) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(EntityWithAutoKey entityWithAutoKey) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(EntityWithAutoKey entityWithAutoKey) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(EntityWithAutoKey entityWithAutoKey) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(EntityWithAutoKey entityWithAutoKey) 
	{
		// post load implementation
	}
}
