/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;


/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntityN
 *
 * @see org.andromda.cartridges.ejb3.EntityN
 */
public class EntityNListener 
{
    /**
     * Default public no-args constructor
     */
    public EntityNListener() 
    { 
    }
    
    @javax.persistence.PrePersist
    public void prePersist(EntityN entityN) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(EntityN entityN) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(EntityN entityN) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(EntityN entityN) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(EntityN entityN) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(EntityN entityN) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(EntityN entityN) 
	{
		// post load implementation
	}
}
