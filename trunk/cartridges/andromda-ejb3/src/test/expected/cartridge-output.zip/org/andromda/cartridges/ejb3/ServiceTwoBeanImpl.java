/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.ejb.SessionContext;

/**
 * @see org.andromda.cartridges.ejb3.ServiceTwoBean
 */
public class ServiceTwoBeanImpl 
    extends ServiceTwoBean 
{
    /**
     * @see org.andromda.cartridges.ejb3.ServiceTwo#operationOne()
     */
    public void operationOne()
    {
        //TODO: put your implementation here.
    }

    /**
     * @see org.andromda.cartridges.ejb3.ServiceTwo#operationTwo()
     */
    public java.lang.String operationTwo()
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

}
