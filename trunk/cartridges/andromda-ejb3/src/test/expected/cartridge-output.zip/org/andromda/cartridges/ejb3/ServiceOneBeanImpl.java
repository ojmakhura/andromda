/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.ejb.SessionContext;

/**
 * @see org.andromda.cartridges.ejb3.ServiceOneBean
 */
public class ServiceOneBeanImpl 
    extends ServiceOneBean 
{
    /**
     * @see org.andromda.cartridges.ejb3.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws org.andromda.cartridges.ejb3.TestException
    {
        //TODO: put your implementation here.
    }

    /**
     * @see org.andromda.cartridges.ejb3.ServiceOne#operationWithSimpleReturnType()
     */
    public java.lang.String operationWithSimpleReturnType()
        throws org.andromda.cartridges.ejb3.TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb3.ServiceOne#operationWithComplexReturnType()
     */
    public java.util.Collection operationWithComplexReturnType()
        throws org.andromda.cartridges.ejb3.TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb3.ServiceOne#SoperationWithSingleArgument(java.util.Date)
     */
    public java.lang.String SoperationWithSingleArgument(java.util.Date argumentOne)
        throws org.andromda.cartridges.ejb3.TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb3.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws org.andromda.cartridges.ejb3.TestException
    {
        //TODO: put your implementation here.
    }

}
