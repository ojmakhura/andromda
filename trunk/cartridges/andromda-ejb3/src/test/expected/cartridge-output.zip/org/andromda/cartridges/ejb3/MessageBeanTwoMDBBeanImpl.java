/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

import javax.jms.Message;

/**
 * @see MessageBeanTwoMDBBean
 */
public class MessageBeanTwoMDBBeanImpl
    extends MessageBeanTwoMDBBean
{


    // --------- Default Constructor ----------
    
    public MessageBeanTwoMDBBeanImpl()
    {
        super();
    }
    
    /**
     * MessageListener callback on arrival of a JMS message
     *
     * @param message The inbound JMS message to process
     */
    public void onMessage(Message message)
    {
        // Implementation
    }

}