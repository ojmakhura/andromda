/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;

/**
 * @see org.andromda.cartridges.ejb3.MessageBeanTwoMDBBean
 */
public class MessageBeanTwoMDBBeanImpl
    extends org.andromda.cartridges.ejb3.MessageBeanTwoMDBBean
{


    // --------- Default Constructor ----------
    
    public MessageBeanTwoMDBBeanImpl()
    {
        super();
    }
    
    /**
     * MessageListener callback on arrival of a JMS message
     *
     * @param message The inbound JMS message to process
     */
    public void onMessage(javax.jms.Message message)
    {
        // Implementation
    }

}