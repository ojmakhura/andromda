/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb3;


/**
 * Callback Listener for Entity POJO EJB org.andromda.cartridges.ejb3.EntityTwo
 *
 * @see org.andromda.cartridges.ejb3.EntityTwo
 */
public class EntityTwoListener 
{
    /**
     * Default public no-args constructor
     */
    public EntityTwoListener() 
    { 
    }
    
    @javax.persistence.PrePersist
    public void prePersist(EntityTwo entityTwo) 
    {
		// pre persist implementation
	}
	
	@javax.persistence.PostPersist
	public void postPersist(EntityTwo entityTwo) 
	{
		// post persist implementation
	}
	
	@javax.persistence.PreRemove
	public void preRemove(EntityTwo entityTwo) 
	{
		// pre remove implementation
	}
	
	@javax.persistence.PostRemove
	public void postRemove(EntityTwo entityTwo) 
	{
		// post remove implementation
	}
	
	@javax.persistence.PreUpdate
	public void preUpdate(EntityTwo entityTwo) {
		// pre update implementation
	}
	
	@javax.persistence.PostUpdate
	public void postUpdate(EntityTwo entityTwo) 
	{
		// post update implementation
	}
	
	@javax.persistence.PostLoad
	public void postLoad(EntityTwo entityTwo) 
	{
		// post load implementation
	}
}
