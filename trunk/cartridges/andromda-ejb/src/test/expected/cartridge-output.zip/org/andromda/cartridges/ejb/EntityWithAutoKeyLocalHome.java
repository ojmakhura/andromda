/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 * Home interface for the EntityWithAutoKey entity bean.
 * 
 */
public interface EntityWithAutoKeyLocalHome
    extends EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityWithAutoKey/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityWithAutoKey/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityWithAutoKey findByPrimaryKey(Long key)
            throws FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param integerPrimary Value for the integerPrimary property
     * @param someText Value for the someText property
     * @param id Value for the id property
     */
    public EntityWithAutoKey create(Integer integerPrimary, String someText, Long id)
           throws CreateException;
}