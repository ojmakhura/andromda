/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import java.util.Collection;
import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;
import javax.ejb.FinderException;

/**
 * Home interface for the EntityN entity bean.
 * 
 */
public interface EntityNLocalHome
    extends EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityN/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityN/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityN findByPrimaryKey(Long key)
            throws FinderException;

   /**
    * 
    */
    public void findByBla()
           throws FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param nId Value for the nId property
     * @param n2Id Value for the n2Id property
     * @param myFunnyAttribute Value for the myFunnyAttribute property
     * @param id Value for the id property
     */
    public EntityN create(int nId, Integer n2Id, String myFunnyAttribute, Long id)
           throws CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param nId Value for the nId property
     * @param n2Id Value for the n2Id property
     * @param myFunnyAttribute Value for the myFunnyAttribute property
     * @param id Value for the id property
     * @param many2manyMs Value for the many2manyMs relation role
     * @param one2manyManies Value for the one2manyManies relation role
     * @param many2oneOne Value for the many2oneOne relation role
     * @param one2oneM Value for the one2oneM relation role
     */
    public EntityN create(int nId, Integer n2Id, String myFunnyAttribute, Long id, Collection many2manyMs, Collection one2manyManies, EntityM many2oneOne, EntityM one2oneM)
           throws CreateException;

}