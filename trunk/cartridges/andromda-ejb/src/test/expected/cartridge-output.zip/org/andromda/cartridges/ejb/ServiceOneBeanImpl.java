/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

import javax.ejb.SessionContext;

import java.util.Collection;
import java.util.Date;
/**
 * @see org.andromda.cartridges.ejb.ServiceOneBean
 */
public class ServiceOneBeanImpl 
    extends ServiceOneBean 
{
    /**
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
    }

    /**
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithSimpleReturnType()
     */
    public String operationWithSimpleReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithComplexReturnType()
     */
    public Collection operationWithComplexReturnType()
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb.ServiceOne#SoperationWithSingleArgument(Date)
     */
    public String SoperationWithSingleArgument(Date argumentOne)
        throws TestException
    {
        //TODO: put your implementation here.
        // Dummy return value, just that the file compiles
        return null;
    }

    /**
     * @see org.andromda.cartridges.ejb.ServiceOne#operationWithMultipleArguments(Long, Boolean)
     */
    public void operationWithMultipleArguments(Long firstArgument, Boolean secondArgument)
        throws TestException
    {
        //TODO: put your implementation here.
    }

}
