package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import java.io.Serializable;


/**
 * @struts.form
 *      name="noTableLinkActivityShowTableDataAgainActionForm"
 */
public final class ShowTableDataAgainActionForm extends NoTableLinkActivityForm implements Serializable
{
}
