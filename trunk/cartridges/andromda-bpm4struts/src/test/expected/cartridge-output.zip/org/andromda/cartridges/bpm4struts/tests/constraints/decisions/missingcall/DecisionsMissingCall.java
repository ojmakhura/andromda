/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingcall;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class DecisionsMissingCall extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _something(mapping, form, request, response);
        if (this.errorsNotPresent(request))
        {
            request.getSession().setAttribute("form", form);
        }
        return forward;
    }

    /**
     * 
     */
    private ActionForward _something(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;
        forward = __${transition.operationCall.name}(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward __$controllerMethodName(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final String value = String.valueOf(ControllerFactory.getControllerInstance().${controllerMethodName}(mapping, (DecisionsMissingCallForm)form, request, response));

        if (value.equals("someGuard"))
        {
            return _something(mapping, form, request, response);
        }
        if (value.equals("anotherGuard"))
        {
            return _something(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _something(mapping, form, request, response);
    }


    /**
     * Returns true if <strong>NO</strong> errors
     * are present in the request.  This includes default validation
     * errors produced by the struts framework and the exception
     * handler errors caught by the pattern matching
     * exception handler.
     *
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(HttpServletRequest request)
    {
        return this.getExceptionHandlerErrors(request).isEmpty() &&
            (this.getErrors(request) == null || this.getErrors(request).isEmpty());
    }

    /**
     * <p>
     *  Retrieves the exception handler messages (if any).  Creates a new
     *  ActionMessages instance and returns that if one doesn't already exist.
     * </p>
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors =
            (org.apache.struts.action.ActionMessages)request.getAttribute(
                "org.andromda.bpm4struts.errormessages");
        if (errors == null)
        {
            errors = new org.apache.struts.action.ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", errors);
        }
        return errors;
    }
}
