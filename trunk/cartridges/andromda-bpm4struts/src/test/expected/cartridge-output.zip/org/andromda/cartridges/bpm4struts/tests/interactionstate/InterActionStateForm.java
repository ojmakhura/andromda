package org.andromda.cartridges.bpm4struts.tests.interactionstate;

public class InterActionStateForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String param;
    private Object[] paramValueList;
    private Object[] paramLabelList;

    public InterActionStateForm()
    {
    }

    /**
     * Resets the given <code>param</code>.
     */
    public void resetParam()
    {
        this.param = null;
    }
    
    public void setParam(java.lang.String param)
    {
        this.param = param;
    }

    /**
     * 
     */
    public java.lang.String getParam()
    {
        return this.param;
    }
    

    public Object[] getParamBackingList()
    {
        Object[] values = this.paramValueList;
        Object[] labels = this.paramLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getParamValueList()
    {
        return this.paramValueList;
    }

    public void setParamValueList(Object[] paramValueList)
    {
        this.paramValueList = paramValueList;
    }

    public Object[] getParamLabelList()
    {
        return this.paramLabelList;
    }

    public void setParamLabelList(Object[] paramLabelList)
    {
        this.paramLabelList = paramLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("param", this.param);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.param = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}