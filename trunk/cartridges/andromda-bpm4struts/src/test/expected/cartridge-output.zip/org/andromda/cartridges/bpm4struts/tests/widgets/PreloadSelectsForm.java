package org.andromda.cartridges.bpm4struts.tests.widgets;

public interface PreloadSelectsForm
{
}
