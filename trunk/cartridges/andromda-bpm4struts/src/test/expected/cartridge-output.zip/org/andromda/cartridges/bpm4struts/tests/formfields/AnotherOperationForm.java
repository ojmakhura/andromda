package org.andromda.cartridges.bpm4struts.tests.formfields;

public interface AnotherOperationForm
{
    public void setNotused(java.lang.String notused);
    public java.lang.String getNotused();
    public void resetNotused();

    public void setUnusedNumber(int unusedNumber);
    public int getUnusedNumber();
    public void resetUnusedNumber();

}
