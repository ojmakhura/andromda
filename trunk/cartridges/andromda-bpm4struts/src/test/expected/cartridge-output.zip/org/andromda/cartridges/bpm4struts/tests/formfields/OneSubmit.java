package org.andromda.cartridges.bpm4struts.tests.formfields;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/FormFields/OneSubmit"
 *        name="formFieldsOneSubmitForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/formfields/one.jsp"
 *    validate="true"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="one"
 *        path="/org/andromda/cartridges/bpm4struts/tests/formfields/one.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="form.fields.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/formfields/one.jsp"
 *       scope="request"
 *
 */
public final class OneSubmit extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = _two(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _two(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().someOperation(mapping, (OneSubmitForm)form, request, response);
        return mapping.findForward("one");
    }

}
