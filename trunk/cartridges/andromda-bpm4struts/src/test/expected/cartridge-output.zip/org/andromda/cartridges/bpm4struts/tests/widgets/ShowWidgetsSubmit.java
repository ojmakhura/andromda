package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class ShowWidgetsSubmit extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("form", form);
        final ActionForward forward = _doSomethingElse(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _doSomethingElse(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("widgets.activity");
    }

}
