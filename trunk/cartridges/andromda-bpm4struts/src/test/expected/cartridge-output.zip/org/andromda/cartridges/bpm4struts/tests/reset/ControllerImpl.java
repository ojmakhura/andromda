/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.reset;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.reset.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.reset.Controller#someOperation(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.reset.SomeOperationForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void someOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.reset.SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setFirstParam("firstParam-test");
    }

}