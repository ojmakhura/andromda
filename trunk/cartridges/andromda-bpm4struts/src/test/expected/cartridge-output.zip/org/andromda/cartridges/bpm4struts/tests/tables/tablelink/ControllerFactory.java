package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ControllerFactory
{
    private final static Controller INSTANCE = new Controller();

    public final static ControllerInterface getControllerInstance()
    {
        return INSTANCE;
    }
}
