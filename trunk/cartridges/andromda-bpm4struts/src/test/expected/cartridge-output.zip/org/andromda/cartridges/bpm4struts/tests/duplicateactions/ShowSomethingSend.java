package org.andromda.cartridges.bpm4struts.tests.duplicateactions;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class ShowSomethingSend extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("form", form);
        final ActionForward forward = _doSomething(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _doSomething(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;
        final org.apache.struts.action.ActionMessages errors = new org.apache.struts.action.ActionMessages();
        try
        {
        }
        catch (Exception ex)
        {
            final String messageKey = org.andromda.presentation.bpm4struts.PatternMatchingExceptionHandler.instance().handleException(ex);
            errors.add(org.apache.struts.action.ActionMessages.GLOBAL_MESSAGE, new org.apache.struts.action.ActionMessage(messageKey));
            super.saveErrors(request, errors);
        }
        finally
        {
            forward = mapping.findForward("show.something");
        }
        if (!errors.isEmpty())
        {
            forward = mapping.getInputForward();
        }
        return forward;
    }

}
