package org.andromda.cartridges.bpm4struts.tests.duplicateactions;

/**
 * @struts.form
 *      name="duplicateActionsUsecaseDuplicateActionsUsecaseForm"
 */
public class DuplicateActionsUsecaseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String testParam;

    public DuplicateActionsUsecaseForm()
    {
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("testParam=");
        buffer.append(String.valueOf(this.getTestParam()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.testParam = null;
    }

}
