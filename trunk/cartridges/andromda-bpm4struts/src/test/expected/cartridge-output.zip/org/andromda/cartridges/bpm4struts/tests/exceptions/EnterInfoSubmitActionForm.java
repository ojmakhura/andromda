package org.andromda.cartridges.bpm4struts.tests.exceptions;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="exceptionsActivityEnterInfoSubmitActionForm"
 */
public class EnterInfoSubmitActionForm extends ValidatorForm implements Serializable
    
{

    public EnterInfoSubmitActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
