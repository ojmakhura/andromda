package org.andromda.cartridges.bpm4struts.tests.constraints.oneusecaseperpackage;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="useCase2UseCase2ActionForm"
 */
public class UseCase2ActionForm extends ValidatorForm implements Serializable
    
{

    public UseCase2ActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
