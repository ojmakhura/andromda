package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State2Trigger2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private int param4;
    private java.lang.String testParam;
    private java.lang.String testParam2;
    private Object[] testParam2ValueList;
    private Object[] testParam2LabelList;

    public State2Trigger2Form()
    {
    }

    /**
     * Resets the given <code>param4</code>.
     */
    public void resetParam4()
    {
        this.param4 = 0;
    }

    public void setParam4(int param4)
    {
        this.param4 = param4;
    }

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }

    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        this.testParam = null;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    /**
     * Resets the given <code>testParam2</code>.
     */
    public void resetTestParam2()
    {
        this.testParam2 = null;
    }

    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }

    public Object[] getTestParam2BackingList()
    {
        Object[] values = this.testParam2ValueList;
        Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.testParam2 = null;
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("param4=");
        buffer.append(String.valueOf(this.getParam4()));
        buffer.append(",testParam=");
        buffer.append(String.valueOf(this.getTestParam()));
        buffer.append(",testParam2=");
        buffer.append(String.valueOf(this.getTestParam2()));

        return buffer.append("]").toString();
    }

    /**
     * Helper method to convert an array to a String.
     */
    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.param4 = 0;
        this.testParam = null;
        this.testParam2 = null;
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}
