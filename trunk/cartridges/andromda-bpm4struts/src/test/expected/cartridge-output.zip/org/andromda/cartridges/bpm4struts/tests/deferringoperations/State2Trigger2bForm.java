package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State2Trigger2bForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , Operation1Form
        , Operation2Form
{
    private java.lang.String testParam;
    private Object[] testParamValueList;
    private Object[] testParamLabelList;
    private java.lang.String param2a;
    private Object[] param2aValueList;
    private Object[] param2aLabelList;
    private java.lang.String pageVariable;
    private Object[] pageVariableValueList;
    private Object[] pageVariableLabelList;
    private int testParam2;
    private Object[] testParam2ValueList;
    private Object[] testParam2LabelList;

    public State2Trigger2bForm()
    {
    }

    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        this.testParam = null;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    public Object[] getTestParamBackingList()
    {
        Object[] values = this.testParamValueList;
        Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    /**
     * Resets the given <code>param2a</code>.
     */
    public void resetParam2a()
    {
        this.param2a = null;
    }

    public void setParam2a(java.lang.String param2a)
    {
        this.param2a = param2a;
    }

    /**
     * 
     */
    public java.lang.String getParam2a()
    {
        return this.param2a;
    }

    public Object[] getParam2aBackingList()
    {
        Object[] values = this.param2aValueList;
        Object[] labels = this.param2aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getParam2aValueList()
    {
        return this.param2aValueList;
    }

    public void setParam2aValueList(Object[] param2aValueList)
    {
        this.param2aValueList = param2aValueList;
    }

    public Object[] getParam2aLabelList()
    {
        return this.param2aLabelList;
    }

    public void setParam2aLabelList(Object[] param2aLabelList)
    {
        this.param2aLabelList = param2aLabelList;
    }

    /**
     * Resets the given <code>pageVariable</code>.
     */
    public void resetPageVariable()
    {
        this.pageVariable = null;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    /**
     * 
     */
    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }

    public Object[] getPageVariableBackingList()
    {
        Object[] values = this.pageVariableValueList;
        Object[] labels = this.pageVariableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPageVariableValueList()
    {
        return this.pageVariableValueList;
    }

    public void setPageVariableValueList(Object[] pageVariableValueList)
    {
        this.pageVariableValueList = pageVariableValueList;
    }

    public Object[] getPageVariableLabelList()
    {
        return this.pageVariableLabelList;
    }

    public void setPageVariableLabelList(Object[] pageVariableLabelList)
    {
        this.pageVariableLabelList = pageVariableLabelList;
    }

    /**
     * Resets the given <code>testParam2</code>.
     */
    public void resetTestParam2()
    {
        this.testParam2 = 0;
    }

    public void setTestParam2(int testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public int getTestParam2()
    {
        return this.testParam2;
    }

    public Object[] getTestParam2BackingList()
    {
        Object[] values = this.testParam2ValueList;
        Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("testParam=");
        buffer.append(String.valueOf(this.getTestParam()));
        buffer.append(",param2a=");
        buffer.append(String.valueOf(this.getParam2a()));
        buffer.append(",pageVariable=");
        buffer.append(String.valueOf(this.getPageVariable()));
        buffer.append(",testParam2=");
        buffer.append(String.valueOf(this.getTestParam2()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.testParam = null;
        this.param2a = null;
        this.pageVariable = null;
        this.testParam2 = 0;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}