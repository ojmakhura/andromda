package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingguard;

public class ControllerFactory
{
    private final static Controller INSTANCE = new ControllerImpl();

    public final static Controller getControllerInstance()
    {
        return INSTANCE;
    }
}
