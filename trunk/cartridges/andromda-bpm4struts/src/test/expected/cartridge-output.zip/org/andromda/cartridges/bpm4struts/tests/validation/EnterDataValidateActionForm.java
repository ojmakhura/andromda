package org.andromda.cartridges.bpm4struts.tests.validation;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="validationActivityEnterDataValidateActionForm"
 */
public class EnterDataValidateActionForm extends ValidatorForm implements Serializable
    
{
    private java.lang.String validateRequiredTest;
    private java.net.URL validateUrlTest;
    private float validateFloatRangeTest;
    private java.lang.String validateCreditcardTest;
    private java.lang.Float validateFloatWrapperRangeTest;
    private java.util.Date validateLenientDateTest;
    private final static java.text.DateFormat validateLenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.lang.String validateMaxlengthTest;
    private java.util.Date validateStrictDateTest;
    private final static java.text.DateFormat validateStrictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private int validateIntRangeTest;
    private java.lang.Double validateDoubleWrapperRangeTest;
    private double validateDoubleRangeTest;
    private java.lang.Integer validateIntWrapperRangeTest;
    private java.lang.String validateEmailTest;
    private java.lang.String validatePatternTest;
    private java.lang.String validateMinlengthTest;

    public EnterDataValidateActionForm()
    {
        validateLenientDateTestDateFormatter.setLenient(true);
        validateStrictDateTestDateFormatter.setLenient(false);
    }

    /**
     * @struts.validator
     *          type="required"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.required.test"
     *
     */
    public void setValidateRequiredTest(java.lang.String validateRequiredTest)
    {
        this.validateRequiredTest = validateRequiredTest;
    }

    public java.lang.String getValidateRequiredTest()
    {
        return this.validateRequiredTest;
    }

    /**
     * @struts.validator
     *          type="url"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.url.test"
     *
     */
    public void setValidateUrlTest(java.net.URL validateUrlTest)
    {
        this.validateUrlTest = validateUrlTest;
    }

    public java.net.URL getValidateUrlTest()
    {
        return this.validateUrlTest;
    }

    /**
     * @struts.validator
     *          type="float"
     *
     * @struts.validator
     *          type="floatRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="1.10"
     *
     * @struts.validator-var
     *          name="max"
     *         value="7.555"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.float.range.test"
     *
     */
    public void setValidateFloatRangeTest(float validateFloatRangeTest)
    {
        this.validateFloatRangeTest = validateFloatRangeTest;
    }

    public float getValidateFloatRangeTest()
    {
        return this.validateFloatRangeTest;
    }

    /**
     * @struts.validator
     *          type="creditCard"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.creditcard.test"
     *
     */
    public void setValidateCreditcardTest(java.lang.String validateCreditcardTest)
    {
        this.validateCreditcardTest = validateCreditcardTest;
    }

    public java.lang.String getValidateCreditcardTest()
    {
        return this.validateCreditcardTest;
    }

    /**
     * @struts.validator
     *          type="float"
     *
     * @struts.validator
     *          type="floatRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="23.333"
     *
     * @struts.validator-var
     *          name="max"
     *         value="33.22222"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.float.wrapper.range.test"
     *
     */
    public void setValidateFloatWrapperRangeTest(java.lang.Float validateFloatWrapperRangeTest)
    {
        this.validateFloatWrapperRangeTest = validateFloatWrapperRangeTest;
    }

    public java.lang.Float getValidateFloatWrapperRangeTest()
    {
        return this.validateFloatWrapperRangeTest;
    }

    public void setValidateLenientDateTestAsDate(java.util.Date validateLenientDateTest)
    {
        this.validateLenientDateTest = validateLenientDateTest;
    }

    public java.util.Date getValidateLenientDateTestAsDate()
    {
        return this.validateLenientDateTest;
    }

    /**
     * @struts.validator
     *          type="date"
     *
     * @struts.validator-var
     *          name="datePattern"
     *         value="dd/MMM/yyyy"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.lenient.date.test"
     *
     */
    public void setValidateLenientDateTest(java.lang.String validateLenientDateTest)
    {
        if (validateLenientDateTest == null || validateLenientDateTest.trim().length()==0)
        {
            this.validateLenientDateTest = null;
        }
        else
        {
            try
            {
                this.validateLenientDateTest = validateLenientDateTestDateFormatter.parse(validateLenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateLenientDateTest()
    {
        return (validateLenientDateTest == null) ? null : validateLenientDateTestDateFormatter.format(validateLenientDateTest);
    }

    public java.text.DateFormat getValidateLenientDateTestDateFormatter()
    {
        return this.validateLenientDateTestDateFormatter;
    }

    /**
     * @struts.validator
     *          type="maxlength"
     *     arg1value="${var:maxlength}"
     *
     * @struts.validator-var
     *          name="maxlength"
     *         value="8"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.maxlength.test"
     *
     */
    public void setValidateMaxlengthTest(java.lang.String validateMaxlengthTest)
    {
        this.validateMaxlengthTest = validateMaxlengthTest;
    }

    public java.lang.String getValidateMaxlengthTest()
    {
        return this.validateMaxlengthTest;
    }

    public void setValidateStrictDateTestAsDate(java.util.Date validateStrictDateTest)
    {
        this.validateStrictDateTest = validateStrictDateTest;
    }

    public java.util.Date getValidateStrictDateTestAsDate()
    {
        return this.validateStrictDateTest;
    }

    /**
     * @struts.validator
     *          type="date"
     *
     * @struts.validator-var
     *          name="datePatternStrict"
     *         value="dd/MM/yyyy"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.strict.date.test"
     *
     */
    public void setValidateStrictDateTest(java.lang.String validateStrictDateTest)
    {
        if (validateStrictDateTest == null || validateStrictDateTest.trim().length()==0)
        {
            this.validateStrictDateTest = null;
        }
        else
        {
            try
            {
                this.validateStrictDateTest = validateStrictDateTestDateFormatter.parse(validateStrictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateStrictDateTest()
    {
        return (validateStrictDateTest == null) ? null : validateStrictDateTestDateFormatter.format(validateStrictDateTest);
    }

    public java.text.DateFormat getValidateStrictDateTestDateFormatter()
    {
        return this.validateStrictDateTestDateFormatter;
    }

    /**
     * @struts.validator
     *          type="integer"
     *
     * @struts.validator
     *          type="intRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="5"
     *
     * @struts.validator-var
     *          name="max"
     *         value="10"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.int.range.test"
     *
     */
    public void setValidateIntRangeTest(int validateIntRangeTest)
    {
        this.validateIntRangeTest = validateIntRangeTest;
    }

    public int getValidateIntRangeTest()
    {
        return this.validateIntRangeTest;
    }

    /**
     * @struts.validator
     *          type="double"
     *
     * @struts.validator
     *          type="doubleRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="10001.111111"
     *
     * @struts.validator-var
     *          name="max"
     *         value="2343223.432234324"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.double.wrapper.range.test"
     *
     */
    public void setValidateDoubleWrapperRangeTest(java.lang.Double validateDoubleWrapperRangeTest)
    {
        this.validateDoubleWrapperRangeTest = validateDoubleWrapperRangeTest;
    }

    public java.lang.Double getValidateDoubleWrapperRangeTest()
    {
        return this.validateDoubleWrapperRangeTest;
    }

    /**
     * @struts.validator
     *          type="double"
     *
     * @struts.validator
     *          type="doubleRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="321.123"
     *
     * @struts.validator-var
     *          name="max"
     *         value="987.78985"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.double.range.test"
     *
     */
    public void setValidateDoubleRangeTest(double validateDoubleRangeTest)
    {
        this.validateDoubleRangeTest = validateDoubleRangeTest;
    }

    public double getValidateDoubleRangeTest()
    {
        return this.validateDoubleRangeTest;
    }

    /**
     * @struts.validator
     *          type="integer"
     *
     * @struts.validator
     *          type="intRange"
     *     arg1value="${var:min}"
     *     arg2value="${var:max}"
     *
     * @struts.validator-var
     *          name="min"
     *         value="1000"
     *
     * @struts.validator-var
     *          name="max"
     *         value="2000"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.int.wrapper.range.test"
     *
     */
    public void setValidateIntWrapperRangeTest(java.lang.Integer validateIntWrapperRangeTest)
    {
        this.validateIntWrapperRangeTest = validateIntWrapperRangeTest;
    }

    public java.lang.Integer getValidateIntWrapperRangeTest()
    {
        return this.validateIntWrapperRangeTest;
    }

    /**
     * @struts.validator
     *          type="email"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.email.test"
     *
     */
    public void setValidateEmailTest(java.lang.String validateEmailTest)
    {
        this.validateEmailTest = validateEmailTest;
    }

    public java.lang.String getValidateEmailTest()
    {
        return this.validateEmailTest;
    }

    /**
     * @struts.validator
     *          type="mask"
     *
     * @struts.validator-var
     *          name="mask"
     *         value="^[a-zA-Z]$"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.pattern.test"
     *
     */
    public void setValidatePatternTest(java.lang.String validatePatternTest)
    {
        this.validatePatternTest = validatePatternTest;
    }

    public java.lang.String getValidatePatternTest()
    {
        return this.validatePatternTest;
    }

    /**
     * @struts.validator
     *          type="minlength"
     *     arg1value="${var:minlength}"
     *
     * @struts.validator-var
     *          name="minlength"
     *         value="4"
     *
     * @struts.validator-args
     *  arg0resource="validation.activity.enter.data.validate.minlength.test"
     *
     */
    public void setValidateMinlengthTest(java.lang.String validateMinlengthTest)
    {
        this.validateMinlengthTest = validateMinlengthTest;
    }

    public java.lang.String getValidateMinlengthTest()
    {
        return this.validateMinlengthTest;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("validateRequiredTest=");
        buffer.append(String.valueOf(this.getValidateRequiredTest()));
        buffer.append(",validateUrlTest=");
        buffer.append(String.valueOf(this.getValidateUrlTest()));
        buffer.append(",validateFloatRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatRangeTest()));
        buffer.append(",validateCreditcardTest=");
        buffer.append(String.valueOf(this.getValidateCreditcardTest()));
        buffer.append(",validateFloatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatWrapperRangeTest()));
        buffer.append(",validateLenientDateTest=");
        buffer.append(String.valueOf(this.getValidateLenientDateTest()));
        buffer.append(",validateMaxlengthTest=");
        buffer.append(String.valueOf(this.getValidateMaxlengthTest()));
        buffer.append(",validateStrictDateTest=");
        buffer.append(String.valueOf(this.getValidateStrictDateTest()));
        buffer.append(",validateIntRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntRangeTest()));
        buffer.append(",validateDoubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleWrapperRangeTest()));
        buffer.append(",validateDoubleRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleRangeTest()));
        buffer.append(",validateIntWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntWrapperRangeTest()));
        buffer.append(",validateEmailTest=");
        buffer.append(String.valueOf(this.getValidateEmailTest()));
        buffer.append(",validatePatternTest=");
        buffer.append(String.valueOf(this.getValidatePatternTest()));
        buffer.append(",validateMinlengthTest=");
        buffer.append(String.valueOf(this.getValidateMinlengthTest()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.validateRequiredTest = null;
        this.validateUrlTest = null;
        this.validateFloatRangeTest = 0;
        this.validateCreditcardTest = null;
        this.validateFloatWrapperRangeTest = null;
        this.validateLenientDateTest = null;
        this.validateMaxlengthTest = null;
        this.validateStrictDateTest = null;
        this.validateIntRangeTest = 0;
        this.validateDoubleWrapperRangeTest = null;
        this.validateDoubleRangeTest = 0;
        this.validateIntWrapperRangeTest = null;
        this.validateEmailTest = null;
        this.validatePatternTest = null;
        this.validateMinlengthTest = null;
    }

}
