/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.names;

public class SimilarNameFactory
{
    private final static SimilarName INSTANCE = new SimilarNameImpl();

    public final static SimilarName getSimilarNameInstance()
    {
        return INSTANCE;
    }
}