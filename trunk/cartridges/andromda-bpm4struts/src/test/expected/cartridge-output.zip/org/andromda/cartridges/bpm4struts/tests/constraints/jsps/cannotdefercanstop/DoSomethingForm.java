package org.andromda.cartridges.bpm4struts.tests.constraints.jsps.cannotdefercanstop;

public interface DoSomethingForm
{
}
