package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import java.io.Serializable;


/**
 * @struts.form
 *      name="tableLinkActivityTableLinkActivityActionForm"
 */
public final class TableLinkActivityActionForm extends TableLinkActivityForm implements Serializable
{
}
