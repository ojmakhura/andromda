/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class ControllerFactory
{
    private final static Controller INSTANCE = new ControllerImpl();

    public final static Controller getControllerInstance()
    {
        return INSTANCE;
    }
}