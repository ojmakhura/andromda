package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/NoTableLinkActivity/ShowTableDataAgain"
 *        name="noTableLinkActivityForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *    validate="false"
 *       scope="session"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="again"
 *        path="/TableLinkActivity/TableLinkActivity.do"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="no.table.link.activity.show.table.data.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/notablelink/show-table-data.jsp"
 *       scope="request"
 *
 */
public final class ShowTableDataAgain extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = mapping.findForward("again");

        return forward;
    }

}
