package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgain2Form"
 */
public class ShowTableDataAgain2Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String otherName;

    public ShowTableDataAgain2Form()
    {
    }

    public void setOtherName(java.lang.String otherName)
    {
        this.otherName = otherName;
    }

    public java.lang.String getOtherName()
    {
        return this.otherName;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("otherName=");
        buffer.append(String.valueOf(this.getOtherName()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.otherName = null;
    }

}
