package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

public interface SomeOperationForm
{
}