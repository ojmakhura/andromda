/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.interactionstate;

/**
 * 
 */
public final class InterActionState extends org.apache.struts.action.Action
{
    public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        // copy any parameters from the previous form into this one
        // (only those with the same name and type are considered, and only if they can be set in the target form)
        org.apache.commons.beanutils.BeanUtils.populate(form, request.getParameterMap());

        org.apache.struts.action.ActionForward forward = mapping.findForward("page1");

        // we only set the new form if no exception handling messages occur
        // otherwise we lose ALL information (such as collections) 
        // from the current form when we go back to the current page
        if (this.getExceptionHandlerErrors(request).isEmpty())
        {
            request.getSession().setAttribute("form", form);
        }
        else
        {
            // the current form MUST be populated here with any new values 
            // because of the fact we didn't set the new form
            
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }

        return forward;
    }

    /**
     * Retrieves the exception handler messages (if any). Creates a new
     * <code>org.apache.struts.action.ActionMessages</code> instance and returns that if one doesn't already exist.
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(javax.servlet.http.HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = null;
        final javax.servlet.http.HttpSession session = request.getSession();
        if (session != null)
        {
            errors = (org.apache.struts.action.ActionMessages)session.getAttribute(org.apache.struts.Globals.MESSAGE_KEY);
            if (errors == null)
            {
                errors = new org.apache.struts.action.ActionMessages();
                session.setAttribute(org.apache.struts.Globals.MESSAGE_KEY, errors);
            }
        }
        return errors;
    }
}