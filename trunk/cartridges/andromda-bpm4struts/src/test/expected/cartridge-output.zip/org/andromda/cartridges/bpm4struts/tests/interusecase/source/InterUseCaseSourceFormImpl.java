/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.interusecase.source;

public class InterUseCaseSourceFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private int sourceParam1;
    private Object[] sourceParam1ValueList;
    private Object[] sourceParam1LabelList;
    private java.lang.String sourceParam2;
    private Object[] sourceParam2ValueList;
    private Object[] sourceParam2LabelList;

    public InterUseCaseSourceFormImpl()
    {
    }

    /**
     * Resets the given <code>sourceParam1</code>.
     */
    public void resetSourceParam1()
    {
        this.sourceParam1 = 0;
    }
    
    public void setSourceParam1(int sourceParam1)
    {
        this.sourceParam1 = sourceParam1;
    }

    /**
     * 
     */
    public int getSourceParam1()
    {
        return this.sourceParam1;
    }
    

    public Object[] getSourceParam1BackingList()
    {
        Object[] values = this.sourceParam1ValueList;
        Object[] labels = this.sourceParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSourceParam1ValueList()
    {
        return this.sourceParam1ValueList;
    }

    public void setSourceParam1ValueList(Object[] sourceParam1ValueList)
    {
        this.sourceParam1ValueList = sourceParam1ValueList;
    }

    public Object[] getSourceParam1LabelList()
    {
        return this.sourceParam1LabelList;
    }

    public void setSourceParam1LabelList(Object[] sourceParam1LabelList)
    {
        this.sourceParam1LabelList = sourceParam1LabelList;
    }

    public void setSourceParam1BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("InterUseCaseSourceFormImpl.setSourceParam1BackingList requires non-null property arguments");
        }

        this.sourceParam1ValueList = null;
        this.sourceParam1LabelList = null;

        if (items != null)
        {
            this.sourceParam1ValueList = new Object[items.size()];
            this.sourceParam1LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.sourceParam1ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.sourceParam1LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("InterUseCaseSourceFormImpl.setSourceParam1BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>sourceParam2</code>.
     */
    public void resetSourceParam2()
    {
        this.sourceParam2 = null;
    }
    
    public void setSourceParam2(java.lang.String sourceParam2)
    {
        this.sourceParam2 = sourceParam2;
    }

    /**
     * 
     */
    public java.lang.String getSourceParam2()
    {
        return this.sourceParam2;
    }
    

    public Object[] getSourceParam2BackingList()
    {
        Object[] values = this.sourceParam2ValueList;
        Object[] labels = this.sourceParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSourceParam2ValueList()
    {
        return this.sourceParam2ValueList;
    }

    public void setSourceParam2ValueList(Object[] sourceParam2ValueList)
    {
        this.sourceParam2ValueList = sourceParam2ValueList;
    }

    public Object[] getSourceParam2LabelList()
    {
        return this.sourceParam2LabelList;
    }

    public void setSourceParam2LabelList(Object[] sourceParam2LabelList)
    {
        this.sourceParam2LabelList = sourceParam2LabelList;
    }

    public void setSourceParam2BackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("InterUseCaseSourceFormImpl.setSourceParam2BackingList requires non-null property arguments");
        }

        this.sourceParam2ValueList = null;
        this.sourceParam2LabelList = null;

        if (items != null)
        {
            this.sourceParam2ValueList = new Object[items.size()];
            this.sourceParam2LabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.sourceParam2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.sourceParam2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("InterUseCaseSourceFormImpl.setSourceParam2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("sourceParam1", this.sourceParam1);
        builder.append("sourceParam2", this.sourceParam2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.sourceParam1 = 0;
        this.sourceParam2 = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}