package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/StartOrExitPageUseCase/SomePageSubmit"
 *        name="startOrExitPageUseCaseSomePageSubmitForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="some.page"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="start.or.exit.page.use.case.some.page.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *       scope="request"
 *
 */
public final class SomePageSubmit extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = thisIsNotAPage(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward thisIsNotAPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return neitherIsThis(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward neitherIsThis(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("some.page");
    }

}
