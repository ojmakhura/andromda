package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/StartOrExitPageUseCase/SomePageSubmit"
 *        name="startOrExitPageUseCaseSomePageSubmitForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="some.page"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="start.or.exit.page.use.case.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *       scope="request"
 *
 */
public final class SomePageSubmit extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = _thisIsNotAPage(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _neitherIsThis(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("some.page");
    }

    /**
     * 
     */
    private ActionForward _thisIsNotAPage(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return _neitherIsThis(mapping, form, request, response);
    }

}
