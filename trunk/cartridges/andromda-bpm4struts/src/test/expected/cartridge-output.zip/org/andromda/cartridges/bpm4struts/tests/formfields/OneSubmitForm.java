package org.andromda.cartridges.bpm4struts.tests.formfields;

public class OneSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , SomeOperationForm
{
    private java.lang.String text;
    private java.util.Collection multiSelect;
    private Object[] multiSelectValueList;
    private Object[] multiSelectLabelList;
    private java.util.Collection collection;
    private Object[] collectionValueList;
    private Object[] collectionLabelList;
    private java.util.Date date;
    private final static java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private boolean bool;
    private java.lang.String selectable;
    private Object[] selectableValueList;
    private Object[] selectableLabelList;
    private int number;

    public OneSubmitForm()
    {
        dateDateFormatter.setLenient(true);
    }

    public void setText(java.lang.String text)
    {
        this.text = text;
    }

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }

    public void setMultiSelect(java.util.Collection multiSelect)
    {
        this.multiSelect = multiSelect;
    }

    /**
     * 
     */
    public java.util.Collection getMultiSelect()
    {
        return this.multiSelect;
    }

    public void setMultiSelectAsArray(Object[] multiSelect)
    {
        this.multiSelect = (multiSelect == null) ? null : java.util.Arrays.asList(multiSelect);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getMultiSelect
     */
    public Object[] getMultiSelectAsArray()
    {
        return (multiSelect == null) ? null : multiSelect.toArray();
    }

    public Object[] getMultiSelectBackingList()
    {
        Object[] values = this.multiSelectValueList;
        Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    public void setCollection(java.util.Collection collection)
    {
        this.collection = collection;
    }

    /**
     * 
     */
    public java.util.Collection getCollection()
    {
        return this.collection;
    }

    public void setCollectionAsArray(Object[] collection)
    {
        this.collection = (collection == null) ? null : java.util.Arrays.asList(collection);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getCollection
     */
    public Object[] getCollectionAsArray()
    {
        return (collection == null) ? null : collection.toArray();
    }

    public Object[] getCollectionBackingList()
    {
        Object[] values = this.collectionValueList;
        Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    public void setDateAsDate(java.util.Date date)
    {
        this.date = date;
    }

    /**
     * Returns the Date instance representing the <code>date</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate#ateFormatter
     */
    public java.util.Date getDateAsDate()
    {
        return this.date;
    }

    public void setDate(java.lang.String date)
    {
        if (date == null || date.trim().length()==0)
        {
            this.date = null;
        }
        else
        {
            try
            {
                this.date = dateDateFormatter.parse(date);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate#sDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate#ateFormatter
     */
    public java.lang.String getDate()
    {
        return (date == null) ? null : dateDateFormatter.format(date);
    }

    /**
     * Returns the date formatter used for the <code>date</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.OneSubmitForm#getDate#sDate
     */
    public final static java.text.DateFormat getDateDateFormatter()
    {
        return OneSubmitForm.dateDateFormatter;
    }

    public void setBool(boolean bool)
    {
        this.bool = bool;
    }

    /**
     * 
     */
    public boolean getBool()
    {
        return this.bool;
    }

    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
    }

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }

    public Object[] getSelectableBackingList()
    {
        Object[] values = this.selectableValueList;
        Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    public void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.multiSelect = null;
        this.multiSelectValueList = new Object[0];
        this.multiSelectLabelList = new Object[0];
        this.collection = null;
        this.collectionValueList = new Object[0];
        this.collectionLabelList = new Object[0];
        this.bool = false;
        this.selectable = null;
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("text=");
        buffer.append(String.valueOf(this.getText()));
        buffer.append(",multiSelect=");
        buffer.append(toString(this.getMultiSelect()));
        buffer.append(",collection=");
        buffer.append(toString(this.getCollection()));
        buffer.append(",date=");
        buffer.append(String.valueOf(this.getDate()));
        buffer.append(",bool=");
        buffer.append(String.valueOf(this.getBool()));
        buffer.append(",selectable=");
        buffer.append(String.valueOf(this.getSelectable()));
        buffer.append(",number=");
        buffer.append(String.valueOf(this.getNumber()));

        return buffer.append("]").toString();
    }

    /**
     * Helper method to convert a collection to a String.
     */
    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    /**
     * Helper method to convert an array to a String.
     */
    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.text = null;
        this.multiSelect = null;
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        this.collection = null;
        this.collectionValueList = null;
        this.collectionLabelList = null;
        this.date = null;
        this.bool = false;
        this.selectable = null;
        this.selectableValueList = null;
        this.selectableLabelList = null;
        this.number = 0;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}
