package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgain2ActionForm"
 */
public class ShowTableDataAgain2ActionForm extends ValidatorForm implements Serializable
    
{
    private java.lang.String again2OtherName;

    public ShowTableDataAgain2ActionForm()
    {
    }

    public void setAgain2OtherName(java.lang.String again2OtherName)
    {
        this.again2OtherName = again2OtherName;
    }

    public java.lang.String getAgain2OtherName()
    {
        return this.again2OtherName;
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("again2OtherName=");
        buffer.append(String.valueOf(this.getAgain2OtherName()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.again2OtherName = null;
    }

}
