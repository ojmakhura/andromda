package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import java.io.Serializable;


/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgain2ActionForm"
 */
public final class ShowTableDataAgain2ActionForm extends TableLinkActivityForm implements Serializable
{
    public void setAgain2OtherName(java.lang.String again2OtherName)
    {
        super.setAgain2OtherName(again2OtherName);
    }

}
