/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.widgets;

public class WidgetsActivityFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , org.andromda.cartridges.bpm4struts.tests.widgets.PreloadSelectsForm
{
    private java.lang.String textAreaTest;
    private java.lang.Object[] textAreaTestValueList;
    private java.lang.Object[] textAreaTestLabelList;
    private java.lang.String radioButtonsTest3;
    private java.lang.Object[] radioButtonsTest3ValueList;
    private java.lang.Object[] radioButtonsTest3LabelList;
    private java.lang.String radioButtonsTest;
    private java.lang.Object[] radioButtonsTestValueList;
    private java.lang.Object[] radioButtonsTestLabelList;
    private boolean checkboxTest;
    private java.lang.Object[] checkboxTestValueList;
    private java.lang.Object[] checkboxTestLabelList;
    private java.lang.String textFieldTest2;
    private java.lang.Object[] textFieldTest2ValueList;
    private java.lang.Object[] textFieldTest2LabelList;
    private java.lang.String selectTest;
    private java.lang.Object[] selectTestValueList;
    private java.lang.Object[] selectTestLabelList;
    private java.lang.String textFieldTest;
    private java.lang.Object[] textFieldTestValueList;
    private java.lang.Object[] textFieldTestLabelList;
    private java.lang.String hiddenTest;
    private java.lang.Object[] hiddenTestValueList;
    private java.lang.Object[] hiddenTestLabelList;
    private java.lang.String passwordFieldTest;
    private java.lang.Object[] passwordFieldTestValueList;
    private java.lang.Object[] passwordFieldTestLabelList;
    private java.lang.String radioButtonsTest2;
    private java.lang.Object[] radioButtonsTest2ValueList;
    private java.lang.Object[] radioButtonsTest2LabelList;

    public WidgetsActivityFormImpl()
    {
    }

    /**
     * Resets the given <code>textAreaTest</code>.
     */
    public void resetTextAreaTest()
    {
        this.textAreaTest = null;
    }

    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
    }

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }
    
    public java.lang.Object[] getTextAreaTestBackingList()
    {
        java.lang.Object[] values = this.textAreaTestValueList;
        java.lang.Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(java.lang.Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public java.lang.Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(java.lang.Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    public void setTextAreaTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextAreaTestBackingList requires non-null property arguments");
        }

        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;

        if (items != null)
        {
            this.textAreaTestValueList = new java.lang.Object[items.size()];
            this.textAreaTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.textAreaTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textAreaTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setTextAreaTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest3</code>.
     */
    public void resetRadioButtonsTest3()
    {
        this.radioButtonsTest3 = null;
    }

    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }
    
    /**
     * Converts the selected option index to the corresponding value as it was modeled.
     */
    public java.lang.String getRadioButtonsTest3OptionValue(int optionIndex)
    {
        switch(optionIndex)
        {
            case 0 : return "aaa";
            case 1 : return "bbb";
            case 2 : return "ccc";
            case 3 : return "ddd";
            default:
                throw new java.lang.ArrayIndexOutOfBoundsException(
                    "Cannot access option "+optionIndex+", please specify a value in the range [0-3]");
        }
    }

    public java.lang.Object[] getRadioButtonsTest3BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest3ValueList;
        java.lang.Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(java.lang.Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(java.lang.Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTest3BackingList requires non-null property arguments");
        }

        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;

        if (items != null)
        {
            this.radioButtonsTest3ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest3LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.radioButtonsTest3ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTest3LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setRadioButtonsTest3BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest</code>.
     */
    public void resetRadioButtonsTest()
    {
        this.radioButtonsTest = null;
    }

    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }
    
    /**
     * Converts the selected option index to the corresponding value as it was modeled.
     */
    public java.lang.String getRadioButtonsTestOptionValue(int optionIndex)
    {
        switch(optionIndex)
        {
            case 0 : return "0";
            case 1 : return "1";
            case 2 : return "2";
            case 3 : return "3";
            case 4 : return "4";
            default:
                throw new java.lang.ArrayIndexOutOfBoundsException(
                    "Cannot access option "+optionIndex+", please specify a value in the range [0-4]");
        }
    }

    public java.lang.Object[] getRadioButtonsTestBackingList()
    {
        java.lang.Object[] values = this.radioButtonsTestValueList;
        java.lang.Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(java.lang.Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public java.lang.Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(java.lang.Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTestBackingList requires non-null property arguments");
        }

        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;

        if (items != null)
        {
            this.radioButtonsTestValueList = new java.lang.Object[items.size()];
            this.radioButtonsTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.radioButtonsTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setRadioButtonsTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>checkboxTest</code>.
     */
    public void resetCheckboxTest()
    {
        this.checkboxTest = false;
    }

    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
    }

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }
    
    public java.lang.Object[] getCheckboxTestBackingList()
    {
        java.lang.Object[] values = this.checkboxTestValueList;
        java.lang.Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(java.lang.Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public java.lang.Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(java.lang.Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    public void setCheckboxTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setCheckboxTestBackingList requires non-null property arguments");
        }

        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;

        if (items != null)
        {
            this.checkboxTestValueList = new java.lang.Object[items.size()];
            this.checkboxTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.checkboxTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.checkboxTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setCheckboxTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>textFieldTest2</code>.
     */
    public void resetTextFieldTest2()
    {
        this.textFieldTest2 = null;
    }

    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }
    
    public java.lang.Object[] getTextFieldTest2BackingList()
    {
        java.lang.Object[] values = this.textFieldTest2ValueList;
        java.lang.Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(java.lang.Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public java.lang.Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(java.lang.Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    public void setTextFieldTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextFieldTest2BackingList requires non-null property arguments");
        }

        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;

        if (items != null)
        {
            this.textFieldTest2ValueList = new java.lang.Object[items.size()];
            this.textFieldTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.textFieldTest2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textFieldTest2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setTextFieldTest2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>selectTest</code>.
     */
    public void resetSelectTest()
    {
        this.selectTest = null;
    }

    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
    }

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }
    
    public java.lang.Object[] getSelectTestBackingList()
    {
        java.lang.Object[] values = this.selectTestValueList;
        java.lang.Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(java.lang.Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public java.lang.Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(java.lang.Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    public void setSelectTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setSelectTestBackingList requires non-null property arguments");
        }

        this.selectTestValueList = null;
        this.selectTestLabelList = null;

        if (items != null)
        {
            this.selectTestValueList = new java.lang.Object[items.size()];
            this.selectTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.selectTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.selectTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setSelectTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>textFieldTest</code>.
     */
    public void resetTextFieldTest()
    {
        this.textFieldTest = null;
    }

    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }
    
    public java.lang.Object[] getTextFieldTestBackingList()
    {
        java.lang.Object[] values = this.textFieldTestValueList;
        java.lang.Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(java.lang.Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public java.lang.Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(java.lang.Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    public void setTextFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextFieldTestBackingList requires non-null property arguments");
        }

        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;

        if (items != null)
        {
            this.textFieldTestValueList = new java.lang.Object[items.size()];
            this.textFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.textFieldTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textFieldTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setTextFieldTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hiddenTest</code>.
     */
    public void resetHiddenTest()
    {
        this.hiddenTest = null;
    }

    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
    }

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }
    
    public java.lang.Object[] getHiddenTestBackingList()
    {
        java.lang.Object[] values = this.hiddenTestValueList;
        java.lang.Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(java.lang.Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public java.lang.Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(java.lang.Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    public void setHiddenTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setHiddenTestBackingList requires non-null property arguments");
        }

        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;

        if (items != null)
        {
            this.hiddenTestValueList = new java.lang.Object[items.size()];
            this.hiddenTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.hiddenTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hiddenTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setHiddenTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>passwordFieldTest</code>.
     */
    public void resetPasswordFieldTest()
    {
        this.passwordFieldTest = null;
    }

    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }
    
    public java.lang.Object[] getPasswordFieldTestBackingList()
    {
        java.lang.Object[] values = this.passwordFieldTestValueList;
        java.lang.Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(java.lang.Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public java.lang.Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(java.lang.Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setPasswordFieldTestBackingList requires non-null property arguments");
        }

        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;

        if (items != null)
        {
            this.passwordFieldTestValueList = new java.lang.Object[items.size()];
            this.passwordFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.passwordFieldTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.passwordFieldTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setPasswordFieldTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>radioButtonsTest2</code>.
     */
    public void resetRadioButtonsTest2()
    {
        this.radioButtonsTest2 = null;
    }

    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }
    
    /**
     * Converts the selected option index to the corresponding value as it was modeled.
     */
    public java.lang.String getRadioButtonsTest2OptionValue(int optionIndex)
    {
        switch(optionIndex)
        {
            default:
                throw new java.lang.ArrayIndexOutOfBoundsException(
                    "Cannot access option "+optionIndex+", please specify a value in the range [0-4]");
        }
    }

    public java.lang.Object[] getRadioButtonsTest2BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest2ValueList;
        java.lang.Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(java.lang.Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(java.lang.Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTest2BackingList requires non-null property arguments");
        }

        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;

        if (items != null)
        {
            this.radioButtonsTest2ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.radioButtonsTest2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.radioButtonsTest2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("WidgetsActivityFormImpl.setRadioButtonsTest2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.checkboxTest = false;
        this.selectTest = null;
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("textAreaTest", this.textAreaTest);
        builder.append("radioButtonsTest3", this.radioButtonsTest3);
        builder.append("radioButtonsTest", this.radioButtonsTest);
        builder.append("checkboxTest", this.checkboxTest);
        builder.append("textFieldTest2", this.textFieldTest2);
        builder.append("selectTest", this.selectTest);
        builder.append("textFieldTest", this.textFieldTest);
        builder.append("hiddenTest", this.hiddenTest);
        builder.append("passwordFieldTest", "***");
        builder.append("radioButtonsTest2", this.radioButtonsTest2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.textAreaTest = null;
        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;
        this.radioButtonsTest3 = null;
        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;
        this.radioButtonsTest = null;
        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;
        this.checkboxTest = false;
        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;
        this.textFieldTest2 = null;
        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;
        this.selectTest = null;
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        this.textFieldTest = null;
        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;
        this.hiddenTest = null;
        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;
        this.passwordFieldTest = null;
        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;
        this.radioButtonsTest2 = null;
        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}