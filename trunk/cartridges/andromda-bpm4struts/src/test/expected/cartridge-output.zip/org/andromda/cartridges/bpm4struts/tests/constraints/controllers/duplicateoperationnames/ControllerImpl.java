package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.DuplicateNameForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void duplicateName(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.DuplicateNameForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.DuplicateNameForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void duplicateName(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.DuplicateNameForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setDiffParam("diffParam-test");
    }

}
