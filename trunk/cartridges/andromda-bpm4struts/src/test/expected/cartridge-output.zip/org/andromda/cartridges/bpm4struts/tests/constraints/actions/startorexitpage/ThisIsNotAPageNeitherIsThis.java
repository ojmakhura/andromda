package org.andromda.cartridges.bpm4struts.tests.constraints.actions.startorexitpage;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/UseCase/ThisIsNotAPageNeitherIsThis"
 *        name="useCaseThisIsNotAPageNeitherIsThisActionForm"
 *       input="${action.input.fullPath}.jsp"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="some.page"
 *        path="/org/andromda/cartridges/bpm4struts/tests/constraints/actions/startorexitpage/some-page.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="use.case.use.case.exception"
 *        type="java.lang.Exception"
 *        path="${action.input.fullPath}.jsp"
 *       scope="request"
 *
 */
public final class ThisIsNotAPageNeitherIsThis extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = neitherIsThis(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward neitherIsThis(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("some.page");
    }

}
