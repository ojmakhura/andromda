package org.andromda.cartridges.bpm4struts.tests.messages;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

/**
 * 
 *
 */
public abstract class Controller implements java.io.Serializable
{
    public abstract boolean doSomething(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.messages.DoSomethingForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;


    protected final void saveWarningMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.warningmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.warningmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }

    protected final void saveSuccessMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.successmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.successmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }
}
