/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.validation;

public class ValidationActivityFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String minLengthOnPasswordTest;
    private java.lang.Object[] minLengthOnPasswordTestValueList;
    private java.lang.Object[] minLengthOnPasswordTestLabelList;
    private java.lang.String requiredTest;
    private java.lang.Object[] requiredTestValueList;
    private java.lang.Object[] requiredTestLabelList;
    private java.lang.String emailTest;
    private java.lang.Object[] emailTestValueList;
    private java.lang.Object[] emailTestLabelList;
    private int intRangeTest;
    private java.lang.Object[] intRangeTestValueList;
    private java.lang.Object[] intRangeTestLabelList;
    private double doubleRangeTest;
    private java.lang.Object[] doubleRangeTestValueList;
    private java.lang.Object[] doubleRangeTestLabelList;
    private java.util.Date hiddenNotValidated;
    private final static java.text.DateFormat hiddenNotValidatedDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private java.lang.Object[] hiddenNotValidatedValueList;
    private java.lang.Object[] hiddenNotValidatedLabelList;
    private java.lang.String maxlengthTest;
    private java.lang.Object[] maxlengthTestValueList;
    private java.lang.Object[] maxlengthTestLabelList;
    private java.lang.String patternTest;
    private java.lang.Object[] patternTestValueList;
    private java.lang.Object[] patternTestLabelList;
    private java.lang.Float floatWrapperRangeTest;
    private java.lang.Object[] floatWrapperRangeTestValueList;
    private java.lang.Object[] floatWrapperRangeTestLabelList;
    private java.lang.Integer intWrapperRangeTest;
    private java.lang.Object[] intWrapperRangeTestValueList;
    private java.lang.Object[] intWrapperRangeTestLabelList;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.lang.Object[] lenientDateTestValueList;
    private java.lang.Object[] lenientDateTestLabelList;
    private java.net.URL urlTest;
    private java.lang.Object[] urlTestValueList;
    private java.lang.Object[] urlTestLabelList;
    private java.lang.String minlengthTest;
    private java.lang.Object[] minlengthTestValueList;
    private java.lang.Object[] minlengthTestLabelList;
    private float floatRangeTest;
    private java.lang.Object[] floatRangeTestValueList;
    private java.lang.Object[] floatRangeTestLabelList;
    private java.lang.Double doubleWrapperRangeTest;
    private java.lang.Object[] doubleWrapperRangeTestValueList;
    private java.lang.Object[] doubleWrapperRangeTestLabelList;
    private java.lang.String creditcardTest;
    private java.lang.Object[] creditcardTestValueList;
    private java.lang.Object[] creditcardTestLabelList;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private java.lang.Object[] strictDateTestValueList;
    private java.lang.Object[] strictDateTestLabelList;

    public ValidationActivityFormImpl()
    {
        hiddenNotValidatedDateFormatter.setLenient(true);
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    /**
     * Resets the given <code>minLengthOnPasswordTest</code>.
     */
    public void resetMinLengthOnPasswordTest()
    {
        this.minLengthOnPasswordTest = null;
    }

    public void setMinLengthOnPasswordTest(java.lang.String minLengthOnPasswordTest)
    {
        this.minLengthOnPasswordTest = minLengthOnPasswordTest;
    }

    /**
     * 
     */
    public java.lang.String getMinLengthOnPasswordTest()
    {
        return this.minLengthOnPasswordTest;
    }
    
    public java.lang.Object[] getMinLengthOnPasswordTestBackingList()
    {
        java.lang.Object[] values = this.minLengthOnPasswordTestValueList;
        java.lang.Object[] labels = this.minLengthOnPasswordTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMinLengthOnPasswordTestValueList()
    {
        return this.minLengthOnPasswordTestValueList;
    }

    public void setMinLengthOnPasswordTestValueList(java.lang.Object[] minLengthOnPasswordTestValueList)
    {
        this.minLengthOnPasswordTestValueList = minLengthOnPasswordTestValueList;
    }

    public java.lang.Object[] getMinLengthOnPasswordTestLabelList()
    {
        return this.minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestLabelList(java.lang.Object[] minLengthOnPasswordTestLabelList)
    {
        this.minLengthOnPasswordTestLabelList = minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setMinLengthOnPasswordTestBackingList requires non-null property arguments");
        }

        this.minLengthOnPasswordTestValueList = null;
        this.minLengthOnPasswordTestLabelList = null;

        if (items != null)
        {
            this.minLengthOnPasswordTestValueList = new java.lang.Object[items.size()];
            this.minLengthOnPasswordTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.minLengthOnPasswordTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.minLengthOnPasswordTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setMinLengthOnPasswordTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>requiredTest</code>.
     */
    public void resetRequiredTest()
    {
        this.requiredTest = null;
    }

    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }
    
    public java.lang.Object[] getRequiredTestBackingList()
    {
        java.lang.Object[] values = this.requiredTestValueList;
        java.lang.Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(java.lang.Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public java.lang.Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(java.lang.Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    public void setRequiredTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setRequiredTestBackingList requires non-null property arguments");
        }

        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;

        if (items != null)
        {
            this.requiredTestValueList = new java.lang.Object[items.size()];
            this.requiredTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.requiredTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.requiredTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setRequiredTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>emailTest</code>.
     */
    public void resetEmailTest()
    {
        this.emailTest = null;
    }

    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }
    
    public java.lang.Object[] getEmailTestBackingList()
    {
        java.lang.Object[] values = this.emailTestValueList;
        java.lang.Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(java.lang.Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public java.lang.Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(java.lang.Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    public void setEmailTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setEmailTestBackingList requires non-null property arguments");
        }

        this.emailTestValueList = null;
        this.emailTestLabelList = null;

        if (items != null)
        {
            this.emailTestValueList = new java.lang.Object[items.size()];
            this.emailTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.emailTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.emailTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setEmailTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intRangeTest</code>.
     */
    public void resetIntRangeTest()
    {
        this.intRangeTest = 0;
    }

    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }
    
    public java.lang.Object[] getIntRangeTestBackingList()
    {
        java.lang.Object[] values = this.intRangeTestValueList;
        java.lang.Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(java.lang.Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public java.lang.Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(java.lang.Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    public void setIntRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setIntRangeTestBackingList requires non-null property arguments");
        }

        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;

        if (items != null)
        {
            this.intRangeTestValueList = new java.lang.Object[items.size()];
            this.intRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.intRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setIntRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleRangeTest</code>.
     */
    public void resetDoubleRangeTest()
    {
        this.doubleRangeTest = 0;
    }

    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }
    
    public java.lang.Object[] getDoubleRangeTestBackingList()
    {
        java.lang.Object[] values = this.doubleRangeTestValueList;
        java.lang.Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(java.lang.Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public java.lang.Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(java.lang.Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setDoubleRangeTestBackingList requires non-null property arguments");
        }

        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.doubleRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setDoubleRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hiddenNotValidated</code>.
     */
    public void resetHiddenNotValidated()
    {
        this.hiddenNotValidated = null;
    }

    public void setHiddenNotValidatedAsDate(java.util.Date hiddenNotValidated)
    {
        this.hiddenNotValidated = hiddenNotValidated;
    }

    /**
     * Returns the Date instance representing the <code>hiddenNotValidated</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getHiddenNotValidated
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#hiddenNotValidatedDateFormatter
     */
    public java.util.Date getHiddenNotValidatedAsDate()
    {
        return this.hiddenNotValidated;
    }

    public void setHiddenNotValidated(java.lang.String hiddenNotValidated)
    {
        if (hiddenNotValidated == null || hiddenNotValidated.trim().length() == 0)
        {
            this.hiddenNotValidated = null;
        }
        else
        {
            try
            {
                this.hiddenNotValidated = hiddenNotValidatedDateFormatter.parse(hiddenNotValidated);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.hiddenNotValidated = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getHiddenNotValidatedAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getHiddenNotValidatedDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getHiddenNotValidatedAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getHiddenNotValidatedDateFormatter
     */
    public java.lang.String getHiddenNotValidated()
    {
        return (hiddenNotValidated == null) ? null : hiddenNotValidatedDateFormatter.format(hiddenNotValidated);
    }

    /**
     * Returns the date formatter used for the <code>hiddenNotValidated</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getHiddenNotValidated
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getHiddenNotValidatedAsDate
     */
    public static java.text.DateFormat getHiddenNotValidatedDateFormatter()
    {
        return ValidationActivityFormImpl.hiddenNotValidatedDateFormatter;
    }

    public java.lang.Object[] getHiddenNotValidatedBackingList()
    {
        java.lang.Object[] values = this.hiddenNotValidatedValueList;
        java.lang.Object[] labels = this.hiddenNotValidatedLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getHiddenNotValidatedValueList()
    {
        return this.hiddenNotValidatedValueList;
    }

    public void setHiddenNotValidatedValueList(java.lang.Object[] hiddenNotValidatedValueList)
    {
        this.hiddenNotValidatedValueList = hiddenNotValidatedValueList;
    }

    public java.lang.Object[] getHiddenNotValidatedLabelList()
    {
        return this.hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedLabelList(java.lang.Object[] hiddenNotValidatedLabelList)
    {
        this.hiddenNotValidatedLabelList = hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setHiddenNotValidatedBackingList requires non-null property arguments");
        }

        this.hiddenNotValidatedValueList = null;
        this.hiddenNotValidatedLabelList = null;

        if (items != null)
        {
            this.hiddenNotValidatedValueList = new java.lang.Object[items.size()];
            this.hiddenNotValidatedLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.hiddenNotValidatedValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hiddenNotValidatedLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setHiddenNotValidatedBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>maxlengthTest</code>.
     */
    public void resetMaxlengthTest()
    {
        this.maxlengthTest = null;
    }

    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }
    
    public java.lang.Object[] getMaxlengthTestBackingList()
    {
        java.lang.Object[] values = this.maxlengthTestValueList;
        java.lang.Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(java.lang.Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public java.lang.Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(java.lang.Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    public void setMaxlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setMaxlengthTestBackingList requires non-null property arguments");
        }

        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;

        if (items != null)
        {
            this.maxlengthTestValueList = new java.lang.Object[items.size()];
            this.maxlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.maxlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.maxlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setMaxlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>patternTest</code>.
     */
    public void resetPatternTest()
    {
        this.patternTest = null;
    }

    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }
    
    public java.lang.Object[] getPatternTestBackingList()
    {
        java.lang.Object[] values = this.patternTestValueList;
        java.lang.Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(java.lang.Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public java.lang.Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(java.lang.Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    public void setPatternTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setPatternTestBackingList requires non-null property arguments");
        }

        this.patternTestValueList = null;
        this.patternTestLabelList = null;

        if (items != null)
        {
            this.patternTestValueList = new java.lang.Object[items.size()];
            this.patternTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.patternTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.patternTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setPatternTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatWrapperRangeTest</code>.
     */
    public void resetFloatWrapperRangeTest()
    {
        this.floatWrapperRangeTest = null;
    }

    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }
    
    public java.lang.Object[] getFloatWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.floatWrapperRangeTestValueList;
        java.lang.Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(java.lang.Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public java.lang.Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(java.lang.Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setFloatWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.floatWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.floatWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.floatWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setFloatWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intWrapperRangeTest</code>.
     */
    public void resetIntWrapperRangeTest()
    {
        this.intWrapperRangeTest = null;
    }

    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }
    
    public java.lang.Object[] getIntWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.intWrapperRangeTestValueList;
        java.lang.Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(java.lang.Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public java.lang.Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(java.lang.Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setIntWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.intWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.intWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.intWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setIntWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>lenientDateTest</code>.
     */
    public void resetLenientDateTest()
    {
        this.lenientDateTest = null;
    }

    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    /**
     * Returns the Date instance representing the <code>lenientDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#lenientDateTestDateFormatter
     */
    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length() == 0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.lenientDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getLenientDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getLenientDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestDateFormatter
     */
    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    /**
     * Returns the date formatter used for the <code>lenientDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestAsDate
     */
    public static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return ValidationActivityFormImpl.lenientDateTestDateFormatter;
    }

    public java.lang.Object[] getLenientDateTestBackingList()
    {
        java.lang.Object[] values = this.lenientDateTestValueList;
        java.lang.Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(java.lang.Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public java.lang.Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(java.lang.Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    public void setLenientDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setLenientDateTestBackingList requires non-null property arguments");
        }

        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;

        if (items != null)
        {
            this.lenientDateTestValueList = new java.lang.Object[items.size()];
            this.lenientDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.lenientDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.lenientDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setLenientDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>urlTest</code>.
     */
    public void resetUrlTest()
    {
        this.urlTest = null;
    }

    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }
    
    public java.lang.Object[] getUrlTestBackingList()
    {
        java.lang.Object[] values = this.urlTestValueList;
        java.lang.Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(java.lang.Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public java.lang.Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(java.lang.Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    public void setUrlTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setUrlTestBackingList requires non-null property arguments");
        }

        this.urlTestValueList = null;
        this.urlTestLabelList = null;

        if (items != null)
        {
            this.urlTestValueList = new java.lang.Object[items.size()];
            this.urlTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.urlTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.urlTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setUrlTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>minlengthTest</code>.
     */
    public void resetMinlengthTest()
    {
        this.minlengthTest = null;
    }

    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }
    
    public java.lang.Object[] getMinlengthTestBackingList()
    {
        java.lang.Object[] values = this.minlengthTestValueList;
        java.lang.Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(java.lang.Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public java.lang.Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(java.lang.Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    public void setMinlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setMinlengthTestBackingList requires non-null property arguments");
        }

        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;

        if (items != null)
        {
            this.minlengthTestValueList = new java.lang.Object[items.size()];
            this.minlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.minlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.minlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setMinlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatRangeTest</code>.
     */
    public void resetFloatRangeTest()
    {
        this.floatRangeTest = 0;
    }

    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }
    
    public java.lang.Object[] getFloatRangeTestBackingList()
    {
        java.lang.Object[] values = this.floatRangeTestValueList;
        java.lang.Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(java.lang.Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public java.lang.Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(java.lang.Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    public void setFloatRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setFloatRangeTestBackingList requires non-null property arguments");
        }

        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;

        if (items != null)
        {
            this.floatRangeTestValueList = new java.lang.Object[items.size()];
            this.floatRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.floatRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setFloatRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleWrapperRangeTest</code>.
     */
    public void resetDoubleWrapperRangeTest()
    {
        this.doubleWrapperRangeTest = null;
    }

    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }
    
    public java.lang.Object[] getDoubleWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.doubleWrapperRangeTestValueList;
        java.lang.Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(java.lang.Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public java.lang.Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(java.lang.Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setDoubleWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.doubleWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setDoubleWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>creditcardTest</code>.
     */
    public void resetCreditcardTest()
    {
        this.creditcardTest = null;
    }

    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }
    
    public java.lang.Object[] getCreditcardTestBackingList()
    {
        java.lang.Object[] values = this.creditcardTestValueList;
        java.lang.Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(java.lang.Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public java.lang.Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(java.lang.Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    public void setCreditcardTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setCreditcardTestBackingList requires non-null property arguments");
        }

        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;

        if (items != null)
        {
            this.creditcardTestValueList = new java.lang.Object[items.size()];
            this.creditcardTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.creditcardTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.creditcardTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setCreditcardTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>strictDateTest</code>.
     */
    public void resetStrictDateTest()
    {
        this.strictDateTest = null;
    }

    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    /**
     * Returns the Date instance representing the <code>strictDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#strictDateTestDateFormatter
     */
    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length() == 0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.strictDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getStrictDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getStrictDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestDateFormatter
     */
    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    /**
     * Returns the date formatter used for the <code>strictDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestAsDate
     */
    public static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return ValidationActivityFormImpl.strictDateTestDateFormatter;
    }

    public java.lang.Object[] getStrictDateTestBackingList()
    {
        java.lang.Object[] values = this.strictDateTestValueList;
        java.lang.Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(java.lang.Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public java.lang.Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(java.lang.Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    public void setStrictDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setStrictDateTestBackingList requires non-null property arguments");
        }

        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;

        if (items != null)
        {
            this.strictDateTestValueList = new java.lang.Object[items.size()];
            this.strictDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.strictDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.strictDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ValidationActivityFormImpl.setStrictDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("minLengthOnPasswordTest", "***");
        builder.append("requiredTest", this.requiredTest);
        builder.append("emailTest", this.emailTest);
        builder.append("intRangeTest", this.intRangeTest);
        builder.append("doubleRangeTest", this.doubleRangeTest);
        builder.append("hiddenNotValidated", this.hiddenNotValidated);
        builder.append("maxlengthTest", this.maxlengthTest);
        builder.append("patternTest", this.patternTest);
        builder.append("floatWrapperRangeTest", this.floatWrapperRangeTest);
        builder.append("intWrapperRangeTest", this.intWrapperRangeTest);
        builder.append("lenientDateTest", this.lenientDateTest);
        builder.append("urlTest", this.urlTest);
        builder.append("minlengthTest", this.minlengthTest);
        builder.append("floatRangeTest", this.floatRangeTest);
        builder.append("doubleWrapperRangeTest", this.doubleWrapperRangeTest);
        builder.append("creditcardTest", this.creditcardTest);
        builder.append("strictDateTest", this.strictDateTest);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.minLengthOnPasswordTest = null;
        this.minLengthOnPasswordTestValueList = null;
        this.minLengthOnPasswordTestLabelList = null;
        this.requiredTest = null;
        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;
        this.emailTest = null;
        this.emailTestValueList = null;
        this.emailTestLabelList = null;
        this.intRangeTest = 0;
        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;
        this.doubleRangeTest = 0;
        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;
        this.hiddenNotValidated = null;
        this.hiddenNotValidatedValueList = null;
        this.hiddenNotValidatedLabelList = null;
        this.maxlengthTest = null;
        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;
        this.patternTest = null;
        this.patternTestValueList = null;
        this.patternTestLabelList = null;
        this.floatWrapperRangeTest = null;
        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;
        this.intWrapperRangeTest = null;
        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;
        this.lenientDateTest = null;
        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;
        this.urlTest = null;
        this.urlTestValueList = null;
        this.urlTestLabelList = null;
        this.minlengthTest = null;
        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;
        this.floatRangeTest = 0;
        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;
        this.doubleWrapperRangeTest = null;
        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;
        this.creditcardTest = null;
        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;
        this.strictDateTest = null;
        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("$action.formKey");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("$action.formKey");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}