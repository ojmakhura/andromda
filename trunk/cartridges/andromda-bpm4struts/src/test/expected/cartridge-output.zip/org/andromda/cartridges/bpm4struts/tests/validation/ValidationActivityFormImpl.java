/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.validation;

public class ValidationActivityFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    private java.lang.String requiredTest;
    private Object[] requiredTestValueList;
    private Object[] requiredTestLabelList;
    private java.lang.String emailTest;
    private Object[] emailTestValueList;
    private Object[] emailTestLabelList;
    private int intRangeTest;
    private Object[] intRangeTestValueList;
    private Object[] intRangeTestLabelList;
    private double doubleRangeTest;
    private Object[] doubleRangeTestValueList;
    private Object[] doubleRangeTestLabelList;
    private java.lang.String maxlengthTest;
    private Object[] maxlengthTestValueList;
    private Object[] maxlengthTestLabelList;
    private java.lang.String patternTest;
    private Object[] patternTestValueList;
    private Object[] patternTestLabelList;
    private java.lang.Float floatWrapperRangeTest;
    private Object[] floatWrapperRangeTestValueList;
    private Object[] floatWrapperRangeTestLabelList;
    private java.lang.Integer intWrapperRangeTest;
    private Object[] intWrapperRangeTestValueList;
    private Object[] intWrapperRangeTestLabelList;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private Object[] lenientDateTestValueList;
    private Object[] lenientDateTestLabelList;
    private java.net.URL urlTest;
    private Object[] urlTestValueList;
    private Object[] urlTestLabelList;
    private java.lang.String minlengthTest;
    private Object[] minlengthTestValueList;
    private Object[] minlengthTestLabelList;
    private float floatRangeTest;
    private Object[] floatRangeTestValueList;
    private Object[] floatRangeTestLabelList;
    private java.lang.Double doubleWrapperRangeTest;
    private Object[] doubleWrapperRangeTestValueList;
    private Object[] doubleWrapperRangeTestLabelList;
    private java.lang.String creditcardTest;
    private Object[] creditcardTestValueList;
    private Object[] creditcardTestLabelList;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] strictDateTestValueList;
    private Object[] strictDateTestLabelList;

    public ValidationActivityFormImpl()
    {
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    /**
     * Resets the given <code>requiredTest</code>.
     */
    public void resetRequiredTest()
    {
        this.requiredTest = null;
    }
    
    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }
    

    public Object[] getRequiredTestBackingList()
    {
        Object[] values = this.requiredTestValueList;
        Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * requiredTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the requiredTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setRequiredTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setRequiredTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setRequiredTestBackingList requires non-null property arguments");
        }

        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;

        if (items != null)
        {
            this.requiredTestValueList = new Object[items.size()];
            this.requiredTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.requiredTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.requiredTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setRequiredTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>emailTest</code>.
     */
    public void resetEmailTest()
    {
        this.emailTest = null;
    }
    
    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }
    

    public Object[] getEmailTestBackingList()
    {
        Object[] values = this.emailTestValueList;
        Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * emailTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the emailTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setEmailTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setEmailTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setEmailTestBackingList requires non-null property arguments");
        }

        this.emailTestValueList = null;
        this.emailTestLabelList = null;

        if (items != null)
        {
            this.emailTestValueList = new Object[items.size()];
            this.emailTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.emailTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.emailTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setEmailTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intRangeTest</code>.
     */
    public void resetIntRangeTest()
    {
        this.intRangeTest = 0;
    }
    
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }
    

    public Object[] getIntRangeTestBackingList()
    {
        Object[] values = this.intRangeTestValueList;
        Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * intRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the intRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setIntRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setIntRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setIntRangeTestBackingList requires non-null property arguments");
        }

        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;

        if (items != null)
        {
            this.intRangeTestValueList = new Object[items.size()];
            this.intRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.intRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setIntRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleRangeTest</code>.
     */
    public void resetDoubleRangeTest()
    {
        this.doubleRangeTest = 0;
    }
    
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }
    

    public Object[] getDoubleRangeTestBackingList()
    {
        Object[] values = this.doubleRangeTestValueList;
        Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * doubleRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the doubleRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDoubleRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDoubleRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setDoubleRangeTestBackingList requires non-null property arguments");
        }

        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleRangeTestValueList = new Object[items.size()];
            this.doubleRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.doubleRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setDoubleRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>maxlengthTest</code>.
     */
    public void resetMaxlengthTest()
    {
        this.maxlengthTest = null;
    }
    
    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }
    

    public Object[] getMaxlengthTestBackingList()
    {
        Object[] values = this.maxlengthTestValueList;
        Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * maxlengthTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the maxlengthTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setMaxlengthTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setMaxlengthTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setMaxlengthTestBackingList requires non-null property arguments");
        }

        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;

        if (items != null)
        {
            this.maxlengthTestValueList = new Object[items.size()];
            this.maxlengthTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.maxlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.maxlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setMaxlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>patternTest</code>.
     */
    public void resetPatternTest()
    {
        this.patternTest = null;
    }
    
    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }
    

    public Object[] getPatternTestBackingList()
    {
        Object[] values = this.patternTestValueList;
        Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * patternTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the patternTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setPatternTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setPatternTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setPatternTestBackingList requires non-null property arguments");
        }

        this.patternTestValueList = null;
        this.patternTestLabelList = null;

        if (items != null)
        {
            this.patternTestValueList = new Object[items.size()];
            this.patternTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.patternTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.patternTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setPatternTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatWrapperRangeTest</code>.
     */
    public void resetFloatWrapperRangeTest()
    {
        this.floatWrapperRangeTest = null;
    }
    
    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }
    

    public Object[] getFloatWrapperRangeTestBackingList()
    {
        Object[] values = this.floatWrapperRangeTestValueList;
        Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * floatWrapperRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the floatWrapperRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setFloatWrapperRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setFloatWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setFloatWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.floatWrapperRangeTestValueList = new Object[items.size()];
            this.floatWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.floatWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setFloatWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>intWrapperRangeTest</code>.
     */
    public void resetIntWrapperRangeTest()
    {
        this.intWrapperRangeTest = null;
    }
    
    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }
    

    public Object[] getIntWrapperRangeTestBackingList()
    {
        Object[] values = this.intWrapperRangeTestValueList;
        Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * intWrapperRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the intWrapperRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setIntWrapperRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setIntWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setIntWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.intWrapperRangeTestValueList = new Object[items.size()];
            this.intWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.intWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.intWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setIntWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>lenientDateTest</code>.
     */
    public void resetLenientDateTest()
    {
        this.lenientDateTest = null;
    }
    
    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    /**
     * Returns the Date instance representing the <code>lenientDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestDateFormatter
     */
    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length()==0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.lenientDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getLenientDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getLenientDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestDateFormatter
     */
    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    /**
     * Returns the date formatter used for the <code>lenientDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getLenientDateTestAsDate
     */
    public final static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return ValidationActivityFormImpl.lenientDateTestDateFormatter;
    }


    public Object[] getLenientDateTestBackingList()
    {
        Object[] values = this.lenientDateTestValueList;
        Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * lenientDateTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the lenientDateTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setLenientDateTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setLenientDateTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setLenientDateTestBackingList requires non-null property arguments");
        }

        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;

        if (items != null)
        {
            this.lenientDateTestValueList = new Object[items.size()];
            this.lenientDateTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.lenientDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.lenientDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setLenientDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>urlTest</code>.
     */
    public void resetUrlTest()
    {
        this.urlTest = null;
    }
    
    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }
    

    public Object[] getUrlTestBackingList()
    {
        Object[] values = this.urlTestValueList;
        Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * urlTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the urlTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setUrlTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setUrlTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setUrlTestBackingList requires non-null property arguments");
        }

        this.urlTestValueList = null;
        this.urlTestLabelList = null;

        if (items != null)
        {
            this.urlTestValueList = new Object[items.size()];
            this.urlTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.urlTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.urlTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setUrlTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>minlengthTest</code>.
     */
    public void resetMinlengthTest()
    {
        this.minlengthTest = null;
    }
    
    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }
    

    public Object[] getMinlengthTestBackingList()
    {
        Object[] values = this.minlengthTestValueList;
        Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * minlengthTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the minlengthTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setMinlengthTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setMinlengthTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setMinlengthTestBackingList requires non-null property arguments");
        }

        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;

        if (items != null)
        {
            this.minlengthTestValueList = new Object[items.size()];
            this.minlengthTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.minlengthTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.minlengthTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setMinlengthTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatRangeTest</code>.
     */
    public void resetFloatRangeTest()
    {
        this.floatRangeTest = 0;
    }
    
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }
    

    public Object[] getFloatRangeTestBackingList()
    {
        Object[] values = this.floatRangeTestValueList;
        Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * floatRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the floatRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setFloatRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setFloatRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setFloatRangeTestBackingList requires non-null property arguments");
        }

        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;

        if (items != null)
        {
            this.floatRangeTestValueList = new Object[items.size()];
            this.floatRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.floatRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setFloatRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>doubleWrapperRangeTest</code>.
     */
    public void resetDoubleWrapperRangeTest()
    {
        this.doubleWrapperRangeTest = null;
    }
    
    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }
    

    public Object[] getDoubleWrapperRangeTestBackingList()
    {
        Object[] values = this.doubleWrapperRangeTestValueList;
        Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * doubleWrapperRangeTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the doubleWrapperRangeTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDoubleWrapperRangeTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDoubleWrapperRangeTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setDoubleWrapperRangeTestBackingList requires non-null property arguments");
        }

        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;

        if (items != null)
        {
            this.doubleWrapperRangeTestValueList = new Object[items.size()];
            this.doubleWrapperRangeTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.doubleWrapperRangeTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.doubleWrapperRangeTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setDoubleWrapperRangeTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>creditcardTest</code>.
     */
    public void resetCreditcardTest()
    {
        this.creditcardTest = null;
    }
    
    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }
    

    public Object[] getCreditcardTestBackingList()
    {
        Object[] values = this.creditcardTestValueList;
        Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * creditcardTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the creditcardTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setCreditcardTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setCreditcardTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setCreditcardTestBackingList requires non-null property arguments");
        }

        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;

        if (items != null)
        {
            this.creditcardTestValueList = new Object[items.size()];
            this.creditcardTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.creditcardTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.creditcardTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setCreditcardTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>strictDateTest</code>.
     */
    public void resetStrictDateTest()
    {
        this.strictDateTest = null;
    }
    
    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    /**
     * Returns the Date instance representing the <code>strictDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestDateFormatter
     */
    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length()==0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.strictDateTest = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getStrictDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getStrictDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestDateFormatter
     */
    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    /**
     * Returns the date formatter used for the <code>strictDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityFormImpl#getStrictDateTestAsDate
     */
    public final static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return ValidationActivityFormImpl.strictDateTestDateFormatter;
    }


    public Object[] getStrictDateTestBackingList()
    {
        Object[] values = this.strictDateTestValueList;
        Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * strictDateTest property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the strictDateTest backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setStrictDateTestBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setStrictDateTestBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ValidationActivityFormImpl.setStrictDateTestBackingList requires non-null property arguments");
        }

        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;

        if (items != null)
        {
            this.strictDateTestValueList = new Object[items.size()];
            this.strictDateTestLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.strictDateTestValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.strictDateTestLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("ValidationActivityFormImpl.setStrictDateTestBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("requiredTest", this.requiredTest);
        builder.append("emailTest", this.emailTest);
        builder.append("intRangeTest", this.intRangeTest);
        builder.append("doubleRangeTest", this.doubleRangeTest);
        builder.append("maxlengthTest", this.maxlengthTest);
        builder.append("patternTest", this.patternTest);
        builder.append("floatWrapperRangeTest", this.floatWrapperRangeTest);
        builder.append("intWrapperRangeTest", this.intWrapperRangeTest);
        builder.append("lenientDateTest", this.lenientDateTest);
        builder.append("urlTest", this.urlTest);
        builder.append("minlengthTest", this.minlengthTest);
        builder.append("floatRangeTest", this.floatRangeTest);
        builder.append("doubleWrapperRangeTest", this.doubleWrapperRangeTest);
        builder.append("creditcardTest", this.creditcardTest);
        builder.append("strictDateTest", this.strictDateTest);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.requiredTest = null;
        this.emailTest = null;
        this.intRangeTest = 0;
        this.doubleRangeTest = 0;
        this.maxlengthTest = null;
        this.patternTest = null;
        this.floatWrapperRangeTest = null;
        this.intWrapperRangeTest = null;
        this.lenientDateTest = null;
        this.urlTest = null;
        this.minlengthTest = null;
        this.floatRangeTest = 0;
        this.doubleWrapperRangeTest = null;
        this.creditcardTest = null;
        this.strictDateTest = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}