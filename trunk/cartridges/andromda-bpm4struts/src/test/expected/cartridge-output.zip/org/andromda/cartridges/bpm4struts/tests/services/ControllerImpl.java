package org.andromda.cartridges.bpm4struts.tests.services;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.services.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#crapmeout(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.services.CrapmeoutForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void crapmeout(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.services.CrapmeoutForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

}
