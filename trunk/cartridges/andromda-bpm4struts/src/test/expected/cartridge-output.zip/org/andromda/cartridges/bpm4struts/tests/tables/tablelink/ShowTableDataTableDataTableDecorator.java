package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;


import javax.servlet.jsp.PageContext;
import javax.servlet.http.HttpServletRequest;

import org.displaytag.decorator.TableDecorator;
import org.apache.commons.beanutils.PropertyUtils;

public class ShowTableDataTableDataTableDecorator extends TableDecorator
{
    // this class uses underscores to avoid naming conflict with user properties

    public String getSecond ()
    {
        try
        {
            final org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm _form = (org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm)getPageContext().getAttribute("tableLinkActivityForm", PageContext.SESSION_SCOPE);

            final Object _row = getCurrentRowObject();
            final StringBuffer _link = new StringBuffer();

            _link.append("<a href=\"");
            _link.append(((HttpServletRequest)getPageContext().getRequest()).getContextPath());
            _link.append("/TableLinkActivity/ShowTableDataAgain.do");
            Object againSecond = PropertyUtils.getProperty(_row, "second");
            if (againSecond != null)
            {
                _link.append("?second=");
                _link.append(againSecond);
            }
            _link.append("\">");
            _link.append(PropertyUtils.getProperty(_row, "second"));
            _link.append("</a>");

            return _link.toString();
        }
        catch (Exception e)
        {
            return e.getMessage();
        }
    }

    public String getThird ()
    {
        try
        {
            final org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm _form = (org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm)getPageContext().getAttribute("tableLinkActivityForm", PageContext.SESSION_SCOPE);

            final Object _row = getCurrentRowObject();
            final StringBuffer _link = new StringBuffer();

            _link.append("<a href=\"");
            _link.append(((HttpServletRequest)getPageContext().getRequest()).getContextPath());
            _link.append("/TableLinkActivity/ShowTableDataAgain2.do");
            Object again2OtherName = PropertyUtils.getProperty(_row, "third");
            if (again2OtherName != null)
            {
                _link.append("&third=");
                _link.append(again2OtherName);
            }
            _link.append("\">");
            _link.append(PropertyUtils.getProperty(_row, "third"));
            _link.append("</a>");

            return _link.toString();
        }
        catch (Exception e)
        {
            return e.getMessage();
        }
    }
}
