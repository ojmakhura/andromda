package org.andromda.cartridges.bpm4struts.tests.constraints.packages.oneusecase;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/UseCase2/UseCase2"
 *        name="useCase2UseCase2ActionForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="use.case2"
 *        path="/UseCase2/UseCase2.do"
 *    redirect="false"
 *
 */
public final class UseCase2 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = nothing(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward nothing(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("use.case2");
    }

}
