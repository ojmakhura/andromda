package org.andromda.cartridges.bpm4struts.tests.exceptions;

/**
 * @struts.form
 *      name="exceptionsActivityExceptionsActivityForm"
 */
public class ExceptionsActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public ExceptionsActivityForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
