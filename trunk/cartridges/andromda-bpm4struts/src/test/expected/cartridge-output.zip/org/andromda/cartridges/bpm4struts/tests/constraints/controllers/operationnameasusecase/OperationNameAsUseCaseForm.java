package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.operationnameasusecase;

public interface OperationNameAsUseCaseForm
{
}
