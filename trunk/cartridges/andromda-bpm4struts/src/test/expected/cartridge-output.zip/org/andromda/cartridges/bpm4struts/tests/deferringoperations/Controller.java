package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 */
public abstract class Controller implements java.io.Serializable
{
    public abstract void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2bForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
    public abstract void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
    public abstract void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State4Trigger4Form form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    public abstract void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2bForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
    public abstract void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception;
    public abstract void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
    public abstract void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State4Trigger4Form form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    public abstract void operation3(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.State2Trigger2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception;

}
