package org.andromda.cartridges.bpm4struts.tests.services;

public interface CrapmeoutForm
{
}
