package org.andromda.cartridges.bpm4struts.tests.reset;

public class ResetForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String firstParam;
    private Object[] firstParamValueList;
    private Object[] firstParamLabelList;

    public ResetForm()
    {
    }

    /**
     * Resets the given <code>firstParam</code>.
     */
    public void resetFirstParam()
    {
        this.firstParam = null;
    }

    public void setFirstParam(java.lang.String firstParam)
    {
        this.firstParam = firstParam;
    }

    /**
     * 
     */
    public java.lang.String getFirstParam()
    {
        return this.firstParam;
    }

    public Object[] getFirstParamBackingList()
    {
        Object[] values = this.firstParamValueList;
        Object[] labels = this.firstParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFirstParamValueList()
    {
        return this.firstParamValueList;
    }

    public void setFirstParamValueList(Object[] firstParamValueList)
    {
        this.firstParamValueList = firstParamValueList;
    }

    public Object[] getFirstParamLabelList()
    {
        return this.firstParamLabelList;
    }

    public void setFirstParamLabelList(Object[] firstParamLabelList)
    {
        this.firstParamLabelList = firstParamLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("firstParam=");
        buffer.append(String.valueOf(this.getFirstParam()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.firstParam = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}