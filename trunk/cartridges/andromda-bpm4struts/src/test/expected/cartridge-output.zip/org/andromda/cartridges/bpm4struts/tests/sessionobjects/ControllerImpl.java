package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void someOperation(ActionMapping mapping, ControllerSomeOperation form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

}
