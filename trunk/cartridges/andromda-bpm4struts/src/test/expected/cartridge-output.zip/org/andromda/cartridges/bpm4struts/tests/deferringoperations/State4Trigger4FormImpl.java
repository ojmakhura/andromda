/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State4Trigger4FormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation1Form
        , org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation2Form
        , org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm
        , org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestMissingArgumentFieldForm
{
    private int param4;
    private java.lang.Object[] param4ValueList;
    private java.lang.Object[] param4LabelList;
    private java.lang.String testParam;
    private java.lang.Object[] testParamValueList;
    private java.lang.Object[] testParamLabelList;
    private java.lang.String param2a;
    private java.lang.Object[] param2aValueList;
    private java.lang.Object[] param2aLabelList;
    private java.lang.String pageVariable;
    private java.lang.Object[] pageVariableValueList;
    private java.lang.Object[] pageVariableLabelList;
    private java.lang.String testParam2;
    private java.lang.Object[] testParam2ValueList;
    private java.lang.Object[] testParam2LabelList;

    public State4Trigger4FormImpl()
    {
    }

    /**
     * Resets the given <code>param4</code>.
     */
    public void resetParam4()
    {
        this.param4 = 0;
    }

    public void setParam4(int param4)
    {
        this.param4 = param4;
    }

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }
    
    public java.lang.Object[] getParam4BackingList()
    {
        java.lang.Object[] values = this.param4ValueList;
        java.lang.Object[] labels = this.param4LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getParam4ValueList()
    {
        return this.param4ValueList;
    }

    public void setParam4ValueList(java.lang.Object[] param4ValueList)
    {
        this.param4ValueList = param4ValueList;
    }

    public java.lang.Object[] getParam4LabelList()
    {
        return this.param4LabelList;
    }

    public void setParam4LabelList(java.lang.Object[] param4LabelList)
    {
        this.param4LabelList = param4LabelList;
    }

    public void setParam4BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4Trigger4FormImpl.setParam4BackingList requires non-null property arguments");
        }

        this.param4ValueList = null;
        this.param4LabelList = null;

        if (items != null)
        {
            this.param4ValueList = new java.lang.Object[items.size()];
            this.param4LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.param4ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.param4LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("State4Trigger4FormImpl.setParam4BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>testParam</code>.
     */
    public void resetTestParam()
    {
        this.testParam = null;
    }

    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
    }

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }
    
    public java.lang.Object[] getTestParamBackingList()
    {
        java.lang.Object[] values = this.testParamValueList;
        java.lang.Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(java.lang.Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public java.lang.Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(java.lang.Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    public void setTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4Trigger4FormImpl.setTestParamBackingList requires non-null property arguments");
        }

        this.testParamValueList = null;
        this.testParamLabelList = null;

        if (items != null)
        {
            this.testParamValueList = new java.lang.Object[items.size()];
            this.testParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.testParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.testParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("State4Trigger4FormImpl.setTestParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>param2a</code>.
     */
    public void resetParam2a()
    {
        this.param2a = null;
    }

    public void setParam2a(java.lang.String param2a)
    {
        this.param2a = param2a;
    }

    /**
     * 
     */
    public java.lang.String getParam2a()
    {
        return this.param2a;
    }
    
    public java.lang.Object[] getParam2aBackingList()
    {
        java.lang.Object[] values = this.param2aValueList;
        java.lang.Object[] labels = this.param2aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getParam2aValueList()
    {
        return this.param2aValueList;
    }

    public void setParam2aValueList(java.lang.Object[] param2aValueList)
    {
        this.param2aValueList = param2aValueList;
    }

    public java.lang.Object[] getParam2aLabelList()
    {
        return this.param2aLabelList;
    }

    public void setParam2aLabelList(java.lang.Object[] param2aLabelList)
    {
        this.param2aLabelList = param2aLabelList;
    }

    public void setParam2aBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4Trigger4FormImpl.setParam2aBackingList requires non-null property arguments");
        }

        this.param2aValueList = null;
        this.param2aLabelList = null;

        if (items != null)
        {
            this.param2aValueList = new java.lang.Object[items.size()];
            this.param2aLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.param2aValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.param2aLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("State4Trigger4FormImpl.setParam2aBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>pageVariable</code>.
     */
    public void resetPageVariable()
    {
        this.pageVariable = null;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    /**
     * 
     */
    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }
    
    public java.lang.Object[] getPageVariableBackingList()
    {
        java.lang.Object[] values = this.pageVariableValueList;
        java.lang.Object[] labels = this.pageVariableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getPageVariableValueList()
    {
        return this.pageVariableValueList;
    }

    public void setPageVariableValueList(java.lang.Object[] pageVariableValueList)
    {
        this.pageVariableValueList = pageVariableValueList;
    }

    public java.lang.Object[] getPageVariableLabelList()
    {
        return this.pageVariableLabelList;
    }

    public void setPageVariableLabelList(java.lang.Object[] pageVariableLabelList)
    {
        this.pageVariableLabelList = pageVariableLabelList;
    }

    public void setPageVariableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4Trigger4FormImpl.setPageVariableBackingList requires non-null property arguments");
        }

        this.pageVariableValueList = null;
        this.pageVariableLabelList = null;

        if (items != null)
        {
            this.pageVariableValueList = new java.lang.Object[items.size()];
            this.pageVariableLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.pageVariableValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.pageVariableLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("State4Trigger4FormImpl.setPageVariableBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>testParam2</code>.
     */
    public void resetTestParam2()
    {
        this.testParam2 = null;
    }

    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
    }

    /**
     * 
     */
    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }
    
    public java.lang.Object[] getTestParam2BackingList()
    {
        java.lang.Object[] values = this.testParam2ValueList;
        java.lang.Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(java.lang.Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public java.lang.Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(java.lang.Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    public void setTestParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4Trigger4FormImpl.setTestParam2BackingList requires non-null property arguments");
        }

        this.testParam2ValueList = null;
        this.testParam2LabelList = null;

        if (items != null)
        {
            this.testParam2ValueList = new java.lang.Object[items.size()];
            this.testParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.testParam2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.testParam2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("State4Trigger4FormImpl.setTestParam2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.testParam2 = null;
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("param4", this.param4);
        builder.append("testParam", this.testParam);
        builder.append("param2a", this.param2a);
        builder.append("pageVariable", this.pageVariable);
        builder.append("testParam2", this.testParam2);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.param4 = 0;
        this.param4ValueList = null;
        this.param4LabelList = null;
        this.testParam = null;
        this.testParamValueList = null;
        this.testParamLabelList = null;
        this.param2a = null;
        this.param2aValueList = null;
        this.param2aLabelList = null;
        this.pageVariable = null;
        this.pageVariableValueList = null;
        this.pageVariableLabelList = null;
        this.testParam2 = null;
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}