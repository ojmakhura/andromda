package org.andromda.cartridges.bpm4struts.tests.constraints.packages.oneusecase;

/**
 * @struts.form
 *      name="oneUseCaseUseCase1OneUseCaseUseCase1Form"
 */
public class OneUseCaseUseCase1Form
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public OneUseCaseUseCase1Form()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
