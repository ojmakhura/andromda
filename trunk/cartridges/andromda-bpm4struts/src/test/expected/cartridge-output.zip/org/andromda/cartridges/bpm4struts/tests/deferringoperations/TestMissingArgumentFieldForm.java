package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public interface TestMissingArgumentFieldForm
{
    public void setThisArgumentIsMissingFromTheActionForm(java.lang.String thisArgumentIsMissingFromTheActionForm);
    public java.lang.String getThisArgumentIsMissingFromTheActionForm();

}
