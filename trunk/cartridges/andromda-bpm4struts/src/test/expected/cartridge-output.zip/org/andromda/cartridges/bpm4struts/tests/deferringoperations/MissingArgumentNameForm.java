package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public interface MissingArgumentNameForm
{
    public void setnull(java.lang.String $fieldName);
    public java.lang.String getnull();
    public void reset();

}
