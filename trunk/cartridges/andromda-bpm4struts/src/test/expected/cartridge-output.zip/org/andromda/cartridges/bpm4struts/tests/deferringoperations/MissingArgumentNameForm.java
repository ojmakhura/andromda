package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>missingArgumentName</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 *  This operation exists to test that parameters must have a
 *  non-empty name.
 * </p>
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#missingArgumentName
 */
public interface MissingArgumentNameForm
{
    /**
     * Sets the <code>$field.name</code> field.
     *
     * 
     */
    public void setnull(java.lang.String $fieldName);
    
    /**
     * Gets the <code>$field.name</code> field.
     *
     * 
     */
    public java.lang.String getnull();
    
    /**
     * Resets the <code>$field.name</code> field.
     */
    public void reset();

}
