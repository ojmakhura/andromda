package org.andromda.cartridges.bpm4struts.tests.exceptions;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="exceptionsActivityExceptionsActivityActionForm"
 */
public class ExceptionsActivityActionForm extends ValidatorForm implements Serializable
    
{

    public ExceptionsActivityActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
