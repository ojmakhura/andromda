package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 */
public abstract class Controller implements java.io.Serializable
{
    public abstract void loadTableData(ActionMapping mapping, LoadTableDataForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

}
