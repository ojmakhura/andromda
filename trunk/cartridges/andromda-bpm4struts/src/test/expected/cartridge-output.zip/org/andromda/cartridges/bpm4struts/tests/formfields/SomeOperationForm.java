package org.andromda.cartridges.bpm4struts.tests.formfields;

public interface SomeOperationForm
{
    public void setDateAsDate(java.util.Date date);
    public java.util.Date getDateAsDate();

    public void setDate(java.lang.String date);
    public java.lang.String getDate();

    public void setNumber(int number);
    public int getNumber();

    public void setCollection(java.util.Collection collection);
    public java.util.Collection getCollection();

    public void setCollectionAsArray(Object[] collection);
    public Object[] getCollectionAsArray();

    public Object[] getCollectionBackingList();
    public Object[] getCollectionValueList();
    public void setCollectionValueList(Object[] collectionValueList);
    public Object[] getCollectionLabelList();
    public void setCollectionLabelList(Object[] collectionLabelList);

    public void setSelectable(java.lang.String selectable);
    public java.lang.String getSelectable();

    public Object[] getSelectableBackingList();
    public Object[] getSelectableValueList();
    public void setSelectableValueList(Object[] selectableValueList);
    public Object[] getSelectableLabelList();
    public void setSelectableLabelList(Object[] selectableLabelList);

}
