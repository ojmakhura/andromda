/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>someOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.formfields.Controller#someOperation
 */
public interface SomeOperationForm
{
    /**
     * Sets the <code>file</code> Struts FormFile field to the specified value.
     *
     * 
     */
    public void setFile(org.apache.struts.upload.FormFile file);


    /**
     * Gets the <code>file</code> Struts FormFile field value.
     *
     * 
     */
    public org.apache.struts.upload.FormFile getFile();

    /**
     * Resets the <code>file</code> field.
     */
    public void resetFile();

    /**
     * This field is a date type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setDate(java.lang.String)
     */
    public void setDateAsDate(java.util.Date date);

    /**
     * This field is a date type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getDate()
     */
    public java.util.Date getDateAsDate();

    /**
     * This field is a date type, and this method allows you to set it into the form as a String.
     *
     * 
     *
     * @see #setDate#sDate(java.util.Date)
     */
    public void setDate(java.lang.String date);

    /**
     * This field is a date type, and this method allows you to get it from the form as a String.
     *
     * 
     *
     * @see #getDate#sDate()
     */
    public java.lang.String getDate();

    /**
     * Resets the <code>date</code> field.
     */
    public void resetDate();

    /**
     * Sets the <code>bool</code> field.
     *
     * 
     */
    public void setBool(boolean bool);

    /**
     * Gets the <code>bool</code> field.
     *
     * 
     */
    public boolean isBool();
    
    /**
     * Resets the <code>bool</code> field.
     */
    public void resetBool();

    /**
     * This field is a collection type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setSetClass#sArray(Object[])
     */
    public void setSetClass(java.util.Set setClass);

    /**
     * This field is a collection type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getSetClass#sArray()
     */
    public java.util.Set getSetClass();

    /**
     * This field is a collection type, and this method allows you to set it as an
     * array into the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #setSetClass(java.util.Set)
     */
    public void setSetClassAsArray(Object[] setClass);

    /**
     * This field is a collection type, and this method allows you to get it as an
     * array from the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #getSetClass()
     */
    public java.lang.Object[] getSetClassAsArray();

    /**
     * Resets the <code>setClass</code> field.
     */
    public void resetSetClass();

    /**
     * The <code>setClass</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getSetClass()
     * @see #getSetClassValueList()
     * @see #getSetClassLabelList()
     * @see #setSetClassLabelList(java.util.Collection,java.lang.String,java.lang.String)
     */
    public java.lang.Object[] getSetClassBackingList();

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * setClass property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the setClass backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSetClassBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or
     *         if the caller does not have access one of the object's properties, if an exception was thrown while
     *         accessing a property or if the property does not exist on at least one of the items
     *
     * @see #getSetClass()
     * @see #getSetClassValueList()
     * @see #getSetClassLabelList()
     * @see #getSetClassLabelList()
     */
    public void setSetClassBackingList(java.util.Collection items, String valueProperty, String labelProperty);

    /**
     * The <code>setClass</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getSetClass()
     * @see #getSetClassBackingList()
     */
    public java.lang.Object[] getSetClassValueList();

    /**
     * The <code>setClass</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getSetClass()
     * @see #getSetClassBackingList()
     */
    public void setSetClassValueList(java.lang.Object[] setClassValueList);

    /**
     * The <code>setClass</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getSetClass()
     * @see #getSetClassBackingList()
     */
    public java.lang.Object[] getSetClassLabelList();

    /**
     * The <code>setClass</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getSetClass()
     * @see #getSetClassBackingList()
     */
    public void setSetClassLabelList(java.lang.Object[] setClassLabelList);

    /**
     * Sets the <code>selectable</code> field.
     *
     * 
     */
    public void setSelectable(java.lang.String selectable);

    /**
     * Gets the <code>selectable</code> field.
     *
     * 
     */
    public java.lang.String getSelectable();
    
    /**
     * Resets the <code>selectable</code> field.
     */
    public void resetSelectable();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     * @see #setSelectableLabelList(java.util.Collection,java.lang.String,java.lang.String)
     */
    public java.lang.Object[] getSelectableBackingList();

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * selectable property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the selectable backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSelectableBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or
     *         if the caller does not have access one of the object's properties, if an exception was thrown while
     *         accessing a property or if the property does not exist on at least one of the items
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     * @see #getSelectableLabelList()
     */
    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty);

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public java.lang.Object[] getSelectableValueList();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableValueList(java.lang.Object[] selectableValueList);

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public java.lang.Object[] getSelectableLabelList();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableLabelList(java.lang.Object[] selectableLabelList);

    /**
     * Sets the <code>booleanClass</code> field.
     *
     * 
     */
    public void setBooleanClass(java.lang.Boolean booleanClass);

    /**
     * Gets the <code>booleanClass</code> field.
     *
     * 
     */
    public java.lang.Boolean getBooleanClass();
    
    /**
     * Resets the <code>booleanClass</code> field.
     */
    public void resetBooleanClass();

    /**
     * Sets the argument value for the specified key into the <code>mapClass</code> Map.
     *
     * 
     *
     * @see #setMapClass(java.util.Map)
     */
    public void setMapClassValue(java.lang.String key, java.lang.Object value);

    /**
     * Gets the argument value for the specified key from the <code>mapClass</code> Map.
     *
     * 
     *
     * @see #getMapClass()
     */
    public java.lang.Object getMapClassValue(java.lang.String key);

    /**
     * Sets the <code>mapClass</code> Map to the specified value.
     *
     * 
     *
     * @see #setMapClass#alue(java.lang.String key, java.lang.Object value)
     */
    public void setMapClass(java.util.Map mapClass);

    /**
     * Gets the <code>mapClass</code> Map.
     *
     * 
     *
     * @see #getMapClass#alue(java.lang.String)
     */
    public java.util.Map getMapClass();

    /**
     * Resets the <code>mapClass</code> field.
     */
    public void resetMapClass();

    /**
     * Sets the <code>floatClass</code> field.
     *
     * 
     */
    public void setFloatClass(java.lang.Float floatClass);

    /**
     * Gets the <code>floatClass</code> field.
     *
     * 
     */
    public java.lang.Float getFloatClass();
    
    /**
     * Resets the <code>floatClass</code> field.
     */
    public void resetFloatClass();

    /**
     * This field is a collection type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setCollection#sArray(Object[])
     */
    public void setCollection(java.util.Collection collection);

    /**
     * This field is a collection type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getCollection#sArray()
     */
    public java.util.Collection getCollection();

    /**
     * This field is a collection type, and this method allows you to set it as an
     * array into the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #setCollection(java.util.Collection)
     */
    public void setCollectionAsArray(Object[] collection);

    /**
     * This field is a collection type, and this method allows you to get it as an
     * array from the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #getCollection()
     */
    public java.lang.Object[] getCollectionAsArray();

    /**
     * Resets the <code>collection</code> field.
     */
    public void resetCollection();

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getCollection()
     * @see #getCollectionValueList()
     * @see #getCollectionLabelList()
     * @see #setCollectionLabelList(java.util.Collection,java.lang.String,java.lang.String)
     */
    public java.lang.Object[] getCollectionBackingList();

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * collection property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the collection backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setCollectionBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or
     *         if the caller does not have access one of the object's properties, if an exception was thrown while
     *         accessing a property or if the property does not exist on at least one of the items
     *
     * @see #getCollection()
     * @see #getCollectionValueList()
     * @see #getCollectionLabelList()
     * @see #getCollectionLabelList()
     */
    public void setCollectionBackingList(java.util.Collection items, String valueProperty, String labelProperty);

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public java.lang.Object[] getCollectionValueList();

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public void setCollectionValueList(java.lang.Object[] collectionValueList);

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public java.lang.Object[] getCollectionLabelList();

    /**
     * The <code>collection</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getCollection()
     * @see #getCollectionBackingList()
     */
    public void setCollectionLabelList(java.lang.Object[] collectionLabelList);

    /**
     * Sets the <code>integerClass</code> field.
     *
     * 
     */
    public void setIntegerClass(java.lang.Integer integerClass);

    /**
     * Gets the <code>integerClass</code> field.
     *
     * 
     */
    public java.lang.Integer getIntegerClass();
    
    /**
     * Resets the <code>integerClass</code> field.
     */
    public void resetIntegerClass();

    /**
     * Sets the <code>number</code> field.
     *
     * 
     */
    public void setNumber(int number);

    /**
     * Gets the <code>number</code> field.
     *
     * 
     */
    public int getNumber();
    
    /**
     * Resets the <code>number</code> field.
     */
    public void resetNumber();

}
