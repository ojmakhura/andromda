package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

public interface LoadTableDataForm
{
    public java.util.Collection getTableData();
    public void setTableData(java.util.Collection tableData);

}