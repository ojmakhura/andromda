package org.andromda.cartridges.bpm4struts.tests.constraints.packages.oneusecase;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/UseCase1/UseCase1"
 *        name="useCase1UseCase1ActionForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="use.case1"
 *        path="/UseCase1/UseCase1.do"
 *    redirect="false"
 *
 */
public final class UseCase1 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = nothing(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward nothing(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return mapping.findForward("use.case1");
    }

}
