package org.andromda.cartridges.bpm4struts.tests.reset;

public class ResetPageSendWithResetForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , SomeOperationForm
{
    private java.lang.String firstParam;

    public ResetPageSendWithResetForm()
    {
    }

    public void setFirstParam(java.lang.String firstParam)
    {
        this.firstParam = firstParam;
    }

    /**
     * 
     */
    public java.lang.String getFirstParam()
    {
        return this.firstParam;
    }
    
    /**
     * Resets the given <code>firstParam</code>.
     */
    public void resetFirstParam()
    {
        this.firstParam = null;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("firstParam=");
        buffer.append(String.valueOf(this.getFirstParam()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.firstParam = null;
    }

}
