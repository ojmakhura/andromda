package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames;

public interface DuplicateNameForm
{
    public void setDiffParam(java.lang.String diffParam);
    public java.lang.String getDiffParam();
    public void resetDiffParam();

}
