package org.andromda.cartridges.bpm4struts.tests.widgets;

public class ShowWidgetsSubmitForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String textAreaTest;
    private java.lang.String radioButtonsTest3;
    private java.lang.String radioButtonsTest;
    private boolean checkboxTest;
    private java.lang.String textFieldTest2;
    private java.lang.String selectTest;
    private Object[] selectTestValueList;
    private Object[] selectTestLabelList;
    private java.lang.String textFieldTest;
    private java.lang.String hiddenTest;
    private java.lang.String passwordFieldTest;
    private java.lang.String radioButtonsTest2;

    public ShowWidgetsSubmitForm()
    {
    }

    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
    }

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }
    
    /**
     * Resets the given <code>textAreaTest</code>.
     */
    public void resetTextAreaTest()
    {
        this.textAreaTest = null;
    }

    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }
    
    /**
     * Resets the given <code>radioButtonsTest3</code>.
     */
    public void resetRadioButtonsTest3()
    {
        this.radioButtonsTest3 = null;
    }

    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }
    
    /**
     * Resets the given <code>radioButtonsTest</code>.
     */
    public void resetRadioButtonsTest()
    {
        this.radioButtonsTest = null;
    }

    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
    }

    /**
     * 
     */
    public boolean getCheckboxTest()
    {
        return this.checkboxTest;
    }
    
    /**
     * Resets the given <code>checkboxTest</code>.
     */
    public void resetCheckboxTest()
    {
        this.checkboxTest = false;
    }

    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }
    
    /**
     * Resets the given <code>textFieldTest2</code>.
     */
    public void resetTextFieldTest2()
    {
        this.textFieldTest2 = null;
    }

    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
    }

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }
    
    /**
     * Resets the given <code>selectTest</code>.
     */
    public void resetSelectTest()
    {
        this.selectTest = null;
    }

    public Object[] getSelectTestBackingList()
    {
        Object[] values = this.selectTestValueList;
        Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }
    
    /**
     * Resets the given <code>textFieldTest</code>.
     */
    public void resetTextFieldTest()
    {
        this.textFieldTest = null;
    }

    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
    }

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }
    
    /**
     * Resets the given <code>hiddenTest</code>.
     */
    public void resetHiddenTest()
    {
        this.hiddenTest = null;
    }

    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
    }

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }
    
    /**
     * Resets the given <code>passwordFieldTest</code>.
     */
    public void resetPasswordFieldTest()
    {
        this.passwordFieldTest = null;
    }

    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
    }

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }
    
    /**
     * Resets the given <code>radioButtonsTest2</code>.
     */
    public void resetRadioButtonsTest2()
    {
        this.radioButtonsTest2 = null;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.checkboxTest = false;
        this.selectTest = null;
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("textAreaTest=");
        buffer.append(String.valueOf(this.getTextAreaTest()));
        buffer.append(",radioButtonsTest3=");
        buffer.append(String.valueOf(this.getRadioButtonsTest3()));
        buffer.append(",radioButtonsTest=");
        buffer.append(String.valueOf(this.getRadioButtonsTest()));
        buffer.append(",checkboxTest=");
        buffer.append(String.valueOf(this.getCheckboxTest()));
        buffer.append(",textFieldTest2=");
        buffer.append(String.valueOf(this.getTextFieldTest2()));
        buffer.append(",selectTest=");
        buffer.append(String.valueOf(this.getSelectTest()));
        buffer.append(",textFieldTest=");
        buffer.append(String.valueOf(this.getTextFieldTest()));
        buffer.append(",hiddenTest=");
        buffer.append(String.valueOf(this.getHiddenTest()));
        buffer.append(",passwordFieldTest=");
        buffer.append(String.valueOf(this.getPasswordFieldTest()));
        buffer.append(",radioButtonsTest2=");
        buffer.append(String.valueOf(this.getRadioButtonsTest2()));

        return buffer.append("]").toString();
    }

    /**
     * Helper method to convert an array to a String.
     */
    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.textAreaTest = null;
        this.radioButtonsTest3 = null;
        this.radioButtonsTest = null;
        this.checkboxTest = false;
        this.textFieldTest2 = null;
        this.selectTest = null;
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        this.textFieldTest = null;
        this.hiddenTest = null;
        this.passwordFieldTest = null;
        this.radioButtonsTest2 = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}
