/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.badtarget;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>thisOperationReturnsSomething</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.constraints.decisions.badtarget.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.decisions.badtarget.Controller#thisOperationReturnsSomething
 */
public interface ThisOperationReturnsSomethingForm
{
}
