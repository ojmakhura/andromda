package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public interface DeferringOperationsForm
{
    public void setTestParam2(java.lang.String testParam2);
    public java.lang.String getTestParam2();
    public void resetTestParam2();

}
