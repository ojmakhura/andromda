package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * @struts.form
 *      name="deferringOperationsDeferringOperationsForm"
 */
public class DeferringOperationsForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String trigger2TestParam;
    private java.lang.String trigger2bTestParam;
    private java.lang.String pageVariable;
    private java.lang.String trigger2bParam2a;
    private int trigger2bTestParam2;

    public DeferringOperationsForm()
    {
    }

    public void setTrigger2TestParam(java.lang.String trigger2TestParam)
    {
        this.trigger2TestParam = trigger2TestParam;
    }

    public java.lang.String getTrigger2TestParam()
    {
        return this.trigger2TestParam;
    }

    public void setTrigger2bTestParam(java.lang.String trigger2bTestParam)
    {
        this.trigger2bTestParam = trigger2bTestParam;
    }

    public java.lang.String getTrigger2bTestParam()
    {
        return this.trigger2bTestParam;
    }

    public void setPageVariable(java.lang.String pageVariable)
    {
        this.pageVariable = pageVariable;
    }

    public java.lang.String getPageVariable()
    {
        return this.pageVariable;
    }

    public void setTrigger2bParam2a(java.lang.String trigger2bParam2a)
    {
        this.trigger2bParam2a = trigger2bParam2a;
    }

    public java.lang.String getTrigger2bParam2a()
    {
        return this.trigger2bParam2a;
    }

    public void setTrigger2bTestParam2(int trigger2bTestParam2)
    {
        this.trigger2bTestParam2 = trigger2bTestParam2;
    }

    public int getTrigger2bTestParam2()
    {
        return this.trigger2bTestParam2;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("trigger2TestParam=");
        buffer.append(String.valueOf(this.getTrigger2TestParam()));
        buffer.append(",trigger2bTestParam=");
        buffer.append(String.valueOf(this.getTrigger2bTestParam()));
        buffer.append(",pageVariable=");
        buffer.append(String.valueOf(this.getPageVariable()));
        buffer.append(",trigger2bParam2a=");
        buffer.append(String.valueOf(this.getTrigger2bParam2a()));
        buffer.append(",trigger2bTestParam2=");
        buffer.append(String.valueOf(this.getTrigger2bTestParam2()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.trigger2TestParam = null;
        this.trigger2bTestParam = null;
        this.pageVariable = null;
        this.trigger2bParam2a = null;
        this.trigger2bTestParam2 = 0;
    }

}
