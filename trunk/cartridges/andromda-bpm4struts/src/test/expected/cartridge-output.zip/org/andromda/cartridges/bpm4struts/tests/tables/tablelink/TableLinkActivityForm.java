package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class TableLinkActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , LoadTableDataForm
{
    private java.lang.String tableMultibox;
    private Object[] tableMultiboxValueList;
    private Object[] tableMultiboxLabelList;
    private java.lang.String tableTextField;
    private Object[] tableTextFieldValueList;
    private Object[] tableTextFieldLabelList;
    private java.lang.String[] multiboxThing;
    private Object[] multiboxThingValueList;
    private Object[] multiboxThingLabelList;
    private java.util.Collection tableData;
    private Object[] tableDataValueList;
    private Object[] tableDataLabelList;
    private java.lang.String second;
    private Object[] secondValueList;
    private Object[] secondLabelList;

    public TableLinkActivityForm()
    {
    }

    /**
     * Resets the given <code>tableMultibox</code>.
     */
    public void resetTableMultibox()
    {
        this.tableMultibox = null;
    }

    public void setTableMultibox(java.lang.String tableMultibox)
    {
        this.tableMultibox = tableMultibox;
    }

    /**
     * 
     */
    public java.lang.String getTableMultibox()
    {
        return this.tableMultibox;
    }

    public Object[] getTableMultiboxBackingList()
    {
        Object[] values = this.tableMultiboxValueList;
        Object[] labels = this.tableMultiboxLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableMultiboxValueList()
    {
        return this.tableMultiboxValueList;
    }

    public void setTableMultiboxValueList(Object[] tableMultiboxValueList)
    {
        this.tableMultiboxValueList = tableMultiboxValueList;
    }

    public Object[] getTableMultiboxLabelList()
    {
        return this.tableMultiboxLabelList;
    }

    public void setTableMultiboxLabelList(Object[] tableMultiboxLabelList)
    {
        this.tableMultiboxLabelList = tableMultiboxLabelList;
    }

    /**
     * Resets the given <code>tableTextField</code>.
     */
    public void resetTableTextField()
    {
        this.tableTextField = null;
    }

    public void setTableTextField(java.lang.String tableTextField)
    {
        this.tableTextField = tableTextField;
    }

    /**
     * 
     */
    public java.lang.String getTableTextField()
    {
        return this.tableTextField;
    }

    public Object[] getTableTextFieldBackingList()
    {
        Object[] values = this.tableTextFieldValueList;
        Object[] labels = this.tableTextFieldLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableTextFieldValueList()
    {
        return this.tableTextFieldValueList;
    }

    public void setTableTextFieldValueList(Object[] tableTextFieldValueList)
    {
        this.tableTextFieldValueList = tableTextFieldValueList;
    }

    public Object[] getTableTextFieldLabelList()
    {
        return this.tableTextFieldLabelList;
    }

    public void setTableTextFieldLabelList(Object[] tableTextFieldLabelList)
    {
        this.tableTextFieldLabelList = tableTextFieldLabelList;
    }

    /**
     * Resets the given <code>multiboxThing</code>.
     */
    public void resetMultiboxThing()
    {
        this.multiboxThing = null;
    }

    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
    }

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }

    public Object[] getMultiboxThingBackingList()
    {
        Object[] values = this.multiboxThingValueList;
        Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = null;
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.TableLinkActivityForm#getTableData
     */
    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    

    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }

    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }

    public Object[] getSecondBackingList()
    {
        Object[] values = this.secondValueList;
        Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.multiboxThing = null;
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("tableMultibox=");
        buffer.append(String.valueOf(this.getTableMultibox()));
        buffer.append(",tableTextField=");
        buffer.append(String.valueOf(this.getTableTextField()));
        buffer.append(",multiboxThing=");
        buffer.append(toString(this.getMultiboxThing()));
        buffer.append(",tableData=");
        buffer.append(toString(this.getTableData()));
        buffer.append(",second=");
        buffer.append(String.valueOf(this.getSecond()));

        return buffer.append("]").toString();
    }

    /**
     * Helper method to convert a collection to a String.
     */
    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    /**
     * Helper method to convert an array to a String.
     */
    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableMultibox = null;
        this.tableTextField = null;
        this.multiboxThing = null;
        this.tableData = null;
        this.second = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}