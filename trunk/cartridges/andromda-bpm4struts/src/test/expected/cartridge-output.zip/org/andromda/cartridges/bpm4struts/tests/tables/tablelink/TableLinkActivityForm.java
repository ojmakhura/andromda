package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * @struts.form
 *      name="tableLinkActivityTableLinkActivityForm"
 */
public class TableLinkActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String againSecond;
    private java.lang.String again2OtherName;
    private java.util.Collection tableData;

    public TableLinkActivityForm()
    {
    }

    public void setAgainSecond(java.lang.String againSecond)
    {
        this.againSecond = againSecond;
    }

    public java.lang.String getAgainSecond()
    {
        return this.againSecond;
    }

    public void setAgain2OtherName(java.lang.String again2OtherName)
    {
        this.again2OtherName = again2OtherName;
    }

    public java.lang.String getAgain2OtherName()
    {
        return this.again2OtherName;
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("againSecond=");
        buffer.append(String.valueOf(this.getAgainSecond()));
        buffer.append(",again2OtherName=");
        buffer.append(String.valueOf(this.getAgain2OtherName()));
        buffer.append(",tableData=");
        buffer.append(toString(this.getTableData()));

        return buffer.append("]").toString();
    }

    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    public void clean()
    {
        this.againSecond = null;
        this.again2OtherName = null;
        this.tableData = null;
    }

}
