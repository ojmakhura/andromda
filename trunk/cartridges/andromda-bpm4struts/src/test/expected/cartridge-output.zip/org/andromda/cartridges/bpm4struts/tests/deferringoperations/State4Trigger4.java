package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class State4Trigger4 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _state5(mapping, form, request, response);
        if (this.errorsNotPresent(request))
        {
            request.getSession().setAttribute("form", form);       
        }
        return forward;
    }

    /**
     * 
     */
    private ActionForward _state1(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;

        final org.apache.struts.action.ActionMessages errors = this.getExceptionHandlerErrors(request);
        try
        {
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().operation1(mapping, (State4Trigger4Form)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().operation2(mapping, (State4Trigger4Form)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                forward = mapping.findForward("state2");
            }
        }
        catch (Exception ex)
        {
            final String messageKey = org.andromda.presentation.bpm4struts.PatternMatchingExceptionHandler.instance().handleException(ex);
            errors.add(org.apache.struts.action.ActionMessages.GLOBAL_MESSAGE, new org.apache.struts.action.ActionMessage(messageKey));
        }
        finally
        {
        }
        if (!errors.isEmpty())
        {
            forward = mapping.getInputForward();
        }
        return forward;
    }

    /**
     * 
     */
    private ActionForward _state5(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;

        final org.apache.struts.action.ActionMessages errors = this.getExceptionHandlerErrors(request);
        try
        {
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().deferringOperations(mapping, (State4Trigger4Form)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().testMissingArgumentField(mapping, (State4Trigger4Form)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                forward = _state1(mapping, form, request, response);
            }
        }
        catch (Exception ex)
        {
            final String messageKey = org.andromda.presentation.bpm4struts.PatternMatchingExceptionHandler.instance().handleException(ex);
            errors.add(org.apache.struts.action.ActionMessages.GLOBAL_MESSAGE, new org.apache.struts.action.ActionMessage(messageKey));
        }
        finally
        {
        }
        if (!errors.isEmpty())
        {
            forward = mapping.getInputForward();
        }
        return forward;
    }


    /**
     * Returns true if <strong>NO</strong> errors
     * are present in the request.  This includes default validation
     * errors produced by the struts framework and the exception 
     * handler errors caught by the pattern matching 
     * exception handler.
     * 
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(HttpServletRequest request)
    {
        return this.getExceptionHandlerErrors(request).isEmpty() &&
        	(this.getErrors(request) == null || this.getErrors(request).isEmpty());
    }

    /**
     * <p>
     *  Retrieves the exception handler messages (if any).  Creates a new
     *  ActionMessages instance and returns that if one doesn't already exist.
     * </p>
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors = 
            (org.apache.struts.action.ActionMessages)request.getAttribute(
                "org.andromda.bpm4struts.errormessages");
        if (errors == null)
        {
            errors = new org.apache.struts.action.ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", errors);
        }
        return errors;
    }
}
