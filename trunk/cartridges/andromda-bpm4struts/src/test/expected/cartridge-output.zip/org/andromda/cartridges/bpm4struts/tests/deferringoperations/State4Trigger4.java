package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/DeferringOperations/State4Trigger4"
 *        name="deferringOperationsState4Trigger4Form"
 *       input="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state4.jsp"
 *    validate="true"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="state2"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state2.jsp"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="deferring.operations.state4.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/deferringoperations/state4.jsp"
 *       scope="request"
 *
 */
public final class State4Trigger4 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = _state1(mapping, form, request, response);

        return forward;
    }

    /**
     * 
     */
    private ActionForward _state1(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().operation1(mapping, (State4Trigger4Form)form, request, response);
        ControllerFactory.getControllerInstance().operation2(mapping, (State4Trigger4Form)form, request, response);
        return mapping.findForward("state2");
    }

}
