package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class State4Trigger4 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("form", form);
        final ActionForward forward = _state5(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private ActionForward _state5(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().deferringOperations(mapping, (State4Trigger4Form)form, request, response);
        ControllerFactory.getControllerInstance().testMissingArgumentField(mapping, (State4Trigger4Form)form, request, response);
        return _state1(mapping, form, request, response);
    }

    /**
     * 
     */
    private ActionForward _state1(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ControllerFactory.getControllerInstance().operation1(mapping, (State4Trigger4Form)form, request, response);
        ControllerFactory.getControllerInstance().operation2(mapping, (State4Trigger4Form)form, request, response);
        return mapping.findForward("state2");
    }

}
