package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public interface ControllerLoadTableData
{
    public java.lang.String getAgainSecond();
    public void setAgainSecond(java.lang.String againSecond);

    public java.lang.String getAgain2OtherName();
    public void setAgain2OtherName(java.lang.String again2OtherName);

    public java.util.Collection getTableData();
    public void setTableData(java.util.Collection tableData);

}