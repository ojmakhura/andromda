package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , LoadTableDataForm
{
    private java.util.Collection tableData;

    public ShowTableDataAgainForm()
    {
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.notablelink.ShowTableDataAgainForm#getTableData
     */
    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    
    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = new java.util.ArrayList();
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("tableData=");
        buffer.append(toString(this.getTableData()));

        return buffer.append("]").toString();
    }

    /**
     * Helper method to convert a collection to a String.
     */
    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    /**
     * Helper method to convert an array to a String.
     */
    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableData = null;
    }

}
