package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

/**
 * @struts.form
 *      name="noTableLinkActivityShowTableDataAgainForm"
 */
public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public ShowTableDataAgainForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
