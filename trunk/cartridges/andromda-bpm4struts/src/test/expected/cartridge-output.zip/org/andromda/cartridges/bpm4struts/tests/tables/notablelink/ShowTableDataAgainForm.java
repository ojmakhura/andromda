/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , LoadTableDataForm
{

    private java.util.Collection tableData;
    private Object[] tableDataValueList;
    private Object[] tableDataLabelList;

    public ShowTableDataAgainForm()
    {
    }

    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = null;
    }
    
    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.notablelink.ShowTableDataAgainForm#getTableData
     */
    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    

    public Object[] getTableDataBackingList()
    {
        Object[] values = this.tableDataValueList;
        Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("tableData", this.tableData);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.tableData = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     * 
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    { 
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }
}