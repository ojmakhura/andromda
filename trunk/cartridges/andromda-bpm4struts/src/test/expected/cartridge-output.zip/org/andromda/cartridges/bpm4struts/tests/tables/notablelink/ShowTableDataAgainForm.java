package org.andromda.cartridges.bpm4struts.tests.tables.notablelink;

/**
 * @struts.form
 *      name="noTableLinkActivityShowTableDataAgainForm"
 */
public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , LoadTableDataForm
{
    private java.util.Collection tableData;

    public ShowTableDataAgainForm()
    {
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    public Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("tableData=");
        buffer.append(toString(this.getTableData()));

        return buffer.append("]").toString();
    }

    private final static String toString(java.util.Collection objects)
    {
        return (objects==null) ? null : toString(objects.toArray());
    }

    private final static String toString(Object[] objects)
    {
        if (objects == null)
        {
            return null;
        }
        final StringBuffer buffer = new StringBuffer("[");
        String prefix = "";
        for (int i=0; i<objects.length; i++)
        {
            buffer.append(prefix);
            buffer.append(objects[i]);
            prefix = ",";
        }
        return buffer.append("]").toString();
    }

    public void clean()
    {
        this.tableData = null;
    }

}
