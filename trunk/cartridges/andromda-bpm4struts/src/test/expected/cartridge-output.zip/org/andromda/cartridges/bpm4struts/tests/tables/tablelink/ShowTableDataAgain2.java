package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/TableLinkActivity/ShowTableDataAgain2"
 *        name="tableLinkActivityForm"
 *       input="/org/andromda/cartridges/bpm4struts/tests/tables/tablelink/show-table-data.jsp"
 *    validate="false"
 *       scope="session"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="again2"
 *        path="/TableLinkActivity/TableLinkActivity.do"
 *    redirect="false"
 *
 * @struts.action-exception
 *         key="table.link.activity.show.table.data.exception"
 *        type="java.lang.Exception"
 *        path="/org/andromda/cartridges/bpm4struts/tests/tables/tablelink/show-table-data.jsp"
 *       scope="request"
 *
 */
public final class ShowTableDataAgain2 extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final ActionForward forward = mapping.findForward("again2");

        setLastBreadCrumb(request, "table.link.activity.title");

        return forward;
    }

    private void setLastBreadCrumb(HttpServletRequest request, String message)
    {
        if (message == null)
        {
            return;
        }

        HttpSession session = request.getSession(true);
        Object breadCrumbsObject = session.getAttribute("org.andromda.bpm4struts.breadcrumbs");

        if (breadCrumbsObject instanceof LinkedHashMap)
        {
            Map breadCrumbMap = (Map)breadCrumbsObject;

            StringBuffer buffer = request.getRequestURL();
            if (request.getQueryString()!=null)
            {
                buffer.append(request.getQueryString());
                buffer.append("&");
            }
            else
            {
                buffer.append("?");
            }
            buffer.append("__bc=1");
            breadCrumbMap.put(message, buffer.toString());
        }
        else
        {
            session.setAttribute("org.andromda.bpm4struts.breadcrumbs", new LinkedHashMap());
        }
    }
}
