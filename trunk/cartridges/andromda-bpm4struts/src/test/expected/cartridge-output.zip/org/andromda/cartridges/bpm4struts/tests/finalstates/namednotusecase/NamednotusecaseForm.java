package org.andromda.cartridges.bpm4struts.tests.finalstates.namednotusecase;

/**
 * @struts.form
 *      name="namednotusecaseNamednotusecaseForm"
 */
public class NamednotusecaseForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{

    public NamednotusecaseForm()
    {
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
