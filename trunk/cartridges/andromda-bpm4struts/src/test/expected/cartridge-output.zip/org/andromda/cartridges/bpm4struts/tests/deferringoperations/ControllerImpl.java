/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation1(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation1Form, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void operation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation1Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation2(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation2Form, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void operation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setTestParam2((int)1624306807);
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#operation3(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation3Form, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void operation3(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.Operation3Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#deferringOperations(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void deferringOperations(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.DeferringOperationsForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setTestParam2("testParam2-test");
        form.setTestParam2ValueList(new Object[] {"testParam2-1", "testParam2-2", "testParam2-3", "testParam2-4", "testParam2-5"});
        form.setTestParam2LabelList(form.getTestParam2ValueList());
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#testMissingArgumentField(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestMissingArgumentFieldForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void testMissingArgumentField(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestMissingArgumentFieldForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setThisArgumentIsMissingFromTheActionForm("thisArgumentIsMissingFromTheActionForm-test");
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#missingArgumentName(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.MissingArgumentNameForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void missingArgumentName(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.MissingArgumentNameForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.set("-test");
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#testPageToPage(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestPageToPageForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final boolean testPageToPage(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.deferringoperations.TestPageToPageForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setDecisionTestParam((int)-395774305);
        return false;
    }

}