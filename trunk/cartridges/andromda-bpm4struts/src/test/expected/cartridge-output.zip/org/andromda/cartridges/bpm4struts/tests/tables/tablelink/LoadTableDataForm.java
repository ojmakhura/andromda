package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public interface LoadTableDataForm
{
    public void setTableData(java.util.Collection tableData);
    public java.util.Collection getTableData();

    public void setTableDataAsArray(Object[] tableData);
    public Object[] getTableDataAsArray();
    public void resetTableData();

    public void setMultiboxThing(java.lang.String[] multiboxThing);
    public java.lang.String[] getMultiboxThing();
    public void resetMultiboxThing();

}
