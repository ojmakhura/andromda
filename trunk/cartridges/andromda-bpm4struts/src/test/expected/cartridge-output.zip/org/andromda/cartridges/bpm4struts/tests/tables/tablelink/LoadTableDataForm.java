package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public interface LoadTableDataForm
{
}
