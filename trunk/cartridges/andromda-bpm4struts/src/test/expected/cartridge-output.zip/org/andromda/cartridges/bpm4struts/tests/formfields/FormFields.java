package org.andromda.cartridges.bpm4struts.tests.formfields;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 *
 * @struts.action
 *        path="/FormFields/FormFields"
 *        name="formFieldsFormFieldsForm"
 *    validate="false"
 *       scope="request"
 *     unknown="false"
 *
 * @struts.action-forward
 *        name="one"
 *        path="/org/andromda/cartridges/bpm4struts/tests/formfields/one.jsp"
 *    redirect="false"
 *
 */
public final class FormFields extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.setAttribute("form", form);
        final ActionForward forward = mapping.findForward("one");
        return forward;
    }

}
