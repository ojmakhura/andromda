/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formfields;

public class FormFieldsFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 21197069381L;

    private java.lang.String title;
    private java.lang.Object[] titleValueList;
    private java.lang.Object[] titleLabelList;
    private java.util.Date time;
    private final static java.text.DateFormat timeTimeFormatter = new java.text.SimpleDateFormat("HH:mm");
    private java.lang.Object[] timeValueList;
    private java.lang.Object[] timeLabelList;
    private org.apache.struts.upload.FormFile file = null;
    private java.lang.Object[] fileValueList;
    private java.lang.Object[] fileLabelList;
    private java.lang.String hasCustomValidator;
    private java.lang.Object[] hasCustomValidatorValueList;
    private java.lang.Object[] hasCustomValidatorLabelList;
    private java.lang.String bAdName;
    private java.lang.Object[] bAdNameValueList;
    private java.lang.Object[] bAdNameLabelList;
    private java.lang.String multiFormat;
    private java.lang.Object[] multiFormatValueList;
    private java.lang.Object[] multiFormatLabelList;
    private java.util.Date date;
    private final static java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private java.lang.Object[] dateValueList;
    private java.lang.Object[] dateLabelList;
    private boolean bool;
    private java.lang.Object[] boolValueList;
    private java.lang.Object[] boolLabelList;
    private java.util.Set setClass;
    private java.lang.Object[] setClassValueList;
    private java.lang.Object[] setClassLabelList;
    private java.lang.String selectable;
    private java.lang.Object[] selectableValueList;
    private java.lang.Object[] selectableLabelList;
    private java.lang.Boolean booleanClass;
    private java.lang.Object[] booleanClassValueList;
    private java.lang.Object[] booleanClassLabelList;
    private java.lang.String text;
    private java.lang.Object[] textValueList;
    private java.lang.Object[] textLabelList;
    private java.util.Map mapClass = new java.util.HashMap();
    private java.lang.Object[] mapClassValueList;
    private java.lang.Object[] mapClassLabelList;
    private java.util.Collection multiSelect;
    private java.lang.Object[] multiSelectValueList;
    private java.lang.Object[] multiSelectLabelList;
    private java.util.Date dateWithoutCalendar;
    private final static java.text.DateFormat dateWithoutCalendarDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private java.lang.Object[] dateWithoutCalendarValueList;
    private java.lang.Object[] dateWithoutCalendarLabelList;
    private java.util.Date dateWithTime;
    private final static java.text.DateFormat dateWithTimeDateFormatter = new java.text.SimpleDateFormat("dddd/MM/yyyy HH:mm:ss");
    private java.lang.Object[] dateWithTimeValueList;
    private java.lang.Object[] dateWithTimeLabelList;
    private java.lang.String hiddenWithDefaultValue;
    private java.lang.Object[] hiddenWithDefaultValueValueList;
    private java.lang.Object[] hiddenWithDefaultValueLabelList;
    private java.lang.Float floatClass;
    private java.lang.Object[] floatClassValueList;
    private java.lang.Object[] floatClassLabelList;
    private java.util.Collection collection;
    private java.lang.Object[] collectionValueList;
    private java.lang.Object[] collectionLabelList;
    private java.lang.Integer integerClass;
    private java.lang.Object[] integerClassValueList;
    private java.lang.Object[] integerClassLabelList;
    private int number;
    private java.lang.Object[] numberValueList;
    private java.lang.Object[] numberLabelList;

    public FormFieldsFormImpl()
    {
        dateDateFormatter.setLenient(true);
        dateWithoutCalendarDateFormatter.setLenient(true);
        dateWithTimeDateFormatter.setLenient(true);
    }

    /**
     * Resets the given <code>title</code>.
     */
    public void resetTitle()
    {
        this.title = null;
    }

    public void setTitle(java.lang.String title)
    {
        this.title = title;
    }

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public java.lang.String getTitle()
    {
        return this.title;
    }
    
    public java.lang.Object[] getTitleBackingList()
    {
        java.lang.Object[] values = this.titleValueList;
        java.lang.Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(java.lang.Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public java.lang.Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(java.lang.Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    public void setTitleBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTitleBackingList requires non-null property arguments");
        }

        this.titleValueList = null;
        this.titleLabelList = null;

        if (items != null)
        {
            this.titleValueList = new java.lang.Object[items.size()];
            this.titleLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.titleValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.titleLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setTitleBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>time</code>.
     */
    public void resetTime()
    {
        this.time = null;
    }

    public void setTimeAsTime(java.util.Date time)
    {
        this.time = time;
    }

    /**
     * Returns the Date instance representing the <code>time</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#timeTimeFormatter
     */
    public java.util.Date getTimeAsTime()
    {
        return this.time;
    }

    public void setTime(java.lang.String time)
    {
        if (time == null || time.trim().length() == 0)
        {
            this.time = null;
        }
        else
        {
            try
            {
                this.time = timeTimeFormatter.parse(time);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.time = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getTimeAsTime()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getTimeTimeFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getTimeAsTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getTimeTimeFormatter
     */
    public java.lang.String getTime()
    {
        return (time == null) ? null : timeTimeFormatter.format(time);
    }

    /**
     * Returns the date formatter used for the <code>time</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getTimeAsTime
     */
    public static java.text.DateFormat getTimeTimeFormatter()
    {
        return FormFieldsFormImpl.timeTimeFormatter;
    }

    public java.lang.Object[] getTimeBackingList()
    {
        java.lang.Object[] values = this.timeValueList;
        java.lang.Object[] labels = this.timeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTimeValueList()
    {
        return this.timeValueList;
    }

    public void setTimeValueList(java.lang.Object[] timeValueList)
    {
        this.timeValueList = timeValueList;
    }

    public java.lang.Object[] getTimeLabelList()
    {
        return this.timeLabelList;
    }

    public void setTimeLabelList(java.lang.Object[] timeLabelList)
    {
        this.timeLabelList = timeLabelList;
    }

    public void setTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTimeBackingList requires non-null property arguments");
        }

        this.timeValueList = null;
        this.timeLabelList = null;

        if (items != null)
        {
            this.timeValueList = new java.lang.Object[items.size()];
            this.timeLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.timeValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.timeLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setTimeBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>file</code>.
     */
    public void resetFile()
    {
        this.file = null;
    }

    public void setFile(org.apache.struts.upload.FormFile file)
    {
        this.file = file;
    }

    /**
     * 
     */
    public org.apache.struts.upload.FormFile getFile()
    {
        return this.file;
    }
    public java.lang.Object[] getFileBackingList()
    {
        java.lang.Object[] values = this.fileValueList;
        java.lang.Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(java.lang.Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public java.lang.Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(java.lang.Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    public void setFileBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setFileBackingList requires non-null property arguments");
        }

        this.fileValueList = null;
        this.fileLabelList = null;

        if (items != null)
        {
            this.fileValueList = new java.lang.Object[items.size()];
            this.fileLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.fileValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fileLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setFileBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hasCustomValidator</code>.
     */
    public void resetHasCustomValidator()
    {
        this.hasCustomValidator = null;
    }

    public void setHasCustomValidator(java.lang.String hasCustomValidator)
    {
        this.hasCustomValidator = hasCustomValidator;
    }

    /**
     * 
     */
    public java.lang.String getHasCustomValidator()
    {
        return this.hasCustomValidator;
    }
    
    public java.lang.Object[] getHasCustomValidatorBackingList()
    {
        java.lang.Object[] values = this.hasCustomValidatorValueList;
        java.lang.Object[] labels = this.hasCustomValidatorLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getHasCustomValidatorValueList()
    {
        return this.hasCustomValidatorValueList;
    }

    public void setHasCustomValidatorValueList(java.lang.Object[] hasCustomValidatorValueList)
    {
        this.hasCustomValidatorValueList = hasCustomValidatorValueList;
    }

    public java.lang.Object[] getHasCustomValidatorLabelList()
    {
        return this.hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorLabelList(java.lang.Object[] hasCustomValidatorLabelList)
    {
        this.hasCustomValidatorLabelList = hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setHasCustomValidatorBackingList requires non-null property arguments");
        }

        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;

        if (items != null)
        {
            this.hasCustomValidatorValueList = new java.lang.Object[items.size()];
            this.hasCustomValidatorLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.hasCustomValidatorValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hasCustomValidatorLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setHasCustomValidatorBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>bAdName</code>.
     */
    public void resetBAdName()
    {
        this.bAdName = null;
    }

    public void setBAdName(java.lang.String bAdName)
    {
        this.bAdName = bAdName;
    }

    /**
     * 
     */
    public java.lang.String getBAdName()
    {
        return this.bAdName;
    }
    
    public java.lang.Object[] getBAdNameBackingList()
    {
        java.lang.Object[] values = this.bAdNameValueList;
        java.lang.Object[] labels = this.bAdNameLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getBAdNameValueList()
    {
        return this.bAdNameValueList;
    }

    public void setBAdNameValueList(java.lang.Object[] bAdNameValueList)
    {
        this.bAdNameValueList = bAdNameValueList;
    }

    public java.lang.Object[] getBAdNameLabelList()
    {
        return this.bAdNameLabelList;
    }

    public void setBAdNameLabelList(java.lang.Object[] bAdNameLabelList)
    {
        this.bAdNameLabelList = bAdNameLabelList;
    }

    public void setBAdNameBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBAdNameBackingList requires non-null property arguments");
        }

        this.bAdNameValueList = null;
        this.bAdNameLabelList = null;

        if (items != null)
        {
            this.bAdNameValueList = new java.lang.Object[items.size()];
            this.bAdNameLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.bAdNameValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.bAdNameLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setBAdNameBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiFormat</code>.
     */
    public void resetMultiFormat()
    {
        this.multiFormat = null;
    }

    public void setMultiFormat(java.lang.String multiFormat)
    {
        this.multiFormat = multiFormat;
    }

    /**
     * 
     */
    public java.lang.String getMultiFormat()
    {
        return this.multiFormat;
    }
    
    public java.lang.Object[] getMultiFormatBackingList()
    {
        java.lang.Object[] values = this.multiFormatValueList;
        java.lang.Object[] labels = this.multiFormatLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMultiFormatValueList()
    {
        return this.multiFormatValueList;
    }

    public void setMultiFormatValueList(java.lang.Object[] multiFormatValueList)
    {
        this.multiFormatValueList = multiFormatValueList;
    }

    public java.lang.Object[] getMultiFormatLabelList()
    {
        return this.multiFormatLabelList;
    }

    public void setMultiFormatLabelList(java.lang.Object[] multiFormatLabelList)
    {
        this.multiFormatLabelList = multiFormatLabelList;
    }

    public void setMultiFormatBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMultiFormatBackingList requires non-null property arguments");
        }

        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;

        if (items != null)
        {
            this.multiFormatValueList = new java.lang.Object[items.size()];
            this.multiFormatLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.multiFormatValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiFormatLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setMultiFormatBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>date</code>.
     */
    public void resetDate()
    {
        this.date = null;
    }

    public void setDateAsDate(java.util.Date date)
    {
        this.date = date;
    }

    /**
     * Returns the Date instance representing the <code>date</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#dateDateFormatter
     */
    public java.util.Date getDateAsDate()
    {
        return this.date;
    }

    public void setDate(java.lang.String date)
    {
        if (date == null || date.trim().length() == 0)
        {
            this.date = null;
        }
        else
        {
            try
            {
                this.date = dateDateFormatter.parse(date);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.date = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateDateFormatter
     */
    public java.lang.String getDate()
    {
        return (date == null) ? null : dateDateFormatter.format(date);
    }

    /**
     * Returns the date formatter used for the <code>date</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateAsDate
     */
    public static java.text.DateFormat getDateDateFormatter()
    {
        return FormFieldsFormImpl.dateDateFormatter;
    }

    public java.lang.Object[] getDateBackingList()
    {
        java.lang.Object[] values = this.dateValueList;
        java.lang.Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(java.lang.Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public java.lang.Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(java.lang.Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    public void setDateBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateBackingList requires non-null property arguments");
        }

        this.dateValueList = null;
        this.dateLabelList = null;

        if (items != null)
        {
            this.dateValueList = new java.lang.Object[items.size()];
            this.dateLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.dateValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setDateBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>bool</code>.
     */
    public void resetBool()
    {
        this.bool = false;
    }

    public void setBool(boolean bool)
    {
        this.bool = bool;
    }

    /**
     * 
     */
    public boolean isBool()
    {
        return this.bool;
    }
    
    public java.lang.Object[] getBoolBackingList()
    {
        java.lang.Object[] values = this.boolValueList;
        java.lang.Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(java.lang.Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public java.lang.Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(java.lang.Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    public void setBoolBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBoolBackingList requires non-null property arguments");
        }

        this.boolValueList = null;
        this.boolLabelList = null;

        if (items != null)
        {
            this.boolValueList = new java.lang.Object[items.size()];
            this.boolLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.boolValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.boolLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setBoolBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>setClass</code>.
     */
    public void resetSetClass()
    {
        this.setClass = null;
    }

    public void setSetClass(java.util.Set setClass)
    {
        this.setClass = setClass;
    }

    /**
     * 
     */
    public java.util.Set getSetClass()
    {
        return this.setClass;
    }

    public void setSetClassAsArray(Object[] setClass)
    {
        this.setClass = (setClass == null) ? null : java.util.Arrays.asList(setClass);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getSetClass
     */
    public java.lang.Object[] getSetClassAsArray()
    {
        return (setClass == null) ? null : setClass.toArray();
    }
    
    public java.lang.Object[] getSetClassBackingList()
    {
        java.lang.Object[] values = this.setClassValueList;
        java.lang.Object[] labels = this.setClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSetClassValueList()
    {
        return this.setClassValueList;
    }

    public void setSetClassValueList(java.lang.Object[] setClassValueList)
    {
        this.setClassValueList = setClassValueList;
    }

    public java.lang.Object[] getSetClassLabelList()
    {
        return this.setClassLabelList;
    }

    public void setSetClassLabelList(java.lang.Object[] setClassLabelList)
    {
        this.setClassLabelList = setClassLabelList;
    }

    public void setSetClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setSetClassBackingList requires non-null property arguments");
        }

        this.setClassValueList = null;
        this.setClassLabelList = null;

        if (items != null)
        {
            this.setClassValueList = new java.lang.Object[items.size()];
            this.setClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.setClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.setClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setSetClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>selectable</code>.
     */
    public void resetSelectable()
    {
        this.selectable = null;
    }

    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
    }

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }
    
    public java.lang.Object[] getSelectableBackingList()
    {
        java.lang.Object[] values = this.selectableValueList;
        java.lang.Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(java.lang.Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public java.lang.Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(java.lang.Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    public void setSelectableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setSelectableBackingList requires non-null property arguments");
        }

        this.selectableValueList = null;
        this.selectableLabelList = null;

        if (items != null)
        {
            this.selectableValueList = new java.lang.Object[items.size()];
            this.selectableLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.selectableValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.selectableLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setSelectableBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>booleanClass</code>.
     */
    public void resetBooleanClass()
    {
        this.booleanClass = null;
    }

    public void setBooleanClass(java.lang.Boolean booleanClass)
    {
        this.booleanClass = booleanClass;
    }

    /**
     * 
     */
    public java.lang.Boolean getBooleanClass()
    {
        return this.booleanClass;
    }
    
    public java.lang.Object[] getBooleanClassBackingList()
    {
        java.lang.Object[] values = this.booleanClassValueList;
        java.lang.Object[] labels = this.booleanClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getBooleanClassValueList()
    {
        return this.booleanClassValueList;
    }

    public void setBooleanClassValueList(java.lang.Object[] booleanClassValueList)
    {
        this.booleanClassValueList = booleanClassValueList;
    }

    public java.lang.Object[] getBooleanClassLabelList()
    {
        return this.booleanClassLabelList;
    }

    public void setBooleanClassLabelList(java.lang.Object[] booleanClassLabelList)
    {
        this.booleanClassLabelList = booleanClassLabelList;
    }

    public void setBooleanClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBooleanClassBackingList requires non-null property arguments");
        }

        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;

        if (items != null)
        {
            this.booleanClassValueList = new java.lang.Object[items.size()];
            this.booleanClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.booleanClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.booleanClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setBooleanClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>text</code>.
     */
    public void resetText()
    {
        this.text = null;
    }

    public void setText(java.lang.String text)
    {
        this.text = text;
    }

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }
    
    public java.lang.Object[] getTextBackingList()
    {
        java.lang.Object[] values = this.textValueList;
        java.lang.Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(java.lang.Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public java.lang.Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(java.lang.Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    public void setTextBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTextBackingList requires non-null property arguments");
        }

        this.textValueList = null;
        this.textLabelList = null;

        if (items != null)
        {
            this.textValueList = new java.lang.Object[items.size()];
            this.textLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.textValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.textLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setTextBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>mapClass</code>.
     */
    public void resetMapClass()
    {
        this.mapClass.clear();
    }
	public void setMapClassValue(java.lang.String key, java.lang.Object value) 
	{
		this.mapClass.put(key, value);
	}

	public java.lang.Object getMapClassValue(String key) 
	{
		return mapClass.get(key);
	}
	
    public void setMapClass(java.util.Map mapClass)
    {
        this.mapClass = mapClass;
    }

    /**
     * 
     */
    public java.util.Map getMapClass()
    {
        return this.mapClass;
    }

    public java.lang.Object[] getMapClassBackingList()
    {
        java.lang.Object[] values = this.mapClassValueList;
        java.lang.Object[] labels = this.mapClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMapClassValueList()
    {
        return this.mapClassValueList;
    }

    public void setMapClassValueList(java.lang.Object[] mapClassValueList)
    {
        this.mapClassValueList = mapClassValueList;
    }

    public java.lang.Object[] getMapClassLabelList()
    {
        return this.mapClassLabelList;
    }

    public void setMapClassLabelList(java.lang.Object[] mapClassLabelList)
    {
        this.mapClassLabelList = mapClassLabelList;
    }

    public void setMapClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMapClassBackingList requires non-null property arguments");
        }

        this.mapClassValueList = null;
        this.mapClassLabelList = null;

        if (items != null)
        {
            this.mapClassValueList = new java.lang.Object[items.size()];
            this.mapClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.mapClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.mapClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setMapClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiSelect</code>.
     */
    public void resetMultiSelect()
    {
        this.multiSelect = null;
    }

    public void setMultiSelect(java.util.Collection multiSelect)
    {
        this.multiSelect = multiSelect;
    }

    /**
     * 
     */
    public java.util.Collection getMultiSelect()
    {
        return this.multiSelect;
    }

    public void setMultiSelectAsArray(Object[] multiSelect)
    {
        this.multiSelect = (multiSelect == null) ? null : java.util.Arrays.asList(multiSelect);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getMultiSelect
     */
    public java.lang.Object[] getMultiSelectAsArray()
    {
        return (multiSelect == null) ? null : multiSelect.toArray();
    }
    
    public java.lang.Object[] getMultiSelectBackingList()
    {
        java.lang.Object[] values = this.multiSelectValueList;
        java.lang.Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(java.lang.Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public java.lang.Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(java.lang.Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    public void setMultiSelectBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMultiSelectBackingList requires non-null property arguments");
        }

        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;

        if (items != null)
        {
            this.multiSelectValueList = new java.lang.Object[items.size()];
            this.multiSelectLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.multiSelectValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiSelectLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setMultiSelectBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>dateWithoutCalendar</code>.
     */
    public void resetDateWithoutCalendar()
    {
        this.dateWithoutCalendar = null;
    }

    public void setDateWithoutCalendarAsDate(java.util.Date dateWithoutCalendar)
    {
        this.dateWithoutCalendar = dateWithoutCalendar;
    }

    /**
     * Returns the Date instance representing the <code>dateWithoutCalendar</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithoutCalendar
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#dateWithoutCalendarDateFormatter
     */
    public java.util.Date getDateWithoutCalendarAsDate()
    {
        return this.dateWithoutCalendar;
    }

    public void setDateWithoutCalendar(java.lang.String dateWithoutCalendar)
    {
        if (dateWithoutCalendar == null || dateWithoutCalendar.trim().length() == 0)
        {
            this.dateWithoutCalendar = null;
        }
        else
        {
            try
            {
                this.dateWithoutCalendar = dateWithoutCalendarDateFormatter.parse(dateWithoutCalendar);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.dateWithoutCalendar = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateWithoutCalendarAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateWithoutCalendarDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithoutCalendarAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithoutCalendarDateFormatter
     */
    public java.lang.String getDateWithoutCalendar()
    {
        return (dateWithoutCalendar == null) ? null : dateWithoutCalendarDateFormatter.format(dateWithoutCalendar);
    }

    /**
     * Returns the date formatter used for the <code>dateWithoutCalendar</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithoutCalendar
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithoutCalendarAsDate
     */
    public static java.text.DateFormat getDateWithoutCalendarDateFormatter()
    {
        return FormFieldsFormImpl.dateWithoutCalendarDateFormatter;
    }

    public java.lang.Object[] getDateWithoutCalendarBackingList()
    {
        java.lang.Object[] values = this.dateWithoutCalendarValueList;
        java.lang.Object[] labels = this.dateWithoutCalendarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getDateWithoutCalendarValueList()
    {
        return this.dateWithoutCalendarValueList;
    }

    public void setDateWithoutCalendarValueList(java.lang.Object[] dateWithoutCalendarValueList)
    {
        this.dateWithoutCalendarValueList = dateWithoutCalendarValueList;
    }

    public java.lang.Object[] getDateWithoutCalendarLabelList()
    {
        return this.dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarLabelList(java.lang.Object[] dateWithoutCalendarLabelList)
    {
        this.dateWithoutCalendarLabelList = dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateWithoutCalendarBackingList requires non-null property arguments");
        }

        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;

        if (items != null)
        {
            this.dateWithoutCalendarValueList = new java.lang.Object[items.size()];
            this.dateWithoutCalendarLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.dateWithoutCalendarValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateWithoutCalendarLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setDateWithoutCalendarBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>dateWithTime</code>.
     */
    public void resetDateWithTime()
    {
        this.dateWithTime = null;
    }

    public void setDateWithTimeAsDate(java.util.Date dateWithTime)
    {
        this.dateWithTime = dateWithTime;
    }

    /**
     * Returns the Date instance representing the <code>dateWithTime</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#dateWithTimeDateFormatter
     */
    public java.util.Date getDateWithTimeAsDate()
    {
        return this.dateWithTime;
    }

    public void setDateWithTime(java.lang.String dateWithTime)
    {
        if (dateWithTime == null || dateWithTime.trim().length() == 0)
        {
            this.dateWithTime = null;
        }
        else
        {
            try
            {
                this.dateWithTime = dateWithTimeDateFormatter.parse(dateWithTime);
            }
            catch(java.text.ParseException e)
            {
                // we are not throwing an exception, let the validator handle these cases
                this.dateWithTime = null;
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getDateWithTimeAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getDateWithTimeDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithTimeAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithTimeDateFormatter
     */
    public java.lang.String getDateWithTime()
    {
        return (dateWithTime == null) ? null : dateWithTimeDateFormatter.format(dateWithTime);
    }

    /**
     * Returns the date formatter used for the <code>dateWithTime</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithTime
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getDateWithTimeAsDate
     */
    public static java.text.DateFormat getDateWithTimeDateFormatter()
    {
        return FormFieldsFormImpl.dateWithTimeDateFormatter;
    }

    public java.lang.Object[] getDateWithTimeBackingList()
    {
        java.lang.Object[] values = this.dateWithTimeValueList;
        java.lang.Object[] labels = this.dateWithTimeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getDateWithTimeValueList()
    {
        return this.dateWithTimeValueList;
    }

    public void setDateWithTimeValueList(java.lang.Object[] dateWithTimeValueList)
    {
        this.dateWithTimeValueList = dateWithTimeValueList;
    }

    public java.lang.Object[] getDateWithTimeLabelList()
    {
        return this.dateWithTimeLabelList;
    }

    public void setDateWithTimeLabelList(java.lang.Object[] dateWithTimeLabelList)
    {
        this.dateWithTimeLabelList = dateWithTimeLabelList;
    }

    public void setDateWithTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateWithTimeBackingList requires non-null property arguments");
        }

        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;

        if (items != null)
        {
            this.dateWithTimeValueList = new java.lang.Object[items.size()];
            this.dateWithTimeLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.dateWithTimeValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.dateWithTimeLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setDateWithTimeBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>hiddenWithDefaultValue</code>.
     */
    public void resetHiddenWithDefaultValue()
    {
        this.hiddenWithDefaultValue = null;
    }

    public void setHiddenWithDefaultValue(java.lang.String hiddenWithDefaultValue)
    {
        this.hiddenWithDefaultValue = hiddenWithDefaultValue;
    }

    /**
     * 
     */
    public java.lang.String getHiddenWithDefaultValue()
    {
        return this.hiddenWithDefaultValue;
    }
    
    public java.lang.Object[] getHiddenWithDefaultValueBackingList()
    {
        java.lang.Object[] values = this.hiddenWithDefaultValueValueList;
        java.lang.Object[] labels = this.hiddenWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getHiddenWithDefaultValueValueList()
    {
        return this.hiddenWithDefaultValueValueList;
    }

    public void setHiddenWithDefaultValueValueList(java.lang.Object[] hiddenWithDefaultValueValueList)
    {
        this.hiddenWithDefaultValueValueList = hiddenWithDefaultValueValueList;
    }

    public java.lang.Object[] getHiddenWithDefaultValueLabelList()
    {
        return this.hiddenWithDefaultValueLabelList;
    }

    public void setHiddenWithDefaultValueLabelList(java.lang.Object[] hiddenWithDefaultValueLabelList)
    {
        this.hiddenWithDefaultValueLabelList = hiddenWithDefaultValueLabelList;
    }

    public void setHiddenWithDefaultValueBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setHiddenWithDefaultValueBackingList requires non-null property arguments");
        }

        this.hiddenWithDefaultValueValueList = null;
        this.hiddenWithDefaultValueLabelList = null;

        if (items != null)
        {
            this.hiddenWithDefaultValueValueList = new java.lang.Object[items.size()];
            this.hiddenWithDefaultValueLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.hiddenWithDefaultValueValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.hiddenWithDefaultValueLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setHiddenWithDefaultValueBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>floatClass</code>.
     */
    public void resetFloatClass()
    {
        this.floatClass = null;
    }

    public void setFloatClass(java.lang.Float floatClass)
    {
        this.floatClass = floatClass;
    }

    /**
     * 
     */
    public java.lang.Float getFloatClass()
    {
        return this.floatClass;
    }
    
    public java.lang.Object[] getFloatClassBackingList()
    {
        java.lang.Object[] values = this.floatClassValueList;
        java.lang.Object[] labels = this.floatClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFloatClassValueList()
    {
        return this.floatClassValueList;
    }

    public void setFloatClassValueList(java.lang.Object[] floatClassValueList)
    {
        this.floatClassValueList = floatClassValueList;
    }

    public java.lang.Object[] getFloatClassLabelList()
    {
        return this.floatClassLabelList;
    }

    public void setFloatClassLabelList(java.lang.Object[] floatClassLabelList)
    {
        this.floatClassLabelList = floatClassLabelList;
    }

    public void setFloatClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setFloatClassBackingList requires non-null property arguments");
        }

        this.floatClassValueList = null;
        this.floatClassLabelList = null;

        if (items != null)
        {
            this.floatClassValueList = new java.lang.Object[items.size()];
            this.floatClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.floatClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.floatClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setFloatClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>collection</code>.
     */
    public void resetCollection()
    {
        this.collection = null;
    }

    public void setCollection(java.util.Collection collection)
    {
        this.collection = collection;
    }

    /**
     * 
     */
    public java.util.Collection getCollection()
    {
        return this.collection;
    }

    public void setCollectionAsArray(Object[] collection)
    {
        this.collection = (collection == null) ? null : java.util.Arrays.asList(collection);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.formfields.FormFieldsFormImpl#getCollection
     */
    public java.lang.Object[] getCollectionAsArray()
    {
        return (collection == null) ? null : collection.toArray();
    }
    
    public java.lang.Object[] getCollectionBackingList()
    {
        java.lang.Object[] values = this.collectionValueList;
        java.lang.Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(java.lang.Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public java.lang.Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(java.lang.Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    public void setCollectionBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setCollectionBackingList requires non-null property arguments");
        }

        this.collectionValueList = null;
        this.collectionLabelList = null;

        if (items != null)
        {
            this.collectionValueList = new java.lang.Object[items.size()];
            this.collectionLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.collectionValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.collectionLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setCollectionBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>integerClass</code>.
     */
    public void resetIntegerClass()
    {
        this.integerClass = null;
    }

    public void setIntegerClass(java.lang.Integer integerClass)
    {
        this.integerClass = integerClass;
    }

    /**
     * 
     */
    public java.lang.Integer getIntegerClass()
    {
        return this.integerClass;
    }
    
    public java.lang.Object[] getIntegerClassBackingList()
    {
        java.lang.Object[] values = this.integerClassValueList;
        java.lang.Object[] labels = this.integerClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getIntegerClassValueList()
    {
        return this.integerClassValueList;
    }

    public void setIntegerClassValueList(java.lang.Object[] integerClassValueList)
    {
        this.integerClassValueList = integerClassValueList;
    }

    public java.lang.Object[] getIntegerClassLabelList()
    {
        return this.integerClassLabelList;
    }

    public void setIntegerClassLabelList(java.lang.Object[] integerClassLabelList)
    {
        this.integerClassLabelList = integerClassLabelList;
    }

    public void setIntegerClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setIntegerClassBackingList requires non-null property arguments");
        }

        this.integerClassValueList = null;
        this.integerClassLabelList = null;

        if (items != null)
        {
            this.integerClassValueList = new java.lang.Object[items.size()];
            this.integerClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.integerClassValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.integerClassLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setIntegerClassBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>number</code>.
     */
    public void resetNumber()
    {
        this.number = 0;
    }

    public void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }
    
    public java.lang.Object[] getNumberBackingList()
    {
        java.lang.Object[] values = this.numberValueList;
        java.lang.Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(java.lang.Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public java.lang.Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(java.lang.Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    public void setNumberBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setNumberBackingList requires non-null property arguments");
        }

        this.numberValueList = null;
        this.numberLabelList = null;

        if (items != null)
        {
            this.numberValueList = new java.lang.Object[items.size()];
            this.numberLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.numberValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.numberLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormFieldsFormImpl.setNumberBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.file = null;
        this.bool = false;
        this.setClass = null;
        this.setClassValueList = new java.lang.Object[0];
        this.setClassLabelList = new java.lang.Object[0];
        this.selectable = null;
        this.booleanClass = null;
        this.multiSelect = null;
        this.multiSelectValueList = new java.lang.Object[0];
        this.multiSelectLabelList = new java.lang.Object[0];
        this.collection = null;
        this.collectionValueList = new java.lang.Object[0];
        this.collectionLabelList = new java.lang.Object[0];
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("title", this.title);
        builder.append("time", this.time);
        builder.append("file", this.file);
        builder.append("hasCustomValidator", this.hasCustomValidator);
        builder.append("bAdName", this.bAdName);
        builder.append("multiFormat", this.multiFormat);
        builder.append("date", this.date);
        builder.append("bool", this.bool);
        builder.append("setClass", this.setClass);
        builder.append("selectable", this.selectable);
        builder.append("booleanClass", this.booleanClass);
        builder.append("text", this.text);
        builder.append("mapClass", this.mapClass);
        builder.append("multiSelect", this.multiSelect);
        builder.append("dateWithoutCalendar", this.dateWithoutCalendar);
        builder.append("dateWithTime", this.dateWithTime);
        builder.append("hiddenWithDefaultValue", this.hiddenWithDefaultValue);
        builder.append("floatClass", this.floatClass);
        builder.append("collection", this.collection);
        builder.append("integerClass", this.integerClass);
        builder.append("number", this.number);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.title = null;
        this.titleValueList = null;
        this.titleLabelList = null;
        this.time = null;
        this.timeValueList = null;
        this.timeLabelList = null;
        this.file = null;
        this.fileValueList = null;
        this.fileLabelList = null;
        this.hasCustomValidator = null;
        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;
        this.bAdName = null;
        this.bAdNameValueList = null;
        this.bAdNameLabelList = null;
        this.multiFormat = null;
        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;
        this.date = null;
        this.dateValueList = null;
        this.dateLabelList = null;
        this.bool = false;
        this.boolValueList = null;
        this.boolLabelList = null;
        this.setClass = null;
        this.setClassValueList = null;
        this.setClassLabelList = null;
        this.selectable = null;
        this.selectableValueList = null;
        this.selectableLabelList = null;
        this.booleanClass = null;
        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;
        this.text = null;
        this.textValueList = null;
        this.textLabelList = null;
        this.mapClass = null;
        this.mapClassValueList = null;
        this.mapClassLabelList = null;
        this.multiSelect = null;
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        this.dateWithoutCalendar = null;
        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;
        this.dateWithTime = null;
        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;
        this.hiddenWithDefaultValue = null;
        this.hiddenWithDefaultValueValueList = null;
        this.hiddenWithDefaultValueLabelList = null;
        this.floatClass = null;
        this.floatClassValueList = null;
        this.floatClassLabelList = null;
        this.collection = null;
        this.collectionValueList = null;
        this.collectionLabelList = null;
        this.integerClass = null;
        this.integerClassValueList = null;
        this.integerClassLabelList = null;
        this.number = 0;
        this.numberValueList = null;
        this.numberLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}