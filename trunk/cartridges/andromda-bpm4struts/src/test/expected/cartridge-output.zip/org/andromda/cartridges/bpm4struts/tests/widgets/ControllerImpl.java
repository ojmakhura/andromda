package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void preloadSelects(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.widgets.WidgetsActivityForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setSubmitHiddenTest("submitHiddenTest-test");
        form.setSubmitTextFieldTest2("submitTextFieldTest2-test");
        form.setSubmitCheckboxTest(false);
        form.setSubmitRadioButtonsTest("submitRadioButtonsTest-test");
        form.setSubmitSelectTest("submitSelectTest-test");
        form.setSubmitSelectTestValueList(new Object[] {"submitSelectTest-1", "submitSelectTest-2", "submitSelectTest-3", "submitSelectTest-4", "submitSelectTest-5"});
        form.setSubmitSelectTestLabelList(form.getSubmitSelectTestValueList());
        form.setSubmitRadioButtonsTest2("submitRadioButtonsTest2-test");
        form.setSubmitTextAreaTest("submitTextAreaTest-test");
        form.setSubmitPasswordFieldTest("submitPasswordFieldTest-test");
        form.setSubmitRadioButtonsTest3("submitRadioButtonsTest3-test");
        form.setSubmitTextFieldTest("submitTextFieldTest-test");
    }

}
