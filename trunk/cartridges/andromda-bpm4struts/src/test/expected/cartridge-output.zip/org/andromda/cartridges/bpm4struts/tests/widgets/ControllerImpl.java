package org.andromda.cartridges.bpm4struts.tests.widgets;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerImpl extends Controller
{
    /**
     * 
     */
    public final void preloadSelects(ActionMapping mapping, ControllerPreloadSelectsInterface form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setSubmitHiddenTest("submitHiddenTest-test");
        form.setSubmitTextFieldTest2("submitTextFieldTest2-test");
        form.setSubmitRadioButtonsTest2("submitRadioButtonsTest2-test");
        form.setSubmitRadioButtonsTest("submitRadioButtonsTest-test");
        form.setSubmitPasswordFieldTest("submitPasswordFieldTest-test");
        form.setSubmitCheckboxTest(false);
        form.setSubmitRadioButtonsTest3("submitRadioButtonsTest3-test");
        form.setSubmitTextFieldTest("submitTextFieldTest-test");
        form.setSubmitTextAreaTest("submitTextAreaTest-test");
        form.setSubmitSelectTest("submitSelectTest-test");
    }











}
