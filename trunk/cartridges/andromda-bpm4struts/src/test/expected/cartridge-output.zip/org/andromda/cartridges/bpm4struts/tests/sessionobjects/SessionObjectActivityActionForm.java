package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

import java.io.Serializable;

import org.apache.struts.action.ActionMapping;
import org.apache.struts.validator.ValidatorForm;

import javax.servlet.http.HttpServletRequest;

/**
 * @struts.form
 *      name="sessionObjectActivitySessionObjectActivityActionForm"
 */
public class SessionObjectActivityActionForm extends ValidatorForm implements Serializable
    , ControllerSomeOperation
{

    public SessionObjectActivityActionForm()
    {
    }

    public void reset(ActionMapping mapping, HttpServletRequest request)
    {
    }



    public void clean()
    {
    }

}
