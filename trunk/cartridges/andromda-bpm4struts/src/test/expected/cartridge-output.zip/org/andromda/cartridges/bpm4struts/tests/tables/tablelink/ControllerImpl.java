/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.Controller#loadTableData(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.tables.tablelink.LoadTableDataForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void loadTableData(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.tables.tablelink.LoadTableDataForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // all properties receive a default value, just to have the application running properly
        form.setTableData(tableDataDummyList);
        form.setMultiboxThing(new Object[] {"multiboxThing-1", "multiboxThing-2", "multiboxThing-3", "multiboxThing-4", "multiboxThing-5"});
    }

    /**
     * This dummy variable is used to populate the "tableDataNoExportTypes" table.
     * You may delete it when you add you own code in this controller.
     */
    private final java.util.Collection tableDataNoExportTypesDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataNoExportTypesDummy("one-1", "two-1", "three-1"),
            new TableDataNoExportTypesDummy("one-2", "two-2", "three-2"),
            new TableDataNoExportTypesDummy("one-3", "two-3", "three-3"),
            new TableDataNoExportTypesDummy("one-4", "two-4", "three-4"),
            new TableDataNoExportTypesDummy("one-5", "two-5", "three-5")
        } );

    /**
     * This inner class is used in the dummy implementation in order to get the web application
     * running without any manual programming.
     * You may delete this class when you add you own code in this controller.
     */
    public final class TableDataNoExportTypesDummy implements java.io.Serializable
    {
        private String one = null;
        private String two = null;
        private String three = null;

        public TableDataNoExportTypesDummy(String one, String two, String three)
        {
            this.one = one;
            this.two = two;
            this.three = three;
        }
        
        public void setOne(String one)
        {
            this.one = one;
        }

        public String getOne()
        {
            return this.one;
        }
        
        public void setTwo(String two)
        {
            this.two = two;
        }

        public String getTwo()
        {
            return this.two;
        }
        
        public void setThree(String three)
        {
            this.three = three;
        }

        public String getThree()
        {
            return this.three;
        }
        
    }

    /**
     * This dummy variable is used to populate the "tableDataDefaultExportTypes" table.
     * You may delete it when you add you own code in this controller.
     */
    private final java.util.Collection tableDataDefaultExportTypesDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataDefaultExportTypesDummy("one-1", "two-1", "three-1"),
            new TableDataDefaultExportTypesDummy("one-2", "two-2", "three-2"),
            new TableDataDefaultExportTypesDummy("one-3", "two-3", "three-3"),
            new TableDataDefaultExportTypesDummy("one-4", "two-4", "three-4"),
            new TableDataDefaultExportTypesDummy("one-5", "two-5", "three-5")
        } );

    /**
     * This inner class is used in the dummy implementation in order to get the web application
     * running without any manual programming.
     * You may delete this class when you add you own code in this controller.
     */
    public final class TableDataDefaultExportTypesDummy implements java.io.Serializable
    {
        private String one = null;
        private String two = null;
        private String three = null;

        public TableDataDefaultExportTypesDummy(String one, String two, String three)
        {
            this.one = one;
            this.two = two;
            this.three = three;
        }
        
        public void setOne(String one)
        {
            this.one = one;
        }

        public String getOne()
        {
            return this.one;
        }
        
        public void setTwo(String two)
        {
            this.two = two;
        }

        public String getTwo()
        {
            return this.two;
        }
        
        public void setThree(String three)
        {
            this.three = three;
        }

        public String getThree()
        {
            return this.three;
        }
        
    }



    /**
     * This dummy variable is used to populate the "tableData" table.
     * You may delete it when you add you own code in this controller.
     */
    private final java.util.Collection tableDataDummyList =
        java.util.Arrays.asList( new Object[] {
            new TableDataDummy("first-1", "second-1", "third-1", "fourth-1"),
            new TableDataDummy("first-2", "second-2", "third-2", "fourth-2"),
            new TableDataDummy("first-3", "second-3", "third-3", "fourth-3"),
            new TableDataDummy("first-4", "second-4", "third-4", "fourth-4"),
            new TableDataDummy("first-5", "second-5", "third-5", "fourth-5")
        } );

    /**
     * This inner class is used in the dummy implementation in order to get the web application
     * running without any manual programming.
     * You may delete this class when you add you own code in this controller.
     */
    public final class TableDataDummy implements java.io.Serializable
    {
        private String first = null;
        private String second = null;
        private String third = null;
        private String fourth = null;

        public TableDataDummy(String first, String second, String third, String fourth)
        {
            this.first = first;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
        }
        
        public void setFirst(String first)
        {
            this.first = first;
        }

        public String getFirst()
        {
            return this.first;
        }
        
        public void setSecond(String second)
        {
            this.second = second;
        }

        public String getSecond()
        {
            return this.second;
        }
        
        public void setThird(String third)
        {
            this.third = third;
        }

        public String getThird()
        {
            return this.third;
        }
        
        public void setFourth(String fourth)
        {
            this.fourth = fourth;
        }

        public String getFourth()
        {
            return this.fourth;
        }
        
    }

}
