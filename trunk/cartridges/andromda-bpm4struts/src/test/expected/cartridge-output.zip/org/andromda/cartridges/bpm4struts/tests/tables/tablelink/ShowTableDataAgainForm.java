package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * @struts.form
 *      name="tableLinkActivityShowTableDataAgainForm"
 */
public class ShowTableDataAgainForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String againSecond;

    public ShowTableDataAgainForm()
    {
    }

    public void setAgainSecond(java.lang.String againSecond)
    {
        this.againSecond = againSecond;
    }

    public java.lang.String getAgainSecond()
    {
        return this.againSecond;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("againSecond=");
        buffer.append(String.valueOf(this.getAgainSecond()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.againSecond = null;
    }

}
