package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 
 *
 */
public abstract class Controller implements java.io.Serializable
{
    public abstract void someOperation(ActionMapping mapping, SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    protected final org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject getTestSessionObject(HttpServletRequest request)
    {
        org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject object = null;
        HttpSession session = request.getSession();
        if (session != null)
        {
            Object attribute = session.getAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject.SESSION_KEY);
            if (attribute instanceof org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject)
            {
                object = (org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject)attribute;
            }
        }
        return object;
    }

    protected final void setTestSessionObject(HttpServletRequest request, org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject object)
    {
        HttpSession session = request.getSession();
        if (session != null)
        {
            session.setAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject.SESSION_KEY, object);
        }
    }

}
