package org.andromda.cartridges.bpm4struts.tests.sessionobjects;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

/**
 * 
 *
 */
public abstract class Controller implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void someOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.sessionobjects.SomeOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;

    protected final org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject getTestSessionObject(HttpServletRequest request)
    {
        org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject object = null;
        HttpSession session = request.getSession(false);
        if (session != null)
        {
            Object attribute = session.getAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject.SESSION_KEY);
            if (attribute instanceof org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject)
            {
                object = (org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject)attribute;
            }
        }
        return object;
    }

    protected final void setTestSessionObject(HttpServletRequest request, org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject object)
    {
        setTestSessionObject(request, object, true);
    }

    protected final void setTestSessionObject(HttpServletRequest request, org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject object, boolean createSession)
    {
        HttpSession session = request.getSession(createSession);
        if (session != null)
        {
            session.setAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject.SESSION_KEY, object);
        }
    }

    protected final void removeTestSessionObject(HttpServletRequest request)
    {
        HttpSession session = request.getSession(false);
        if (session != null)
        {
            session.removeAttribute(org.andromda.cartridges.bpm4struts.tests.sessionobjects.TestSessionObject.SESSION_KEY);
        }
    }


    protected final void saveWarningMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.warningmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.warningmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }

    protected final void saveSuccessMessage(HttpServletRequest request, String message)
    {
        ActionMessages messages = (ActionMessages)request.getAttribute("org.andromda.bpm4struts.successmessages");
        if (messages == null)
        {
            messages = new ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.successmessages", messages);
        }
        messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(message));
    }

}
