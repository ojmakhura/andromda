package org.andromda.cartridges.bpm4struts.tests.validation;

/**
 * @struts.form
 *      name="validationActivityValidationActivityForm"
 */
public class ValidationActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String validateRequiredTest;
    private java.net.URL validateUrlTest;
    private float validateFloatRangeTest;
    private java.lang.String validateCreditcardTest;
    private java.lang.Float validateFloatWrapperRangeTest;
    private java.util.Date validateLenientDateTest;
    private final static java.text.DateFormat validateLenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.lang.String validateMaxlengthTest;
    private java.util.Date validateStrictDateTest;
    private final static java.text.DateFormat validateStrictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private int validateIntRangeTest;
    private java.lang.Double validateDoubleWrapperRangeTest;
    private double validateDoubleRangeTest;
    private java.lang.Integer validateIntWrapperRangeTest;
    private java.lang.String validateEmailTest;
    private java.lang.String validatePatternTest;
    private java.lang.String validateMinlengthTest;

    public ValidationActivityForm()
    {
        validateLenientDateTestDateFormatter.setLenient(true);
        validateStrictDateTestDateFormatter.setLenient(false);
    }

    public void setValidateRequiredTest(java.lang.String validateRequiredTest)
    {
        this.validateRequiredTest = validateRequiredTest;
    }

    public java.lang.String getValidateRequiredTest()
    {
        return this.validateRequiredTest;
    }

    public void setValidateUrlTest(java.net.URL validateUrlTest)
    {
        this.validateUrlTest = validateUrlTest;
    }

    public java.net.URL getValidateUrlTest()
    {
        return this.validateUrlTest;
    }

    public void setValidateFloatRangeTest(float validateFloatRangeTest)
    {
        this.validateFloatRangeTest = validateFloatRangeTest;
    }

    public float getValidateFloatRangeTest()
    {
        return this.validateFloatRangeTest;
    }

    public void setValidateCreditcardTest(java.lang.String validateCreditcardTest)
    {
        this.validateCreditcardTest = validateCreditcardTest;
    }

    public java.lang.String getValidateCreditcardTest()
    {
        return this.validateCreditcardTest;
    }

    public void setValidateFloatWrapperRangeTest(java.lang.Float validateFloatWrapperRangeTest)
    {
        this.validateFloatWrapperRangeTest = validateFloatWrapperRangeTest;
    }

    public java.lang.Float getValidateFloatWrapperRangeTest()
    {
        return this.validateFloatWrapperRangeTest;
    }

    public void setValidateLenientDateTestAsDate(java.util.Date validateLenientDateTest)
    {
        this.validateLenientDateTest = validateLenientDateTest;
    }

    public java.util.Date getValidateLenientDateTestAsDate()
    {
        return this.validateLenientDateTest;
    }

    public void setValidateLenientDateTest(java.lang.String validateLenientDateTest)
    {
        if (validateLenientDateTest == null || validateLenientDateTest.trim().length()==0)
        {
            this.validateLenientDateTest = null;
        }
        else
        {
            try
            {
                this.validateLenientDateTest = validateLenientDateTestDateFormatter.parse(validateLenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateLenientDateTest()
    {
        return (validateLenientDateTest == null) ? null : validateLenientDateTestDateFormatter.format(validateLenientDateTest);
    }

    public java.text.DateFormat getValidateLenientDateTestDateFormatter()
    {
        return this.validateLenientDateTestDateFormatter;
    }

    public void setValidateMaxlengthTest(java.lang.String validateMaxlengthTest)
    {
        this.validateMaxlengthTest = validateMaxlengthTest;
    }

    public java.lang.String getValidateMaxlengthTest()
    {
        return this.validateMaxlengthTest;
    }

    public void setValidateStrictDateTestAsDate(java.util.Date validateStrictDateTest)
    {
        this.validateStrictDateTest = validateStrictDateTest;
    }

    public java.util.Date getValidateStrictDateTestAsDate()
    {
        return this.validateStrictDateTest;
    }

    public void setValidateStrictDateTest(java.lang.String validateStrictDateTest)
    {
        if (validateStrictDateTest == null || validateStrictDateTest.trim().length()==0)
        {
            this.validateStrictDateTest = null;
        }
        else
        {
            try
            {
                this.validateStrictDateTest = validateStrictDateTestDateFormatter.parse(validateStrictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateStrictDateTest()
    {
        return (validateStrictDateTest == null) ? null : validateStrictDateTestDateFormatter.format(validateStrictDateTest);
    }

    public java.text.DateFormat getValidateStrictDateTestDateFormatter()
    {
        return this.validateStrictDateTestDateFormatter;
    }

    public void setValidateIntRangeTest(int validateIntRangeTest)
    {
        this.validateIntRangeTest = validateIntRangeTest;
    }

    public int getValidateIntRangeTest()
    {
        return this.validateIntRangeTest;
    }

    public void setValidateDoubleWrapperRangeTest(java.lang.Double validateDoubleWrapperRangeTest)
    {
        this.validateDoubleWrapperRangeTest = validateDoubleWrapperRangeTest;
    }

    public java.lang.Double getValidateDoubleWrapperRangeTest()
    {
        return this.validateDoubleWrapperRangeTest;
    }

    public void setValidateDoubleRangeTest(double validateDoubleRangeTest)
    {
        this.validateDoubleRangeTest = validateDoubleRangeTest;
    }

    public double getValidateDoubleRangeTest()
    {
        return this.validateDoubleRangeTest;
    }

    public void setValidateIntWrapperRangeTest(java.lang.Integer validateIntWrapperRangeTest)
    {
        this.validateIntWrapperRangeTest = validateIntWrapperRangeTest;
    }

    public java.lang.Integer getValidateIntWrapperRangeTest()
    {
        return this.validateIntWrapperRangeTest;
    }

    public void setValidateEmailTest(java.lang.String validateEmailTest)
    {
        this.validateEmailTest = validateEmailTest;
    }

    public java.lang.String getValidateEmailTest()
    {
        return this.validateEmailTest;
    }

    public void setValidatePatternTest(java.lang.String validatePatternTest)
    {
        this.validatePatternTest = validatePatternTest;
    }

    public java.lang.String getValidatePatternTest()
    {
        return this.validatePatternTest;
    }

    public void setValidateMinlengthTest(java.lang.String validateMinlengthTest)
    {
        this.validateMinlengthTest = validateMinlengthTest;
    }

    public java.lang.String getValidateMinlengthTest()
    {
        return this.validateMinlengthTest;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("validateRequiredTest=");
        buffer.append(String.valueOf(this.getValidateRequiredTest()));
        buffer.append(",validateUrlTest=");
        buffer.append(String.valueOf(this.getValidateUrlTest()));
        buffer.append(",validateFloatRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatRangeTest()));
        buffer.append(",validateCreditcardTest=");
        buffer.append(String.valueOf(this.getValidateCreditcardTest()));
        buffer.append(",validateFloatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatWrapperRangeTest()));
        buffer.append(",validateLenientDateTest=");
        buffer.append(String.valueOf(this.getValidateLenientDateTest()));
        buffer.append(",validateMaxlengthTest=");
        buffer.append(String.valueOf(this.getValidateMaxlengthTest()));
        buffer.append(",validateStrictDateTest=");
        buffer.append(String.valueOf(this.getValidateStrictDateTest()));
        buffer.append(",validateIntRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntRangeTest()));
        buffer.append(",validateDoubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleWrapperRangeTest()));
        buffer.append(",validateDoubleRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleRangeTest()));
        buffer.append(",validateIntWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntWrapperRangeTest()));
        buffer.append(",validateEmailTest=");
        buffer.append(String.valueOf(this.getValidateEmailTest()));
        buffer.append(",validatePatternTest=");
        buffer.append(String.valueOf(this.getValidatePatternTest()));
        buffer.append(",validateMinlengthTest=");
        buffer.append(String.valueOf(this.getValidateMinlengthTest()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.validateRequiredTest = null;
        this.validateUrlTest = null;
        this.validateFloatRangeTest = 0;
        this.validateCreditcardTest = null;
        this.validateFloatWrapperRangeTest = null;
        this.validateLenientDateTest = null;
        this.validateMaxlengthTest = null;
        this.validateStrictDateTest = null;
        this.validateIntRangeTest = 0;
        this.validateDoubleWrapperRangeTest = null;
        this.validateDoubleRangeTest = 0;
        this.validateIntWrapperRangeTest = null;
        this.validateEmailTest = null;
        this.validatePatternTest = null;
        this.validateMinlengthTest = null;
    }

}
