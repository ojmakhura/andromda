package org.andromda.cartridges.bpm4struts.tests.validation;

public class ValidationActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String requiredTest;
    private Object[] requiredTestValueList;
    private Object[] requiredTestLabelList;
    private java.lang.String emailTest;
    private Object[] emailTestValueList;
    private Object[] emailTestLabelList;
    private int intRangeTest;
    private Object[] intRangeTestValueList;
    private Object[] intRangeTestLabelList;
    private double doubleRangeTest;
    private Object[] doubleRangeTestValueList;
    private Object[] doubleRangeTestLabelList;
    private java.lang.String maxlengthTest;
    private Object[] maxlengthTestValueList;
    private Object[] maxlengthTestLabelList;
    private java.lang.String patternTest;
    private Object[] patternTestValueList;
    private Object[] patternTestLabelList;
    private java.lang.Float floatWrapperRangeTest;
    private Object[] floatWrapperRangeTestValueList;
    private Object[] floatWrapperRangeTestLabelList;
    private java.lang.Integer intWrapperRangeTest;
    private Object[] intWrapperRangeTestValueList;
    private Object[] intWrapperRangeTestLabelList;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private Object[] lenientDateTestValueList;
    private Object[] lenientDateTestLabelList;
    private java.net.URL urlTest;
    private Object[] urlTestValueList;
    private Object[] urlTestLabelList;
    private java.lang.String minlengthTest;
    private Object[] minlengthTestValueList;
    private Object[] minlengthTestLabelList;
    private float floatRangeTest;
    private Object[] floatRangeTestValueList;
    private Object[] floatRangeTestLabelList;
    private java.lang.Double doubleWrapperRangeTest;
    private Object[] doubleWrapperRangeTestValueList;
    private Object[] doubleWrapperRangeTestLabelList;
    private java.lang.String creditcardTest;
    private Object[] creditcardTestValueList;
    private Object[] creditcardTestLabelList;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private Object[] strictDateTestValueList;
    private Object[] strictDateTestLabelList;

    public ValidationActivityForm()
    {
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    /**
     * Resets the given <code>requiredTest</code>.
     */
    public void resetRequiredTest()
    {
        this.requiredTest = null;
    }
    
    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }
    

    public Object[] getRequiredTestBackingList()
    {
        Object[] values = this.requiredTestValueList;
        Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    /**
     * Resets the given <code>emailTest</code>.
     */
    public void resetEmailTest()
    {
        this.emailTest = null;
    }
    
    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }
    

    public Object[] getEmailTestBackingList()
    {
        Object[] values = this.emailTestValueList;
        Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    /**
     * Resets the given <code>intRangeTest</code>.
     */
    public void resetIntRangeTest()
    {
        this.intRangeTest = 0;
    }
    
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }
    

    public Object[] getIntRangeTestBackingList()
    {
        Object[] values = this.intRangeTestValueList;
        Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    /**
     * Resets the given <code>doubleRangeTest</code>.
     */
    public void resetDoubleRangeTest()
    {
        this.doubleRangeTest = 0;
    }
    
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }
    

    public Object[] getDoubleRangeTestBackingList()
    {
        Object[] values = this.doubleRangeTestValueList;
        Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    /**
     * Resets the given <code>maxlengthTest</code>.
     */
    public void resetMaxlengthTest()
    {
        this.maxlengthTest = null;
    }
    
    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }
    

    public Object[] getMaxlengthTestBackingList()
    {
        Object[] values = this.maxlengthTestValueList;
        Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    /**
     * Resets the given <code>patternTest</code>.
     */
    public void resetPatternTest()
    {
        this.patternTest = null;
    }
    
    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }
    

    public Object[] getPatternTestBackingList()
    {
        Object[] values = this.patternTestValueList;
        Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    /**
     * Resets the given <code>floatWrapperRangeTest</code>.
     */
    public void resetFloatWrapperRangeTest()
    {
        this.floatWrapperRangeTest = null;
    }
    
    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }
    

    public Object[] getFloatWrapperRangeTestBackingList()
    {
        Object[] values = this.floatWrapperRangeTestValueList;
        Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    /**
     * Resets the given <code>intWrapperRangeTest</code>.
     */
    public void resetIntWrapperRangeTest()
    {
        this.intWrapperRangeTest = null;
    }
    
    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }
    

    public Object[] getIntWrapperRangeTestBackingList()
    {
        Object[] values = this.intWrapperRangeTestValueList;
        Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    /**
     * Resets the given <code>lenientDateTest</code>.
     */
    public void resetLenientDateTest()
    {
        this.lenientDateTest = null;
    }
    
    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    /**
     * Returns the Date instance representing the <code>lenientDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest#ateFormatter
     */
    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length()==0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getLenientDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getLenientDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest#sDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest#ateFormatter
     */
    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    /**
     * Returns the date formatter used for the <code>lenientDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest#sDate
     */
    public final static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return ValidationActivityForm.lenientDateTestDateFormatter;
    }


    public Object[] getLenientDateTestBackingList()
    {
        Object[] values = this.lenientDateTestValueList;
        Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    /**
     * Resets the given <code>urlTest</code>.
     */
    public void resetUrlTest()
    {
        this.urlTest = null;
    }
    
    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }
    

    public Object[] getUrlTestBackingList()
    {
        Object[] values = this.urlTestValueList;
        Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    /**
     * Resets the given <code>minlengthTest</code>.
     */
    public void resetMinlengthTest()
    {
        this.minlengthTest = null;
    }
    
    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }
    

    public Object[] getMinlengthTestBackingList()
    {
        Object[] values = this.minlengthTestValueList;
        Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    /**
     * Resets the given <code>floatRangeTest</code>.
     */
    public void resetFloatRangeTest()
    {
        this.floatRangeTest = 0;
    }
    
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }
    

    public Object[] getFloatRangeTestBackingList()
    {
        Object[] values = this.floatRangeTestValueList;
        Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    /**
     * Resets the given <code>doubleWrapperRangeTest</code>.
     */
    public void resetDoubleWrapperRangeTest()
    {
        this.doubleWrapperRangeTest = null;
    }
    
    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }
    

    public Object[] getDoubleWrapperRangeTestBackingList()
    {
        Object[] values = this.doubleWrapperRangeTestValueList;
        Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    /**
     * Resets the given <code>creditcardTest</code>.
     */
    public void resetCreditcardTest()
    {
        this.creditcardTest = null;
    }
    
    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }
    

    public Object[] getCreditcardTestBackingList()
    {
        Object[] values = this.creditcardTestValueList;
        Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    /**
     * Resets the given <code>strictDateTest</code>.
     */
    public void resetStrictDateTest()
    {
        this.strictDateTest = null;
    }
    
    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    /**
     * Returns the Date instance representing the <code>strictDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest#ateFormatter
     */
    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length()==0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getStrictDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getStrictDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest#sDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest#ateFormatter
     */
    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    /**
     * Returns the date formatter used for the <code>strictDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest#sDate
     */
    public final static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return ValidationActivityForm.strictDateTestDateFormatter;
    }


    public Object[] getStrictDateTestBackingList()
    {
        Object[] values = this.strictDateTestValueList;
        Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("requiredTest=");
        buffer.append(String.valueOf(this.getRequiredTest()));
        buffer.append(",emailTest=");
        buffer.append(String.valueOf(this.getEmailTest()));
        buffer.append(",intRangeTest=");
        buffer.append(String.valueOf(this.getIntRangeTest()));
        buffer.append(",doubleRangeTest=");
        buffer.append(String.valueOf(this.getDoubleRangeTest()));
        buffer.append(",maxlengthTest=");
        buffer.append(String.valueOf(this.getMaxlengthTest()));
        buffer.append(",patternTest=");
        buffer.append(String.valueOf(this.getPatternTest()));
        buffer.append(",floatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getFloatWrapperRangeTest()));
        buffer.append(",intWrapperRangeTest=");
        buffer.append(String.valueOf(this.getIntWrapperRangeTest()));
        buffer.append(",lenientDateTest=");
        buffer.append(String.valueOf(this.getLenientDateTest()));
        buffer.append(",urlTest=");
        buffer.append(String.valueOf(this.getUrlTest()));
        buffer.append(",minlengthTest=");
        buffer.append(String.valueOf(this.getMinlengthTest()));
        buffer.append(",floatRangeTest=");
        buffer.append(String.valueOf(this.getFloatRangeTest()));
        buffer.append(",doubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getDoubleWrapperRangeTest()));
        buffer.append(",creditcardTest=");
        buffer.append(String.valueOf(this.getCreditcardTest()));
        buffer.append(",strictDateTest=");
        buffer.append(String.valueOf(this.getStrictDateTest()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.requiredTest = null;
        this.emailTest = null;
        this.intRangeTest = 0;
        this.doubleRangeTest = 0;
        this.maxlengthTest = null;
        this.patternTest = null;
        this.floatWrapperRangeTest = null;
        this.intWrapperRangeTest = null;
        this.lenientDateTest = null;
        this.urlTest = null;
        this.minlengthTest = null;
        this.floatRangeTest = 0;
        this.doubleWrapperRangeTest = null;
        this.creditcardTest = null;
        this.strictDateTest = null;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}