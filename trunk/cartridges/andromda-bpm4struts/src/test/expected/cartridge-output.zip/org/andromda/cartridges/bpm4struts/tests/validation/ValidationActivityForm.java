package org.andromda.cartridges.bpm4struts.tests.validation;

/**
 * @struts.form
 *      name="validationActivityValidationActivityForm"
 */
public class ValidationActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private int validateIntRangeTest;
    private java.lang.Double validateDoubleWrapperRangeTest;
    private java.lang.String validateEmailTest;
    private java.lang.String validateRequiredTest;
    private java.lang.String validateMaxlengthTest;
    private double validateDoubleRangeTest;
    private java.util.Date validateStrictDateTest;
    private final static java.text.DateFormat validateStrictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");
    private java.lang.Float validateFloatWrapperRangeTest;
    private java.lang.String validateMinlengthTest;
    private java.util.Date validateLenientDateTest;
    private final static java.text.DateFormat validateLenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.net.URL validateUrlTest;
    private java.lang.String validatePatternTest;
    private java.lang.String validateCreditcardTest;
    private java.lang.Integer validateIntWrapperRangeTest;
    private float validateFloatRangeTest;

    public ValidationActivityForm()
    {
        validateStrictDateTestDateFormatter.setLenient(false);
        validateLenientDateTestDateFormatter.setLenient(true);
    }

    public void setValidateIntRangeTest(int validateIntRangeTest)
    {
        this.validateIntRangeTest = validateIntRangeTest;
    }

    public int getValidateIntRangeTest()
    {
        return this.validateIntRangeTest;
    }

    public void setValidateDoubleWrapperRangeTest(java.lang.Double validateDoubleWrapperRangeTest)
    {
        this.validateDoubleWrapperRangeTest = validateDoubleWrapperRangeTest;
    }

    public java.lang.Double getValidateDoubleWrapperRangeTest()
    {
        return this.validateDoubleWrapperRangeTest;
    }

    public void setValidateEmailTest(java.lang.String validateEmailTest)
    {
        this.validateEmailTest = validateEmailTest;
    }

    public java.lang.String getValidateEmailTest()
    {
        return this.validateEmailTest;
    }

    public void setValidateRequiredTest(java.lang.String validateRequiredTest)
    {
        this.validateRequiredTest = validateRequiredTest;
    }

    public java.lang.String getValidateRequiredTest()
    {
        return this.validateRequiredTest;
    }

    public void setValidateMaxlengthTest(java.lang.String validateMaxlengthTest)
    {
        this.validateMaxlengthTest = validateMaxlengthTest;
    }

    public java.lang.String getValidateMaxlengthTest()
    {
        return this.validateMaxlengthTest;
    }

    public void setValidateDoubleRangeTest(double validateDoubleRangeTest)
    {
        this.validateDoubleRangeTest = validateDoubleRangeTest;
    }

    public double getValidateDoubleRangeTest()
    {
        return this.validateDoubleRangeTest;
    }

    public void setValidateStrictDateTestAsDate(java.util.Date validateStrictDateTest)
    {
        this.validateStrictDateTest = validateStrictDateTest;
    }

    public java.util.Date getValidateStrictDateTestAsDate()
    {
        return this.validateStrictDateTest;
    }

    public void setValidateStrictDateTest(java.lang.String validateStrictDateTest)
    {
        if (validateStrictDateTest == null || validateStrictDateTest.trim().length()==0)
        {
            this.validateStrictDateTest = null;
        }
        else
        {
            try
            {
                this.validateStrictDateTest = validateStrictDateTestDateFormatter.parse(validateStrictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateStrictDateTest()
    {
        return (validateStrictDateTest == null) ? null : validateStrictDateTestDateFormatter.format(validateStrictDateTest);
    }

    public java.text.DateFormat getValidateStrictDateTestDateFormatter()
    {
        return this.validateStrictDateTestDateFormatter;
    }

    public void setValidateFloatWrapperRangeTest(java.lang.Float validateFloatWrapperRangeTest)
    {
        this.validateFloatWrapperRangeTest = validateFloatWrapperRangeTest;
    }

    public java.lang.Float getValidateFloatWrapperRangeTest()
    {
        return this.validateFloatWrapperRangeTest;
    }

    public void setValidateMinlengthTest(java.lang.String validateMinlengthTest)
    {
        this.validateMinlengthTest = validateMinlengthTest;
    }

    public java.lang.String getValidateMinlengthTest()
    {
        return this.validateMinlengthTest;
    }

    public void setValidateLenientDateTestAsDate(java.util.Date validateLenientDateTest)
    {
        this.validateLenientDateTest = validateLenientDateTest;
    }

    public java.util.Date getValidateLenientDateTestAsDate()
    {
        return this.validateLenientDateTest;
    }

    public void setValidateLenientDateTest(java.lang.String validateLenientDateTest)
    {
        if (validateLenientDateTest == null || validateLenientDateTest.trim().length()==0)
        {
            this.validateLenientDateTest = null;
        }
        else
        {
            try
            {
                this.validateLenientDateTest = validateLenientDateTestDateFormatter.parse(validateLenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    public java.lang.String getValidateLenientDateTest()
    {
        return (validateLenientDateTest == null) ? null : validateLenientDateTestDateFormatter.format(validateLenientDateTest);
    }

    public java.text.DateFormat getValidateLenientDateTestDateFormatter()
    {
        return this.validateLenientDateTestDateFormatter;
    }

    public void setValidateUrlTest(java.net.URL validateUrlTest)
    {
        this.validateUrlTest = validateUrlTest;
    }

    public java.net.URL getValidateUrlTest()
    {
        return this.validateUrlTest;
    }

    public void setValidatePatternTest(java.lang.String validatePatternTest)
    {
        this.validatePatternTest = validatePatternTest;
    }

    public java.lang.String getValidatePatternTest()
    {
        return this.validatePatternTest;
    }

    public void setValidateCreditcardTest(java.lang.String validateCreditcardTest)
    {
        this.validateCreditcardTest = validateCreditcardTest;
    }

    public java.lang.String getValidateCreditcardTest()
    {
        return this.validateCreditcardTest;
    }

    public void setValidateIntWrapperRangeTest(java.lang.Integer validateIntWrapperRangeTest)
    {
        this.validateIntWrapperRangeTest = validateIntWrapperRangeTest;
    }

    public java.lang.Integer getValidateIntWrapperRangeTest()
    {
        return this.validateIntWrapperRangeTest;
    }

    public void setValidateFloatRangeTest(float validateFloatRangeTest)
    {
        this.validateFloatRangeTest = validateFloatRangeTest;
    }

    public float getValidateFloatRangeTest()
    {
        return this.validateFloatRangeTest;
    }

    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("validateIntRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntRangeTest()));
        buffer.append(",validateDoubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleWrapperRangeTest()));
        buffer.append(",validateEmailTest=");
        buffer.append(String.valueOf(this.getValidateEmailTest()));
        buffer.append(",validateRequiredTest=");
        buffer.append(String.valueOf(this.getValidateRequiredTest()));
        buffer.append(",validateMaxlengthTest=");
        buffer.append(String.valueOf(this.getValidateMaxlengthTest()));
        buffer.append(",validateDoubleRangeTest=");
        buffer.append(String.valueOf(this.getValidateDoubleRangeTest()));
        buffer.append(",validateStrictDateTest=");
        buffer.append(String.valueOf(this.getValidateStrictDateTest()));
        buffer.append(",validateFloatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatWrapperRangeTest()));
        buffer.append(",validateMinlengthTest=");
        buffer.append(String.valueOf(this.getValidateMinlengthTest()));
        buffer.append(",validateLenientDateTest=");
        buffer.append(String.valueOf(this.getValidateLenientDateTest()));
        buffer.append(",validateUrlTest=");
        buffer.append(String.valueOf(this.getValidateUrlTest()));
        buffer.append(",validatePatternTest=");
        buffer.append(String.valueOf(this.getValidatePatternTest()));
        buffer.append(",validateCreditcardTest=");
        buffer.append(String.valueOf(this.getValidateCreditcardTest()));
        buffer.append(",validateIntWrapperRangeTest=");
        buffer.append(String.valueOf(this.getValidateIntWrapperRangeTest()));
        buffer.append(",validateFloatRangeTest=");
        buffer.append(String.valueOf(this.getValidateFloatRangeTest()));

        return buffer.append("]").toString();
    }


    public void clean()
    {
        this.validateIntRangeTest = 0;
        this.validateDoubleWrapperRangeTest = null;
        this.validateEmailTest = null;
        this.validateRequiredTest = null;
        this.validateMaxlengthTest = null;
        this.validateDoubleRangeTest = 0;
        this.validateStrictDateTest = null;
        this.validateFloatWrapperRangeTest = null;
        this.validateMinlengthTest = null;
        this.validateLenientDateTest = null;
        this.validateUrlTest = null;
        this.validatePatternTest = null;
        this.validateCreditcardTest = null;
        this.validateIntWrapperRangeTest = null;
        this.validateFloatRangeTest = 0;
    }

}
