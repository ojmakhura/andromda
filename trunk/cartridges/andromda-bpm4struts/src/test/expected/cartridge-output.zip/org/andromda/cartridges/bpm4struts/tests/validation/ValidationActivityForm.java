package org.andromda.cartridges.bpm4struts.tests.validation;

public class ValidationActivityForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String requiredTest;
    private java.lang.String emailTest;
    private int intRangeTest;
    private double doubleRangeTest;
    private java.lang.String maxlengthTest;
    private java.lang.String patternTest;
    private java.lang.Float floatWrapperRangeTest;
    private java.lang.Integer intWrapperRangeTest;
    private java.util.Date lenientDateTest;
    private final static java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
    private java.net.URL urlTest;
    private java.lang.String minlengthTest;
    private float floatRangeTest;
    private java.lang.Double doubleWrapperRangeTest;
    private java.lang.String creditcardTest;
    private java.util.Date strictDateTest;
    private final static java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MM/yyyy");

    public ValidationActivityForm()
    {
        lenientDateTestDateFormatter.setLenient(true);
        strictDateTestDateFormatter.setLenient(false);
    }

    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
    }

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }

    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
    }

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }

    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
    }

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }

    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
    }

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }

    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }

    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
    }

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }

    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }

    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }

    public void setLenientDateTestAsDate(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
    }

    /**
     * Returns the Date instance representing the <code>lenientDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTestDateFormatter
     */
    public java.util.Date getLenientDateTestAsDate()
    {
        return this.lenientDateTest;
    }

    public void setLenientDateTest(java.lang.String lenientDateTest)
    {
        if (lenientDateTest == null || lenientDateTest.trim().length()==0)
        {
            this.lenientDateTest = null;
        }
        else
        {
            try
            {
                this.lenientDateTest = lenientDateTestDateFormatter.parse(lenientDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getLenientDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getLenientDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTestDateFormatter
     */
    public java.lang.String getLenientDateTest()
    {
        return (lenientDateTest == null) ? null : lenientDateTestDateFormatter.format(lenientDateTest);
    }

    /**
     * Returns the date formatter used for the <code>lenientDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getLenientDateTestAsDate
     */
    public final static java.text.DateFormat getLenientDateTestDateFormatter()
    {
        return ValidationActivityForm.lenientDateTestDateFormatter;
    }

    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
    }

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }

    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
    }

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }

    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
    }

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }

    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
    }

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }

    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
    }

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }

    public void setStrictDateTestAsDate(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
    }

    /**
     * Returns the Date instance representing the <code>strictDateTest</code> field.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTestDateFormatter
     */
    public java.util.Date getStrictDateTestAsDate()
    {
        return this.strictDateTest;
    }

    public void setStrictDateTest(java.lang.String strictDateTest)
    {
        if (strictDateTest == null || strictDateTest.trim().length()==0)
        {
            this.strictDateTest = null;
        }
        else
        {
            try
            {
                this.strictDateTest = strictDateTestDateFormatter.parse(strictDateTest);
            }
            catch(java.text.ParseException e)
            {
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * 
     *
     * This method returns a <code>java.lang.String</code> instance, in order to get the
     * <code>java.util.Date</code> instance see the <code>getStrictDateTestAsDate()</code>
     * method.
     * <p>
     * The conversion from Date to String (and vice-versa) is done by means of a date formatter, which
     * can be accessed here: <code>getStrictDateTestDateFormatter()</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTestAsDate
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTestDateFormatter
     */
    public java.lang.String getStrictDateTest()
    {
        return (strictDateTest == null) ? null : strictDateTestDateFormatter.format(strictDateTest);
    }

    /**
     * Returns the date formatter used for the <code>strictDateTest</code> property.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTest
     * @see org.andromda.cartridges.bpm4struts.tests.validation.ValidationActivityForm#getStrictDateTestAsDate
     */
    public final static java.text.DateFormat getStrictDateTestDateFormatter()
    {
        return ValidationActivityForm.strictDateTestDateFormatter;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    /**
     * Returns a String instance representing the contents of this form, nested collections will also
     * have their elements printed (one level).
     */
    public String toString()
    {
        final StringBuffer buffer = new StringBuffer().append("[");

        buffer.append("requiredTest=");
        buffer.append(String.valueOf(this.getRequiredTest()));
        buffer.append(",emailTest=");
        buffer.append(String.valueOf(this.getEmailTest()));
        buffer.append(",intRangeTest=");
        buffer.append(String.valueOf(this.getIntRangeTest()));
        buffer.append(",doubleRangeTest=");
        buffer.append(String.valueOf(this.getDoubleRangeTest()));
        buffer.append(",maxlengthTest=");
        buffer.append(String.valueOf(this.getMaxlengthTest()));
        buffer.append(",patternTest=");
        buffer.append(String.valueOf(this.getPatternTest()));
        buffer.append(",floatWrapperRangeTest=");
        buffer.append(String.valueOf(this.getFloatWrapperRangeTest()));
        buffer.append(",intWrapperRangeTest=");
        buffer.append(String.valueOf(this.getIntWrapperRangeTest()));
        buffer.append(",lenientDateTest=");
        buffer.append(String.valueOf(this.getLenientDateTest()));
        buffer.append(",urlTest=");
        buffer.append(String.valueOf(this.getUrlTest()));
        buffer.append(",minlengthTest=");
        buffer.append(String.valueOf(this.getMinlengthTest()));
        buffer.append(",floatRangeTest=");
        buffer.append(String.valueOf(this.getFloatRangeTest()));
        buffer.append(",doubleWrapperRangeTest=");
        buffer.append(String.valueOf(this.getDoubleWrapperRangeTest()));
        buffer.append(",creditcardTest=");
        buffer.append(String.valueOf(this.getCreditcardTest()));
        buffer.append(",strictDateTest=");
        buffer.append(String.valueOf(this.getStrictDateTest()));

        return buffer.append("]").toString();
    }


    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.requiredTest = null;
        this.emailTest = null;
        this.intRangeTest = 0;
        this.doubleRangeTest = 0;
        this.maxlengthTest = null;
        this.patternTest = null;
        this.floatWrapperRangeTest = null;
        this.intWrapperRangeTest = null;
        this.lenientDateTest = null;
        this.urlTest = null;
        this.minlengthTest = null;
        this.floatRangeTest = 0;
        this.doubleWrapperRangeTest = null;
        this.creditcardTest = null;
        this.strictDateTest = null;
    }

}
