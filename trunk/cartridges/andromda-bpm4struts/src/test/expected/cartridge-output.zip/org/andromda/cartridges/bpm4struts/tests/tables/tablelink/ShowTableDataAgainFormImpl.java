/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataAgainFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.lang.String third;
    private java.lang.Object[] thirdValueList;
    private java.lang.Object[] thirdLabelList;
    private java.lang.String fourth;
    private java.lang.Object[] fourthValueList;
    private java.lang.Object[] fourthLabelList;
    private java.lang.String second;
    private java.lang.Object[] secondValueList;
    private java.lang.Object[] secondLabelList;

    public ShowTableDataAgainFormImpl()
    {
    }

    /**
     * Resets the given <code>third</code>.
     */
    public void resetThird()
    {
        this.third = null;
    }

    public void setThird(java.lang.String third)
    {
        this.third = third;
    }

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }
    
    public java.lang.Object[] getThirdBackingList()
    {
        java.lang.Object[] values = this.thirdValueList;
        java.lang.Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(java.lang.Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public java.lang.Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(java.lang.Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setThirdBackingList requires non-null property arguments");
        }

        this.thirdValueList = null;
        this.thirdLabelList = null;

        if (items != null)
        {
            this.thirdValueList = new java.lang.Object[items.size()];
            this.thirdLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.thirdValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thirdLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataAgainFormImpl.setThirdBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>fourth</code>.
     */
    public void resetFourth()
    {
        this.fourth = null;
    }

    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
    }

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }
    
    public java.lang.Object[] getFourthBackingList()
    {
        java.lang.Object[] values = this.fourthValueList;
        java.lang.Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(java.lang.Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public java.lang.Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(java.lang.Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setFourthBackingList requires non-null property arguments");
        }

        this.fourthValueList = null;
        this.fourthLabelList = null;

        if (items != null)
        {
            this.fourthValueList = new java.lang.Object[items.size()];
            this.fourthLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.fourthValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fourthLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataAgainFormImpl.setFourthBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }

    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    
    public java.lang.Object[] getSecondBackingList()
    {
        java.lang.Object[] values = this.secondValueList;
        java.lang.Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(java.lang.Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public java.lang.Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(java.lang.Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataAgainFormImpl.setSecondBackingList requires non-null property arguments");
        }

        this.secondValueList = null;
        this.secondLabelList = null;

        if (items != null)
        {
            this.secondValueList = new java.lang.Object[items.size()];
            this.secondLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.secondValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.secondLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataAgainFormImpl.setSecondBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("third", this.third);
        builder.append("fourth", this.fourth);
        builder.append("second", this.second);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.third = null;
        this.thirdValueList = null;
        this.thirdLabelList = null;
        this.fourth = null;
        this.fourthValueList = null;
        this.fourthLabelList = null;
        this.second = null;
        this.secondValueList = null;
        this.secondLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}