

node_AndroMDA_car_rental_sample = gFld("<code>AndroMDA_car_rental_sample</code>", "AndroMDA_car_rental_sample.html", "Model.gif")

            
        
                
        insDoc(node_AndroMDA_car_rental_sample, gLnk(0, "&nbsp;StrutsConfiguration","StrutsConfiguration.html", "Class.gif"))
    
    
        
        node_AndroMDA_car_rental_sample_Use_Cases = insFld(node_AndroMDA_car_rental_sample, gFld("Use_Cases","Use_Cases.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Administrator","Use_Cases/Administrator.html", "Actor.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Authenticating_as_a_Customer","Use_Cases/Authenticating_as_a_Customer.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Authenticating_as_an_Administrator","Use_Cases/Authenticating_as_an_Administrator.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;CallCenter","Use_Cases/CallCenter.html", "Actor.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Car_Handout_Desk","Use_Cases/Car_Handout_Desk.html", "Actor.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Car_Reception_Desk","Use_Cases/Car_Reception_Desk.html", "Actor.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Customer","Use_Cases/Customer.html", "Actor.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Handing_out_a_Car","Use_Cases/Handing_out_a_Car.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Registering_a_new_Customer","Use_Cases/Registering_a_new_Customer.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Registering_a_new_car","Use_Cases/Registering_a_new_car.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Registering_a_new_car_type","Use_Cases/Registering_a_new_car_type.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Registering_an_accident","Use_Cases/Registering_an_accident.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Reserving_a_Car","Use_Cases/Reserving_a_Car.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Returning_a_Car","Use_Cases/Returning_a_Car.html", "UseCase.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_Use_Cases, gLnk(0, "&nbsp;Searching_for_a_known_Customer","Use_Cases/Searching_for_a_known_Customer.html", "UseCase.gif"))
            
        
        node_AndroMDA_car_rental_sample_org = insFld(node_AndroMDA_car_rental_sample, gFld("org","org.html", "Package.gif"))

            
        
        node_AndroMDA_car_rental_sample_org_andromda = insFld(node_AndroMDA_car_rental_sample_org, gFld("andromda","org/andromda.html", "Package.gif"))

            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples = insFld(node_AndroMDA_car_rental_sample_org_andromda, gFld("samples","org/andromda/samples.html", "Package.gif"))

            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples, gFld("carrental","org/andromda/samples/carrental.html", "Package.gif"))

            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental, gFld("admins","org/andromda/samples/carrental/admins.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins, gLnk(0, "&nbsp;AdminService","org/andromda/samples/carrental/admins/AdminService.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins, gLnk(0, "&nbsp;Administrator","org/andromda/samples/carrental/admins/Administrator.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins, gLnk(0, "&nbsp;AdminsException","org/andromda/samples/carrental/admins/AdminsException.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental, gFld("contracts","org/andromda/samples/carrental/contracts.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;AccidentDoc","org/andromda/samples/carrental/contracts/AccidentDoc.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;Contract","org/andromda/samples/carrental/contracts/Contract.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;ContractException","org/andromda/samples/carrental/contracts/ContractException.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;ContractService","org/andromda/samples/carrental/contracts/ContractService.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;HandoutDoc","org/andromda/samples/carrental/contracts/HandoutDoc.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;PartnerInAccident","org/andromda/samples/carrental/contracts/PartnerInAccident.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;Reservation","org/andromda/samples/carrental/contracts/Reservation.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gLnk(0, "&nbsp;ReturnDoc","org/andromda/samples/carrental/contracts/ReturnDoc.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental, gFld("customers","org/andromda/samples/carrental/customers.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;Customer","org/andromda/samples/carrental/customers/Customer.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;CustomerException","org/andromda/samples/carrental/customers/CustomerException.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;CustomerService","org/andromda/samples/carrental/customers/CustomerService.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;Driver","org/andromda/samples/carrental/customers/Driver.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;DriverData","org/andromda/samples/carrental/customers/DriverData.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gLnk(0, "&nbsp;DriverLocal","org/andromda/samples/carrental/customers/DriverLocal.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental, gFld("inventory","org/andromda/samples/carrental/inventory.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;Car","org/andromda/samples/carrental/inventory/Car.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;CarAccessory","org/andromda/samples/carrental/inventory/CarAccessory.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;CarAccessoryType","org/andromda/samples/carrental/inventory/CarAccessoryType.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;CarData","org/andromda/samples/carrental/inventory/CarData.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;CarType","org/andromda/samples/carrental/inventory/CarType.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;CarTypeData","org/andromda/samples/carrental/inventory/CarTypeData.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;InventoryException","org/andromda/samples/carrental/inventory/InventoryException.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gLnk(0, "&nbsp;InventoryService","org/andromda/samples/carrental/inventory/InventoryService.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins_web = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins, gFld("web","org/andromda/samples/carrental/admins/web.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins_web, gLnk(0, "&nbsp;AdminLoginAction","org/andromda/samples/carrental/admins/web/AdminLoginAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins_web, gLnk(0, "&nbsp;AdminLoginForm","org/andromda/samples/carrental/admins/web/AdminLoginForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins_web, gLnk(0, "&nbsp;AdminLoginPage","org/andromda/samples/carrental/admins/web/AdminLoginPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_admins_web, gLnk(0, "&nbsp;AdminMenuPage","org/andromda/samples/carrental/admins/web/AdminMenuPage.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts_web = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts, gFld("web","org/andromda/samples/carrental/contracts/web.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts_web, gLnk(0, "&nbsp;CarReservationAction","org/andromda/samples/carrental/contracts/web/CarReservationAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts_web, gLnk(0, "&nbsp;ListOfReservationsAction","org/andromda/samples/carrental/contracts/web/ListOfReservationsAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts_web, gLnk(0, "&nbsp;ReservationForm","org/andromda/samples/carrental/contracts/web/ReservationForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_contracts_web, gLnk(0, "&nbsp;ReservationPage","org/andromda/samples/carrental/contracts/web/ReservationPage.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers, gFld("web","org/andromda/samples/carrental/customers/web.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerCreationAction","org/andromda/samples/carrental/customers/web/CustomerCreationAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerCreationForm","org/andromda/samples/carrental/customers/web/CustomerCreationForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerCreationPage","org/andromda/samples/carrental/customers/web/CustomerCreationPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerLoginAction","org/andromda/samples/carrental/customers/web/CustomerLoginAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerLoginForm","org/andromda/samples/carrental/customers/web/CustomerLoginForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerLoginPage","org/andromda/samples/carrental/customers/web/CustomerLoginPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;CustomerMenuPage","org/andromda/samples/carrental/customers/web/CustomerMenuPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_customers_web, gLnk(0, "&nbsp;ListCustomersAction","org/andromda/samples/carrental/customers/web/ListCustomersAction.html", "Class.gif"))
            
        
        node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web = insFld(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory, gFld("web","org/andromda/samples/carrental/inventory/web.html", "Package.gif"))

                            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarCreationAction","org/andromda/samples/carrental/inventory/web/CarCreationAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarCreationForm","org/andromda/samples/carrental/inventory/web/CarCreationForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarCreationPage","org/andromda/samples/carrental/inventory/web/CarCreationPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarTypeCreationAction","org/andromda/samples/carrental/inventory/web/CarTypeCreationAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarTypeCreationForm","org/andromda/samples/carrental/inventory/web/CarTypeCreationForm.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;CarTypeCreationPage","org/andromda/samples/carrental/inventory/web/CarTypeCreationPage.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;ListCarTypesAction","org/andromda/samples/carrental/inventory/web/ListCarTypesAction.html", "Class.gif"))
            
        
                
        insDoc(node_AndroMDA_car_rental_sample_org_andromda_samples_carrental_inventory_web, gLnk(0, "&nbsp;ListCarsAction","org/andromda/samples/carrental/inventory/web/ListCarsAction.html", "Class.gif"))
        
