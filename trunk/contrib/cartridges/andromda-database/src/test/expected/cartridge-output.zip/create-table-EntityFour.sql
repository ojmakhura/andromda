/* --------------- EntityFour table definition --------------------- */
CREATE TABLE ENTITY_FOUR 
(
    ID NUMBER(19) NOT NULL,
    ENTITY_EIGHT_FK NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXENTITYEIGHTENTITYFOUR ON ENTITY_FOUR
(
       ENTITY_EIGHT_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_FOUR
   ADD  ( CONSTRAINT XPKENTITYFOUR PRIMARY KEY (ID) );
