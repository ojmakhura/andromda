/* --------------- EntityNine table definition --------------------- */
CREATE TABLE ENTITY_NINE 
(
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_NINE
   ADD  ( CONSTRAINT XPKENTITYNINE PRIMARY KEY (ID) );
