/* --------------- Many2ManyTwo table definition --------------------- */
CREATE TABLE MANY2_MANY_TWO (
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE MANY2_MANY_TWO
   ADD  ( CONSTRAINT XPKMANY2_MANY_TWO PRIMARY KEY (ID) );