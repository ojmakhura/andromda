/* ------------ EntityEight sequence ---------------- */
CREATE SEQUENCE ENTITY_EIGHT_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntityFour sequence ---------------- */
CREATE SEQUENCE ENTITY_FOUR_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntityOne sequence ---------------- */
CREATE SEQUENCE ENTITY_ONE_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ Many2ManyOne sequence ---------------- */
CREATE SEQUENCE MANY2_MANY_ONE_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntitySeven sequence ---------------- */
CREATE SEQUENCE ENTITY_SEVEN_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntitySix sequence ---------------- */
CREATE SEQUENCE ENTITY_SIX_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntityTwo sequence ---------------- */
CREATE SEQUENCE ENTITY_TWO_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntityThree sequence ---------------- */
CREATE SEQUENCE ENTITY_THREE_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ Many2ManyTwo sequence ---------------- */
CREATE SEQUENCE MANY2_MANY_TWO_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  
/* ------------ EntityFive sequence ---------------- */
CREATE SEQUENCE ENTITY_FIVE_SEQ                                              
INCREMENT BY 1                                                                  
START WITH 1                                                                    
MINVALUE 1                                                                      
MAXVALUE 999999999999                                                           
NOCYCLE                                                                         
NOORDER                                                                         
NOCACHE;  

