/* --------------- EntityFive table definition --------------------- */
CREATE TABLE ENTITY_FIVE 
(
    ID NUMBER(19) NOT NULL,
    MANY2_MANY_ONE_FK NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXMANY2_MANY_ONEENTITY_FIVE ON ENTITY_FIVE
(
       MANY2_MANY_ONE_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_FIVE
   ADD  ( CONSTRAINT XPKENTITY_FIVE PRIMARY KEY (ID) );
