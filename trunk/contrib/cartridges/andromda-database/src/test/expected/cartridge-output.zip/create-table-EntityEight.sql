/* --------------- EntityEight table definition --------------------- */
CREATE TABLE ENTITY_EIGHT 
(
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_EIGHT
   ADD  ( CONSTRAINT XPKENTITY_EIGHT PRIMARY KEY (ID) );