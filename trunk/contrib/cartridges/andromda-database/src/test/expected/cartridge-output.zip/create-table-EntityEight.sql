/* --------------- EntityEight table definition --------------------- */
CREATE TABLE ENTITY_EIGHT 
(
    ENTITY4_ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_EIGHT
   ADD  ( CONSTRAINT XPKENTITYEIGHT PRIMARY KEY (ENTITY4_ID) );
