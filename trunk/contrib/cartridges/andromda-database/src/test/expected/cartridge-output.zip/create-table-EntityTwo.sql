/* --------------- EntityTwo table definition --------------------- */
CREATE TABLE ENTITY_TWO 
(
    NAME VARCHAR2(255) NOT NULL,
    ATTRIBUTE_ONE NUMBER(19) NOT NULL,
    ENTITY_ONE_FK NUMBER(19) NOT NULL,
    ENTITY_THREE_FK NUMBER(19) NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXENTITYONEENTITYTWO ON ENTITY_TWO
(
       ENTITY_ONE_FK
);

CREATE INDEX IDXENTITYTHREEENTITYTWO ON ENTITY_TWO
(
       ENTITY_THREE_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_TWO
   ADD  ( CONSTRAINT XPKENTITYTWO PRIMARY KEY (NAME) );
