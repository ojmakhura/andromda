/* --------------- Many2ManyOne table definition --------------------- */
CREATE TABLE MANY2_MANY_ONE (
	ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE MANY2_MANY_ONE
   ADD  ( CONSTRAINT XPKMANY2_MANY_ONE PRIMARY KEY (ID) );