/* --------------- EntityThree table definition --------------------- */
CREATE TABLE ENTITY_THREE 
(
    ID NUMBER(19) NOT NULL,
    TEST_ATTRIBUTE NUMBER(1) NULL,
    TEST_ATTRIBUTE_TWO NUMBER(19) NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_THREE
   ADD  ( CONSTRAINT XPKENTITY_THREE PRIMARY KEY (ID) );