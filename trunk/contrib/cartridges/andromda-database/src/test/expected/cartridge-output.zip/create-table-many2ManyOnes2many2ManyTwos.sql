/* --------------- many2ManyOnes2many2ManyTwos table definition --------------------- */
CREATE TABLE MANY2_MANY_ONES2MANY2_MANY_TWO (
    $primaryKeyColumn.columnName $primaryKeyColumn.sqlType NOT NULL,
    MANY2_MANY_ONES_FK NUMBER(19) NULL,
    MANY2_MANY_TWOS_FK NUMBER(19) NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXMANY2_MANY_ONEMANY2_MANY_TW ON MANY2_MANY_ONES2MANY2_MANY_TWO
(
       MANY2_MANY_ONES_FK
);

CREATE INDEX IDXMANY2_MANY_TWOMANY2_MANY_ON ON MANY2_MANY_ONES2MANY2_MANY_TWO
(
       MANY2_MANY_TWOS_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
   ADD  ( CONSTRAINT $table.primaryKeyConstraintName PRIMARY KEY ($table.primaryKeyColumn.columnName) );