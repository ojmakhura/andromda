/* ------------- EntityTwo foreign key contraints ------------------ */
ALTER TABLE ENTITY_TWO
    ADD  ( CONSTRAINT FKENTITYONEENTITYTWO
        FOREIGN KEY (ENTITY_ONE_FK)
            REFERENCES ENTITY_ONE
                ) ;

ALTER TABLE ENTITY_TWO
    ADD  ( CONSTRAINT FKENTITYTHREEENTITYTWO
        FOREIGN KEY (ENTITY_THREE_FK)
            REFERENCES ENTITY_THREE
                ) ;

/* ------------- EntityFive foreign key contraints ------------------ */
ALTER TABLE ENTITY_FIVE
    ADD  ( CONSTRAINT FKMANY2MANYONEENTITYFIVE
        FOREIGN KEY (MANY2_MANY_ONE_FK)
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

/* ------------- EntitySeven foreign key contraints ------------------ */
ALTER TABLE ENTITY_SEVEN
    ADD  ( CONSTRAINT FKENTITYSIXENTITYSEVEN
        FOREIGN KEY (ID)
            REFERENCES ENTITY_SIX
                ) ;

ALTER TABLE ENTITY_SEVEN
    ADD  ( CONSTRAINT FKMANY2MANYTWOENTITYSEVEN
        FOREIGN KEY (MANY2_MANY_TWO_FK)
            REFERENCES MANY2_MANY_TWO
                ) ;

/* ------------- many2ManyOnes2many2ManyTwos foreign key contraints ------------------ */
ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2MANYONEMANY2MANYONES2MA
        FOREIGN KEY (MANY2_MANY_ONES_FK)
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;

ALTER TABLE MANY2_MANY_ONES2MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2MANYTWOMANY2MANYONES2MA
        FOREIGN KEY (MANY2_MANY_TWOS_FK)
            REFERENCES MANY2_MANY_TWO
                 ON DELETE CASCADE ) ;

/* ------------- EntityEight foreign key contraints ------------------ */
ALTER TABLE ENTITY_EIGHT
    ADD  ( CONSTRAINT FKENTITYFOURENTITYEIGHT
        FOREIGN KEY (ENTITY4_ID)
            REFERENCES ENTITY_FOUR
                 ON DELETE CASCADE ) ;

/* ------------- EntityThree foreign key contraints ------------------ */
ALTER TABLE ENTITY_THREE
    ADD  ( CONSTRAINT FKENTITYFOURENTITYTHREE
        FOREIGN KEY (ENTITY_FOUR_FK)
            REFERENCES ENTITY_FOUR
                ) ;


