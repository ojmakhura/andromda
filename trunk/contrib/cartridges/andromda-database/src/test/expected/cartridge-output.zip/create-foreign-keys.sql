/* ------------- many2ManyOnes2many2ManyTwos foreign key contraints ------------------ */
ALTER TABLE MANY2_MANY_TWO
    ADD  ( CONSTRAINT FKMANY2_MANY_ONEMANY2_MANY_TWO
        FOREIGN KEY (MANY2_MANY_ONES_FK)
            REFERENCES MANY2_MANY_ONE
                ) ;

ALTER TABLE MANY2_MANY_ONE
    ADD  ( CONSTRAINT FKMANY2_MANY_TWOMANY2_MANY_ONE
        FOREIGN KEY (MANY2_MANY_TWOS_FK)
            REFERENCES MANY2_MANY_TWO
                ) ;

/* ------------- EntityTwo foreign key contraints ------------------ */
ALTER TABLE ENTITY_TWO
    ADD  ( CONSTRAINT FKENTITY_THREEENTITY_TWO
        FOREIGN KEY (ENTITY_THREE_FK)
            REFERENCES ENTITY_THREE
                ) ;

/* ------------- EntityFive foreign key contraints ------------------ */
ALTER TABLE ENTITY_FIVE
    ADD  ( CONSTRAINT FKMANY2_MANY_ONEENTITY_FIVE
        FOREIGN KEY (MANY2_MANY_ONE_FK)
            REFERENCES MANY2_MANY_ONE
                 ON DELETE CASCADE ) ;


