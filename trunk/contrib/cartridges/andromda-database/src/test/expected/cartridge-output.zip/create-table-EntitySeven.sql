/* --------------- EntitySeven table definition --------------------- */
CREATE TABLE ENTITY_SEVEN 
(
    ID NUMBER(19) NOT NULL,
    ENTITY_SIX_FK NUMBER(19) NOT NULL,
    MANY2_MANY_TWO_FK NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */
CREATE INDEX IDXENTITYSIXENTITYSEVEN ON ENTITY_SEVEN
(
       ENTITY_SIX_FK
);

CREATE INDEX IDXMANY2MANYTWOENTITYSEVEN ON ENTITY_SEVEN
(
       MANY2_MANY_TWO_FK
);


/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_SEVEN
   ADD  ( CONSTRAINT XPKENTITYSEVEN PRIMARY KEY (ID) );
