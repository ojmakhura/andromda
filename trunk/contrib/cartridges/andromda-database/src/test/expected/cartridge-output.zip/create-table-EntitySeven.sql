/* --------------- EntitySeven table definition --------------------- */
CREATE TABLE ENTITY_SEVEN (
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_SEVEN
   ADD  ( CONSTRAINT XPKENTITY_SEVEN PRIMARY KEY (ID) );