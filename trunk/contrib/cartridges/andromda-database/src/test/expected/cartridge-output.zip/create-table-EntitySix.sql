/* --------------- EntitySix table definition --------------------- */
CREATE TABLE ENTITY_SIX 
(
    ID NUMBER(19) NOT NULL
);

/* ------------- relation indexes ------------------ */

/* ------------ primary key contraints ---------------- */
ALTER TABLE ENTITY_SIX
   ADD  ( CONSTRAINT XPKENTITY_SIX PRIMARY KEY (ID) );