delete from TASK;
delete from USER_ROLE;
delete from AUTHORITIES;
delete from USERS;
