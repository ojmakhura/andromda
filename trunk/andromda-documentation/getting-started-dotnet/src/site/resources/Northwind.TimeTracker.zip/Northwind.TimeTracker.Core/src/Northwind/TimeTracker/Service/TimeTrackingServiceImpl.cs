// Name: TimeTrackingServiceImpl.cs
// license-header cs merge-point
//
// This is only generated once! It will never be overwritten.
// You can (and have to!) safely modify it by hand.

using System;
using AndroMDA.NHibernateSupport;
using System.Collections;
using Northwind.TimeTracker.VO;

namespace Northwind.TimeTracker.Service
{
    public class TimeTrackingServiceImpl : TimeTrackingServiceBase
    {
        protected override TimecardVO[] HandleGetAllTimecards()
        {
            IList timecards = this.TimecardDao.LoadAll();
            IList timecardVOs = this.TimecardDao.ToTimecardVOList(timecards);
            TimecardVO[] voarray = new TimecardVO[timecardVOs.Count];
            timecardVOs.CopyTo(voarray, 0);
            return voarray;
        }
    }
}
